"""2026-10-30 20:02: 에이블리 옵션 표 가상 스크롤(24개 중 8개만 읽음) · 진열 중인 마지막 옵션(원컬러 1개) 끄기."""
import sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import soldout_display as sd

class FakeFrame:
    """가상 스크롤 표: rows 전체 중 [top//60, +8) 만 '그려진' 것으로 돌려준다."""
    def __init__(self,rows,product='진열'):
        self.rows=rows;self.top=0;self.clicks=[];self.product=product
    def visible(self):s=self.top//60;return self.rows[s:s+8]
    def evaluate(self,js,arg=None):
        if js is sd.ABLY_OPTS_JS:return [dict(r) for r in self.visible()]
        if js is sd.ABLY_SCROLL_JS:
            mx=max(0,len(self.rows)*60-480)
            if arg is not None:self.top=max(0,min(mx,arg))
            return {'top':self.top,'max':mx,'step':288,'virtual':True}
        if js is sd.ABLY_CLICK_JS:
            key,what=arg;row=next((r for r in self.visible() if r['i']==key),None)
            if not row:return 'missing'
            self.clicks.append((key,what))
            if what=='switch':row['on']=False
            if what=='rep':
                for r in self.rows:r['rep']=False
                row['rep']=True
            return 'clicked'
        if js is sd.ABLY_RADIO_STATE_JS:return self.product
        if js is sd.ABLY_RADIO_JS:self.product='미진열';return 'off'
        raise AssertionError(js[:40])
    def locator(self,*a,**k):raise AssertionError('no locator')

def rows24():
    out=[]
    for ci,c in enumerate(['블랙','그레이','스카이블루','옐로우','아이보리','핑크']):
        for si,s in enumerate(['M（44）','L（55）','XL（66）','XXL（77）']):
            n=str(413713525+ci*4+si);out.append({'i':n,'no':n,'color':c,'size':s,'on':True,'disabled':False,'rep':ci==0 and si==0})
    return out

class Page:
    def wait_for_timeout(self,ms):pass

def flow(frame):
    f=sd.AblyDisplayFlow.__new__(sd.AblyDisplayFlow);f.f=frame;f.page=Page();f.step=''
    f.open_edit=lambda no:None;f.save=lambda:frame.clicks.append(('save',''))
    return f

class VirtualOptions(unittest.TestCase):
    def test_reads_all_24_options_through_scrolling(self):
        f=flow(FakeFrame(rows24()));opts=f.options()
        self.assertEqual(len(opts),24);self.assertEqual(len({o['color'] for o in opts}),6)
    def test_turns_off_option_below_the_fold(self):
        fr=FakeFrame(rows24());f=flow(fr)
        r=f.set_off('54823839','아이보리','XXL(77)')
        self.assertEqual(r['result'],'에이블리 처리 완료');self.assertIn('아이보리',r['detail'])
        self.assertIn(('413713544','switch'),fr.clicks);self.assertFalse(next(x for x in fr.rows if x['no']=='413713544')['on'])
    def test_rep_option_moves_to_other_displayed_option(self):
        fr=FakeFrame(rows24());f=flow(fr)
        r=f.set_off('1','블랙','M(44)')
        self.assertIn('대표 옵션 →',r['detail']);self.assertTrue(any(w=='rep' for _,w in fr.clicks))
    def test_last_displayed_option_hides_whole_product(self):
        fr=FakeFrame([{'i':'1','no':'1','color':'차콜（원컬러）','size':'FREE','on':True,'disabled':False,'rep':True}]);f=flow(fr)
        r=f.set_off('60213298','차콜(원컬러)','FREE')
        self.assertEqual(r['result'],'에이블리 처리 완료');self.assertIn('상품 전체 미진열',r['detail']);self.assertIn('마지막 옵션',r['detail'])
        self.assertEqual(fr.product,'미진열');self.assertFalse(any(w=='switch' for _,w in fr.clicks))
    def test_last_displayed_among_many_hides_product(self):
        rows=rows24()
        for r in rows[1:]:r['on']=False
        fr=FakeFrame(rows);r=flow(fr).set_off('1','블랙','M(44)')
        self.assertIn('상품 전체 미진열',r['detail'])
    def test_already_hidden_option_reports_already(self):
        rows=rows24();rows[19]['on']=False
        r=flow(FakeFrame(rows)).set_off('1','아이보리','XXL(77)');self.assertEqual(r['result'],'에이블리 이미 미진열')
if __name__=='__main__':unittest.main()
