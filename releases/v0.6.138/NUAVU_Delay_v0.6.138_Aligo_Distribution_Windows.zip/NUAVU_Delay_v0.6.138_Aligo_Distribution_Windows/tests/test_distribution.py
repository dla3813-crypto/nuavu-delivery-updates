import copy,json,tempfile,unittest,subprocess,sys,plistlib
from datetime import datetime,timedelta
from pathlib import Path
from unittest.mock import patch
import pytest
from helpers import Base,Clock,MemoryVault,FakeSMS
from domain import Engine,Store,FIRST,CHANGE,SOLDOUT_BANK,SOLDOUT_CARD,KST,ValidationError,report_due,parse_time,bytecount,now
from branding import clean_name,render_template,canonical_template,safe_outgoing,message_title,normalize_seller
from provider import AligoSMS,Credential,ProviderError,UncertainError,report_status,safe_text,integer
from aligo_workflow import TEMPLATE_KEYS
from install_desktop import build_bundle

@pytest.mark.parametrize('name',['데모스토어','다른쇼핑몰','NOVA SHOP','한'*30])
@pytest.mark.parametrize('template',[FIRST,CHANGE,SOLDOUT_CARD,SOLDOUT_BANK])
def test_brand_render(name,template):
    text=render_template(template,name)
    assert text.startswith('안녕하세요. 고객님\n'+name+'입니다.')
    assert '누아브' not in text and 'nuavu.kr' not in text
    assert len(message_title(name).encode('cp949'))<=40

@pytest.mark.parametrize('name',['누아브','NUAVU','nuavu'])
def test_own_shop_link_retained(name):assert 'http://nuavu.kr' in render_template(SOLDOUT_BANK,name)

@pytest.mark.parametrize('name',['',None,True,'한'*31,'가\n나','😀','{쇼핑몰명}','<b>쇼핑몰</b>'])
def test_bad_shop_name(name):
    with pytest.raises(ValidationError):clean_name(name)

@pytest.mark.parametrize('state,expected',[
    ('발송완료','DELIVERED'),('발송실패','FAILED'),('전송완료','DELIVERED'),('성공','DELIVERED'),
    ('대기','PENDING'),('발송중','PENDING'),('접수완료','PENDING'),('알수없음','PENDING'),
    ('1000','PENDING'),(1000,'PENDING'),(1,'PENDING'),(True,'PENDING'),('', 'PENDING')])
def test_detail_states(state,expected):assert report_status(state)==expected

@pytest.mark.parametrize('value',[True,1.0,'1.0','NaN',None,{},[]])
def test_strict_integer(value):assert integer(value) is None

class AdapterTests(unittest.TestCase):
    def setUp(self):self.cred=Credential('FAKE-ID','FAKE-KEY')
    def adapter(self,response):
        self.calls=[]
        def transport(path,fields):self.calls.append((path,fields));return response
        return AligoSMS(transport)
    def send(self,p):return p.send('LMS',self.cred,'0212345678','01000000000','테스트','테스트')
    def test_request_spec(self):
        p=self.adapter({'result_code':1,'msg_id':123,'success_cnt':1,'error_cnt':0,'msg_type':'LMS'})
        self.assertEqual(self.send(p),{'mid':'123'});path,f=self.calls[0]
        self.assertEqual(path,'/send/');self.assertEqual(set(f),{'key','userid','sender','receiver','msg','msg_type','title','testmode_yn'})
        self.assertEqual(f['userid'],'FAKE-ID');self.assertEqual(f['testmode_yn'],'N');self.assertNotIn('rdate',f)
    def test_explicit_rejection(self):
        p=self.adapter({'result_code':-101,'message':'bad FAKE-KEY FAKE-ID'})
        with self.assertRaises(ProviderError) as e:self.send(p)
        self.assertNotIn('FAKE-KEY',str(e.exception));self.assertEqual(len(self.calls),1)
    def test_inconsistent_acceptance_never_retried(self):
        for extra in [{'msg_id':None},{'success_cnt':0},{'error_cnt':1},{'msg_type':'SMS'}]:
            p=self.adapter({'result_code':1,'msg_id':123,'success_cnt':1,'error_cnt':0,'msg_type':'LMS'}|extra)
            with self.assertRaises(UncertainError):self.send(p)
            self.assertEqual(len(self.calls),1)
    def test_numeric_string_acceptance(self):
        p=self.adapter({'result_code':'1','msg_id':'123','success_cnt':'1','error_cnt':'0'})
        self.assertEqual(self.send(p)['mid'],'123')
    def test_redirect_or_http_not_used(self):
        p=self.adapter({})
        with self.assertRaises(ProviderError):p.send('LMS',self.cred,'0212345678','01000000000','a','a','http')
        self.assertFalse(self.calls)
    def test_no_multi_recipient_parameter(self):
        p=self.adapter({})
        with self.assertRaises(ProviderError):p.send('LMS',self.cred,'0212345678','01000000000,01000000001','a','a')
        self.assertFalse(self.calls)
    def test_timeout_is_not_retried(self):
        calls=[]
        def timeout(*args):calls.append(1);raise UncertainError('offline timeout')
        with self.assertRaises(UncertainError):self.send(AligoSMS(timeout))
        self.assertEqual(len(calls),1)
    def test_detail_uses_mid_and_pagination(self):
        calls=[]
        def transport(path,f):calls.append((path,f));return {'result_code':1,'list':[{'mdid':str(f['page'])}],'next_yn':'Y' if f['page']==1 else 'N'}
        rows=AligoSMS(transport).detail(self.cred,'123')
        self.assertEqual(len(rows),2);self.assertTrue(all(p=='/sms_list/' and f['mid']=='123' for p,f in calls))
    def test_invalid_detail_shape(self):
        with self.assertRaises(UncertainError):self.adapter({'result_code':1,'list':{}}).detail(self.cred,'123')
    def test_empty_details_pending(self):self.assertEqual(self.adapter({'result_code':1,'list':[],'next_yn':'N'}).detail(self.cred,'123'),[])
    def test_no_plain_api_key_repr(self):self.assertNotIn('FAKE-KEY',repr(self.cred))
    def test_actual_tls_verification(self):
        import ssl
        from aligo_http import verified_context
        ctx=verified_context();self.assertTrue(ctx.check_hostname);self.assertEqual(ctx.verify_mode,ssl.CERT_REQUIRED)

class ShopTests(Base):
    def test_all_default_templates_work(self):
        for key in ['first','change','soldout_card','soldout_bank']:
            p=self.data(template=self.engine.message_templates()[key],noticeType=key if key.startswith('soldout') else 'delay',dueDate='' if key.startswith('soldout') else '2026-10-21')
            g=self.engine.build_sms_groups(self.store.read(),p)[0]
            self.assertIn('데모스토어입니다.',g['content']);self.assertNotIn('누아브',g['content']);self.assertNotIn('nuavu.kr',g['content'])
    def test_draft_name_renames_and_persists(self):
        self.queue(template=render_template(FIRST,'데모스토어'));self.engine.configure_shop({'shopName':'두번째몰'});self.restart()
        self.assertIn('두번째몰입니다.',self.engine.public_state()['settings']['smsTemplates']['first'])
        self.assertNotIn('데모스토어',self.engine.public_state()['settings']['smsTemplates']['first'])
    def test_name_change_pauses_and_prevents_resume(self):
        self.queue(sendMode='MORNING');self.engine.configure_shop({'shopName':'두번째몰'})
        self.assertEqual(self.last()['status'],'PAUSED');self.assertFalse(self.engine.send_one())
        with self.assertRaises(ValidationError):self.engine.queue_control({'action':'resume','confirmed':True})
        self.restart();self.assertEqual(self.last()['status'],'PAUSED');self.assertFalse(self.fake.sent)
    def test_name_change_keeps_sent_history(self):
        self.send();before=self.last();self.engine.configure_shop({'shopName':'두번째몰'});self.assertEqual(self.last(),before)
    def test_name_change_invalidates_preview(self):
        p=self.engine.preview(self.data());self.engine.configure_shop({'shopName':'두번째몰'})
        with self.assertRaises(ValidationError):self.engine.commit({'token':p['token']})
    def test_same_name_does_not_pause(self):
        self.queue();self.engine.configure_shop({'shopName':'데모스토어'});self.assertEqual(self.last()['status'],'QUEUED')
    def test_blank_brand_blocks_composition(self):
        with self.store.edit() as s:s['settings']['shopName']=''
        with self.assertRaises(ValidationError):self.engine.preview(self.data())
    def test_foreign_literal_in_product_blocked(self):
        with self.store.edit() as s:s['rows'][0]['product']='누아브 이름이 남은 상품'
        with self.assertRaises(ValidationError):self.engine.preview(self.data())
    def test_key_not_in_state_or_csv(self):
        self.send();raw=json.dumps(self.engine.public_state(),ensure_ascii=False)+str(self.engine.export_csv())
        self.assertNotIn('FAKE-KEY-OFFLINE-ONLY',raw);self.assertEqual(self.vault.value['provider'],'ALIGO_SMS')
    def test_same_id_blank_key_retained(self):
        self.engine.configure({'user':'DEMO','apikey':'','sender':'0212345678'});self.assertEqual(self.engine.credential('LMS').apikey,'FAKE-KEY-OFFLINE-ONLY')
    def test_new_id_blank_key_blocked(self):
        with self.assertRaises(ValidationError):self.engine.configure({'user':'OTHER','apikey':'','sender':'0212345678'})
    def test_restart_restores_only_new_aligo_credential(self):
        self.restart();self.assertTrue(self.engine.public_state()['credentialsReady']['LMS']);self.assertEqual(self.engine.credential('LMS').user,'DEMO')
    def test_legacy_keychain_payload_rejected(self):
        self.vault.value['provider']='OLD';self.restart();self.assertFalse(self.engine.public_state()['credentialsReady']['LMS'])
    def test_table_zoom_persists_no_send(self):
        self.engine.configure_view({'tableZoom':80});self.restart();self.assertEqual(self.engine.public_state()['settings']['tableZoom'],80);self.assertFalse(self.fake.calls)
    def test_zoom_invalid_values(self):
        for value in [True,0,59,165,99,'100',100.0]:
            with self.assertRaises(ValidationError):self.engine.configure_view({'tableZoom':value})
    def test_import_configured_prefix(self):
        self.assertEqual(normalize_seller('데모스토어 에이블리','데모스토어'),'누아브 에이블리')
        self.assertIsNone(normalize_seller('다른몰 에이블리','데모스토어'))
        r=self.store.read()['rows'][0]|{'seller':'데모스토어 에이블리','orderId':'NEW-ALIAS'}
        self.engine.import_rows({'rows':[r]});self.assertEqual(self.store.read()['rows'][-1]['seller'],'누아브 에이블리')
    def test_same_sender_receiver_allowed_by_sms_adapter(self):
        self.engine.configure({'user':'DEMO','apikey':'','sender':'01000001234'});self.send();self.assertEqual(self.last()['status'],'PENDING')

class ReceiptTests(Base):
    def test_acceptance_stays_pending_stores_mid(self):
        n=self.send();self.assertEqual(n['status'],'PENDING');self.assertEqual(n['aligoMid'],'1000');self.assertEqual(n['provider'],'ALIGO_SMS');self.assertFalse(self.row()['deliveryVerified'])
    def test_query_at_15s_and_acceptance_plus60s(self):
        self.fake.empty=True;n=self.send();self.at_age(n,seconds=14);self.engine.poll();self.assertFalse(self.fake.report_calls)
        self.at_age(n,seconds=15);self.engine.poll();self.assertEqual(len(self.fake.report_calls),1);self.assertEqual(self.last()['resultReview'],'WATCH_15S')
        self.assertEqual(parse_time(self.last()['nextCheckAt']),parse_time(n['acceptedAt'])+timedelta(seconds=60))
        self.at_age(n,seconds=59);self.engine.poll();self.assertEqual(len(self.fake.report_calls),1)
        self.at_age(n,seconds=60);self.engine.poll();self.assertEqual(len(self.fake.report_calls),2);self.assertEqual(self.last()['status'],'PENDING');self.assertEqual(self.last()['resultReview'],'UNCONFIRMED_1M')
        self.assertFalse(self.engine.send_one());self.assertEqual(len(self.fake.sent),1)
    def test_exact_delivered_row(self):
        self.send();self.engine.poll(force=True);self.assertEqual(self.last()['status'],'DELIVERED');self.assertTrue(self.row()['deliveryVerified'])
    def test_exact_failed_row(self):
        self.fake.result='발송실패';self.send();self.engine.poll(force=True);self.assertEqual(self.last()['status'],'FAILED');self.assertFalse(self.engine.send_one());self.assertEqual(len(self.fake.sent),1)
    def test_unknown_numeric_not_success(self):
        self.fake.result='1000';n=self.send();self.at_age(n,seconds=60);self.engine.poll();self.assertEqual(self.last()['status'],'PENDING')
    def test_wrong_recipient(self):
        self.fake.row_override={'receiver':'01000009999'};self.send();self.engine.poll(force=True);self.assertEqual(self.last()['status'],'PENDING')
    def test_wrong_sender(self):
        self.fake.row_override={'sender':'0211112222'};self.send();self.engine.poll(force=True);self.assertEqual(self.last()['status'],'PENDING')
    def test_wrong_type(self):
        self.fake.row_override={'type':'SMS'};self.send();self.engine.poll(force=True);self.assertEqual(self.last()['status'],'PENDING')
    def test_ambiguous_rows(self):
        self.fake.duplicate=True;self.send();self.engine.poll(force=True);self.assertEqual(self.last()['status'],'PENDING')
    def test_query_error_stays_pending(self):
        self.fake.report_error=True;self.send();self.engine.poll(force=True);self.assertEqual(self.last()['status'],'PENDING')
    def test_timeout_never_retries_after_restart(self):
        self.fake.error=UncertainError('synthetic timeout');self.send();self.assertEqual(self.last()['status'],'UNKNOWN');self.restart()
        self.fake.error=None;self.engine.poll(force=True);self.assertFalse(self.engine.send_one());self.assertEqual(len([c for c in self.fake.calls if c[0]=='/send/']),1)
    def test_duplicate_commit_no_duplicate_send(self):
        p=self.engine.preview(self.data());self.engine.commit({'token':p['token']});self.engine.commit({'token':p['token']});self.engine.send_one();self.assertFalse(self.engine.send_one());self.assertEqual(len(self.fake.sent),1)
    def test_morning_request_kept_local(self):
        self.clock(20);self.queue(sendMode='MORNING');self.assertFalse(self.engine.send_one());self.assertFalse(self.fake.sent)
        self.clock(9,15);self.engine.send_one();self.assertEqual(self.last()['status'],'PENDING');self.assertNotIn('rdate',self.fake.sent[0]['fields'])
    def test_queued_restart_resumes_once(self):
        self.queue();self.restart();self.engine.send_one();self.assertFalse(self.engine.send_one());self.assertEqual(len(self.fake.sent),1)

class AlimtalkTests(Base):
    def test_no_bundled_codes_account_or_body(self):
        with tempfile.TemporaryDirectory() as d:
            store=Store(d);e=Engine(store);s=e.public_state()['aligo'];self.assertEqual(s['user'],'');self.assertFalse(s['enabled'])
            self.assertTrue(all(not t['code'] and not t['body'] for t in s['templates'].values()));store.close()
    def test_configured_templates_load(self):self.assertEqual(self.setup_at()['count'],2)
    def test_other_shop_template_rejected_not_rewritten(self):
        self.at.body=render_template(FIRST,'누아브');self.assertEqual(self.setup_at()['count'],0);self.assertFalse(self.at.sent)
    def test_other_shop_button_rejected(self):
        self.at.buttons=[{'name':'사이트','linkM':'http://nuavu.kr'}];self.assertEqual(self.setup_at()['count'],0)
    def test_accepted_alimtalk_no_fallback(self):
        self.setup_at();self.send(deliveryChannel='AT',aligoTemplate='first');self.engine.poll(force=True);self.assertFalse(self.fake.sent);self.assertEqual(len(self.store.read()['notices']),1)
    def test_unknown_alimtalk_no_fallback(self):
        self.setup_at();self.at.empty=True;n=self.send(deliveryChannel='AT',aligoTemplate='first');self.at_age(n,seconds=60);self.engine.poll();self.assertEqual(len(self.store.read()['notices']),1)
    def test_definite_failure_creates_single_aligo_lms(self):
        self.setup_at();self.at.result='카카오톡 미사용자';self.send(deliveryChannel='AT',aligoTemplate='first');self.engine.poll(force=True)
        child=self.last();self.assertEqual(child['kind'],'LMS');self.assertEqual(child['provider'],'ALIGO_SMS');self.assertIn('데모스토어입니다.',child['content']);self.assertNotIn('누아브',child['content'])
        self.engine.poll(force=True);self.restart();self.engine.poll(force=True);self.assertEqual(len(self.store.read()['notices']),2)
        self.engine.send_one();self.assertEqual(len(self.fake.sent),1);self.assertEqual(self.last()['status'],'PENDING')
    def test_provider_sms_already_exists_no_duplicate(self):
        self.setup_at();self.at.result='카카오톡 미사용자';self.at.smid='123';self.send(deliveryChannel='AT',aligoTemplate='first');self.engine.poll(force=True)
        self.assertEqual(len(self.store.read()['notices']),1);self.assertEqual(self.last()['fallbackDecision'],'HELD')
    def test_shop_change_holds_old_fallback(self):
        self.setup_at();self.at.result='카카오톡 미사용자';self.send(deliveryChannel='AT',aligoTemplate='first');self.engine.configure_shop({'shopName':'새로운몰'});self.engine.poll(force=True)
        self.assertEqual(len(self.store.read()['notices']),1);self.assertEqual(self.last()['fallbackDecision'],'HELD')
    def test_timeout_at_acceptance_never_falls_back(self):
        self.setup_at();self.at.error=UncertainError('synthetic timeout');self.send(deliveryChannel='AT',aligoTemplate='first');self.engine.poll(force=True)
        self.assertEqual(self.last()['status'],'UNKNOWN');self.assertEqual(len(self.store.read()['notices']),1)
    def test_approved_body_is_unchanged(self):
        self.setup_at();self.send(deliveryChannel='AT',aligoTemplate='first');n=self.last();self.assertNotIn('안내번호:',n['content']);self.assertIn('안내번호:',n['fallback']['content'])

class PackagingTests(unittest.TestCase):
    def test_bundle_isolated_includes_new_module(self):
        with tempfile.TemporaryDirectory() as d:
            app=build_bundle(Path(d)/'배송안내 배포판.app',Path('/example/isolated/python'))
            info=plistlib.loads((app/'Contents/Info.plist').read_bytes());self.assertEqual(info['CFBundleVersion'],'0.6.138');self.assertTrue(info['CFBundleIdentifier'].endswith('.distribution'))
            self.assertTrue((app/'Contents/Resources/branding.py').exists());self.assertFalse((app/'Contents/Resources/data').exists())
            self.assertEqual(info['CFBundleIconFile'],'CS-Pink.icns')
            self.assertEqual((app/'Contents/Resources/CS-Pink.icns').read_bytes(),(Path(__file__).resolve().parents[1]/'assets/CS-Pink.icns').read_bytes())
            for name in ('order_export.py','color_labels.py','templates/order_export.xlsx','CS-Pink.icns'):
                self.assertTrue((app/'Contents/Resources'/name).is_file(),name)
    def test_foreign_edition_db_refused(self):
        with tempfile.TemporaryDirectory() as d:
            store=Store(d)
            with store.edit() as s:s.pop('edition')
            store.close()
            with self.assertRaises(ValidationError):Store(d)
    def test_command_shell_syntax(self):
        for p in Path(__file__).resolve().parents[1].glob('*.command'):subprocess.run(['bash','-n',str(p)],check=True)
    def test_no_old_sms_network_or_password_ui(self):
        # 2026-10-26 17:46 요청: 배포판에도 너나우리 경로(선택) 추가 → 너나우리 통신은 nunauri_provider.py 한 곳에만, 알리고 어댑터(provider.py)는 그대로.
        root=Path(__file__).resolve().parents[1]
        for name in ['provider.py','domain.py','aligo_workflow.py','web/app.js','web/index.html']:
            source=(root/name).read_text();self.assertNotIn('youiwe.co.kr',source)
        self.assertIn('youiwe.co.kr',(root/'nunauri_provider.py').read_text())
    def test_nunauri_password_never_in_db(self):
        import json,tempfile
        from domain import Store,Engine
        from helpers import FakeSMS,MemoryVault,FakeAT
        with tempfile.TemporaryDirectory() as d:
            store=Store(d);e=Engine(store,FakeSMS(),MemoryVault(),aligo_provider=FakeAT(),aligo_vault=MemoryVault(),nuna_vault=MemoryVault())
            e.configure_nunauri({'smsUser':'NUNA','smsPassword':'SECRET-FAKE-PW','lmsUser':'NUNA','lmsPassword':'SECRET-FAKE-PW'})
            self.assertNotIn('SECRET-FAKE-PW',json.dumps(store.read(),ensure_ascii=False));self.assertNotIn('SECRET-FAKE-PW',json.dumps(e.public_state(),ensure_ascii=False))
            store.close()
