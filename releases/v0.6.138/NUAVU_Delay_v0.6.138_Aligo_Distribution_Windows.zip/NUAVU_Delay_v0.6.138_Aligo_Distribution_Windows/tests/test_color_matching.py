"""Color annotation regression checks with synthetic workbooks and fake senders."""
import copy
import unicodedata
from pathlib import Path

import pytest

from domain import SELLERS
from helpers import Base
from supply_workflow import candidates, order_signature, variant_id
from test_supply_regression import order, source_row, xlsx


def candidate(option, color, source_size='F', product='가디건', source_product='가디건'):
    source = dict(brand='N', product=source_product, color=color, size=source_size)
    source['variant'] = variant_id(source)
    return candidates(dict(product=product, option=option), [source], {})[0]


@pytest.mark.parametrize('option,color', [
    ('다크그레이', '深灰色 다크그레이17'),
    ('다크그레이 / FREE', '深灰色 다크그레이17'),
    ('[다크 그레이-FREE]', '深灰色 다크그레이17'),
    ('색상: 다크 그레이 / 사이즈:', '深灰色 다크그레이17'),
    ('深灰色 다크그레이17 / FREE', '다크그레이'),
    ('深灰色 다크17그레이 / FREE', '深灰色 다크그레이99'),
    ('다크\t그레이', '深灰色\n다크\u3000그레이１７'),
    (unicodedata.normalize('NFD', '다크 그레이'), '深灰色 다크그레이17'),
    ('Dark Gray', '深灰色 DARK GRAY17'),
    ('아이보리 / FREE', '米白色 아이보리03'),
    ('블랙 / FREE', '黑色 블랙2'),
])
def test_color_annotations_match_on_either_side(option, color):
    assert len(candidate(option, color)) == 1


@pytest.mark.parametrize('option,color', [
    ('그레이', '深灰色 다크그레이17'),
    ('다크그레이', '浅灰色 라이트그레이17'),
    ('블랙', '米白色 아이보리03'),
    ('深灰色17 / FREE', '深灰色17'),
    ('17 / FREE', '18'),
    (' / FREE', '深灰色17'),
    ('다크그레이', '深灰色17'),
    ('深灰色17', '다크그레이'),
])
def test_different_or_unknown_colors_do_not_match(option, color):
    assert not candidate(option, color)


@pytest.mark.parametrize('option,source_size,expected', [
    ('다크그레이 / 55', '55', True),
    ('다크그레이 / 55', '66', False),
    ('다크그레이 / 2XL', '2XL', True),
    ('다크그레이 / 2XL', 'XL', False),
    ('다크그레이 / M', 'L', False),
    ('다크그레이', 'L', True),
])
def test_sizes_remain_distinct(option, source_size, expected):
    assert bool(candidate(option, '深灰色 다크그레이17', source_size)) is expected


def test_product_numbers_remain_distinct():
    assert not candidate('다크그레이', '深灰色 다크그레이17',
                         product='가디건17', source_product='가디건18')


def test_persisted_identifiers_remain_v0615_compatible():
    source = dict(brand='N', product='가디건', color='深灰色 다크그레이17', size='F')
    assert variant_id(source) == '197a82fb9469c498d57e7a929f52180759fb1c797f3ea0e89a09640e8b2ec20c'
    assert variant_id(source) != variant_id(source | {'color': '다크그레이'})
    assert order_signature(dict(product='가디건', option='深灰色 다크그레이17')) != \
        order_signature(dict(product='가디건', option='다크그레이'))


class ColorWorkflowTests(Base):
    def setUp(self):
        super().setUp()
        self.folder = Path(self.tmp.name) / 'color-supply'
        self.folder.mkdir()
        self.engine.supply_link(str(self.folder))
        self.set_orders([order(1, option='다크그레이')])

    def set_orders(self, rows):
        self.engine.import_rows(dict(rows=rows, mode='snapshot', scope=SELLERS, replaceConfirmed=True))

    def write(self, name, rows):
        (self.folder / name).write_bytes(xlsx([('테스트', rows)]))

    def active(self):
        return {r['orderId']: r for r in self.engine.public_state()['rows'] if r['active']}

    def test_latest_progress_match_preserves_source_text_and_orders(self):
        self.write('진행상황_1016.xlsx', [source_row(color='深灰色 다크그레이17', qty=50, office='2026-10-13')])
        self.write('진행상황_1017.xlsx', [source_row(color='深灰色 다크그레이17', office='2026-10-17')])
        before = copy.deepcopy(self.store.read()['rows'])
        result = self.engine.supply_refresh()
        row = self.active()['TEST-001']
        self.assertEqual(result['progressSelection']['name'], '진행상황_1017.xlsx')
        self.assertEqual(row['supplyInfo']['plannedQty'], 1)
        self.assertEqual(row['supplyInfo']['sources'][0]['color'], '深灰色 다크그레이17')
        self.assertEqual(row['dispatchEnd'], '2026-10-22')
        self.assertEqual(self.store.read()['rows'], before)
        self.assertFalse(self.fake.sent)
        self.assertFalse(self.at.sent)

    def test_manifest_color_match_conserves_fifo_stock(self):
        self.set_orders([order(2, option='深灰色 다크그레이17 / FREE'), order(1, option='다크 그레이')])
        self.write('솔리아 10월 13일 출고장 (완료).xlsx', [source_row(color='深灰色 다크그레이17')])
        self.engine.supply_refresh()
        rows = self.active()
        self.assertTrue(rows['TEST-001']['stockSecured'])
        self.assertFalse(rows['TEST-002']['stockSecured'])
        self.assertTrue(rows['TEST-002']['supplyInfo']['matched'])
        self.assertEqual(sum(r['supplyInfo']['allocatedQty'] for r in rows.values()), 1)

    def test_color_annotations_cannot_double_count_the_same_supply_wave(self):
        self.set_orders([order(1, option='다크그레이'), order(2, option='다크그레이')])
        self.write('솔리아 10월 13일 출고장 (완료).xlsx', [source_row(color='다크그레이')])
        self.write('진행상황_1017.xlsx', [source_row(color='深灰色 다크그레이17', office='2026-10-13')])
        self.engine.supply_refresh()
        self.assertEqual(sum(r['supplyInfo']['allocatedQty'] for r in self.active().values()), 1)

    def test_closed_manifest_not_reused_from_annotated_progress(self):
        self.write('솔리아 10월 13일 출고장 (완료).xlsx', [source_row(color='다크그레이')])
        self.engine.supply_refresh()
        self.engine.supply_reset({'confirmed': True})
        self.set_orders([order(2, option='다크그레이')])
        self.write('진행상황_1017.xlsx', [source_row(color='深灰色 다크그레이17', office='2026-10-13')])
        self.engine.supply_refresh()
        self.assertEqual(self.active()['TEST-002']['supplyInfo']['allocatedQty'], 0)

    def test_later_wave_is_still_available(self):
        self.set_orders([order(1, option='다크그레이'), order(2, option='다크그레이')])
        self.write('솔리아 10월 13일 출고장 (완료).xlsx', [source_row(color='다크그레이')])
        self.write('진행상황_1017.xlsx', [source_row(color='深灰色 다크그레이17', office='2026-10-17')])
        self.engine.supply_refresh()
        self.assertEqual(self.active()['TEST-001']['supplyInfo']['manifestQty'], 1)
        self.assertEqual(self.active()['TEST-002']['supplyInfo']['plannedQty'], 1)

    def test_post_cutoff_progress_keeps_explicit_sizes_distinct(self):
        self.set_orders([order(1, option='다크그레이 / 55'), order(2, option='다크그레이 / 66')])
        self.write('솔리아 10월 13일 출고장 (완료).xlsx', [source_row(color='다크그레이', size='55')])
        self.write('진행상황_1017.xlsx', [source_row(color='深灰色 다크그레이17', size='66', office='2026-10-14')])
        self.engine.supply_refresh()
        self.assertEqual(self.active()['TEST-001']['supplyInfo']['manifestQty'], 1)
        self.assertEqual(self.active()['TEST-002']['supplyInfo']['plannedQty'], 1)

    def test_manual_mapping_and_sealed_allocations_survive_restart(self):
        self.write('솔리아 10월 13일 출고장 (완료).xlsx', [source_row(product='수동 연결 상품', color='深灰色 다크그레이17')])
        self.engine.supply_refresh()
        row = self.active()['TEST-001']
        vid = self.engine.public_state()['supply']['variants'][0]['variant']
        self.engine.supply_match({'key': row['key'], 'variants': [vid]})
        self.engine.supply_reset({'confirmed': True})
        before = copy.deepcopy(self.store.read()['supply'])
        self.restart()
        self.assertEqual(self.store.read()['supply'], before)
        self.assertTrue(self.active()['TEST-001']['stockSecured'])

    def test_v0615_update_preserves_state_and_pending_notices(self):
        self.write('진행상황_1017.xlsx', [source_row(color='深灰色 다크그레이17', office='2026-10-17')])
        self.engine.supply_refresh()
        self.queue(keys=[self.active()['TEST-001']['key']], sendMode='MORNING')
        with self.store.edit() as state:
            state['appVersion'] = '0.6.15'
            state['alerts'].append(dict(code='RESULT_UNCONFIRMED', resolvedAt='', id='TEST', noticeId='EXAMPLE', level='error'))
        before = copy.deepcopy(self.store.read())
        self.restart()
        after = self.store.read()
        for key in ['rows', 'settings', 'supply', 'alerts']:
            self.assertEqual(after[key], before[key], key)
        for old, new in zip(before['notices'], after['notices']):
            for key in old.keys() | new.keys():
                if key not in {'events', 'note', 'resumedAt'}:
                    self.assertEqual(new.get(key), old.get(key), key)
        self.assertEqual(after['appVersion'], '0.6.138')
        self.assertFalse(self.fake.sent)
        self.assertFalse(self.at.sent)
