"""2026-10-30: 배송전 주문교환(옵션 교환 후 출고 대기) 주문이 'C/S 정상' 조회에서 빠져 앱에 안 잡힘.
이지어드민에서 확인: 같은 조건에 C/S '정상' 0건 → '정상+교환' 1건. 조회 조건을 '정상+교환'으로."""
import re,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class CsFilter(unittest.TestCase):
    def test_query_uses_normal_plus_exchange_and_checks_it(self):
        src=(ROOT/'order_browser.py').read_text(encoding='utf-8')
        self.assertIn("""select[name="order_cs_sel"]').select_option(label='정상+교환')""",src)
        self.assertIn("""('select[name="order_cs_sel"]','정상+교환')""",src)
        self.assertNotRegex(src,r"order_cs_sel\"\]'\)\.select_option\(label='정상'\)")
        self.assertIn('C/S 정상+교환',(ROOT/'web'/'index.html').read_text(encoding='utf-8'))
if __name__=='__main__':unittest.main()
