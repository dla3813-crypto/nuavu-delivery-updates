"""2026-10-28 21:46 요청 'CPU 최소한으로': 놀고 있을 때 5초마다 11MB 상태를 다시 저장하던 문제 (예약 주문취소 확인)와
1~5초 루프들이 매번 전체 상태를 다시 해석하던 문제. 내용이 그대로면 저장·리비전 증가 없음, 읽기 전용 확인은 캐시(peek)."""
import json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import domain
from domain import Store

class StoreIdle(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.store=Store(self.tmp.name)
    def tearDown(self):self.store.close();self.tmp.cleanup()
    def rev(self):return self.store.read()['revision']
    def test_noop_edit_does_not_save_or_bump(self):
        r=self.rev()
        with self.store.edit() as s:pass
        with self.store.edit() as s:s['rows']=list(s['rows'])
        self.assertEqual(self.rev(),r);self.assertEqual(self.store.version,r)
        with self.store.edit() as s:s['x']=1
        self.assertEqual(self.rev(),r+1);self.assertEqual(self.store.version,r+1)
    def test_exception_in_edit_saves_nothing(self):
        r=self.rev()
        with self.assertRaises(ValueError):
            with self.store.edit() as s:s['x']=1;raise ValueError('x')
        self.assertEqual(self.rev(),r);self.assertNotIn('x',self.store.read())
    def test_peek_is_cached_until_revision_changes(self):
        a=self.store.peek();self.assertIs(self.store.peek(),a)
        with self.store.edit() as s:pass
        self.assertIs(self.store.peek(),a)                  # 빈 저장은 캐시를 깨지 않음
        with self.store.edit() as s:s['x']=2
        b=self.store.peek();self.assertIsNot(b,a);self.assertEqual(b['x'],2)

class ControllerIdle(unittest.TestCase):
    def setUp(self):
        try:from test_v052 import MemoryVault
        except ImportError:from helpers import MemoryVault
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(self.tmp.name);self.engine=domain.Engine(self.store,None,MemoryVault())
    def tearDown(self):self.store.close();self.tmp.cleanup()
    def test_run_due_without_schedule_never_writes(self):
        from soldout_display import SoldoutDisplayController
        c=SoldoutDisplayController(self.engine);r=self.store.read()['revision']
        with patch.object(self.store,'edit',side_effect=AssertionError('빈 확인에서 저장하면 안 됩니다')):
            for _ in range(5):self.assertFalse(c.run_due())
        self.assertEqual(self.store.read()['revision'],r)
    def test_idle_minute_parses_state_rarely(self):
        clock=[1000.0];r=self.store.read()['revision'];n=[0];orig=json.loads
        def count(*a,**k):
            if a and isinstance(a[0],str) and '"revision"' in a[0][:200000]:n[0]+=1
            return orig(*a,**k)
        with patch('domain.time.monotonic',lambda:clock[0]),patch('json.loads',count):
            for _ in range(60):clock[0]+=1;self.engine.worker_tick()
        self.assertEqual(self.store.read()['revision'],r)
        self.assertLessEqual(n[0],6,'놀고 있는 1분 동안 전체 상태 해석은 몇 번이면 충분합니다')
    def test_desktop_backup_interval_is_ten_minutes(self):
        self.assertGreaterEqual(domain.WORKER_BACKUP_INTERVAL,600)

class AnimationPause(unittest.TestCase):
    def test_animations_pause_when_window_not_watched(self):
        web=ROOT/'web'
        self.assertIn('<script src="idle_pause.js"></script>',(web/'index.html').read_text(encoding='utf-8'))
        self.assertIn("'/idle_pause.js':'idle_pause.js'",(ROOT/'app.py').read_text(encoding='utf-8'))
        js=(web/'idle_pause.js').read_text(encoding='utf-8');self.assertIn('nuavu-idle',js);self.assertIn('hasFocus',js)
        self.assertIn('html.nuavu-idle *',(web/'style.css').read_text(encoding='utf-8'))
if __name__=='__main__':unittest.main()
