"""Both V columns are display evidence; manifest inventory identity stays stable."""
import copy
from pathlib import Path

import pytest

from helpers import Base
from supply_workflow import read_supplier, digest, SupplyError
from test_supply_regression import order, source_row, xlsx

NAME='솔리아 10월 13일 출고장 (완료).xlsx'


def manifest(rows):
    return read_supplier(NAME,xlsx([('출고장',rows)]),2026,'manifest')


@pytest.mark.parametrize('cell,expected',[
    ('2026-10-12','2026-10-12'),('10월 12일','2026-10-12'),
    (46311,'2026-10-16'),('', ''),('미도착',''),('2026-02-30',''),
])
def test_manifest_reads_only_valid_V_dates(cell,expected):
    batch=manifest([source_row(office=cell,purchase='2026-10-11')])
    row=batch['rows'][0]
    assert row['officeDate']==expected
    assert row['basisDate']==''
    assert row['shipDate']=='2026-10-13'
    assert row['basisType']=='manifest'


def test_manifest_V_never_changes_existing_stock_fingerprint_or_SKU():
    blank=manifest([source_row()]);dated=manifest([source_row(office='2026-10-12')])
    row=dated['rows'][0]
    legacy_payload=[[row[k] for k in ('brand','product','color','size','qty')]+['']]
    assert dated['fingerprint']==blank['fingerprint']==digest(['manifest','2026-10-13',legacy_payload])
    assert dated['rows'][0]['variant']==blank['rows'][0]['variant']
    assert dated['evidenceFingerprint']!=blank['evidenceFingerprint']


class ManifestOfficeWorkflowTests(Base):
    def setUp(self):
        super().setUp()
        self.folder=Path(self.tmp.name)/'supplier';self.folder.mkdir()
        with self.store.edit() as s:s['rows']=[]
        self.engine.supply_link(str(self.folder))

    def orders(self,*rows):self.engine.import_rows({'rows':list(rows),'mode':'merge'})
    def sources(self,manifests,progress=()):
        (self.folder/NAME).write_bytes(xlsx([('출고장',manifests)]))
        (self.folder/'진행상황.xlsx').write_bytes(xlsx([('진행상황',progress or [source_row(product='다른 상품')])]))
        self.engine.supply_refresh()
    def active(self):return [r for r in self.engine.public_state()['rows'] if r['active']]

    def test_manifest_only_and_both_source_dates_are_separate(self):
        self.orders(order(1),order(2,product='니트'))
        self.sources([source_row(office='2026-10-12'),source_row(product='니트',office='2026-10-11')],
                     [source_row(office='2026-10-16')])
        rows={r['product']:r for r in self.active()}
        assert rows['가디건']['progressOfficeDates']==['2026-10-16']
        assert rows['가디건']['manifestOfficeDates']==['2026-10-12']
        assert rows['가디건']['officeDates']==['2026-10-12','2026-10-16']
        assert rows['니트']['progressOfficeDates']==[]
        assert rows['니트']['manifestOfficeDates']==['2026-10-11']

    def test_manifest_metadata_does_not_change_allocation_or_forecast(self):
        self.orders(order(1,qty=2))
        self.sources([source_row()],[source_row(office='2026-10-16')])
        before=self.active()[0]
        self.sources([source_row(office='2026-10-20')],[source_row(office='2026-10-16')])
        after=self.active()[0]
        for key in ('dispatchStart','dispatchEnd','stockSecured','delayRisk'):
            assert before[key]==after[key]
        assert before['supplyInfo']['parts']==after['supplyInfo']['parts']
        assert after['manifestOfficeDates']==['2026-10-20']

    def test_same_wave_is_not_double_counted_from_two_V_columns(self):
        self.orders(order(1,qty=2))
        self.sources([source_row(office='2026-10-11')],[source_row(office='2026-10-12')])
        row=self.active()[0]
        assert row['supplyInfo']['allocatedQty']==1
        assert not row['dispatchEnd']
        assert row['progressOfficeDates']==[] # <= last manifest day is excluded from active progress
        assert row['manifestOfficeDates']==['2026-10-11']

    def test_fifo_later_order_keeps_V_evidence_without_claiming_stock(self):
        self.orders(order(1),order(2))
        self.sources([source_row(office='2026-10-12')])
        rows=sorted(self.active(),key=lambda r:r['orderId'])
        assert [r['supplyInfo']['manifestQty'] for r in rows]==[1,0]
        assert all(r['manifestOfficeDates']==['2026-10-12'] for r in rows)
        assert not rows[1]['dispatchEnd']

    def test_invalid_and_blank_V_do_not_use_filename_or_purchase_date(self):
        self.orders(order(1,qty=3))
        self.sources([source_row(office='미도착',purchase='2026-10-10'),source_row()])
        row=self.active()[0]
        assert row['manifestOfficeDates']==[]
        assert row['officeDates']==[]
        assert row['supplyInfo']['manifestQty']==2

    def test_wrong_color_size_brand_and_product_cannot_contribute_dates(self):
        self.orders(order(1,option='아이보리 / M'))
        self.sources([source_row(color='블랙',size='M',office='2026-10-12'),
                      source_row(size='L',office='2026-10-12'),
                      source_row(size='M',brand='OD',office='2026-10-12'),
                      source_row(size='M',product='별도 상품',office='2026-10-12')])
        assert self.active()[0]['officeDates']==[]

    def test_update_requires_manual_refresh_and_survives_restart(self):
        self.orders(order(1))
        self.sources([source_row()])
        with self.store.edit() as s:s['appVersion']='0.6.18'
        before=copy.deepcopy(self.store.read())
        (self.folder/NAME).write_bytes(xlsx([('출고장',[source_row(office='2026-10-12')])]))
        self.restart()
        assert self.active()[0]['manifestOfficeDates']==[]
        after=self.store.read()
        for key in ('rows','notices','settings','supply'):assert after[key]==before[key]
        assert after['appVersion']=='0.6.138'
        self.engine.supply_refresh();self.restart()
        assert self.active()[0]['manifestOfficeDates']==['2026-10-12']

    def test_V_only_change_does_not_reopen_closed_manifest(self):
        self.orders(order(1),order(2))
        self.sources([source_row()]);self.engine.supply_reset({'confirmed':True})
        before=copy.deepcopy(self.store.read()['supply']['sealed'])
        self.sources([source_row(office='2026-10-12')])
        assert all(b['closed'] for b in self.store.read()['supply']['manifests'].values())
        assert self.store.read()['supply']['sealed']==before
        assert sum(r['supplyInfo']['manifestQty'] for r in self.active())==1
        assert all(r['manifestOfficeDates']==[] for r in self.active())

    def test_conflicting_V_copies_fail_without_replacing_previous_data(self):
        self.orders(order(1));self.sources([source_row(office='2026-10-12')])
        before=copy.deepcopy(self.store.read())
        (self.folder/'복사본 솔리아 10월 13일 출고장 (완료).xlsx').write_bytes(
            xlsx([('출고장',[source_row(office='2026-10-11')])]))
        with pytest.raises(SupplyError,match='내용이 다른 출고장'):self.engine.supply_refresh()
        assert self.store.read()==before

    def test_display_does_not_persist_or_send(self):
        self.orders(order(1));self.sources([source_row(office='2026-10-12')])
        before=copy.deepcopy(self.store.read())
        self.active();self.active()
        assert self.store.read()==before
        assert not self.fake.sent and not self.at.sent
