from datetime import datetime,timedelta,timezone
from email.utils import format_datetime
from unittest.mock import MagicMock,patch
import unittest
from order_auto import KST,OrderAutoError,server_request_window,requested_job,checked_request_name
from order_browser import Flow

class RequestClockTests(unittest.TestCase):
    def setUp(self):
        self.start=datetime(2026,10,18,1,1,56,200000,tzinfo=KST)
        self.accept=self.start+timedelta(seconds=1)
        self.sent=self.start+timedelta(seconds=6)
        self.received=self.sent+timedelta(seconds=.2)
        self.header=format_datetime(datetime(2026,10,17,16,2,0,tzinfo=timezone.utc),usegmt=True)
        self.row={'id':'1','at':'2026-10-18 01:01:55','template':'확장주문검색2'}
    def window(self,**kw):
        values=dict(started=self.start,accepted=self.accept,date_header=self.header,sent=self.sent,received=self.received,elapsed=.2,age='0');values.update(kw)
        return server_request_window(**values)
    def test_observed_one_second_mismatch_reproduces_then_matches(self):
        # 2026-10-29: 1초 어긋남은 이제 앞뒤 3초 여유로 서버 시각 보정 없이도 찾는다 (보정해도 그대로 찾음)
        self.assertEqual(requested_job([self.row],self.start,self.accept),self.row)
        low,high=self.window();self.assertEqual(requested_job([self.row],low,high),self.row)
    def test_forward_server_clock(self):
        header=format_datetime((self.sent+timedelta(seconds=3)).astimezone(timezone.utc),usegmt=True)
        low,high=self.window(date_header=header)
        self.assertEqual(requested_job([dict(self.row,at='2026-10-18 01:02:00')],low,high)['id'],'1')
    def test_no_clock_drift_remains_valid(self):
        header=format_datetime(self.sent.astimezone(timezone.utc),usegmt=True)
        low,high=self.window(date_header=header)
        self.assertEqual(requested_job([dict(self.row,at='2026-10-18 01:01:56')],low,high)['id'],'1')
    def test_old_job_not_fallback(self):
        low,high=self.window()
        self.assertIsNone(requested_job([dict(self.row,at='2026-10-18 00:53:42')],low,high))
    def test_all_candidates_inside_uncertainty_rejected(self):
        low,high=self.window()
        with self.assertRaisesRegex(OrderAutoError,'여러 개'):requested_job([self.row,dict(self.row,id='2',at='2026-10-18 01:01:54')],low,high)
    def test_pending_job_can_be_selected_by_corrected_time(self):
        low,high=self.window();r=dict(self.row,status='작업중')
        self.assertEqual(requested_job([r],low,high),r)
    def test_invalid_stale_slow_or_changed_clock_stops(self):
        for values in [dict(date_header=None),dict(date_header='bad'),dict(date_header='Sun, 18 Oct 2026 01:02:00'),dict(age='12'),dict(received=self.sent+timedelta(seconds=6),elapsed=6),dict(elapsed=2),dict(date_header='Sat, 17 Oct 2026 15:00:00 GMT'),dict(accepted=self.start-timedelta(seconds=1)),dict(sent=self.start)]:
            with self.subTest(values=values),self.assertRaises(OrderAutoError):self.window(**values)
    def test_exact_job_id_and_request_second_remain_unchanged(self):
        low,high=self.window();rows=[dict(self.row,id='expected')]
        self.assertEqual(requested_job(rows,low,high),rows[0])
    def test_midnight_converts_dates(self):
        low,high=self.window(started=self.start.replace(hour=0,minute=0,second=0),accepted=self.start.replace(hour=0,minute=0,second=1),sent=self.sent.replace(hour=0,minute=0,second=6),received=self.received.replace(hour=0,minute=0,second=6),date_header='Sat, 17 Oct 2026 15:00:04 GMT')
        self.assertEqual(low.date().isoformat(),'2026-10-17');self.assertEqual(high.date().isoformat(),'2026-10-18')
    def test_clock_only_after_acknowledgement(self):
        flow=Flow(MagicMock(),MagicMock());page=MagicMock()
        with self.assertRaises(OrderAutoError):flow.navigate(page,'https://ga79.ezadmin.co.kr/template40.htm?template=BL30')
        page.goto.assert_not_called();self.assertIsNone(flow.manager_clock)
