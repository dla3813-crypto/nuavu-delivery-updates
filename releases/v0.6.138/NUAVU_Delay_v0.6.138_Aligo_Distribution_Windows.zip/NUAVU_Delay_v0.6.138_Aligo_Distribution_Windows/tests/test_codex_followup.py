"""2026-10-26 16:08 요청: AI 대화 예약 확인 — 그 시각에 같은 대화에 질문을 자동으로 보내고 답을 남긴다."""
import datetime,tempfile,time,unittest
from pathlib import Path
from codex_service import CodexChatService
from codex_followup import parse_when,label,FollowupError
from codex_view import parts
from test_codex_chat import FakeClient

NOW=datetime.datetime(2026,10,26,16,10)

class ParseTests(unittest.TestCase):
    def test_formats(self):
        for v in ('2026-10-27T18:00','2026-10-27 18:00','2026-10-27T18:00:00',' 2026-10-27T18:00 '):self.assertEqual(parse_when(v,NOW),'2026-10-27T18:00')
        self.assertEqual(label('2026-10-27T18:00'),'10/27(화) 18:00')
    def test_rejects(self):
        for v in ('내일 6시','2026-10-26T15:00','2027-01-30T09:00','2026-13-01T00:00',''):
            with self.assertRaises(FollowupError):parse_when(v,NOW)

class Base(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=Path(self.tmp.name);self.alerts=[]
        self.s=CodexChatService(self.base/'state',self.base/'out',roots=[('o','o',self.base)],context=lambda:'요약',version='t',
                                open_url=lambda u:None,open_path=lambda p:None,client_factory=FakeClient,job_alert=lambda t,m,l='info':self.alerts.append((t,m,l)))
        self.s.followup_interval=3600
    def tearDown(self):self.s.close();self.tmp.cleanup()
    def wait(self):
        end=time.monotonic()+5
        while self.s.op and time.monotonic()<end:time.sleep(.01)
        self.assertFalse(self.s.op,self.s.error)
    def turns(self):return [x for x in self.s.client.calls if x.get('method')=='turn/start']
    def finish(self,status='completed'):
        self.s.client.event('turn/completed',{'threadId':'own-thread','turn':{'status':status}});self.wait()

class FollowupTests(Base):
    def test_schedule_card_and_tool(self):
        from codex_tools import AppTools
        tools=AppTools.__new__(AppTools)
        import datetime as _dt;run_at=(_dt.datetime.now()+_dt.timedelta(days=2)).strftime('%Y-%m-%dT18:00');when=label(run_at)   # 실제 시계 기준 (도구 경로엔 now 인자 없음)
        r=tools.t_schedule_followup(self.s,{'runAt':run_at,'prompt':'네 분(가○○·나○○·다○○·라○○) 우체국 회수접수가 정상 진행 중인지 회수 기록으로 확인'})
        self.assertTrue(r['ok'],r);self.assertEqual(r['when'],when)
        f=self.s.followups()[0];self.assertEqual((f['status'],f['runAt']),('pending',run_at))
        card=[m for m in self.s.chat['messages'] if m['role']=='followup'];self.assertEqual(len(card),1);self.assertEqual(card[0]['status'],'pending')
        html=parts(self.s.status())['messages'];self.assertIn('예약 확인',html);self.assertIn(when,html);self.assertIn('cxCancelFollowup',html)
        self.assertEqual(tools.t_list_followups(self.s,{})['followups'][0]['status'],'대기 중')
        self.assertFalse(tools.t_schedule_followup(self.s,{'runAt':'어제','prompt':'x'})['ok'])
    def test_tick_sends_prompt_and_finishes(self):
        self.s.connect();self.wait()
        f=self.s.schedule_followup('2026-10-27T18:00','네 분 회수 확인',now=NOW)
        self.assertIsNone(self.s.followup_tick(now=datetime.datetime(2026,10,27,17,59)));self.assertEqual(self.turns(),[])
        fid=self.s.followup_tick(now=datetime.datetime(2026,10,27,18,0));self.wait()
        self.assertEqual(fid,f['id']);self.assertEqual(len(self.turns()),1)
        sent=self.turns()[0]['params']['input'][0]['text'];self.assertIn('⏰ 예약 확인 (10/27(화) 18:00)',sent);self.assertIn('네 분 회수 확인',sent)
        self.assertEqual(self.s.followups()[0]['status'],'running');self.assertEqual(self.s.chat['messages'][-1]['role'],'user')
        self.assertIsNone(self.s.followup_tick(now=datetime.datetime(2026,10,27,18,1)))   # 실행 중엔 또 안 보냄
        self.finish()
        self.assertEqual(self.s.followups()[0]['status'],'done')
        card=[m for m in self.s.chat['messages'] if m['role']=='followup'][0];self.assertEqual(card['status'],'done')
        self.assertEqual(self.alerts[-1][0],'AI 예약 확인 답변');self.assertEqual(self.alerts[-1][2],'info')
        self.assertIsNone(self.s.followup_tick(now=datetime.datetime(2026,10,27,18,5)))   # 한 번만
    def test_late_run_marked(self):
        self.s.connect();self.wait();self.s.schedule_followup('2026-10-27T18:00','회수 확인',now=NOW)
        self.s.followup_tick(now=datetime.datetime(2026,10,27,19,30));self.wait()
        self.assertIn('지연 실행',self.turns()[0]['params']['input'][0]['text'])
    def test_cancel(self):
        f=self.s.schedule_followup('2026-10-27T18:00','회수 확인',now=NOW)
        self.s.handle('cxCancelFollowup',f['id'])
        self.assertEqual(self.s.followups()[0]['status'],'cancelled');self.assertIsNone(self.s.followup_tick(now=datetime.datetime(2026,10,28,0,0)))
        with self.assertRaises(Exception):self.s.cancel_followup(f['id'])
    def test_failure_when_not_logged_in(self):
        FakeClient.account_type='none'
        try:
            self.s.schedule_followup('2026-10-27T18:00','회수 확인',now=NOW)
            self.s.followup_tick(now=datetime.datetime(2026,10,27,18,0));self.wait()
        finally:FakeClient.account_type='chatgpt'
        f=self.s.followups()[0];self.assertEqual(f['status'],'failed');self.assertIn('로그인',f['note'])
        self.assertEqual(self.alerts[-1][0],'AI 예약 확인 실패');self.assertEqual(self.alerts[-1][2],'error')
    def test_runs_in_its_own_session(self):
        self.s.connect();self.wait();self.s.send('첫 질문');self.wait();self.finish()
        first=self.s.chat['id'];self.s.schedule_followup('2026-10-27T18:00','회수 확인',now=NOW)
        self.s.new();self.assertNotEqual(self.s.chat['id'],first)
        self.s.followup_tick(now=datetime.datetime(2026,10,27,18,0));self.wait()
        self.assertEqual(self.s.chat['id'],first);self.assertIn('회수 확인',self.s.chat['messages'][-1]['text'])
    def test_running_on_restart_becomes_failed(self):
        self.s.schedule_followup('2026-10-27T18:00','회수 확인',now=NOW)
        with self.s.lock:self.s.saved['followups'][0]['status']='running';self.s.save()
        self.s.close()
        s2=CodexChatService(self.base/'state',self.base/'out',roots=[('o','o',self.base)],context=lambda:'',version='t',open_url=lambda u:None,open_path=lambda p:None,client_factory=FakeClient)
        try:self.assertEqual(s2.followups()[0]['status'],'failed')
        finally:s2.close()
    def test_instructions_mention_scheduling(self):
        t=self.s._instructions();self.assertIn('schedule_followup',t);self.assertIn('Current time (KST)',t)

if __name__=='__main__':unittest.main()
