"""2026-10-27 17:30: 원격(HTTP) 화면에서 '메시지 없는 배송지연' 처리 시 'crypto.randomUUID is not a function'.
crypto.randomUUID 는 HTTPS·localhost 에서만 있으므로 화면 코드는 항상 nuavuRequestId() 를 쓴다."""
import re,unittest
from pathlib import Path
WEB=Path(__file__).resolve().parents[1]/'web'

class RequestId(unittest.TestCase):
    def helper_file(self):
        for name in ('viewport.js','import.js'):
            p=WEB/name
            if p.exists() and 'globalThis.nuavuRequestId=function' in p.read_text(encoding='utf-8'):return name
        self.fail('nuavuRequestId 정의가 없습니다')
    def test_helper_defined_and_loaded_before_users(self):
        name=self.helper_file();html=(WEB/'index.html').read_text(encoding='utf-8')
        self.assertLess(html.index(name),html.index('app.js'));self.assertLess(html.index(name),html.index('returns_ui.js'))
    def test_helper_has_fallbacks(self):
        t=(WEB/self.helper_file()).read_text(encoding='utf-8')
        self.assertIn('getRandomValues',t);self.assertIn('Math.random',t)
    def test_no_direct_random_uuid_calls(self):
        for p in WEB.glob('*.js'):
            t=p.read_text(encoding='utf-8')
            for m in re.finditer(r'crypto\.randomUUID',t):
                line=t[t.rfind('\n',0,m.start())+1:t.find('\n',m.start())]
                if line.lstrip().startswith('//'):continue
                line=t[t.rfind('\n',0,m.start())+1:t.find('\n',m.start())]
                self.assertTrue('typeof crypto.randomUUID' in line or 'return crypto.randomUUID()' in line or 'crypto?.randomUUID?.()' in line,f'{p.name}: {line[:120]}')
                if 'crypto?.randomUUID?.()' in line:self.assertIn('nuavuRequestId',line,p.name)   # import.js uid(): 헬퍼 먼저
if __name__=='__main__':unittest.main()
