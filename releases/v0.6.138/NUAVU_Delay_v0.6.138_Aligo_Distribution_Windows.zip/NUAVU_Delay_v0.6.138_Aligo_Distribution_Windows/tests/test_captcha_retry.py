"""2026-10-29 15:36 요청: 캡차 인증 요청에 1분 동안 응답이 없으면 Chrome 을 닫고 2분 간격으로 다시 수집,
수집되면 멈추고 안 되면 최대 20회. [다운로드 완료]/[제가 직접 할게요]를 누르면 사람이 처리 (재수집 안 함)."""
import sys,tempfile,threading,unittest
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT)]
import order_browser as ob
from order_auto import OrderAutoController,OrderAutoError,Cancelled,KST
from domain import Store

class FakeTime:
    """monotonic/sleep 가상 시계 (실제로 기다리지 않음)."""
    def __init__(self):self.t=1000.0;self.slept=0.0
    def monotonic(self):return self.t
    def sleep(self,s):self.t+=s;self.slept+=s

class Ctl:
    def __init__(self,stop_after=None):
        self.updates=[];self.alerts=[];self.ended=0;self.stop_after=stop_after;self.checks=0
    def update(self,phase,msg):self.updates.append((phase,msg))
    def alert(self,*a):self.alerts.append(a)
    def end_browser_recovery(self):self.ended+=1
    def check(self):
        self.checks+=1
        if self.stop_after is not None and self.checks>self.stop_after:raise Cancelled('중단')

class RetryLoop(unittest.TestCase):
    def run_with(self,outcomes,ctl=None):
        ft=FakeTime();ctl=ctl or Ctl();calls=[]
        def once(c,cfg):
            calls.append((cfg['captchaAttempt'],ft.t))
            r=outcomes[len(calls)-1] if len(calls)<=len(outcomes) else outcomes[-1]
            if isinstance(r,Exception):raise r
            return r
        with patch.object(ob,'_run_export_once',once),patch.object(ob.time,'monotonic',ft.monotonic),patch.object(ob.time,'sleep',ft.sleep):
            try:res=ob.run_export(ctl,{'folder':'x'})
            except Exception as exc:res=exc
        return res,calls,ctl,ft
    def test_success_first_time_no_retry(self):
        res,calls,ctl,ft=self.run_with([('a.xls',b'1')])
        self.assertEqual(res,('a.xls',b'1'));self.assertEqual([a for a,_ in calls],[0]);self.assertEqual(ft.slept,0)
    def test_retries_every_two_minutes_and_stops_on_success(self):
        U=ob.CaptchaUnanswered('응답 없음')
        res,calls,ctl,ft=self.run_with([U,U,U,('b.xls',b'2')])
        self.assertEqual(res,('b.xls',b'2'));self.assertEqual([a for a,_ in calls],[0,1,2,3])
        gaps=[b-a for (_,a),(_,b) in zip(calls,calls[1:])];self.assertTrue(all(abs(g-120)<=1 for g in gaps),gaps)
        self.assertTrue(any(p=='retry_wait' and '(3/20)' in m for p,m in ctl.updates))
        self.assertEqual(ctl.alerts,[])   # 성공하면 실패 알림 없음
    def test_gives_up_after_twenty_retries_with_one_alert(self):
        res,calls,ctl,ft=self.run_with([ob.CaptchaUnanswered('응답 없음')])
        self.assertIsInstance(res,OrderAutoError);self.assertNotIsInstance(res,ob.CaptchaUnanswered)
        self.assertEqual(len(calls),21);self.assertEqual(calls[-1][0],20)   # 첫 시도 + 재수집 20회
        self.assertIn('20회',str(res));self.assertEqual(len(ctl.alerts),1);self.assertEqual(ctl.alerts[0][2],'error')
    def test_other_errors_are_not_retried(self):
        res,calls,ctl,ft=self.run_with([OrderAutoError('비밀번호가 일치하지 않습니다')])
        self.assertIsInstance(res,OrderAutoError);self.assertEqual(len(calls),1)
    def test_cancel_during_wait(self):
        res,calls,ctl,ft=self.run_with([ob.CaptchaUnanswered('x')],ctl=Ctl(stop_after=5))
        self.assertIsInstance(res,Cancelled);self.assertEqual(len(calls),1)

class CaptchaWait(unittest.TestCase):
    def flow(self,commands,hold_after=None):
        ft=FakeTime();alerts=[];state={'hold':False,'n':0}
        def take():
            state['n']+=1;ft.t+=1
            if hold_after is not None and state['n']==hold_after:state['hold']=True
            return commands(state['n'])
        c=SimpleNamespace(alert=lambda *a:alerts.append(a),captcha_wait=lambda m:alerts.append(('wait',m)),take_browser_action=take,
                          end_browser_recovery=lambda:None,update=lambda *a:None)
        c.captcha_hold=False
        page=SimpleNamespace(is_closed=lambda:False,wait_for_timeout=lambda ms:None)
        ctx=SimpleNamespace(on=lambda *a:None,remove_listener=lambda *a:None,pages=[page])
        f=ob.Flow.__new__(ob.Flow);f.c=c;f.context=ctx;f.page=None;f.step='';f.export_acknowledged=False;f.export_accepted=False
        f.close_extra_pages=lambda:None;f.live_pages=lambda:[page];f.fetch_requested=lambda s,a,cfg:('x.xls',b'd')
        orig=take
        def take2():
            r=orig();c.captcha_hold=state['hold'];return r
        c.take_browser_action=take2
        return f,page,ft,alerts
    def test_no_answer_in_one_minute_raises_unanswered(self):
        f,page,ft,alerts=self.flow(lambda n:None)
        with patch.object(ob.time,'monotonic',ft.monotonic):
            with self.assertRaises(ob.CaptchaUnanswered):f.captcha_download(page,datetime.now(KST),{'folder':'x'})
        self.assertLessEqual(ft.t-1000,ob.CAPTCHA_ANSWER_SECONDS+2)
        self.assertEqual(len([a for a in alerts if a[0]!='wait']),1)   # 첫 시도엔 알림
    def test_retry_attempt_does_not_alert_again(self):
        f,page,ft,alerts=self.flow(lambda n:None)
        with patch.object(ob.time,'monotonic',ft.monotonic):
            with self.assertRaises(ob.CaptchaUnanswered):f.captcha_download(page,datetime.now(KST),{'folder':'x','captchaAttempt':3})
        self.assertEqual([a for a in alerts if a[0]!='wait'],[]);self.assertIn('3회째',[a for a in alerts if a[0]=='wait'][0][1])
    def test_downloaded_within_minute_continues(self):
        f,page,ft,alerts=self.flow(lambda n:('downloaded','') if n==30 else None)
        with patch.object(ob.time,'monotonic',ft.monotonic):
            self.assertEqual(f.captcha_download(page,datetime.now(KST),{'folder':'x'}),('x.xls',b'd'))
    def test_hold_keeps_waiting_past_one_minute(self):
        f,page,ft,alerts=self.flow(lambda n:('downloaded','') if n==400 else None,hold_after=20)
        with patch.object(ob.time,'monotonic',ft.monotonic):
            self.assertEqual(f.captcha_download(page,datetime.now(KST),{'folder':'x'}),('x.xls',b'd'))
        self.assertGreater(ft.t-1000,ob.CAPTCHA_ANSWER_SECONDS)

class HoldAction(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(Path(self.tmp.name)/'data')
        self.c=OrderAutoController(self.store);self.gate=threading.Event()
        self.c.thread=threading.Thread(target=self.gate.wait,daemon=True);self.c.thread.start();self.c.job={'id':'J1','phase':'running','message':''}
    def tearDown(self):self.gate.set();self.c.thread.join(2);self.store.close();self.tmp.cleanup()
    def test_hold_only_while_captcha_then_downloaded_still_works(self):
        with self.assertRaises(OrderAutoError):self.c.request_browser_action('J1','hold')
        self.c.captcha_wait('캡차');self.assertFalse(self.c.status()['captchaHold'])
        st=self.c.request_browser_action('J1','hold');self.assertTrue(st['captchaHold']);self.assertTrue(st['captchaWait']);self.assertEqual(st['phase'],'error_open')
        self.c.request_browser_action('J1','downloaded');self.assertEqual(self.c.take_browser_action(),('downloaded',''))
        self.c.end_browser_recovery();self.assertFalse(self.c.status()['captchaHold'])
    def test_ui_wiring(self):
        ui=''.join((ROOT/'web'/n).read_text(encoding='utf-8') for n in ('index.html','app.js')+(('order_auto_ui.js',) if (ROOT/'web'/'order_auto_ui.js').exists() else ()))
        self.assertIn('id="captchaHoldOrderBrowser"',ui);self.assertIn("orderBrowserAction('hold')",ui);self.assertIn('r.captchaHold',ui)
if __name__=='__main__':unittest.main()
