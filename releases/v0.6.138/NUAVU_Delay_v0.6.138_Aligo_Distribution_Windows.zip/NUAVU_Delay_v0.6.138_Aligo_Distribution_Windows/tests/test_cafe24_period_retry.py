"""2026-10-27 18:38: 전체 반품체크 안에서 자사몰 '1개월' 선택 표시가 늦게 붙어 실패하던 것 — 기다리고, 한 번 더 누른다."""
import re,sys,unittest
from contextlib import contextmanager
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import cafe24_returns as cr
from return_data import ReturnError

class Loc:
    def __init__(self,page,sel,text=None):self.page=page;self.sel=sel;self.text=text
    def filter(self,has_text=None):return Loc(self.page,self.sel,has_text)
    @property
    def first(self):return self
    def count(self):
        if self.sel=='a.btnDate':return 1
        if self.sel=='a.btnDate.selected':
            self.page.polls+=1
            return 1 if self.page.selected_after is not None and self.page.polls>=self.page.selected_after else 0
        if self.sel=='select[name="rows"]':return 0
        return 1
    def click(self,timeout=None):self.page.clicks.append(self.sel)
    def select_option(self,*a,**k):pass

class Page:
    def __init__(self,selected_after):self.selected_after=selected_after;self.polls=0;self.clicks=[];self.waited=0;self.url='https://nuavu.cafe24.com/admin/php/shop1/s_new/order_returns.php'
    def goto(self,*a,**k):pass
    def locator(self,sel):return Loc(self,sel)
    @contextmanager
    def expect_navigation(self,**k):yield
    def wait_for_timeout(self,ms):self.waited+=ms
    def evaluate(self,js,*a):
        if 'btnDate' in js:return '오늘 3일 7일 1개월 3개월'
        return {'rows':[],'empty':True,'pages':[],'current':'1'}
    def screenshot(self,**k):raise RuntimeError('no screenshot in test')

class Flow:
    def __init__(self,page):self.page=page;self.step='';self.msgs=[]
    def progress(self,m):self.msgs.append(m)
    def wait(self,fn,sec,msg):
        if not fn():raise ReturnError(msg)

def run(selected_after):
    page=Page(selected_after);r=cr.Cafe24Returns(Flow(page),'nuavu.cafe24.com','return');r.open_list();return page,r

class PeriodRetry(unittest.TestCase):
    def test_immediate(self):
        page,_=run(1);self.assertEqual(page.clicks.count('a.btnDate'),1);self.assertEqual(page.clicks.count('#search_button'),1)
    def test_waits_for_late_selected(self):
        page,_=run(6);self.assertEqual(page.clicks.count('a.btnDate'),1);self.assertEqual(page.clicks.count('#search_button'),1);self.assertGreaterEqual(page.polls,6)
    def test_retries_once_then_succeeds(self):
        page,r=run(40)   # 15초(약 31회) 안에 안 붙음 → 1개월·조회 한 번 더
        self.assertEqual(page.clicks.count('a.btnDate'),2);self.assertEqual(page.clicks.count('#search_button'),2)
        self.assertTrue(any('다시 선택' in m for m in r.flow.msgs))
    def test_fails_with_diagnostics_after_two_tries(self):
        page=Page(None);r=cr.Cafe24Returns(Flow(page),'nuavu.cafe24.com','return')
        with self.assertRaises(ReturnError) as c:r.open_list()
        m=str(c.exception);self.assertIn('2회 시도',m);self.assertIn('1개월',m);self.assertIn('캡처 실패',m);self.assertEqual(page.clicks.count('#search_button'),2)
    def test_period_selected_polls_half_second(self):
        page=Page(None);r=cr.Cafe24Returns(Flow(page),'nuavu.cafe24.com','return')
        self.assertFalse(r.period_selected(0));self.assertEqual(page.polls,1);self.assertFalse(r.period_selected(2));self.assertEqual(page.waited,2000)
if __name__=='__main__':unittest.main()
