"""Local supplier-folder watcher. No provider, browser or messaging operations."""
from __future__ import annotations
from job_alerts import job_alert
import copy,hashlib,json,threading,time
from functools import wraps
from pathlib import Path
from workbook_reader import text

POLL_SECONDS=5
STABLE_SECONDS=5

def serialized_supply(method):
    @wraps(method)
    def wrapped(self,*args,**kwargs):
        with self.supply_io_lock:
            return method(self,*args,**kwargs)
    return wrapped

def scan_signature(folder):
    from supply_workflow import is_progress_file,SupplyError,skip_supply_file
    p=Path(folder)
    if not folder or not p.is_dir():raise SupplyError('연결 폴더에 접근할 수 없습니다. 이전 자료를 유지합니다.')
    folder_stat=p.stat();items=[]
    for f in p.iterdir():
        name=text(f.name)
        if f.is_symlink() or not f.is_file() or name.startswith(('~$','.')) or f.suffix.lower()!='.xlsx':continue
        if skip_supply_file(name):continue   # (NS 이미지)·색칠 사본은 감시 대상이 아니다
        if not (is_progress_file(name) or ('출고장' in name and '완료' in name)):continue
        a=f.stat();items.append((f.name,a.st_size,a.st_mtime_ns,a.st_ctime_ns,a.st_ino))
    data=[str(p),folder_stat.st_dev,folder_stat.st_ino,sorted(items)]
    return hashlib.sha256(json.dumps(data,ensure_ascii=False).encode()).hexdigest()

class SupplyWatcher:
    def __init__(self,engine):
        self.engine=engine;self.thread=None;self.lock=threading.Lock()
        self.candidate=None;self.since=0;self.failed=None;self.generation=0
        self.info={'phase':'off','lastCheckedAt':'','error':'','message':'자동 반영 꺼짐'}
    def status(self):
        with self.lock:return copy.deepcopy(self.info)
    def update(self,**values):
        with self.lock:self.info.update(values)
    def reset(self):
        with self.lock:
            self.generation+=1;self.candidate=None;self.failed=None
            self.info.update(phase='waiting',error='',message='변경 확인 대기')
    def running(self):return bool(self.thread and self.thread.is_alive())
    def start(self):
        if self.running():return
        self.thread=threading.Thread(target=self.work,name='supplier-folder-watch',daemon=True);self.thread.start()
    def work(self):
        while not self.engine.stop.is_set():
            self.tick()
            self.engine.stop.wait(POLL_SECONDS)
    def tick(self,clock=None):
        from supply_workflow import init_supply,SupplyError
        from domain import now
        if self.engine.stop.is_set() or getattr(self.engine,'reset_in_progress',False):return
        # Never wait behind a manual read/reset. Try again on the next poll.
        if not self.engine.supply_io_lock.acquire(blocking=False):return
        try:
            _s=(getattr(self.engine.store,'peek',None) or self.engine.store.read)()   # 2026-10-28 CPU: 읽기 전용 캐시
            v=init_supply({'supply':dict(_s.get('supply') or {})})
            if not v['autoEnabled']:
                self.candidate=None;self.failed=None
                self.update(phase='off',error='',message='자동 반영 꺼짐');return
            self.update(lastCheckedAt=now())
            current=scan_signature(v['folder'])
            if current==v.get('watchSignature'):
                self.candidate=None;self.failed=None
                self.update(phase='watching',error='',message='변경 없음 · 5초마다 확인');return
            if current==self.failed:return
            tick=time.monotonic() if clock is None else clock
            if current!=self.candidate:
                self.candidate=current;self.since=tick
                self.update(phase='settling',error='',message='파일 변경 감지 · 저장 완료 확인 중');return
            if tick-self.since<STABLE_SECONDS:return
            self.update(phase='reading',error='',message='변경된 진행상황·출고장 반영 중')
            try:
                result=self.engine.supply_refresh(_automatic=True,_expected_signature=current)
            except Exception as exc:
                if self.engine.stop.is_set():return
                self.failed=current
                message=str(exc) if isinstance(exc,SupplyError) else '자동 반영 중 오류가 발생했습니다. 이전 자료를 유지합니다. 수동갱신으로 확인하세요.'
                self.update(phase='error',error=message,message=message);job_alert(self.engine,'진행상황·출고장 자동 반영 막힘',message,'error');return
            self.candidate=None;self.failed=None
            self.update(phase='watching',error='',message=result['message'])
            job_alert(self.engine,'진행상황·출고장 자동 반영 완료',result['message'])
        except Exception as exc:
            if self.engine.stop.is_set():return
            message=str(exc) if isinstance(exc,SupplyError) else '폴더를 확인하지 못했습니다. 이전 자료를 유지합니다.'
            self.update(phase='error',error=message,message=message)
        finally:self.engine.supply_io_lock.release()
    def join(self,timeout=25):
        if self.thread:self.thread.join(timeout=timeout)
