"""중국 취소건 (2026-10-22 22:55 요청, 공통).

진행상황(AI) › 취소건 폴더의 판매처별 '(MMDD) MMDD~MMDD <판매처> 취소건.xlsx'를 읽는다.
 · 열: A 날짜(MMDD) · B 주문번호(S…) · C 상품명 · D 옵션(컬러) · E 사이즈 · F 주문수량 · G 단가 · H 금액 · I 비고 · J 中国备注
 · 행 색: 초록(C6EFCE) = 그날 새로 발견된 취소건 · 주황(FFEB9C) = 예전에 발견된 취소건.
   → 초록행만 '취소 기록'으로 쌓는다(처음 실행 때도 그날의 초록행부터). 같은 주문번호는 한 번만.
 · 같은 상품명·컬러·사이즈에 서로 다른 주문번호의 취소가 쌓이면 1차 → 2차 → 3차.
 · 마지막 취소 뒤 진행상황에 같은 상품·옵션의 더 늦은 주문(L열 주문일 > 취소된 주문일)이 있으면 '(N차)재발주'.
 · I·J열 사유는 한국어로 풀어 보여준다. '…件起(做)'·'…장 부터'는 수량 미달 → 수량체크.
 · 주문과의 연결은 수동매칭 규칙(진행상황 매칭과 같은 상품명·컬러·사이즈 비교 + 저장된 수동 매칭)을 그대로 쓴다.
   상품명만 같고 컬러/사이즈가 다르면 '매칭 가능한 비슷한 취소상품' → 사람이 같은 상품/다른 상품을 고른다.
"""
from __future__ import annotations
import hashlib,io,json,os,re,threading,time,unicodedata,zipfile,posixpath
from datetime import date,datetime,timedelta,timezone
from xml.etree import ElementTree as ET
from workbook_reader import read_xlsx,text,WorkbookError,xml as safe_xml

NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
REL='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
GREEN={'C6EFCE'};ORANGE={'FFEB9C'}
KST=timezone(timedelta(hours=9))
CANCEL_KINDS=('soldout','defect','other')   # 단계(1·2·3차)를 세는 취소 사유
MAX_EVENTS=2000

class ChinaCancelError(ValueError):pass

def nfc(s):return unicodedata.normalize('NFC',str(s or ''))
def digest(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:24]

# ---------------------------------------------------------------- 엑셀: 값 + 행 색
def _rgb(fill):
    p=fill.find('s:patternFill',NS)
    if p is None or p.get('patternType') in (None,'none'):return ''
    fg=p.find('s:fgColor',NS)
    if fg is None:return ''
    return (fg.get('rgb') or '')[-6:].upper()

def row_colors(raw):
    """첫 시트의 {행번호(1부터): 'RRGGBB'} — 행에서 처음 색이 칠해진 칸 기준."""
    out={}
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            names=z.namelist()
            if 'xl/styles.xml' not in names:return out
            st=safe_xml(z.read('xl/styles.xml'))
            fills=[_rgb(f) for f in st.findall('s:fills/s:fill',NS)]
            xfs=[int(x.get('fillId') or 0) for x in st.findall('s:cellXfs/s:xf',NS)]
            wb=safe_xml(z.read('xl/workbook.xml'))
            rels={r.get('Id'):r.get('Target') for r in safe_xml(z.read('xl/_rels/workbook.xml.rels'))}
            first=wb.find('s:sheets/s:sheet',NS)
            target=rels.get(first.get(REL),'') if first is not None else ''
            path=posixpath.normpath(target.lstrip('/') if target.startswith('/') else 'xl/'+target)
            if path not in names:return out
            for row in safe_xml(z.read(path)).findall('s:sheetData/s:row',NS):
                n=int(row.get('r') or 0)
                for c in row.findall('s:c',NS):
                    s=c.get('s')
                    if s is None:continue
                    i=int(s)
                    color=fills[xfs[i]] if i<len(xfs) and xfs[i]<len(fills) else ''
                    if color:out[n]=color;break
    except (zipfile.BadZipFile,KeyError,ValueError,ET.ParseError,IndexError):return {}
    return out

HEADERS={'date':('날짜',),'code':('주문번호',),'product':('상품명',),'color':('옵션',),'size':('사이즈',),'qty':('주문수량','수량'),
         'noteI':('비고',),'noteJ':('中国备注','중국비고')}
DEFAULT_COLS={'date':0,'code':1,'product':2,'color':3,'size':4,'qty':5,'noteI':8,'noteJ':9}

def file_meta(name):
    """'(1022) 1022~0910 누아브 취소건.xlsx' → ('누아브', 'MMDD' 파일일)."""
    n=nfc(name)
    m=re.search(r'\((\d{4})\)',n);day=m.group(1) if m else ''
    b=re.search(r'\d{4}\s*[~\-]\s*\d{4}\s*(.+?)\s*취소건',n)
    brand=b.group(1).strip() if b else re.sub(r'\.xlsx$','',n)
    return brand,day

def mmdd_date(v,year):
    s=re.sub(r'\D','',text(v))
    if len(s)==3:s='0'+s
    if len(s)!=4:return ''
    try:return date(year,int(s[:2]),int(s[2:])).isoformat()
    except ValueError:return ''

def parse_cancel_file(name,raw,year=2026):
    sheets=read_xlsx(raw)
    if not sheets:raise ChinaCancelError('시트가 없습니다: '+nfc(name))
    rows=sheets[0]['rows'];colors=row_colors(raw)
    cols=dict(DEFAULT_COLS);start=0
    for i,r in enumerate(rows[:5]):
        heads=[text(x) for x in r]
        if any('주문번호' in h for h in heads) and any('상품명' in h for h in heads):
            for k,names in HEADERS.items():
                for j,h in enumerate(heads):
                    if any(h.startswith(x) for x in names):cols[k]=j;break
            start=i+1;break
    brand,day=file_meta(name);out=[]
    for i,r in enumerate(rows[start:],start+1):
        get=lambda k:r[cols[k]] if cols[k]<len(r) else None
        code=text(get('code'));product=text(get('product'))
        if not code or not product:continue
        color=colors.get(i,'')
        out.append({'line':i,'file':nfc(name),'brand':brand,'fileDay':day,'code':code,'orderDate':mmdd_date(get('date'),year),
                    'product':product,'color':text(get('color')),'size':text(get('size')),'qty':text(get('qty')),
                    'noteI':text(get('noteI')),'noteJ':text(get('noteJ')),
                    'fill':'green' if color in GREEN else 'orange' if color in ORANGE else (color or '')})
    return out

# ---------------------------------------------------------------- 사유 해석 (I·J열)
COLOR_ZH={'黑色':'블랙','白色':'화이트','蓝色':'블루','红色':'레드','灰色':'그레이','粉色':'핑크','绿色':'그린','黄色':'옐로우','紫色':'퍼플',
          '杏色':'베이지','卡色':'카키','米色':'아이보리','咖啡色':'브라운','棕色':'브라운','军绿色':'카키','浅卡':'연카키','炭灰色':'차콜'}
def zh_color(s):
    for k,v in COLOR_ZH.items():s=s.replace(k,v)
    return s

def reason_parts(note):
    """한 칸의 사유 → (category, 한국어 설명). category: qty·delay·soldout·defect·other·''"""
    t=re.sub(r'\s+',' ',text(note)).strip()
    if not t:return '',''
    m=re.search(r'(一个颜色|每色|一色)?\s*(\d+)\s*件\s*起\s*(做)?',t)
    if m:return 'qty',(('한 색상당 ' if m.group(1) else '')+f'최소 {m.group(2)}장부터 주문 가능 — 수량이 모자라 발주가 안 됨 (원문 {t})')
    m=re.search(r'(\d+)\s*장\s*부터',t)
    if m:return 'qty',f'최소 {m.group(1)}장부터 주문 가능 — 수량이 모자라 발주가 안 됨'+('' if t==m.group(0) else f' (원문 {t})')
    m=re.search(r'预计\s*(\d{1,2})\s*月\s*(\d{1,2})\s*[号日]\s*(出)?',t)
    if m:return 'delay',f'중국 거래처 안내: {m.group(1)}월 {m.group(2)}일 출고 예정 — 취소 아님 (원문 {t})'
    if '下架' in t:return 'soldout','下架 = 거래처가 상품을 내림(품절)'
    if re.search(r'링크.*(사라|없어|삭제)|链接.*(没|失效|下)',t):return 'soldout','1688 상품 링크가 사라짐(상품 삭제·품절)'
    if re.search(r'링크\s*품절',t):return 'soldout','이 1688 링크 품절'
    if re.search(r'생산\s*계획이?\s*없',t):return 'soldout','거래처 생산 계획 없음(재입고 미정)'
    m=re.search(r'只有\s*(.+)',t)
    if m:return 'soldout',f'{zh_color(m.group(1))}만 있음 — 주문한 색상은 품절 (원문 {t})'
    if '缺货' in t or '没货' in t or '断货' in t:return 'soldout',f'재고 없음(품절) (원문 {t})'
    m=re.search(r'(\d{1,2})\s*/\s*(\d{1,2})\s*(\d+)\s*(장|개)\s*(품절|불량|취소)\s*환불',t)
    if m:
        kind={'품절':'soldout','불량':'defect','취소':'other'}[m.group(5)]
        return kind,f'{m.group(1)}/{m.group(2)} {m.group(3)}장 {m.group(5)} 환불'
    if '불량' in t:return 'defect',f'불량 ({t})'
    if '재고가 없' in t or '품절' in t:return 'soldout',t
    return 'other',t

PRIORITY={'qty':0,'soldout':1,'defect':2,'other':3,'delay':4,'':9}
def explain(noteI,noteJ):
    parts=[(c,k,s) for c,(k,s) in (('I',reason_parts(noteI)),('J',reason_parts(noteJ))) if k]
    if not parts:return 'other','사유 없음(비고·中国备注 비어 있음)'
    kind=sorted(parts,key=lambda p:PRIORITY[p[1]])[0][1]
    return kind,' / '.join(f'{c}열: {s}' for c,k,s in parts)

KIND_LABEL={'soldout':'품절','qty':'수량체크','delay':'입고 예정','defect':'불량','other':'취소'}

# ---------------------------------------------------------------- 상태
def init_china(s):
    v=s.get('chinaCancel')
    if not isinstance(v,dict):v=s['chinaCancel']={}
    for k,d in {'folder':'','items':{},'codes':[],'decisions':{},'lastScan':{},'signature':''}.items():v.setdefault(k,d if not isinstance(d,(dict,list)) else type(d)())
    return v

def color_key(v):
    """진행상황 매칭과 같은 컬러 비교(누아브판 color_key · 배포판 match_color_name)."""
    import supply_workflow as sw
    fn=getattr(sw,'color_key',None) or getattr(sw,'match_color_name',None)
    return fn(v) if fn else sw.norm(v)

def item_key(product,color,size):
    from supply_workflow import match_product_name,size_name
    return digest([match_product_name(product),color_key(color),size_name(size)])

def record_rows(v,rows,found_on):
    """초록행만 기록. 반환: 새로 추가된 건수."""
    codes=set(v['codes']);added=0
    for r in rows:
        if r['fill']!='green' or r['code'] in codes:continue
        kind,why=explain(r['noteI'],r['noteJ'])
        iid=item_key(r['product'],r['color'],r['size'])
        item=v['items'].setdefault(iid,{'id':iid,'product':r['product'],'color':r['color'],'size':r['size'],'events':[]})
        day=r['fileDay'];seen=found_on
        if re.fullmatch(r'\d{4}',day or ''):
            try:seen=date(int(found_on[:4]),int(day[:2]),int(day[2:])).isoformat()
            except ValueError:pass
        item['events'].append({'code':r['code'],'orderDate':r['orderDate'],'foundOn':seen,'file':r['file'],'line':r['line'],'brand':r['brand'],
                               'qty':r['qty'],'noteI':r['noteI'],'noteJ':r['noteJ'],'kind':kind,'reason':why})
        codes.add(r['code']);added+=1
    v['codes']=sorted(codes)[-MAX_EVENTS:]
    return added

def stage_of(item):
    return min(3,sum(e['kind'] in CANCEL_KINDS for e in item['events']))

def item_kind(item):
    cancels=[e for e in item['events'] if e['kind'] in CANCEL_KINDS]
    if cancels:return 'cancel'
    if any(e['kind']=='qty' for e in item['events']):return 'qty'
    return 'delay'

# ---------------------------------------------------------------- 폴더 · 읽기
def resolve_folder(s):
    v=init_china(s)
    if v.get('folder'):return v['folder']
    supply=(s.get('supply') or {}).get('folder') or ''
    cands=[]
    if supply:
        cands+= [os.path.join(supply,'취소건'),os.path.join(os.path.dirname(supply),'진행상황(AI)','취소건')]
    cands.append(os.path.join(os.path.expanduser('~'),'Desktop','진행상황(AI)','취소건'))
    for c in cands:
        try:
            parent=os.path.dirname(c);want=nfc(os.path.basename(c))
            if os.path.isdir(parent):
                for x in os.listdir(parent):
                    if nfc(x)==want and os.path.isdir(os.path.join(parent,x)):return os.path.join(parent,x)
        except OSError:continue
    return ''

def list_files(folder):
    out=[]
    for x in sorted(os.listdir(folder)):
        n=nfc(x)
        if n.startswith(('~$','.')) or not n.lower().endswith('.xlsx') or '취소건' not in n:continue
        p=os.path.join(folder,x);st=os.stat(p);out.append((p,n,st.st_size,int(st.st_mtime)))
    return out

def scan(engine,force=False,now=None):
    """폴더가 바뀌었으면 읽어서 초록행을 기록. 반환 {'changed','added','files','error'}"""
    now=now or datetime.now(KST)
    _s=(getattr(engine.store,'peek',None) or engine.store.read)()   # 2026-10-28 CPU: 읽기 전용 캐시 → init_china 가 채우는 기본값은 얕은 복사본에만
    s={'chinaCancel':dict(_s.get('chinaCancel') or {}) if isinstance(_s.get('chinaCancel'),dict) else {},'supply':_s.get('supply') or {}};folder=resolve_folder(s)
    def note(folder_,error):
        # 2026-10-28 CPU: 같은 폴더·같은 오류면 다시 쓰지 않는다 (20초마다 시각만 바뀐 저장 → 화면 새로고침·백업 연쇄 방지)
        last=s['chinaCancel'].get('lastScan') or {}
        if not force and last.get('folder')==folder_ and last.get('error')==error:return
        with engine.store.edit() as st:init_china(st)['lastScan']={'at':now.isoformat(timespec='seconds'),'folder':folder_,'files':[],'error':error}
    if not folder:
        note('','취소건 폴더를 찾지 못했습니다. ⚙ 설정에서 진행상황(AI) › 취소건 폴더를 연결하세요.')
        return {'changed':False,'added':0,'files':[],'error':'no folder'}
    try:files=list_files(folder)
    except OSError as exc:
        note(folder,'폴더를 읽지 못했습니다: '+str(exc)[:120])
        return {'changed':False,'added':0,'files':[],'error':str(exc)}
    sig=digest([[n,sz,mt] for _,n,sz,mt in files])
    if not force and sig==init_china(s).get('signature'):return {'changed':False,'added':0,'files':[],'error':''}
    parsed=[];errors=[]
    for p,n,sz,mt in files:
        try:
            with open(p,'rb') as f:raw=f.read()
            rows=parse_cancel_file(n,raw,now.year);parsed.append((n,rows))
        except (OSError,WorkbookError,ChinaCancelError) as exc:errors.append(f'{n}: {str(exc)[:100]}')
    with engine.store.edit() as st:
        v=init_china(st);added=0
        for n,rows in parsed:added+=record_rows(v,rows,now.date().isoformat())
        v['signature']=sig
        v['lastScan']={'at':now.isoformat(timespec='seconds'),'folder':folder,'added':added,'error':'; '.join(errors)[:400],
                       'files':[{'name':n,'rows':len(rows),'green':sum(r['fill']=='green' for r in rows)} for n,rows in parsed]}
    return {'changed':True,'added':added,'files':[n for n,_ in parsed],'error':'; '.join(errors)}

class ChinaCancelWatcher:
    """취소건 폴더를 20초마다 확인(파일 이름·크기·수정시각이 바뀌면 다시 읽음)."""
    def __init__(self,engine,interval=20):
        self.engine=engine;self.interval=interval;self.stop=threading.Event();self.thread=None
    def running(self):return bool(self.thread and self.thread.is_alive())
    def start(self):
        if self.running():return
        def loop():
            while True:
                try:scan(self.engine)
                except Exception as exc:
                    try:self.engine.record_error('중국 취소건 폴더 읽기 실패',str(exc)[:300])
                    except Exception:pass
                if self.stop.wait(self.interval):break
        self.thread=threading.Thread(target=loop,daemon=True,name='china-cancel-watch');self.thread.start()
    def shutdown(self):self.stop.set()

# ---------------------------------------------------------------- 주문 행 표시
def _same_item(a_product,a_color,a_size,b_product,b_color,b_size):
    from supply_workflow import same_product,size_name
    return same_product(a_product,b_product) and color_key(a_color)==color_key(b_color) and size_name(a_size)==size_name(b_size)

def match_row(row,item,mappings,variants_by_id):
    """'manual' | 'auto' | 'similar' | None"""
    from supply_workflow import same_product,product_within,option_parts,size_name,order_signature
    product_ok=same_product(row.get('product',''),item['product']) or product_within(row.get('product',''),item['product'])
    rule=mappings.get(order_signature(row))
    if rule:
        for vid in rule:
            x=variants_by_id.get(vid)
            if x and _same_item(x['product'],x['color'],x['size'],item['product'],item['color'],item['size']):return 'manual'
        return 'similar' if product_ok else None
    if not product_ok:return None
    oc,os_=option_parts(row.get('option',''));oc=color_key(oc)
    ic=color_key(item['color']);isz=size_name(item['size'])
    color_ok=oc=='원컬러' or (oc and ic==oc) or (ic in ('원컬러','onecolor') and not oc)
    size_ok=os_=='free' or not isz or isz==os_ or (isz=='free' and not os_)
    return 'auto' if color_ok and size_ok else 'similar'

def reorders(item,progress):
    """마지막 취소 뒤 진행상황에 같은 상품·컬러·사이즈의 더 늦은 주문이 있으면 그 행들."""
    cancels=[e for e in item['events'] if e['kind'] in CANCEL_KINDS]
    if not cancels:return []
    last=max(cancels,key=lambda e:(e.get('orderDate') or '',e.get('foundOn') or ''))
    after=last.get('orderDate') or last.get('foundOn') or ''
    out=[]
    for r in progress:
        if (r.get('purchaseDate') or '')<=after:continue
        if _same_item(r.get('product',''),r.get('color',''),r.get('size',''),item['product'],item['color'],item['size']):
            out.append({'file':r.get('sourceFile',''),'line':r.get('line',''),'purchaseDate':r.get('purchaseDate',''),'qty':r.get('qty','')})
    return out

def decorate(s):
    """public_state: 주문 행마다 r['chinaCancel'], 그리고 s['chinaCancel'] 요약."""
    v=init_china(s);items=list(v['items'].values())
    sup=s.get('supply') or {};mappings=sup.get('mappings') or {}
    variants={}
    for b in (sup.get('manifests') or {}).values():
        for r in b.get('rows',[]):variants.setdefault(r.get('variant'),r)
    for r in sup.get('progress') or []:variants.setdefault(r.get('variant'),r)
    progress=sup.get('progress') or []
    info={}
    for it in items:
        st=stage_of(it);kind=item_kind(it);re_=reorders(it,progress) if kind=='cancel' else []
        last=it['events'][-1] if it['events'] else {}
        info[it['id']]={'stage':st,'kind':kind,'reorder':re_[:3],'last':last}
    decisions=v.get('decisions') or {}
    for r in s.get('rows',[]):
        r.pop('chinaCancel',None)
        if not r.get('active') or not items:continue
        best=None
        for it in items:
            d=decisions.get(r['key']+'|'+it['id'])
            if d=='reject':continue
            m=match_row(r,it,mappings,variants)
            if d=='match':m='confirmed'
            if not m:continue
            i=info[it['id']];e=i['last']
            label=('수량체크' if i['kind']=='qty' else '입고 예정' if i['kind']=='delay' else f"중국 취소 {i['stage']}차")
            if i['kind']=='cancel' and i['reorder']:label=f"({i['stage']}차)재발주"
            cand={'itemId':it['id'],'match':m,'stage':i['stage'] if i['kind']=='cancel' else 0,'kind':i['kind'],'label':label,
                  'reorder':i['reorder'],'product':it['product'],'color':it['color'],'size':it['size'],
                  'reason':e.get('reason',''),'reasonKind':KIND_LABEL.get(e.get('kind',''),''),'noteI':e.get('noteI',''),'noteJ':e.get('noteJ',''),
                  'code':e.get('code',''),'orderDate':e.get('orderDate',''),'foundOn':e.get('foundOn',''),'file':e.get('file',''),'line':e.get('line',''),'brand':e.get('brand',''),
                  'events':[{k:x.get(k,'') for k in ('code','orderDate','foundOn','brand','kind','reason')} for x in it['events']][-5:]}
            rank=(m!='similar',cand['stage'],cand['kind']=='cancel')
            if best is None or rank>best[0]:best=(rank,cand)
        if best:r['chinaCancel']=best[1]
    s['chinaCancel']={'folder':v.get('folder',''),'lastScan':v.get('lastScan',{}),'items':len(items),
                      'events':sum(len(it['events']) for it in items)}
    return s

def decide(s,p):
    v=init_china(s)
    key=str(p.get('rowKey','')) if isinstance(p,dict) else '';iid=str(p.get('itemId','')) if isinstance(p,dict) else ''
    d=p.get('decision') if isinstance(p,dict) else ''
    if not key or iid not in v['items'] or d not in ('match','reject','clear'):raise ChinaCancelError('주문과 취소 상품을 확인하세요.')
    if not any(r.get('key')==key for r in s.get('rows',[])):raise ChinaCancelError('주문을 찾지 못했습니다.')
    if d=='clear':v['decisions'].pop(key+'|'+iid,None)
    else:v['decisions'][key+'|'+iid]=d
    return {'message':'같은 상품으로 연결했습니다.' if d=='match' else '다른 상품으로 표시했습니다. 이 주문에는 다시 묻지 않습니다.' if d=='reject' else '선택을 지웠습니다.'}
