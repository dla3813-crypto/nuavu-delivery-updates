# NUAVU_Delay_v0.6.130_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06129.md
