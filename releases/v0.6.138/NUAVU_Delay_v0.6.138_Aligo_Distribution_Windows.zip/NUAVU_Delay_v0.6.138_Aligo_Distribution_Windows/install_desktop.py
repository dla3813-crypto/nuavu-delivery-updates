#!/usr/bin/env python3
"""Create a per-user .app launcher containing application code (not Python).
The caller installs pywebview into a user-local venv first; this builds no binaries.
No admin privileges, no background daemon, no changes to the order database.
"""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
import os
from pathlib import Path
import plistlib
import shlex
import shutil
import sys

ROOT=Path(__file__).resolve().parent

def build_bundle(destination: Path, python: Path) -> Path:
    destination=Path(destination).expanduser()
    if destination.suffix!='.app':raise ValueError('Destination must have .app extension')
    if not Path(python).is_absolute():raise ValueError('Python interpreter path must be absolute')
    destination.parent.mkdir(parents=True,exist_ok=True)
    stage=destination.with_name(destination.stem+'.installing.app')
    if stage.exists():shutil.rmtree(stage)
    resources=stage/'Contents/Resources';macos=stage/'Contents/MacOS'
    resources.mkdir(parents=True);macos.mkdir()
    for name in ('app.py','domain.py','branding.py','provider.py','desktop.py','aftersales_data.py','aftersales_lock.py','aftersales_collect.py','exchange_browser.py','exchange_reship.py','job_alerts.py','browser_window.py','zigzag_credentials.py','zigzag_browser.py','zigzag_sync.py','zigzag_rules.py','phone_alert.py','app_update.py','ably_return_accept.py','return_messages.py','zigzag_returns.py','cafe24_credentials.py','soldout_display.py','soldout_cancel.py','platform_support.py','windows_credentials.py','pickup_browser.py','pickup_controller.py','pickup_report.py','credentials.py','history_seed.py','desktop_backup.py','aligo_provider.py','aligo_http.py','aligo_credentials.py','aligo_workflow.py','workbook_reader.py','supply_calendar.py','delay_risk.py','supply_workflow.py','supply_watch.py','external_notices.py','order_items.py','color_labels.py','order_auto.py','order_browser.py','ezadmin_credentials.py','ably_sync.py','ably_browser.py','amood_push.py','cafe24_returns.py','china_cancel.py','ably_credentials.py','factory_reset.py','return_data.py','return_check.py','return_session.py','return_browser.py','codex_rpc.py','codex_files.py','codex_service.py','codex_view.py','codex_catalog.py','codex_context.py','codex_tools.py','codex_followup.py','nunauri_provider.py'):
        shutil.copy2(ROOT/name,resources/name)
    shutil.copytree(ROOT/'web',resources/'web')
    shutil.copy2(ROOT/'order_export.py',resources/'order_export.py')
    shutil.copytree(ROOT/'templates',resources/'templates')
    shutil.copy2(ROOT/'assets/CS-Pink.icns',resources/'CS-Pink.icns')
    info={'CFBundleName':'배송안내 배포판','CFBundleDisplayName':'배송안내 배포판',
          'CFBundleIdentifier':'kr.nuavu.deliverynotice.distribution','CFBundleVersion':'0.6.138',
          'CFBundleShortVersionString':'0.6.138','CFBundlePackageType':'APPL',
          'CFBundleExecutable':'NUAVU','CFBundleIconFile':'CS-Pink.icns','NSHighResolutionCapable':True,
          'LSArchitecturePriority':['arm64','x86_64'],
          'NSDownloadsFolderUsageDescription':'선택한 다운로드 폴더에 주문 엑셀을 저장하고 읽습니다.',
          'NSDesktopFolderUsageDescription':'선택한 바탕화면 폴더의 출고장·진행상황 엑셀을 읽고 배송안내_배포판_백업에 백업을 저장합니다.',
          'NSAppTransportSecurity':{'NSAllowsLocalNetworking':True}}
    (stage/'Contents/Info.plist').write_bytes(plistlib.dumps(info))
    script='''#!/bin/bash
set -eu
umask 077
HERE="$(cd "$(dirname "$0")/../Resources" && pwd)"
PYTHON=__PYTHON__
LOGDIR="$HOME/Library/Logs/NUAVU Delay Distribution"
mkdir -p "$LOGDIR"
if [ ! -x "$PYTHON" ]; then
  /usr/bin/osascript -e 'display alert "배송안내 배포판" message "실행 구성요소가 없습니다. 처음한번_앱설치.command를 다시 실행하세요."'
  exit 1
fi
export PYTHONDONTWRITEBYTECODE=1
export PYTHONUNBUFFERED=1
cd "$HERE"
# A shell-script .app can inherit a translated execution preference from
# Launch Services. Select the native Python slice before any app/DB startup;
# its Chrome children must inherit the same native execution preference.
if [ "$(/usr/sbin/sysctl -n hw.optional.arm64 2>/dev/null || true)" = 1 ]; then
  if ! /usr/bin/arch -arm64 "$PYTHON" -I -c 'import platform; assert platform.machine() == "arm64"; import webview, objc, AppKit, WebKit, Security, playwright.sync_api' >> "$LOGDIR/desktop.log" 2>&1; then
    /usr/bin/osascript -e 'display alert "배송안내 배포판" message "Apple Silicon용 실행 구성요소를 확인하지 못했습니다. 앱을 닫고 v0.6.138 이상의 처음한번_앱설치.command를 다시 실행하세요. 기존 주문·발송 이력은 유지됩니다."'
    exit 1
  fi
  exec /usr/bin/arch -arm64 "$PYTHON" "$HERE/desktop.py" >> "$LOGDIR/desktop.log" 2>&1
fi
exec "$PYTHON" "$HERE/desktop.py" >> "$LOGDIR/desktop.log" 2>&1
'''.replace('__PYTHON__',shlex.quote(str(python)))
    executable=macos/'NUAVU';executable.write_text(script);executable.chmod(0o755)
    backup=None
    if destination.exists():
        stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f')
        backup=destination.with_name(destination.stem+'.before-'+stamp+'.app')
        destination.rename(backup)
    try:stage.rename(destination)
    except Exception:
        if backup and backup.exists():backup.rename(destination)
        raise
    return destination

def main():
    p=argparse.ArgumentParser();p.add_argument('--destination',default=str(Path.home()/'Applications/배송안내 배포판.app'))
    p.add_argument('--python',default=sys.executable);args=p.parse_args()
    target=build_bundle(Path(args.destination),Path(args.python))
    print('앱 생성 완료: '+str(target))
    print('앱 코드는 이 번들 안에, Python 실행환경은 사용자 Library 안에 있습니다. 둘 다 유지하세요.')

if __name__=='__main__':main()
