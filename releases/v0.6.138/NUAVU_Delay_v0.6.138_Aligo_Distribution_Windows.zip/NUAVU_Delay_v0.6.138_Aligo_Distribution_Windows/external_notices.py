"""Platform/manual acknowledgement import. Never a delivery receipt or send job."""
from __future__ import annotations
import base64,copy,re,secrets
from collections import defaultdict
from datetime import date
from workbook_reader import read_xlsx,text,cell,integer,WorkbookError,MAX_FILE
from supply_workflow import digest
from order_items import ABLY,item_id,items_of,ItemIdError
from branding import normalize_seller

class ExternalError(ValueError):pass
ALIASES={'orderId':['주문번호'],'product':['상품명'],'option':['옵션정보','옵션명'],
         'seller':['판매채널','판매처'],'qty':['수량'],'itemId':['상품주문번호','주문상품번호']}
def compact(v):return re.sub(r'\s+','',text(v))
def _checked_item_id(value):
    try:return item_id(value)
    except ItemIdError as exc:raise ExternalError(str(exc)) from exc

def ably_entries(raw,shop_name=""):
    sheets=read_xlsx(raw);entries=[];seen=set();headers=0
    for sheet in sheets:
        # Ably's first sheet contains sample orders: it is NOT the dispatch list.
        if re.search(r'유의사항|작성방법|샘플|가이드|instructions|sample',sheet['name'],re.I):continue
        found=None
        for index,values in enumerate(sheet['rows'][:30]):
            hs=[compact(v) for v in values];mapping={}
            for key,aliases in ALIASES.items():mapping[key]=next((hs.index(a) for a in aliases if a in hs),-1)
            if all(mapping[k]>=0 for k in ('orderId','product','option','qty','seller')):
                found=(index,mapping);break
        if not found:continue
        headers+=1;idx,m=found
        for lineno,values in enumerate(sheet['rows'][idx+1:],idx+2):
            get=lambda key:cell(values,m[key]) if m[key]>=0 else None
            oid=text(get('orderId'));prod=text(get('product'))
            if not oid and not prod:continue
            seller=normalize_seller(get('seller'),shop_name)
            if not seller:raise ExternalError(f'{sheet["name"]} {lineno}행: 판매채널을 확인하세요. 설정하지 않은 다른 쇼핑몰의 주문은 반영하지 않습니다.')
            qty=integer(get('qty'))
            if not oid or not prod or not qty:raise ExternalError(f'{sheet["name"]} {lineno}행: 주문번호/상품/수량을 확인하세요.')
            if re.search(r'\de[+-]?\d',oid,re.I):raise ExternalError('주문번호가 지수 표기입니다. 원본을 텍스트로 내보내세요.')
            e={'seller':seller,'orderId':oid,'product':prod,'option':text(get('option')),'qty':qty,
               'itemId':_checked_item_id(get('itemId')),'sheet':sheet['name'],'line':lineno}
            identity=(seller,oid,e['itemId']) if e['itemId'] else (seller,oid,prod,e['option'])
            if identity in seen:continue
            seen.add(identity);entries.append(e)
    if not headers:raise ExternalError('에이블리 발송관리의 주문번호·상품명·옵션 정보·수량·판매채널 열을 찾지 못했습니다.')
    if not entries:raise ExternalError('반영할 주문이 없습니다. 목록을 지우는 작업은 하지 않았습니다.')
    return entries

def matches(state,entries,due):
    """Only Ably's line IDs determine the match. No order/name/option fallback.

    An aggregated application row can include multiple detail IDs. All of those
    quantities must be covered to mark that entire row notified; a subset must
    not accidentally mark the other line(s) too.
    """
    byid=defaultdict(list);metadata={};invalid=set()
    for row in state['rows']:
        if not row.get('active') or row.get('seller')!=ABLY:continue
        try:parts=items_of(row)
        except ItemIdError:parts=[];invalid.add(row['key'])
        metadata[row['key']]=parts
        for part in parts:byid[part['id']].append((row,part))
    results=[];groups=defaultdict(list)
    for entry in entries:
        e=dict(entry);e.update(key='',status='missing',reason='',matchMethod='상품주문번호',matchedOrderId='')
        ident=e.get('itemId','')
        if e['seller']!=ABLY:e.update(status='excluded',reason='에이블리 외 판매처: 자동 안내 반영 제외')
        elif not ident:e.update(status='missing_id',reason='발송관리 엑셀에 상품주문번호가 없습니다.')
        elif not byid.get(ident):
            e['reason']='일치하는 상품주문번호 없음 · 주문 상세번호(M열)가 포함된 최신 확장주문검색을 먼저 불러오세요.'
        elif len(byid[ident])!=1:e.update(status='ambiguous',reason='같은 상품주문번호가 여러 주문에 연결됨 · 중복 번호 확인 필요')
        else:
            row,part=byid[ident][0]
            if part['qty']!=e['qty']:e.update(status='quantity',reason='상품주문번호는 일치하나 수량이 다릅니다. 최신 주문 확인 필요')
            else:
                e.update(key=row['key'],status='ready',matchedOrderId=row['orderId'])
                groups[row['key']].append(e)
        results.append(e)
    rows={r['key']:r for r in state['rows']}
    for key,group in groups.items():
        parts=metadata[key];provided=[e['itemId'] for e in group];required={p['id'] for p in parts}
        if len(provided)!=len(set(provided)):
            reason='발송관리 파일에 같은 상품주문번호가 중복됨 · 중복 행 확인 필요'
        elif sum(p['qty'] for p in parts)!=rows[key]['qty'] or set(provided)!=required:
            reason='같은 주문·상품·옵션으로 합쳐진 행의 상품주문번호/수량 일부만 포함됨 · 전체 안내 처리하지 않습니다.'
        else:continue
        for e in group:e.update(status='partial',reason=reason,key='')
    return results

class ExternalWorkflow:
    def external_preview(self,p):
        due=p.get('dueDate','')
        try:
            if not isinstance(due,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',due):raise ValueError('date')
            date.fromisoformat(due)
        except (ValueError,TypeError):raise ExternalError('이미 안내한 출고 예정일을 선택하세요.')
        data=p.get('data','')
        if not isinstance(data,str) or len(data)>MAX_FILE*1.4:raise ExternalError('파일 크기를 확인하세요.')
        try:entries=ably_entries(base64.b64decode(data,validate=True),self.store.read()['settings'].get('shopName',''))
        except (ValueError,WorkbookError) as e:raise ExternalError(str(e)) from e
        s=self.store.read();res=matches(s,entries,due);token=secrets.token_urlsafe(24)
        ready=[e for e in res if e['status']=='ready'];bykey={r['key']:r for r in s['rows']}
        plan={'entries':entries,'sourceFile':text(p.get('fileName'))[:250],'dueDate':due,
              'keys':list(dict.fromkeys(e['key'] for e in ready)),'signatures':{e['key']:digest(bykey[e['key']]) for e in ready}}
        # Existing send plans share the cache but this is a distinct, typed token.
        self.plans['external:'+token]=plan
        if len(self.plans)>200:self.plans.pop(next(iter(self.plans)))
        return {'token':token,'entries':res,'sourceCount':len(entries),'ready':len(plan['keys']),'matchedEntries':len(ready),'missing':len(res)-len(ready),
                'orders':len({(bykey[k]['seller'],bykey[k]['orderId']) for k in plan['keys']}),'dueDate':due,'message':'이 엑셀은 안내 이력만 반영합니다. 전체 미출고 목록을 교체하지 않습니다.'}

    def _external_record(self,s,keys,due,source,entries,notice_key='first',request_id=''):
        from domain import now,applied_notice,notice_sort_key
        bykey={r['key']:r for r in s['rows'] if r.get('active')};stamp=now();groups=defaultdict(list);skipped=0
        if notice_key not in ('first','change'):raise ExternalError('최초 지연 또는 일정 재변경을 선택하세요.')
        for key in keys:
            row=bykey.get(key)
            if not row:raise ExternalError('현재 미출고 목록에서 선택 상품이 사라졌습니다. 다시 선택하세요.')
            ns=sorted([n for n in s['notices'] if key in n.get('itemKeys',[]) and applied_notice(n)],key=notice_sort_key)
            if not request_id and ns and ns[-1].get('manualAcknowledgement') and ns[-1].get('dueDate')==due:
                skipped+=1;continue
            groups[(row['seller'],row['orderId'])].append(row)
        matchedkeys={r['key'] for rows in groups.values() for r in rows};cancelled=0
        # Prevent a previously queued old notice from being sent after marking it
        # externally acknowledged. Only intersecting unsent batches are cancelled.
        for n in s['notices']:
            if n['status'] in ('QUEUED','SCHEDULED','PAUSED') and matchedkeys.intersection(n.get('itemKeys',[])):
                self.transition(n,'CANCELLED','메시지 없는 안내 처리로 해당 미요청/예약 묶음을 취소했습니다.');cancelled+=1
                self.resolve_wait_alerts(s,n)
        for (seller,oid),rows in groups.items():
            rowkeys={r['key'] for r in rows};es=[e for e in entries if e.get('key') in rowkeys]
            note=('사용자가 안내할 출고 예정일을 변경하고 안내 완료 1회를 기록했습니다. 실제 메시지 발송 없음.' if request_id else '사용자가 이미 안내한 출고 예정일을 기록했습니다. 문자/알림톡 요청 및 공급사 성공 확인이 아닙니다.')
            s['notices'].append({'id':'ACK-'+secrets.token_urlsafe(16),'ref':'','kind':'EXTERNAL','channel':'메시지 없는 안내 처리',
                'content':'실제 발송 없음 · 사용자 안내 완료 표시','title':'플랫폼/수동 배송지연 안내',
                'phone':'','seller':seller,'orderId':oid,'dueDate':due,'noticeType':'delay','templateKey':notice_key,
                'itemKeys':[r['key'] for r in rows],'products':[{k:r[k] for k in ('product','option','qty')} for r in rows],
                'createdAt':stamp,'updatedAt':stamp,'importedAt':stamp,'logicalCreatedAt':stamp,'sourceSnapshot':stamp,
                'isTest':False,'status':'IMPORTED','source':'external_excel','manualAcknowledgement':True,
                **({'manualDueDateUpdate':True,'manualRequestId':request_id,'manualRequestKeys':sorted(keys),'manualRequestTemplate':notice_key} if request_id else {}),
                'actualSendDateKnown':False,'sourceFile':source,'sourceSheet':', '.join(sorted({e['sheet'] for e in es})),
                'sourceRows':[e['line'] for e in es],'sourceMappings':[{'itemId':e.get('itemId',''),'key':e.get('key',''),'method':'상품주문번호'} for e in es],
                'note':note,'events':[{'at':stamp,'status':'IMPORTED','note':note}]})
        s['queuePaused']=any(n['status']=='PAUSED' for n in s['notices'])
        s['audits'].append({'at':stamp,'event':'메시지 없는 안내 기록','source':source,'dueDate':due,'items':len(matchedkeys),'cancelled':cancelled})
        return {'items':len(matchedkeys),'orders':len(groups),'skipped':skipped,'cancelled':cancelled,
                'message':f'{len(matchedkeys)}개 상품 안내 처리 완료 · 실제 메시지 0통 · 관련 미요청/예약 {cancelled}건 취소'}

    def external_apply(self,p):
        token=p.get('token','');plan=self.plans.get('external:'+str(token))
        if not plan:raise ExternalError('엑셀을 다시 선택하고 날짜를 확인하세요.')
        if not plan['keys']:raise ExternalError('상품주문번호가 일치하는 반영 대상이 없습니다. M열 포함 주문 엑셀을 먼저 확인하세요.')
        with self.network_lock,self.store.edit() as s:
            bykey={r['key']:r for r in s['rows']}
            if any(k not in bykey or digest(bykey[k])!=sig for k,sig in plan['signatures'].items()):raise ExternalError('주문 정보가 바뀌었습니다. 다시 대조하세요.')
            if any(n['status']=='SENDING' and set(plan['keys']).intersection(n.get('itemKeys',[])) for n in s['notices']):raise ExternalError('선택 주문의 실제 발송이 처리 중입니다. 완료 후 다시 반영하세요.')
            current=matches(s,plan['entries'],plan['dueDate'])
            if {e['key'] for e in current if e['status']=='ready'}!=set(plan['keys']):
                raise ExternalError('상품주문번호 연결이 변경되었습니다. 다시 주문 대조하세요.')
            res=self._external_record(s,plan['keys'],plan['dueDate'],plan['sourceFile'],current)
        self.plans.pop('external:'+str(token),None)
        if self.archive:self.backup_desktop(force=True,reason='external-notice')
        return res

    def run_pending_platform_pushes(self):
        """Worker tick: start the 오전 9시 예약 platform pushes whose time has come (desktop hook required; otherwise they wait)."""
        from datetime import datetime,timezone
        import domain as _domain
        hook=getattr(self,'manual_notice_hook',None)
        pending=(getattr(self.store,'peek',None) or self.store.read)().get('pendingPlatformPushes') or []   # 2026-10-28 CPU: 읽기 전용 캐시
        if not pending or not hook:return []
        now=_domain.datetime.now(timezone.utc)   # app clock
        def due(item):
            try:return datetime.fromisoformat(item['at'])<=now
            except (KeyError,ValueError,TypeError):return True
        todo=[x for x in pending if due(x)]
        if not todo:return []
        ids={x['id'] for x in todo}
        with self.store.edit() as s:s['pendingPlatformPushes']=[x for x in s.get('pendingPlatformPushes',[]) if x.get('id') not in ids]
        for item in todo:
            try:
                note=hook(list(item.get('keys',[])))
                if note:self.add_job_alert('오전 9시 예약 플랫폼 안내 시작',note)
            except Exception as exc:self.add_job_alert('예약 플랫폼 안내 시작 실패',str(exc) or type(exc).__name__,'error')
        return todo
    def external_manual(self,p):
        keys=p.get('keys');due=p.get('dueDate')
        if not isinstance(keys,list) or not keys or len(keys)>20000 or any(not isinstance(k,str) for k in keys):raise ExternalError('안내 처리할 주문상품을 선택하세요.')
        try:
            if not isinstance(due,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',due):raise ValueError('date')
            date.fromisoformat(due)
        except (ValueError,TypeError):raise ExternalError('안내할 출고 예정일을 선택하세요.')
        keys=list(dict.fromkeys(keys))
        # 2026-10-21: 자사몰은 메시지 없는 배송지연 안내 금지 (실수로 같이 보내는 것 방지)
        _rows={r['key']:r for r in self.store.read()['rows']}
        if any((_rows.get(k) or {}).get('seller')=='누아브 자사몰' for k in keys):raise ExternalError('자사몰 주문건이 끼어있습니다. 자사몰을 해제 후 보내주세요.')
        schedule=p.get('schedule','') or ''
        if schedule not in ('','now','morning'):raise ExternalError('전송 시점을 확인하세요.')
        mode=p.get('mode','');request_id=''
        if mode:
            if mode!='set_due_date':raise ExternalError('안내 처리 방식을 확인하세요.')
            request_id=p.get('requestId','')
            if not isinstance(request_id,str) or not re.fullmatch(r'[a-zA-Z0-9_-]{16,80}',request_id):raise ExternalError('안내창을 다시 열어 처리하세요.')
        with self.network_lock,self.store.edit() as s:
            previous=[n for n in s['notices'] if request_id and n.get('manualRequestId')==request_id]
            if previous:
                if any(n.get('manualRequestKeys')!=sorted(keys) or n.get('dueDate')!=due or n.get('manualRequestTemplate')!=p.get('templateKey','first') for n in previous):raise ExternalError('이미 처리한 요청의 내용이 다릅니다. 안내창을 다시 여세요.')
                return {'items':len(keys),'orders':len(previous),'skipped':0,'cancelled':0,'replayed':True,'message':f'{len(keys)}개 상품 안내 처리가 이미 완료되었습니다. 이력을 중복 추가하지 않았습니다.'}
            if any(n['status']=='SENDING' and set(keys).intersection(n.get('itemKeys',[])) for n in s['notices']):raise ExternalError('선택한 주문이 실제 발송 중입니다. 완료 후 다시 처리하세요.')
            if request_id:
                # 2026-10-23: 지그재그 주문이 섞인 메시지 없는 안내는 지그재그 달력에서 고를 수 있는 날짜만 (고객 안내 문자는 제한 없음).
                from zigzag_rules import check_due
                from domain import today as _today
                _sel=[r for r in s['rows'] if r['key'] in set(keys)];_err=check_due(s,_sel,due,_today())
                if _err:raise ExternalError(_err)
            res=self._external_record(s,keys,due,'직접 선택 · 엑셀 없음',[],p.get('templateKey','first'),request_id=request_id)
            morning_at=''
            if schedule=='morning':
                # 18시 이후 선택지 (문자 작성과 동일): 안내 이력·예정일은 지금 바꾸고, 에이블리·지그재그 플랫폼 안내는 오전 9시에 보낸다.
                from domain import morning_send_time
                import domain as _domain;from datetime import timezone
                morning_at=morning_send_time(_domain.datetime.now(timezone.utc)).isoformat(timespec='seconds')   # app clock (tests patch domain.datetime)
                s.setdefault('pendingPlatformPushes',[]).append({'id':request_id or secrets.token_urlsafe(12),'keys':list(keys),'at':morning_at,'createdAt':_domain.datetime.now(timezone.utc).isoformat(timespec='seconds'),'dueDate':due})
        if self.archive:self.backup_desktop(force=True,reason='manual-notice')
        if schedule=='morning':
            res['scheduledAt']=morning_at;res['message']=res.get('message','')+' · 에이블리·지그재그 플랫폼 안내는 오전 9시('+morning_at[5:16].replace('T',' ')+')에 전송합니다.'
            return res
        # Message-less acknowledgement → Ably gets the same 배송지연 message for these rows (desktop hook; push only).
        hook=getattr(self,'manual_notice_hook',None)
        if hook:
            try:note=hook(list(keys))
            except Exception as exc:
                note='';self.add_job_alert('에이블리 자동 발송 처리 시작 실패',str(exc) or type(exc).__name__,'error')
            if note:res['message']=res.get('message','')+' · '+note
        return res
