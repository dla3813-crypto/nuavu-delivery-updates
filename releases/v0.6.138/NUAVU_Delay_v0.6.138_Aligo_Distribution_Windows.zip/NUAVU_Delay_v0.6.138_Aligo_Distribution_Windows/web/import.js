// 2026-10-27: crypto.randomUUID 는 HTTPS·localhost 에서만 있다 (HTTP 원격 접속 → undefined). 요청 ID는 항상 이 함수로.
globalThis.nuavuRequestId=function(){
 try{if(typeof crypto!=='undefined'&&typeof crypto.randomUUID==='function')return crypto.randomUUID();}catch(e){}
 try{const a=new Uint8Array(16);crypto.getRandomValues(a);return Array.from(a,b=>b.toString(16).padStart(2,'0')).join('');}catch(e){}
 let s='';while(s.length<32)s+=Math.random().toString(36).slice(2);return s.slice(0,32);
};
/* NUAVU: read-only Excel column detection and normalization. Server validates again. */
(function(root) {
'use strict';
const SELLERS = ['누아브 에이블리','누아브 자사몰','누아브 지그재그','누아브 아무드'];   // 2026-10-21 아무드 추가
// 이지어드민 확장주문검색의 판매처 표기 → 앱 판매처 (예: "아무드 누아브" → 누아브 아무드)
const SELLER_ALIASES = {'아무드누아브':'누아브 아무드','아무드':'누아브 아무드','누아브아무드':'누아브 아무드'};
const clean = v => String(v ?? '').normalize('NFC').trim();
const compact = v => clean(v).replace(/\s+/g,'');
const ALIASES = {
 seller:['판매처','판매처명','판매채널','쇼핑몰명','쇼핑몰'],
 orderId:['주문번호','판매처주문번호','사이트주문번호','쇼핑몰주문번호','주문코드'],
 orderItemId:['주문상세번호','주문상세번호(에이블리)','상품주문번호','주문상품번호','주문품목번호'],
 product:['상품명','상품이름','판매처상품명','주문상품명'],
 option:['옵션명','옵션','옵션정보','상품옵션'],
 qty:['수량','주문수량','상품수량'],
 orderDate:['주문일','주문일시','결제일','결제일시','주문날짜'],
 orderTime:['주문시간','주문시각','결제시간','주문 시간'],  // 확장주문검색 has a separate time column (e.g. 20:59:33)
 buyer:['주문자명','주문자이름','주문자','구매자명'],
 recipient:['수령자이름','수령자명','수취인명','수취인','수령인'],
 phone:['주문자휴대폰','주문자휴대전화','구매자휴대폰','주문자연락처','연락처','주문자전화번호','주문자전화'],
 altPhone:['수령자휴대폰','수취인연락처','수령자연락처','수취인휴대폰','수령자전화','수령자전화번호']
};
function kstDate(now=new Date()) { return new Date(now.getTime()+9*3600000).toISOString().slice(0,10); }
function addDays(date, n) { return new Date(Date.parse(date+'T00:00:00Z')+n*86400000).toISOString().slice(0,10); }
function validDate(v) { return /^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v+'T00:00:00Z')) && new Date(v+'T00:00:00Z').toISOString().slice(0,10)===v; }
function uid() { return (root.nuavuRequestId ? root.nuavuRequestId() : null) || globalThis.crypto?.randomUUID?.() || Date.now().toString(36)+'-'+Math.random().toString(36).slice(2); }
let shopName='';
function setShopName(value){shopName=compact(value);}
function sourceSeller(v) {
 const label=clean(v).replace(/\s+/g,' '),k=compact(label);if(!shopName||!label||label.length>150||/[\x00-\x1f\x7f]/.test(label))return null;
 const names=[shopName,...(['누아브','nuavu'].includes(shopName.toLowerCase())?['누아브']:[])];
 for(const channel of ['에이블리','자사몰','지그재그','아무드'])if(k===channel||names.some(n=>k===n+channel||k===channel+n))return '누아브 '+channel;
 for(let i=0;i<label.length;i++)if(label[i]===' '){const left=label.slice(0,i),right=label.slice(i+1);const channel=names.includes(compact(left))?right:names.includes(compact(right))?left:'';if(channel)return '누아브 '+compact(channel);}
 return null;
}
function seller(v,strict=false) {if(strict)return sourceSeller(v);const k=compact(v);return SELLERS.find(s=>compact(s)===k)||SELLER_ALIASES[k]||sourceSeller(v)||SELLERS.find(s=>s.replace('누아브 ','')===k)||null;}
function discoverSellers(matrix,headerIndex,mapping){
 const seen=new Set(),result=[];if(mapping.seller<0)return result;
 for(const row of matrix.slice(headerIndex+1)){
  if(row.some(v=>/^(합계|총계|총합계)$/.test(clean(v))))continue;
  const label=clean(row[mapping.seller]).replace(/\s+/g,' '),id=compact(label);
  if(sourceSeller(label)&&!seen.has(id)){seen.add(id);result.push(label);}
 }return result;
}
function rememberedSellers(available,settings){
 const prefs=(settings.importSellerChoices||{})[compact(settings.shopName)]||{},legacy=settings.importScope??SELLERS;
 return available.filter(label=>Object.hasOwn(prefs,compact(label))?prefs[compact(label)]:(SELLERS.includes(sourceSeller(label))?legacy.includes(sourceSeller(label)):true));
}
function inSourceScope(row,scope){const source=row.sourceSeller||row.exportContacts?.sellerLabel;return source?scope.some(x=>compact(x)===compact(source)):scope.some(x=>sourceSeller(x)===row.seller);}
function phone(v) { let p=clean(v).replace(/[^0-9+]/g,''); if(p.startsWith('+82')) p='0'+p.slice(3); return p.replace(/\D/g,''); }
function validPhone(v) { return /^01[016789]\d{7,8}$/.test(phone(v)); }
function maskPhone(v) { const p=phone(v); return p.length>=8 ? p.slice(0,3)+'-****-'+p.slice(-4) : (p?'번호 확인 필요':'번호 없음'); }
function itemId(v) {
 if(v===undefined||v===null||v==='')return '';
 if(typeof v==='number'&&(!Number.isSafeInteger(v)||Math.abs(v)>=1e15))throw Error('주문 상세번호 정밀도를 확인하세요. 텍스트로 다시 내보내 주세요.');
 const id=String(v).normalize('NFKC').trim();
 if(typeof v==='boolean'||/^[+-]?\d+(?:\.\d+)?e[+-]?\d+$/i.test(id)||id.length>150||/[\s\x00-\x1f]/.test(id))throw Error('주문 상세번호 형식 오류. 텍스트 번호를 사용하세요.');
 return id;
}
// Display search only. Never use these relaxed tokens for stock/product matching.
function productSearch(values,query) {
 const words=value=>String(value??'').normalize('NFKC').toLocaleLowerCase()
  .replace(/([가-힣])([a-z0-9])/g,'$1 $2').replace(/([a-z0-9])([가-힣])/g,'$1 $2')
  .split(/[^\p{L}\p{N}]+/u).filter(Boolean);
 const terms=words(query),hay=values.flatMap(words);
 if(!terms.length)return values.map(v=>String(v??'').normalize('NFKC').toLocaleLowerCase()).join(' ').includes(query);
 // Option markers and sizes must remain distinct: X != XL, 4XL != 14XL.
 const exact=t=>/^(?:\d+|[xo]|(?:\d+)?x*[sml]|free)$/i.test(t);
 return terms.every(t=>hay.some(w=>exact(t)?w===t:w.includes(t)));
}
function matchesSearch(r,query,field='all') {
 const q=String(query??'').normalize('NFKC').trim().toLocaleLowerCase();if(!q)return true;
 const ids=(r.orderItems||[]).map(p=>p.id);if(r.orderItemId)ids.push(r.orderItemId);
 if(['product','productName','option'].includes(field))return productSearch(field==='product'?[r.product,r.option]:[field==='productName'?r.product:r.option],q);
 if(field==='all'&&productSearch([r.product,r.option],q))return true;
 const hay=field==='orderId'?[r.orderId,...ids]:field==='customer'?[r.buyer,r.recipient,r.phone]:[r.seller,r.orderId,...ids,r.buyer,r.recipient,r.phone];
 if(hay.map(v=>String(v??'').normalize('NFKC')).join(' ').toLocaleLowerCase().includes(q))return true;
 // Phone normalization only in customer/all search, never in product/option search.
 if(!['all','customer'].includes(field)||!/^\+?[\d\s().\-\u2010-\u2015\u2212]+$/u.test(q))return false;
 const digits=phone(q);return digits.length>=2&&phone(r.phone).includes(digits);
}
function keyOf(r) { return JSON.stringify([r.seller,clean(r.orderId),clean(r.product),clean(r.option)]); }
function orderKey(r) { return JSON.stringify([r.seller,r.orderId]); }
function guessMapping(headers) {
 const out={}; for (const [field, aliases] of Object.entries(ALIASES)) {
  out[field]=-1; for (const a of aliases) { const i=headers.findIndex(h=>compact(h)===compact(a)); if(i>=0){out[field]=i;break;} }
 } return out;
}
function findHeader(rows) {
 let best=0,score=-1; rows.slice(0,25).forEach((r,i)=>{const m=guessMapping(r);const n=Object.values(m).filter(v=>v>=0).length;if(n>score){best=i;score=n;}});return best;
}
function parseRows(matrix, headerIndex, mapping, options={}) {
 const contactAliases={recipientMobile:['수령자휴대폰','수취인휴대폰','수취인연락처','수령자연락처'],recipientPhone:['수령자전화','수령자전화번호'],buyerPhone:['주문자전화','주문자전화번호'],buyerMobile:['주문자휴대폰','주문자휴대전화','구매자휴대폰']};
 const contactColumns=Object.fromEntries(Object.entries(contactAliases).map(([key,aliases])=>[key,(matrix[headerIndex]||[]).findIndex(h=>aliases.some(a=>compact(a)===compact(h)))]));
 const rows=[],errors=[],excluded={},aggregated=new Map();let combined=0;
 for(let i=headerIndex+1;i<matrix.length;i++) {
  const raw=matrix[i];if(!raw.some(v=>clean(v)))continue;
  if(raw.some(v=>/^(합계|총계|총합계)$/.test(clean(v))))continue;
  const get=f=>mapping[f]>=0?raw[mapping[f]]:'';
  const channel=seller(get('seller'),options.strictShop===true);
  if(!channel||(Array.isArray(options.scope)&&!(options.scopeLabels?options.scope.some(x=>compact(x)===compact(get('seller'))):options.scope.includes(channel)))) { const original=clean(get('seller'))||'(판매처 비어 있음)';excluded[original]=(excluded[original]||0)+1;continue; }
  const id=clean(get('orderId')), product=clean(get('product'));
  if(!id || !product) { errors.push({line:i+1,message:!id?'주문번호가 비어 있습니다.':'상품명이 비어 있습니다.'});continue; }
  if(/^[-+]?\d+(\.\d+)?e[+-]?\d+$/i.test(id) || (typeof get('orderId')==='number' && Math.abs(get('orderId'))>=1e15)) {
   errors.push({line:i+1,message:'주문번호가 지수 표기이거나 정밀도 손실 가능성이 있습니다. 원본에서 텍스트로 다시 내보내 주세요.'});continue;
  }
  const qtyStr=clean(get('qty')).replace(/,/g,''),qty=qtyStr?Number(qtyStr):1;
  if(!Number.isInteger(qty)||qty<=0){errors.push({line:i+1,message:'수량은 1 이상의 정수여야 합니다.'});continue;}
  const dateRaw=clean(get('orderDate')); const dm=dateRaw.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
  // 2026-10-19: keep the order time for 당일/익일 출고 판정. A date-only 주문일 plus 주문시간 becomes 'YYYY-MM-DD HH:MM:SS'.
  const timeRaw=clean(get('orderTime')).match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?/);
  const timestamp=dm&&timeRaw&&!/\d{1,2}:\d{2}/.test(dateRaw)?`${dm[1]}-${dm[2].padStart(2,'0')}-${dm[3].padStart(2,'0')} ${timeRaw[1].padStart(2,'0')}:${timeRaw[2]}:${timeRaw[3]||'00'}`:dateRaw;
  const date=dm?`${dm[1]}-${dm[2].padStart(2,'0')}-${dm[3].padStart(2,'0')}`:'';
  const primary=phone(get('phone')),secondary=phone(get('altPhone'));
  const r={seller:channel,sourceSeller:clean(get('seller')),orderId:id,product,option:clean(get('option')),qty,orderDate:date,orderTimestamp:timestamp,
   buyer:clean(get('buyer')),recipient:clean(get('recipient')),phone:primary||secondary,
   phoneSource:primary?'주문자':'수령자 대체',needsPhoneApproval:!primary&&!!secondary,
   active:true,sourceLine:i+1,review:false};
  r.exportContacts=Object.values(contactColumns).some(c=>c>=0)?{...Object.fromEntries(Object.entries(contactColumns).map(([k,c])=>[k,c>=0?clean(raw[c]):''])),sellerLabel:clean(get('seller'))}:null;
  if(channel===SELLERS[0]||channel==='누아브 아무드') {
   try {const detail=itemId(get('orderItemId'));r.orderItemIdMapped=mapping.orderItemId>=0;r.orderItemId=detail;r.orderItems=detail?[{id:detail,qty}]:[];}
   catch(e){errors.push({line:i+1,message:e.message});continue;}
  }
  r.key=keyOf(r);
  if(aggregated.has(r.key)){
   const old=aggregated.get(r.key);
   if(old.phone!==r.phone) errors.push({line:i+1,message:'같은 주문·상품·옵션의 연락처가 서로 다릅니다.'});
   else if((r.orderItems||[]).some(p=>(old.orderItems||[]).some(x=>x.id===p.id)))errors.push({line:i+1,message:'같은 상품주문번호가 반복됩니다. 중복 행을 확인하세요.'});
   else {old.qty+=r.qty;old.orderItems=[...(old.orderItems||[]),...(r.orderItems||[])];old.orderItemId=old.orderItems.length===1?old.orderItems[0].id:'';old.orderItemIdMapped=old.orderItemIdMapped||r.orderItemIdMapped;old.exportContacts=old.exportContacts&&r.exportContacts?Object.fromEntries(Object.keys(old.exportContacts).map(k=>[k,old.exportContacts[k]===r.exportContacts[k]?old.exportContacts[k]:''])):null;combined++;}
  } else {aggregated.set(r.key,r);rows.push(r);}
 }
 return {rows,errors,excluded,combined};
}

const api={discoverSellers,rememberedSellers,inSourceScope,SELLERS,setShopName,seller,ALIASES,guessMapping,findHeader,parseRows,kstDate,addDays,validDate,matchesSearch,itemId};
root.NuavuImport=api;if(typeof module!=="undefined"&&module.exports)module.exports=api;
})(typeof globalThis!=="undefined"?globalThis:this);
