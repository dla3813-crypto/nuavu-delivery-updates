'use strict';
// 2026-10-20 판매처별 자동 회수접수 선택 (에이블리·자사몰·지그재그)
function pickupSellerValues(){const o={};for(const b of document.querySelectorAll('.pickup-seller'))o[b.dataset.seller]=b.checked;return o;}
function applyPickupSellers(s){const sellers=(s&&s.settings&&s.settings.sellers)||{};for(const b of document.querySelectorAll('.pickup-seller'))b.checked=sellers[b.dataset.seller]!==false;syncPickupSellers();}
function syncPickupSellers(){const m=document.getElementById('pickupEnabled');if(!m)return;for(const b of document.querySelectorAll('.pickup-seller'))b.disabled=!m.checked;}
document.addEventListener('change',e=>{if(e.target&&e.target.id==='pickupEnabled')syncPickupSellers();});
// Separate return screen. Order selection, exports and sending are never reused.
(()=>{
 const el=id=>document.getElementById(id);
 const labels={late:'늦은 반품신청',urgent:'환불승인 시급',arrived:'승인처리 대상',transit:'반품 배송중',fee:'반품배송비 -3,000원',registered:'회수 접수 완료',uncollected:'회수 전 / 미접수',unknown:'조회 확인 필요',not_defect_done:'반품 불량 아님 안내 완료',exchange:'교환'};
 const descriptions={late:'반품 요청일이 원송장 배달완료일로부터 7일을 넘긴 상품입니다.',urgent:'반품 배달완료일로부터 7일 초과, 8일째부터 표시합니다.',arrived:'반품 배달완료 후 7일 이내인 상품입니다.',transit:'CJ 집화·간선 또는 우체국 접수·도착·발송 이력이 있는 상품입니다.',fee:'다른 색상에 해당하지 않는 반품배송비 -3,000원 상품입니다.',registered:'반품송장이 택배사에 접수(접수전)되어 있지만 아직 집화·수거 이력이 없는 상품입니다. 회수접수를 다시 하지 않습니다.',uncollected:'택배사 조회는 완료했지만 반품송장 또는 회수 이력이 없습니다.',unknown:'송장번호·택배사·조회 오류를 확인해야 합니다. 미배송 건수에 합산하지 않습니다.',exchange:'교환요청·교환수거중 상품을 함께 표시합니다. 이지어드민 C/S에서 C+주문번호(교환 재발송) 주문을 찾아 송장·상태를 표시하며, 재발송 송장이 있는 행은 굵게 + 교환 발송완료로 표시합니다. 교환 접수·승인·철회는 실행하지 않습니다.',not_defect_done:'반품 불량 아님 안내 문자를 요청·발송한 반품입니다. 문자 결과는 예약·발송 이력에서 확인하세요.'};
 let view=false,category='',job={},checking=false,sort='requestedAt',direction=-1,signature='',sellerFilter='';
 const picked=new Set();const sellerOf=r=>r.seller||'에이블리';
 const SELLERS=[['','전체 판매처'],['에이블리','에이블리'],['자사몰','자사몰'],['지그재그','지그재그']];
 let data={rows:[],counts:{},lastChecked:''};
 el('returnsPanel').innerHTML=`
 <div class="returns-heading"><div><p class="eyebrow">RETURNS</p><h2>반품/교환</h2><p class="sub">에이블리 반품 진행 관리 · 지난 일년 · 상품별 조회</p></div><div class="settings-actions"><button id="returnRun" class="return-primary">반품체크 · 지금 조회</button><button id="exchangeRun" class="return-primary">교환 · 지금 조회</button><button id="allRun" class="return-primary" title="반품체크와 교환 조회를 한 번에 실행합니다">전체 · 지금 조회</button><span class="return-only-run"><button data-return-only="에이블리" title="에이블리 반품만 조회해 그 판매처 결과만 바꿉니다">에이블리 반품조회</button><button data-return-only="자사몰" title="자사몰 반품만 조회해 그 판매처 결과만 바꿉니다">자사몰 반품조회</button><button data-return-only="지그재그" title="지그재그 반품만 조회해 그 판매처 결과만 바꿉니다">지그재그 반품조회</button></span><button id="pickupOpen">회수접수</button><button id="returnSettingsOpen">반품 설정</button><button id="returnBack">주문 목록으로</button></div></div>
 <p id="returnStamp" class="sub"></p><p id="returnStatus" role="status"></p>
 <div class="settings-actions"><button id="returnContinue" hidden>로그인 완료 · 계속</button><button id="returnCancel" hidden>조회 중단 · 창 닫기</button></div>
 <div id="returnSellers" class="return-sellers tabs" role="group" aria-label="반품 판매처"></div>
 <div id="returnTabs" class="return-tabs" role="group" aria-label="반품 섹션"></div>
 <p id="returnDescription" class="sub"></p>
 <div class="return-filters"><input id="returnSearch" aria-label="반품 검색" placeholder="주문번호, 상품명·옵션, 고객명, 송장번호 검색"><select id="returnEmphasis" aria-label="반품 사유 추가 필터"><option value="">모든 반품 사유·배송비</option><option value="seller">판매자 사유만</option><option value="fee">-3,000원 전체</option><option value="blueFee">배송중인 -3,000원</option></select><select id="returnSort" aria-label="반품 목록 정렬"><option value="requestedAt_desc">요청일 최신순 ↓</option><option value="requestedAt_asc">요청일 오래된순 ↑</option><option value="returnDelivered_asc">반품 도착일 오래된순 ↑</option><option value="returnDelivered_desc">반품 도착일 최신순 ↓</option><option value="customer_asc">고객명 오름차순 ↑</option><option value="orderId_asc">주문번호 오름차순 ↑</option></select></div>
 <div class="settings-actions return-pick-bar"><label class="checkline"><input type="checkbox" id="returnPickAll"> 표시된 행 전체 선택</label><button id="returnPickRun" class="return-primary" disabled>선택 회수접수 · 0건</button><span class="sub">체크한 반품·교환 건을 한 번에 이지어드민 회수접수 창에 넣습니다 (원송장 있는 행만).</span></div>
 <p id="returnSummary" class="return-summary" role="status"></p>
 <div class="return-table-wrap"><table id="returnTable"><thead><tr><th class="return-pick-col"></th><th><button data-return-sort="requestedAt">반품 요청일 ↕</button></th><th><button data-return-sort="orderId">주문번호 ↕</button></th><th><button data-return-sort="product">상품명 · 옵션 ↕</button></th><th><button data-return-sort="customer">고객명 ↕</button></th><th><button data-return-sort="reason">반품 사유 ↕</button></th><th><button data-return-sort="fee">반품 배송비 ↕</button></th><th>원송장 · 배달완료일</th><th><button data-return-sort="returnNo">반품송장 ↕</button> · <button data-return-sort="deliveryStatus">배송 상태 ↕</button></th><th><button data-return-sort="returnDelivered">반품 배달완료일 ↕</button></th></tr></thead><tbody id="returnRows"></tbody></table></div>
 <div id="returnEmpty" class="empty"></div>
 <p class="sub return-legend">반품송장 미조회는 정렬 방향과 관계없이 맨 아래에 표시합니다. 노랑 → 핑크 → 그린 → 블루 → 그레이 순으로 행 색상을 적용합니다. 판매자 사유는 굵은 행과 빨간 사유로, 배송중인 -3,000원은 파란 행과 굵은 빨간 글씨로 표시합니다. 조회만 하며 환불 승인·고객 메시지 발송은 실행하지 않습니다.</p>`;
 document.body.insertAdjacentHTML('beforeend',`<dialog id="returnSettingsDialog" class="ably-dialog">
 <div class="dialoghead"><h2>⚙ 반품/교환 설정</h2><button id="returnSettingsClose">닫기</button></div>
 <p>반품·교환 배송정보를 확인합니다. 교환 조회는 에이블리 설정의 계정을, 회수접수는 이지어드민 설정의 계정을 사용합니다.</p>
 <div id="returnLocalSettings" hidden><label>반품 파일 폴더<input id="returnFolder" readonly></label><button id="returnFolderPick">폴더 연결</button><label class="auto-toggle"><input type="checkbox" id="returnWatchEnabled"> 반품 엑셀 변경 자동 확인</label><p class="sub">에이블리 반품진행상황.xlsx의 변경을 확인하고 CJ·우체국 배송정보를 보완합니다.</p></div><label>실행 방법<select id="returnMode"><option value="manual">수동 · 버튼을 누를 때만</option><option value="daily">매일 자동 확인</option></select></label>
 <label>매일 실행 시각 (한국 시간)<input type="time" id="returnTime" value="09:00"></label>
 <p class="sub">앱이 실행 중일 때 하루 한 번 확인합니다. 설정 시각을 지난 뒤 앱을 켜면 오늘 실행하지 않은 경우 한 번 확인합니다. 오류가 난 날은 자동 재시도하지 않으며 ‘지금 조회’로 다시 실행할 수 있습니다.</p>
 <label class="auto-toggle"><input type="checkbox" id="pickupEnabled"> 자동 회수접수</label><div id="pickupSellers" class="pickup-sellers"><span class="sub">판매처별 자동 회수접수</span> <label><input type="checkbox" class="pickup-seller" data-seller="에이블리" checked> 에이블리</label> <label><input type="checkbox" class="pickup-seller" data-seller="자사몰" checked> 자사몰</label> <label><input type="checkbox" class="pickup-seller" data-seller="지그재그" checked> 지그재그</label></div><div class="settings-actions return-test-actions"><span class="sub">판매처별 반품 테스트 (조회만 · 저장·회수접수·수거완료 없음)</span> <button data-return-test="에이블리">에이블리 테스트</button><button data-return-test="자사몰">자사몰 테스트</button><button data-return-test="지그재그">지그재그 테스트</button></div><pre id="returnTestResult" class="sub prewrap" hidden></pre><p class="sub">회수 전/미접수·조회 확인 필요 건을 EX00에서 확인한 뒤 접수합니다. 접수 이력이 있는 원송장은 자동 반복하지 않습니다.</p><div class="settings-actions"><button id="returnSave" class="return-primary">설정 저장</button><button id="returnLoginSettings">로그인 설정 (⚙ 설정)</button><button id="returnSettingsRun">반품체크 · 지금 조회</button></div>
 <p id="returnSettingsStatus" role="status" class="sub"></p></dialog>`);
 const sortLabels={requestedAt:'요청일',returnDelivered:'반품 도착일',customer:'고객명',orderId:'주문번호',product:'상품명',reason:'반품 사유',fee:'배송비',returnNo:'반품송장',deliveryStatus:'배송 상태'};
 el('returnSort').innerHTML=Object.entries(sortLabels).flatMap(([k,v])=>[['asc','오름차순 ↑'],['desc','내림차순 ↓']].map(([dir,label])=>`<option value="${k}_${dir}">${v} ${label}</option>`)).join('');el('returnSort').value='requestedAt_desc';
 const returnNumber=r=>String(r.returnNo??'').trim();
 const deliveryStatus=r=>r.issue||((r.registered||r.returnStatus==='REGISTERED')?'회수 접수 완료 (접수전)':({arrived:'배달완료',transit:'배송중',undelivered:'회수 전 / 미접수'})[r.logistics])||'확인 필요';
 const blank=v=>v===null||v===undefined||String(v).trim()==='';
 function filtered(){
  const terms=el('returnSearch').value.normalize('NFKC').toLowerCase().split(/\s+/).filter(Boolean),extra=el('returnEmphasis').value;
  const rows=(category==='exchange'?(data.exchangeRows||[]):category?data.rows:[...data.rows,...(data.exchangeRows||[])]).filter(r=>(!sellerFilter||sellerOf(r)===sellerFilter)&&(!category||category==='exchange'||r.category===category)&&(!extra||(extra==='seller'?r.sellerReason:extra==='fee'?r.feeFlag:r.transitFee))&&terms.every(t=>[r.orderId,r.itemId,r.product,r.option,r.customer,r.invoice,r.returnNo].join(' ').normalize('NFKC').toLowerCase().includes(t)));
  return rows.sort((a,b)=>{
   // Missing return invoices stay at the bottom before applying any sort direction.
   const missingA=!returnNumber(a),missingB=!returnNumber(b);
   if(missingA!==missingB)return missingA?1:-1;
   const value=r=>sort==='deliveryStatus'?deliveryStatus(r):sort==='returnNo'?returnNumber(r):r[sort];
   const av=value(a),bv=value(b),emptyA=blank(av),emptyB=blank(bv);
   if(emptyA!==emptyB)return emptyA?1:-1;
   if(emptyA)return 0;
   return direction*(sort==='fee'?av-bv:orderCollator.compare(String(av),String(bv)));
  });
 }
 function render(){
  const c=data.counts||{};
  el('returnsCount').textContent=((c.total||0)+(c.exchange||0)).toLocaleString();el('returnsCounts').textContent=`도착 ${c.arrived||0}건 / 배송중 ${c.transit||0}건 / 미배송 ${c.undelivered||0}건 / 교환 ${c.exchange||0}건`;
  const hints=[];
  if(job.running)hints.push(job.canContinue?'로그인 확인 대기':'반품 조회 중');
  else if(['error','error_open'].includes(job.phase))hints.push('최근 조회 실패 · 기존 결과 유지');
  else if(data.lastChecked)hints.push('조회 '+dateTime(data.lastChecked));
  if(c.unknown)hints.push(`조회 확인 필요 ${c.unknown}건`);
  el('returnsWarning').textContent=hints.join(' · ');
  el('returnsCard').classList.toggle('is-active',view);el('returnsCard').setAttribute('aria-pressed',String(view));el('returnsCard').setAttribute('aria-expanded',String(view));
  if(view)document.querySelectorAll('.card[data-color]').forEach(e=>{e.classList.remove('is-active');e.setAttribute('aria-pressed','false');});
  el('returnStamp').textContent=(category==='exchange'&&data.exchangeChecked)?`교환 마지막 조회 ${dateTime(data.exchangeChecked)} · 교환 상품 ${(data.exchangeRows||[]).length}건`:data.lastChecked?`마지막 조회 ${dateTime(data.lastChecked)}${(data.cafe24?.enabled?' · 자사몰 '+(data.cafe24.error?'조회 실패: '+data.cafe24.error:Object.entries(data.cafe24.totals||{}).map(([k,v])=>k+' '+v+'건').join(' / ')):'')+(data.zigzag?.enabled?' · 지그재그 '+Object.entries(data.zigzag.totals||{}).map(([k,v])=>k+' '+v+'건').join(' / ')+(data.zigzag.error?' (조회 실패: '+data.zigzag.error+')':''):data.zigzag?.note?' · '+data.zigzag.note:'')}${data.source?' · '+(data.source==='에이블리 다운로드'?'에이블리에서 바로 다운로드':'폴더 파일 '+data.source):''} · 반품 접수 ${data.counts?.requests??data.rows.length}건 (에이블리 반품요청+검수대기 카드 기준) · 상품 ${data.rows.length}개${data.counts?.multiProductRequests?' · 상품 2개 이상 접수 '+data.counts.multiProductRequests+'건':''}`:(data.scopeChanged?'쇼핑몰이 바뀌었습니다. 새 마켓으로 반품체크를 실행하세요.':'아직 반품을 조회하지 않았습니다.');
  el('returnStatus').textContent=job.message||job.lastResult||'';el('returnStatus').classList.toggle('error',['error','error_open'].includes(job.phase));
  el('returnContinue').hidden=!job.canContinue;el('returnCancel').hidden=!job.running;
  el('exchangeRun').disabled=!!job.running;el('allRun').disabled=!!job.running;el('returnRun').disabled=!!job.running;el('returnSettingsRun').disabled=!!job.running;
  if(!view)return;
  const inSeller=r=>!sellerFilter||sellerOf(r)===sellerFilter,sRows=data.rows.filter(inSeller),sEx=(data.exchangeRows||[]).filter(inSeller);
  const counts=Object.fromEntries(Object.keys(labels).map(k=>[k,k==='exchange'?sEx.length:sRows.filter(r=>r.category===k).length]));
  el('returnSellers').innerHTML=SELLERS.map(([k,v])=>`<button data-return-seller="${k}" class="${sellerFilter===k?'on':''}" aria-pressed="${sellerFilter===k}">${v} <b>${(k?data.rows.filter(r=>sellerOf(r)===k):data.rows).length}</b>${k?` · 교환 ${(data.exchangeRows||[]).filter(r=>sellerOf(r)===k).length}`:''}</button>`).join('');
  el('returnTabs').innerHTML=[['','전체 반품/교환'],...Object.entries(labels)].map(([k,v])=>`<button class="return-tab return-${k||'all'} ${category===k?'is-active':''}" data-return-tab="${k}" aria-pressed="${category===k}"><span>${v}</span><b>${k?counts[k]:sRows.length+sEx.length}건</b></button>`).join('');
  if(typeof renderPickBar==='function')renderPickBar();
  el('returnDescription').textContent=descriptions[category]||'도착·배송중·미배송은 배송 상태 기준이며, 아래 색상은 먼저 확인할 사유를 나타냅니다. 택배사 조회 실패는 별도로 표시합니다.';
  el('returnTable').querySelectorAll('th').forEach(th=>th.removeAttribute('aria-sort'));
  el('returnTable').querySelectorAll('[data-return-sort]').forEach(b=>{
   const label=b.dataset.sortLabel||(b.dataset.sortLabel=b.textContent.replace(/\s*[↕↑↓]$/,''));
   const active=b.dataset.returnSort===sort;
   b.textContent=label+' '+(active?(direction===1?'↑':'↓'):'↕');
   if(active)b.closest('th').setAttribute('aria-sort',direction===1?'ascending':'descending');
  });
  const rows=filtered();el('returnSummary').textContent=`${labels[category]||'전체 반품/교환'} · ${rows.length}개 상품 / ${new Set(rows.map(r=>r.orderId)).size}개 주문`;
  const reshipCell=r=>r.kind!=='exchange'?'':r.reshipDone?`<b class="reship-badge">교환 발송완료</b><span class="secondary">${esc(r.reshipOrderId)} · ${esc(r.reshipCarrier||'택배사 미확인')} ${esc(r.reshipInvoice)} · ${esc(r.reshipStatus)}${r.reshipDelivery?' ('+esc(r.reshipDelivery)+')':''}</span>`:r.reshipError?`<span class="secondary reship-error">재발송 확인 실패</span>`:r.reshipChecked?`<span class="secondary">재발송 없음</span>`:'';
  for(const k of [...picked])if(!rows.some(r=>r.key===k))picked.delete(k);
  el('returnRows').innerHTML=rows.map(r=>`<tr class="return-${r.category}${r.sellerReason?' return-seller':''}${r.blueFee?' return-blue-fee':''}${r.reshipDone?' return-reship':''}"><td class="return-pick-col">${r.invoice?`<input type="checkbox" class="return-pick" data-pick-key="${esc(r.key)}" ${picked.has(r.key)?'checked':''} aria-label="회수접수 선택">`:''}</td><td>${esc(r.requestedAt)}${sellerOf(r)!=='에이블리'?'<span class="secondary return-seller-badge">'+esc(sellerOf(r))+(r.zigzagStatus?' · '+esc(r.zigzagStatus):'')+(r.cafe24Status?' · '+esc(r.cafe24Status):'')+'</span>':''}${r.requestedAtFull?'<span class="secondary">'+esc(r.requestedAtFull.slice(11,16))+'</span>':''}${r.zigzagAction?'<span class="secondary">'+esc(r.zigzagAction)+'</span>':''}${r.kind==='exchange'?'<span class="secondary">'+esc(r.exchangeStatus)+'</span>':''}<span class="secondary">${esc(r.label)}</span>${reshipCell(r)}${r.urgent&&r.category!=='urgent'?'<b class="return-reason">환불승인 시급</b>':''}</td><td>${esc(r.orderId)}<span class="secondary">${esc(r.itemId||'')}</span></td><td class="return-product">${esc(r.product)}<span class="secondary">${esc((r.option||'')+(r.exchangeOption?' → '+r.exchangeOption:''))}</span></td><td>${esc(r.customer)}</td><td class="return-reason">${esc(r.reason)}</td><td>${Number(r.fee).toLocaleString()}원</td><td>${esc(r.invoice||'번호 없음')}<span class="secondary">${esc(r.origDelivered||'완료일 미조회')}</span></td><td>${esc(returnNumber(r)||'반품송장 미조회')}<span class="secondary">${esc(({CJ:'CJ대한통운',EPOST:'우체국'})[r.carrier]||'택배사 미확인')} · ${esc(deliveryStatus(r))}</span>${r.feeFlag?'<span class="secondary">배송비 -3,000원</span>':''}</td><td>${esc(r.returnDelivered||'—')}<span class="secondary">${r.daysAfterReturn===null?'':esc(r.daysAfterReturn+'일 경과')}</span><button class="tiny pickup-row" data-pickup-key="${esc(r.key)}" ${r.invoice?'':'disabled'}>회수 · 이력</button>${r.kind==='exchange'?'':`<button class="tiny return-msg" data-msg-key="${esc(r.key)}" data-msg-kind="return_overdue" ${r.invoice?'':'disabled'} title="청약철회 기간 경과 · 반품 요청 철회 처리 안내 (문자)">기한 초과 문자${r.overdueNotice?' · '+esc(r.overdueNotice):''}</button>`}<button class="tiny return-msg" data-msg-key="${esc(r.key)}" data-msg-kind="return_not_defect" ${r.invoice?'':'disabled'} title="불량 사유 아님 · 귀책 사유 수정 요청 안내 (문자)">불량 아님 문자${r.notDefectNotice?' · '+esc(r.notDefectNotice):''}</button><button class="tiny return-msg" data-msg-key="${esc(r.key)}" data-msg-kind="return_manual" ${r.invoice?'':'disabled'} title="직접 작성한 문자를 이 ${r.kind==='exchange'?'교환':'반품'} 건 수취인에게 보냅니다">수동 메시지 작성${r.manualNotice?' · '+esc(r.manualNotice):''}</button>${(r.pickupHistory||[]).filter(h=>h.attempt).map(h=>'<span class="secondary">'+esc(h.attempt+'차 회수접수 · '+h.result)+'</span>').join('')}</td></tr>`).join('');
  el('returnEmpty').hidden=rows.length>0;el('returnEmpty').textContent=data.lastChecked?'이 조건에 해당하는 반품이 없습니다.':'반품체크를 실행하면 조회한 상품이 이곳에 표시됩니다.';
 }
 function show(value){view=value;document.body.classList.toggle('return-view',view);el('orderWorkspace').hidden=view;el('returnsPanel').hidden=!view;render();}
 async function call(action,settings=null){
  const bridge=window.pywebview?.api;if(!state?.desktopMode||!bridge?.return_action)throw Error('반품체크 실행과 설정은 새 버전 Mac 앱에서 사용할 수 있습니다.');
  const result=await bridge.return_action(token,action,settings,job.id||'');if(result.error)throw Error(result.error);return result;
 }
 window.returnsCall=call;
 function accept(s){job=s;if(s.data)data=s.data;render();renderTest();renderOnly();window.dispatchEvent(new CustomEvent('nuavu-auto-state'));}
 function renderOnly(){for(const b of document.querySelectorAll('[data-return-only]'))b.disabled=!!job.running;}
 document.addEventListener('click',async e=>{const b=e.target.closest&&e.target.closest('[data-return-only]');if(!b)return;
  show(true);category='';sellerFilter=b.dataset.returnOnly;
  try{accept(await call('seller:'+b.dataset.returnOnly));}catch(err){job={...job,message:err.message,phase:'error'};render();}});
 function renderTest(){
  const box=el('returnTestResult');if(!box)return;
  for(const b of document.querySelectorAll('[data-return-test]'))b.disabled=!!job.running;
  if(job.kind!=='test'){return;}
  box.hidden=false;box.textContent=(job.message||'')+(job.testRows&&job.testRows.length?'\n'+job.testRows.join('\n'):'');
  el('returnSettingsStatus').textContent=job.running?'테스트 진행 중 · '+(job.message||''):'';
  if(job.running)setTimeout(poll,1500);
 }
 document.addEventListener('click',async e=>{const b=e.target.closest&&e.target.closest('[data-return-test]');if(!b)return;
  el('returnTestResult').hidden=false;el('returnTestResult').textContent=b.dataset.returnTest+' 테스트를 시작합니다.';
  try{accept(await call('test:'+b.dataset.returnTest));}catch(err){el('returnTestResult').textContent=err.message;}});
 async function poll(){
  if(checking||window.factoryResetStarted||!state?.desktopMode||!window.pywebview?.api?.return_action)return;
  checking=true;try{accept(await call('status'));}catch(e){job={...job,message:e.message};render();}finally{checking=false;}
 }
 async function run(){
  show(true);el('returnRun').disabled=true;el('returnSettingsRun').disabled=true;
  try{accept(await call('start'));el('returnSettingsDialog').close();}catch(e){job={...job,message:e.message,phase:'error'};el('returnSettingsStatus').textContent=e.message;render();}
 }
 async function settings(){
  el('returnSettingsDialog').showModal();el('returnSave').disabled=true;el('returnSettingsStatus').textContent='설정을 확인합니다.';
  try{const s=await call('status');accept(s);el('returnLocalSettings').hidden=!s.settings.local;el('returnFolder').value=s.settings.folder||'';el('returnWatchEnabled').checked=!!s.settings.watchEnabled;{const ps=await window.pickupCall('status');el('pickupEnabled').checked=!!ps.settings.enabled;applyPickupSellers(ps);}el('returnMode').value=s.settings.mode;el('returnTime').value=s.settings.time;el('returnTime').disabled=s.settings.mode!=='daily';window.dispatchEvent(new CustomEvent('nuavu-auto-state'));el('returnSettingsStatus').textContent=s.message||'';el('returnSave').disabled=false;}catch(e){el('returnSettingsStatus').textContent=e.message;}
 }
 el('returnsCard').onclick=()=>{show(true);poll();};el('returnBack').onclick=()=>{show(false);renderOrder();};
 const renderOrder=()=>{window.dispatchEvent(new CustomEvent('nuavu-return-closed'));};
 document.querySelectorAll('.card[data-color],#failedBtn').forEach(b=>b.addEventListener('click',()=>show(false)));
 el('returnsSettingsBtn').onclick=settings;el('returnSettingsOpen').onclick=settings;el('returnSettingsClose').onclick=()=>el('returnSettingsDialog').close();
 el('returnLoginSettings').onclick=()=>{el('returnSettingsDialog').close();(window.openSettingsHub||openAblySettings)();};
 el('returnRun').onclick=run;el('returnSettingsRun').onclick=run;
 el('returnMode').onchange=()=>{el('returnTime').disabled=el('returnMode').value!=='daily';};
 el('returnSave').onclick=async()=>{el('returnSave').disabled=true;try{accept(await call('save',{mode:el('returnMode').value,time:el('returnTime').value,watchEnabled:el('returnWatchEnabled').checked,folder:el('returnFolder').value}));await window.pickupCall('save',{enabled:el('pickupEnabled').checked,sellers:pickupSellerValues()});el('returnSettingsStatus').textContent='반품/교환·회수 설정을 저장했습니다.';}catch(e){el('returnSettingsStatus').textContent=e.message;}finally{el('returnSave').disabled=false;}};
 for(const [id,action] of [['returnCancel','cancel'],['returnContinue','continue']])el(id).onclick=async()=>{try{accept(await call(action));}catch(e){job.message=e.message;render();}};
 el('exchangeRun').onclick=async()=>{show(true);category='exchange';try{accept(await call('exchange'));}catch(e){job.message=e.message;render();}};
 el('allRun').onclick=async()=>{show(true);category='';try{accept(await call('all'));}catch(e){job.message=e.message;render();}};
 el('pickupOpen').onclick=()=>window.openPickup();
 el('returnFolderPick').onclick=async()=>{try{const r=await window.pywebview.api.pick_return_folder(token);if(r?.error)throw Error(r.error);if(r){el('returnFolder').value=r.settings.folder;accept(r);}}catch(e){el('returnSettingsStatus').textContent=e.message;}};
 el('returnRows').onclick=e=>{const b=e.target.closest('[data-pickup-key]');if(b){const r=[...data.rows,...(data.exchangeRows||[])].find(r=>r.key===b.dataset.pickupKey);if(r)window.openPickup(r);return;}
  const m=e.target.closest('[data-msg-key]');if(m){const r=[...data.rows,...(data.exchangeRows||[])].find(r=>r.key===m.dataset.msgKey);if(r)openReturnMessage(r,m.dataset.msgKind);}};
 // 반품 안내 문자 (2026-10-19): 기한 초과 / 불량 아님 — SMS·LMS only, 수취인 연락처로. 18시 이후에는 문자 작성과 같이 즉시 / 오전 9시 예약.
 let msgTarget=null,msgRequestId='';
 if(!el('returnMsgDialog'))document.body.insertAdjacentHTML('beforeend',`<dialog id="returnMsgDialog"><div class="dialoghead"><div><p class="eyebrow">RETURN MESSAGE</p><h2 id="returnMsgTitle">반품 안내 문자</h2></div><button data-close="returnMsgDialog">닫기</button></div>
 <p id="returnMsgMeta" class="sub"></p><pre id="returnMsgContent" class="prewrap"></pre><div id="returnMsgEditWrap" hidden><textarea id="returnMsgEdit" rows="10" maxlength="900" placeholder="보낼 내용을 작성하세요"></textarea><p id="returnMsgCount" class="sub"></p></div><p id="returnMsgHint" class="sub"></p><p id="returnMsgStatus" role="status"></p>
 <div class="settings-actions"><button id="returnMsgSend" class="return-primary">문자 발송 요청</button><button id="returnMsgMorning" class="return-primary" hidden>오전 9시 예약 발송</button></div></dialog>`);
 el('returnMsgDialog').querySelector('[data-close]').onclick=()=>el('returnMsgDialog').close();
 async function openReturnMessage(r,kind){
  msgTarget={invoice:r.invoice,kind};msgRequestId=nuavuRequestId();
  const ex=r.kind==='exchange',word=ex?'교환':'반품',manual=kind==='return_manual';
  el('returnMsgTitle').textContent=kind==='return_overdue'?'반품 기한 초과 안내 문자':manual?word+' 수동 메시지 작성':word+' 불량 아님 안내 문자';
  el('returnMsgContent').hidden=manual;el('returnMsgEditWrap').hidden=!manual;el('returnMsgEdit').value='';el('returnMsgMeta').textContent='미리보기를 불러옵니다.';el('returnMsgContent').textContent='';el('returnMsgHint').textContent='';el('returnMsgStatus').textContent='';
  el('returnMsgSend').disabled=true;el('returnMsgMorning').hidden=true;el('returnMsgDialog').showModal();
  try{const pv=await api('return-message-preview',{invoice:r.invoice,kind});
   const phone=pv.phone?pv.phone.replace(/(\d{3})(\d{3,4})(\d{4})/,'$1-****-$3'):'(없음)';
   el('returnMsgMeta').textContent=`${pv.seller||''} · 주문 ${pv.orderId||'—'} · 원송장 ${pv.invoice} · 수신 ${phone}${pv.phoneOk?'':' · 연락처 확인 필요'} · ${pv.content.length}자`;
   el('returnMsgContent').textContent=pv.content;
   if(manual){el('returnMsgEdit').value=pv.content;countManual();setTimeout(()=>{const t=el('returnMsgEdit');t.focus();t.setSelectionRange(t.value.length,t.value.length);},50);}
   const w=state?.sendWindow,night=!!w?.nightChoices,st=pv.state||{},cur=kind==='return_overdue'?st.overdue:manual?'':st.notDefect;
   el('returnMsgHint').textContent=(cur?`이 반품 건에는 같은 안내가 이미 있습니다 (${cur}). 다시 보내면 중복 발송됩니다. `:'')+(night?`18시 이후입니다. 즉시 발송 또는 오전 9시(${dateTime(w.morningSendAt)}) 예약을 선택하세요.`:'요청하면 바로 문자 공급사에 전송하고 15초 뒤 결과를 확인합니다.')+(kind==='return_not_defect'&&!ex?' 발송 후 이 반품은 "반품 불량 아님 안내 완료" 카드로 이동합니다.':'')+(manual?` 작성한 내용 끝에 안내번호가 붙습니다.${st.manual?' (이 건에 보낸 수동 메시지 있음: '+st.manual+')':''}`:'');
   el('returnMsgSend').textContent=night?'즉시 발송':'문자 발송 요청';el('returnMsgMorning').hidden=!night;el('returnMsgSend').disabled=!pv.phoneOk;el('returnMsgMorning').disabled=!pv.phoneOk;
  }catch(e){el('returnMsgMeta').textContent='';el('returnMsgStatus').textContent=e.message;}
 }
 async function sendReturnMessage(sendMode,button){
  if(!msgTarget)return;const other=button===el('returnMsgSend')?el('returnMsgMorning'):el('returnMsgSend');button.disabled=true;other.disabled=true;el('returnMsgStatus').textContent='문자 발송을 요청합니다.';
  try{const body={...msgTarget,sendMode,requestId:msgRequestId};if(msgTarget.kind==='return_manual')body.content=el('returnMsgEdit').value;
   const r=await api('return-message-send',body);el('returnMsgDialog').close();toast(r.message);if(typeof refresh==='function')refresh();}
  catch(e){el('returnMsgStatus').textContent=e.message;button.disabled=false;other.disabled=false;}
 }
 function countManual(){const v=el('returnMsgEdit').value;el('returnMsgCount').textContent=`${v.length}/900자 · ${v.trim()?'':'내용을 작성하세요 · '}발송할 때 문자 길이에 따라 단문/장문으로 보냅니다.`;}
 el('returnMsgEdit').addEventListener('input',()=>{countManual();msgRequestId=nuavuRequestId();});
 el('returnMsgSend').onclick=()=>sendReturnMessage(state?.sendWindow?.nightChoices?'IMMEDIATE':'AUTO',el('returnMsgSend'));
 el('returnMsgMorning').onclick=()=>sendReturnMessage('MORNING',el('returnMsgMorning'));
 el('returnTabs').onclick=e=>{const b=e.target.closest('[data-return-tab]');if(b){category=b.dataset.returnTab;render();}};
 el('returnSellers').onclick=e=>{const b=e.target.closest('[data-return-seller]');if(b){sellerFilter=b.dataset.returnSeller;render();}};
 function pickedRows(){return [...data.rows,...(data.exchangeRows||[])].filter(r=>picked.has(r.key)&&r.invoice);}
 function renderPickBar(){const n=pickedRows().length;el('returnPickRun').disabled=!n;el('returnPickRun').textContent=`선택 회수접수 · ${n}건`;}
 el('returnRows').addEventListener('change',e=>{const c=e.target.closest('.return-pick');if(!c)return;if(c.checked)picked.add(c.dataset.pickKey);else picked.delete(c.dataset.pickKey);renderPickBar();});
 el('returnPickAll').onchange=()=>{const on=el('returnPickAll').checked;for(const c of el('returnRows').querySelectorAll('.return-pick')){c.checked=on;if(on)picked.add(c.dataset.pickKey);else picked.delete(c.dataset.pickKey);}renderPickBar();};
 el('returnPickRun').onclick=()=>{const rows=pickedRows();if(!rows.length)return;if(!window.openPickupMany)return alert('회수접수는 설치한 맥 앱에서 사용할 수 있습니다.');window.openPickupMany(rows);};
 el('returnSearch').oninput=render;el('returnEmphasis').onchange=render;
 el('returnSort').onchange=()=>{const bits=el('returnSort').value.split('_');sort=bits[0];direction=bits[1]==='asc'?1:-1;render();};
 el('returnTable').querySelectorAll('[data-return-sort]').forEach(b=>b.onclick=()=>{const k=b.dataset.returnSort;direction=sort===k?-direction:1;sort=k;el('returnSort').value=sort+(direction===1?'_asc':'_desc');render();});
 window.addEventListener('nuavu-state',()=>{const next=state?.returns;if(next){const sig=JSON.stringify(next);if(sig!==signature){signature=sig;data=next;}}render();});
 window.addEventListener('nuavu-return-closed',()=>window.setTimeout(()=>window.dispatchEvent(new CustomEvent('nuavu-state')),0));
 if(state?.returns)data=state.returns;render();let pollTick=0;setInterval(()=>{pollTick++;const hot=job?.running||job?.phase==='running'||view||el('returnSettingsDialog').open;if(hot||pollTick%6===0)poll();},2500);   // 09:05 CPU 최적화
})();
