'use strict';
// 2026-10-28 'CPU 최소한으로': 다른 앱을 보고 있거나 창이 가려지면 반짝임·깜빡임 애니메이션을 멈춘다 (창을 보고 있을 때는 그대로).
(()=>{
 const root=document.documentElement;
 const set=()=>{let idle=document.hidden;try{idle=idle||!document.hasFocus();}catch(e){}root.classList.toggle('nuavu-idle',!!idle);};
 document.addEventListener('visibilitychange',set);window.addEventListener('blur',set);window.addEventListener('focus',set);
 window.addEventListener('pointerdown',set,true);set();
})();
