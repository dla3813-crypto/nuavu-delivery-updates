"""Durable local order/notice workflow. Standard library only; no live sends in tests."""
from __future__ import annotations
import base64
import csv
import hashlib
import io
import json
import os
import re
import secrets
import sqlite3
import threading
import time
import unicodedata
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from provider import Credential, AligoSMS, ProviderError, UncertainError, report_status, safe_text
from credentials import default_vault, VaultError
from branding import ShopWorkflow, canonical_template, render_template, clean_name, safe_outgoing, message_title, normalize_seller, import_seller, seller_choices, selected_seller_labels, row_in_seller_scope
from aligo_workflow import AligoWorkflow
from return_messages import ReturnMessageMixin,RETURN_NOTICE_TYPES
from supply_workflow import SupplyWorkflow
from external_notices import ExternalWorkflow
from order_items import ABLY,AMOOD,ItemIdError,items_of,set_items,combine_items
from history_seed import is_external, notice_sort_key, effective_notice_key

APP_VERSION='0.6.99'
KST=timezone(timedelta(hours=9)); SELLERS=['누아브 에이블리','누아브 자사몰','누아브 지그재그','누아브 아무드']   # 2026-10-21 01:29: 아무드 추가 (기존 인덱스 유지; 화면 탭 순서는 에이블리·아무드·자사몰·지그재그)
PENDING={'QUEUED','SCHEDULED','PAUSED','SENDING','PENDING','UNKNOWN'}
FINISHED={'DELIVERED','FAILED','CANCELLED'}
LEGACY_FIRST='안녕하세요, 누아브입니다.\n\n주문하신 상품의 입고가 지연되어 안내드립니다.\n\n상품: {상품목록}\n출고 예정일: {출고예정일}\n\n기다리게 해드려 정말 죄송합니다. 입고되는 대로 꼼꼼히 검수하여 빠르게 출고하겠습니다.\n\n기다려주셔서 감사합니다.'
LEGACY_CHANGE='안녕하세요, 누아브입니다.\n\n고객님께 앞서 안내드린 출고 일정이 변경되어 다시 안내드립니다.\n\n상품: {상품목록}\n변경된 출고 예정일: {출고예정일}\n\n안내드린 일정을 지키지 못해 정말 죄송합니다. 입고되는 대로 우선적으로 검수하여 빠르게 출고하겠습니다.\n\n기다려주셔서 감사합니다.'
FIRST='안녕하세요. 고객님\n{쇼핑몰명}입니다.\n\n주문하신 상품의 입고가 지연되어 안내드립니다.\n\n상품: {상품목록}\n출고 예정일: {출고예정일}\n\n기다리게 해드려 정말 죄송합니다.\n입고되는 대로 꼼꼼히 검수하여 빠르게 출고하겠습니다.\n\n기다려주셔서 감사합니다.'
CHANGE='안녕하세요. 고객님\n{쇼핑몰명}입니다.\n\n고객님께 앞서 안내드린 출고 일정이 변경되어 다시 안내드립니다.\n\n상품: {상품목록}\n변경된 출고 예정일: {출고예정일}\n\n거래처 입고지연으로 인해\n안내드린 일정을 지키지 못해 정말 죄송합니다.\n입고되는 대로 우선적으로 검수하여 빠르게 출고하겠습니다.\n\n기다려주셔서 감사합니다.'
SOLDOUT_CARD='안녕하세요. 고객님\n{쇼핑몰명}입니다.\n\n먼저 불편을 드려 진심으로 죄송합니다.\n\n주문해주신 “{상품목록}” 상품이 원거래처 품절로 확인되어\n추가 확보가 어려운 상황입니다.\n\n다른 거래처를 통해 재고를 확인해 보았으나,\n현재로서는 발송이 불가하여 부득이하게 품절 취소 처리를 도와드리게 되었습니다.\n\n기대해주신 만큼 만족을 드리지 못해 정말 죄송하며,\n결제하신 금액은 취소 처리 후 순차적으로 환불될 예정입니다.\n\n다시 한 번 불편을 드린 점 진심으로 사과드립니다.\n\n감사합니다.'
SOLDOUT_BANK='안녕하세요. 고객님\n{쇼핑몰명}입니다.\n\n먼저 불편을 드려 진심으로 죄송합니다.\n\n주문해주신 “{상품목록}” 상품이 원거래처 품절로 확인되어\n추가 확보가 어려운 상황입니다.\n\n다른 거래처를 통해 재고를 확인해 보았으나,\n현재로서는 발송이 불가하여 부득이하게 품절 취소 처리를 도와드리게 되었습니다.\n\n기대해주신 만큼 만족을 드리지 못해 정말 죄송하며,\n결제하신 금액은 계좌로 환불처리 예정으로, 환불받으실\n은행/계좌번호/예금주명 회신 부탁드립니다.\n\n다시 한 번 불편을 드린 점 진심으로 사과드립니다.\n\n감사합니다.\n{자사몰링크}'
# Delivery reports are not read receipts. Missing reports stay unresolved even
# when the UI places them in its attention/failure bucket.
REPORT_DELAY=timedelta(seconds=15)
REPORT_DEADLINE=timedelta(minutes=1)
REPORT_LATE_INTERVAL=timedelta(hours=12)
# 2026-10-24: 1분 뒤에도 미확인이면 접수 기준 10분·30분·1시간·3시간·6시간에 다시 조회하고, 그 뒤로만 12시간 간격.
# (알리고는 1분 안에 처리 중(Q…)으로 남았다가 몇 분 뒤 성공이 되는 경우가 있음 — 10/24 09:00 건: 알리고 성공인데 앱은 21시까지 미확인)
REPORT_LATE_STEPS=(timedelta(minutes=10),timedelta(minutes=30),timedelta(hours=1),timedelta(hours=3),timedelta(hours=6))
REPORT_POLICY='15s-1m-v1'
RESULT_WATCH='WATCH_15S'
RESULT_TIMEOUT='UNCONFIRMED_1M'
LEGACY_RESULT_WATCH='WATCH_12H'
LEGACY_RESULT_TIMEOUT='UNCONFIRMED_25H'
WORKER_REPORT_INTERVAL=1.0
WORKER_IDLE_SECONDS=2.0   # 09:05: idle rescan interval (a 09:00 reservation starts within 2초)
WORKER_BACKUP_INTERVAL=60.0
SEND_MODES={'AUTO','IMMEDIATE','MORNING'}
NOTICE_TYPES={'delay','soldout_card','soldout_bank','manual'}  # 반품 안내(return_*)는 return_messages 경로로만 생성
TEMPLATE_KEYS=('first','change','soldout_card','soldout_bank','manual')

def is_soldout(n):
    return n.get('noticeType','delay') in {'soldout_card','soldout_bank'}

BLOCKING={'QUEUED','SCHEDULED','PAUSED','SENDING','UNKNOWN'}
class ValidationError(Exception): pass

def now(): return datetime.now(timezone.utc).isoformat(timespec='milliseconds')
def today(): return datetime.now(KST).date().isoformat()

def _phone_offer(alert):
    """2026-10-23 아이폰 알림: 앱 알림이 저장되는 두 함수(add_alert·add_job_alert)가 저장 직후 이것 하나만 부른다.
    문제 등급인지·중복·시간당 20통·발송은 phone_alert 가 백그라운드에서 판단한다. 절대 예외를 내지 않는다."""
    try:
        import phone_alert;phone_alert.offer(alert)
    except Exception:pass

def _zz_row_window(s,row,t):
    from zigzag_rules import row_window
    try:return row_window(s,row,t)
    except Exception:return None
def parse_time(value):
    """ISO timestamps and common unambiguous provider date representations."""
    value=str(value or '').strip()
    if not value:return None
    try:
        dt=datetime.fromisoformat(value.replace('Z','+00:00'))
    except ValueError:
        dt=None
        for fmt in ('%Y%m%d%H%M%S','%Y-%m-%d %H:%M:%S','%Y/%m/%d %H:%M:%S','%Y.%m.%d %H:%M:%S'):
            try:dt=datetime.strptime(value,fmt);break
            except ValueError:pass
        if dt is None:return None
    return dt.replace(tzinfo=KST) if dt.tzinfo is None else dt

def customer_send_time(clock=None):
    """Customer sends are permitted 09:00 <= KST time < 18:00, every calendar day.

    Return the earliest permitted instant, not a provider-side reservation.
    Pass an aware clock in tests; production always uses the local server clock.
    """
    clock=clock or datetime.now(timezone.utc)
    if clock.tzinfo is None:raise ValueError('Timezone-aware clock required')
    local=clock.astimezone(KST)
    if local.hour>=18:
        return (local+timedelta(days=1)).replace(hour=9,minute=0,second=0,microsecond=0)
    if local.hour<9:return local.replace(hour=9,minute=0,second=0,microsecond=0)
    return local

def morning_send_time(clock=None):
    """Next calendar 09:00 KST. Before 09:00 use today; otherwise tomorrow."""
    clock=clock or datetime.now(timezone.utc)
    if clock.tzinfo is None:raise ValueError('Timezone-aware clock required')
    local=clock.astimezone(KST)
    target=local.replace(hour=9,minute=0,second=0,microsecond=0)
    return target if local<target else target+timedelta(days=1)

def selected_send_time(mode, clock=None):
    clock=clock or datetime.now(timezone.utc)
    if mode not in SEND_MODES:raise ValidationError('발송 방식은 즉시전송 또는 오전 9시 전송으로 선택하세요.')
    if mode=='IMMEDIATE':return clock.astimezone(KST)
    return morning_send_time(clock) if mode=='MORNING' else customer_send_time(clock)

def dispatch_target(n,clock):
    """Keep the original choice across shutdown, queue waits and recovery.

    Legacy reservations (no explicit mode) retain their previous daytime rule.
    A morning reservation that is missed at night is NOT silently sent at night.
    Only a saved, explicit IMMEDIATE choice bypasses the night rule.
    """
    mode=n.get('sendMode','AUTO')
    if mode not in SEND_MODES:raise ValidationError('저장된 발송 방식을 읽지 못했습니다.')
    target=clock if n.get('isTest') or mode=='IMMEDIATE' else customer_send_time(clock)
    reserved=parse_time(n.get('scheduledAt'))
    if n.get('scheduledAt') and not reserved:raise ValidationError('예약 시각을 읽을 수 없습니다.')
    if reserved and reserved>target:
        target=reserved if mode=='IMMEDIATE' else customer_send_time(reserved)
    return target

def send_window(clock=None,mode='AUTO'):
    clock=clock or datetime.now(timezone.utc)
    target=selected_send_time(mode,clock)
    morning=morning_send_time(clock)
    local=clock.astimezone(KST)
    return {'serverNow':clock.isoformat(timespec='milliseconds'),
            'scheduled':target>clock,'sendAt':target.isoformat(timespec='milliseconds'),
            'minDueDate':target.date().isoformat(),
            'sameDay':target.date()==local.date(),
            'nightChoices':local.hour>=18 or local.hour<9,
            'immediateMinDueDate':local.date().isoformat(),
            'morningSendAt':morning.isoformat(timespec='milliseconds'),
            'morningMinDueDate':morning.date().isoformat(),
            'morningSameDay':morning.date()==local.date()}

def result_deadline(n):
    base=parse_time(n.get('acceptedAt') or n.get('attemptedAt'))
    return base+REPORT_DEADLINE if base else None

def result_timeout(n):
    # A workflow failure bucket, not a fabricated carrier-delivery failure.
    return n['status'] in {'PENDING','UNKNOWN'} and n.get('resultReview') in {RESULT_TIMEOUT,LEGACY_RESULT_TIMEOUT}

def display_status(n):
    if n.get('fallbackSmsOk') and n.get('status')=='FAILED':return 'FALLBACK_SMS'   # 알림톡 불가 → 문자로 안내 완료 (정상)
    if result_timeout(n):return RESULT_TIMEOUT
    if n['status'] in {'PENDING','UNKNOWN'} and n.get('resultReview') in {RESULT_WATCH,LEGACY_RESULT_WATCH}:return RESULT_WATCH
    return n['status']

def fallback_sms_ok(n,by_id):
    """2026-10-21: 알림톡 실패 확정이지만 같은 안내를 알리고 문자로 대체 접수/수신 → 정상 안내로 본다."""
    if n.get('kind')!='AT' or not n.get('fallbackId'):return False
    if n.get('status')!='FAILED' and not (n.get('fallbackDecision')=='MANUAL' and n.get('status')!='DELIVERED'):return False
    c=by_id.get(n['fallbackId']);return bool(c and c.get('fallbackOf')==n['id'] and c.get('status') in {'PENDING','DELIVERED'})

def report_due(n):
    base=parse_time(n.get('acceptedAt') or n.get('attemptedAt'))
    next_at=parse_time(n.get('nextCheckAt'))
    first=base+REPORT_DELAY if base else None
    return max(first,next_at) if first and next_at else (next_at or first)

def schedule_check(n):
    n['resultPolicyVersion']=REPORT_POLICY
    deadline=result_deadline(n)
    if deadline:n['resultDeadlineAt']=deadline.isoformat(timespec='milliseconds')
    due=report_due(n)
    if due:n['nextCheckAt']=due.isoformat(timespec='milliseconds')

def defer_check(n, checked):
    baseline=parse_time(n.get('acceptedAt') or n.get('attemptedAt'))
    if baseline is None:
        n['nextCheckAt']=(checked+REPORT_LATE_INTERVAL).isoformat(timespec='milliseconds')
        return
    first=baseline+REPORT_DELAY
    deadline=baseline+REPORT_DEADLINE
    # Second check is at acceptance + 60s, NOT first lookup + 60s.
    # Do not turn the 15-second initial delay into an endless API poll loop.
    target=first if checked<first else (deadline if checked<deadline else late_check_target(baseline,checked))
    n['nextCheckAt']=target.isoformat(timespec='milliseconds')

def late_check_target(baseline,checked):
    """1분 이후 재조회 시각: 접수 기준 10분·30분·1시간·3시간·6시간 중 아직 안 지난 첫 시각, 다 지났으면 12시간 뒤."""
    for step in REPORT_LATE_STEPS:
        if checked<baseline+step:return baseline+step
    return checked+REPORT_LATE_INTERVAL

def pull_in_late_check(n,clock):
    """2026-10-24 업데이트: 예전 규칙으로 12시간 뒤에 잡힌 미확인 결과 조회를 새 간격으로 당긴다 (조회만, 재발송 없음).
    여러 번 실행해도 같은 결과(이미 당겨진 건은 그대로)."""
    if n.get('kind') not in {'AT','SMS','LMS'} or n.get('status') not in {'PENDING','UNKNOWN'}:return False
    baseline=parse_time(n.get('acceptedAt') or n.get('attemptedAt'));nxt=parse_time(n.get('nextCheckAt'))
    if baseline is None or nxt is None or nxt<=baseline+REPORT_DEADLINE:return False
    last=parse_time(n.get('reportCheckedAt')) or clock
    target=late_check_target(baseline,max(last,baseline+REPORT_DEADLINE))
    if target>=nxt:return False
    n['nextCheckAt']=target.isoformat(timespec='milliseconds');return True


def migrate_report_policy(s,n,clock):
    """Re-time unresolved work once, without assigning a delivery result.

    All previous checks remain in the migration audit. Terminal states and
    unsent/reserved messages are untouched. Overdue legacy work is re-queried
    before this version decides its classification. Same-version restarts do
    not reset the clock or repeatedly poll an unresolved result.
    """
    if n.get('resultPolicyVersion')==REPORT_POLICY:return
    if n.get('kind') not in {'AT','SMS','LMS'} or n['status'] not in {'PENDING','UNKNOWN','SENDING'}:return
    baseline=parse_time(n.get('acceptedAt') or n.get('attemptedAt'))
    if baseline is None:return
    previous={k:n.get(k) for k in ('resultPolicyVersion','resultReview','resultDeadlineAt','nextCheckAt','watchSince','timeoutAt')}
    n.setdefault('resultPolicyHistory',[]).append({'at':clock.isoformat(timespec='milliseconds'),'previous':previous})
    n['resultPolicyVersion']=REPORT_POLICY
    n['resultDeadlineAt']=(baseline+REPORT_DEADLINE).isoformat(timespec='milliseconds')
    n['nextCheckAt']=max(baseline+REPORT_DELAY,clock).isoformat(timespec='milliseconds')
    n['resultReview']=''
    n.pop('watchSince',None);n.pop('timeoutAt',None)
    n['note']='조회 주기 변경: 접수 15초·1분 기준으로 기존 전송 결과만 우선 재조회합니다. 재발송하지 않습니다.'
    n.setdefault('events',[]).append({'at':clock.isoformat(timespec='milliseconds'),'status':n['status'],'note':n['note']})
    for a in s.get('alerts',[]):
        if a.get('noticeId')==n['id'] and a.get('code') in {'RESULT_UNCONFIRMED','RESULT_UNCONFIRMED_12H','RESULT_UNCONFIRMED_25H','RESULT_UNCONFIRMED_3M','RESULT_UNCONFIRMED_1M','RESULT_UNCONFIRMED_10S','RESULT_UNCONFIRMED_15S'} and not a.get('resolvedAt'):
            a['resolvedAt']=clock.isoformat(timespec='milliseconds')
            a['resolution']='조회 주기 변경으로 보관. 새 전송내역을 조회한 뒤 다시 분류합니다.'

def pending_applied(n):
    """2026-10-19 (공통): a queued/scheduled/paused/sending delay message already names the new 출고 예정일. The row
    shows that date right away (so it leaves 재발송 필요 lists); a failed or cancelled send drops out of this set and the
    previously announced date returns by itself. Sold-out and freeform (manual) messages never pre-apply."""
    return (n.get('noticeType')!='manual' and not is_soldout(n) and not is_external(n)
            and n['status'] in {'QUEUED','SCHEDULED','PAUSED','SENDING'} and bool(n.get('dueDate')))

def applied_notice(n):
    # Business acknowledgement is not carrier-confirmed delivery.
    # Freeform text stays in the send ledger without becoming a shipping acknowledgement.
    return n.get('noticeType')!='manual' and (n['status'] in {'PENDING','DELIVERED'} or is_external(n))


def awaiting_reservation(n):
    """A live local reservation, including pauses and its dispatch hand-off.

    A saved scheduledAt alone does not mean it is still waiting: keep cancelled,
    accepted, failed, and outcome-unknown requests out of the reservation bucket.
    The latter must only be queried, never silently returned to a send queue.
    """
    return n['status']=='SCHEDULED' or bool(
        n.get('scheduledAt') and n['status'] in {'PAUSED','QUEUED','SENDING'})


def clean(v): return unicodedata.normalize('NFC',str(v or '')).strip()
def phone(v):
    p=clean(v)
    if p.startswith('+82'): p='0'+p[3:]
    return re.sub(r'\D','',p)
def valid_phone(v): return bool(re.fullmatch(r'01[016789]\d{7,8}',v))
def jskey(a): return json.dumps(a,ensure_ascii=False,separators=(',',':'))
def rowkey(r): return jskey([r['seller'],r['orderId'],r['product'],r['option']])
def fingerprint(v): return hashlib.sha256(jskey(v).encode()).hexdigest()
def notice_ref(): return 'N'+base64.b32encode(secrets.token_bytes(8)).decode().rstrip('=')
def bytecount(text):
    try: return len(text.encode('cp949'))
    except UnicodeEncodeError as exc: raise ValidationError('문자에서 지원되지 않는 이모지·특수문자가 있습니다. 미리보기 내용을 수정하세요.') from exc

def initial_state():
    return {'schema':2,'edition':'aligo-distribution','appVersion':APP_VERSION,'revision':0,'rows':[],'notices':[],'imports':[],'audits':[],
            'settings':{'shopName':'','shopRevision':0,'tableZoom':100,'smsProvider':'ALIGO','smsUser':'','lmsUser':'','sender':'','scheme':'https','configRevision':0,'template':FIRST,'templateType':'delay','defaultTemplate':'first','smsTemplates':{}},
            'alerts':[],'tests':{},'queuePaused':False,'pollNote':'','lastPoll':None}

def ensure_composer_preferences(settings):
    """Starting template is an explicit preference, never the last sent type.

    Preserve custom SMS text per kind, separately from the new default choice.
    An existing legacy sold-out draft must not turn into the initial delay body.
    """
    if settings.get('defaultTemplate') not in TEMPLATE_KEYS:
        settings['defaultTemplate']='first'
    if not isinstance(settings.get('smsTemplates'),dict):
        settings['smsTemplates']={}
        legacy=settings.get('template')
        kind=settings.get('templateType','delay')
        key=kind if kind in {'soldout_card','soldout_bank'} else ('change' if legacy==CHANGE else 'first')
        if isinstance(legacy,str) and legacy.strip():settings['smsTemplates'][key]=legacy
    settings['smsTemplates']={k:v for k,v in settings['smsTemplates'].items()
        if k in TEMPLATE_KEYS and isinstance(v,str) and v.strip()}


CAFE24_SELLER='누아브 자사몰'
RESERVED_STATES={'SCHEDULED','QUEUED','PAUSED'}
APP_CANCEL_DONE={'자사몰 취소 완료','자사몰 이미 취소됨','에이블리 취소 완료','지그재그 취소 완료'}
SELLER_PLATFORM={'누아브 자사몰':'cafe24','누아브 지그재그':'zigzag','누아브 에이블리':'ably'}
def app_cancelled_index(s):
    """품절 주문취소 이력에서 앱이 실제로 취소 완료한 주문: ('cafe24'|'zigzag', 주문번호) · ('ably', 상품주문번호)."""
    out=set()
    for x in s.get('soldoutCancelLog',[]):
        if x.get('test') or x.get('result') not in APP_CANCEL_DONE:continue
        if x.get('platform')=='ably':out.add(('ably',str(x.get('sno',''))))
        elif x.get('platform')=='cafe24':out.add(('cafe24',cafe24_base(x.get('orderId',''))))
        else:out.add((str(x.get('platform','')),str(x.get('orderId',''))))
    return frozenset(out)
def cafe24_base(value):
    m=re.search(r'\d{8}-\d{7}',str(value or ''));return m.group(0) if m else str(value or '').strip()
def app_cancelled(r,idx):
    plat=SELLER_PLATFORM.get(r.get('seller'))
    if plat=='ably':
        ids=[str(p.get('id')) for p in (r.get('orderItems') or []) if p.get('id')] or ([str(r['orderItemId'])] if r.get('orderItemId') else [])
        return bool(ids) and any(('ably',i) in idx for i in ids)
    if plat=='cafe24':return any(('cafe24',cafe24_base(v)) in idx for v in (r.get('orderId'),r.get('orderItemId')) if v)
    return bool(plat) and (plat,str(r.get('orderId',''))) in idx
def refund_hold(r,ns,idx=frozenset()):
    """2026-10-22 02:15: 자사몰 주문에 '품절안내 (자사몰/무통장)'(환불 계좌 요청) 문자를 보냈으면
    주문 엑셀에서 빠져도 목록에 남긴다 — 사장님이 '환불완료'를 누를 때까지.
    아직 예약/대기 중인 문자는 앱이 그 자사몰 주문을 이미 취소 접수한 경우에만 남긴다."""
    if r.get('seller')!=CAFE24_SELLER or r.get('refundDoneAt'):return False
    for n in ns:
        if n.get('noticeType')!='soldout_bank' or n.get('isTest') or n.get('status') in {'CANCELLED','FAILED'}:continue
        if n.get('status') not in RESERVED_STATES or app_cancelled(r,idx):return True
    return False
def send_hold(r,ns,idx=frozenset()):
    """2026-10-22 02:35: 앱이 품절로 주문을 취소했는데(08:50) 품절 안내 문자는 아직 예약/대기(09:00)이면,
    주문 엑셀(예: 08:55 자동)에서 빠져도 행과 예약 문자를 유지해 문자가 나가게 한다. 문자가 나간 뒤에는 다음 엑셀에서 평소처럼 빠진다.
    앱이 취소하지 않았는데 빠진 주문(고객 직접 취소 등)은 예전처럼 예약 문자를 취소한다."""
    if not app_cancelled(r,idx):return False
    return any(is_soldout(n) and not n.get('isTest') and n.get('status') in RESERVED_STATES|{'SENDING'} for n in ns)
def hold_keys(s):
    """(환불 대기 keys, 문자 발송 대기 keys)"""
    by={};idx=app_cancelled_index(s)
    for n in s.get('notices',[]):
        if is_soldout(n):
            for k in n.get('itemKeys',[]):by.setdefault(k,[]).append(n)
    refund={r['key'] for r in s['rows'] if r['key'] in by and refund_hold(r,by[r['key']],idx)}
    send={r['key'] for r in s['rows'] if r['key'] in by and send_hold(r,by[r['key']],idx)}
    return refund,send
def refund_hold_keys(s):return hold_keys(s)[0]

def purge_inactive_soldout_rows(s,scope=None,eligible_keys=None):
    """Remove sold-out item records, NOT delivery ledger entries.

    Only rows already excluded by a confirmed full snapshot can be removed.
    Ledgers retain provider identities for late reports, duplicate prevention,
    and batch history. An in-flight send is never touched here.
    """
    latest={}
    for n in sorted(s.get('notices',[]),key=notice_sort_key):
        if n.get('isTest') or n.get('noticeType')=='manual':continue
        for key in n.get('itemKeys',[]):latest[key]=n
    keys={r['key'] for r in s['rows'] if not r.get('active',True)
        and (scope is None or r['seller'] in scope)
        and (eligible_keys is None or r['key'] in eligible_keys)
        and is_soldout(latest.get(r['key'],{}))}
    if keys:
        s['rows']=[r for r in s['rows'] if r['key'] not in keys]
        s.setdefault('audits',[]).append({'at':now(),'event':'전체 목록에서 빠진 품절 상품 레코드 삭제 (전송 이력 유지)',
            'removedItems':len(keys)})
    return len(keys)


class Store:
    def __init__(self, directory):
        self.directory=Path(directory); self.directory.mkdir(parents=True,exist_ok=True,mode=0o700)
        try: os.chmod(self.directory,0o700)
        except OSError: pass
        self.path=self.directory/'nuavu.sqlite3';self.lock=threading.RLock()
        self.db=sqlite3.connect(self.path,check_same_thread=False)
        self.db.execute('PRAGMA journal_mode=WAL');self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('CREATE TABLE IF NOT EXISTS app_state(id INTEGER PRIMARY KEY CHECK(id=1),body TEXT NOT NULL)')
        self.db.execute('INSERT OR IGNORE INTO app_state VALUES(1,?)',(jskey(initial_state()),));self.db.commit()
        os.chmod(self.path,0o600)
        if self.read().get('schema')!=2: raise ValidationError('지원되지 않는 저장 형식입니다. 기존 파일을 보존하세요.')
        if self.read().get('edition')!='aligo-distribution':
            self.db.close()
            raise ValidationError('기존 전용판 DB는 배포판에서 열지 않습니다. 배송안내 배포판의 별도 데이터 경로를 사용하세요.')
        self.backup()
        if self.read().get('appVersion')!=APP_VERSION:
            out=self.directory/'backups'/('before-v'+APP_VERSION+'-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.sqlite3')
            with self.lock:
                target=sqlite3.connect(out)
                try:self.db.backup(target)
                finally:target.close()
            os.chmod(out,0o600)

    @property
    def version(self):
        v=getattr(self,'_version',None)
        if v is None:
            with self.lock:v=self._version=int(self.read().get('revision',0))
        return v
    def read(self):
        with self.lock: return json.loads(self.db.execute('SELECT body FROM app_state WHERE id=1').fetchone()[0])
    @contextmanager
    def edit(self):
        with self.lock:
            s=self.read()
            yield s
            s['revision']+=1
            with self.db: self.db.execute('UPDATE app_state SET body=? WHERE id=1',(jskey(s),))
            self._version=s['revision']   # in-memory mirror of the saved revision (09:05 CPU 최적화: 읽지 않고 변경 여부 확인)
    def backup(self):
        folder=self.directory/'backups';folder.mkdir(exist_ok=True,mode=0o700)
        out=folder/(today()+'.sqlite3')
        if not out.exists():
            with self.lock:
                target=sqlite3.connect(out)
                try: self.db.backup(target)
                finally: target.close()
            os.chmod(out,0o600)
        for p in sorted(p for p in folder.glob('*.sqlite3') if re.fullmatch(r'\d{4}-\d{2}-\d{2}\.sqlite3',p.name))[:-14]: p.unlink()
    def close(self):
        with self.lock: self.db.close()

class Engine(ReturnMessageMixin, ShopWorkflow, SupplyWorkflow, ExternalWorkflow, AligoWorkflow):
    def __init__(self,store,provider=None,vault=None,archive=None,aligo_provider=None,aligo_vault=None):
        self.store=store;self.provider=provider or AligoSMS();self.creds={};self.plans={}
        self.vault=vault if vault is not None else default_vault(store.directory)
        self.login_state={'saved':False,'restored':False,'error':'','available':self.vault.available,'backend':self.vault.name}
        self.network_lock=threading.Lock();self.stop=threading.Event();self.thread=None
        self.last_poll_clock=0.0
        self.last_backup_clock=0.0
        self.archive=archive
        self.setup_aligo(store,aligo_provider,aligo_vault)
        try:
            import browser_window;browser_window.configure(False,store.read().get('settings',{}).get('headlessChrome',False))
        except Exception:pass
        with self.store.edit() as s:
            previous_version=s.get('appVersion')
            upgrading=previous_version not in {'0.5','0.5.1','0.5.2','0.5.3','0.5.4','0.5.5','0.5.6','0.6.0','0.6.1','0.6.2','0.6.3','0.6.4','0.6.5','0.6.6','0.6.7','0.6.8','0.6.9','0.6.10','0.6.11','0.6.12','0.6.13','0.6.14','0.6.15','0.6.16','0.6.17','0.6.18','0.6.19','0.6.20','0.6.21','0.6.22','0.6.23','0.6.24','0.6.25','0.6.26','0.6.27','0.6.28','0.6.29','0.6.30','0.6.31','0.6.32','0.6.36','0.6.37','0.6.38','0.6.39','0.6.40','0.6.41','0.6.42','0.6.43','0.6.44','0.6.45','0.6.46','0.6.47','0.6.48','0.6.49','0.6.50','0.6.51','0.6.52','0.6.53','0.6.54','0.6.55','0.6.56','0.6.57','0.6.58','0.6.59','0.6.60','0.6.61','0.6.62','0.6.63','0.6.64','0.6.65','0.6.66','0.6.67','0.6.68','0.6.69','0.6.70','0.6.71','0.6.72','0.6.73','0.6.74','0.6.75','0.6.76','0.6.77','0.6.78','0.6.79','0.6.80','0.6.81','0.6.82','0.6.83','0.6.84','0.6.85','0.6.86','0.6.87','0.6.88','0.6.89','0.6.90','0.6.91','0.6.92','0.6.93','0.6.94','0.6.95','0.6.96','0.6.97','0.6.98','0.6.99',APP_VERSION}
            login_upgrade=previous_version not in {'0.5.2','0.5.3','0.5.4','0.5.5','0.5.6','0.6.0','0.6.1','0.6.2','0.6.3','0.6.4','0.6.5','0.6.6','0.6.7','0.6.8','0.6.9','0.6.10','0.6.11','0.6.12','0.6.13','0.6.14','0.6.15','0.6.16','0.6.17','0.6.18','0.6.19','0.6.20','0.6.21','0.6.22','0.6.23','0.6.24','0.6.25','0.6.26','0.6.27','0.6.28','0.6.29','0.6.30','0.6.31','0.6.32','0.6.36','0.6.37','0.6.38','0.6.39','0.6.40','0.6.41','0.6.42','0.6.43','0.6.44','0.6.45','0.6.46','0.6.47','0.6.48','0.6.49','0.6.50','0.6.51','0.6.52','0.6.53','0.6.54','0.6.55','0.6.56','0.6.57','0.6.58','0.6.59','0.6.60','0.6.61','0.6.62','0.6.63','0.6.64','0.6.65','0.6.66','0.6.67','0.6.68','0.6.69','0.6.70','0.6.71','0.6.72','0.6.73','0.6.74','0.6.75','0.6.76','0.6.77','0.6.78','0.6.79','0.6.80','0.6.81','0.6.82','0.6.83','0.6.84','0.6.85','0.6.86','0.6.87','0.6.88','0.6.89','0.6.90','0.6.91','0.6.92','0.6.93','0.6.94','0.6.95','0.6.96','0.6.97','0.6.98','0.6.99',APP_VERSION}
            self.ensure_shop_state(s)
            self.ensure_aligo_state(s)
            s.setdefault('alerts',[])
            old_template=s['settings'].get('template','')
            if old_template==LEGACY_FIRST:s['settings']['template']=FIRST
            elif old_template==LEGACY_CHANGE:s['settings']['template']=CHANGE
            s['appVersion']=APP_VERSION
            s['settings'].setdefault('templateType','delay')
            ensure_composer_preferences(s['settings'])
            if previous_version!=APP_VERSION:purge_inactive_soldout_rows(s)
            if upgrading:
                s['pollNote']='접수 15초 후 1차, 총 1분에 2차 조회합니다.'
                for a in s['alerts']:
                    if a['code']=='RESULT_UNCONFIRMED' and not a.get('resolvedAt'):
                        a['resolvedAt']=now();a['resolution']='새 조회 일정으로 재확인' 
            if login_upgrade:s['audits'].append({'at':now(),'event':'v0.5.2 업데이트: 수신 테스트 제거 · 키체인 계정 유지 · 파일 선택 오류 수정, 기존 주문/이력 보존'})
            if previous_version!=APP_VERSION:s['audits'].append({'at':now(),'event':'v0.6.99 배포판: 에이블리 동기화 시 앱 안내건 배송지연 메시지 발송 처리 추가 · 교환 조회 지연 대기'})
            if previous_version!=APP_VERSION:s['pollNote']='접수 15초 후 1차, 총 1분에 2차 확인합니다. 미확정은 실제 실패와 구분하며 자동 재발송하지 않습니다.'
            interrupted=any(n['status']=='SENDING' for n in s['notices'])
            for n in s['notices']:
                n.setdefault('noticeType','delay')
                # Existing queues must not acquire permission to send at night.
                if not is_external(n):n.setdefault('sendMode','AUTO')
                if n['status']=='PENDING' and not n.get('acceptedAt'):
                    n['acceptedAt']=n.get('attemptedAt') or n['createdAt']
                migrate_report_policy(s,n,datetime.now(timezone.utc))
                pull_in_late_check(n,datetime.now(timezone.utc))
                if n['status'] in {'PENDING','UNKNOWN','SENDING'}:schedule_check(n)
                if n.get('isTest') and n['status'] in {'QUEUED','SCHEDULED','PAUSED'}:
                    self.transition(n,'CANCELLED','수신 테스트 기능 제거: 아직 요청하지 않은 이전 테스트를 취소했습니다.')
                elif n['status']=='SENDING': self.transition(n,'UNKNOWN','앱 중단 중 요청 결과 미확정. 재발송 없이 조회만 합니다.')
                elif n['status'] in {'QUEUED','SCHEDULED'}:
                    self.transition(n,'PAUSED','재시작: 저장 계정과 주문을 확인한 뒤 미요청/예약을 자동으로 이어갑니다.' if not interrupted else '요청 중 앱이 중단되어 다른 미요청 작업도 확인이 필요합니다.')
                    n['autoResume']=not interrupted
                    n['pauseReason']='restart' if not interrupted else 'interrupted_request'
                elif n['status']=='PAUSED' and n.get('note','').startswith('앱 재시작: 미요청/예약 시각을 보존했습니다.'):
                    # Migrate only the exact old restart-pause, never a manual/error pause.
                    n['autoResume']=not interrupted;n['pauseReason']='restart' if not interrupted else 'interrupted_request'
            s['queuePaused']=any(n['status']=='PAUSED' for n in s['notices'])
        self.setup_supply()
        self.restore_credentials()
        self.restore_aligo_credentials()

    @staticmethod
    def transition(n,status,note):
        n['status']=status;n['note']=note;n['updatedAt']=now()
        n['autoResume']=False
        n.pop('pauseReason',None)
        n.setdefault('events',[]).append({'at':n['updatedAt'],'status':status,'note':note})

    @staticmethod
    def add_alert(s,n,code,level,message):
        """Persist a single alert per outcome, including across restarts."""
        alerts=s.setdefault('alerts',[])
        if any(a['noticeId']==n['id'] and a['code']==code for a in alerts):return
        alerts.append({'id':secrets.token_urlsafe(12),'noticeId':n['id'],'code':code,
                       'level':level,'message':message,'at':now(),'acknowledgedAt':None})
        _phone_offer(alerts[-1])

    @staticmethod
    def resolve_wait_alerts(s,n):
        for a in s.get('alerts',[]):
            if a['noticeId']==n['id'] and (a['level']=='warning' or a['code'] in {'RESULT_UNCONFIRMED_25H','RESULT_UNCONFIRMED_3M','RESULT_UNCONFIRMED_1M'}) and not a.get('resolvedAt'):
                a['resolvedAt']=now()

    def set_browser_window(self,p):
        """settings.headlessChrome: run every automation Chrome without a window. A step that needs a person
        in the browser (extra authentication, 로그인 확인 후 이어가기) fails with a clear message instead."""
        enabled=bool(p.get('headlessChrome'))
        with self.store.edit() as s:s['settings']['headlessChrome']=enabled;s['settings'].pop('minimizeChrome',None)
        import browser_window;browser_window.configure(False,enabled)
        return {'headlessChrome':enabled,'message':'자동화 Chrome을 헤드리스(창 없음)로 실행합니다. 추가 인증이 필요한 작업은 헤드리스를 끄고 실행하세요.' if enabled else '자동화 Chrome 창을 보이게 실행합니다.'}
    def set_auto_zigzag_push(self,p):
        """settings.autoZigzagPush (default on): a message-less delay acknowledgement also sends Zigzag's 배송연기 안내 for those rows."""
        enabled=bool(p.get('autoZigzagPush'))
        with self.store.edit() as s:s['settings']['autoZigzagPush']=enabled
        return {'autoZigzagPush':enabled,'message':'메시지 없는 안내 처리 뒤 지그재그 배송연기 안내를 자동으로 전송합니다.' if enabled else '메시지 없는 안내 처리 뒤 지그재그 배송연기 안내를 자동으로 전송하지 않습니다.'}
    def set_auto_ably_push(self,p):
        """settings.autoAblyPush (default on): a message-less delay acknowledgement also sends Ably's 배송지연 message for those rows."""
        enabled=bool(p.get('autoAblyPush'))
        with self.store.edit() as s:s['settings']['autoAblyPush']=enabled
        return {'autoAblyPush':enabled,'message':'메시지 없는 안내 처리 뒤 에이블리 배송지연 메시지 발송 처리를 자동으로 실행합니다.' if enabled else '메시지 없는 안내 처리 뒤 에이블리 발송 처리를 자동으로 실행하지 않습니다.'}
    def phone_alert(self,p):
        """⚙ 설정 › 자동화 › 아이폰 알림 (아이메시지): status / save / test."""
        import phone_alert
        return phone_alert.settings_action(self,p if isinstance(p,dict) else {})
    def add_job_alert(self,title,message,level='info'):
        """'작업 완료!' style notification for finished/failed background jobs. Dismissed via acknowledge_alerts."""
        try:
            with self.store.edit() as s:
                alerts=s.setdefault('alerts',[])
                alerts.append({'id':secrets.token_urlsafe(12),'noticeId':'','code':'JOB_FAILED' if level=='error' else 'JOB_DONE','job':True,
                               'title':str(title)[:80],'level':'error' if level=='error' else 'info','message':str(message)[:600],'at':now(),'acknowledgedAt':None})
                _phone_offer(alerts[-1])
                # Keep the acknowledged job history bounded.
                acked=[a for a in alerts if a.get('job') and a.get('acknowledgedAt')]
                for a in acked[:-200]:alerts.remove(a)
        except Exception:pass  # a missing notification never breaks the job itself
        if level=='error':self.record_error(title,message)   # 2026-10-22: ⚙ 설정 › 오류 로그
    def record_error(self,title,message,detail=''):
        """오류 로그 (⚙ 설정 › 오류 로그). 막힘·실패 알림과 처리되지 않은 오류를 시각·버전·코드 위치(traceback)와 함께 남긴다.
        except 블록 안에서 불리면 그 예외의 traceback을 자동으로 붙인다. Never raises."""
        try:
            import sys as _sys,traceback as _tb,threading as _th
            tb=detail or (_tb.format_exc() if _sys.exc_info()[0] else '')
            with self.store.edit() as s:
                log=s.setdefault('errorLog',[])
                log.append({'id':secrets.token_urlsafe(9),'at':now(),'version':APP_VERSION,'title':str(title)[:200],'message':str(message)[:4000],
                            'detail':str(tb)[-6000:],'thread':_th.current_thread().name})
                del log[:-300]
        except Exception:pass
    def error_log(self,p):
        if isinstance(p,dict) and p.get('action')=='clear':
            with self.store.edit() as s:s['errorLog']=[]
        s=self.store.read()
        return {'entries':list(reversed(s.get('errorLog',[])[-300:])),'version':APP_VERSION}
    def acknowledge_alerts(self,p):
        ids=p.get('ids',[])
        if not isinstance(ids,list) or len(ids)>10000:raise ValidationError('알림 선택을 확인하세요.')
        with self.store.edit() as s:
            for a in s.get('alerts',[]):
                if a['id'] in ids:a['acknowledgedAt']=now()
        return {'message':'알림을 확인 처리했습니다. 발송 결과나 문자는 변경하지 않습니다.'}

    def public_state(self):
        s=self.store.read();s.pop('ablySyncCache',None);t=today()
        from aftersales_data import public_aftersales as public_returns
        s['returns']=public_returns(s,date.fromisoformat(t));s.pop('returnCheck',None);s.pop('exchangeCheck',None)
        cancelled_idx=app_cancelled_index(s)
        for r in s['rows']:
            ns=sorted((n for n in s['notices'] if not n['isTest'] and r['key'] in n['itemKeys']),key=notice_sort_key)
            good=sorted((n for n in ns if applied_notice(n)),key=effective_notice_key)
            pending_dates=[n for n in ns if pending_applied(n)]
            latest=sorted(good+pending_dates,key=effective_notice_key)[-1] if good or pending_dates else None
            outcomes=sorted((n for n in ns if (n['status'] in {'PENDING','DELIVERED','FAILED'} or is_external(n) or result_timeout(n)) and not n.get('fallbackSmsOk')),key=notice_sort_key)
            outcome=outcomes[-1] if outcomes else None
            failed=bool(outcome and (outcome['status']=='FAILED' or result_timeout(outcome)))
            r['noticeType']=latest.get('noticeType','delay') if latest else 'delay'
            r['dueDate']=latest.get('dueDate','') if latest else '';r['noticeCount']=len(good)
            r['dueDatePending']=bool(latest and pending_applied(latest))
            r['delayNoticeCount']=sum(not is_soldout(n) for n in good)  # Read-only lookup metadata; no history mutation.
            r['dueDateSource']=('ably_sync' if latest.get('source')=='ably_sync' else 'zigzag_sync' if latest.get('source')=='zigzag_sync' else 'external' if is_external(latest) else 'pending_message' if pending_applied(latest) else 'customer_message') if latest else ''
            # 2026-10-23: 지그재그 주문은 주문 수집 때부터 지그재그 발송 예정일(결제일+3영업일)을 안내한 출고 예정일로 보여 준다.
            # 메시지 없는 안내·고객 안내 문자를 처리하면 그 이력(latest)이 바로 이 값을 대신한다.
            r['zigzagWindow']=_zz_row_window(s,r,t) if r.get('seller')=='누아브 지그재그' else None
            r['zigzagDefaultDue']=bool(not latest and r['zigzagWindow'] and r['zigzagWindow'].get('shipBy'))
            if r['zigzagDefaultDue']:r['dueDate']=r['zigzagWindow']['shipBy'];r['dueDateSource']='zigzag_default'
            r['externalNoticeCount']=sum(is_external(n) for n in good)
            r['appNoticeCount']=len(good)-r['externalNoticeCount']
            # 2026-10-20 06:19: a 품절 안내 that is queued/scheduled (대기) already counts as 품절 안내 완료(대기 포함) — the row leaves
            # 품절 확인 필요 right away; a FAILED/CANCELLED message drops it back automatically.
            soldout_pending=[n for n in ns if is_soldout(n) and n.get('noticeType')!='manual' and n['status'] in {'QUEUED','SCHEDULED','PAUSED','SENDING'}]
            r['soldoutPending']=bool(soldout_pending) and not bool(latest and is_soldout(latest))
            r['soldoutNotified']=bool(latest and is_soldout(latest)) or bool(soldout_pending)
            r['refundHold']=refund_hold(r,ns,cancelled_idx);r['sendHold']=send_hold(r,ns,cancelled_idx)
            if failed:r['bucket']='failed';r['color']='failed'
            elif r['soldoutNotified']:r['bucket']='soldout';r['color']='charcoal'
            elif not latest or not r['dueDate']:r['bucket']='unnotified';r['color']='white'   # 지그재그 자동 발송 예정일은 표시만 (안내 전 분류 유지)
            elif t<r['dueDate']:r['bucket']='within';r['color']='green'
            elif t==r['dueDate']:r['bucket']='due_today';r['color']='yellow'
            else:r['bucket']='overdue';r['color']='red'
            r['failedNoticeId']=outcome['id'] if failed else ''
            r['failedReason']=('1분 결과 미확인' if result_timeout(outcome) else '전송 실패 확정') if failed else ''
            r['resultUnconfirmedFailure']=bool(failed and result_timeout(outcome))
            r['lastSuccessAt']=latest.get('deliveredAt','') if latest else ''
            r['lastNoticeAt']=(latest.get('acceptedAt') or latest.get('attemptedAt') or latest.get('deliveredAt') or latest['createdAt']) if latest else ''
            r['externalHistory']=bool(latest and is_external(latest))
            if r['externalHistory']:r['lastNoticeAt']=''
            r['deliveryVerified']=bool(latest and latest['status']=='DELIVERED')
            shipping_ns=[n for n in ns if n.get('noticeType')!='manual']
            r['removeIfExcludedSoldout']=bool(shipping_ns and is_soldout(shipping_ns[-1]))
            r['lastState']=display_status(ns[-1]) if ns else '';r['lastNoticeId']=ns[-1]['id'] if ns else ''
            r['pending']=any(n['status'] in PENDING for n in ns)
            # Classification is separate from the color of the last valid notice.
            # Do not count a reserved first notice as 'unnotified', or a reserved
            # re-notice a second time under its previous due/failed/sold-out card.
            reservations=sorted((n for n in ns if awaiting_reservation(n)),key=notice_sort_key)
            reservation=reservations[-1] if reservations else None
            r['noticeBucket']=r['bucket']
            r['reservationPending']=bool(reservation)
            r['reservationState']=reservation['status'] if reservation else ''
            r['reservationNoticeId']=reservation['id'] if reservation else ''
            r['scheduledAt']=reservation.get('scheduledAt','') if reservation else ''
            if reservation:r['bucket']='scheduled'
        s['appVersion']=APP_VERSION
        name=s['settings'].get('shopName','')
        s['settings']['template']=render_template(s['settings'].get('template',FIRST),name)
        s['settings']['smsTemplates']={k:render_template(v,name) for k,v in s['settings'].get('smsTemplates',{}).items()}
        s['messageTemplates']={k:render_template(v,name) for k,v in [('first',FIRST),('change',CHANGE),('soldout_card',SOLDOUT_CARD),('soldout_bank',SOLDOUT_BANK)]}
        s['messageTitles']={'delay':message_title(name),'soldout':message_title(name,True)}
        s['credentialsReady']={k:k in self.creds for k in ('SMS','LMS')}
        s.pop('tests',None)
        s['accountStorage']=dict(self.login_state)
        s['desktopBackup']=self.archive.status() if self.archive else {'enabled':False}
        s['autoResumeWaiting']=sum(n['status']=='PAUSED' and bool(n.get('autoResume')) for n in s['notices'])
        for n in s['notices']:
            n.pop('fingerprint',None);n.pop('testCodeHash',None)
            n['displayStatus']=display_status(n)
            deadline=result_deadline(n)
            if deadline:n['resultDeadlineAt']=deadline.isoformat(timespec='milliseconds')
        s['today']=t;s['dataPath']=str(self.store.path);s['sendWindow']=send_window()
        s['pendingPlatformPushes']=[{'id':x.get('id',''),'at':x.get('at',''),'items':len(x.get('keys',[])),'dueDate':x.get('dueDate','')} for x in s.get('pendingPlatformPushes',[])]
        s['reportPolicy']={'firstSeconds':15,'secondSeconds':60,'lateRetrySeconds':43200,'anchor':'acceptedAt','unconfirmedMeansFailure':False}
        return self.supply_public(self.china_public(self.decorate_public(s)))

    @staticmethod
    def account_binding(settings):
        return {k:settings.get(k,'') for k in ('smsUser','lmsUser','sender','scheme')}

    def restore_credentials(self):
        """Read only this edition's Aligo SMS keychain item, never a legacy password."""
        with self.network_lock:
            try:
                payload=self.vault.load()
                if not payload:
                    self.login_state.update(saved=False,restored=False,error='')
                    return {'message':'저장된 알리고 문자 계정이 없습니다. 문자 설정에서 한 번 저장하세요.'}
                cfg=self.store.read()['settings']
                if payload.get('provider')!='ALIGO_SMS' or payload.get('binding')!=self.account_binding(cfg):
                    raise VaultError('저장된 알리고 계정과 발신 설정이 다릅니다. 계정을 다시 저장하세요.')
                value=payload.get('credential',{})
                cred=Credential(value.get('user',''),value.get('apikey',''))
                if (not isinstance(cred.user,str) or cred.user!=cfg.get('smsUser') or not cred.user
                        or not isinstance(cred.apikey,str) or not cred.apikey or len(cred.apikey)>500):
                    raise VaultError('저장된 알리고 API 계정 형식을 읽지 못했습니다.')
                self.creds={'SMS':cred,'LMS':cred}
                self.login_state.update(saved=True,restored=True,error='')
                self.last_poll_clock=0.0
                resumed=self._resume_recovered_locked()
                return {'message':f'알리고 문자 계정을 불러왔습니다. 미요청/예약 {resumed}건 복구, 미확정은 결과만 조회합니다.'}
            except (VaultError,TypeError,AttributeError) as exc:
                self.creds.clear()
                message=str(exc) if isinstance(exc,VaultError) else '알리고 키체인 형식을 확인하세요.'
                self.login_state.update(error=message,restored=False)
                return {'message':message,'restored':False}

    def _resume_recovered_locked(self):
        """Called with network_lock held after loading credentials.

        Resume ONLY jobs interrupted before any provider attempt. Manual pauses,
        configuration/error holds and attempted requests are never auto-resumed.
        """
        snapshot=self.store.read()
        candidates=[n for n in snapshot['notices'] if n['status']=='PAUSED' and n.get('autoResume') and self.has_credential(n['kind'])]
        if not candidates:return 0
        resumed=0
        with self.store.edit() as s:
            cfg=s['settings'];clock=datetime.now(timezone.utc)
            for n in s['notices']:
                if n['status']!='PAUSED' or not n.get('autoResume') or not self.has_credential(n['kind']):continue
                try:
                    if n.get('attemptedAt'):
                        self.transition(n,'UNKNOWN','요청 시도가 있는 작업은 다시 보내지 않고 결과만 확인합니다.')
                        schedule_check(n);continue
                    cred=self.validate_send_config(s,n)
                    if n.get('isTest'):raise ValidationError('제거된 수신 테스트는 재개하지 않습니다.')
                    target=dispatch_target(n,clock)
                    if n.get('dueDate') and n['dueDate']<target.astimezone(KST).date().isoformat():
                        raise ValidationError('재실행 시 출고 예정일이 발송일보다 빠릅니다. 새 예정일로 작성하세요.')
                    self.validate_snapshot(s,n)
                except ValidationError as exc:
                    self.transition(n,'PAUSED',str(exc));n['pauseReason']='validation'
                    self.add_alert(s,n,'AUTO_RESUME_BLOCKED','warning','자동 이어보내기 보류: '+str(exc))
                    continue
                n['configRevision']=cfg['configRevision'];n['resumedAt']=now()
                if target>clock:
                    n['scheduledAt']=target.isoformat(timespec='milliseconds')
                    self.transition(n,'SCHEDULED','재시작 자동 복구: 기존 예약의 허용 시각에 이어서 보냅니다.')
                else:self.transition(n,'QUEUED','재시작 자동 복구: 아직 요청하지 않은 안내만 이어서 보냅니다.')
                self.resolve_wait_alerts(s,n);resumed+=1
            s['queuePaused']=any(n['status']=='PAUSED' for n in s['notices'])
            if resumed:s['audits'].append({'at':now(),'event':'재실행 미요청/예약 자동 재개','count':resumed})
        return resumed

    def backup_desktop(self, force=False, reason='periodic'):
        if not self.archive:return {'enabled':False,'message':'독립 맥 앱에서 바탕화면 자동 백업을 사용합니다.'}
        result=self.archive.run(force=force,reason=reason)
        result['message']=('바탕화면 백업 저장 완료. iCloud 업로드 완료 여부는 Finder에서 확인하세요.' if not result.get('error') else result['error'])
        return result

    def credential(self,kind):
        if kind=='AT':
            if not self.aligo_cred:raise ValidationError(self.aligo_login.get('error') or '알림톡 설정에서 알리고 계정을 한 번 저장하세요.')
            return self.aligo_cred
        if kind not in self.creds:
            reason=self.login_state.get('error')
            raise ValidationError(reason or f'{kind} 서비스 계정이 없습니다. 문자 설정에서 한 번 저장하세요.')
        return self.creds[kind]

    def configure(self,p):
        sender=phone(p.get('sender',''))
        if not re.fullmatch(r'0\d{8,10}|1[568]\d{6}',sender):
            raise ValidationError('알리고에 등록된 발신번호를 입력하세요.')
        user=clean(p.get('user'))
        api=p.get('apikey','')
        if not user or len(user)>100 or re.search(r'\s',user):
            raise ValidationError('알리고 로그인 ID를 공백 없이 입력하세요.')
        if not isinstance(api,str) or len(api)>500:
            raise ValidationError('알리고 API Key 입력을 확인하세요.')
        api=api.strip()
        with self.network_lock:
            prev=self.creds.get('LMS')
            key=api or (prev.apikey if prev and prev.user==user else '')
            if not key or re.search(r'\s',key):
                raise ValidationError('알리고 API Key를 입력하세요. 다른 ID로 변경할 때는 새 키가 필요합니다.')
            cred=Credential(user,key)
            with self.store.edit() as s:
                old=s['settings'];new={'smsUser':user,'lmsUser':user,'sender':sender,'scheme':'https'}
                changed=any(old.get(k)!=v for k,v in new.items()) or prev!=cred
                payload={'version':1,'provider':'ALIGO_SMS','binding':new,
                         'credential':{'user':cred.user,'apikey':cred.apikey}}
                if self.vault.available:
                    try:self.vault.save(payload)
                    except VaultError as exc:
                        self.login_state['error']=str(exc)
                        raise ValidationError(str(exc)) from exc
                old.update(new);old['smsProvider']='ALIGO'
                if changed:
                    old['configRevision']+=1;self.plans.clear()
                    for n in s['notices']:
                        if n['status'] in {'QUEUED','SCHEDULED'}:
                            self.transition(n,'PAUSED','알리고 문자 설정 변경: 기존 미요청·예약을 취소하고 새 설정으로 다시 작성하세요.')
                s['queuePaused']=any(n['status']=='PAUSED' for n in s['notices'])
                s['audits'].append({'at':now(),'event':'알리고 문자 계정 저장 (API Key는 키체인/실행 메모리만, 발송 없음)'})
            self.creds={'SMS':cred,'LMS':cred};self.last_poll_clock=0.0
            self.login_state.update(saved=self.vault.available,restored=False,error='')
            self._resume_recovered_locked()
        return {'message':('알리고 문자 계정을 맥 키체인에 저장했습니다. 다음 실행부터 자동으로 사용합니다.'
                           if self.vault.available else '알리고 계정을 실행 메모리에 설정했습니다. 이 비맥 환경에서는 영구 저장하지 않습니다.')+
                          ' 계정 저장만으로 문자를 보내지 않습니다.'}

    def forget_credentials(self,p):
        if p.get('confirmed') is not True:raise ValidationError('저장된 계정 삭제를 확인하세요.')
        with self.network_lock:
            try:self.vault.delete()
            except VaultError as exc:raise ValidationError(str(exc)) from exc
            with self.store.edit() as s:
                for n in s['notices']:
                    if n['status'] in {'QUEUED','SCHEDULED'}:self.transition(n,'PAUSED','저장된 계정 삭제로 미요청/예약을 일시정지했습니다.')
                s['queuePaused']=any(n['status']=='PAUSED' for n in s['notices'])
                s['tests']={};s['settings']['configRevision']+=1
                s['audits'].append({'at':now(),'event':'사용자가 이 앱의 저장 계정을 삭제함. 주문·전송 이력은 보존'})
            self.creds.clear();self.plans.clear()
            self.login_state.update(saved=False,restored=False,error='')
        return {'message':'저장된 계정만 삭제했습니다. 주문·이력은 유지하며 발송·조회는 계정 재설정 전까지 멈춥니다.'}

    def remaining(self,kind):
        if kind not in ('SMS','LMS'): raise ValidationError('문자 종류 오류')
        cred=self.credential(kind);s=self.store.read()
        with self.network_lock: return {'remaining':self.provider.remaining(kind,cred,s['settings']['scheme'])}

    def import_rows(self,p):
        from order_export import contacts,merge_contacts
        source=p.get('rows',[])
        if not isinstance(source,list) or len(source)>20000: raise ValidationError('최대 20,000행까지 불러올 수 있습니다.')
        # Legacy internal clients default to merge; the visible app always sends
        # explicit snapshot (default) or merge (partial/test file).
        mode=p.get('mode','merge');scope=p.get('scope',[]);label_scope=p.get('scopeLabels') is True
        if p.get('parseErrors'):raise ValidationError('엑셀 오류를 해결한 뒤 반영하세요. 잘못 읽힌 행을 자동 제외하지 않습니다.')
        if mode not in ('merge','snapshot'): raise ValidationError('불러오기 방식 오류')
        if mode=='snapshot' and not label_scope and (not scope or any(x not in SELLERS for x in scope)): raise ValidationError('전체 목록 교체 대상 판매처를 선택하세요.')
        records={};excluded={};combined=0
        settings=self.store.read()['settings']
        shop_name=settings.get('shopName','')
        scoped=p.get('scopeFilter') is True
        if label_scope:
            scoped=True
            available=seller_choices(p.get('available'),shop_name);scope=seller_choices(scope,shop_name)
            if not scope or not set(scope)<=set(available):raise ValidationError('현재 엑셀 판매처를 하나 이상 선택하세요.')
            if scope!=selected_seller_labels(settings,available) or p.get('shopRevision')!=settings.get('shopRevision',0):
                raise ValidationError('저장된 판매처 선택이 바뀌었습니다. 파일을 다시 여세요.')
        elif scoped:
            from branding import import_scope
            scope=import_scope(scope)
            if not shop_name:raise ValidationError('쇼핑몰 이름을 먼저 설정하세요.')
            if not scope:raise ValidationError('불러올 판매처를 하나 이상 선택하세요.')
            if scope!=settings['importScope'] or p.get('shopRevision')!=settings.get('shopRevision',0):
                raise ValidationError('저장된 쇼핑몰 또는 판매처 선택이 바뀌었습니다. 파일을 다시 열어 확인하세요.')
        for v in source:
            if not isinstance(v,dict): raise ValidationError('주문 데이터 형식 오류')
            original_seller=clean(v.get('seller'));seller=normalize_seller(original_seller,shop_name)
            if scoped:
                if not isinstance(v.get('sourceSeller'),str):raise ValidationError('원본 판매처 정보가 없습니다. 엑셀을 다시 불러오세요.')
                original_seller=clean(v['sourceSeller']);seller=import_seller(original_seller,shop_name)
                if label_scope:
                    if not row_in_seller_scope({'sourceSeller':original_seller},scope,shop_name):seller=None
                elif seller not in scope:seller=None
            if not seller: excluded[original_seller]=excluded.get(original_seller,0)+1;continue
            r={k:clean(v.get(k)) for k in ('orderId','product','option','orderDate','buyer','recipient','phoneSource')}
            if not r['orderId'] or not r['product']: raise ValidationError('주문번호와 상품명은 필수입니다.')
            if re.fullmatch(r'\d+(\.\d+)?e[+-]?\d+',r['orderId'],re.I): raise ValidationError('주문번호 지수표기는 지원하지 않습니다. 원본을 텍스트로 내보내세요.')
            if any(len(value)>1500 for value in r.values()): raise ValidationError('너무 긴 항목이 있습니다.')
            qty=v.get('qty',1)
            if isinstance(qty,bool) or not isinstance(qty,(int,float)) or int(qty)!=qty or not 1<=qty<=100000: raise ValidationError('수량을 확인하세요.')
            r['orderTimestamp']=clean(v.get('orderTimestamp'))[:120]
            try:r['exportContacts']=contacts(v.get('exportContacts'))
            except ValueError as exc:raise ValidationError(str(exc)) from exc
            if label_scope:r['sourceSeller']=original_seller
            r.update(seller=seller,phone=phone(v.get('phone')),qty=int(qty),active=True,review=False,needsPhoneApproval=bool(v.get('needsPhoneApproval')),lastSeen=now())
            if seller in (ABLY,AMOOD):
                try:set_items(r,items_of({**v,'seller':seller,'qty':int(qty)}))
                except ItemIdError as exc:raise ValidationError(str(exc)) from exc
                r['orderItemIdMapped']=bool(v.get('orderItemIdMapped') or v.get('orderItemId') or v.get('orderItems'))
            r['key']=rowkey(r)
            if r['key'] in records:
                if records[r['key']]['phone']!=r['phone']: raise ValidationError('같은 주문상품에 서로 다른 연락처가 있습니다.')
                if seller in (ABLY,AMOOD):
                    try:combine_items(records[r['key']],r)
                    except ItemIdError as exc:raise ValidationError(str(exc)) from exc
                records[r['key']]['exportContacts']=merge_contacts(records[r['key']].get('exportContacts'),r.get('exportContacts'))
                records[r['key']]['qty']+=r['qty'];combined+=1
            else: records[r['key']]=r
        detail_keys={}
        for r in records.values():
            for part in r.get('orderItems',[]):
                if (r['seller'],part['id']) in detail_keys and detail_keys[(r['seller'],part['id'])]!=r['key']:
                    raise ValidationError('같은 에이블리 상품주문번호가 서로 다른 주문상품에 있습니다. M열을 확인하세요.')
                detail_keys[(r['seller'],part['id'])]=r['key']
        if not records and mode!='snapshot': raise ValidationError('불러올 대상 주문이 없습니다.')
        if mode=='snapshot' and not label_scope and any(r['seller'] not in scope for r in records.values()): raise ValidationError('파일에 포함된 판매처를 교체 범위에 모두 포함하세요.')
        if mode=='snapshot' and p.get('replaceConfirmed') is not True: raise ValidationError('누락된 상품이 현재 목록에서 제외됨을 확인하세요.')
        if mode=='snapshot' and not records and p.get('emptyConfirmed') is not True:
            raise ValidationError('대상 상품이 0개입니다. 실제로 전체 미출고가 0개인지 별도로 확인하세요.')
        if self.archive:self.backup_desktop(force=True,reason='before-import')
        with self.network_lock, self.store.edit() as s:
            if any(n['status']=='SENDING' for n in s['notices']):raise ValidationError('요청 중인 문자가 있습니다. 처리 완료 후 다시 반영하세요.')
            if scoped and (scope!=(selected_seller_labels(s['settings'],available) if label_scope else s['settings']['importScope']) or p.get('shopRevision')!=s['settings'].get('shopRevision',0)):
                raise ValidationError('판매처 선택이 바뀌었습니다. 엑셀을 다시 열어 확인하세요.')
            old={r['key']:r for r in s['rows']};inactive=0;added=0;updated=0;refund_keys,send_keys=hold_keys(s);hold=refund_keys|send_keys
            eligible={r['key'] for r in s['rows'] if row_in_seller_scope(r,scope,shop_name)} if label_scope else {r['key'] for r in s['rows'] if r['seller'] in scope}
            if label_scope and any(k in old and k not in eligible for k in records):
                raise ValidationError('선택하지 않은 판매처와 같은 주문번호·상품이 있습니다. 판매처명을 확인하세요.')
            for key,r in old.items():
                missing=mode=='snapshot' and key in eligible and key not in records
                if key in refund_keys:r['refundHoldMissing']=missing   # 자사몰 환불 대기: 엑셀에서 빠져도 유지
                if key in send_keys:r['sendHoldMissing']=missing       # 앱이 품절 취소 → 예약 품절 문자 발송 대기: 엑셀에서 빠져도 유지
                elif r.get('sendHoldMissing'):r.pop('sendHoldMissing',None)
                if mode=='snapshot' and key in eligible and key not in records and r['active'] and key not in hold:
                    r['active']=False;r['excludedAt']=now();r['archiveReason']='최신 전체 미출고 목록에서 제외 (출고/취소 세부 사유 미구분)';inactive+=1
            for key,r in records.items():
                if key in old:
                    prev=old[key];has_notice=any(key in n['itemKeys'] for n in s['notices'])
                    # Files without the new column can still be used. Preserve metadata
                    # only when the unchanged row quantity means its coverage is valid.
                    if r['seller'] in (ABLY,AMOOD) and not r.get('orderItemIdMapped') and prev['qty']==r['qty']:
                        set_items(r,items_of(prev));r['orderItemIdMapped']=bool(prev.get('orderItemIdMapped'))
                    r['review']=prev.get('review',False) or (has_notice and (prev['qty']!=r['qty'] or prev['phone']!=r['phone']))
                    prev.update(r);updated+=1
                else: s['rows'].append(r);added+=1
            cancelled=0
            for n in s['notices']:
                if n['status'] in {'QUEUED','PAUSED','SCHEDULED'} and any(k not in records and k not in hold and mode=='snapshot' and k in eligible for k in n['itemKeys']):
                    self.transition(n,'CANCELLED','새 미출고 목록에서 대상이 제외되어 미요청/예약 작업을 취소했습니다.');cancelled+=1
                    self.resolve_wait_alerts(s,n)
                    if n.get('scheduledAt'):self.add_alert(s,n,'RESERVATION_EXCLUDED','warning','최신 미출고 목록에서 예약 상품이 빠져 이 주문의 예약 문자 전체를 취소했습니다. 나머지 상품은 필요시 다시 선택하세요.')
            purged=purge_inactive_soldout_rows(s,eligible_keys=eligible) if mode=='snapshot' else 0
            self.supply_after_import(s)
            res={'removedSoldout':purged,'at':now(),'fileName':clean(p.get('fileName'))[:250],'mode':mode,'scope':scope,'added':added,'updated':updated,'inactive':inactive,'cancelled':cancelled,'combined':combined,'excluded':p.get('excluded',excluded)}
            s['imports'].append(res)
            s['queuePaused']=any(n['status']=='PAUSED' for n in s['notices'])
        if self.archive:self.backup_desktop(force=True,reason='after-import')
        return res

    def save_preferences(self,p):
        key=p.get('defaultTemplate')
        if not isinstance(key,str) or key not in TEMPLATE_KEYS:
            raise ValidationError('기본 안내 양식을 목록에서 선택하세요.')
        with self.store.edit() as s:
            ensure_composer_preferences(s['settings'])
            s['settings']['defaultTemplate']=key
            s['audits'].append({'at':now(),'event':'작성창 기본 안내 양식 저장','templateKey':key})
        return {'defaultTemplate':key,'message':'기본 안내 양식을 저장했습니다. 다음 작성창부터 적용되며 문자는 발송하지 않습니다.'}

    def review_rows(self,keys):
        with self.store.edit() as s:
            for r in s['rows']:
                if r['key'] in keys:r['review']=False
        return {'message':'선택 상품의 변경 내용을 확인 처리했습니다.'}

    @staticmethod
    def new_notice(kind,content,title,receiver,ref,keys,is_test=False):
        return {'id':secrets.token_urlsafe(16),'ref':ref,'kind':kind,'provider':'ALIGO_SMS','channel':'알리고 '+kind,'content':content,'title':title,'phone':receiver,
                'itemKeys':keys,'products':[],'isTest':is_test,'createdAt':now(),'updatedAt':now(),'status':'QUEUED','events':[],
                'seller':'테스트' if is_test else '', 'orderId':'','dueDate':'','noticeType':'delay','note':'아직 공급사에 요청하지 않았습니다.'}

    def build_sms_groups(self,s,p):
        shop_name=clean_name(s['settings'].get('shopName',''))
        notice_type=clean(p.get('noticeType','delay'))
        if notice_type not in NOTICE_TYPES:raise ValidationError('지원되지 않는 안내 종류입니다.')
        send_mode=clean(p.get('sendMode','AUTO'))
        send_at=selected_send_time(send_mode)
        soldout=notice_type in {'soldout_card','soldout_bank'};manual=notice_type=='manual';d=None;due=''
        if manual and clean(p.get('dueDate')):raise ValidationError('수동 작성은 출고 예정일 없이 발송합니다.')
        if notice_type=='delay':
            due=clean(p.get('dueDate'))
            try:d=date.fromisoformat(due)
            except ValueError as exc:raise ValidationError('출고 예정일을 선택하세요.') from exc
            if d.isoformat()!=due or due<today():raise ValidationError('예정일은 오늘 또는 이후 날짜여야 합니다.')
            earliest=send_at.date().isoformat()
            if due<earliest:raise ValidationError(f'지금 요청하면 {earliest} 오전 9시에 예약 발송됩니다. 출고 예정일도 {earliest} 또는 이후로 선택하세요.')
        keys=set(p.get('keys',[]));selected=[r for r in s['rows'] if r['key'] in keys]
        if not selected or len(selected)!=len(keys): raise ValidationError('발송 대상을 다시 선택하세요.')
        template=p.get('template',FIRST)
        if not isinstance(template,str) or not template.strip() or len(template)>4000: raise ValidationError('안내문 길이를 확인하세요.')
        template=render_template(template,shop_name)
        if not manual and shop_name not in template:raise ValidationError('안내문에 설정한 쇼핑몰 이름 또는 {쇼핑몰명}을 유지하세요.')
        if not manual and '{상품목록}' not in template:raise ValidationError('안내문에 {상품목록}을 유지하세요.')
        if notice_type=='delay' and '{출고예정일}' not in template:raise ValidationError('지연 안내문에는 {출고예정일}도 유지하세요.')
        if manual and '{출고예정일}' in template:raise ValidationError('수동 작성에는 출고 예정일 변수를 사용할 수 없습니다.')
        if soldout and '{출고예정일}' in template:raise ValidationError('품절 안내에는 출고 예정일을 사용하지 않습니다. 품절 양식을 선택하세요.')
        mode=p.get('kind','LMS')
        if mode not in ('SMS','LMS','AUTO'): raise ValidationError('문자 종류를 확인하세요.')
        grouped={}
        for r in selected:
            if not r['active'] or (r['seller'] not in SELLERS and import_seller(r.get('sourceSeller'),shop_name)!=r['seller']): raise ValidationError('현재 미출고 목록에 없는 상품입니다.')
            if r['review']: raise ValidationError('수량·연락처가 변경된 상품이 있습니다. 확인 처리 후 다시 선택하세요.')
            if not valid_phone(r['phone']): raise ValidationError(f"{r['orderId']}: 수신번호를 확인하세요. 안심번호는 이 버전에서 자동 발송하지 않습니다.")
            if r['needsPhoneApproval'] and not p.get('alternativeApproved'): raise ValidationError('수령자 대체 번호 사용을 확인하세요.')
            if any(r['key'] in n['itemKeys'] and n['status'] in BLOCKING for n in s['notices']): raise ValidationError('선택 상품에 미요청·요청 중 또는 접수 여부가 불분명한 작업이 있습니다. 기존 작업부터 확인하세요.')
            all_rows=[x for x in s['rows'] if x['active'] and (x['seller'],x['orderId'])==(r['seller'],r['orderId'])]
            if len({x['phone'] for x in all_rows})!=1: raise ValidationError('동일 주문 내 수신번호가 다릅니다. 엑셀을 확인하세요.')
            grouped.setdefault((r['seller'],r['orderId']),[]).append(r)
        result=[]
        for (seller,oid),rs in grouped.items():
            products='\n'.join(f"{r['product']}{' ('+r['option']+')' if r['option'] else ''} × {r['qty']}" for r in rs)
            label=f'{d.year}년 {d.month}월 {d.day}일' if d else ''
            base=template.replace('{상품목록}',products).replace('{출고예정일}',label)
            if re.search(r'\{[^{}]+\}',base): raise ValidationError('지원되지 않는 치환 변수가 있습니다.')
            # Preserve the original customer-facing reference. Results now correlate by Aligo MID.
            ref=notice_ref();content=base+'\n\n안내번호:'+ref
            safe_outgoing(content,shop_name)
            size=bytecount(content);kind=('SMS' if size<=90 else 'LMS') if mode=='AUTO' else mode
            limit=90 if kind=='SMS' else 2000
            if size>limit: raise ValidationError(f'{oid}: {kind} {size}바이트 / 앱 제한 {limit}바이트. 상품 수 또는 문구를 줄이세요.')
            title=render_template(clean(p.get('title') or (shop_name+' 안내' if manual else message_title(shop_name,soldout))),shop_name)
            safe_outgoing(title,shop_name)
            if not title or bytecount(title)>40: raise ValidationError('제목은 1~40바이트로 입력하세요.')
            itemkeys=sorted(r['key'] for r in rs)
            fp=fingerprint([seller,oid,rs[0]['phone'],itemkeys,due,base,kind]+([notice_type] if notice_type!='delay' else []))
            if any(n.get('fingerprint')==fp and (n['status'] in PENDING or n['status']=='DELIVERED') for n in s['notices']): raise ValidationError(f'{oid}: 동일 상품·예정일·문구로 이미 안내했습니다.')
            repeated=any((applied_notice(n) or (n.get('noticeType')=='manual' and n['status'] in {'PENDING','DELIVERED'})) and any(k in n['itemKeys'] for k in itemkeys) for n in s['notices'])
            result.append({'seller':seller,'orderId':oid,'phone':rs[0]['phone'],'itemKeys':itemkeys,'products':[{k:r[k] for k in ('product','option','qty')} for r in rs],
                           'content':content,'base':base,'ref':ref,'title':title,'kind':kind,'bytes':size,'dueDate':due,'noticeType':notice_type,'fingerprint':fp,'repeated':repeated})
        return result

    def preview(self,p):
        groups=self.build_groups(self.store.read(),p)
        token=secrets.token_urlsafe(24)
        self.plans={k:v for k,v in self.plans.items() if time.monotonic()-v['at']<600}
        if len(self.plans)>50:self.plans.clear()
        self.plans[token]={'at':time.monotonic(),'groups':groups,'input':p}
        return {'token':token,'groups':groups,'count':len(groups),'repeatCount':sum(g['repeated'] for g in groups)}

    def commit(self,p):
        token=p.get('token','')
        with self.store.edit() as s:
            already=[n for n in s['notices'] if n.get('batchToken')==token]
            if already:return {'count':len(already),'alreadyAccepted':True}
            plan=self.plans.get(token)
            if not plan or time.monotonic()-plan['at']>600: raise ValidationError('발송 준비가 만료되었습니다. 작성창을 다시 열어주세요.')
            groups=plan['groups'];fresh=self.build_groups(s,plan['input'])
            window=send_window(mode=plan['input'].get('sendMode','AUTO'))
            if any(g['dueDate'] and g['dueDate']<window['minDueDate'] for g in groups):raise ValidationError('발송 허용시간이 변경되었습니다. 출고 예정일을 예약 발송일 이후로 다시 선택하세요.')
            if [g['fingerprint'] for g in groups]!=[g['fingerprint'] for g in fresh]: raise ValidationError('대상 정보가 변경되었습니다. 작성창을 다시 열어주세요.')
            cfg=s['settings']
            if not cfg['sender']: raise ValidationError('알리고 문자·대체문자 발신번호를 설정하세요.')
            for g in groups:
                cred=self.credential(g['kind'])
                sender=self.sender_for(s,g['kind'])
                if not sender:raise ValidationError('발신번호를 설정하세요.')
            for g in groups:
                n=self.new_notice(g['kind'],g['content'],g['title'],g['phone'],g['ref'],g['itemKeys'])
                n.update({k:g[k] for k in ('seller','orderId','products','dueDate','noticeType','fingerprint')})
                n.update(batchToken=token,sender=self.sender_for(s,g['kind']),scheme=cfg['scheme'],account=self.credential(g['kind']).user,configRevision=cfg['configRevision'])
                n.update(shopName=cfg['shopName'],shopRevision=cfg['shopRevision'])
                self.decorate_notice(n,g,s)
                n['sendAuthorizedAt']=now()
                n['sendMode']=plan['input'].get('sendMode','AUTO')
                if window['scheduled']:
                    n['scheduledAt']=window['sendAt']
                    self.transition(n,'SCHEDULED','오전 9시 예약 선택: 한국 시간 '+window['minDueDate']+' 오전 9시 예약 (아직 공급사에 요청하지 않음)')
                s['notices'].append(n)
            s['queuePaused']=False
            if plan['input'].get('deliveryChannel')=='AT':s['aligo']['lastTemplate']=plan['input'].get('aligoTemplate','first')
            elif plan['input'].get('noticeType','delay')!='manual':
                s['settings']['template']=canonical_template(plan['input']['template'],cfg['shopName']);s['settings']['templateType']=plan['input'].get('noticeType','delay')
                ensure_composer_preferences(s['settings'])
                key=plan['input'].get('templateKey')
                expected_type=plan['input'].get('noticeType','delay')
                if key not in TEMPLATE_KEYS or (key if str(key).startswith('soldout') else 'delay')!=expected_type:
                    key=expected_type if expected_type.startswith('soldout') else ('change' if plan['input']['template']==CHANGE else 'first')
                s['settings']['smsTemplates'][key]=canonical_template(plan['input']['template'],cfg['shopName'])
            s['audits'].append({'at':now(),'event':f'사용자가 {len(groups)}건 '+('예약 발송 승인' if window['scheduled'] else '실발송 확인')})
            soldout_items=[]
            if plan['input'].get('noticeType','delay') in {'soldout_card','soldout_bank'}:
                # 2026-10-20 06:05: one item per order row (product/option + seller/orderId/상품주문번호) so the hook can also
                # 주문 취소 접수 (자사몰·에이블리) right after the option OFF. Display dedupes by (product, option) itself.
                rows_by_key={r['key']:r for r in s['rows']}
                for g in groups:
                    for k in g['itemKeys']:
                        r=rows_by_key.get(k)
                        if not r or not str(r.get('product','')).strip():continue
                        ids=[p.get('id') for p in (r.get('orderItems') or []) if p.get('id')] or ([r['orderItemId']] if r.get('orderItemId') else [])
                        soldout_items.append({'product':r['product'],'option':r.get('option',''),'seller':r.get('seller',''),'orderId':r.get('orderId',''),'orderItemIds':[str(i) for i in ids],'qty':r.get('qty',0),
                                              'key':r.get('key',''),'sendAt':window['sendAt'] if window['scheduled'] else ''})   # 2026-10-22: 예약 문자면 주문취소는 전송 10분 전
        # 품절 안내(카드/무통장) 문자를 요청·예약한 즉시 자사몰·에이블리 품절 옵션 처리 (desktop hook; 웹 테스트 모드에서는 없음).
        hook=getattr(self,'soldout_display_hook',None)
        if soldout_items and hook:
            try:hook(soldout_items)
            except Exception:pass
        return {'count':len(groups),'scheduled':window['scheduled'],'scheduledAt':window['sendAt'] if window['scheduled'] else None,
                'message':(window['minDueDate']+f' 오전 9시 예약 {len(groups)}건을 저장했습니다. 프로그램을 켜 두세요.' if window['scheduled'] else '발송 대기열에 저장했습니다. 한 건씩 요청하고 결과를 조회합니다.')} 

    def china_public(self,s):
        """2026-10-22 22:55: 중국 취소건 → 주문 행 표시 (supply_public 전에: 진행상황·수동매칭 원본이 필요)."""
        try:
            from china_cancel import decorate
            return decorate(s)
        except Exception as exc:
            s['chinaCancel']={'error':'중국 취소건 표시 실패: '+str(exc)[:160]}
            return s
    def china_cancel_action(self,p):
        from china_cancel import decide,scan,ChinaCancelError
        a=p.get('action') if isinstance(p,dict) else ''
        try:
            if a=='decide':
                with self.store.edit() as s:return decide(s,p)
            if a=='scan':
                r=scan(self,force=True)
                if r.get('error')=='no folder':raise ValidationError('취소건 폴더를 찾지 못했습니다. 폴더를 연결하세요.')
                return {'message':f"취소건 폴더를 다시 읽었습니다 · 파일 {len(r.get('files') or [])}개 · 새 초록행 {r.get('added',0)}건"+(' · 오류: '+r['error'] if r.get('error') else '')}
        except ChinaCancelError as exc:raise ValidationError(str(exc)) from None
        raise ValidationError('지원하지 않는 중국 취소건 작업입니다.')
    def china_cancel_folder(self,path):
        import os
        if not path or not os.path.isdir(path):raise ValidationError('폴더를 찾지 못했습니다.')
        from china_cancel import init_china,scan
        with self.store.edit() as s:init_china(s)['folder']=str(path);init_china(s)['signature']=''
        r=scan(self,force=True)
        return {'message':f"취소건 폴더를 연결했습니다 · 파일 {len(r.get('files') or [])}개 · 새 초록행 {r.get('added',0)}건"}
    def refund_done(self,p):
        """2026-10-22: 자사몰 환불 대기 주문 → 사장님이 환불완료를 누르면 목록에서 뺀다(이력은 유지)."""
        keys=p.get('keys') if isinstance(p,dict) else None
        if not isinstance(keys,list) or not keys or len(keys)>200 or not all(isinstance(k,str) for k in keys):raise ValidationError('환불완료할 주문을 선택하세요.')
        with self.store.edit() as s:
            hold=refund_hold_keys(s);done=0
            for r in s['rows']:
                if r['key'] in keys and r['key'] in hold:
                    r['refundDoneAt']=now();r['active']=False;r['excludedAt']=now();r['archiveReason']='자사몰 환불완료 (사장님 처리)';r.pop('refundHoldMissing',None);done+=1
            if not done:raise ValidationError('환불 대기 중인 자사몰 주문이 아닙니다.')
            s['audits'].append({'at':now(),'event':f'자사몰 환불완료 {done}건 · 목록에서 제외'})
        return {'count':done,'message':f'환불완료 처리했습니다 · {done}개 상품을 목록에서 뺐습니다.'}

    @staticmethod
    def validate_snapshot(s,n):
        if n.get('returnInvoice'):return  # 반품 안내 문자: no order rows to re-check
        bykey={r['key']:r for r in s['rows']}
        for key in n['itemKeys']:
            r=bykey.get(key)
            if not r or not r['active'] or r['review'] or r['phone']!=n['phone']:
                raise ValidationError('예약/대기 주문이 변경되거나 미출고 목록에서 제외되었습니다. 취소 후 다시 작성하세요.')
        current=[{k:bykey[key][k] for k in ('product','option','qty')} for key in n['itemKeys']]
        if sorted(jskey(x) for x in current)!=sorted(jskey(x) for x in n['products']):
            raise ValidationError('예약/대기 상품 정보가 변경되었습니다. 취소 후 다시 작성하세요.')
        # Do not silently send an old contact if a different item in the order was edited.
        all_rows=[r for r in s['rows'] if r['active'] and (r['seller'],r['orderId'])==(n['seller'],n['orderId'])]
        if any(r['phone']!=n['phone'] for r in all_rows):raise ValidationError('동일 주문 안의 연락처가 변경되었습니다. 취소 후 다시 작성하세요.')

    def queue_control(self,p):
        action=p.get('action')
        with self.store.edit() as s:
            if action=='pause':
                for n in s['notices']:
                    if n['status'] in {'QUEUED','SCHEDULED'}:self.transition(n,'PAUSED','사용자 일시정지 (미요청/예약 시각 보존)')
                s['queuePaused']=True
            elif action in {'cancel','cancel_one'}:
                targets=[n for n in s['notices'] if action=='cancel' or n['id']==p.get('id')]
                if action=='cancel_one' and (len(targets)!=1 or targets[0]['status'] not in {'QUEUED','PAUSED','SCHEDULED'}):
                    raise ValidationError('아직 공급사에 요청하지 않은 예약/대기 작업만 취소할 수 있습니다.')
                for n in targets:
                    if n['status'] in {'QUEUED','PAUSED','SCHEDULED'}:
                        self.transition(n,'CANCELLED','사용자가 미요청/예약 작업을 취소했습니다.')
                        self.resolve_wait_alerts(s,n)
                s['queuePaused']=any(n['status']=='PAUSED' for n in s['notices'])
            elif action=='resume':
                if p.get('confirmed') is not True:raise ValidationError('미요청·예약 작업 이어보내기를 확인하세요.')
                cfg=s['settings'];queued=[n for n in s['notices'] if n['status']=='PAUSED']
                clock=datetime.now(timezone.utc);updates=[]
                for n in queued:
                    checked=dict(n)
                    if n['kind']=='AT':checked['aligoRevision']=s['aligo']['revision']
                    cred=self.validate_send_config(s,checked)
                    target=dispatch_target(n,clock)
                    if n['dueDate'] and n['dueDate']<target.astimezone(KST).date().isoformat():
                        raise ValidationError('예약/대기 작업의 출고 예정일이 발송일보다 빠릅니다. 취소 후 새 예정일로 작성하세요.')
                    self.validate_snapshot(s,n);updates.append((n,target))
                for n,target in updates:
                    n['configRevision']=cfg['configRevision'];n['sendAuthorizedAt']=now()
                    if n['kind']=='AT':n['aligoRevision']=s['aligo']['revision']
                    if not n['isTest'] and target>clock:
                        n['scheduledAt']=target.isoformat(timespec='milliseconds')
                        self.transition(n,'SCHEDULED','사용자가 예약을 이어보내기 승인 (아직 공급사에 요청하지 않음)')
                    else:self.transition(n,'QUEUED','사용자가 미요청 작업을 이어보내기 승인')
                    self.resolve_wait_alerts(s,n)
                s['queuePaused']=False
            else:raise ValidationError('대기열 명령 오류')
        return {'message':'미요청·예약 대기열을 변경했습니다. 이미 접수된 문자는 취소하거나 다시 보내지 않습니다.'}

    def send_one(self):
        clock=datetime.now(timezone.utc)
        def ready(n):
            at=parse_time(n.get('scheduledAt'))
            return n['status']=='QUEUED' or (n['status']=='SCHEDULED' and (not at or at<=clock))
        if not any(ready(n) for n in self.store.read()['notices']):return False
        with self.network_lock:
            with self.store.edit() as s:
                clock=datetime.now(timezone.utc)
                # Legacy/morning jobs retain daytime rules; explicit IMMEDIATE is preserved.
                target=customer_send_time(clock)
                for n in s['notices']:
                    if not n['isTest'] and n.get('sendMode','AUTO')!='IMMEDIATE' and ready(n) and target>clock:
                        n['scheduledAt']=target.isoformat(timespec='milliseconds')
                        self.transition(n,'SCHEDULED','발송 허용시간 밖이므로 한국 시간 '+target.strftime('%Y-%m-%d %H:%M')+'로 예약했습니다.')
                n=next((n for n in s['notices'] if ready(n)),None)
                if not n:return False
                try:
                    cred=self.validate_send_config(s,n)
                    if n['configRevision']!=s['settings']['configRevision']:
                        raise ValidationError('발송 설정이 변경되었습니다.')
                    if n['dueDate'] and n['dueDate']<today():raise ValidationError('대기 중 출고 예정일이 지났습니다. 취소 후 새 예정일로 작성하세요.')
                    if n['status']=='SCHEDULED' and not parse_time(n.get('scheduledAt')):
                        raise ValidationError('예약 시각이 올바르지 않습니다. 취소 후 다시 작성하세요.')
                    self.validate_snapshot(s,n)
                except ValidationError as e:
                    self.transition(n,'PAUSED',str(e));s['queuePaused']=True
                    self.add_alert(s,n,'SEND_PAUSED','warning','미요청/예약 발송을 일시정지했습니다. '+str(e))
                    return False
                self.resolve_wait_alerts(s,n)
                self.transition(n,'SENDING','공급사에 한 번만 요청 중');n['attemptedAt']=now();snap=dict(n)
            result={}
            try:
                result=self.dispatch_notice(snap,cred)
                status,note='PENDING','안내 처리 완료 ('+('알리고 알림톡' if snap['kind']=='AT' else '알리고 문자')+' 접수). 15초 후 1차, 접수 후 총 1분에 2차 결과를 확인합니다. 수신 성공 확정과는 별도입니다.'
            except ProviderError as e:status,note='FAILED',str(e)
            except Exception as e:
                status='UNKNOWN';note=str(e) if isinstance(e,UncertainError) else '예상하지 못한 통신 오류. 재발송 없이 결과를 확인하세요.'
            with self.store.edit() as s:
                live=next(x for x in s['notices'] if x['id']==snap['id']);self.transition(live,status,note)
                if status=='PENDING':
                    live['aligoMid']=result['mid']
                    live['acceptedAt']=now();schedule_check(live)
                elif status=='UNKNOWN':
                    schedule_check(live)
                    self.add_alert(s,live,'REQUEST_UNKNOWN','warning','접수 여부를 확인할 수 없습니다. 자동 재발송하지 않습니다. 이력을 확인하세요.')
                elif status=='FAILED':self.add_alert(s,live,'DELIVERY_FAILED','error',('알리고' if live['kind']=='AT' else '알리고 문자')+'에서 발송 요청이 거절되었습니다. '+note)
                if status in {'FAILED','UNKNOWN'}:
                    for x in s['notices']:
                        if x['status'] in {'QUEUED','SCHEDULED'}:self.transition(x,'PAUSED','앞선 요청 오류로 남은 미요청/예약 작업을 정지했습니다.')
                    s['queuePaused']=True
            return True

    def flag_unconfirmed(self,s,n,checked,reason):
        """Classify missing evidence, never invent a carrier FAILED result.

        Keep underlying PENDING/UNKNOWN state so late results can reconcile and
        identical requests stay blocked. Accepted notices keep due-date history.
        """
        base=parse_time(n.get('acceptedAt') or n.get('attemptedAt'))
        if not base or checked<base+REPORT_DELAY:return
        deadline=base+REPORT_DEADLINE
        n['resultDeadlineAt']=deadline.isoformat(timespec='milliseconds')
        n['resultUnknownReason']=reason
        if checked<deadline:
            n['resultReview']=RESULT_WATCH
            n.setdefault('watchSince',checked.isoformat(timespec='milliseconds'))
            prefix='안내 처리 유지' if n['status']=='PENDING' else '접수 여부 미확인 유지'
            n['note']=prefix+' · 1차 결과 미확인: '+reason+' · 실제 접수/요청 후 총 1분에 2차 확인합니다. 자동 재발송하지 않습니다.'
            self.add_alert(s,n,'RESULT_UNCONFIRMED_15S','warning','15초 1차 결과 미확인 · 추가 확인 중. 접수된 안내는 유지하고 접수 후 총 1분에 2차 확인합니다. 자동 재발송하지 않습니다.')
        else:
            n['resultReview']=RESULT_TIMEOUT
            n.setdefault('timeoutAt',checked.isoformat(timespec='milliseconds'))
            n['note']='발송실패 분류 · 1분 결과 미확인: '+reason+' · 실제 미수신 확정은 아닙니다. 기존 접수 이력은 보존하고 자동 재발송하지 않습니다.'
            for a in s.get('alerts',[]):
                if a['noticeId']==n['id'] and a['code'] in {'RESULT_UNCONFIRMED_12H','RESULT_UNCONFIRMED_15S'} and not a.get('resolvedAt'):a['resolvedAt']=now()
            self.add_alert(s,n,'RESULT_UNCONFIRMED_1M','error','1분 결과 미확인으로 발송실패 칸에 분류했습니다. 실제 전송 실패 확정과는 다릅니다. 공급사 내역을 대조하세요. 자동 재발송하지 않습니다.')

    def poll_sms(self,force=False):
        if not self.network_lock.acquire(blocking=False):
            return {'message':'발송 요청 중입니다. 잠시 후 결과를 확인합니다.'}
        try:
            snapshot=self.store.read();clock=datetime.now(timezone.utc)
            candidates=[]
            for n in snapshot['notices']:
                if n.get('kind') not in {'SMS','LMS'} or n['status'] not in {'PENDING','UNKNOWN'}:continue
                if n.get('provider')!='ALIGO_SMS':continue
                attempted=parse_time(n.get('attemptedAt'));due=report_due(n)
                if not attempted or (not force and (clock-attempted>timedelta(days=7) or (due and clock<due))):continue
                cred=self.creds.get(n['kind'])
                if not cred or n.get('account')!=cred.user:continue
                candidates.append(n)
            candidates=sorted(candidates,key=lambda n:n.get('reportCheckedAt',''))[:30]
            changed=0
            for n in candidates:
                records=[];matches=[];reason='';cred=self.creds[n['kind']]
                try:
                    if not n.get('aligoMid'):
                        reason='알리고 접수 응답에서 메시지 ID를 확보하지 못했습니다. 알리고 전송내역에서 수동 확인하세요.'
                    else:
                        records=self.provider.detail(cred,n['aligoMid'])
                        for row in records:
                            # MID belongs to this one-recipient request. Aligo SMS detail has
                            # no message body, so do NOT borrow the legacy body-based join.
                            if (str(row.get('type','')).upper()==n['kind']
                                    and phone(row.get('receiver'))==n['phone']
                                    and phone(row.get('sender'))==n['sender']
                                    and re.fullmatch(r'[1-9]\d*',str(row.get('mdid','')))):
                                matches.append(row)
                        if len(matches)!=1:
                            reason='메시지 ID 상세 내역에서 수신번호·발신번호·문자 종류가 정확히 일치하는 한 건을 확인하지 못했습니다.'
                except (ProviderError,UncertainError) as exc:
                    reason=safe_text(str(exc),cred)
                with self.store.edit() as current:
                    live=next(x for x in current['notices'] if x['id']==n['id'])
                    if live['status'] not in {'PENDING','UNKNOWN'}:continue
                    checked=datetime.now(timezone.utc)
                    live['reportCheckedAt']=checked.isoformat(timespec='milliseconds');defer_check(live,checked)
                    live['reportRecordCount']=len(records);live['reportMatchCount']=len(matches)
                    if len(matches)==1:
                        row=matches[0];raw=safe_text(row.get('sms_state',''),cred)
                        live['rawResult']=raw;live['aligoDetailId']=str(row['mdid'])
                        status=report_status(row.get('sms_state'),kind=n['kind'])
                        if status in {'DELIVERED','FAILED'}:
                            self.transition(live,status,'알리고 문자 상세 결과 확인: '+raw);changed+=1
                            self.resolve_wait_alerts(current,live)
                            live['resultReview']='RESOLVED';live['resultResolvedAt']=now()
                            live['resultUnknownReason']='';live['nextCheckAt']=None
                            if status=='DELIVERED':live['deliveredAt']=now()
                            else:self.add_alert(current,live,'DELIVERY_FAILED','error','알리고 문자 전송 실패가 확인되었습니다. '+raw)
                        else:reason='알리고 전송 중 또는 아직 확인되지 않은 상태: '+(raw or '(비어 있음)')
                    if live['status'] in {'PENDING','UNKNOWN'}:
                        live['note']='알리고 문자 결과 확인 중. 자동 재발송하지 않습니다. '+reason
                        self.flag_unconfirmed(current,live,checked,reason)
            message=f'알리고 문자 {len(candidates)}건 조회 / {changed}건 최종 확인. 접수 15초·총 1분 조회, 미확정 자동 재발송 없음.'
            with self.store.edit() as s:s['lastPoll']=now();s['pollNote']=message
            return {'message':message}
        finally:self.network_lock.release()

    def manual_result(self,p):
        status=p.get('status');reason=clean(p.get('reason'))
        if status not in {'DELIVERED','FAILED'} or len(reason)<5 or p.get('confirmed') is not True:raise ValidationError('공급사의 최종 결과를 확인한 뒤 근거를 5자 이상 기록하세요.')
        with self.store.edit() as s:
            n=next((n for n in s['notices'] if n['id']==p.get('id')),None)
            if not n or n['status'] not in {'PENDING','UNKNOWN'}:raise ValidationError('결과 미확정 작업만 수동 확인할 수 있습니다.')
            self.transition(n,status,'사용자 수동 확인: '+reason[:500]);n['manual']=True
            self.resolve_wait_alerts(s,n)
            n['resultReview']='RESOLVED';n['resultResolvedAt']=now()
            if status=='FAILED':self.add_alert(s,n,'DELIVERY_FAILED','error','사용자가 최종 전송 실패를 확인했습니다. 해당 안내의 일정 반영을 취소했습니다.')
            if status=='DELIVERED':n['deliveredAt']=now()
            s['audits'].append({'at':now(),'event':'공급사 최종 결과 수동 확인','id':n['id'],'status':status,'reason':reason[:500]})
        return {'message':'공급사 확인 결과를 이력에 기록했습니다.'}

    def has_due_reports(self,clock=None):
        """Local-only due scan; no API call/DB write when nothing is due."""
        clock=clock or datetime.now(timezone.utc)
        for n in self.store.read()['notices']:
            if n.get('kind') not in {'AT','SMS','LMS'} or n['status'] not in {'PENDING','UNKNOWN'}:continue
            attempted=parse_time(n.get('attemptedAt'))
            if not attempted:continue
            if clock-attempted>timedelta(days=7):continue
            due=report_due(n)
            if not due or clock<due:continue
            if n['kind']=='AT':
                cred=self.aligo_cred
                if not cred or n.get('account')!=cred.user or n.get('aligoProfile')!=cred.profile:continue
            else:
                cred=self.creds.get(n['kind'])
                if not cred or n.get('account')!=cred.user:continue
            return True
        return False

    def worker_tick(self):
        # 09:05 CPU 최적화: when the last full tick changed nothing (store revision unchanged) and found nothing to do, the
        # per-second notice/report scan is skipped for WORKER_IDLE_SECONDS. Folder watches/backups keep their own clocks.
        now_clock=time.monotonic()
        if self.store.version==getattr(self,'_idle_version',None) and now_clock<getattr(self,'_idle_until',0):
            if hasattr(self,'inventory_tick'):self.inventory_tick()
            self._worker_housekeeping();return
        before=self.store.version
        try:self.run_pending_platform_pushes()
        except Exception:pass
        self.send_one()
        tick=time.monotonic()
        if tick-self.last_poll_clock>=WORKER_REPORT_INTERVAL and self.has_due_reports():
            self.last_poll_clock=tick
            self.poll()
        if self.store.version==before:self._idle_version=before;self._idle_until=time.monotonic()+WORKER_IDLE_SECONDS
        else:self._idle_version=None
        self._worker_housekeeping()
    def _worker_housekeeping(self):
        self.sweep_fallback_sms()
        self.ship_delay_alert()
        # Keep the pre-existing backup interval, not every 1 or 10 seconds.
        tick=time.monotonic()
        if tick-self.last_backup_clock>=WORKER_BACKUP_INTERVAL:
            self.last_backup_clock=tick
            self.store.backup();self.backup_desktop()

    def ship_delay_alert(self):
        """Once per Tuesday: red alert when its 출고장 is still missing on Wednesday 18:00 (the dialog asks the details)."""
        tick=time.monotonic()
        if tick-getattr(self,'_ship_delay_tick',-1e9)<60:return
        self._ship_delay_tick=tick
        try:
            from supply_workflow import ship_delay_question
            q=ship_delay_question((self.store.read().get('supply') or {}))
            if not q or q['tuesday'] in (self.store.read().get('supply',{}).get('shipDelayAlerted') or []):return
            with self.store.edit() as s:s.setdefault('supply',{}).setdefault('shipDelayAlerted',[]).append(q['tuesday']);del s['supply']['shipDelayAlerted'][:-20]
            d=date.fromisoformat(q['tuesday'])
            self.add_job_alert(f'{d.month}/{d.day}(화) 출고장 없음 · 출고 확인 필요',f'수요일 오후 6시까지 {d.month}/{d.day} 화요일 출고장이 들어오지 않았습니다. 앱 창의 질문에서 출고 진행 여부와 다음 출고일(금요일/토요일)을 알려주세요.','error')
        except Exception:pass
    def sweep_fallback_sms(self):
        """Mark 알림톡 failures whose 문자 대체 went out as 정상 안내, once, with a history line."""
        version=getattr(self.store,'version',None)
        if version is not None and version==getattr(self,'_fallback_sweep_version',object()):return 0
        s=self.store.read();by_id={n['id']:n for n in s['notices']}
        todo=[n['id'] for n in s['notices'] if fallback_sms_ok(n,by_id) and not n.get('fallbackSmsOk')]
        if todo:
            with self.store.edit() as s:
                by_id={n['id']:n for n in s['notices']}
                for nid in todo:
                    n=by_id.get(nid)
                    if not n or not fallback_sms_ok(n,by_id) or n.get('fallbackSmsOk'):continue
                    reason=''
                    try:reason=json.loads(n.get('rawResult') or '{}').get('rslt_message','')
                    except (ValueError,TypeError,AttributeError):reason=''
                    stamp=now();n['fallbackSmsOk']=True;n['fallbackSmsAt']=stamp
                    note=f"알림톡 불가{('('+reason+')') if reason else ''}로 문자(알리고 LMS)로 안내됨 · 정상 안내로 처리"
                    n.setdefault('events',[]).append({'at':stamp,'status':n['status'],'note':note});n['note']=note
                    for a in s.get('alerts',[]):
                        if a.get('noticeId')==nid and a.get('code')=='DELIVERY_FAILED' and not a.get('resolvedAt'):a['resolvedAt']=stamp
        self._fallback_sweep_version=getattr(self.store,'version',None)
        return len(todo)

    def start_worker(self):
        self.supply_watcher.start()
        def work():
            while not self.stop.is_set():
                try:
                    self.worker_tick()
                except Exception:
                    # Never retry the last send after a programming/storage error.
                    with self.store.edit() as s:
                        for n in s['notices']:
                            if n['status']=='SENDING':self.transition(n,'UNKNOWN','처리 중 오류. 재발송 없이 확인 필요.')
                            elif n['status'] in {'QUEUED','SCHEDULED'}:self.transition(n,'PAUSED','처리 오류로 미요청/예약 대기열 정지')
                        s['pollNote']='작업 오류가 발생해 미요청 작업을 정지했습니다. 기록을 확인하세요.'
                self.stop.wait(WORKER_REPORT_INTERVAL)
        self.thread=threading.Thread(target=work,daemon=True);self.thread.start()

    def stop_worker(self):
        self.stop.set()
        self.supply_watcher.join()
        if self.thread:self.thread.join(timeout=25)
        if not self.thread or not self.thread.is_alive():self.backup_desktop(force=True,reason='shutdown')

    def export_csv(self):
        out=io.StringIO();w=csv.writer(out);w.writerow(['기록ID','종류','테스트','판매처','주문번호','수신번호','출고예정일','요청시각UTC','전송상태','성공확인시각UTC','결과원문','안내문','비고','접수시각UTC','다음조회시각UTC','예약시각','예약승인시각UTC','안내종류','발송방식','결과확인단계','1분확인시각','미확인사유','알리고mid','알림톡템플릿','대체원안내ID','대체문자ID','대체보류사유'])
        def cell(x):
            v=str(x or '')
            return "'"+v if v.lstrip().startswith(('=','+','-','@')) or v.startswith(('\t','\r')) else v
        for n in self.store.read()['notices']:
            w.writerow([cell(v) for v in [n['id'],n['kind'],n['isTest'],n['seller'],n['orderId'],n['phone'],n['dueDate'],n.get('attemptedAt'),n['status'],n.get('deliveredAt'),n.get('rawResult'),n['content'],n.get('note'),n.get('acceptedAt'),n.get('nextCheckAt'),n.get('scheduledAt'),n.get('sendAuthorizedAt'),n.get('noticeType','delay'),n.get('sendMode','AUTO'),n.get('resultReview',''),n.get('resultDeadlineAt',''),n.get('resultUnknownReason',''),n.get('aligoMid',''),n.get('aligoCode',''),n.get('fallbackOf',''),n.get('fallbackId',''),n.get('fallbackReason','')]])
        return ('\ufeff'+out.getvalue()).encode('utf-8')
