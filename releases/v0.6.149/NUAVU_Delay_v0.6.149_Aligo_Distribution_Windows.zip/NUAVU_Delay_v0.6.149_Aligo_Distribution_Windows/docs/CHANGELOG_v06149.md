# NUAVU_Delay_v0.6.149_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06148.md

## 2026-11-09 22:36 사장님 (배포 대상: 0.6.148 → 0.6.149) — 누아브판 0.6.160 이식: CPU 최적화 (patch/apply_06160_cpu.py, 공용)
- supply_workflow 상품명 정규화 lru_cache(frozenset), public_state 주문키→안내 색인, desktop_backup 수시 백업 15분 간격·보관 12개, WORKER_BACKUP_INTERVAL 1800. 테스트 tests/test_cpu_06149.py (8)
