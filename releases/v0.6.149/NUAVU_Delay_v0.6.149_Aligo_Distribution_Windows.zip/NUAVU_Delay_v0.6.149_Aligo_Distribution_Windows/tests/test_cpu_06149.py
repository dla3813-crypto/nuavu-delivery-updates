"""v0.6.160 (2026-11-09 22:36 사장님 "cpu 사용률 왤케 높냐"): 상품명 정규화 캐시 + 바탕화면(iCloud) 백업 빈도·보관 축소."""
import sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from supply_workflow import product_forms,same_product,shared_product,norm,product_name,match_product_name,_product_forms_str
from domain import Store,WORKER_BACKUP_INTERVAL
import desktop_backup
from desktop_backup import DesktopBackup

class NameCacheTests(unittest.TestCase):
    def test_forms_are_frozen_and_cached(self):
        a=product_forms('(NA-1)[2color]로아 베이지 코트');b=product_forms('(NA-1)[2color]로아 베이지 코트')
        self.assertIsInstance(a,frozenset);self.assertIs(a,b);self.assertEqual(a,frozenset({'로아베이지코트'}))
    def test_semantics_unchanged(self):
        self.assertTrue(same_product('[2color]스타 버니 패치 팬츠','스타 버니 패치 팬츠'))
        self.assertTrue(shared_product(['S6 [긴팔] 가디건','긴팔 가디건']));self.assertFalse(shared_product(['코트','팬츠']))
        self.assertEqual(norm(None),'');self.assertEqual(norm(12.0),norm('12.0'));self.assertEqual(product_name('[긴팔] 가디건'),'가디건');self.assertEqual(match_product_name('(2colors) S6 코트'),'코트')
    def test_cache_hit_counter_grows(self):
        before=_product_forms_str.cache_info().hits
        for _ in range(5):product_forms('캐시 확인용 상품명')
        self.assertGreaterEqual(_product_forms_str.cache_info().hits-before,4)

class BackupThrottleTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(self.tmp.name)
        self.archive=DesktopBackup(self.store,Path(self.tmp.name)/'Desktop/배송지연(AI)')
        self.clock=[1000.0];desktop_backup._monotonic=lambda:self.clock[0]
    def tearDown(self):self.tmp.cleanup()
    def files(self):return sorted(p.name for p in self.archive.folder.glob('백업-*.sqlite3'))
    def bump(self):
        with self.store.edit() as s:s['pollNote']=str(self.clock[0])
    def test_frequent_forced_backups_are_throttled_to_15_minutes(self):
        self.archive.run(force=True,reason='before-import');self.assertEqual(len(self.files()),1)
        self.clock[0]+=60;self.bump();self.archive.run(force=True,reason='after-import');self.assertEqual(len(self.files()),1)   # 1분 뒤 → 건너뜀
        self.assertEqual(self.archive.status().get('skipped'),'after-import')
        self.clock[0]+=15*60;self.bump();self.archive.run(force=True,reason='ably-push');self.assertEqual(len(self.files()),2)   # 15분 지나면 저장
    def test_manual_and_shutdown_are_immediate(self):
        self.archive.run(force=True,reason='periodic');self.clock[0]+=5;self.bump()
        self.archive.run(force=True,reason='manual');self.clock[0]+=5;self.bump();self.archive.run(force=True,reason='shutdown')
        self.assertEqual(len(self.files()),3)
    def test_first_backup_of_day_not_throttled(self):
        self.archive.run(force=True,reason='after-import');self.assertEqual(len(self.files()),1)   # 일별 파일 없으면 즉시
    def test_retention_keeps_12(self):
        for i in range(15):
            self.clock[0]+=16*60;self.bump();self.archive.run(force=True,reason='after-import')
        self.assertEqual(len(self.files()),12)
    def test_periodic_interval_is_30_minutes(self):self.assertEqual(WORKER_BACKUP_INTERVAL,1800.0)

if __name__=='__main__':unittest.main()
