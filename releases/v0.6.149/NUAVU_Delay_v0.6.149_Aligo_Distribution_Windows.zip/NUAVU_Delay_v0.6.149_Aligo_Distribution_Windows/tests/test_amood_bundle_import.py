"""[배포판 이식본] v0.6.149 (2026-11-02): 아무드 묶음(추가옵션) 주문 — 같은 주문번호·같은 상품주문번호(M열)가 옵션만 다른
여러 줄이면 오류 대신 한 주문상품으로 합친다 (실제 사례: 팬츠 '[아이보리-팬츠만 구매]' + '★[레이어드 스커트]★').
에이블리는 줄마다 상품주문번호가 다르므로 기존 검사(서로 다른 주문상품에 같은 번호 → 오류)를 유지한다."""
import sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from domain import Store,Engine,ValidationError,SELLERS,today
from clock_helper import install_day_clock

class FakeProvider:
    def send(self,*a,**k):return 1
    def remaining(self,*a):return '0'
    def report(self,*a):return []

def amood(option,qty=1,detail='7694357',order='2338578',product='[2color]스타 버니 패치 코튼 와이드 롱 팬츠',phone='01000009999'):
    return dict(seller='누아브 아무드',orderId=order,product=product,option=option,qty=qty,orderDate=today(),orderTimestamp=today()+' 16:50:27',
                buyer='고객',recipient='',phone=phone,phoneSource='주문자',needsPhoneApproval=False,
                orderItemId=detail,orderItems=[{'id':detail,'qty':qty}],orderItemIdMapped=True,exportOrderItemIds=[detail],
                exportContacts={'recipientMobile':phone,'recipientPhone':'','buyerPhone':'','buyerMobile':phone})

class AmoodBundle(unittest.TestCase):
    def setUp(self):
        install_day_clock(self)
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(self.tmp.name);self.engine=Engine(self.store,FakeProvider())
        with self.store.edit() as s:s['settings']['shopName']='누아브'   # 배포판: 판매처 이름을 쇼핑몰 이름으로 정규화하므로 필요
    def tearDown(self):
        try:self.engine.stop.set()
        except Exception:pass
        self.tmp.cleanup()
    def rows(self):return [r for r in self.store.read()['rows'] if r['seller']=='누아브 아무드']

    def test_real_case_merges_into_one_item(self):
        res=self.engine.import_rows({'rows':[amood('[아이보리-팬츠만 구매]'),amood('★[레이어드 스커트]★')],'mode':'merge'})
        rows=self.rows();self.assertEqual(len(rows),1)
        r=rows[0]
        self.assertEqual(r['option'],'[아이보리-팬츠만 구매] + ★[레이어드 스커트]★')
        self.assertEqual(r['qty'],1)
        self.assertEqual(r['orderItems'],[{'id':'7694357','qty':1}]);self.assertEqual(r['orderItemId'],'7694357')
        self.assertEqual(r.get('exportOrderItemIds',['7694357']),['7694357'])   # 배포판 행에는 exportOrderItemIds 가 없음(누아브판 전용 필드)
        self.assertEqual(res['amoodBundled'],1);self.assertEqual(res['added'],1)

    def test_snapshot_mode_same_file_twice_is_stable(self):
        p={'rows':[amood('[아이보리-팬츠만 구매]'),amood('★[레이어드 스커트]★')],'mode':'snapshot','scope':SELLERS,'replaceConfirmed':True}
        self.engine.import_rows(p);first=self.rows()[0]['key']
        res=self.engine.import_rows(p);rows=self.rows()
        self.assertEqual([r['key'] for r in rows if r['active']],[first]);self.assertEqual(res['updated'],1);self.assertEqual(res['added'],0)

    def test_different_phone_rejected(self):
        with self.assertRaises(ValidationError):
            self.engine.import_rows({'rows':[amood('[아이보리-팬츠만 구매]'),amood('★[레이어드 스커트]★',phone='01000001111')],'mode':'merge'})

    def test_distinct_detail_ids_stay_separate(self):
        self.engine.import_rows({'rows':[amood('아이보리',detail='111'),amood('블랙',detail='222')],'mode':'merge'})
        self.assertEqual(len(self.rows()),2)

    def test_ably_duplicate_detail_still_rejected(self):
        a=amood('아이보리');b=amood('블랙')
        for x in (a,b):x['seller']='누아브 에이블리'
        with self.assertRaises(ValidationError) as cm:self.engine.import_rows({'rows':[a,b],'mode':'merge'})
        self.assertIn('에이블리 상품주문번호',str(cm.exception))

    def test_three_lines_and_quantity(self):
        self.engine.import_rows({'rows':[amood('팬츠만 구매',qty=2),amood('레이어드 스커트'),amood('벨트')],'mode':'merge'})
        rows=self.rows();self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['option'],'팬츠만 구매 + 레이어드 스커트 + 벨트');self.assertEqual(rows[0]['qty'],2)
        self.assertEqual(rows[0]['orderItems'],[{'id':'7694357','qty':2}])

if __name__=='__main__':unittest.main()
