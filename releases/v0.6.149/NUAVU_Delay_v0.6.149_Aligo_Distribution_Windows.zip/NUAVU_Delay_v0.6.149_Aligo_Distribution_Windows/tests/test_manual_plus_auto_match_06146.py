"""배포판 v0.6.149 (2026-11-05 20:52 사장님, 누아브판 0.6.157 이식): 수동 매칭이 저장돼 있어도 같은 상품의 자동 후보를 함께 연결.
사례: 로아 베이지 사선 더블 블랙 후드 숏 코트 자켓 [One Color-FREE] — 출고장(컬러 M·사이즈 M)만 수동 매칭돼 있고
진행상황(One Color·M)은 같은 주문건인데 연결되지 않던 문제. 원컬러/FREE 주문은 컬러·사이즈가 무엇이든 같은 상품명이면 연결."""
import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from supply_workflow import candidates,auto_added_variants,automatic_candidates,variant_id,order_signature

def variant(product,color,size,brand='N',kind='manifest',qty=5,ship='2026-10-31',office='2026-10-29'):
    r={'brand':brand,'product':product,'color':color,'size':size,'qty':qty,'sheet':'출고장','line':1,'sourceFile':'f.xlsx','kind':kind,
       'shipDate':ship if kind=='manifest' else '','basisDate':'' if kind=='manifest' else office,'officeDate':office,'officeRaw':office,'purchaseDate':'','basisType':kind}
    r['variant']=variant_id(r);return r

ROA='로아 베이지 사선 더블 블랙 후드 숏 코트 자켓'
class ManualPlusAuto(unittest.TestCase):
    def setUp(self):
        self.row={'product':ROA,'option':'[One Color-FREE]','qty':1}
        self.manifest=variant(ROA,'M','M');self.progress=variant(ROA,'One Color','M',kind='progress')
        self.other=variant('다른 코트 자켓','One Color','M',kind='progress')
        self.vs=[self.manifest,self.progress,self.other]
    def test_onecolor_free_auto_matches_any_color_size(self):
        hits,amb,how=candidates(self.row,self.vs,{})
        self.assertEqual({h['variant'] for h in hits},{self.manifest['variant'],self.progress['variant']});self.assertFalse(amb);self.assertEqual(how,'automatic')
    def test_manual_rule_now_also_includes_auto_hits(self):
        maps={order_signature(self.row):[self.manifest['variant']]}
        hits,amb,how=candidates(self.row,self.vs,maps)
        self.assertEqual([h['variant'] for h in hits],[self.manifest['variant'],self.progress['variant']]);self.assertEqual(how,'manual');self.assertFalse(amb)
        self.assertEqual(auto_added_variants(self.row,self.vs,maps),[self.progress['variant']])
    def test_exclusion_rule_still_connects_nothing(self):
        maps={order_signature(self.row):[]}
        hits,amb,how=candidates(self.row,self.vs,maps);self.assertEqual(hits,[]);self.assertEqual(how,'manual')
        self.assertEqual(auto_added_variants(self.row,self.vs,maps),[])
    def test_auto_hit_of_different_product_not_added_to_manual(self):
        """수동 선택이 다른 상품명(포함 매칭으로 잡힌 것)이라면 그 상품과 이름이 겹치는 행만 더한다."""
        row={'product':'(NA-1)[2color]'+ROA,'option':'[원컬러-FREE]','qty':1}
        maps={order_signature(row):[self.other['variant']]}   # 사장님이 일부러 다른 이름의 행을 골랐을 때
        hits,amb,how=candidates(row,self.vs,maps)
        self.assertEqual([h['variant'] for h in hits],[self.other['variant']])   # 로아 행들은 이름이 안 겹치므로 안 더함
    def test_manual_specific_color_order_adds_only_compatible_rows(self):
        row={'product':ROA,'option':'[블랙-M]','qty':1}
        black_m=variant(ROA,'블랙','M');black_l=variant(ROA,'블랙','L');white_m=variant(ROA,'화이트','M')
        maps={order_signature(row):[white_m['variant']]}   # 사장님이 화이트 M을 수동 연결 (컬러 다른 행)
        hits,amb,how=candidates(row,[black_m,black_l,white_m],maps)
        self.assertEqual({h['variant'] for h in hits},{white_m['variant'],black_m['variant']})   # 자동 규칙에 맞는 블랙 M만 추가, 블랙 L은 아님
    def test_manual_rule_with_unknown_variant_only(self):
        maps={order_signature(self.row):['variant-that-vanished']}
        hits,amb,how=candidates(self.row,self.vs,maps);self.assertEqual(how,'automatic');self.assertEqual({h['variant'] for h in hits},{self.manifest['variant'],self.progress['variant']})   # 2026-11-09: 수동 행이 다 사라지면 자동으로
    def test_automatic_candidates_helper(self):
        hits,amb=automatic_candidates(self.row,self.vs);self.assertEqual(len(hits),2);self.assertFalse(amb)

if __name__=='__main__':unittest.main()
