"""배포판 v0.6.149 (2026-11-05 21:10 사장님, 누아브판 0.6.157 이식): 중국어 컬러 발주 행은 자동으로 붙이지 않고 '수동매칭 권장'에 — 이미 매칭된 주문이라도."""
import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from supply_workflow import candidates,manual_color_recommendations,variant_id

def variant(product,color,size,brand='N',kind='progress',qty=5,office=''):
    r={'brand':brand,'product':product,'color':color,'size':size,'qty':qty,'sheet':'진행상황','line':1,'sourceFile':'f.xlsx','kind':kind,
       'shipDate':'','basisDate':office,'officeDate':office,'officeRaw':office,'purchaseDate':'','basisType':kind}
    r['variant']=variant_id(r);return r

P='웰론 후드 경량 패딩'
class ChineseColorRecommendation(unittest.TestCase):
    def setUp(self):
        self.gray=variant(P,'그레이','3XL');self.cn=variant(P,'灰色','3XL');self.black=variant(P,'블랙','3XL');self.cn4=variant(P,'灰色','4XL')
        self.vs=[self.gray,self.cn,self.black,self.cn4];self.row={'product':P,'option':'[그레이-3XL]','qty':1}
    def test_chinese_row_not_auto_matched(self):
        hits,amb,how=candidates(self.row,[self.cn],{});self.assertEqual(hits,[])
    def test_matched_order_recommends_only_chinese_excluding_connected(self):
        hits,amb,how=candidates(self.row,self.vs,{});self.assertEqual([h['variant'] for h in hits],[self.gray['variant']])
        rec=manual_color_recommendations(self.row,self.vs,exclude={h['variant'] for h in hits},only_chinese=True)
        self.assertEqual([r['variant'] for r in rec],[self.cn['variant']]);self.assertIn('중국어 컬러 번역 확인',rec[0]['reason'])
    def test_unmatched_order_keeps_similar_color_recommendation(self):
        ivory=variant(P,'아이보리','3XL');cnw=variant(P,'白色','3XL')
        rec=manual_color_recommendations({'product':P,'option':'[화이트-3XL]','qty':1},[ivory,cnw])
        self.assertEqual({r['variant'] for r in rec},{ivory['variant'],cnw['variant']})
        rec=manual_color_recommendations({'product':P,'option':'[화이트-3XL]','qty':1},[ivory,cnw],only_chinese=True)
        self.assertEqual([r['variant'] for r in rec],[cnw['variant']])

if __name__=='__main__':unittest.main()
