import copy
import io
import json
import zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from xml.etree import ElementTree as ET

import pytest
from app import Handler
from desktop import DesktopAPI
from domain import ValidationError
from helpers import Base
from order_export import HEADERS,SECTIONS,export_orders,values,recipient_mobile,workbook_bytes
from test_supply_regression import order
from workbook_reader import read_xlsx

CONTACTS=dict(recipientMobile='010-0000-0011',recipientPhone='02-000-1111',
              buyerPhone='02-000-2222',buyerMobile='010-0000-0022',sellerLabel='데모스토어 에이블리')

class OrderExportTests(Base):
    def setUp(self):
        super().setUp()
        with self.store.edit() as s:s['rows']=[]
        self.engine.import_rows({'rows':[order(1)|{'recipient':'가상 수령자','orderTimestamp':'2026-10-13 09:20:00','exportContacts':CONTACTS},
                                         order(2,product='두 번째 상품')]})

    def payload(self,section='white',keys=None):
        state=self.engine.public_state()
        return dict(keys=keys or [r['key'] for r in state['rows']],revision=state['revision'],section=section)

    def test_exact_template_headers_order_values_and_contacts(self):
        result=export_orders(self.engine,self.payload())
        rows=read_xlsx(result['data'])[0]['rows']
        assert result['name']=='안내 전_1014.xlsx'
        assert rows[0]==HEADERS and len(rows)==3
        assert rows[1][:9]==['가디건/아이보리 / FREE',1,'2026.10.13/09:20:00','가상 수령자',
                             '010-0000-0011','데모스토어 에이블리','02-000-2222','010-0000-0022','TEST-001']
        assert result['missingContacts']==0

    def test_filenames_follow_every_section_and_risk_stage(self):
        for section,label in SECTIONS.items():
            payload=self.payload(section)
            if section=='delay_risk':payload['riskStage']='watch';label+='_감시'
            assert export_orders(self.engine,payload)['name']==label+'_1014.xlsx'
        assert export_orders(self.engine,self.payload('delay_risk')|{'riskStage':'confirmed'})['name']=='예정일 초과 예상_확정_1014.xlsx'

    def test_selected_keys_preserve_screen_order_and_do_not_export_other_orders(self):
        keys=self.payload()['keys'][::-1]
        result=export_orders(self.engine,self.payload(keys=keys[:1]))
        rows=read_xlsx(result['data'])[0]['rows']
        assert len(rows)==2 and rows[1][0].startswith('두 번째 상품/')

    def test_export_reads_current_notice_and_actual_supply_basis(self):
        key=self.payload()['keys'][0]
        self.engine.external_manual({'keys':[key],'dueDate':'2026-10-21'})
        rows=read_xlsx(export_orders(self.engine,self.payload())['data'])[0]['rows']
        assert rows[1][10]=='10월 21일' and rows[1][11]=='' and rows[1][12]=='매칭 필요'  # v0.6.149: J=상세주문번호
        r=self.engine.public_state()['rows'][0]
        r.update(dispatchStart='2026-10-21',dispatchEnd='2026-10-22',supplyInfo={'manifestQty':1,'plannedQty':1,'allocatedQty':2})
        assert values(r,'데모스토어')[11:]==['10월 21일 ~ 10월 22일','출고장 + 진행상황']

    def test_phone_order_numbers_and_formula_like_product_are_literal_text(self):
        with self.store.edit() as s:
            s['rows'][0]['orderId']='0001234567890123456789';s['rows'][0]['product']='=HYPERLINK("http://example.invalid")';s['rows'][0]['option']='@literal'
        data=export_orders(self.engine,self.payload())['data']
        rows=read_xlsx(data)[0]['rows']
        assert rows[1][8]=='0001234567890123456789' and rows[1][0].startswith('=HYPERLINK')
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            sheet=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
            assert not sheet.findall('.//m:f',ns)
            assert sheet.find('.//m:c[@r="I2"]',ns).get('t')=='inlineStr'

    def test_exact_template_font_fill_widths_row_heights_and_borders(self):
        data=export_orders(self.engine,self.payload())['data']
        ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            sheet=ET.fromstring(z.read('xl/worksheets/sheet1.xml'));styles=ET.fromstring(z.read('xl/styles.xml'))
            assert [float(c.get('width')) for c in sheet.find('m:cols',ns)][:13]==[43.1640625,8.33203125,15.6640625,10.33203125,15,13.5,12.5,12,15.5,15.5,16.33203125,16.33203125,14.1640625]
            assert all(float(r.get('ht'))==15 for r in sheet.find('m:sheetData',ns))
            xfs=styles.find('m:cellXfs',ns)
            for cell in sheet.findall('.//m:c',ns):
                xf=xfs[int(cell.get('s','0'))];font=styles.find('m:fonts',ns)[int(xf.get('fontId'))]
                assert font.find('m:name',ns).get('val')=='굴림' and font.find('m:sz',ns).get('val')=='9'
                border=styles.find('m:borders',ns)[int(xf.get('borderId'))]
                assert all(border.find('m:'+side,ns).get('style')=='thin' for side in ('left','right','top','bottom'))
            xf=xfs[int(sheet.find('.//m:c[@r="A1"]',ns).get('s'))]
            fill=styles.find('m:fills',ns)[int(xf.get('fillId'))]
            assert fill.find('m:patternFill/m:fgColor',ns).get('rgb').endswith('CCFFCC')

    def test_bad_requests_stale_revision_and_duplicate_keys_rejected(self):
        payload=self.payload()
        for changes in ({'keys':[]},{'keys':[payload['keys'][0]]*2},{'keys':['missing']},{'keys':[{}]},
                        {'section':'../secret'},{'revision':-1},{'section':'delay_risk','riskStage':'other'}):
            with pytest.raises(ValidationError):export_orders(self.engine,payload|changes)

    def test_export_is_readonly_and_sends_nothing(self):
        before=copy.deepcopy(self.store.read());export_orders(self.engine,self.payload('charcoal'))
        assert self.store.read()==before and not self.fake.sent and not self.at.sent

    def test_contacts_import_validation_and_restart(self):
        self.restart();assert self.store.read()['rows'][0]['exportContacts']==CONTACTS
        for value in ({'bad':'data'},{'buyerPhone':123},{'buyerPhone':'x'*1501},[]):
            with pytest.raises(ValidationError):self.engine.import_rows({'rows':[order(3)|{'exportContacts':value}]})

    def test_http_download_authenticated_post_only(self):
        body=json.dumps(self.payload()).encode();handler=object.__new__(Handler);responses=[]
        handler.server=SimpleNamespace(engine=self.engine,origin='http://127.0.0.1:1234',token='secret')
        handler.headers={'Host':'127.0.0.1:1234','Content-Type':'application/json','Origin':handler.server.origin,
                         'X-NUAVU-Token':'secret','Content-Length':str(len(body))}
        handler.path='/api/order-export';handler.rfile=io.BytesIO(body)
        handler.respond=lambda *a,**kw:responses.append((a,kw));handler.do_POST()
        args,_=responses[-1];assert args[0]==200 and args[1][:2]==b'PK' and args[3]['X-Export-Count']=='2'
        handler.headers['X-NUAVU-Token']='bad';handler.rfile=io.BytesIO(body);handler.do_POST()
        assert responses[-1][0][0]==403

    def native(self,path=None):
        view=SimpleNamespace(FileDialog=SimpleNamespace(SAVE='save'))
        class Window:
            def get_current_url(self):return 'http://127.0.0.1:1234/'
            def create_file_dialog(self,*a,**kwargs):self.options=kwargs;return str(path) if path else None
        api=DesktopAPI(self.engine,'token','http://127.0.0.1:1234',view);api._window=Window()
        return api

    def test_native_save_dialog_uses_section_filename_and_xlsx_bytes(self):
        path=Path(self.tmp.name)/'품절 안내_1014.xlsx';api=self.native(path)
        result=api.save_export('token','orders',self.payload('charcoal'))
        assert result['saved'] and api._window.options['save_filename']=='품절 안내_1014.xlsx'
        assert read_xlsx(path.read_bytes())[0]['rows'][0]==HEADERS
        assert path.stat().st_mode&0o777==0o600

    def test_native_cancel_wrong_extension_and_auth_do_not_write(self):
        assert self.native().save_export('token','orders',self.payload())=={'saved':False}
        path=Path(self.tmp.name)/'bad.csv';api=self.native(path)
        assert 'error' in api.save_export('token','orders',self.payload()) and not path.exists()
        assert 'error' in api.save_export('bad','orders',self.payload()) and not path.exists()


    def test_older_orders_put_notice_mobile_in_recipient_column_without_reimport(self):
        row=self.engine.public_state()['rows'][1]
        assert not row.get('exportContacts') and row['phone']
        assert values(row,'')[4]==recipient_mobile(row) and recipient_mobile(row)
        assert '수령자전화' not in HEADERS and len(HEADERS)==13 and HEADERS[9]=='상세주문번호'

    def test_filter_covers_headers_and_all_94_orders(self):
        row=values(self.engine.public_state()['rows'][0],'')
        for count in (1,94):
            with zipfile.ZipFile(io.BytesIO(workbook_bytes([row]*count))) as z:
                sheet=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
                assert sheet.find('m:autoFilter',ns).get('ref')==f'A1:M{count+1}'
                dimension=sheet.find('m:dimension',ns)
                assert dimension is None or dimension.get('ref')==f'A1:M{count+1}'
                assert len(sheet.find('m:sheetData',ns))==count+1

    def test_missing_mobile_count_uses_actual_exported_cell(self):
        with self.store.edit() as s:
            s['rows'][0]['exportContacts']={};s['rows'][0]['phone']=''
        result=export_orders(self.engine,self.payload())
        assert result['missingContacts']==1
        assert read_xlsx(result['data'])[0]['rows'][1][4]==''

    def test_finder_reveals_only_saved_file_and_uses_chosen_name(self):
        path=Path(self.tmp.name)/'직접 고른 파일명.xlsx';api=self.native(path)
        result=api.save_export('token','orders',self.payload())
        assert result['name']==path.name and result['revealId'] and 'path' not in result
        with patch('desktop.sys.platform','darwin'),patch('desktop.IS_MAC',True),patch('platform_support.IS_MAC',True),patch('platform_support.subprocess.run') as opened:
            assert api.reveal_export('token',result['revealId'])=={'opened':True}
            assert opened.call_args.args[0]==['/usr/bin/open','-R',str(path)]
            assert 'shell' not in opened.call_args.kwargs
            assert api.open_export('token',result['revealId'])=={'opened':True}
            assert opened.call_args.args[0]==['/usr/bin/open',str(path)]
            assert 'shell' not in opened.call_args.kwargs

    def test_finder_rejects_unknown_identifier_bad_auth_and_missing_files(self):
        path=Path(self.tmp.name)/'saved.xlsx';api=self.native(path)
        result=api.save_export('token','orders',self.payload())
        with patch('desktop.subprocess.run') as opened:
            for token,ident in [('bad',result['revealId']),('token','/etc/passwd'),('token',None)]:
                assert 'error' in api.reveal_export(token,ident)
                assert 'error' in api.open_export(token,ident)
            path.unlink();assert 'error' in api.reveal_export('token',result['revealId'])
            assert 'error' in api.open_export('token',result['revealId'])
            opened.assert_not_called()

    def test_finder_failure_is_reported_and_no_open_occurs_during_save(self):
        path=Path(self.tmp.name)/'saved.xlsx';api=self.native(path)
        with patch('desktop.subprocess.run',side_effect=OSError()) as opened,patch('desktop.sys.platform','darwin'):
            result=api.save_export('token','orders',self.payload());opened.assert_not_called()
            assert 'error' in api.reveal_export('token',result['revealId'])
            assert 'error' in api.open_export('token',result['revealId'])


@pytest.mark.parametrize('row,expected',[
    ({'phone':'01012345678','phoneSource':'주문자'},'010-1234-5678'),
    ({'phone':'01012345678','phoneSource':'수령자 대체'},'010-1234-5678'),
    ({'phone':'01012345678','exportContacts':{'recipientMobile':'010-9999-8888'}},'010-9999-8888'),
    ({'phone':'01012345678','exportContacts':{'recipientPhone':'010-9999-8888'}},'010-9999-8888'),
    ({'phone':'01012345678','exportContacts':{'recipientMobile':'','recipientPhone':'02-123-4567'}},'010-1234-5678'),
    ({'phone':'','exportContacts':{'buyerMobile':'+82 10-9999-8888'}},'010-9999-8888'),
    ({'phone':'','exportContacts':{'buyerPhone':'0111234567'}},'011-123-4567'),
    ({'phone':'02-123-4567','exportContacts':{'recipientMobile':'010-****-8888'}},''),
    ({'phone':''},''),
])
def test_export_mobile_priority_and_missing_numbers(row,expected):
    assert recipient_mobile(row)==expected
