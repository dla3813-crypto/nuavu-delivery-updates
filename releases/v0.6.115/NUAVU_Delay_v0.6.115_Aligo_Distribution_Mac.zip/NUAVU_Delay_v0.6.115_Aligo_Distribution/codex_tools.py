"""배송안내 · Codex 앱 도구 (2026-10-25 요청: '기존 앱 기능을 AI가 호출할 도구로 연결').

Codex app-server 의 dynamicTools 로 등록하고, Codex 가 item/tool/call 로 부르면 이 앱이 실행해 결과(JSON)를 돌려준다.
- 화면 도구(ui): 상태 필터·카드 숫자·주문 검색·자동 불러오기 버튼처럼 앱 화면(app.js)이 계산하는 것은 화면의 같은 함수로 처리한다.
- 앱 도구(py): 자료 목록·출고장·문구·작업 상태·진행상황/현재고 반영·반품/회수 조회·제안 카드는 앱의 기존 메서드를 그대로 부른다.
- 발송·주문 변경은 하지 않는다. propose_action 은 확인 카드만 만들고, 실제 처리는 사장님이 앱의 기존 화면에서 한다.
- 고객 연락처는 어떤 도구에서도 돌려주지 않는다. 이름은 가운데를 가린다(김*수).
"""
from __future__ import annotations
import json,re,time
from datetime import datetime,timedelta,timezone

KST=timezone(timedelta(hours=9))
VERSION=1

def spec(name,desc,props=None,required=()):
    return {'type':'function','name':name,'description':desc,
            'inputSchema':{'type':'object','properties':props or {},'required':list(required),'additionalProperties':False}}

def mask(name):
    n=str(name or '').strip()
    if len(n)<=1:return n
    # '*' 대신 '○' — 답변 마크다운의 **굵게**와 섞이지 않게 (2026-10-25 실화면: **…오*윤…** 이 깨짐)
    if len(n)==2:return n[0]+'○'
    return n[0]+'○'*(len(n)-2)+n[-1]

def seller_label(v):return str(v or '').replace('누아브 ','')

UI_TOOLS={'app_overview','list_orders','import_orders','shortage_report','bundle_plan'}

# ---------- 설정 (2026-10-25 03:10 · 18:00 요청: 설정 조회·변경을 AI 대화로) ----------
# 저장된 값을 앱 설정 화면과 같은 함수로 읽고, 사장님이 카드 버튼을 눌렀을 때만 같은 함수로 바꾼다.
# 비밀번호·계정·받는 곳 연락처는 값으로 돌려주지 않는다 (저장됨/없음만).
TEMPLATE_NAMES={'first':'최초 지연 안내','change':'일정 재변경 안내','soldout_card':'품절안내 (에이블리/자사몰 카드)','soldout_bank':'품절안내 (자사몰/무통장)','manual':'수동 작성'}
PICKUP_SELLER_NAMES=('에이블리','자사몰','지그재그')
def _hhmm(v):
    t=str(v or '').strip().replace(' ','')
    pm=bool(re.match(r'(오후|저녁|밤|pm)',t,re.I));am=bool(re.match(r'(오전|아침|새벽|am)',t,re.I))
    t=re.sub(r'^(오후|오전|저녁|밤|아침|새벽|am|pm)','',t,flags=re.I)
    m=re.fullmatch(r'(\d{1,2})(?:(?::|시)(\d{1,2})?분?)?(반)?',t)
    if not m:raise ValueError('시간은 HH:MM (예: 18:00, 오후 6시) 로 주세요.')
    h=int(m[1]);mi=30 if m[3] else int(m[2] or 0)
    if pm and h<12:h+=12
    if am and h==12:h=0
    if h>23 or mi>59:raise ValueError('시간은 00:00~23:59 사이로 주세요.')
    return f'{h:02d}:{mi:02d}'
def _bool(v):
    if isinstance(v,bool):return v
    t=str(v).strip().lower()
    if t in ('true','on','1','켜기','켜','켬','켜짐','사용','yes','y'):return True
    if t in ('false','off','0','끄기','꺼','끔','꺼짐','사용 안 함','no','n'):return False
    raise ValueError('켜기/끄기(true/false)로 주세요.')
def _hours(v):
    items=v if isinstance(v,(list,tuple)) else re.findall(r'\d{1,2}',str(v or ''))
    out=sorted({int(x) for x in items})
    if not out or any(h<0 or h>23 for h in out):raise ValueError('시각은 0~23 시 숫자 목록으로 주세요 (예: [9,13,16]).')
    return out
def _choice(choices,names=None):
    def norm(v):
        if v in choices:return v
        try:
            if int(v) in choices:return int(v)
        except (TypeError,ValueError):pass
        if names:
            hit=[k for k,n in names.items() if str(v).strip() and str(v).strip() in n]
            if len(hit)==1:return hit[0]
        raise ValueError('고를 수 있는 값: '+', '.join(str(names.get(c,c) if names else c) for c in choices))
    return norm
def _sellers(v):
    if not isinstance(v,dict) or not v:raise ValueError('판매처별 켜기/끄기를 {"에이블리":true,...} 처럼 주세요.')
    out={}
    for k,x in v.items():
        name=str(k).replace('누아브 ','').strip()
        if name not in PICKUP_SELLER_NAMES:raise ValueError('판매처는 에이블리·자사몰·지그재그 중에서 고르세요.')
        out[name]=_bool(x)
    return out
def show_value(v,names=None):
    if isinstance(v,bool):return '켜짐' if v else '꺼짐'
    if isinstance(v,list):return '·'.join(f'{h}' for h in v)+'시'
    if isinstance(v,dict):return ', '.join(f"{k} {'켜짐' if x else '꺼짐'}" for k,x in v.items())
    if names and v in names:return names[v]
    return '없음' if v in (None,'') else str(v)

# 대화로 바꿀 수 없는 설정 화면 항목과 이유 (사장님께 정확히 알려 주기 위함)
NOT_SUPPORTED=[
    {'item':'문자(너나우리) 서비스 ID·비밀번호·발신번호·연결 방식','reason':'계정·비밀번호라 대화에서 보이거나 바꾸지 않습니다','where':'⚙ 설정 › 메시지 › 문자 설정'},
    {'item':'알림톡(알리고) 계정·템플릿','reason':'계정 정보라 대화에서 바꾸지 않습니다','where':'⚙ 설정 › 메시지 › 알림톡 설정'},
    {'item':'이지어드민·에이블리·지그재그·자사몰 로그인','reason':'아이디·비밀번호라 대화에서 보이거나 바꾸지 않습니다 (저장 여부만 확인)','where':'⚙ 설정 › 로그인'},
    {'item':'연결 폴더 (진행상황·현재고·반품·미출고 엑셀·주문 다운로드)','reason':'폴더 선택 창이 필요합니다 (지금 경로 확인은 가능)','where':'각 설정 화면의 폴더 선택'},
    {'item':'원격 접속','reason':'비밀번호가 필요해 맥미니 설정 화면에서만 바꿉니다','where':'⚙ 설정 › 원격 접속'},
    {'item':'아이폰 알림 받는 곳(번호·Apple ID)','reason':'연락처라 대화에서 보이지 않습니다 (켜기/끄기만 가능)','where':'⚙ 설정 › 자동화 › 아이폰 알림'},
    {'item':'진행상황 반영 상세 (브랜드·휴무일·추가 일수)','reason':'입력 항목이 많아 화면에서 확인하며 바꿔야 합니다','where':'진행상황 반영 설정'},
]

class SettingsMixin:
    """앱 설정 화면의 같은 함수를 부른다. 고객 메시지는 보내지 않는다."""
    def _setting_specs(self):
        e=self.engine;b=self.bridge;specs={}
        def st():return e.store.read()
        def add(key,**kw):specs[key]=kw
        # 반품 매일 자동 조회 · 반품 엑셀 변경 자동 확인 (반품 조회) — 자동 회수접수와 별개
        rc=(lambda:b._return_controller()) if b is not None and hasattr(b,'_return_controller') else None
        def ret_cfg():return rc().config() if rc else {}
        def ret_set(**chg):
            c=rc();cfg=c.config();new={k:cfg[k] for k in ('mode','time','watchEnabled','folder','source') if k in cfg};new.update(chg)
            return c.save(new)
        if rc:
            add('return_check_daily',label='반품 매일 자동 조회 (반품체크)',short='반품 자동조회',kind='bool',aliases=['반품 자동조회','반품체크 자동','반품 조회 자동'],
                get=lambda:ret_cfg().get('mode')=='daily',set=lambda v:ret_set(mode='daily' if v else 'manual'),norm=_bool,
                when=lambda:('매일 '+str(ret_cfg().get('time',''))) if ret_cfg().get('mode')=='daily' else '꺼짐 (수동 조회만)')
            add('return_check_time',label='반품 매일 자동 조회 시각',short='반품 자동조회 시각',kind='time',aliases=['반품 조회 시간','반품체크 시간'],
                get=lambda:ret_cfg().get('time',''),set=lambda v:ret_set(time=v,mode='daily'),norm=_hhmm,help='시각을 바꾸면 반품 매일 자동 조회도 켜집니다. 자동 회수접수는 이 조회 뒤에 이어서 실행됩니다.')
            add('return_file_watch',label='반품 엑셀 변경 자동 확인',short='반품 엑셀 자동 확인',kind='bool',aliases=['반품 폴더 감시'],
                get=lambda:bool(ret_cfg().get('watchEnabled')),set=lambda v:ret_set(watchEnabled=v),norm=_bool,
                help='반품 폴더의 반품진행상황.xlsx가 바뀌면 배송정보를 보완합니다.')
        # 자동 회수접수 — 반품 조회와 별개 기능 (이지어드민 회수 요청)
        pc=(lambda:b._pickup_controller()) if b is not None and hasattr(b,'_pickup_controller') else None
        if pc:
            def pick_when():
                c=ret_cfg()
                if c.get('mode')=='daily':return f"따로 정한 시각은 없고, 반품 매일 자동 조회({c.get('time','')}) 뒤 회수 대상이 생기면 바로(10초 안) 접수"
                return '따로 정한 시각은 없고, 반품 조회 뒤 회수 대상이 생기면 바로 접수 (반품 매일 자동 조회는 꺼져 있음)'
            add('auto_pickup',label='자동 회수접수 (회수접수 자동 실행)',short='자동회수',kind='bool',aliases=['자동회수','자동 회수','회수접수 자동','자동 회수접수'],
                get=lambda:bool(pc().config().get('enabled')),set=lambda v:pc().save({'enabled':v}),norm=_bool,when=pick_when,
                help='반품 조회 결과 중 회수 대상 송장을 이지어드민에 회수접수합니다. 반품 매일 자동 조회와는 별개입니다. 실행 시각을 바꾸려면 반품 자동조회 시각(return_check_time)을 바꿉니다.')
            add('auto_pickup_sellers',label='자동 회수접수 판매처',short='자동회수 판매처',kind='sellers',aliases=['자동회수 판매처'],
                get=lambda:{k:bool(v) for k,v in (pc().config().get('sellers') or {}).items()},
                set=lambda v:pc().save({'enabled':bool(pc().config().get('enabled')),'sellers':v}),norm=_sellers)
        # 정시 주문 자동 불러오기 · 미출고 엑셀 자동 저장 (누아브판)
        if getattr(e,'order_import_scheduler',None) is not None:
            from order_import_schedule import public as imp
            def imp_when():
                v=imp(st());return ('다음 '+str(v.get('nextAt',''))[:16].replace('T',' ')) if v.get('enabled') and v.get('nextAt') else ''
            add('order_auto_import',label='정시 주문 자동 불러오기',short='정시 주문 자동 불러오기',kind='bool',aliases=['주문 자동 불러오기','자동 불러오기'],
                get=lambda:bool(imp(st()).get('enabled')),set=lambda v:e.order_import_scheduler.configure(v),norm=_bool,when=imp_when)
        if hasattr(e,'order_exporter'):
            from order_export_auto import schedule_of
            add('order_schedule_hours',label='정시 주문 불러오기(:55)·미출고 엑셀 저장(:58) 시각',short='주문 불러오기 시각',kind='hours',aliases=['주문 불러오기 시간','불러오기 시각'],
                get=lambda:list(schedule_of(st())[0]),set=lambda v:e.order_exporter.set_schedule(hours=v),norm=_hours,
                help='시(時) 목록. 예: [9,13,16] → 09:55·13:55·16:55 불러오기, 각 3분 뒤 엑셀 저장. 기본 8~16시 매시.')
            add('order_schedule_weekends',label='정시 주문 불러오기·엑셀 저장 주말에도 실행',short='주말 실행',kind='bool',
                get=lambda:schedule_of(st())[1],set=lambda v:e.order_exporter.set_schedule(weekends=v),norm=_bool)
            add('order_export_auto',label='미출고 엑셀 자동 저장',short='미출고 엑셀 자동 저장',kind='bool',
                get=lambda:bool(e.order_exporter.public().get('enabled')),
                set=lambda v:e.order_exporter.configure({'enabled':v,'filename':e.order_exporter.public().get('filename') or '현재 미출고 상품.xlsx'}),norm=_bool)
            def fname(v):
                from order_export_auto import filename
                return filename(str(v))
            add('order_export_filename',label='미출고 엑셀 파일 이름',short='미출고 엑셀 파일 이름',kind='text',
                get=lambda:e.order_exporter.public().get('filename',''),
                set=lambda v:e.order_exporter.configure({'enabled':bool(e.order_exporter.public().get('enabled')),'filename':v}),norm=fname)
        # 현재고 자동갱신 (누아브판)
        if hasattr(e,'inventory_settings'):
            def inv():
                s=st().get('inventory',{});return {'autoEnabled':bool(s.get('autoEnabled')),'offsetMinutes':int(s.get('offsetMinutes',40) or 40),'hourly':bool(s.get('hourly'))}
            add('inventory_auto',label='현재고 자동갱신',short='현재고 자동갱신',kind='bool',get=lambda:inv()['autoEnabled'],
                set=lambda v:e.inventory_settings({**inv(),'autoEnabled':v}),norm=_bool,
                when=lambda:(('매시 ' if inv()['hourly'] else '정해진 시각 ')+f"+{inv()['offsetMinutes']}분 · 폴더 실시간 감시") if inv()['autoEnabled'] else '')
            add('inventory_offset_minutes',label='현재고 자동갱신 분 (+30 또는 +40)',short='현재고 갱신 분',kind='choice',choices=[30,40],get=lambda:inv()['offsetMinutes'],
                set=lambda v:e.inventory_settings({**inv(),'offsetMinutes':v}),norm=_choice([30,40]))
            add('inventory_hourly',label='현재고 자동갱신 매시 (끄면 정해진 시각만)',short='현재고 매시 갱신',kind='bool',get=lambda:inv()['hourly'],
                set=lambda v:e.inventory_settings({**inv(),'hourly':v}),norm=_bool)
        if hasattr(e,'supply_auto_settings'):
            add('supply_auto',label='진행상황·출고장 자동 반영',short='진행상황 자동 반영',kind='bool',get=lambda:bool((st().get('supply') or {}).get('autoEnabled')),
                set=lambda v:e.supply_auto_settings({'enabled':v}),norm=_bool)
        if hasattr(e,'save_preferences'):
            add('default_template',label='작성창 기본 안내 양식',short='기본 안내 양식',kind='choice',choices=list(TEMPLATE_NAMES),names=TEMPLATE_NAMES,
                get=lambda:(st().get('settings') or {}).get('defaultTemplate','first'),set=lambda v:e.save_preferences({'defaultTemplate':v}),norm=_choice(list(TEMPLATE_NAMES),TEMPLATE_NAMES))
        if hasattr(e,'set_auto_ably_push'):
            add('auto_ably_push',label='메시지 없는 안내 → 에이블리 발송 처리 자동 실행',short='에이블리 자동 처리',kind='bool',get=lambda:(st().get('settings') or {}).get('autoAblyPush',True) is not False,
                set=lambda v:e.set_auto_ably_push({'autoAblyPush':v}),norm=_bool)
        if hasattr(e,'set_auto_zigzag_push'):
            add('auto_zigzag_push',label='메시지 없는 안내 → 지그재그 배송연기 안내 자동 전송',short='지그재그 자동 전송',kind='bool',get=lambda:(st().get('settings') or {}).get('autoZigzagPush',True) is not False,
                set=lambda v:e.set_auto_zigzag_push({'autoZigzagPush':v}),norm=_bool)
        if hasattr(e,'set_browser_window'):
            add('headless_chrome',label='Chrome 헤드리스 (창 없이 실행)',short='Chrome 헤드리스',kind='bool',get=lambda:bool((st().get('settings') or {}).get('headlessChrome')),
                set=lambda v:e.set_browser_window({'headlessChrome':v}),norm=_bool,help='추가 인증·로그인 확인이 필요한 작업은 창이 없어 진행할 수 없습니다.')
        if hasattr(e,'phone_alert'):
            def ph():return e.phone_alert({'action':'status'}) or {}
            def ph_set(v):
                cur=ph()
                if v and not cur.get('to'):raise ValueError('받는 곳(번호·Apple ID)이 저장돼 있지 않습니다. ⚙ 설정 › 자동화 › 아이폰 알림에서 먼저 입력하세요.')
                r=e.phone_alert({'action':'save','enabled':v,'to':cur.get('to','')})
                if r.get('error'):raise ValueError(r['error'])
                return r
            add('phone_alert',label='아이폰 알림 (아이메시지)',short='아이폰 알림',kind='bool',get=lambda:bool(ph().get('enabled')),set=ph_set,norm=_bool,
                when=lambda:'받는 곳 저장됨' if ph().get('to') else '받는 곳 없음')
        return specs

    def _read_only(self):
        """바꿀 수 없지만 상태는 알려 줄 수 있는 항목 (값은 저장 여부·경로만)."""
        e=self.engine;b=self.bridge;out=[]
        def safe(label,fn):
            try:out.append({'label':label,'value':fn()})
            except Exception:out.append({'label':label,'value':'확인하지 못했습니다'})
        safe('문자(너나우리) 계정',lambda:'저장됨' if getattr(e,'creds',None) else '저장 안 됨')
        if hasattr(e,'aligo_cred'):safe('알림톡(알리고) 계정',lambda:'저장됨' if getattr(e,'aligo_cred',None) else '저장 안 됨')
        if b is not None:
            def login(fn):
                info=fn() or {};return '설정됨' if info.get('username') and info.get('hasPassword') else '설정 필요'
            if hasattr(b,'_orders_controller'):safe('이지어드민 로그인',lambda:login(lambda:b._orders_controller().login_settings()))
            if hasattr(b,'_ably_controller'):safe('에이블리 로그인',lambda:login(lambda:b._ably_controller().settings()))
            if hasattr(b,'_zigzag_controller'):safe('지그재그 로그인',lambda:login(lambda:b._zigzag_controller().settings()))
            if hasattr(b,'_orders_controller'):safe('주문 다운로드 폴더',lambda:b._orders_controller().settings().get('folder') or '연결 안 됨')
            if hasattr(b,'_return_controller'):safe('반품 폴더',lambda:b._return_controller().config().get('folder') or '연결 안 됨')
        s=e.store.read()
        safe('진행상황 폴더',lambda:(s.get('supply') or {}).get('folder') or '연결 안 됨')
        if 'inventory' in s:safe('현재고 폴더',lambda:(s.get('inventory') or {}).get('folder') or '연결 안 됨')
        if 'orderExport' in s or hasattr(e,'order_exporter'):safe('미출고 엑셀 저장 폴더',lambda:(s.get('orderExport') or {}).get('folder') or '연결 안 됨')
        return out

    def t_get_settings(self,service,args):
        out=[]
        for k,sp in self._setting_specs().items():
            try:cur=sp['get']()
            except Exception as exc:cur=None
            item={'key':k,'label':sp['label'],'short':sp.get('short',sp['label']),'kind':sp['kind'],'current':cur,'shown':show_value(cur,sp.get('names'))}
            try:
                w=sp['when']() if sp.get('when') else ''
                if w:item['when']=w
            except Exception:pass
            for f in ('choices','names','help','aliases'):
                if sp.get(f):item[f]=sp[f]
            out.append(item)
        r={'ok':True,'checkedAt':datetime.now(KST).isoformat(timespec='seconds'),'settings':out,'notSupported':NOT_SUPPORTED,
           'note':'current 는 지금 저장된 실제 값입니다. 바꾸려면 propose_action change_settings — 사장님이 카드 버튼을 눌러야 바뀝니다. '
                  '반품 자동조회(return_check_daily)와 자동 회수접수(auto_pickup)는 별개 기능입니다.'}
        if args.get('include_status',True):r['readOnly']=self._read_only()
        return r

    def check_settings(self,changes):
        """카드용: 키·값 확인 + 지금 값. 바꾸지는 않는다."""
        specs=self._setting_specs();rows=[];bad=[]
        if not isinstance(changes,dict) or not changes:return [],['바꿀 설정이 없습니다.']
        alias={a:k for k,sp in specs.items() for a in sp.get('aliases',[])}
        for k,v in list(changes.items())[:12]:
            key=str(k) if str(k) in specs else alias.get(str(k),'')
            sp=specs.get(key)
            if not sp:
                hit=next((n for n in NOT_SUPPORTED if any(w in str(k) for w in ('비밀번호','password','계정','로그인','폴더','원격','발신'))),None)
                bad.append(f'{k}: 이 대화에서 바꿀 수 없는 설정입니다'+(f" ({hit['reason']} · {hit['where']})" if hit else '.'));continue
            try:val=sp['norm'](v)
            except Exception as exc:bad.append(f"{sp['label']}: {exc}");continue
            try:cur=sp['get']()
            except Exception:cur=None
            if sp['kind']=='sellers' and isinstance(cur,dict):val={**cur,**val}
            rows.append({'key':key,'label':sp['label'],'short':sp.get('short',sp['label']),'kind':sp['kind'],'from':cur,'to':val,'names':sp.get('names'),'same':cur==val})
        return rows,bad

    def apply_settings(self,rows):
        """사장님이 카드 버튼을 눌렀을 때: 저장 → 다시 읽어서 저장된 값 확인."""
        specs=self._setting_specs();done=[];failed=[]
        for r in rows:
            sp=specs.get(r['key'])
            if not sp:failed.append(f"{r['label']}: 지금은 바꿀 수 없습니다.");continue
            try:
                res=sp['set'](r['to'])
                if isinstance(res,dict) and res.get('error'):raise ValueError(res['error'])
            except Exception as exc:failed.append(f"{sp['label']}: {str(exc)[:200]}");continue
            try:after=sp['get']()
            except Exception:after=None
            ok=after==r['to']
            done.append({**r,'after':after,'verified':ok})
            if not ok:failed.append(f"{sp['label']}: 저장 후 다시 확인한 값이 {show_value(after,sp.get('names'))} 입니다.")
        return done,failed

class AppTools(SettingsMixin):
    """engine: 앱 엔진 · bridge: DesktopAPI(작업 상태) · catalog: 자료 목록 · validate: 제안 확인 함수."""
    def __init__(self,engine,bridge=None,catalog=None):
        self.engine=engine;self.bridge=bridge;self.catalog=catalog

    # ---------- 도구 목록 ----------
    def specs(self):
        status_help=('status: 앱 화면의 "안내 상태" 필터 값. 빈 값 = 전체. 자주 쓰는 값: white(안내 전), white_dated(안내 전 · 일정 확정), white_undated(안내 전 · 일정 미확정), '
                     'green(예정일 이내), confirmed(예정일 이내 확정), yellow(예정일 당일), red(예정일 초과), notice_resend(출고 예정일 재발송 필요), late_today(당일 출고 지연), '
                     'failed(발송실패), charcoal(품절 안내 완료), soldout_check(품절 확인 필요), dispatch_dated(출고 예정일자 예정), dispatch_undated(출고 예정일자 미확정), '
                     'ready_all(출고 가능 전체), ready_t / ready_n(당일/익일 단품), ready_full_bundle_t / ready_full_bundle_n(당일/익일 합포), ready_partial_bundle(합포/부분), '
                     'scheduled_bundle(출고 예정 합포/부분), bundle_confirmed / bundle_planned / bundle_unconfirmed(합포 주문건 확정/예정/미확정), delay_risk(예정일 초과 예상), '
                     'supply_unmatched(수동 매칭 필요), exchange(교환건), china_all(중국 취소건). 정확한 전체 목록과 지금 개수는 app_overview 의 statusFilters 를 보세요.')
        out=[
          spec('app_overview','앱 대시보드 요약: 화면의 카드별 숫자, 안내 상태 필터별 개수(statusFilters: value/label/count), 마지막 주문 불러오기·진행상황·현재고 반영 시각. 질문을 받으면 먼저 이것으로 현황을 보세요.'),
          spec('list_orders','앱 화면과 같은 필터로 미출고 주문상품을 조회합니다. 행키(key)·판매처·주문번호·상품·옵션·수량·안내 상태·안내한 출고 예정일(dueDate)·출고 예상일(dispatchStart~End)·'
               '공급 배정(allocatedQty/qty, supplyReason)·현재고 준비·합포 정보(isBundle, bundleType, bundleReady, bundleSize)·회수/반품 기록 여부를 돌려줍니다. 고객 이름은 가려서, 연락처는 주지 않습니다. '+status_help,
               {'status':{'type':'string','description':'안내 상태 필터 값 (빈 값 = 전체)'},
                'search':{'type':'string','description':'검색어 (상품명+옵션, 주문번호, 고객명 등). 대화에 나온 가려진 이름(박○하)도 그대로 넣으면 첫·끝 글자로 찾습니다'},
                'search_field':{'type':'string','enum':['all','product','productName','option','orderId','customer'],'description':'검색 범위 (고객 이름으로 찾을 때 customer)'},
                'seller':{'type':'string','description':'판매처 이름 (에이블리·아무드·자사몰·지그재그) · 빈 값 = 전체'},
                'scope':{'type':'string','enum':['active','inactive','all'],'description':'active=현재 미출고(기본), all=보관 포함'},
                'limit':{'type':'integer','description':'최대 행 수 (기본 200, 최대 500)'}}),
          spec('shortage_report','입고 예정인데 수량이 부족한 주문 (예: "다음 주 입고 예정인데 수량 부족한 주문"). 기간(기본 다음 주 월~일) 안에 한국 입고 예정 물량이 있는 상품·옵션별로, '
               '날짜가 잡힌 배정이 주문 수량보다 적은 주문상품과 부족 수량·입고 물량(출고장/진행상황, 중국 출고일, 입고 예상일)을 한 번에 돌려줍니다. 앱 공급 계산(FIFO)을 그대로 씁니다.',
               {'from':{'type':'string','description':'YYYY-MM-DD (선택)'},'to':{'type':'string','description':'YYYY-MM-DD (선택)'},
                'week':{'type':'string','enum':['next','this'],'description':'from/to 가 없을 때 기간 (기본 next=다음 주)'}}),
          spec('bundle_plan','합포(한 주문 여러 상품) 주문 중 특정 날짜에 나갈 수 있는 것 (예: "합포 중 월요일에 나갈 수 있는 것"). 앱의 출고 가능 규칙(현재고 준비 또는 출고 예상 시작일 ≤ 그날)으로 '
               '전부 가능(full)·일부 가능(partial)·아직(notReady) 주문을 상품별 출고 예상일과 함께 돌려줍니다.',
               {'date':{'type':'string','description':'YYYY-MM-DD (기본 오늘)'}}),
          spec('list_materials','앱이 관리하는 자료(주문 엑셀·진행상황·출고장·회수접수 결과·미출고 엑셀·현재고 등)의 회차 목록 (id, 종류, 파일명, 기준일, 버전, 저장 시각).',
               {'kind':{'type':'string','description':'종류로 거르기 (orders, progress, shipment, pickup, notice_export, inventory, notice_text, order_list) · 빈 값 = 전체'}}),
          spec('link_material','자료 하나를 이 대화 작업 폴더에 복사해 연결합니다. 돌려준 file 이름으로 직접 읽으세요. 지난 회차는 읽기 전용입니다.',{'id':{'type':'string'}},['id']),
          spec('dispatch_batches','출고장(중국 출고일)별 지금 출고 예상일·해당 주문상품 수·사장님 직접 지정 여부.'),
          spec('notice_templates','앱 기본 안내 문구(첫 안내·일정 변경·품절), 저장한 문자 문구, 승인된 알림톡 양식 이름/본문. 추천 문구를 쓰기 전에 보세요.'),
          spec('search_returns','반품·교환 조회 결과와 회수접수 기록을 고객 이름·원송장번호·주문번호로 찾습니다. 회수접수 됐는지(차수·결과·시각) 알려 줍니다.',
               {'query':{'type':'string','description':'고객 이름, 원송장번호(10~14자리) 또는 주문번호'}},['query']),
          spec('job_status','지금 돌고 있는 앱 작업(주문 불러오기·동기화·회수접수 등)과 다음 예정 작업. wait_seconds 를 주면 작업이 끝날 때까지 최대 그만큼 기다립니다.',
               {'wait_seconds':{'type':'integer','description':'0~90'}}),
          spec('import_orders','앱의 "자동 불러오기 시작" 버튼과 같은 동작으로 이지어드민에서 주문 엑셀을 받아 반영을 시작합니다 (고객 메시지 없음). 사장님이 주문을 불러오라고 했을 때만 쓰세요. 끝났는지는 job_status 로 확인하세요.'),
          spec('refresh_supply','연결된 진행상황·출고장 폴더를 다시 읽어 출고 예상일을 다시 계산합니다 (화면의 진행상황 수동갱신과 같음, 고객 메시지 없음).'),
          spec('propose_action','사장님 확인용 카드를 대화에 만듭니다. 실행은 하지 않습니다 — 사장님이 카드를 누르면 앱의 기존 화면이 대상·날짜·문구가 채워진 채 열리고, 사장님이 그 화면에서 보내거나 적용합니다. '
               'action: no_send_notice(메시지 없는 배송지연 안내 · rowKeys, dueDate, template first/change), compose_notice(고객 문자/알림톡 · rowKeys, template first/change/manual, dueDate, message=추천 문구(manual일 때 그대로 채움)), '
               'change_dispatch(출고장 단위 출고 예상일 변경 · chinaDates, dispatchStart, dispatchEnd), change_settings(앱 설정 변경 · settings={get_settings 의 key: 새 값}). 결과는 사장님이 처리한 뒤 recent_action_results 로 확인할 수 있습니다.',
               {'action':{'type':'string','enum':['no_send_notice','compose_notice','change_dispatch','change_settings']},
                'settings':{'type':'object','description':'change_settings: get_settings 의 key → 새 값 (예: {"return_check_time":"18:30"})','additionalProperties':True},
                'rowKeys':{'type':'array','items':{'type':'string'},'description':'list_orders 의 key'},
                'dueDate':{'type':'string','description':'YYYY-MM-DD (안내할 출고 예정일)'},
                'template':{'type':'string','enum':['first','change','manual']},
                'message':{'type':'string','description':'추천 문구 (compose_notice · manual)'},
                'title':{'type':'string','description':'문자 제목 (선택)'},
                'chinaDates':{'type':'array','items':{'type':'string'}},
                'dispatchStart':{'type':'string'},'dispatchEnd':{'type':'string'},
                'reason':{'type':'string','description':'고른 근거 한두 줄'}},['action']),
          spec('get_settings','앱 설정의 지금 저장된 실제 값 (⚙ 설정 › 자동화의 모든 스위치와 시각: 반품 매일 자동 조회·시각, 반품 엑셀 변경 자동 확인, 자동 회수접수(자동회수)·판매처, 정시 주문 자동 불러오기·시각·주말, 미출고 엑셀 자동 저장·파일 이름, 현재고 자동갱신, 진행상황 자동 반영, 기본 안내 양식, 에이블리·지그재그 자동 처리, Chrome 헤드리스, 아이폰 알림) + 로그인·계정 저장 여부·연결 폴더(읽기 전용) + 대화로 못 바꾸는 항목(notSupported). 설정을 묻거나 바꾸라고 하면 반드시 먼저 이것을 부르고, 추측하지 마세요.',
               {'include_status':{'type':'boolean','description':'로그인·계정 저장 여부·폴더도 볼지 (기본 true)'}}),
          spec('open_file','Codex 가 작업 폴더에 만든/고친 파일이나 별도 저장한 결과 파일을 이 컴퓨터에서 엽니다. reveal=true 면 Finder(윈도우: 탐색기)에서 그 파일을 선택한 채로 보여 줍니다. 작업 폴더·결과 파일만 됩니다.',
               {'file':{'type':'string','description':'작업 폴더 기준 파일 이름 (예: 안내문_수정.xlsx)'},'reveal':{'type':'boolean','description':'true = Finder에서 보기, false = 기본 앱으로 열기'}},['file']),
          spec('recent_action_results','이 대화의 카드로 사장님이 실제로 처리한 결과(문자 요청·메시지 없는 안내·출고 예상일 변경)와 시각.'),
        ]
        if hasattr(self.engine,'inventory_refresh'):
            out.append(spec('refresh_inventory','연결된 현재고 폴더의 최신 현재고조회 파일을 다시 읽습니다 (화면의 현재고 수동갱신과 같음).'))
        return out

    # ---------- 실행 ----------
    def call(self,service,name,args):
        args=args if isinstance(args,dict) else {}
        if name in UI_TOOLS:return service.ui_call(name,args)
        fn=getattr(self,'t_'+name,None)
        if fn is None:return {'ok':False,'error':f'모르는 도구입니다: {name}'}
        return fn(service,args)

    def t_list_materials(self,service,args):
        if self.catalog is None:return {'ok':False,'error':'자료 목록을 사용할 수 없습니다.'}
        from codex_catalog import public,KINDS
        kind=str(args.get('kind') or '')
        items=[{**public(i),'label':KINDS.get(i.get('kind'),i.get('kind'))} for i in self.catalog.items(kind or None)][:80]
        return {'ok':True,'items':items,'count':len(items)}

    def t_link_material(self,service,args):
        if self.catalog is None:return {'ok':False,'error':'자료 목록을 사용할 수 없습니다.'}
        item=self.catalog.get(str(args.get('id') or ''))
        if not item:return {'ok':False,'error':'그 id 의 자료가 없습니다. list_materials 로 다시 확인하세요.'}
        key=service._link_result(item)
        with service.lock:
            service._write_context()
            rec=service.workspace.records.get(key) or {}
        return {'ok':True,'file':rec.get('name',''),'readOnly':bool(rec.get('readOnly')),'basis':item.get('basis',''),'version':item.get('version','')}

    def t_dispatch_batches(self,service,args):
        try:waves=(self.engine.public_state().get('supply') or {}).get('dispatchWaves') or []
        except Exception as exc:return {'ok':False,'error':str(exc)[:200]}
        return {'ok':True,'batches':waves}

    def t_notice_templates(self,service,args):
        out={'ok':True}
        try:
            from domain import FIRST,CHANGE,SOLDOUT_CARD,SOLDOUT_BANK
            out['defaults']={'first':FIRST,'change':CHANGE,'soldout_card':SOLDOUT_CARD,'soldout_bank':SOLDOUT_BANK}
        except Exception:pass
        try:
            s=self.engine.store.read();st=s.get('settings') or {}
            out['saved']={k:v for k,v in (st.get('smsTemplates') or {}).items() if isinstance(v,str)}
            out['defaultTemplate']=st.get('defaultTemplate','first')
            if st.get('shopName'):out['shopName']=st['shopName']
            out['alimtalk']=[{'key':k,'name':t.get('name',''),'body':t.get('body',''),'verified':bool(t.get('verified'))} for k,t in ((s.get('aligo') or {}).get('templates') or {}).items() if isinstance(t,dict)]
        except Exception:pass
        out['rules']=['알림톡은 승인된 양식 그대로만 보낼 수 있습니다 (#{상품명}, #{출고예정일}만 채움). 문구를 바꾸려면 문자(SMS/LMS, template=manual).',
                      '문자: 단문 80바이트, 장문 2,000바이트 이내. {상품목록}, {출고예정일} 변수를 쓸 수 있습니다.']
        return out

    def t_search_returns(self,service,args):
        q=str(args.get('query') or '').strip()
        if not q:return {'ok':False,'error':'고객 이름·원송장번호·주문번호를 주세요.'}
        try:st=self.engine.public_state()
        except Exception as exc:return {'ok':False,'error':str(exc)[:200]}
        ret=st.get('returns') or {};digits=re.sub(r'\D','',q);qn=q.replace(' ','')
        masked=bool(re.fullmatch(r'\S[*○]+\S?',qn))   # 대화에 나온 가려진 이름(홍○동)으로도 찾기
        def name_hit(name):
            n=str(name or '').replace(' ','')
            if not qn or not n:return False
            if masked:return len(n)>=2 and n[0]==qn[0] and (qn[-1] in '*○' or n[-1]==qn[-1])
            return qn in n
        def hit(r):
            return (digits and len(digits)>=6 and (digits in re.sub(r'\D','',str(r.get('invoice',''))) or digits in re.sub(r'\D','',str(r.get('orderId',''))) or digits in re.sub(r'\D','',str(r.get('returnInvoice',''))))) \
                or name_hit(r.get('customer')) or (q and q==str(r.get('orderId','')))
        rows=[]
        for r in (ret.get('rows') or [])+(ret.get('exchangeRows') or []):
            if not hit(r):continue
            rows.append({'kind':'교환' if r.get('kind')=='exchange' else '반품','seller':seller_label(r.get('seller','')),'customer':mask(r.get('customer')),'orderId':r.get('orderId',''),
                         'product':r.get('product',''),'invoice':r.get('invoice',''),'returnInvoice':r.get('returnInvoice',''),'requestedAt':r.get('requestedAt',''),
                         'status':r.get('label',''),'logistics':r.get('logistics',''),'pickupHistory':r.get('pickupHistory',[])})
        # 반품 조회 결과에 없지만 회수접수만 한 송장 (직접 입력한 회수접수)
        try:
            s=self.engine.store.read();seen={r['invoice'] for r in rows}
            for h in s.get('pickupHistory',[]):
                inv=str(h.get('invoice',''))
                if inv in seen:continue
                if (digits and len(digits)>=6 and digits in inv) or name_hit(h.get('customer')):
                    rows.append({'kind':'회수접수 기록','customer':mask(h.get('customer')),'invoice':inv,'pickupHistory':[{k:h.get(k,'') for k in ('result','at','acceptedAt','attempt','receiver','carrier','note')}]})
        except Exception:pass
        return {'ok':True,'checkedAt':ret.get('lastChecked',''),'exchangeCheckedAt':ret.get('exchangeChecked',''),'matches':rows[:50],'count':len(rows),
                'note':'pickupHistory 가 비어 있으면 이 앱에서 회수접수한 기록이 없습니다. 판매처 화면에서 직접 접수한 건은 알 수 없습니다.'}

    def t_job_status(self,service,args):
        wait=max(0,min(90,int(args.get('wait_seconds') or 0)))
        end=time.monotonic()+wait;last=None
        while True:
            last=self._activity()
            if not last.get('running') or time.monotonic()>=end:break
            time.sleep(2)
        try:
            s=self.engine.store.read();oa=s.get('orderAutoImport') or {}
            last['lastOrderDownload']=oa.get('lastDownload','');last['lastOrderFile']=oa.get('lastFile','')
        except Exception:pass
        last['ok']=True;return last
    def _activity(self):
        """앱 진행상황 바와 같은 작업 목록 (창 인증 호출 없이 컨트롤러 상태만 읽음)."""
        b=self.bridge;running=[]
        if b is not None:
            for label,attr in (('주문 불러오기','_order_auto'),('에이블리·아무드 동기화','_ably_sync'),('지그재그','_zigzag'),('반품·교환 조회','_returns'),('회수접수','_pickup'),('품절 처리·주문취소','_soldout_display')):
                c=getattr(b,attr,None)
                try:
                    if c and getattr(c,'thread',None) and c.thread.is_alive():running.append({'name':label,'message':str((getattr(c,'job',None) or {}).get('message',''))[:200]})
                except Exception:pass
            try:
                if getattr(getattr(self.engine,'order_exporter',None),'busy',False):running.append({'name':'미출고 엑셀 저장','message':''})
            except Exception:pass
            oa=getattr(b,'_order_auto',None)
            job=getattr(oa,'job',None) if oa else None
            if isinstance(job,dict):
                last={'phase':job.get('phase',''),'message':str(job.get('message',''))[:300]}
                return {'running':running,'orderImport':last}
        return {'running':running}

    def t_refresh_supply(self,service,args):
        try:r=self.engine.supply_refresh({})
        except Exception as exc:return {'ok':False,'error':str(exc)[:400]}
        return {'ok':True,'message':r.get('message',''),'files':r.get('files'),'warnings':(r.get('warnings') or [])[:10]}
    def t_refresh_inventory(self,service,args):
        try:r=self.engine.inventory_refresh({})
        except Exception as exc:return {'ok':False,'error':str(exc)[:400]}
        return {'ok':True,'message':(r or {}).get('message','') if isinstance(r,dict) else str(r)[:300]}

    def t_propose_action(self,service,args):
        return service.add_proposal(args)

    def t_open_file(self,service,args):
        p=service.open_named(args.get('file'),reveal=bool(args.get('reveal')))
        return {'ok':True,'file':p.name,'shown':'Finder에서 선택해 표시함' if args.get('reveal') else '기본 앱으로 열었음'}

    def t_recent_action_results(self,service,args):
        with service.lock:items=list(service.chat.get('actionResults',[]))[-20:]
        return {'ok':True,'results':items,'note':'여기 없는 처리는 아직 사장님이 하지 않은 것입니다.'}
