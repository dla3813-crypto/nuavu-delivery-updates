"""배송안내 배포판 · Codex 대화 화면 (2026-10-24 22:05 추가 요청: Codex 데스크톱 구조).

[왼쪽 대화 목록] [제목줄 + 가운데 대화(최대 820px) + 하단 고정 입력창] [필요할 때만 여는 작업 파일 패널]
화면은 부분(part)별 HTML 로 보내고, 입력창은 브라우저에서 한 번만 만들어 다시 그리지 않는다 (입력 중인 글·한글 조합 유지).
모델 응답은 먼저 모두 HTML 이스케이프한 뒤 굵게·코드·표·목록만 정해진 태그로 바꾼다. 응답 속 <script>·버튼·링크는 글자로만 보인다.
"""
import html,json,re

def esc(v):return html.escape(str(v) if v is not None else '',quote=True)

# 아이콘 (인라인 SVG — 글꼴에 따라 어긋나는 문자 아이콘 대신)
ICONS={
 'send':'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V5M5.5 11.5 12 5l6.5 6.5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 'stop':'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="7" y="7" width="10" height="10" rx="2" fill="currentColor"/></svg>',
 'plus':'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
 'close':'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.5 6.5l11 11M17.5 6.5l-11 11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
 'side':'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="5" width="17" height="14" rx="3" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M9.5 5v14" stroke="currentColor" stroke-width="1.8"/></svg>',
 'more':'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="6" cy="12" r="1.7" fill="currentColor"/><circle cx="12" cy="12" r="1.7" fill="currentColor"/><circle cx="18" cy="12" r="1.7" fill="currentColor"/></svg>',
 'trash':'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 7h14M10 7V5h4v2M7.5 7l.8 12h7.4l.8-12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 'file':'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3.5h7l4 4V20a.5.5 0 0 1-.5.5h-10.5a.5.5 0 0 1-.5-.5V4a.5.5 0 0 1 .5-.5z" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M14 3.5V8h4" fill="none" stroke="currentColor" stroke-width="1.7"/></svg>',
 'clock':'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M12 7.5V12l3 2" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
 'max':'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 5h5v5M10 19H5v-5M19 5l-6 6M5 19l6-6" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 'min':'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 10h-5V5M5 14h5v5M14 10l6-6M10 14l-6 6" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 'tool':'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14.5 5.5a4 4 0 0 0-5 5L4.8 15.2a1.6 1.6 0 0 0 2.3 2.3l4.7-4.7a4 4 0 0 0 5-5l-2.4 2.4-2.1-.3-.3-2.1z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
 'new':'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 19h4l10-10-4-4L5 15v4z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
}
def icon(name):return ICONS[name]

def btn(title,action,value=None,disabled=False,primary=False,cls='',label=None,ic=None):
    val='' if value is None else ' data-value="'+esc(json.dumps(value,ensure_ascii=False) if isinstance(value,dict) else value)+'"'
    body=(icon(ic)+('<span>'+esc(title)+'</span>' if title else '')) if ic else esc(title)
    aria=' aria-label="'+esc(label)+'" title="'+esc(label)+'"' if label else ''
    return '<button type="button" class="cx-btn'+(' primary' if primary else '')+(' '+cls if cls else '')+'" data-cx="'+action+'"'+val+aria+(' disabled' if disabled else '')+'>'+body+'</button>'

try:from codex_service import REVEAL_LABEL
except Exception:REVEAL_LABEL='Finder에서 보기'

# ---------- 안전한 마크다운 (이스케이프 후 정해진 태그만) ----------
def _inline(s):
    s=re.sub(r'`([^`\n]+)`',r'<code>\1</code>',s)
    s=re.sub(r'\*\*(?=\S)((?:[^*\n]|\*(?!\*))+?)\*\*',r'<strong>\1</strong>',s)   # 안쪽의 단일 * (예: 가려진 이름) 허용
    return s
def markdown(text):
    lines=esc(text).split('\n');out=[];i=0
    while i<len(lines):
        ln=lines[i]
        if ln.strip().startswith('```'):
            j=i+1;code=[]
            while j<len(lines) and not lines[j].strip().startswith('```'):code.append(lines[j]);j+=1
            out.append('<pre><code>'+'\n'.join(code)+'</code></pre>');i=j+1;continue
        if ln.strip().startswith('|') and i+1<len(lines) and re.fullmatch(r'\s*\|?[\s:|-]+\|?\s*',lines[i+1]) and '-' in lines[i+1]:
            rows=[ln];j=i+2
            while j<len(lines) and lines[j].strip().startswith('|'):rows.append(lines[j]);j+=1
            cells=lambda r:[c.strip() for c in r.strip().strip('|').split('|')]
            head=''.join('<th>'+_inline(c)+'</th>' for c in cells(rows[0]))
            body=''.join('<tr>'+''.join('<td>'+_inline(c)+'</td>' for c in cells(r))+'</tr>' for r in rows[1:])
            out.append('<div class="cx-table"><table><thead><tr>'+head+'</tr></thead><tbody>'+body+'</tbody></table></div>');i=j;continue
        m=re.match(r'(#{1,4})\s+(.*)',ln)
        if m:out.append('<p class="cx-h">'+_inline(m[2])+'</p>');i+=1;continue
        if re.match(r'\s*(?:[-*•]|\d+[.)])\s+',ln):
            items=[];ordered=bool(re.match(r'\s*\d+[.)]',ln))
            while i<len(lines) and re.match(r'\s*(?:[-*•]|\d+[.)])\s+',lines[i]):
                items.append('<li>'+_inline(re.sub(r'^\s*(?:[-*•]|\d+[.)])\s+','',lines[i]))+'</li>');i+=1
            out.append(('<ol>' if ordered else '<ul>')+''.join(items)+('</ol>' if ordered else '</ul>'));continue
        if re.match(r'\s*&gt;',ln):   # 인용(> …) — 추천 문구를 상자로 (2026-10-25 실화면: > 가 그대로 보였음)
            q=[];j=i
            while j<len(lines) and re.match(r'\s*&gt;',lines[j]):q.append(re.sub(r'^\s*&gt;\s?','',lines[j]));j+=1
            paras=[];cur=[]
            for x in q:
                if x.strip():cur.append(x)
                elif cur:paras.append(cur);cur=[]
            if cur:paras.append(cur)
            out.append('<blockquote class="cx-quote">'+''.join('<p>'+_inline('<br>'.join(p_))+'</p>' for p_ in paras)+'</blockquote>');i=j;continue
        if not ln.strip():i+=1;continue
        para=[ln];i+=1
        while i<len(lines) and lines[i].strip() and not re.match(r'\s*(?:[-*•]|\d+[.)]|#{1,4})\s+|\s*\||\s*```|\s*&gt;',lines[i]):para.append(lines[i]);i+=1
        out.append('<p>'+_inline('<br>'.join(para))+'</p>')
    return ''.join(out)

def _settings_button(rows):
    """'자동회수 켜기' · '반품 자동조회 시각 18:00로 변경' · 여러 개면 '이대로 적용'."""
    if len(rows)!=1:return '이대로 적용'
    r=rows[0];to=r.get('to');name=r.get('short') or r.get('label','설정')
    if isinstance(to,bool):return name+(' 켜기' if to else ' 끄기')
    if r.get('kind') in ('time','text','choice'):
        shown=(r.get('names') or {}).get(to,to) if isinstance(r.get('names'),dict) else to
        return f'{name} {shown}(으)로 변경'
    return name+' 변경'

def _usage(limits):
    out=[]
    for _,windows in (limits or {}).items():
        for _,w in windows.items():
            minutes=w.get('windowDurationMins') or 0
            window=(str(round(minutes/1440))+'일' if minutes>=1440 else str(round(minutes/60))+'시간' if minutes>=60 else str(minutes)+'분') if minutes else '구독'
            if 'usedPercent' in w:out.append(esc(window)+' '+esc(round(float(w['usedPercent'])))+'% 사용')
    return ' · '.join(out)

def _day(v):
    v=str(v or '')
    return f'{int(v[5:7])}/{int(v[8:10])}' if re.match(r'\d{4}-\d{2}-\d{2}',v) else v

def parts(s,remote=False):
    busy=s['busy'];account=s['account'];ok=account.get('type')=='chatgpt'
    # 왼쪽 대화 목록
    side='<div class="cx-side-top"><span>대화</span>'+btn('새 대화','cxNew',disabled=busy,ic='new',cls='cx-small')+'</div><div class="cx-threads" role="list" aria-label="저장된 대화">'
    for t in s['sessions']:
        active=t['id']==s['session']
        side+=('<div class="cx-thread'+(' active' if active else '')+'"><button type="button" class="cx-thread-main" data-cx="cxSelect" data-value="'+esc(t['id'])+'" aria-current="'+('true' if active else 'false')+'"'+(' disabled' if busy and not active else '')+'>'+esc(t['title'])+'</button>'
               +btn('','cxDelete',t['id'],disabled=busy,cls='cx-icon cx-trash',label='대화 삭제 (되돌리기 가능)',ic='trash')+'</div>')
    side+='</div>'
    if s.get('undoDelete'):side+='<div class="cx-undo">'+btn('지운 대화 되돌리기'+(f" ({int(s['undoDelete'])})" if int(s['undoDelete'])>1 else ''),'cxUndoDelete',disabled=busy,cls='cx-small')+'</div>'
    side+='<div class="cx-account"><span class="cx-dot'+(' on' if ok else '')+'"></span>'+(esc(str(account.get('planType') or 'ChatGPT').upper())+' · 구독 연결됨' if ok else 'ChatGPT 연결 전')+'<small>실행·파일은 이 컴퓨터에서</small></div>'
    # 제목줄
    nfiles=len(s['files'])
    head=('<button type="button" class="cx-icon" data-cx-local="side" aria-label="대화 목록 접기·펼치기" title="대화 목록">'+icon('side')+'</button>'
          '<div class="cx-title" role="heading" aria-level="1">'+esc(s.get('title') or '새 대화')+'</div>'
          '<button type="button" class="cx-btn cx-small" data-cx-local="files" aria-expanded="false">'+icon('file')+'<span>작업 파일'+(f' {nfiles}' if nfiles else '')+'</span></button>'
          '<details class="cx-more"><summary class="cx-icon" aria-label="연결·모델·사용량 설정" title="연결·모델·사용량">'+icon('more')+'</summary><div class="cx-more-body"><b class="cx-more-title">연결 · 모델 · 사용량</b><div class="cx-row">'
          +btn('연결 확인','cxConnect',disabled=busy,cls='cx-small')+btn('ChatGPT 로그인','cxLogin',disabled=busy,primary=not ok,cls='cx-small')+(btn('연결 해제','cxLogout',disabled=busy,cls='cx-small') if ok else '')+'</div>')
    if s['models']:
        model=next((m for m in s['models'] if m['id']==s['model']),s['models'][0])
        efforts=model['efforts'];effort=s['effort'] if s['effort'] in efforts else model['default']
        head+=('<label>모델<select id="cx-model"'+(' disabled' if busy else '')+'>'+''.join('<option value="'+esc(m['id'])+'"'+(' selected' if m['id']==s['model'] else '')+'>'+esc(m['name'])+'</option>' for m in s['models'])+'</select></label>'
               '<label>생각 깊이<select id="cx-effort"'+(' disabled' if busy else '')+'>'+''.join('<option'+(' selected' if e==effort else '')+'>'+esc(e)+'</option>' for e in efforts)+'</select></label>'
               +btn('설정 저장','cxSettings',disabled=busy,cls='cx-small'))
    usage=_usage(s.get('limits'))
    head+=(('<p class="cx-usage">사용량: '+usage+'</p>' if usage else '')
           +'<div class="cx-row">'+btn('질문·파일 수정 시험','cxTest',disabled=busy or not ok,cls='cx-small')+'</div>'
           '<p class="cx-note">ChatGPT 구독 사용량이 적용됩니다 (무제한 아님). 한도 초과·연결 실패 때 API 과금으로 바꾸지 않습니다. 문자·알림톡 발송과 주문 변경은 이 대화에서 하지 않습니다.</p></div></details>'
           '<button type="button" class="cx-icon cx-size" data-cx-local="size" aria-label="크게 보기·작게 보기" title="크게 보기 / 작게 보기"><span class="cx-size-max">'+icon('max')+'</span><span class="cx-size-min">'+icon('min')+'</span></button>'
           '<button type="button" class="cx-icon" data-cx-local="close" aria-label="대화창 닫기" title="닫기">'+icon('close')+'</button>')
    # 대화
    msgs=''
    alert=''   # 오류·로그인 안내는 입력창 바로 위에 (대화를 위로 올려 읽고 있어도 보이게)
    if s['error']:alert+='<div class="cx-alert" role="alert">'+esc(s['error'])+'</div>'
    if s['loginPending']:alert+='<div class="cx-alert soft">이 컴퓨터 브라우저에서 ChatGPT 로그인을 완료해 주세요. '+btn('로그인 창 다시 열기','cxLoginOpen',cls='cx-small')+'</div>'
    if not s['messages']:
        msgs+=('<div class="cx-empty"><b class="cx-empty-title">무엇을 도와드릴까요?</b><p>아래 입력창에 적어 주세요. 앱이 관리하는 최신 자료(현재 주문 목록·주문 엑셀·진행상황·출고장·안내문)는 첨부하지 않아도 찾아서 연결합니다.</p>'
               '<p class="cx-muted">질문과 함께 연결된 자료는 사장님의 ChatGPT 계정(OpenAI)으로 보내져 처리됩니다. 주문 엑셀에는 고객 이름·연락처가 들어 있을 수 있습니다. 현재 주문 목록은 연락처를 빼고 보냅니다.</p>'
               '<div class="cx-suggest"><span>안내 전 일정 확정건 지연 메시지 준비해 줘</span><span>OOO 회수접수 됐어?</span><span>다음 주 입고 예정인데 수량 부족한 주문</span><span>합포 중 월요일에 나갈 수 있는 것</span><span>자동회수 설정되어 있어?</span></div></div>')
    last_assistant=max((i for i,m in enumerate(s['messages']) if m.get('role')=='assistant'),default=-1)
    for i,m in enumerate(s['messages']):
        role=m.get('role')
        if role=='system':msgs+='<div class="cx-sys" data-cx-message="'+esc(m['id'])+'">'+esc(m['text'])+'</div>';continue
        if role=='files':   # 2026-10-25 18:00: AI가 만든 파일 → [열기] [Finder에서 보기]
            msgs+='<div class="cx-filesline" data-cx-message="'+esc(m['id'])+'"><div class="cx-role">'+('결과 저장함' if m.get('saved') else 'Codex가 만든 파일')+'</div>'
            for it in m.get('items') or []:
                ref={'export':it['export']} if it.get('export') else {'key':it['key']}
                msgs+=('<div class="cx-fileitem">'+icon('file')+'<b>'+esc(it['name'])+'</b><small>'+f"{(it.get('bytes') or 0)/1024:,.1f} KB"+'</small>'
                       +btn('열기','cxOpenFile',ref,cls='cx-small')+btn(REVEAL_LABEL,'cxRevealFile',ref,cls='cx-small')+'</div>')
            msgs+='</div>';continue
        if role=='tool':msgs+='<div class="cx-toolline'+('' if m.get('ok',True) else ' fail')+'" data-cx-message="'+esc(m['id'])+'">'+icon('tool')+'<span>앱 도구 · '+esc(m['text'])+'</span></div>';continue
        if role=='proposal' and m.get('action')=='change_settings':   # 2026-10-25 03:10: 설정·시간 변경
            from codex_tools import show_value as show
            rows=''.join('<li>'+esc(r['label'])+'<br><span class="cx-muted">지금 '+esc(show(r.get('from'),r.get('names')))+'</span> → <b>'+esc(show(r.get('to'),r.get('names')))+'</b></li>' for r in m.get('changes') or [])   # 03:40 실화면: 작은 창에서 표가 잘림 → 목록으로
            done=m.get('applied') and m.get('applied')!='working'
            msgs+=('<div class="cx-proposal" data-cx-message="'+esc(m['id'])+'"><div class="cx-role">'+('적용함' if done else 'Codex 제안 · 아직 바꾸지 않았습니다')+'</div><b>'+esc(m.get('label',''))+' · '+str(len(m.get('changes') or []))+'개</b>'
                   +('<p>'+esc(m['reason'])+'</p>' if m.get('reason') else '')
                   +'<ul class="cx-setlist">'+rows+'</ul>'
                   +(''.join('<p class="cx-warn">'+esc(w)+'</p>' for w in m.get('warnings') or []))
                   +('<p class="'+('cx-warn' if m.get('failed') else 'cx-muted')+'">'+esc(m.get('result',''))+'</p>' if done else '<div class="cx-row"><button type="button" class="cx-btn primary cx-small" data-cx="cxApplySettings" data-value="'+esc(m['id'])+'"'+(' disabled' if m.get('applied') else '')+'>'+esc(_settings_button(m.get('changes') or []))+'</button><span class="cx-muted">앱 설정 화면과 같은 방식으로 바꿉니다. 고객 메시지는 보내지 않습니다.</span></div>')
                   +'</div>')
            continue
        if role=='proposal' and m.get('action')=='change_dispatch':   # 2026-10-24: 출고장 단위 출고 예상일 변경
            waves=m.get('chinaDates') or [];a,b=m.get('dispatchStart',''),m.get('dispatchEnd','')
            span=_day(a)+('' if a==b else '~'+_day(b))
            val=json.dumps({'action':'change_dispatch','chinaDates':waves,'start':a,'end':b,'proposal':m['id']},ensure_ascii=False)
            msgs+=('<div class="cx-proposal" data-cx-message="'+esc(m['id'])+'"><div class="cx-role">Codex 제안 · 아직 바꾸지 않았습니다</div><b>'+esc(m.get('label',''))+' · 출고장 '+str(len(waves))+'개'+(' (주문상품 '+str(m.get('count',0))+'개)' if m.get('count') else '')+' → '+esc(span)+'</b>'
                   +('<p>'+esc(m['reason'])+'</p>' if m.get('reason') else '')
                   +('<ul>'+''.join('<li>'+esc(x)+'</li>' for x in m.get('samples') or [])+'</ul>' if m.get('samples') else '')
                   +(''.join('<p class="cx-warn">'+esc(w)+'</p>' for w in m.get('warnings') or []))
                   +('<p class="cx-warn">지금 목록에 없는 출고장 '+str(m['unmatched'])+'개는 뺐습니다.</p>' if m.get('unmatched') else '')
                   +('<div class="cx-row"><button type="button" class="cx-btn primary cx-small" data-cx-local="proposal" data-value="'+esc(val)+'">출고 예상일 변경 창에서 확인</button><span class="cx-muted">고객에게 안내한 출고 예정일·발송 이력은 그대로이고 메시지는 보내지 않습니다.</span></div>' if waves else '<p class="cx-warn">바꿀 출고장이 없습니다.</p>')
                   +'</div>')
            continue
        if role=='proposal':
            n=len(m.get('keys') or [])
            val=json.dumps({'action':m['action'],'keys':m.get('keys') or [],'dueDate':m.get('dueDate',''),'template':m.get('template','first'),'message':m.get('message',''),'title':m.get('title',''),'proposal':m['id']},ensure_ascii=False)
            msgs+=('<div class="cx-proposal" data-cx-message="'+esc(m['id'])+'"><div class="cx-role">Codex 제안 · 아직 처리하지 않았습니다</div><b>'+esc(m.get('label',''))+' · '+str(n)+'개 상품'+(' · 출고 예정일 '+esc(_day(m['dueDate'])) if m.get('dueDate') else '')+'</b>'
                   +('<p>'+esc(m['reason'])+'</p>' if m.get('reason') else '')
                   +('<div class="cx-draftmsg"><b>추천 문구'+(' · '+esc(m['title']) if m.get('title') else '')+'</b><pre>'+esc(m['message'])+'</pre></div>' if m.get('message') else '')
                   +('<ul>'+''.join('<li>'+esc(x)+'</li>' for x in m.get('samples') or [])+('<li>…외 '+str(n-len(m.get('samples') or []))+'개</li>' if n>len(m.get('samples') or []) else '')+'</ul>' if m.get('samples') else '')
                   +(''.join('<p class="cx-warn">'+esc(w)+'</p>' for w in m.get('warnings') or []))
                   +('<p class="cx-warn">현재 목록에 없는 행 '+str(m['unmatched'])+'개는 뺐습니다.</p>' if m.get('unmatched') else '')
                   +('<div class="cx-row"><button type="button" class="cx-btn primary cx-small" data-cx-local="proposal" data-value="'+esc(val)+'">앱 화면에서 확인하고 처리</button><span class="cx-muted">선택된 상품과 날짜를 확인한 뒤 앱의 기존 버튼으로 처리합니다.</span></div>' if n else '<p class="cx-warn">처리할 상품이 없습니다.</p>')
                   +'</div>')
            continue
        if role=='user':msgs+='<div class="cx-user" data-cx-message="'+esc(m['id'])+'">'+esc(m['text'])+'</div>';continue
        live=s['running'] and i==last_assistant and i==len(s['messages'])-1
        msgs+=('<div class="cx-assistant" role="article" data-cx-message="'+esc(m['id'])+'"><div class="cx-role">Codex'+(' <span class="cx-live">작성 중…</span>' if live else '')+'</div>'
               +markdown(m.get('text',''))+'</div>')
    if s['running'] and (not s['messages'] or s['messages'][-1].get('role')!='assistant'):msgs+='<div class="cx-thinking"><span class="cx-pulse"></span>이 컴퓨터에서 생각하고 있어요…</div>'
    for req in s['pending']:
        msgs+='<div class="cx-question" data-cx-request="'+esc(req['id'])+'"><b>Codex의 확인 질문</b>'
        for q in req['questions']:
            msgs+='<label>'+esc(q.get('question','답변을 입력해 주세요.'))+'<input data-cx-answer="'+esc(q['id'])+'" maxlength="5000" placeholder="답변" '+('type="password" ' if q.get('isSecret') else '')+'></label>'
            for opt in q.get('options') or []:msgs+='<small>'+esc(opt.get('label',''))+' · '+esc(opt.get('description',''))+'</small>'
        msgs+=btn('답변 전달','cxAnswer',primary=True,cls='cx-small')+'</div>'
    # 자료 선택 (모호할 때 / 최근 자료)
    picker=''
    pk=s.get('resultPicker')
    if pk:
        q=pk.get('question')
        picker=('<div class="cx-picker" role="dialog" aria-label="자료 선택"><div class="cx-picker-head"><b>'+('사용할 자료를 골라 주세요' if q else '최근 작업 자료')+'</b>'
                +btn('','cxPickerClose',cls='cx-icon',label='닫기',ic='close')+'</div>'
                +('<p>질문: '+esc(q[:120])+' — 고르면 이 질문을 한 번만 보냅니다.</p>' if q else '<p>앱이 등록한 자료입니다. 고르면 현재 대화에 연결합니다 (원본은 그대로).</p>')+'<div class="cx-picker-list">')
        for it in pk.get('items',[]):
            picker+=('<button type="button" class="cx-pick" data-cx="cxChoose" data-value="'+esc(it['id'])+'"'+(' disabled' if busy else '')+'><b>'+esc(it['name'])+'</b><span>'+esc(it['label'])+' · 기준 '+esc(_day(it.get('basis')))
                     +' · 생성 '+esc(str(it.get('createdAt',''))[5:16].replace('T',' '))+' · v'+esc(it.get('version',''))+'</span></button>')
        if not pk.get('items'):picker+='<p>등록된 자료가 아직 없습니다. 앱에서 주문 불러오기·현재고·진행상황 갱신·미출고 엑셀 저장을 하면 여기에 쌓입니다.</p>'
        picker+='</div></div>'
    # 입력창 위 자료 칩
    chips=''.join('<span class="cx-chip" title="'+esc(l.get('name',''))+'">'+icon('file')+'<span class="cx-chip-name">'+esc(l.get('file',''))+'</span><span class="cx-chip-meta">'+esc(_day(l.get('basis')))+(' · 자동 연결' if l.get('auto') else '')+(' · 지난 회차' if l.get('historical') else ' · 앱 화면 기준' if l.get('generated') else '')+(' · 수정됨' if l.get('workingCopyModified') else '')+'</span>'
                  +btn('','cxUnlink',l['key'],disabled=busy,cls='cx-chip-x',label='현재 대화 연결 해제 (원본은 그대로)',ic='close')+'</span>' for l in s.get('linkedResults',[]))
    chips+=''.join('<span class="cx-chip" title="'+esc(a['file'])+'">'+icon('file')+'<span class="cx-chip-name">'+esc(a['file'])+'</span><span class="cx-chip-meta">첨부</span>'
                   +btn('','cxUnlink',a['key'],disabled=busy,cls='cx-chip-x',label='현재 대화 연결 해제 (원본은 그대로)',ic='close')+'</span>' for a in s.get('attached',[]))
    # 작업 파일 패널
    files='<div class="cx-files-head"><b>작업 파일</b><button type="button" class="cx-icon" data-cx-local="files" aria-label="작업 파일 닫기">'+icon('close')+'</button></div><div class="cx-row">'+btn('이 컴퓨터 파일','cxBrowse','',disabled=busy,cls='cx-small',ic='plus')+btn('최근 자료','cxResults',disabled=busy,cls='cx-small',ic='clock')+btn('변경 확인','cxReview',disabled=busy,cls='cx-small')+'</div>'
    if not s['files']:files+='<p class="cx-muted">아직 연결된 파일이 없습니다. 질문하면 앱 자료를 자동으로 연결하고, ＋로 이 컴퓨터 파일을 직접 가져올 수도 있습니다. 원본은 반영 전까지 그대로입니다.</p>'
    for f in s['files']:
        a=f.get('artifact') or {}
        meta=(esc(a.get('label',''))+' · 기준 '+esc(_day(a.get('basis')))+' · v'+esc(a.get('version',''))+(' · 앱 화면 기준(읽기 전용)' if a.get('generated') else ' · 지난 회차(읽기 전용)' if f.get('readOnly') else '')) if a else ('이 컴퓨터 파일 복사본' if f.get('linked') else 'Codex가 만든 새 파일'+(' · 비교 기준: '+esc(f['compareWith']) if f.get('compareWith') else ''))
        files+=('<div class="cx-file"><b>'+esc(f['name'])+'</b><small>'+meta+' · '+('수정됨' if f['changed'] else '변경 없음')+' · '+f"{f['bytes']/1024:,.1f} KB"+'</small><div class="cx-row">'+btn('열기','cxOpenFile',{'key':f['key']},cls='cx-small')+btn(REVEAL_LABEL,'cxRevealFile',{'key':f['key']},cls='cx-small'))
        if f['changed']:
            if f['original']:files+=btn('원본에 반영','cxApply',{'key':f['key'],'sha':f['sha']},disabled=busy,primary=True,cls='cx-small cx-arm')
            files+=btn('별도 저장','cxExport',{'key':f['key'],'sha':f['sha']},disabled=busy,cls='cx-small')
        if f['canRestore']:files+=btn('원본 되돌리기','cxRestore',f['key'],disabled=busy,cls='cx-small cx-arm')
        if f.get('linked'):files+=btn('연결 해제','cxUnlink',f['key'],disabled=busy,cls='cx-small')
        files+='</div>'
        if f['changed']:files+='<details><summary>변경 전후 보기</summary><pre>'+esc(f['preview'])+'</pre></details>'
        if f.get('source') and not f.get('readOnly'):files+='<small class="cx-src">원본: '+esc(f['source'])+'</small>'
        files+='</div>'
    browser=''
    b=s.get('browser')
    if b:
        browser=('<div class="cx-picker" role="dialog" aria-label="이 컴퓨터 파일 선택"><div class="cx-picker-head"><b>이 컴퓨터 파일 선택</b>'+btn('','cxBrowserClose',cls='cx-icon',label='닫기',ic='close')+'</div>'
                 '<p>이 컴퓨터에 있는 파일만 보입니다'+(' (원격 화면에서도 이 컴퓨터 파일 목록)' if remote else '')+'. 고른 파일은 복사본으로 가져옵니다.</p><div class="cx-row">')
        for key,label in s['roots']:browser+=btn(label,'cxBrowse',key+':',cls='cx-small')
        if b['parent']:browser+=btn('↑ 상위 폴더','cxBrowse',b['parent'],cls='cx-small')
        browser+='</div><small class="cx-muted">'+esc(b.get('label',b['token']))+'</small><div class="cx-picker-list">'
        for f in b['items']:browser+='<button type="button" class="cx-pick" data-cx="'+('cxBrowse' if f['dir'] else 'cxAttach')+'" data-value="'+esc(f['token'])+'"'+(' disabled' if busy and not f['dir'] else '')+'><b>'+('▸ ' if f['dir'] else '')+esc(f['name'])+'</b></button>'
        if not b['items']:browser+='<p>지원하는 파일이 없습니다.</p>'
        browser+='</div></div>'
    model=next((m for m in s['models'] if m['id']==s['model']),None)
    composer={'model':(model['name'] if model else '모델')+' · '+str(s.get('effort') or ''),'status':s['error'] or s['message'],'error':bool(s['error']),'usage':usage}
    return {'side':side,'head':head,'messages':msgs,'alert':alert,'picker':picker,'chips':chips,'files':files,'browser':browser,'composer':composer,'session':s['session'],'nfiles':nfiles}
