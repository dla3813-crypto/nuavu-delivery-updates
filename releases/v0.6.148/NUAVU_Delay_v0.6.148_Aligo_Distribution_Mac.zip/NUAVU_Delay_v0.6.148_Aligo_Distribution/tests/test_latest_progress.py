"""v0.6.15: date-suffixed snapshots, missing-size matching and safe upgrades.
Synthetic workbook protocol fixtures only; all providers are fakes. No live I/O.
"""
import copy
import os
import plistlib
import unicodedata
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

import pytest

from domain import Engine, KST, SELLERS
from install_desktop import build_bundle
from supply_workflow import (
    SupplyError, candidates, digest, is_progress_file, legacy_option_parts,
    option_parts, order_signature, product_name, progress_filename_day,
    variant_id,
)
from helpers import Base
from test_supply_regression import order, source_row, xlsx


@pytest.mark.parametrize('filename,expected', [
    ('진행상황_1017.xlsx', '2026-10-17'),
    ('진행상황1017.xlsx', '2026-10-17'),
    ('진행상황 1017.xlsx', '2026-10-17'),
    ('진행상황 (1017).xlsx', '2026-10-17'),
    ('진행상황_1017 (1).xlsx', '2026-10-17'),
    ('진행상황_1017(2).XLSX', '2026-10-17'),
    ('진행상황_20261017.xlsx', '2026-10-17'),
    ('진행상황_2026-10-17.xlsx', '2026-10-17'),
    ('진행상황_2026.10.17.xlsx', '2026-10-17'),
    ('진행상황_2026_10_17.xlsx', '2026-10-17'),
    ('진행상황_2026년 10월 17일.xlsx', '2026-10-17'),
    ('진행상황_10월 17일.xlsx', '2026-10-17'),
    ('진행상황_10-17.xlsx', '2026-10-17'),
    ('진행상황_10.17.xlsx', '2026-10-17'),
    ('진행상황_1017_최종.xlsx', '2026-10-17'),
    ('진행 상황_1017.xlsx', '2026-10-17'),
    (unicodedata.normalize('NFD','진행상황_1017.xlsx'), '2026-10-17'),
    ('진행상황.xlsx', None),
    ('진행상황 (1).xlsx', None),
    ('진행상황_최종.xlsx', None),
])
def test_progress_names(filename, expected):
    assert is_progress_file(filename)
    value = progress_filename_day(filename, 2026)
    assert (value.isoformat() if value else None) == expected


@pytest.mark.parametrize('filename', [
    '진행상황_0230.xlsx', '진행상황_1331.xlsx', '진행상황_20260229.xlsx',
    '진행상황_2026-10-32.xlsx', '진행상황_20261301.xlsx', '진행상황_10170.xlsx',
])
def test_invalid_progress_dates_do_not_become_mtime(filename):
    with pytest.raises(SupplyError):
        progress_filename_day(filename, 2026)


@pytest.mark.parametrize('filename', [
    '출고장.xlsx', '진행상황_1017.xls', '진행상황_1017.xlsx.bak',
    '다른진행상황_1017.xlsx', '진행상황표.xlsx',
])
def test_unrelated_filenames_ignored(filename):
    assert not is_progress_file(filename)


def test_explicit_year_vs_workspace_year():
    assert progress_filename_day('진행상황_0102.xlsx', 2027).isoformat() == '2027-01-02'
    assert progress_filename_day('진행상황_20261231.xlsx', 2027).isoformat() == '2026-12-31'


@pytest.mark.parametrize('option,color', [
    ('블랙', '블랙'), ('[블랙]', '블랙'), ('컬러: 블랙', '블랙'),
    ('색상=아이보리', '아이보리'), ('[ 블랙 ]', '블랙'),
    ('블랙 /', '블랙'), ('[블랙-]', '블랙'),
    ('블랙 / 사이즈:', '블랙'), ('블랙 / []', '블랙'),
    ('블랙(모델착용)', '블랙'), ('[베이지(모델 착용)]', '베이지'),
    ('원컬러', '원컬러'), (unicodedata.normalize('NFD', '블랙'), '블랙'),
])
def test_omitted_order_size_is_free(option, color):
    assert option_parts(option) == (color, 'free')


@pytest.mark.parametrize('option,size', [
    ('블랙 / S','s'), ('[블랙-M]','m'), ('블랙-L','l'),
    ('컬러: 블랙 / 사이즈: 2XL','2xl'), ('[블랙-55]','55'),
    ('블랙 / 미확인','미확인'), ('블랙 / 사이즈: UNKNOWN','unknown'),
    ('[화이트-한장만 구매]',''),
])
def test_explicit_sizes_never_become_free(option,size):
    assert option_parts(option)[1] == size


@pytest.mark.parametrize('option', ['', None, '   ', '[]', '사이즈: FREE', 'M'])
def test_missing_color_does_not_auto_match(option):
    r=source_row()
    source={'brand':'N','product':'가디건','color':'아이보리','size':'F'}
    source['variant']=variant_id(source)
    hits,ambiguous,method=candidates(order(1,option=option),[source],{})
    assert not hits and not ambiguous


class LatestProgressTests(Base):
    def setUp(self):
        super().setUp()
        self.folder=Path(self.tmp.name)/'자료';self.folder.mkdir()
        self.engine.supply_link(str(self.folder))
        self.set_orders([order(1,option='아이보리')])

    def set_orders(self,rows):
        self.engine.import_rows({'rows':rows,'mode':'snapshot','scope':SELLERS,'replaceConfirmed':True})

    def write(self,name,rows=None,modified='2026-10-17 12:00:00'):
        path=self.folder/name
        path.write_bytes(xlsx([('테스트',rows if rows is not None else [source_row(office='2026-10-17')])]))
        stamp=int(datetime.fromisoformat(modified).replace(tzinfo=KST).timestamp()*1_000_000_000)
        os.utime(path,ns=(stamp,stamp))
        return path

    def row(self):
        return next(r for r in self.engine.public_state()['rows'] if r['active'])

    def test_dated_file_loads_and_color_only_order_matches(self):
        self.write('진행상황_1017.xlsx')
        result=self.engine.supply_refresh()
        self.assertEqual(result['files'],1)
        self.assertEqual(result['progressSelection']['name'],'진행상황_1017.xlsx')
        self.assertTrue(self.row()['supplyInfo']['matched'])
        self.assertEqual(self.row()['supplyInfo']['parsedSize'],'free')
        self.assertEqual(self.row()['dispatchEnd'],'2026-10-22')
        self.assertFalse(self.row()['stockSecured'])

    def test_filename_date_wins_over_copy_mtime(self):
        self.write('진행상황_1016.xlsx',modified='2026-10-19 15:00:00')
        self.write('진행상황_1017.xlsx',modified='2026-10-17 10:00:00')
        result=self.engine.supply_refresh()
        self.assertEqual(result['progressSelection']['name'],'진행상황_1017.xlsx')
        self.assertEqual(result['progressSelection']['ignoredCount'],1)

    def test_snapshot_date_need_not_equal_order_today_or_manifest(self):
        self.write('진행상황_1031.xlsx')
        self.write('솔리아 10월 13일 출고장 (완료).xlsx',[source_row(product='별도상품')])
        result=self.engine.supply_refresh()
        self.assertEqual(result['files'],2)
        self.assertEqual(result['progressSelection']['name'],'진행상황_1031.xlsx')
        self.assertEqual(self.row()['dispatchEnd'],'2026-10-22') # V=10/17, NOT filename 10/31

    def test_month_boundary_uses_real_date(self):
        self.write('진행상황_0930.xlsx');self.write('진행상황_1001.xlsx')
        self.assertEqual(self.engine.supply_refresh()['progressSelection']['name'],'진행상황_1001.xlsx')

    def test_explicit_year_boundary(self):
        self.write('진행상황_20261231.xlsx');self.write('진행상황_20270101.xlsx')
        self.assertEqual(self.engine.supply_refresh()['progressSelection']['name'],'진행상황_20270101.xlsx')

    def test_same_day_uses_later_modification_not_copy_number(self):
        self.write('진행상황_1017 (99).xlsx',modified='2026-10-17 10:00:00')
        self.write('진행상황_1017.xlsx',modified='2026-10-17 11:00:00')
        self.assertEqual(self.engine.supply_refresh()['progressSelection']['name'],'진행상황_1017.xlsx')

    def test_undated_does_not_override_a_dated_snapshot(self):
        self.write('진행상황.xlsx',modified='2026-12-01 12:00:00')
        self.write('진행상황_1017.xlsx')
        self.assertEqual(self.engine.supply_refresh()['progressSelection']['name'],'진행상황_1017.xlsx')

    def test_undated_only_uses_latest_mtime(self):
        self.write('진행상황.xlsx',modified='2026-10-17 13:00:00')
        self.write('진행상황 (1).xlsx',modified='2026-10-17 12:00:00')
        result=self.engine.supply_refresh()['progressSelection']
        self.assertEqual(result['name'],'진행상황.xlsx')
        self.assertEqual(result['dateSource'],'modified')

    def test_same_rank_same_contents_read_once(self):
        self.write('진행상황_1017.xlsx');self.write('진행상황_1017 (1).xlsx')
        result=self.engine.supply_refresh()
        self.assertEqual(result['files'],1)
        self.assertEqual(len(self.store.read()['supply']['progress']),1)

    def test_same_rank_different_contents_atomic(self):
        self.write('진행상황_1016.xlsx');self.engine.supply_refresh()
        before=copy.deepcopy(self.store.read())
        self.write('진행상황_1017.xlsx');self.write('진행상황_1017 (1).xlsx',[source_row(qty=5)])
        with self.assertRaisesRegex(SupplyError,'내용이 서로'):
            self.engine.supply_refresh()
        self.assertEqual(self.store.read(),before)

    def test_newest_corrupt_never_falls_back(self):
        self.write('진행상황_1016.xlsx');self.engine.supply_refresh()
        before=copy.deepcopy(self.store.read())
        (self.folder/'진행상황_1017.xlsx').write_bytes(b'broken')
        with self.assertRaises(SupplyError):self.engine.supply_refresh()
        self.assertEqual(self.store.read(),before)

    def test_bad_old_workbook_not_opened(self):
        (self.folder/'진행상황_1016.xlsx').write_bytes(b'old broken contents')
        self.write('진행상황_1017.xlsx')
        self.assertEqual(self.engine.supply_refresh()['files'],1)

    def test_invalid_filename_date_preserves_previous_state(self):
        self.write('진행상황_1017.xlsx');self.engine.supply_refresh()
        before=copy.deepcopy(self.store.read())
        self.write('진행상황_1331.xlsx')
        with self.assertRaises(SupplyError):self.engine.supply_refresh()
        self.assertEqual(self.store.read(),before)

    def test_prior_progress_snapshots_not_summed(self):
        self.set_orders([order(1,qty=2,option='아이보리')])
        self.write('진행상황_1016.xlsx',[source_row(qty=1,office='2026-10-17')])
        self.write('진행상황_1017.xlsx',[source_row(qty=1,office='2026-10-17')])
        self.engine.supply_refresh()
        self.assertEqual(self.row()['supplyInfo']['plannedQty'],1)
        self.assertEqual(self.row()['dispatchEnd'],'')

    def test_newest_replaces_old_not_merge(self):
        self.write('진행상황_1016.xlsx');self.engine.supply_refresh()
        self.assertTrue(self.row()['supplyInfo']['matched'])
        self.write('진행상황_1017.xlsx',[source_row(product='다른상품',office='2026-10-17')])
        self.engine.supply_refresh()
        self.assertFalse(self.row()['supplyInfo']['matched'])
        self.assertEqual(len(self.store.read()['supply']['progress']),1)

    def test_filename_date_does_not_replace_blank_V(self):
        self.write('진행상황_1017.xlsx',[source_row(purchase='2026-10-14')])
        self.engine.supply_refresh()
        self.assertTrue(self.row()['supplyInfo']['matched'])
        self.assertEqual(self.row()['dispatchEnd'],'')
        self.assertEqual(self.row()['supplyInfo']['reasonCode'],'OFFICE_UNARRIVED')

    def test_new_file_not_read_until_manual_refresh(self):
        self.write('진행상황_1016.xlsx');self.engine.supply_refresh()
        self.write('진행상황_1017.xlsx',[source_row(product='다른상품',office='2026-10-17')])
        self.restart()
        self.assertEqual(self.engine.public_state()['supply']['lastScan']['progressSelection']['name'],'진행상황_1016.xlsx')
        self.assertTrue(self.row()['supplyInfo']['matched'])
        self.engine.supply_refresh()
        self.assertFalse(self.row()['supplyInfo']['matched'])

    def test_more_than_100_daily_snapshots_are_allowed(self):
        for i in range(110):
            from datetime import timedelta,date
            day=date(2026,1,1)+timedelta(days=i)
            self.write('진행상황_'+day.strftime('%m%d')+'.xlsx')
        result=self.engine.supply_refresh()
        self.assertEqual(result['files'],1)
        self.assertEqual(result['progressSelection']['candidateCount'],110)

    def test_temp_hidden_and_symlink_files_are_ignored(self):
        self.write('진행상황_1016.xlsx')
        (self.folder/'~$진행상황_1017.xlsx').write_bytes(b'not an excel')
        (self.folder/'.진행상황_1017.xlsx').write_bytes(b'not an excel')
        (self.folder/'진행상황_1018.xlsx').symlink_to(self.folder/'진행상황_1016.xlsx')
        self.assertEqual(self.engine.supply_refresh()['progressSelection']['name'],'진행상황_1016.xlsx')

    def test_subdirectories_not_scanned(self):
        self.write('진행상황_1016.xlsx');sub=self.folder/'백업';sub.mkdir()
        (sub/'진행상황_1017.xlsx').write_bytes(xlsx([('t',[source_row()])]))
        self.assertEqual(self.engine.supply_refresh()['progressSelection']['name'],'진행상황_1016.xlsx')

    def test_different_brand_warns_without_auto_selecting(self):
        self.write('진행상황_1017.xlsx',[source_row(brand='OD',office='2026-10-17')])
        result=self.engine.supply_refresh()
        self.assertIn('선택 브랜드에 해당하는 행이 0개',result['warnings'][0])
        self.assertIn('OD',result['warnings'][0])
        self.assertFalse(self.row()['supplyInfo']['matched'])
        self.assertEqual(self.store.read()['supply']['brands'],['N','NS'])
        self.engine.supply_settings({'year':2026,'brands':['OD'],'holidays':[]})
        self.engine.supply_refresh()
        self.assertTrue(self.row()['supplyInfo']['matched'])

    def test_color_only_matches_completed_manifest(self):
        self.write('솔리아 10월 13일 출고장 (완료).xlsx',[source_row()])
        self.engine.supply_refresh()
        self.assertTrue(self.row()['stockSecured'])
        self.assertEqual(self.row()['supplyInfo']['manifestQty'],1)

    def test_missing_size_uses_existing_FREE_exception_even_source_L(self):
        self.write('솔리아 10월 13일 출고장 (완료).xlsx',[source_row(size='L')])
        self.engine.supply_refresh()
        self.assertTrue(self.row()['stockSecured'])

    def test_explicit_M_does_not_match_L(self):
        self.set_orders([order(1,option='아이보리 / M')])
        self.write('솔리아 10월 13일 출고장 (완료).xlsx',[source_row(size='L')])
        self.engine.supply_refresh()
        self.assertFalse(self.row()['supplyInfo']['matched'])

    def test_size_omission_does_not_ignore_color(self):
        self.set_orders([order(1,option='블랙')])
        self.write('솔리아 10월 13일 출고장 (완료).xlsx',[source_row(color='아이보리')])
        self.engine.supply_refresh()
        self.assertFalse(self.row()['supplyInfo']['matched'])

    def test_missing_size_respects_one_unit_fifo(self):
        self.set_orders([order(2,option='아이보리'),order(1,option='아이보리 / FREE')])
        self.write('솔리아 10월 13일 출고장 (완료).xlsx',[source_row(qty=1)])
        self.engine.supply_refresh()
        rows={r['orderId']:r for r in self.engine.public_state()['rows'] if r['active']}
        self.assertTrue(rows['TEST-001']['stockSecured'])
        self.assertFalse(rows['TEST-002']['stockSecured'])
        self.assertTrue(rows['TEST-002']['supplyInfo']['matched'])

    def test_identifiers_and_manual_mapping_unchanged(self):
        self.write('진행상황_1017.xlsx',[source_row(product='별칭 가디건',office='2026-10-17')])
        self.engine.supply_refresh()
        row=self.row();original=copy.deepcopy(self.store.read()['rows'])
        self.assertEqual(order_signature(row),digest([product_name(row['product']),*legacy_option_parts(row['option'])]))
        vid=self.engine.public_state()['supply']['variants'][0]['variant']
        self.engine.supply_match({'key':row['key'],'variants':[vid]})
        self.engine.supply_refresh();self.restart()
        self.assertTrue(self.row()['supplyInfo']['matched'])
        self.assertEqual(self.row()['supplyInfo']['matchMethod'],'manual')
        self.assertEqual(self.store.read()['rows'],original)

    def test_same_wave_no_progress_plus_manifest_double_count(self):
        self.set_orders([order(1,option='아이보리'),order(2,option='아이보리')])
        self.write('진행상황_1017.xlsx',[source_row(office='2026-10-13')])
        self.write('솔리아 10월 13일 출고장 (완료).xlsx',[source_row()])
        self.engine.supply_refresh()
        rows=[r for r in self.engine.public_state()['rows'] if r['active']]
        self.assertEqual(sum(r['supplyInfo']['allocatedQty'] for r in rows),1)

    def test_closed_manifest_not_resurrected_by_new_snapshot(self):
        self.write('솔리아 10월 13일 출고장 (완료).xlsx',[source_row()])
        self.engine.supply_refresh();self.engine.supply_reset({'confirmed':True})
        self.set_orders([order(2,option='아이보리')])
        self.write('진행상황_1017.xlsx',[source_row(office='2026-10-13')])
        self.engine.supply_refresh()
        self.assertFalse(self.row()['stockSecured'])
        self.assertEqual(self.row()['supplyInfo']['allocatedQty'],0)

    def test_failed_corrupt_latest_keeps_closed_manifests_and_mappings(self):
        self.write('솔리아 10월 13일 출고장 (완료).xlsx',[source_row()])
        self.engine.supply_refresh();self.engine.supply_reset({'confirmed':True})
        before=copy.deepcopy(self.store.read())
        (self.folder/'진행상황_1017.xlsx').write_bytes(b'invalid')
        with self.assertRaises(SupplyError):self.engine.supply_refresh()
        self.assertEqual(before,self.store.read())

    def test_no_notice_mutation_or_live_send_from_refresh(self):
        self.queue(keys=[self.row()['key']],sendMode='MORNING')
        before=copy.deepcopy(self.store.read()['notices'])
        self.write('진행상황_1017.xlsx');self.engine.supply_refresh()
        self.assertEqual(self.store.read()['notices'],before)
        self.assertFalse(self.fake.sent)
        self.assertFalse(self.fake.report_calls)
        self.assertFalse(self.at.sent)

    def test_v0614_upgrade_preserves_queue_ids_settings_and_supply(self):
        self.queue(keys=[self.row()['key']],sendMode='MORNING')
        self.write('진행상황_1017.xlsx');self.engine.supply_refresh()
        with self.store.edit() as s:
            s['appVersion']='0.6.14'
            s['alerts'].append({'code':'RESULT_UNCONFIRMED','resolvedAt':'','id':'TEST','noticeId':'EXAMPLE_UNCONFIRMED','level':'error'})
        before=copy.deepcopy(self.store.read())
        self.restart();after=self.store.read()
        for key in ['rows','settings','supply','alerts']:
            self.assertEqual(after[key],before[key],key)
        # Normal restarts append pause/recovery events, but keep content, IDs,
        # state and the original scheduled time. Those are not a migration loss.
        self.assertEqual(len(after['notices']),len(before['notices']))
        for old,new in zip(before['notices'],after['notices']):
            for key in old.keys()|new.keys():
                if key not in {'events','note','resumedAt'}:
                    self.assertEqual(new.get(key),old.get(key),key)
            self.assertEqual(new['events'][:len(old['events'])],old['events'])
        self.assertEqual(after['appVersion'],'0.6.148')
        self.assertFalse(self.fake.sent)

    def test_bundle_update_only_replaces_distribution_app(self):
        home=Path(self.tmp.name)/'Applications';home.mkdir()
        original=home/'누아브 배송안내.app';original.mkdir();(original/'keep').write_text('ORIGINAL')
        distribution=home/'배송안내 배포판.app';distribution.mkdir();(distribution/'old').write_text('OLD')
        target=build_bundle(distribution,Path('/example/python'))
        self.assertEqual((original/'keep').read_text(),'ORIGINAL')
        self.assertEqual(len(list(home.glob('배송안내 배포판.before-*.app'))),1)
        info=plistlib.loads((target/'Contents/Info.plist').read_bytes())
        self.assertEqual(info['CFBundleVersion'],'0.6.148')
        self.assertIn('latest_progress_files',(target/'Contents/Resources/supply_workflow.py').read_text())
