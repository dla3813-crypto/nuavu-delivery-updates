"""배포판 v0.6.148 (2026-11-09 14:48 사장님, 누아브판 0.6.159 이식): 수동 매칭해 둔 발주 행이 사라진 뒤(출고장 완료·삭제) — 로아 베이직 사선 더플 블랙 후드 숏 코트 자켓 사례.
① 수동 규칙의 행이 모두 사라지면 자동 규칙으로 되돌린다 (진행상황 20이 자동으로 붙음).
② 수동 매칭 창에서 사라진 행 id가 섞여 저장돼도 "현재 선택 브랜드의 상품이 아닙니다"로 막지 않고 살아 있는 id만 저장한다."""
import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]));sys.path.insert(0,str(Path(__file__).resolve().parent))
from supply_workflow import candidates,variant_id,order_signature,SupplyError
from domain import SELLERS
from helpers import Base
from test_supply_regression import order,source_row,xlsx

def variant(product,color,size,brand='N',kind='progress',qty=5,office=''):
    r={'brand':brand,'product':product,'color':color,'size':size,'qty':qty,'sheet':'s','line':1,'sourceFile':'f.xlsx','kind':kind,
       'shipDate':'2026-11-03' if kind=='manifest' else '','basisDate':office,'officeDate':office,'officeRaw':office,'purchaseDate':'','basisType':kind}
    r['variant']=variant_id(r);return r

ROA='로아 베이직 사선 더플 블랙 후드 숏 코트 자켓'
class VanishedRuleFallsBackToAutomatic(unittest.TestCase):
    def test_all_manual_rows_gone_uses_automatic(self):
        row={'product':ROA,'option':'[One Color-FREE]','qty':1}
        progress=variant(ROA,'One Color','M')
        maps={order_signature(row):['manifest-row-that-was-removed']}
        hits,amb,how=candidates(row,[progress],maps)
        self.assertEqual(([h['variant'] for h in hits],amb,how),([progress['variant']],False,'automatic'))
    def test_some_manual_rows_remain_keeps_manual_union(self):
        row={'product':ROA,'option':'[One Color-FREE]','qty':1}
        m=variant(ROA,'M','M',kind='manifest');p=variant(ROA,'One Color','M')
        hits,amb,how=candidates(row,[m,p],{order_signature(row):[m['variant'],'gone']})
        self.assertEqual(([h['variant'] for h in hits],how),([m['variant'],p['variant']],'manual'))
    def test_exclusion_rule_still_excludes(self):
        row={'product':ROA,'option':'[One Color-FREE]','qty':1}
        self.assertEqual(candidates(row,[variant(ROA,'One Color','M')],{order_signature(row):[]})[0],[])

class StaleIdsOnSave(Base):
    def setUp(self):
        super().setUp();self.folder=Path(self.tmp.name)/'supply';self.folder.mkdir();self.engine.supply_link(str(self.folder))
        with self.store.edit() as s:s['settings']['shopName']='누아브'
    def set_orders(self,rows):self.engine.import_rows(dict(rows=rows,mode='snapshot',scope=SELLERS,replaceConfirmed=True))
    def refresh(self,rows):
        (self.folder/'솔리아 11월 3일 출고장 (완료).xlsx').write_bytes(xlsx([('가상 출고장',rows)]));return self.engine.supply_refresh()
    def active(self):return [r for r in self.engine.public_state()['rows'] if r['active']]
    def test_stale_rule_id_is_dropped_not_rejected(self):
        self.set_orders([order(1,product=ROA,option='One Color / FREE')])
        self.refresh([source_row(product=ROA,color='One Color',size='M',qty=20)])
        r=self.active()[0];live=self.engine.public_state()['supply']['variants'][0]['variant']
        sig=order_signature(r)
        with self.store.edit() as s:s['supply']['mappings'][sig]=['removed-manifest-row']   # 치워진 출고장 행만 남은 규칙
        self.engine.supply_match({'key':r['key'],'variants':['removed-manifest-row',live]})
        self.assertEqual(self.store.read()['supply']['mappings'][sig],[live])
    def test_unknown_id_still_rejected(self):
        self.set_orders([order(1,product=ROA,option='One Color / FREE')])
        self.refresh([source_row(product=ROA,color='One Color',size='M',qty=20)])
        r=self.active()[0]
        with self.assertRaises(SupplyError):self.engine.supply_match({'key':r['key'],'variants':['never-existed']})
    def test_only_stale_ids_clears_rule_back_to_automatic(self):
        self.set_orders([order(1,product=ROA,option='One Color / FREE')])
        self.refresh([source_row(product=ROA,color='One Color',size='M',qty=20)])
        r=self.active()[0];sig=order_signature(r)
        with self.store.edit() as s:s['supply']['mappings'][sig]=['removed-manifest-row']
        self.engine.supply_match({'key':r['key'],'variants':['removed-manifest-row']})
        self.assertNotIn(sig,self.store.read()['supply']['mappings'])
        self.assertEqual(self.active()[0]['supplyInfo']['matchMethod'],'automatic')

if __name__=='__main__':unittest.main()
