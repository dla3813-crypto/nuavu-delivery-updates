"""배포판 v0.6.148 (2026-11-09 00:45 사장님, 누아브판 0.6.158 이식): 11/3(화) 출고장이 완료 후 폴더에서 치워진 뒤 11/9 00:39 '출고장 없음' 알림이 뜬 문제.
- 기억된 마지막 출고장 날짜(progressCutoff) >= 그 화요일이면 묻지 않는다.
- 마감(수요일 18:00 KST) 뒤 사장님이 수동으로 출고장을 갱신했으면 빨간 알림은 생략 (ship_delay_manual_seen)."""
import sys,unittest
from pathlib import Path
from datetime import datetime,timezone,timedelta
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from supply_workflow import ship_delay_question
from domain import ship_delay_manual_seen
KST=timezone(timedelta(hours=9))

class CutoffTests(unittest.TestCase):
    V={'folder':'/x','manifests':{},'shipDelays':{},'year':2026}
    MON=datetime(2026,11,9,0,39,tzinfo=KST)   # 월요일 00:39, 11/3(화) 질문 창 안
    def test_real_case_remembered_manifest_suppresses_question(self):
        self.assertEqual(ship_delay_question(self.V,self.MON)['tuesday'],'2026-11-03')
        self.assertIsNone(ship_delay_question({**self.V,'progressCutoff':'2026-11-03'},self.MON))
        self.assertIsNone(ship_delay_question({**self.V,'progressCutoff':'2026-11-07'},self.MON))   # 더 뒤 날짜 기억도 충분
    def test_older_remembered_date_still_asks(self):
        self.assertEqual(ship_delay_question({**self.V,'progressCutoff':'2026-10-31'},self.MON)['tuesday'],'2026-11-03')
    def test_remembered_date_from_manifest_list_also_counts(self):
        v={**self.V,'manifests':{'manifest:2026-11-03':{'date':'2026-11-03'}}}
        self.assertIsNone(ship_delay_question(v,self.MON))

class ManualSeenTests(unittest.TestCase):
    def test_manual_read_after_deadline(self):
        self.assertTrue(ship_delay_manual_seen('2026-11-03','2026-11-08T15:16:57.998+00:00'))   # 11/9 00:16 KST
        self.assertTrue(ship_delay_manual_seen('2026-11-03','2026-11-04T09:00:00+00:00'))        # 수요일 18:00 KST 정각
    def test_manual_read_before_deadline_does_not_count(self):
        self.assertFalse(ship_delay_manual_seen('2026-11-03','2026-11-04T08:59:59+00:00'))
        self.assertFalse(ship_delay_manual_seen('2026-11-03',''));self.assertFalse(ship_delay_manual_seen('bad','2026-11-05T00:00:00+00:00'))

if __name__=='__main__':unittest.main()
