"""Isolated aftersales tests: fake vault, synthetic rows, temporary reports only."""
import unittest,tempfile,threading,copy,io,zipfile
from pathlib import Path
from datetime import date,datetime
from zoneinfo import ZoneInfo
from unittest.mock import patch
from types import SimpleNamespace
from domain import Store
from aftersales_data import auto_candidates,shop,public_aftersales,parse_pickup_input,read_local
from pickup_browser import recipient_option,verified_result,existing
from pickup_controller import PickupController
from return_check import ReturnController
from return_data import ReturnError,clean_tracking
from order_auto import OrderAutoError
from exchange_browser import parse_exchange,detail_invoice,FIELDS
from pickup_report import report_bytes,save_report
from workbook_reader import read_xlsx
try:from helpers import MemoryVault
except ImportError:from test_v052 import MemoryVault
TODAY=date(2026,10,18)
NOW=datetime(2026,10,18,10,tzinfo=ZoneInfo('Asia/Seoul'))
def row(n='610000000001',status='NONE',issue=''):
 return dict(key=n,invoice=n,orderId='TEST-'+n,itemId=n,product='가상상품',requestedAt='2026-10-16',fee=0,reason='고객변심',customer='주문자',recipient='수령인',recipientPhone='01000001234',returnStatus=status,issue=issue,origDelivered='2026-10-15',returnDelivered='',returnNo='')
def snapshot(rows):return dict(shopName='테스트상점',shopRevision=1,rows=rows,lastChecked=NOW.isoformat())
class Pure(unittest.TestCase):
 def test_candidate_classes_and_scope(self):
  state={'settings':{'shopName':'테스트상점','shopRevision':1},'returnCheck':snapshot([row(),row('610000000002',issue='실패'),row('610000000003','IN_TRANSIT'),row('610000000004','DELIVERED')]),'exchangeCheck':snapshot([row('610000000005')])}
  got=auto_candidates(state,TODAY);self.assertEqual([r['invoice'] for r in got],['610000000001','610000000002','610000000005']);self.assertEqual(got[0]['customer'],'수령인')
  state['pickupHistory']=[{'invoice':got[0]['invoice'],**shop(state),'result':'접수 실패'}];self.assertEqual(len(auto_candidates(state,TODAY)),2)
  state['settings']['shopRevision']=2;self.assertEqual(auto_candidates(state,TODAY),[])
 def test_only_requested_sections_and_conflicting_recipient(self):
  state={'settings':{'shopName':'테스트상점','shopRevision':1},'returnCheck':snapshot([row()|{'fee':-3000},row('610000000002')]),'exchangeCheck':snapshot([row('610000000002')|{'recipient':'다른수령인'}])}
  candidates=auto_candidates(state,TODAY);self.assertEqual(len(candidates),1);self.assertTrue(candidates[0]['preflightIssue'])
 def test_duplicate_input_merge_and_conflict(self):
  self.assertEqual(len(parse_pickup_input([{'invoice':'6100-0000-0001'},{'invoice':'610000000001','customer':'A'}])),1)
  with self.assertRaises(ReturnError):parse_pickup_input([{'invoice':'610000000001','customer':'A'},{'invoice':'610000000001','customer':'B'}])
  for values in ([],[{'invoice':'bad'}],[None]):
   with self.subTest(values=values),self.assertRaises(ReturnError):parse_pickup_input(values)
 def test_recipient_exact_carrier_and_ambiguity(self):
  opts=[{'value':'1','text':'테스트상점'},{'value':'2','text':'테스트상점(우체국)'}]
  self.assertEqual(recipient_option(opts,'테스트상점','EPOST')['value'],'2');self.assertEqual(recipient_option(opts,'테스트상점','CJ')['value'],'1')
  for opts2 in ([],opts+[opts[1]], [{'value':'3','text':'다른상점'}]):
   with self.assertRaises(OrderAutoError):recipient_option(opts2,'테스트상점','EPOST')
 def test_success_requires_all_evidence(self):
  s={'registrations':[{'status':'준비중','carrier':'우체국택배','receiver':'테스트상점','at':'2026-10-18 10:00:00'}],'original':'610000000001','date':'2026-10-18','modify':True,'delete':True}
  self.assertEqual(verified_result(s,'610000000001','EPOST','테스트상점',[]),'접수 완료')
  for key,val in [('original','610000000002'),('date',''),('modify',False),('delete',False),('registrations',[])]:
   with self.subTest(key=key):self.assertEqual(verified_result(s|{key:val},'610000000001','EPOST','테스트상점',[]),'접수 실패')
  wrong=copy.deepcopy(s);wrong['registrations'][0]['carrier']='대한통운';self.assertEqual(verified_result(wrong,'610000000001','EPOST','테스트상점',[]),'택배사 잘못 접수')
  self.assertEqual(verified_result(s,'610000000001','EPOST','테스트상점',s['registrations']),'접수 실패')
 def test_existing_registration_guard(self):
  for s in ({'modify':True,'delete':False,'registrations':[]},{'modify':False,'delete':True,'registrations':[]},{'modify':False,'delete':False,'registrations':[{'status':'요청'}]}):self.assertTrue(existing(s))
 def test_exchange_named_fields_and_detail(self):
  vals={'requestId':'R1','requestedAt':'2026-10-18 10:00:00','exchangeStatus':'교환요청','itemId':'123456','orderId':'TEST-1','product':'테스트','option':'블랙','exchangeOption':'화이트','qty':'1','fee':'0원','returnNo':'-','customer':'가상','recipientPhone':'01000001234','reason':'교환'}
  parsed=parse_exchange(list(FIELDS.values()),[[vals[k] for k in FIELDS]],'교환요청');self.assertEqual(parsed[0]['exchangeOption'],'화이트');self.assertEqual(parsed[0]['returnNo'],'')
  with self.assertRaises(ReturnError):parse_exchange(list(FIELDS.values()),[[vals[k] for k in FIELDS]],'교환수거중')
  text='상품주문정보 조회 [123456]\n배송정보\n송장번호\n\n610000000001\n배송지정보\n송장번호\n510000000001'
  self.assertEqual(detail_invoice(text,'123456'),'610000000001')
  with self.assertRaises(ReturnError):detail_invoice(text,'999999')
 def test_report_no_formula_and_preserves_text(self):
  rows=[{'invoice':'00000000000001','customer':'=1+1','result':'접수 실패','attempt':2}]
  raw=report_bytes(rows);book=read_xlsx(raw);self.assertEqual(str(book[0]['rows'][2][0]),'00000000000001');self.assertEqual(book[0]['rows'][2][1],'=1+1')
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   xml=z.read('xl/worksheets/sheet1.xml');self.assertIn(b'autoFilter',xml);self.assertIn(b'A2:J3',xml);self.assertNotIn(b'<f>',xml)  # v0.6.148/v0.6.148: + 에이블리 접수·안내 columns
  with tempfile.TemporaryDirectory() as d:
   one=save_report(rows,d,NOW);two=save_report(rows,d,NOW);self.assertNotEqual(one,two);self.assertEqual(Path(one).stat().st_mode&0o777,0o600)
class Controllers(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.store=Store(Path(self.tmp.name)/'db')
  with self.store.edit() as s:s['settings'].update(shopName='테스트상점',shopRevision=1);s['returnCheck']=snapshot([row()])
  self.engine=SimpleNamespace(store=self.store,stop=threading.Event());self.cs=[]
  self.report=patch('pickup_report.save_report',return_value=str(Path(self.tmp.name)/'result.xlsx'));self.report.start();self.addCleanup(self.report.stop)
 def tearDown(self):
  for c in self.cs:c.shutdown();c.thread.join(2) if c.thread else None
  self.store.close();self.tmp.cleanup()
 def ctrl(self,runner):
  c=PickupController(self.engine,runner=runner,vault=MemoryVault(),clock=lambda:NOW);self.cs.append(c);return c
 def test_auto_defaults_off_and_claim_once_across_restart(self):
  def run(c,rows,shop,inspect):
   self.assertEqual(c.store.read()['pickupHistory'][0]['result'],'처리 대기')
   c.record({'invoice':rows[0]['invoice'],'result':'조회 실패'})
  c=self.ctrl(run);self.assertFalse(c.tick());c.save(True);self.assertTrue(c.tick());c.thread.join(2);self.assertFalse(c.tick())
  other=self.ctrl(run);self.assertFalse(other.tick());self.assertEqual(len(self.store.read()['pickupHistory']),1)
 def test_manual_attempts_durable_and_increment(self):
  def run(c,rows,shop,inspect):
   c.before_submit(rows[0]['invoice']);self.assertEqual(c.store.read()['pickupHistory'][-1]['result'],'접수 결과 미확인');c.record({'invoice':rows[0]['invoice'],'result':'접수 완료','phone':'01000000000'})
  c=self.ctrl(run)
  for _ in range(2):c.start_pickups([row()]);c.thread.join(2)
  hs=self.store.read()['pickupHistory'];self.assertEqual([h['attempt'] for h in hs],[1,2]);self.assertNotIn('phone',hs[0])
 def test_inspect_has_no_persistent_attempt(self):
  c=self.ctrl(lambda c,rows,*args:c.record({'invoice':rows[0]['invoice'],'result':'접수 전 확인'},True));c.start_pickups([row()],inspect_only=True);c.thread.join(2);self.assertFalse(self.store.read().get('pickupHistory'));self.assertEqual(c.status()['rows'][0]['result'],'접수 전 확인')
 def test_crash_after_click_keeps_unknown_and_unprocessed(self):
  def run(c,rows,*args):c.before_submit(rows[0]['invoice']);raise OrderAutoError('중단')
  c=self.ctrl(run);c.start_pickups([row(),row('610000000002')]);c.thread.join(2)
  got=c.status();self.assertEqual(len(got['rows']),2);self.assertEqual(got['rows'][0]['result'],'접수 결과 미확인');self.assertEqual(got['phase'],'error');self.assertEqual(len(auto_candidates(self.store.read(),TODAY)),0)
 def test_shop_change_before_click_blocks(self):
  def run(c,rows,*args):
   with self.store.edit() as s:s['settings']['shopName']='변경'
   with self.assertRaises(OrderAutoError):c.before_submit(rows[0]['invoice'])
  c=self.ctrl(run);c.start_pickups([row()]);c.thread.join(2);self.assertFalse(any(h.get('attempt') for h in self.store.read().get('pickupHistory',[])))
 def test_busy_and_reset_guard(self):
  c=self.ctrl(lambda *args:None);c.busy=lambda:True
  with self.assertRaises(OrderAutoError):c.start_pickups([row()])
  c.busy=lambda:False;self.engine.reset_in_progress=True
  with self.assertRaises(OrderAutoError):c.start_pickups([row()])
 def test_return_and_exchange_atomic_separate(self):
  c=ReturnController(self.engine,runner=lambda account,c:dict(complete=True,total=1,rows=[row('610000000002')]),vault=MemoryVault(),clock=lambda:NOW,local=True);self.cs.append(c)
  c.accounts.for_login=lambda:{};c.start(kind='exchange');c.thread.join(2)
  self.assertEqual(self.store.read()['returnCheck']['rows'][0]['invoice'],'610000000001');self.assertEqual(self.store.read()['exchangeCheck']['rows'][0]['invoice'],'610000000002')
  old=copy.deepcopy(self.store.read()['exchangeCheck']);c.runner=lambda *args:dict(complete=False,rows=[],total=0);c.start(kind='exchange');c.thread.join(2);self.assertEqual(old,self.store.read()['exchangeCheck'])
 def test_seller_only_run_replaces_only_that_seller(self):
  """2026-10-21 20:06: 판매처별 실제 반품조회 — 다른 판매처 결과는 그대로."""
  with self.store.edit() as s:s['returnCheck']=snapshot([row('610000000001')|{'seller':'에이블리'},row('610000000009')|{'seller':'자사몰','key':'cafe24:old'},row('610000000008')|{'seller':'지그재그','key':'zz:1'}])|{'zigzag':{'enabled':True,'totals':{'반품요청':1}}}
  c=ReturnController(self.engine,runner=lambda account,c:dict(complete=True,total=1,rows=[row('610000000005')|{'seller':'자사몰','key':'cafe24:new'}],cafe24={'enabled':True,'totals':{'진행 중':1},'error':''}),vault=MemoryVault(),clock=lambda:NOW,local=True);self.cs.append(c)
  c.start(kind='seller',seller='자사몰');c.thread.join(3)
  saved=self.store.read()['returnCheck']
  self.assertEqual(sorted((r['seller'],r['invoice']) for r in saved['rows']),[('에이블리','610000000001'),('자사몰','610000000005'),('지그재그','610000000008')])
  self.assertEqual(saved['zigzag']['totals'],{'반품요청':1});self.assertEqual(saved['cafe24']['totals'],{'진행 중':1})
  self.assertIn('자사몰만 조회',c.status()['message'])
  with self.assertRaises(ReturnError):c.start(kind='seller',seller='쿠팡')

if __name__=='__main__':unittest.main()
