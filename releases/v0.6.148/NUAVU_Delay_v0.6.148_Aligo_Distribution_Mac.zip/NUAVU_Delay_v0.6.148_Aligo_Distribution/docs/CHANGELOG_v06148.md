# NUAVU_Delay_v0.6.148_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06147.md

## 2026-11-09 14:48 사장님 (배포 대상: 0.6.147 → 0.6.148) — 누아브판 0.6.159 이식 (patch/apply_06159_stale_manual_mapping.py, 공용)
- candidates: 수동 규칙의 행이 모두 사라졌으면 자동 규칙으로. supply_match: 사라진 규칙 id는 버리고 살아 있는 id만 저장(모르는 id만 오류), 전부 사라졌으면 규칙 제거. app.js: 현재 후보 목록에 있는 id만 전송.
- 테스트 tests/test_stale_manual_mapping_06148.py (6, 배포판 harness), test_manual_plus_auto_match_06146 기대값 1건 갱신.
