"""v0.6.13 source stage/exchange changes. Temporary DB, offline fake providers."""
import copy,json,subprocess,unittest
from pathlib import Path
from helpers import Base
from test_supply_regression import order,source_row,xlsx
from supply_workflow import allocation_view,read_supplier,progress_facts
from domain import APP_VERSION
ROOT=Path(__file__).resolve().parents[1]
class StageTests(Base):
    def setUp(self):
        super().setUp();self.folder=Path(self.tmp.name)/'자료';self.folder.mkdir();self.engine.supply_link(str(self.folder))
        with self.store.edit() as s:s['rows']=[]
    def seed(self,items=None,progress=None,manifest=None):
        self.engine.import_rows({'rows':items or [order(1)]})
        if progress is not None:(self.folder/'진행상황.xlsx').write_bytes(xlsx([('자료',progress)]))
        if manifest is not None:(self.folder/'솔리아 10월 13일 출고장 (완료).xlsx').write_bytes(xlsx([('자료',manifest)]))
        self.engine.supply_refresh();return self.engine.public_state()['rows']
    def test_blank_V_is_unconfirmed_even_with_L(self):
        r=self.seed(progress=[source_row(purchase='2026-10-13')])[0];self.assertFalse(r['progressHasOfficeDate']);self.assertEqual(r['progressStage'],'UNCONFIRMED');self.assertEqual(r['dispatchEnd'],'')
    def test_valid_V_is_planned(self):
        r=self.seed(progress=[source_row(office='2026-10-16')])[0];self.assertTrue(r['progressHasOfficeDate']);self.assertEqual(r['progressStage'],'PLANNED');self.assertEqual(r['dispatchStart'],'2026-10-21')
    def test_quantity_shortage_is_not_mistaken_for_V_blank(self):
        r=self.seed([order(1,qty=2)],progress=[source_row(qty=1,office='2026-10-16')])[0];self.assertEqual(r['dispatchEnd'],'');self.assertEqual(r['progressStage'],'PLANNED')
    def test_stock_consumed_by_earlier_orders_does_not_erase_V(self):
        r=self.seed([order(1),order(2)],progress=[source_row(qty=1,office='2026-10-16')]);self.assertEqual(r[1]['dispatchEnd'],'');self.assertTrue(r[1]['progressHasOfficeDate'])
    def test_zero_quantity_still_retains_V_presence(self):
        r=self.seed(progress=[source_row(qty=0,office='2026-10-16')])[0];self.assertTrue(r['progressHasOfficeDate']);self.assertEqual(r['dispatchEnd'],'');self.assertEqual(r['supplyInfo']['allocatedQty'],0)
    def test_zero_quantity_V_blank_is_unconfirmed(self):
        r=self.seed(progress=[source_row(qty=0,purchase='2026-10-13')])[0];self.assertEqual(r['progressStage'],'UNCONFIRMED')
    def test_bad_V_does_not_use_purchase(self):
        r=self.seed(progress=[source_row(office='미도착',purchase='2026-10-13')])[0];self.assertFalse(r['progressHasOfficeDate']);self.assertEqual(r['dispatchEnd'],'')
    def test_wrong_color_does_not_borrow_V(self):
        r=self.seed(progress=[source_row(color='블랙',office='2026-10-16')])[0];self.assertEqual(r['progressStage'],'UNMATCHED');self.assertEqual(r['progressOfficeDates'],[])
    def test_wrong_size_does_not_borrow_V(self):
        r=self.seed([order(1,option='아이보리 / M')],progress=[source_row(size='L',office='2026-10-16')])[0];self.assertFalse(r['progressHasOfficeDate'])
    def test_onecolor_free_exceptions_remain(self):
        r=self.seed([order(1,option='[원컬러-FREE]')],progress=[source_row(color='블랙',size='L',office='2026-10-16')])[0];self.assertTrue(r['progressHasOfficeDate'])
    def test_nonselected_brand_cannot_supply_V(self):
        r=self.seed(progress=[source_row(brand='M',office='2026-10-16')])[0];self.assertFalse(r['progressHasOfficeDate'])
    def test_review_has_V_but_no_allocation(self):
        self.seed(progress=[source_row(office='2026-10-16')])
        with self.store.edit() as s:s['rows'][0]['review']=True
        r=self.row();self.assertTrue(r['progressHasOfficeDate']);self.assertEqual(r['dispatchEnd'],'')
    def test_soldout_source_lookup_does_not_allocate_stock(self):
        r=self.seed(progress=[source_row(office='2026-10-16')])[0];self.engine.external_manual({'keys':[r['key']],'dueDate':'2026-10-30'})
        with self.store.edit() as s:s['notices'][-1]['noticeType']='soldout_card';s['notices'][-1]['dueDate']=''
        r=self.row();self.assertTrue(r['progressHasOfficeDate']);self.assertEqual(r['dispatchEnd'],'');self.assertEqual(r['bucket'],'soldout')
    def test_manifest_proof_is_preserved_without_V(self):
        r=self.seed(progress=[source_row()],manifest=[source_row()])[0];self.assertTrue(r['stockSecured']);self.assertEqual(r['progressStage'],'MANIFEST_SECURED');self.assertEqual(r['dispatchEnd'],'2026-10-19')
    def test_sealed_manifest_is_not_reclassified_as_V_missing(self):
        self.seed(manifest=[source_row()]);self.engine.supply_reset({'confirmed':True});r=self.row();self.assertTrue(r['stockSecured']);self.assertEqual(r['progressStage'],'MANIFEST_SECURED')
    def test_V_source_list_is_sorted_and_deduplicated(self):
        r=self.seed(progress=[source_row(office='2026-10-17'),source_row(office='2026-10-16'),source_row(office='2026-10-16')])[0];self.assertEqual(r['progressOfficeDates'],['2026-10-16','2026-10-17'])
    def test_manual_mapping_does_not_make_V(self):
        r=self.seed([order(1,product='별도이름')],progress=[source_row()])[0];variant=self.engine.public_state()['supply']['variants'][0]['variant'];self.engine.supply_match({'key':r['key'],'variants':[variant]});self.assertEqual(self.row()['progressStage'],'UNCONFIRMED')
    def test_manual_mapping_reads_real_V(self):
        r=self.seed([order(1,product='별도이름')],progress=[source_row(office='2026-10-16')])[0];variant=self.engine.public_state()['supply']['variants'][0]['variant'];self.engine.supply_match({'key':r['key'],'variants':[variant]});self.assertEqual(self.row()['progressStage'],'PLANNED')
    def test_source_updated_only_by_manual_refresh(self):
        self.seed(progress=[source_row()]);(self.folder/'진행상황.xlsx').write_bytes(xlsx([('자료',[source_row(office='2026-10-16')])]))
        self.assertFalse(self.row()['progressHasOfficeDate']);self.engine.supply_refresh();self.assertTrue(self.row()['progressHasOfficeDate'])
    def test_public_view_no_store_mutation(self):
        self.seed(progress=[source_row(office='2026-10-16')]);before=self.store.read();self.engine.public_state();self.assertEqual(before,self.store.read());self.assertFalse(self.fake.sent);self.assertFalse(self.fake.report_calls)
    def test_exchange_C_raw_ID_preserved(self):
        r=self.seed([{**order(1),'orderId':'C20261016-001'}])[0];self.assertTrue(r['isExchange']);self.assertEqual(r['displayOrderId'],'[교환] C20261016-001');self.assertEqual(self.store.read()['rows'][0]['orderId'],'C20261016-001')
    def test_lowercase_prefix_supported_without_changing_id(self):
        r=self.seed([{**order(1),'orderId':'c00042'}])[0];self.assertTrue(r['isExchange']);self.assertEqual(r['orderId'],'c00042')
    def test_internal_C_is_not_exchange(self):
        r=self.seed([{**order(1),'orderId':'20261016C123'}])[0];self.assertFalse(r['isExchange'])
    def test_exchange_preserves_notice_bucket_and_dates(self):
        r=self.seed([{**order(1),'orderId':'C00042'}])[0];self.engine.external_manual({'keys':[r['key']],'dueDate':'2026-10-30'});r=self.row();self.assertTrue(r['isExchange']);self.assertEqual(r['bucket'],'within');self.assertEqual(r['color'],'green');self.assertEqual(r['dueDate'],'2026-10-30')
    def test_exchange_gets_short_supply_first(self):
        # 2026-10-22 22:55 요청: 출고장·진행상황 수량이 모자라면 교환(C 주문번호) 송장을 먼저 배정 (이전 규칙: 교환 표시는 FIFO를 바꾸지 않음).
        self.seed([order(1,day='2026-10-12'),{**order(2,day='2026-10-13'),'orderId':'C00042'}],manifest=[source_row(qty=1)]);rows=self.engine.public_state()['rows'];self.assertFalse(rows[0]['stockSecured']);self.assertTrue(rows[1]['stockSecured'])
    def test_display_metadata_not_persisted_in_DB(self):
        self.seed([{**order(1),'orderId':'C00042'}],progress=[source_row(office='2026-10-16')]);r=self.store.read()['rows'][0];self.assertNotIn('displayOrderId',r);self.assertNotIn('progressOfficeDates',r)
    def test_upgrade_preserves_ids_settings_ledger(self):
        r=self.seed([{**order(1),'orderId':'C00042'}],progress=[source_row(office='2026-10-16')])[0];self.engine.external_manual({'keys':[r['key']],'dueDate':'2026-10-30'})
        with self.store.edit() as s:s['appVersion']='0.6.12'
        before=self.store.read();self.restart();after=self.store.read();self.assertEqual(after['rows'],before['rows']);self.assertEqual(after['notices'],before['notices']);self.assertEqual(after['settings'],before['settings']);self.assertEqual(after['supply'],before['supply']);self.assertEqual(after['appVersion'],'0.6.125')
    def test_old_reservation_stays_pending_without_sending(self):
        r=self.seed()[0];self.queue(keys=[r['key']],sendMode='MORNING');before=self.last().copy()
        with self.store.edit() as s:s['appVersion']='0.6.12'
        self.restart();self.assertEqual(self.last()['scheduledAt'],before['scheduledAt']);self.assertEqual(self.last()['status'],'SCHEDULED');self.assertEqual(self.last()['id'],before['id']);self.assertFalse(self.fake.sent)
if __name__=='__main__':unittest.main()
