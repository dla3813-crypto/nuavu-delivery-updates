"""2026-10-23 버튼 하나 업데이트: 서명 확인, 버전 비교, 위조·변조 거절, 안전한 압축 풀기, 적용기(맥·윈도우 흐름)."""
import hashlib,io,json,os,sys,tempfile,threading,time,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import app_update as au

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization
except ImportError:Ed25519PrivateKey=None

def keypair():
    k=Ed25519PrivateKey.generate()
    return k,k.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw).hex()

def manifest(k,version='9.9.9',files=None,app=au.APP_ID,notes=('새 기능',)):
    files=files or {'mac':{'name':'m.zip','url':'https://raw.githubusercontent.com/x/y/main/m.zip','sha256':'0'*64,'size':10},
                    'windows':{'name':'w.zip','url':'https://raw.githubusercontent.com/x/y/main/w.zip','sha256':'0'*64,'size':10}}
    p={'app':app,'version':version,'publishedAt':'2026-10-23T00:00:00+00:00','notes':list(notes),'files':files}
    return json.dumps({'payload':p,'signature':k.sign(au.canonical(p)).hex()},ensure_ascii=False).encode()

@unittest.skipIf(Ed25519PrivateKey is None,'cryptography 없음')
class SignatureTests(unittest.TestCase):
    def test_pure_python_verify_matches_cryptography(self):
        k,pub=keypair()
        for msg in (b'',b'abc',os.urandom(300),'한글 메모'.encode()):
            sig=k.sign(msg);self.assertTrue(au.ed25519_verify(bytes.fromhex(pub),msg,sig))
            self.assertFalse(au.ed25519_verify(bytes.fromhex(pub),msg+b'x',sig))
            bad=bytearray(sig);bad[5]^=1;self.assertFalse(au.ed25519_verify(bytes.fromhex(pub),msg,bytes(bad)))
    def test_rfc8032_vector_1(self):
        pub=bytes.fromhex('d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a')
        sig=bytes.fromhex('e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b')
        self.assertTrue(au.ed25519_verify(pub,b'',sig))
    def test_manifest_checks(self):
        k,pub=keypair();other,_=keypair()
        self.assertEqual(au.verify_manifest(manifest(k),pub)['version'],'9.9.9')
        with self.assertRaisesRegex(au.UpdateError,'서명'):au.verify_manifest(manifest(other),pub)   # 다른 키로 서명
        doc=json.loads(manifest(k));doc['payload']['version']='9.9.10'
        with self.assertRaisesRegex(au.UpdateError,'서명'):au.verify_manifest(json.dumps(doc).encode(),pub)   # 서명 뒤 변조
        with self.assertRaisesRegex(au.UpdateError,'다른 프로그램'):au.verify_manifest(manifest(k,app='other'),pub)
        evil={'mac':{'name':'m','url':'https://evil.example.com/m.zip','sha256':'0'*64,'size':10}}
        with self.assertRaisesRegex(au.UpdateError,'허용되지 않은'):au.verify_manifest(manifest(k,files=evil),pub)
        with self.assertRaises(au.UpdateError):au.verify_manifest(b'not json',pub)
    def test_embedded_public_key_is_valid_point(self):self.assertIsNotNone(au._decode(bytes.fromhex(au.PUBLIC_KEY_HEX)))

class FakeEngine:
    def __init__(self,d):self.store=type('S',(),{'directory':d})();self.errors=[]
    def record_error(self,*a):self.errors.append(a)

def make_zip(files):
    b=io.BytesIO()
    with zipfile.ZipFile(b,'w') as z:
        for name,data in files.items():z.writestr(name,data)
    return b.getvalue()

@unittest.skipIf(Ed25519PrivateKey is None,'cryptography 없음')
class UpdaterTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.d=Path(self.tmp.name)
        self.k,self.pub=keypair()
        self.zip=make_zip({'NUAVU_Delay_v9.9.9_Aligo_Distribution/update_apply.py':'print(1)','NUAVU_Delay_v9.9.9_Aligo_Distribution/desktop.py':'#'})
        f={'name':'p.zip','url':'https://raw.githubusercontent.com/x/y/main/p.zip','sha256':hashlib.sha256(self.zip).hexdigest(),'size':len(self.zip)}
        self.files={'mac':f,'windows':f,'other':f}
    def tearDown(self):self.tmp.cleanup()
    def fake_fetch(self,manifest_bytes,zip_bytes=None):
        def fetch(url,limit,progress=None,dest=None,timeout=30):
            if 'latest.json' in url:return manifest_bytes
            Path(dest).write_bytes(zip_bytes if zip_bytes is not None else self.zip);return None
        return fetch
    def updater(self,current='0.6.125',**kw):
        return au.Updater(FakeEngine(self.d),current,manifest_url='https://raw.githubusercontent.com/x/y/main/latest.json',public_key_hex=self.pub,data=self.d,**kw)
    def test_newer_version_is_offered_same_or_older_is_not(self):
        u=self.updater()
        with patch('app_update.fetch',self.fake_fetch(manifest(self.k,files=self.files))):s=u.check()
        self.assertTrue(s['available']);self.assertEqual((s['latest'],s['notes']),('9.9.9',['새 기능']))
        with patch('app_update.fetch',self.fake_fetch(manifest(self.k,version='0.6.125',files=self.files))):s=u.check()
        self.assertFalse(s['available'])
        with patch('app_update.fetch',self.fake_fetch(manifest(self.k,version='0.6.80',files=self.files))):self.assertFalse(u.check()['available'])
    def test_forged_manifest_is_ignored_quietly(self):
        other,_=keypair();u=self.updater()
        with patch('app_update.fetch',self.fake_fetch(manifest(other,files=self.files))):s=u.check()
        self.assertFalse(s['available']);self.assertIn('서명',s['error'])
        with self.assertRaisesRegex(au.UpdateError,'새 버전이 없습니다'):u.install()
    def test_busy_blocks_install(self):
        u=self.updater(busy=lambda:'문자 전송')
        with patch('app_update.fetch',self.fake_fetch(manifest(self.k,files=self.files))):u.check()
        with self.assertRaisesRegex(au.UpdateError,'문자 전송'):u.install()
    def test_install_verifies_hash_then_launches_apply_and_quits(self):
        quit=threading.Event();launched=[]
        u=self.updater(quit_app=quit.set)
        with patch('app_update.fetch',self.fake_fetch(manifest(self.k,files=self.files))),patch.object(au.Updater,'_launch_apply',lambda self,root,ver:launched.append((root,ver))):
            u.check();u.install();u.thread.join(10)
        self.assertEqual(u.status()['phase'],'installing',u.status());self.assertTrue(quit.wait(5))
        root,ver=launched[0];self.assertEqual(ver,'9.9.9');self.assertTrue((root/'update_apply.py').exists())
        self.assertFalse((self.d/'updates/v9.9.9/package.zip').exists())
    def test_tampered_download_is_not_installed(self):
        quit=threading.Event();u=self.updater(quit_app=quit.set)
        with patch('app_update.fetch',self.fake_fetch(manifest(self.k,files=self.files),zip_bytes=self.zip[:-1]+b'X')),patch.object(au.Updater,'_launch_apply',lambda *a:self.fail('launched')):
            u.check();u.install();u.thread.join(10)
        s=u.status();self.assertEqual(s['phase'],'error');self.assertIn('서명된 파일과 다릅니다',s['error']);self.assertFalse(quit.is_set())

class ExtractTests(unittest.TestCase):
    def test_rejects_parent_paths_and_links(self):
        with tempfile.TemporaryDirectory() as t:
            t=Path(t);z=t/'a.zip';z.write_bytes(make_zip({'../evil.py':'x','a/update_apply.py':'x'}))
            with self.assertRaisesRegex(au.UpdateError,'경로'):au.safe_extract(z,t/'out')
            b=io.BytesIO()
            with zipfile.ZipFile(b,'w') as zz:
                info=zipfile.ZipInfo('a/link');info.external_attr=(0o120777<<16);zz.writestr(info,'/etc/passwd');zz.writestr('a/update_apply.py','x')
            z.write_bytes(b.getvalue())
            with self.assertRaisesRegex(au.UpdateError,'링크'):au.safe_extract(z,t/'out2')

class ApplyTests(unittest.TestCase):
    def test_windows_overwrites_app_folder_with_backup(self):
        import update_apply as ua
        with tempfile.TemporaryDirectory() as t:
            t=Path(t);app=t/'app';app.mkdir();(app/'desktop.py').write_text('old');(app/'keep.txt').write_text('mine')
            new=t/'new';new.mkdir();(new/'desktop.py').write_text('new');(new/'web').mkdir();(new/'web/a.js').write_text('js')
            a=type('A',(),{'app_root':str(app),'data':str(t/'data'),'from_version':'0.6.125'})()
            with patch.object(ua,'HERE',new),patch.object(ua,'pip_install',lambda *x:None),patch.object(ua.subprocess,'Popen') as pop:
                ua.apply_windows(a)
            self.assertEqual((app/'desktop.py').read_text(),'new');self.assertEqual((app/'web/a.js').read_text(),'js');self.assertEqual((app/'keep.txt').read_text(),'mine')
            self.assertEqual((t/'data/updates/backup-v0.6.125/desktop.py').read_text(),'old');self.assertTrue(pop.called)
    def test_mac_rebuilds_bundle_and_keeps_old_one(self):
        import update_apply as ua
        with tempfile.TemporaryDirectory() as t:
            t=Path(t);bundle=t/'배송안내 배포판.app';(bundle/'Contents').mkdir(parents=True);(bundle/'Contents/old').write_text('old')
            a=type('A',(),{'bundle':str(bundle)})()
            with patch.object(ua,'pip_install',lambda *x:None),patch.object(ua.subprocess,'run') as run:
                ua.apply_mac(a)
            self.assertTrue((bundle/'Contents/Resources/desktop.py').exists());self.assertTrue((bundle/'Contents/Resources/app_update.py').exists());self.assertFalse((bundle/'Contents/Resources/update_apply.py').exists())
            self.assertEqual(len(list(t.glob('배송안내 배포판.before-*.app'))),1);self.assertTrue(run.called)
    def test_wait_for_exit_uses_running_lock(self):
        import update_apply as ua
        from platform_support import ProcessLock
        with tempfile.TemporaryDirectory() as t:
            held=ProcessLock(t);self.assertTrue(held.acquire())
            # flock is per open file description: a second open in the same process still conflicts
            self.assertFalse(ua.wait_for_exit(t,0,seconds=1.2))
            held.release();self.assertTrue(ua.wait_for_exit(t,0,seconds=2))

if __name__=='__main__':unittest.main()

class PatchNotesAfterUpdate(unittest.TestCase):
    """2026-10-25: 업데이트를 받고 새 버전이 처음 켜지면 '업데이트 완료 · 바뀐 점' (적용기 표시 + 앱에 든 패치노트)."""
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.d=Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def updater(self,current):return au.Updater(FakeEngine(self.d),current,manifest_url='https://raw.githubusercontent.com/x/y/main/latest.json',public_key_hex='00'*32,data=self.d)
    def test_bundled_notes_match_this_version(self):
        from domain import APP_VERSION
        notes=au.bundled_notes(APP_VERSION);self.assertTrue(notes);self.assertTrue(any('AI' in n for n in notes))
        self.assertEqual(au.bundled_notes('0.0.1'),[])
    def test_marker_from_apply_shows_once_then_cleared(self):
        import update_apply
        from domain import APP_VERSION
        a=type('A',(),{'data':str(self.d),'from_version':'0.6.99','version':APP_VERSION})()
        update_apply.mark_updated(a)
        u=self.updater(APP_VERSION);s=u.status()
        self.assertEqual(s['justUpdated']['from'],'0.6.99');self.assertEqual(s['justUpdated']['to'],APP_VERSION);self.assertTrue(s['justUpdated']['notes']);self.assertTrue(s['justUpdated']['sections'])
        s=u.acknowledge_update();self.assertNotIn('justUpdated',s);self.assertFalse((self.d/'updates'/'just_updated.json').exists())
        self.assertNotIn('justUpdated',self.updater(APP_VERSION).status())   # 다시 켜도 안 뜸
    def test_marker_for_other_version_is_dropped(self):
        d=self.d/'updates';d.mkdir();(d/'just_updated.json').write_text(json.dumps({'from':'0.6.1','to':'9.9.9'}),encoding='utf-8')
        self.assertNotIn('justUpdated',self.updater('0.6.125').status());self.assertFalse((d/'just_updated.json').exists())
    def test_apply_marks_before_opening_new_version_and_ui_wired(self):
        src=(ROOT/'update_apply.py').read_text(encoding='utf-8')
        self.assertLess(src.index('    mark_updated(a)\n    subprocess.run'),src.index("subprocess.run(['/usr/bin/open',str(bundle)]"))
        self.assertIn('    mark_updated(a)\n    pyw=',src)
        js=(ROOT/'web'/'update_ui.js').read_text(encoding='utf-8');self.assertIn('updateDoneDialog',js);self.assertIn('update_ack',js)
        self.assertIn('def update_ack',(ROOT/'desktop.py').read_text(encoding='utf-8'))

class PatchNotesSections(unittest.TestCase):
    def test_sections_with_images_exist_and_served(self):
        from domain import APP_VERSION
        p=au.bundled_patch(APP_VERSION);self.assertTrue(p['headline']);self.assertGreaterEqual(len(p['sections']),3)
        imgs=[s['image'] for s in p['sections'] if s['image']];self.assertTrue(imgs)
        for i in imgs:self.assertTrue((ROOT/'web'/i).is_file(),i)
        src=(ROOT/'app.py').read_text(encoding='utf-8');self.assertIn("/patch/([a-z0-9_]{1,40})",src)
        js=(ROOT/'web'/'update_ui.js').read_text(encoding='utf-8');self.assertIn('update-sec',js);self.assertIn('탐색기에서 보기',js)
