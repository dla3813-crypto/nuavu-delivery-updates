import copy,threading,unittest
from unittest.mock import patch,MagicMock
from helpers import Base
from test_supply_regression import order
from ably_sync import apply_snapshot,validate_snapshot,date_range,AblySyncError,AblySyncController,account_cache_key
from ably_credentials import AblyAccounts,AblyKeychain,SERVICE
from credentials import VaultError
from history_seed import is_external
from desktop import DesktopAPI

def snapshot(entries=None):
    entries=entries if entries is not None else [dict(itemId='801',orderId='12345',qty=1,noticeSent=True,range='2026-10-21~2026-10-22',noticeDate='2026-10-15')]
    return dict(entries=entries,total=len(entries),notifiedTotal=len(entries),pages=max(1,(len(entries)+99)//100),complete=True,verified=True)

class SyncTests(Base):
    def setUp(self):
        super().setUp()
        with self.store.edit() as s:s['rows']=[]
        self.engine.import_rows({'rows':[order(1)|{'orderId':'12345','orderItemId':'801'}]})
        self.key=self.store.read()['rows'][0]['key']
    def apply(self,s=None):return apply_snapshot(self.engine,s or snapshot())
    def test_range_end_and_platform_history(self):
        self.apply();r=self.row();n=self.last()
        self.assertEqual(r['dueDate'],'2026-10-22');self.assertEqual(r['dueDateSource'],'ably_sync')
        self.assertEqual(n['platformNoticeDates'],['2026-10-15']);self.assertEqual(n['sourceMappings'][0]['startDate'],'2026-10-21')
        self.assertTrue(is_external(n));self.assertEqual(len(self.fake.sent),0)
    def test_unsent_payload_rejected(self):
        s=snapshot();s['entries'][0]['noticeSent']=False
        before=self.store.read()
        with self.assertRaises(AblySyncError):self.apply(s)
        self.assertEqual(self.store.read(),before)
    def test_scanned_unsent_rows_not_imported(self):
        s=snapshot();s['total']=150;s['pages']=2
        result=self.apply(s);self.assertEqual(result['skippedUnsent'],149);self.assertEqual(result['eligible'],1)
    def test_all_unsent_preserves_history(self):
        self.apply();before=copy.deepcopy(self.store.read()['notices']);s=snapshot([]);s.update(total=12)
        result=self.apply(s);self.assertEqual(result['skippedUnsent'],12);self.assertEqual(self.store.read()['notices'],before)
    def test_same_snapshot_no_duplicate(self):
        self.apply();n=copy.deepcopy(self.last());self.assertEqual(self.apply()['unchanged'],1);self.assertEqual(self.last(),n)
    def test_changed_and_returned_date_both_recorded(self):
        self.apply();s=snapshot();s['entries'][0]['range']='2026-10-23';self.apply(s);self.assertEqual(self.row()['dueDate'],'2026-10-23');self.apply()
        self.assertEqual(len(self.store.read()['notices']),3);self.assertEqual(self.row()['dueDate'],'2026-10-22')
    def test_manual_later_cannot_override_sync(self):
        self.apply();self.clock(12);self.engine.external_manual({'keys':[self.key],'dueDate':'2026-10-30'})
        self.assertEqual(self.row()['dueDate'],'2026-10-22')
    def test_app_accepted_wins_over_newer_sync_and_manual(self):
        self.send(keys=[self.key],dueDate='2026-10-25');self.clock(12);self.apply();self.engine.external_manual({'keys':[self.key],'dueDate':'2026-10-30'})
        self.assertEqual(self.row()['dueDate'],'2026-10-25');self.assertEqual(self.row()['dueDateSource'],'customer_message')
    def test_app_delivered_earlier_wins(self):
        self.send(keys=[self.key],dueDate='2026-10-25')
        with self.store.edit() as s:s['notices'][0]['status']='DELIVERED'
        self.apply();self.assertEqual(self.row()['dueDate'],'2026-10-25')
    def test_new_app_date_wins(self):
        self.apply();self.send(keys=[self.key],dueDate='2026-10-24');self.assertEqual(self.row()['dueDate'],'2026-10-24')
    def test_failed_draft_unknown_not_effective(self):
        self.queue(keys=[self.key],dueDate='2026-10-25')
        for status in ['QUEUED','FAILED','UNKNOWN','CANCELLED']:
            with self.store.edit() as s:s['notices'][0]['status']=status
            self.apply();self.assertEqual(self.row()['dueDate'],'2026-10-25' if status=='QUEUED' else '2026-10-22')  # v0.6.142: a queued draft pre-applies its date
            if status=='FAILED':self.assertEqual(self.row()['bucket'],'failed');self.assertEqual(self.row()['lastState'],'FAILED')
    def test_reserved_notice_unchanged(self):
        self.queue(keys=[self.key],sendMode='MORNING',dueDate='2026-10-25');before=copy.deepcopy(self.last())
        self.apply();self.assertEqual(self.store.read()['notices'][0],before)
    def test_sending_rejects_atomic(self):
        self.queue(keys=[self.key]);
        with self.store.edit() as s:s['notices'][0]['status']='SENDING'
        before=self.store.read()
        with self.assertRaises(AblySyncError):self.apply()
        self.assertEqual(self.store.read(),before)
    def test_test_send_not_priority(self):
        self.send(keys=[self.key],dueDate='2026-10-25')
        with self.store.edit() as s:s['notices'][0]['isTest']=True
        self.apply();self.assertEqual(self.row()['dueDate'],'2026-10-22')
    def test_missing_date_preserves_previous(self):
        self.apply();s=snapshot();s['entries'][0]['range']='';self.assertEqual(self.apply(s)['missingDate'],1)
        self.assertEqual(self.row()['dueDate'],'2026-10-22')
    def test_empty_full_list_does_not_delete(self):
        self.apply();before=copy.deepcopy(self.store.read()['notices']);self.apply(snapshot([]));self.assertEqual(self.store.read()['notices'],before)
    def test_no_match_no_order_creation(self):
        s=snapshot();s['entries'][0]['itemId']='999';self.assertEqual(self.apply(s)['unmatched'],1);self.assertEqual(len(self.store.read()['rows']),1)
    def test_exact_detail_identity_preserves_legacy_matching(self):
        s=snapshot();s['entries'][0]['orderId']='45678';self.assertEqual(self.apply(s)['items'],1)
        self.assertEqual(self.last()['orderId'],'12345')
    def test_quantity_mismatch_not_applied(self):
        s=snapshot();s['entries'][0]['qty']=2;self.assertEqual(self.apply(s)['unmatched'],1);self.assertFalse(self.store.read()['notices'])
    def test_aggregate_partial_not_applied(self):
        self.engine.import_rows({'rows':[order(1)|{'orderId':'12345','orderItemId':'801'},order(1)|{'orderId':'12345','orderItemId':'802'}]})
        self.assertEqual(self.apply()['items'],0)
    def test_aggregate_full_uses_latest_range_end(self):
        self.engine.import_rows({'rows':[order(1)|{'orderId':'12345','orderItemId':'801'},order(1)|{'orderId':'12345','orderItemId':'802'}]})
        s=snapshot();s['entries'].append(dict(s['entries'][0],itemId='802',range='2026-10-25'));s['total']=2;s['notifiedTotal']=2
        self.assertEqual(self.apply(s)['items'],1);self.assertEqual(self.row()['dueDate'],'2026-10-25')
    def test_restart_preserves_history(self):
        self.apply();before=copy.deepcopy(self.store.read()['notices']);self.restart()
        self.assertEqual(self.store.read()['notices'],before);self.assertEqual(self.row()['dueDate'],'2026-10-22')
    def test_partial_duplicate_malformed_never_mutate(self):
        for change in [{'verified':False},{'complete':False},{'total':-1},{'pages':2}]:
            with self.subTest(change=change):
                before=self.store.read()
                with self.assertRaises(AblySyncError):self.apply(snapshot()|change)
                self.assertEqual(self.store.read(),before)
        s=snapshot();s['entries']*=2;s['total']=2;s['notifiedTotal']=2
        with self.assertRaises(AblySyncError):self.apply(s)
    def test_controller_apply_once_and_no_secret_result(self):
        vault=MagicMock(available=True);vault.load.return_value=dict(version=1,username='fake',password='FAKE-SECRET')
        c=AblySyncController(self.engine,runner=lambda a,s,p,cache:snapshot(),vault=vault);c.start();c.thread.join(4)
        self.assertEqual(c.status()['phase'],'done');self.assertNotIn('FAKE-SECRET',str(c.status()));self.assertEqual(len(self.store.read()['notices']),1)
    def test_controller_cancel_discards_complete_results(self):
        vault=MagicMock(available=True);vault.load.return_value=dict(version=1,username='fake',password='FAKE-SECRET')
        def runner(a,stop,p,cache):stop.set();return snapshot()
        c=AblySyncController(self.engine,runner=runner,vault=vault);c.start();c.thread.join(4)
        self.assertEqual(c.status()['phase'],'cancelled');self.assertFalse(self.store.read()['notices'])
        self.assertNotIn('ablySyncCache',self.store.read())
    def test_successful_read_cache_survives_restart_but_not_ui_payload(self):
        ck=account_cache_key({'username':'fake','shopName':'데모스토어'})
        apply_snapshot(self.engine,snapshot(),ck)
        cached=copy.deepcopy(self.store.read()['ablySyncCache'][ck])
        self.assertEqual(cached['801']['range'],'2026-10-21~2026-10-22')
        self.assertTrue(cached['801']['readAt']);self.assertNotIn('ablySyncCache',self.engine.public_state())
        self.restart();self.assertEqual(self.store.read()['ablySyncCache'][ck],cached)
        result=apply_snapshot(self.engine,snapshot([cached['801']|{'fromCache':True}]),ck)
        self.assertEqual((result['cached'],result['fresh'],result['unchanged']),(1,0,1))
        self.assertEqual(len(self.store.read()['notices']),1)
        self.assertEqual(self.store.read()['ablySyncCache'][ck],cached)
    def test_missing_date_is_not_marked_scraped(self):
        ck=account_cache_key({'username':'fake','shopName':'데모스토어'});s=snapshot();s['entries'][0]['range']=''
        apply_snapshot(self.engine,s,ck)
        self.assertNotIn('801',self.store.read()['ablySyncCache'][ck])
    def test_cached_unmatched_can_apply_after_later_order_import(self):
        ck=account_cache_key({'username':'fake','shopName':'데모스토어'});s=snapshot();s['entries'][0]['itemId']='802'
        self.assertEqual(apply_snapshot(self.engine,s,ck)['unmatched'],1)
        cached=self.store.read()['ablySyncCache'][ck]['802']
        self.engine.import_rows({'rows':[order(1)|{'orderId':'12345','orderItemId':'802'}]})
        self.assertEqual(apply_snapshot(self.engine,snapshot([cached|{'fromCache':True}]),ck)['items'],1)
        self.assertEqual(self.last()['sourceReadAt'],[cached['readAt']])
    def test_partial_or_sending_failure_never_saves_cache(self):
        ck=account_cache_key({'username':'fake','shopName':'데모스토어'});before=self.store.read()
        with self.assertRaises(AblySyncError):apply_snapshot(self.engine,snapshot()|{'verified':False},ck)
        self.assertEqual(self.store.read(),before)
        self.queue(keys=[self.key])
        with self.store.edit() as s:s['notices'][0]['status']='SENDING'
        before=self.store.read()
        with self.assertRaises(AblySyncError):apply_snapshot(self.engine,snapshot(),ck)
        self.assertEqual(self.store.read(),before)
    def test_cache_scoped_to_account_and_copied_to_reader(self):
        ck=account_cache_key({'username':'fake','shopName':'데모스토어'});apply_snapshot(self.engine,snapshot(),ck)
        vault=MagicMock(available=True);vault.load.return_value=dict(version=1,username='fake',password='FAKE-SECRET')
        received=[]
        def runner(a,stop,p,cache):
            received.append(copy.deepcopy(cache));cache.clear();return snapshot()
        c=AblySyncController(self.engine,runner=runner,vault=vault);c.start();c.thread.join(4)
        self.assertEqual(c.status()['phase'],'done');self.assertIn('801',received[0])
        self.assertIn('801',self.store.read()['ablySyncCache'][ck])
        vault.load.return_value=dict(version=1,username='other',password='FAKE-SECRET')
        c.start();c.thread.join(4)
        self.assertEqual(c.status()['phase'],'done');self.assertEqual(received[1],{})
        self.assertEqual(len(self.store.read()['ablySyncCache']),2)
    def test_bridge_checks_token_and_origin(self):
        bridge=DesktopAPI(self.engine,'token','http://127.0.0.1:123',MagicMock());bridge._window=MagicMock();bridge._window.get_current_url.return_value='http://127.0.0.1:123/'
        bridge._ably_sync=MagicMock();bridge._ably_sync.status.return_value={'phase':'idle'}
        self.assertIn('error',bridge.ably_sync_action('bad','status'));bridge._ably_sync.status.assert_not_called()
        self.assertEqual(bridge.ably_sync_action('token','status'),{'phase':'idle'})
        bridge._window.get_current_url.return_value='https://evil.example/'
        self.assertIn('error',bridge.ably_sync_action('token','start'));bridge._ably_sync.start.assert_not_called()

class CredentialTests(unittest.TestCase):
    def test_service_separate(self):self.assertEqual(SERVICE,'kr.nuavu.deliverynotice.distribution.ably')
    def test_info_never_returns_secret(self):
        v=MagicMock(available=True);v.load.return_value=dict(version=1,username='fake',password='FAKE-SECRET')
        self.assertNotIn('FAKE-SECRET',str(AblyAccounts('.',v).info()))
    def test_changed_account_requires_password(self):
        v=MagicMock(available=True);v.load.return_value=dict(version=1,username='fake',password='FAKE-SECRET')
        with self.assertRaises(VaultError):AblyAccounts('.',v).save('other','')
        v.save.assert_not_called()
    def test_save_error_no_secret(self):
        v=MagicMock(available=True);v.save.side_effect=Exception('FAKE-SECRET')
        with self.assertRaises(VaultError) as ex:AblyAccounts('.',v).save('fake','FAKE-SECRET')
        self.assertNotIn('FAKE-SECRET',str(ex.exception))
    def test_dates(self):
        self.assertEqual(date_range('2026-10-21~2026-10-22'),('2026-10-21','2026-10-22'))
        for v in ['2026-02-30','2026-10-22~2026-10-21','10/21','<script>']:
            with self.assertRaises(AblySyncError):date_range(v)
