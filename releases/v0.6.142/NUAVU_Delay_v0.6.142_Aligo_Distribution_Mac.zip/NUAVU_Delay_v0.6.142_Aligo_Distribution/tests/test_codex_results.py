"""2026-10-24 22:05 추가 요청: 앱 자료 자동 연결 (자료 목록 · 회차 보관본 · 질문별 선택 · 해시 검증 · 선택창 · 연결 해제 · 대화 삭제/되돌리기)."""
import io,json,sys,tempfile,time,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
sys.path.insert(0,str(Path(__file__).resolve().parent))
import codex_catalog
from codex_catalog import ArtifactCatalog
from codex_files import digest
from codex_service import CodexChatService
from codex_view import parts,markdown
from test_codex_chat import FakeClient,make_xlsx


def rich_xlsx(path,value='출고예정일 미정'):
    import openpyxl
    from openpyxl.drawing.image import Image
    from openpyxl.styles import Font,PatternFill
    from PIL import Image as P
    w=openpyxl.Workbook();s=w.active;s['A1']='주문';s['B1']=value;s['C1']='=SUM(D1:D3)';s['D1']=3;s['D2']=4
    s.merge_cells('A3:B3');s['A1'].font=Font(bold=True);s['A1'].fill=PatternFill('solid',fgColor='FFF2CC')
    b=io.BytesIO();P.new('RGB',(5,5),'blue').save(b,'PNG');b.seek(0);s.add_image(Image(b),'F2');w.save(path)


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=Path(self.tmp.name);self.state=self.base/'state'
        self.out=self.base/'out';self.out.mkdir()
        self.cat=codex_catalog.install(ArtifactCatalog(self.state,notice_text=lambda:'# 최근 안내문\n상품: 니트\n출고 예정일: 10월 28일'))
        self.s=self.make()
    def make(self):
        return CodexChatService(self.state,self.out/'Codex 결과',roots=[('out','out',self.out)],context=lambda:'요약',version='0.6.142',
                                open_url=lambda u:None,open_path=lambda p:None,client_factory=FakeClient,catalog=self.cat)
    def tearDown(self):
        self.s.close();codex_catalog.install(None);self.tmp.cleanup()
    def wait(self):
        end=time.monotonic()+5
        while self.s.op and time.monotonic()<end:time.sleep(.01)
        self.assertFalse(self.s.op,self.s.error)
    def turns(self):return [x for x in (self.s.client.calls if self.s.client else []) if x.get('method')=='turn/start']
    def finish(self):
        self.s.client.event('turn/completed',{'threadId':'own-thread','turn':{'status':'completed'}});self.wait()
    def export(self,value):
        p=self.out/'현재 미출고 상품.xlsx';rich_xlsx(p,value);return codex_catalog.record('orders',p,role='input')   # 배포판: 미출고 엑셀 자동 저장이 없어 주문 엑셀 회차로 시험


class CatalogTests(Base):
    def test_same_name_overwrite_keeps_every_round_and_dedupes_same_content(self):
        a=self.export('1회차');b=self.export('1회차')   # 같은 내용 다시 저장 → 새 회차 아님
        self.assertEqual(a['id'],b['id']);self.assertEqual(len(self.cat.items('orders')),1)
        c=self.export('2회차')
        self.assertEqual(c['version'],2);self.assertNotEqual(c['id'],a['id'])
        self.assertTrue(Path(a['path']).is_file());self.assertEqual(digest(a['path']),a['sha256'])   # 지난 회차 보관본이 그대로
        r=self.cat.resolve('지난 회차 주문 엑셀 분석해 줘');self.assertEqual([x['id'] for x in r['selected']],[a['id']])
        r=self.cat.resolve('최신 주문 엑셀 분석해 줘');self.assertEqual([x['id'] for x in r['selected']],[c['id']])
        self.assertTrue(self.cat.is_live(c));self.assertFalse(self.cat.is_live(a))
    def test_missing_and_date_and_ambiguous(self):
        r=self.cat.resolve('최신 진행상황으로 수량 알려 줘')
        self.assertTrue(any('진행상황' in m for m in r['missing']))
        d=self.base/'ship';d.mkdir()
        for n in ('10월 22일 출고장 완료.xlsx','10월 23일 출고장 완료.xlsx'):
            p=d/n;make_xlsx(p,n);codex_catalog.record_bytes('shipment',n,p.read_bytes(),source=str(p),basis='2026-10-'+n[4:6],run='scan-1')
        r=self.cat.resolve('최신 출고장 확인해 줘');self.assertEqual(len(r['selected']),1);self.assertIn('23일',r['selected'][0]['name'])
        r=self.cat.resolve('10월 22일 출고장 수량 알려 줘');self.assertIn('22일',r['selected'][0]['name'])
        r=self.cat.resolve('9월 25일 출고장 수량 알려 줘');self.assertTrue(r['missing'])   # 오늘 날짜와 겹치지 않는 날짜
        p=d/'x.xlsx';make_xlsx(p,'다른 내용');codex_catalog.record_bytes('shipment','10월 23일 출고장 완료 (2).xlsx',p.read_bytes(),basis='2026-10-23')
        # 같은 순간·같은 기준일 두 개는 고를 수 없음 → 선택
        for it in self.cat.data['items']:
            if it['kind']=='shipment':it['createdAt']='2026-10-24T22:00:00+09:00';it['run']='scan-2'
        r=self.cat.resolve('최신 출고장 확인해 줘');self.assertEqual(len(r['choices']),2);self.assertFalse(r['selected'])
    def test_unrelated_question_links_nothing(self):
        self.export('a')
        for q in ('안녕하세요','지그재그 배송연기 규칙 설명해 줘'):
            self.assertFalse(self.cat.resolve(q)['requested'],q)
    def test_hooks_never_break_and_register(self):
        codex_catalog.install(None)
        self.assertIsNone(codex_catalog.record('notice_export',self.base/'없음.xlsx'))
        codex_catalog.install(self.cat)
        import pickup_report,datetime
        path=pickup_report.save_report([],self.out,datetime.datetime(2026,10,24,22,0))
        self.assertEqual(self.cat.items('pickup')[0]['source'],str(Path(path).resolve()))


class LinkTests(Base):
    def test_ask_without_attachment_links_real_copy_and_followups_reuse(self):
        a=self.export('출고예정일 미정');src=self.out/'현재 미출고 상품.xlsx';before=src.read_bytes()
        self.s.send('방금 가져온 주문 엑셀 다시 분석해 줘');self.wait()
        self.assertEqual(len(self.turns()),1)
        rec=next(r for r in self.s.workspace.records.values() if r.get('artifact'))
        work=self.s.workspace.work/rec['name'];self.assertEqual(digest(work),a['sha256'])          # 바이트 그대로 (수식·서식·병합·이미지 포함)
        ctx=(self.s.workspace.work/'.nuavu/context.md').read_text()
        self.assertIn(a['id'],ctx);self.assertIn('"linked": true',ctx);self.assertIn(rec['name'],ctx)
        self.assertIn(rec['name'],parts(self.s.status())['chips'])
        self.finish()
        self.s.send('그중 누아브만 따로 정리해 줘');self.wait()
        self.assertEqual(len(self.turns()),2);self.assertEqual(len([r for r in self.s.workspace.records.values() if r.get('artifact')]),1)
        self.finish()
        # 작업본을 고쳐도 원본은 그대로, 명시적 반영 때만 바뀜
        rich_xlsx(work,'10/28 출고');self.assertEqual(src.read_bytes(),before)
        self.s.review();self.wait();f=next(x for x in self.s.files if x['key']==rec['id'])
        self.assertTrue(f['changed']);self.assertTrue(f['original']);self.assertEqual(src.read_bytes(),before)
        self.s.apply(f['key'],f['sha']);self.wait();self.assertEqual(digest(src),f['sha'])
        self.s.restore(f['key']);self.wait();self.assertEqual(src.read_bytes(),before)
        # 앱 재시작 후에도 대화·연결 자료·작업본 유지
        key=self.s.chat['id'];self.s.close();self.s=self.make()
        self.assertEqual(self.s.chat['id'],key);self.assertEqual(len(self.s.status()['linkedResults']),1)
        self.assertTrue((self.s.workspace.work/rec['name']).is_file())
        # 새 대화에서도 최신 안내건을 찾아 연결
        self.s.new();self.s.send('최신 주문 엑셀 요약해 줘');self.wait()
        self.assertEqual(len(self.s.status()['linkedResults']),1)
    def test_conflict_and_historical_read_only(self):
        old=self.export('1회차');new=self.export('2회차');src=self.out/'현재 미출고 상품.xlsx'
        self.s.send('지난 회차 주문 엑셀 확인해 줘');self.wait();self.finish()
        rec=next(r for r in self.s.workspace.records.values() if r.get('artifact'))
        self.assertEqual(rec['artifact']['id'],old['id']);self.assertTrue(rec['readOnly'])
        rich_xlsx(self.s.workspace.work/rec['name'],'수정');self.s.review();self.wait()
        f=next(x for x in self.s.files if x['key']==rec['id']);self.assertFalse(f['original'])   # 원본 반영 버튼 없음 (별도 저장만)
        before=src.read_bytes()
        self.s.apply(f['key'],f['sha'])
        end=time.monotonic()+4
        while self.s.op and time.monotonic()<end:time.sleep(.01)
        self.assertIn('지난 회차',self.s.error);self.assertEqual(src.read_bytes(),before)
        # 최신 회차 연결 후 원본이 그사이 바뀌면 덮어쓰지 않음
        self.s.new();self.s.send('최신 주문 엑셀 확인해 줘');self.wait();self.finish()
        rec=next(r for r in self.s.workspace.records.values() if r.get('artifact'))
        rich_xlsx(self.s.workspace.work/rec['name'],'AI 수정');rich_xlsx(src,'사장님이 다른 작업으로 수정')
        self.s.review();self.wait();f=next(x for x in self.s.files if x['key']==rec['id'])
        self.s.apply(f['key'],f['sha'])
        end=time.monotonic()+4
        while self.s.op and time.monotonic()<end:time.sleep(.01)
        self.assertIn('다른 작업에서 원본을 변경',self.s.error)
    def test_ambiguous_picker_sends_question_once(self):
        d=self.base/'s';d.mkdir()
        for i,n in enumerate(('10월 23일 출고장 완료.xlsx','10월 23일 출고장 완료 (2).xlsx')):
            p=d/f'{i}.xlsx';make_xlsx(p,n);codex_catalog.record_bytes('shipment',n,p.read_bytes(),basis='2026-10-23')
        for it in self.cat.data['items']:it['createdAt']='2026-10-24T22:00:00+09:00';it['run']='scan-9'
        self.s.send('최신 출고장 수량 확인해 줘');self.wait()
        st=self.s.status();self.assertTrue(st['resultPicker']);self.assertEqual(len(self.turns()),0)
        self.assertIn('cxChoose',parts(st)['picker'])
        with self.assertRaises(Exception):self.s.send('다른 질문')     # 선택 전에는 다른 질문으로 덮지 않음
        self.s.choose_result(st['resultPicker']['items'][1]['id']);self.wait()
        self.assertEqual(len(self.turns()),1);self.assertEqual(self.turns()[0]['params']['input'][0]['text'],'최신 출고장 수량 확인해 줘')
        self.assertIsNone(self.s.status()['resultPicker'])
    def test_missing_material_reported_not_pretended(self):
        self.s.send('최신 진행상황으로 이번 주 수량 알려 줘');self.wait()
        ctx=(self.s.workspace.work/'.nuavu/context.md').read_text()
        self.assertIn('진행상황: 앱에 등록된 파일이 없습니다',ctx);self.assertEqual(len(self.turns()),1)
    def test_copy_failure_is_reported(self):
        a=self.export('x');Path(a['path']).write_bytes(b'tampered')    # 보관본 손상 → 해시 불일치
        self.s.send('최신 주문 엑셀 분석해 줘');self.wait()
        ctx=(self.s.workspace.work/'.nuavu/context.md').read_text()
        self.assertIn('복사 실패',ctx);self.assertEqual(self.s.status()['linkedResults'],[])
    def test_unlink_keeps_original_and_snapshot(self):
        a=self.export('x');self.s.send('최신 주문 엑셀 분석해 줘');self.wait();self.finish()
        key=self.s.status()['linkedResults'][0]['key'];self.s.unlink(key)
        self.assertEqual(self.s.status()['linkedResults'],[]);self.assertTrue(Path(a['path']).is_file());self.assertTrue((self.out/'현재 미출고 상품.xlsx').is_file())
    def test_notice_text_material(self):
        self.s.send('아까 만든 안내문을 더 짧고 정중하게 고쳐 줘');self.wait()
        l=self.s.status()['linkedResults'];self.assertEqual(l[0]['kind'],'notice_text')
        self.assertIn('출고 예정일',(self.s.workspace.work/l[0]['file']).read_text())
    def test_delete_and_undo_conversation(self):
        first=self.s.chat['id'];self.s.send('안녕');self.wait();self.finish();self.s.new()
        self.s.delete_session(first);self.assertNotIn(first,[x['id'] for x in self.s.status()['sessions']]);self.assertTrue(self.s.status()['undoDelete'])
        self.assertIn('cxUndoDelete',parts(self.s.status())['side'])
        self.s.undo_delete_session();self.assertIn(first,[x['id'] for x in self.s.status()['sessions']])
        self.assertTrue((self.state/'codex_chat/sessions'/first/'chat.json').is_file())
    def test_undo_delete_survives_restart(self):
        # 2026-10-24 실화면: 재시작 후 대화가 목록에서 빠져 있었고 되돌릴 방법이 없었음 → 지운 대화는 재시작 후에도 되돌리기
        first=self.s.chat['id'];self.s.send('안녕');self.wait();self.finish();self.s.new()
        self.s.delete_session(first);self.s.close()
        s2=self.make();self.assertEqual(s2.status()['undoDelete'],1);self.assertIn('지운 대화 되돌리기',parts(s2.status())['side'])
        s2.undo_delete_session();self.assertIn(first,[x['id'] for x in s2.status()['sessions']]);self.assertEqual(s2.status()['undoDelete'],0)
        s2.close()
    def test_auto_hidden_empty_chat_is_not_restorable(self):
        self.s.send('안녕');self.wait();self.finish();self.s.new();empty=self.s.chat['id']
        self.s.send('두 번째');self.wait();self.finish()   # 빈 대화가 아니게 되므로 직접 빈 대화를 하나 더 만든다
        self.s._create_session();self.s.select(self.s.saved['sessions'][1]['id']);self.s.close()
        s2=self.make();self.assertEqual(s2.status()['undoDelete'],0);s2.close()


class SmallFixes(Base):
    def test_new_does_not_pile_up_empty_conversations(self):
        n=len(self.s.status()['sessions']);self.s.new();self.s.new();self.assertEqual(len(self.s.status()['sessions']),n)
    def test_empty_sessions_hidden_on_restart(self):
        self.s.send('안녕');self.wait();self.finish()
        for _ in range(2):
            with self.s.lock:k=self.s._create_session();self.s._load_session(k)
        self.s.select(self.s.saved['sessions'][-1]['id']) if False else None
        self.s.close();self.s=self.make()
        titles=[x['title'] for x in self.s.status()['sessions']]
        self.assertLessEqual(titles.count('새 대화'),1)
    def test_attached_file_chip_and_new_file_compared_with_source(self):
        p=self.out/'주문.xlsx';rich_xlsx(p,'');self.s.attach_token('out:주문.xlsx');self.wait()
        self.assertIn('첨부',parts(self.s.status())['chips'])
        rich_xlsx(self.s.workspace.work/'주문_수정.xlsx','2026-10-29');self.s.review();self.wait()
        f=next(x for x in self.s.files if x['name']=='주문_수정.xlsx')
        self.assertEqual(f['compareWith'],'주문.xlsx');self.assertIn('B1:  → 2026-10-29',f['preview'].replace('None',''))
        self.assertNotIn('A1:',f['preview'])   # 같은 값은 변경으로 보지 않음


class ProposalTests(Base):
    def make(self):
        self.cat.order_list=lambda:'행키,판매처,상품명\nk1,누아브 에이블리,니트\nk2,누아브 자사몰,셔츠\n'
        return CodexChatService(self.state,self.out/'Codex 결과',roots=[('out','out',self.out)],context=lambda:'요약',version='0.6.142',
                                open_url=lambda u:None,open_path=lambda p:None,client_factory=FakeClient,catalog=self.cat,
                                validate_action=lambda p:{'keys':[k for k in p['keys'] if k in ('k1','k2')],'samples':['에이블리 · 니트'],'unmatched':len([k for k in p['keys'] if k not in ('k1','k2')]),'warnings':[]})
    def test_action_request_becomes_confirmation_card_only(self):
        self.s.send('입고 확정된 건 메시지 없는 배송지연 안내 보내줘');self.wait()
        l=self.s.status()['linkedResults'];self.assertEqual(l[0]['kind'],'order_list')
        self.assertIn('행키',(self.s.workspace.work/l[0]['file']).read_text(encoding='utf-8-sig'))
        # 2026-10-24 실화면: 앱이 만든 자료가 '지난 회차'로 잘못 보이던 문제 → '앱 화면 기준'
        self.assertFalse(l[0]['historical']);self.assertTrue(l[0]['generated'])
        chips=parts(self.s.status())['chips'];self.assertIn('앱 화면 기준',chips);self.assertNotIn('지난 회차',chips)
        self.assertIn('"generated": true',(self.s.workspace.work/'.nuavu/context.md').read_text(encoding='utf-8'))
        (self.s.workspace.work/'.nuavu/app_action.json').write_text(json.dumps({'action':'no_send_notice','rowKeys':['k1','zz'],'dueDate':'2026-10-27','template':'first','reason':'출고장 수량 확보'}))
        self.finish()
        m=self.s.status()['messages'][-1];self.assertEqual(m['role'],'proposal');self.assertEqual(m['keys'],['k1']);self.assertEqual(m['unmatched'],1)
        html=parts(self.s.status())['messages'];self.assertIn('data-cx-local="proposal"',html);self.assertIn('아직 처리하지 않았습니다',html)
        self.assertFalse((self.s.workspace.work/'.nuavu/app_action.json').exists())   # 한 번만 카드로
    def test_dispatch_change_becomes_card_only(self):
        # 2026-10-24 실화면: '출고예상일 변경'을 배송지연 안내로 오해 → 별도 제안(change_dispatch), 앱의 출고 예상일 변경 창을 연다
        self.s.validate_action=lambda p:{'chinaDates':[c for c in p['chinaDates'] if c=='2026-10-24'],'samples':['10/24 중국 출고분 · 주문상품 68개'],'unmatched':1,'warnings':[],'count':68}
        self.s.send('28~29일로 잡힌 출고장 출고예상일을 27일로 변경해');self.wait()
        self.assertEqual(self.s.status()['linkedResults'][0]['kind'],'order_list')
        (self.s.workspace.work/'.nuavu/app_action.json').write_text(json.dumps({'action':'change_dispatch','chinaDates':['2026-10-24','2026-09-01'],'dispatchStart':'2026-10-27','dispatchEnd':'2026-10-27','reason':'출고장 일정 당겨짐'}))
        self.finish()
        m=self.s.status()['messages'][-1];self.assertEqual((m['role'],m['action'],m['chinaDates'],m['count']),('proposal','change_dispatch',['2026-10-24'],68))
        html=parts(self.s.status())['messages'];self.assertIn('출고 예상일 변경 창에서 확인',html);self.assertIn('10/27',html);self.assertIn('메시지는 보내지 않습니다',html)
        for bad in ({'action':'change_dispatch','chinaDates':[],'dispatchStart':'2026-10-27'},{'action':'change_dispatch','chinaDates':['2026-10-24'],'dispatchStart':'2026-10-28','dispatchEnd':'2026-10-27'}):
            self.s.send('다시');self.wait();(self.s.workspace.work/'.nuavu/app_action.json').write_text(json.dumps(bad));self.finish()
            self.assertEqual(self.s.status()['messages'][-1]['role'],'system')
        self.assertIn('받은 항목',self.s.status()['messages'][-1]['text'])
    def test_dispatch_proposal_accepts_common_variants(self):
        seen=[];self.s.validate_action=lambda p:(seen.append(p),{'chinaDates':p['chinaDates'] or ['2026-10-23'],'samples':[],'unmatched':0,'warnings':[],'count':3})[1]
        for raw in ({'action':'change_dispatch','chinaDates':'2026-10-23 2026-10-24','start':'2026-10-27'},
                    {'action':'change_dispatch','chinaDate':'2026-10-23','dispatchDate':'2026-10-27'},
                    {'action':'change_dispatch','rowKeys':['k1'],'dispatchStart':'2026-10-27'},
                    {'action':'change_dispatch','currentStart':'2026-10-28','currentEnd':'2026-10-29','newDate':'2026-10-27'}):
            self.s.send('출고 예상일 바꿔');self.wait();(self.s.workspace.work/'.nuavu/app_action.json').write_text(json.dumps(raw));self.finish()
            m=self.s.status()['messages'][-1];self.assertEqual((m['role'],m['dispatchStart'],m['dispatchEnd']),('proposal','2026-10-27','2026-10-27'),raw)
        self.assertEqual(seen[0]['chinaDates'],['2026-10-23','2026-10-24']);self.assertEqual(seen[2]['rowKeys'],['k1']);self.assertEqual(seen[3]['fromDates'],['2026-10-28','2026-10-29'])
        self.assertIn('change_dispatch',(self.s.workspace.work/'.nuavu/context.md').read_text(encoding='utf-8'))   # 이어지는 대화에서도 형식을 다시 읽을 수 있게
    def test_instructions_separate_two_dates(self):
        t=self.s._instructions();self.assertIn('change_dispatch',t);self.assertIn('안내한 출고 예정일',t);self.assertIn('출고 예상일',t)
    def test_bad_action_is_ignored(self):
        self.s.send('문자 보내줘');self.wait()
        (self.s.workspace.work/'.nuavu/app_action.json').write_text(json.dumps({'action':'delete_orders','rowKeys':['k1']}))
        self.finish();m=self.s.status()['messages'][-1];self.assertEqual(m['role'],'system');self.assertIn('무시',m['text'])


class InstructionTests(unittest.TestCase):
    def test_instructions_render(self):
        s=CodexChatService.__new__(CodexChatService);s.python='/fixed/python3'
        text=s._instructions();self.assertIn('app_action.json',text);self.assertIn('/fixed/python3',text);self.assertIn('propose_action',text);self.assertNotIn('{{',text)


class ViewTests(unittest.TestCase):
    def test_markdown_is_escaped_and_tables_render(self):
        h=markdown('**합계**\n\n| 상품 | 수량 |\n|---|---:|\n| <b>니트</b> | 3 |\n\n- a\n- b\n\n```\n<script>x</script>\n```')
        self.assertIn('<strong>합계</strong>',h);self.assertIn('<table>',h);self.assertIn('&lt;b&gt;니트&lt;/b&gt;',h);self.assertIn('<ul>',h)
        self.assertNotIn('<script>',h);self.assertNotIn('<b>니트',h)

if __name__=='__main__':unittest.main()


class SendModeProposal(Base):
    """2026-10-25 23:51 요청: '내일 오전 9시 예약' 을 카드에 담는다 (예약 자체는 사장님이 작성창 버튼으로)."""
    def test_morning_send_mode_on_direct_phone_card(self):
        self.s.add_proposal({'action':'compose_notice','phones':['010-2222-3333'],'template':'manual','message':'테스트 문구','manualReason':'회수 안내','sendMode':'MORNING'})
        p=[m for m in self.s.chat['messages'] if m.get('role')=='proposal'][-1]
        self.assertEqual((p['sendMode'],p['phones']),('MORNING',['01022223333']))
        html=parts(self.s.status())['messages']
        self.assertIn('오전 9시 예약',html);self.assertIn('[오전 9시에 전송]',html);self.assertIn('sendMode',html)
    def test_default_send_mode_is_immediate(self):
        self.s.add_proposal({'action':'compose_notice','phones':['01022223333'],'template':'manual','message':'테스트 문구'})
        p=[m for m in self.s.chat['messages'] if m.get('role')=='proposal'][-1]
        self.assertEqual(p['sendMode'],'IMMEDIATE')
