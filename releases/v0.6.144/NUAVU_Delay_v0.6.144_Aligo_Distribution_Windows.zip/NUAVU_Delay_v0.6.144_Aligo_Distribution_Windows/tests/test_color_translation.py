"""Chinese labels may recommend a connection but must not allocate until saved."""
import copy
from pathlib import Path
import pytest
from color_labels import color_label
from domain import SELLERS
from helpers import Base
from supply_workflow import candidates,manual_color_recommendations,variant_id
from test_manual_recommendations import variant
from test_supply_regression import order,source_row,xlsx

@pytest.mark.parametrize('raw,label',[
    ('卡其色','베이지'),('卡其 １７','베이지'),('颜色: 卡其色17','베이지'),
    ('深灰色17','다크그레이'),('浅灰色','라이트그레이'),('淺灰色','라이트그레이'),
    ('米白色','아이보리'),('白色','화이트'),('黑色','블랙'),('军绿色','카키'),
    ('咖啡色','브라운'),('藏青色','네이비'),('蓝色','블루'),('粉色','핑크'),
    ('红色','레드'),('黄色','옐로우'),('紫色','퍼플'),('橙色','오렌지'),
])
def test_known_labels_and_supplier_numbers(raw,label):
    result=color_label(raw)
    assert result['label']==label and result['translated'] and not result['needsReview']

@pytest.mark.parametrize('raw',['未知灰色','卡其色/黑色','卡其色加绒','薄荷绿','<img src=x onerror=alert(1)>卡其色'])
def test_unknown_or_compound_shades_are_not_guessed(raw):
    result=color_label(raw)
    assert result['label']=='번역 확인 필요' and result['needsReview'] and not result['translated']

@pytest.mark.parametrize('raw,label',[('深灰色 다크 그레이17','다크그레이'),('卡其色 카키2','카키'),('米白色 아이보리03','아이보리')])
def test_existing_korean_text_stays_authoritative(raw,label):
    result=color_label(raw)
    assert result['label']==label and not result['translated'] and not result['needsReview']

@pytest.mark.parametrize('option,color,expected',[
    ('베이지','卡其色17',True),('카키','卡其色',False),('그린','卡其色',False),
    ('화이트','米白色',True),('화이트','白色17',True),('다크그레이','深灰色',True),
    ('그레이','深灰色',False),('블랙','未知灰色',False),('卡其色17','베이지',True),
])
def test_translation_recommendations_are_not_automatic(option,color,expected):
    row=dict(product='어텀 트위드',option=option);source=variant(color=color)
    assert not candidates(row,[source],{})[0]
    result=manual_color_recommendations(row,[source])
    assert bool(result)==expected
    if result:
        assert result[0]['variant']==source['variant'] and result[0]['sourceColor']==color
        assert '중국어 컬러 번역 확인' in result[0]['reason']

def test_product_size_and_unknown_shades_still_block_suggestions():
    row=dict(product='어텀 트위드',option='베이지 / 55')
    for source in [variant(product='다른상품',color='卡其色',size='55'),variant(color='卡其色',size='66'),variant(color='深卡其色',size='55')]:
        assert not manual_color_recommendations(row,[source])
    assert not manual_color_recommendations(row,[variant(color='卡其色'),variant(product='트위드',color='卡其色',size='55')])

class TranslationWorkflowTests(Base):
    def setUp(self):
        super().setUp();self.folder=Path(self.tmp.name)/'translated-supply';self.folder.mkdir()
        self.engine.supply_link(str(self.folder))
        self.engine.import_rows(dict(rows=[order(1,option='베이지'),order(2,option='베이지')],mode='snapshot',scope=SELLERS,replaceConfirmed=True))
        (self.folder/'솔리아 10월 13일 출고장 (완료).xlsx').write_bytes(xlsx([('출고장',[source_row(color='卡其色17',qty=1)])]))
        self.engine.supply_refresh()

    def active(self):return [r for r in self.engine.public_state()['rows'] if r['active']]

    def test_display_metadata_is_read_only_and_original_identifiers_stay_intact(self):
        before=copy.deepcopy(self.store.read());state=self.engine.public_state()
        source=state['supply']['variants'][0]
        assert source['color']=='卡其色17' and source['colorLabel']=='베이지' and source['colorTranslated']
        assert source['variant']==variant_id(source)
        for row in self.active():
            assert row['supplyInfo']['manualRecommended'] and not row['stockSecured'] and not row['dispatchEnd']
            assert not row['supplyInfo']['allocatedQty']
        assert self.store.read()==before and not self.fake.sent and not self.at.sent

    def test_only_explicit_save_assigns_original_stock_and_persists(self):
        row=self.active()[0];key=row['supplyInfo']['manualRecommendations'][0]['variant']
        self.engine.supply_match(dict(key=row['key'],variants=[key]))
        before=copy.deepcopy(self.store.read());self.restart()
        rows=self.active()
        assert sum(r['supplyInfo']['manifestQty'] for r in rows)==1
        assert all(r['supplyInfo']['matchMethod']=='manual' for r in rows)
        assert self.store.read()['supply']==before['supply']
        assert next(iter(before['supply']['manifests'].values()))['rows'][0]['color']=='卡其色17'

    def test_v0620_upgrade_translates_existing_cached_sources_without_reread(self):
        with self.store.edit() as s:s['appVersion']='0.6.20'
        before=copy.deepcopy(self.store.read())
        for path in self.folder.iterdir():path.unlink()
        self.restart();after=self.store.read()
        for key in ('rows','supply','settings','notices'):assert after[key]==before[key]
        assert after['appVersion']=='0.6.144'
        assert self.engine.public_state()['supply']['variants'][0]['colorLabel']=='베이지'
        assert all(r['supplyInfo']['manualRecommended'] for r in self.active())


def test_existing_latin_annotation_comparison_is_not_lost():
    row=dict(product='어텀 트위드',option='white')
    assert manual_color_recommendations(row,[variant(color='米白色 ivory17')])
    row['option']='白色 white17'
    assert manual_color_recommendations(row,[variant(color='ivory')])
