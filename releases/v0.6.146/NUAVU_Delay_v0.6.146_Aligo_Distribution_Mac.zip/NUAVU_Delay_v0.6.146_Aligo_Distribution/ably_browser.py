"""Visible Python/Chrome reader. Login, pagination and detail-open/close.

The only site mutation is Ably's own "배송지연메시지 발송 처리" and only when a
planner (app history) names the exact 상품주문번호; see Reader.push. Never
clicks dispatch, cancel or order-update actions. Each run has one isolated
context. No account/cookie/profile export.
"""
from __future__ import annotations
import math,re,time
from urllib.parse import urlsplit
from ably_sync import AblySyncError,AblyCancelled,AblyPushAborted,date_range,PUSH_OPTIONS

LOGIN='https://my.a-bly.com/login'
ORDERS='https://my.a-bly.com/sales/order/send?entry_point=dashboard&ably_global_tab=default'
HEADERS=('상품주문번호','주문번호','수량','판매채널','배송지연 메시지 발송')
PUSH_BUTTON='배송지연메시지 발송 처리'
SEND_BUTTON='배송지연메시지 발송'
MODAL='.notify-delay-modal'
PICKER_PANEL='.el-picker-panel.expected-sending-date-picker__popper'
def exact(text):return re.compile(r'^\s*'+re.escape(text)+r'\s*$')

class Reader:
    def __init__(self,page,stop,progress):self.page=page;self.stop=stop;self.progress=progress
    def check(self,ignore_stop=False):
        if self.stop.is_set() and not ignore_stop:raise AblyCancelled('동기화를 중단했습니다. 기존 이력을 유지합니다.')
        if self.page.is_closed():raise AblySyncError('에이블리 창이 닫혔습니다. 기존 이력을 유지합니다.')
    def wait(self,predicate,message,seconds=30,ignore_stop=False):
        # ignore_stop: between clicking Ably's send and reading its outcome, a cancel must not
        # abandon a message that may already have gone out; the loop checks stop afterwards.
        until=time.monotonic()+seconds
        while time.monotonic()<until:
            self.check(ignore_stop)
            value=predicate()
            if value:return value
            self.page.wait_for_timeout(150)
        raise AblySyncError(message)
    def trusted(self,login=False):
        u=urlsplit(self.page.url)
        return u.scheme=='https' and u.hostname=='my.a-bly.com' and u.port in (None,443) and not u.username and not u.password and (u.path=='/login' if login else u.path=='/sales/order/send')
    def logged_in(self):
        u=urlsplit(self.page.url)
        return u.scheme=='https' and u.hostname=='my.a-bly.com' and self.page.locator('a[href="/seller"]').count()==1 and self.page.get_by_text('로그아웃',exact=True).is_visible()
    def login(self,account):
        self.progress('에이블리 로그인 화면을 엽니다.')
        self.page.goto(LOGIN,wait_until='domcontentloaded',timeout=30000)
        self.wait(lambda:self.logged_in() or self.page.locator('input[type="password"]:visible').count()==1,'로그인 화면이 열리지 않았습니다.')
        if not self.logged_in():
            if not self.trusted(login=True):raise AblySyncError('에이블리 로그인 주소를 확인하지 못했습니다. 계정을 입력하지 않았습니다.')
            pw=self.page.locator('input[type="password"]:visible')
            user=self.page.locator('input[type="text"]:visible, input[type="email"]:visible, input:not([type]):visible')
            if user.count()!=1:raise AblySyncError('로그인 아이디 입력칸을 구분하지 못했습니다.')
            for loc,value in ((user,account['username']),(pw,account['password'])):
                self.check()
                if not self.trusted(login=True):raise AblySyncError('로그인 입력 중 주소가 바뀌었습니다.')
                maxlength=loc.get_attribute('maxlength')
                if maxlength and int(maxlength)>=0 and len(value)>int(maxlength):raise AblySyncError('계정 길이가 사이트 입력 제한을 초과했습니다.')
                loc.fill('');loc.press_sequentially(value,delay=20);loc.press('Tab')
                if loc.input_value()!=value:raise AblySyncError('로그인 입력값이 일치하지 않습니다. 저장 계정을 확인하세요.')
            self.check()
            if not self.trusted(login=True) or user.input_value()!=account['username'] or pw.input_value()!=account['password']:raise AblySyncError('로그인 전 입력값을 확인하지 못했습니다.')
            self.page.get_by_role('button',name='로그인',exact=True).click(timeout=10000)
            self.progress('로그인 확인 중입니다. 추가 인증이 나오면 Chrome에서 직접 완료하세요. 자동 재시도하지 않습니다.')
            import browser_window;started=time.monotonic()
            def signed():
                if time.monotonic()-started>8:
                    if browser_window.need_person():raise AblySyncError('추가 인증 또는 로그인 확인이 필요합니다. '+browser_window.need_person())
                    browser_window.attention()  # extra authentication likely: show the window
                return self.logged_in()
            self.wait(signed,'로그인을 확인하지 못했습니다. 계정 또는 추가 인증을 확인하고 다시 동기화하세요.',120)
            browser_window.calm()
        market=self.page.locator('a[href="/seller"]').inner_text().strip()
        from branding import seller_identity
        self.market=account.get('shopName','')
        if not self.market or seller_identity(market)!=seller_identity(self.market):raise AblySyncError('앱에 설정한 쇼핑몰과 에이블리 마켓이 다릅니다. 계정과 쇼핑몰 이름을 확인하세요.')
        self.page.goto(ORDERS,wait_until='domcontentloaded',timeout=30000)

    def read_list(self):
        if not self.trusted() or not self.logged_in():raise AblySyncError('에이블리 세션 또는 발송 관리 주소가 바뀌었습니다.')
        from branding import seller_identity
        if not getattr(self,'market','') or seller_identity(self.page.locator('a[href="/seller"]').inner_text())!=seller_identity(self.market):raise AblySyncError('조회 도중 에이블리 마켓이 바뀌었습니다. 다시 동기화하세요.')
        # Only the table's five required columns are read; no contacts/addresses.
        return self.page.evaluate('''() => {
          const head=document.querySelector('table.el-table__header'), body=document.querySelector('table.el-table__body');
          const paging=document.querySelector('.pagination-container');
          if(!head||!body||!paging)return null;
          const headers=[...head.querySelectorAll('th')].map(e=>e.innerText.trim());
          const names=['상품주문번호','주문번호','수량','판매채널','배송지연 메시지 발송'];
          const idx=names.map(n=>headers.indexOf(n)); if(idx.some(i=>i<0))return null;
          const loading=[...document.querySelectorAll('.el-loading-mask')].some(e=>e.getBoundingClientRect().width&&getComputedStyle(e).display!=='none');
          return {loading,total:paging.querySelector('.total-count')?.innerText,
            active:paging.querySelector('.el-pager .active')?.innerText,
            size:paging.querySelector('.el-pagination__sizes input')?.value,
            rows:[...body.querySelectorAll('tbody tr')].map(r=>idx.map(i=>r.cells[i]?.innerText.trim()))};
        }''')
    def list_ready(self,number=None):
        d=self.read_list()
        if not d or d['loading']:return False
        m=re.fullmatch(r'\s*총\s*([\d,]+)건\s*',d['total'] or '')
        if not m:return False
        d['total']=int(m[1].replace(',',''));d['active']=int(d['active'] or 1)
        if d['total']>20000:raise AblySyncError('최대 20,000개 상품까지 동기화할 수 있습니다.')
        if number is not None and d['active']!=number:return False
        if d['size']!='100개씩 보기':return False
        expected=max(0,min(100,d['total']-(d['active']-1)*100))
        if len(d['rows'])!=expected:return False
        return d
    def page_number(self,number):
        self.check()
        empty=self.list_ready(number)
        if empty and empty['total']==0:return empty
        pager=self.page.locator('.pagination-container .el-pager')
        target=pager.get_by_text(str(number),exact=True)
        for _ in range(200):
            if target.count()==1 and target.is_visible():break
            btn=self.page.locator('.pagination-container > .btn-next')
            if not btn.is_enabled():raise AblySyncError('다음 페이지 번호를 찾지 못했습니다.')
            before=pager.inner_text();btn.click()
            self.wait(lambda:pager.inner_text()!=before,'페이지 목록이 바뀌지 않았습니다.')
        else:raise AblySyncError('페이지 목록 확인 한도를 초과했습니다.')
        active=pager.locator('.active').inner_text().strip()
        if active!=str(number):
            previous=self.read_list()['rows'];target.click()
            self.wait(lambda:(d if (d:=self.read_list()) and d['rows']!=previous else False),'페이지의 주문 목록이 바뀌지 않았습니다.')
        return self.wait(lambda:self.list_ready(number),'주문 목록 갱신을 확인하지 못했습니다.')
    def detail(self,item):
        ident=item['itemId'];self.check()
        headers=self.page.locator('table.el-table__header th').all_inner_texts()
        column=[v.strip() for v in headers].index('상품주문번호')+1
        self.page.locator(f'table.el-table__body tbody tr td:nth-child({column}) a').filter(has_text=re.compile(r'^\s*'+re.escape(ident)+r'\s*$')).click(timeout=10000)
        dialog=self.page.get_by_role('dialog',name=f'상품주문정보 조회 [{ident}]',exact=True)
        dialog.wait_for(state='visible',timeout=15000)
        def fields():
            return dialog.evaluate('''el => Object.fromEntries([...el.querySelectorAll('.title')]
                .filter(e=>['예상출고일','수량','주문상태'].includes(e.textContent.trim()))
                .map(e=>[e.textContent.trim(),e.nextElementSibling?.textContent.trim()]))''')
        d=self.wait(lambda:(f if (f:=fields()).get('수량') else False),'주문 상세가 준비되지 않았습니다.')
        if not self.trusted() or d.get('수량')!=str(item['qty']) or d.get('주문상태')!='상품 준비중' or '예상출고일' not in d:
            raise AblySyncError('주문 상세의 수량·상태·출고일 항목을 대조하지 못했습니다.')
        value=d['예상출고일'] or '';date_range(value)
        dialog.get_by_role('button',name='Close',exact=True).click();dialog.wait_for(state='hidden',timeout=10000)
        return value
    @staticmethod
    def items(d):
        result=[]
        for ident,order,qty,seller,notice in d['rows']:
            if seller!='에이블리' or not re.fullmatch(r'\d+',ident or '') or not re.fullmatch(r'\d+',order or '') or not re.fullmatch(r'[1-9]\d*',qty or ''):raise AblySyncError('상품주문번호·주문번호·수량·판매채널을 확인하지 못했습니다.')
            m=re.fullmatch(r'발송(?:\s*\((\d{4}-\d{2}-\d{2})\))?',notice or '')
            if notice not in ('','-','미발송','발송 필요') and not m:raise AblySyncError('배송지연 메시지 발송 이력 형식을 확인하지 못했습니다.')
            result.append({'itemId':ident,'orderId':order,'qty':int(qty),'noticeSent':bool(m),'noticeDate':(m[1] or '') if m else ''})
        return result
    def page_size_100(self):
        self.wait(lambda:self.page.locator('.el-pagination__sizes input').is_enabled(),'발송 관리 목록이 준비되지 않았습니다.')
        if self.page.locator('.el-pagination__sizes input').input_value()=='100개씩 보기':return
        self.page.locator('.el-pagination__sizes input').click()
        self.page.get_by_text('100개씩 보기',exact=True).click()
    def first_page_group(self):
        # Restart at page 1 by the existing first-page group button when needed.
        pager=self.page.locator('.pagination-container .el-pager')
        if not pager.get_by_text('1',exact=True).count():
            for _ in range(200):
                self.check();prev=self.page.locator('.pagination-container > .btn-prev')
                if not prev.is_enabled():break
                before=pager.inner_text();prev.click();self.wait(lambda:pager.inner_text()!=before,'첫 페이지로 돌아가지 못했습니다.')
                if pager.get_by_text('1',exact=True).count():break
    def verify_all(self,original,total,pages,message):
        self.progress('모든 페이지의 주문번호와 수량을 다시 대조합니다.')
        self.first_page_group();verified=[]
        for number in range(1,pages+1):
            d=self.page_number(number)
            if d['total']!=total:raise AblySyncError(message+' 중 주문 건수가 바뀌었습니다. 다시 동기화하세요.')
            verified.extend(self.items(d))
        if original!=verified or len(original)!=total:raise AblySyncError(message+'가 일치하지 않습니다. 다시 동기화하세요.')
    COUNT_CHANGE_RETRIES=3   # 2026-11-04: 주문 건수가 바뀌면(새 주문 유입) 처음부터 다시 확인하는 횟수
    def _count_changed(self,exc):return ('바뀌었습니다' in str(exc)) or ('일치하지 않습니다' in str(exc))
    def _walk_list(self,message,tolerant=False):
        """모든 페이지를 훑어 (items, total, pages, page_of). tolerant=False: 건수가 바뀌면 AblySyncError. tolerant=True: 바뀐 건수에 맞춰
        페이지를 늘려 계속 훑고 중복 행은 처음 본 페이지로 둔다(발송 직전 행 확인이 따로 있으므로 안전)."""
        first=self.page_number(1);total=first['total'];pages=max(1,math.ceil(total/100));original=[];seen=set();page_of={};number=0
        while number<pages:
            number+=1;d=self.page_number(number)
            if d['total']!=total:
                if not tolerant:raise AblySyncError(message+' 중 주문 건수가 바뀌었습니다. 다시 실행하세요.')
                total=d['total'];pages=max(pages,max(1,math.ceil(total/100)));self.progress(f'주문 건수가 {total}건으로 바뀌어 {pages}페이지까지 계속 확인합니다')
            for item in self.items(d):
                if item['itemId'] in seen:
                    if tolerant:continue
                    raise AblySyncError('페이지 사이에 중복 상품주문번호가 있습니다. 다시 실행하세요.')
                seen.add(item['itemId']);page_of[item['itemId']]=number;original.append(item)
            self.progress(f'{number}/{pages}페이지 목록 확인')
        return original,total,pages,page_of
    def collect(self,cache=None,planner=None):
        # 2026-11-04: 수집·대조 중 주문 건수가 바뀌면(새 주문 유입) 처음부터 다시 (최대 3회). 발송은 전체 대조 뒤에만 하므로 재시작해도 안전.
        for attempt in range(1,self.COUNT_CHANGE_RETRIES+1):
            try:return self._collect_once(cache,planner)
            except AblySyncError as exc:
                if attempt>=self.COUNT_CHANGE_RETRIES or not self._count_changed(exc):raise
                self.progress(f'주문 건수가 바뀌어 처음부터 다시 수집합니다 ({attempt}/{self.COUNT_CHANGE_RETRIES}) · {exc}');self.first_page_group()
    def _collect_once(self,cache=None,planner=None):
        cache=cache or {}
        self.page_size_100()
        first=self.page_number(1);total=first['total'];pages=max(1,math.ceil(total/100));entries=[];original=[];seen=set();page_of={}
        for number in range(1,pages+1):
            d=self.page_number(number)
            if d['total']!=total:raise AblySyncError('수집 중 주문 건수가 바뀌었습니다. 일부 자료는 반영하지 않았습니다. 다시 동기화하세요.')
            items=self.items(d);original.extend(items)
            for item in items:
                if item['itemId'] in seen:raise AblySyncError('페이지 사이에 중복 상품주문번호가 있습니다. 다시 동기화하세요.')
                seen.add(item['itemId']);page_of[item['itemId']]=number
                if not item['noticeSent']:continue
                saved=cache.get(item['itemId'])
                if saved and saved.get('noticeSent') is True and all(saved.get(k)==item[k] for k in ('itemId','orderId','qty','noticeDate')):
                    try:valid=bool(date_range(saved.get('range'))[1])
                    except AblySyncError:valid=False
                    if valid:
                        entries.append({**item,'range':saved['range'],'readAt':saved.get('readAt',''),'fromCache':True})
                        continue
                self.progress(f'{number}/{pages}페이지 · 안내 발송 {len(entries)+1}번째 상품의 예상출고일 확인 중')
                entries.append({**item,'range':self.detail(item)})
            after=self.page_number(number)
            if after['total']!=total or self.items(after)!=items:raise AblySyncError('상세 조회 중 주문 목록이 바뀌었습니다. 다시 동기화하세요.')
        self.verify_all(original,total,pages,'전체 페이지 대조')
        if len(entries)!=sum(e['noticeSent'] for e in original):raise AblySyncError('전체 페이지 대조가 일치하지 않습니다. 다시 동기화하세요.')
        pushes=[]
        if planner:
            # Only after the complete, twice-verified list: plan from app history, then act.
            targets,skipped=planner([dict(i) for i in original]);pushes=list(skipped)
            if targets:
                pushes.extend(self.push(targets,page_of,pages))
                sent={p['itemId']:p for p in pushes if p['status']=='sent'}
                try:
                    self.first_page_group()
                    for item in original:
                        p=sent.get(item['itemId'])
                        if not p:continue
                        item.update(noticeSent=True,noticeDate=p['platformNotice'])
                        self.progress(f'발송 처리한 상품주문번호 {item["itemId"]}의 예상출고일을 확인합니다.')
                        self.page_number(page_of[item['itemId']])
                        entries.append({**item,'range':self.detail(item)})
                    self.verify_all(original,total,pages,'발송 처리 후 전체 페이지 대조')
                    if len(entries)!=sum(e['noticeSent'] for e in original):raise AblySyncError('발송 처리 후 전체 페이지 대조가 일치하지 않습니다. 다시 동기화하세요.')
                except AblyCancelled:
                    if sent:raise AblyPushAborted('동기화를 중단했습니다. 이미 발송 처리한 건은 기록합니다.',pushes)
                    raise
                except Exception as exc:
                    if sent:raise AblyPushAborted(str(exc) if isinstance(exc,AblySyncError) else f'발송 처리 후 확인 중 오류 · {type(exc).__name__}: {str(exc).splitlines()[0][:160] if str(exc) else ""}',pushes) from exc
                    raise
        return {'entries':entries,'total':total,'notifiedTotal':len(entries),'pages':pages,'complete':True,'verified':True,'pushes':pushes}

    def push_only(self,planner):
        """List every page (no 예상출고일 detail reads), then send app-planned delay messages only.

        Used right after a message-less delay acknowledgement in the app: the Ably side gets the
        배송지연 message for those orders, and nothing from Ably is imported into the app.
        """
        self.page_size_100()
        tolerated=False
        for attempt in range(1,self.COUNT_CHANGE_RETRIES+1):
            try:
                original,total,pages,page_of=self._walk_list('목록 확인')
                self.verify_all(original,total,pages,'전체 페이지 대조');break
            except AblySyncError as exc:
                if not self._count_changed(exc):raise
                if attempt<self.COUNT_CHANGE_RETRIES:
                    self.progress(f'주문 건수가 바뀌어 목록을 처음부터 다시 확인합니다 ({attempt}/{self.COUNT_CHANGE_RETRIES})');self.first_page_group();continue
                # 2026-11-04 사장님: 건수가 계속 바뀌어도(새 주문 유입) 발송은 진행한다. 발송 직전에 행(주문번호·수량·미발송)을 다시 확인하므로 안전.
                self.progress('주문 건수가 계속 바뀌어 전체 대조 없이 진행합니다. 발송 직전에 행을 다시 확인합니다.');self.first_page_group()
                original,total,pages,page_of=self._walk_list('목록 확인',tolerant=True);tolerated=True
        targets,skipped=planner([dict(i) for i in original]);pushes=list(skipped)
        if targets:pushes.extend(self.push(targets,page_of,pages))
        return {'entries':[],'total':total,'notifiedTotal':0,'pages':pages,'complete':True,'verified':not tolerated,'pushes':pushes,'pushOnly':True,'planned':len(targets),'countChanged':tolerated}

    # ---- Ably "배송지연메시지 발송 처리" (the only site mutation; app-planned only) ----
    def checked_ids(self):
        return self.page.evaluate('''() => {
          const head=document.querySelector('table.el-table__header'), body=document.querySelector('table.el-table__body');
          if(!head||!body)return null;
          const i=[...head.querySelectorAll('th')].map(e=>e.innerText.trim()).indexOf('상품주문번호'); if(i<0)return null;
          return [...body.querySelectorAll('tbody tr')].filter(r=>r.querySelector('td.el-table-column--selection input[type="checkbox"]')?.checked).map(r=>r.cells[i]?.innerText.trim());
        }''') or []
    def row_of(self,ident):
        headers=[v.strip() for v in self.page.locator('table.el-table__header th').all_inner_texts()]
        column=headers.index('상품주문번호')+1
        return self.page.locator('table.el-table__body tbody tr').filter(has=self.page.locator(f'td:nth-child({column})').filter(has_text=exact(ident)))
    def set_checked(self,ident,on):
        row=self.row_of(ident)
        if row.count()!=1:raise AblySyncError(f'상품주문번호 {ident} 행을 하나로 찾지 못했습니다.')
        if (ident in self.checked_ids())==on:return
        self.robust_click(row.locator('td.el-table-column--selection label.el-checkbox'),f'상품주문번호 {ident} 체크박스',lambda:(ident in self.checked_ids())==on,10)
    def clear_checks(self):
        for ident in list(self.checked_ids()):self.set_checked(ident,False)
        if self.checked_ids():raise AblySyncError('이전 선택을 해제하지 못했습니다.')
    def open_modal_index(self):
        """Index (among all .el-dialog) of the visibly open '배송지연메시지 발송' dialog, or -1.

        Found by title and geometry, not by wrapper class: several dialog copies can exist
        (e.g. per market tab) and a hidden one must never be taken for the open one."""
        try:
            return self.page.evaluate('''()=>{const ds=[...document.querySelectorAll('.el-dialog')];
              return ds.findIndex(d=>{const t=d.querySelector('.el-dialog__title');const w=d.parentElement;
                if(!t||t.textContent.trim()!=='배송지연메시지 발송')return false;
                const r=d.getBoundingClientRect();const cs=getComputedStyle(d);const wcs=w?getComputedStyle(w):cs;
                return r.height>0&&r.width>0&&cs.display!=='none'&&cs.visibility!=='hidden'&&wcs.display!=='none'&&wcs.visibility!=='hidden';});}''')
        except Exception:return -1
    def open_modal(self):
        i=self.open_modal_index()
        if i<0:raise AblySyncError('배송지연메시지 발송 창이 열려 있지 않습니다.')
        return self.page.locator('.el-dialog').nth(i)
    def modal_state(self,modal):
        return modal.evaluate('''el=>({picked:[...el.querySelectorAll('.expected-sending-day-button__name')].filter(e=>e.classList.contains('selected')).map(e=>e.innerText.trim()),
            date:el.querySelector('.expected-sending-date-picker input')?.value||'',
            send:[...el.querySelectorAll('footer button')].filter(b=>b.innerText.trim()==='배송지연메시지 발송').map(b=>!b.disabled)})''')
    def choose_option(self,modal,option,due):
        if option=='date':
            picker=modal.locator('.expected-sending-date-picker input');panel=self.page.locator(PICKER_PANEL)
            self.robust_click(picker,'날짜로 선택하기',lambda:panel.count()==1 and panel.is_visible(),10)
            y,m,d=(int(v) for v in due.split('-'))
            labels=lambda:[re.sub(r'\D','',t) for t in panel.locator('.el-date-picker__header-label').all_inner_texts()]
            for _ in range(3):
                head=labels()
                if len(head)!=2 or not all(head):raise AblySyncError('달력의 연·월 표시를 읽지 못했습니다.')
                if (int(head[0]),int(head[1]))==(y,m):break
                if (int(head[0]),int(head[1]))>(y,m):raise AblySyncError('달력이 선택할 달보다 뒤에 있습니다.')
                self.robust_click(panel.locator('button.el-date-picker__next-btn.el-icon-arrow-right'),'달력 다음 달',lambda:labels()!=head,10)
            else:raise AblySyncError('달력에서 해당 월을 찾지 못했습니다.')
            cell=panel.locator('table.el-date-table td.available:not(.prev-month):not(.next-month):not(.disabled)').filter(has_text=exact(str(d)))
            if cell.count()!=1:raise AblySyncError(f'달력에서 {due}을(를) 선택 가능한 날짜로 찾지 못했습니다.')
            self.robust_click(cell,f'달력 {due}',lambda:self.modal_state(modal)['date']==due,10)
        else:
            if option not in PUSH_OPTIONS.values():raise AblySyncError('예상 출고일 선택지를 확인하지 못했습니다.')
            btn=modal.locator('.expected-sending-day-button__name').filter(has_text=exact(option))
            self.robust_click(btn,f'예상 출고일 버튼 "{option}"',lambda:self.modal_state(modal)['picked']==[option],10)
        st=self.modal_state(modal)
        if (st['picked'],st['date'])!=(([] if option=='date' else [option]),(due if option=='date' else '')) or st['send']!=[True]:
            raise AblySyncError('예상 출고일이 하나만 선택된 상태를 확인하지 못했습니다.')
    def step(self,name):
        self.last_step=name;self.progress(name)
    def robust_click(self,locator,what,verify,seconds=8):
        """Click, verify the resulting state; if the pointer click did not take, dispatch a DOM click once."""
        if locator.count()!=1:raise AblySyncError(f'{what}을(를) 하나로 찾지 못했습니다 ({locator.count()}개).')
        try:locator.scroll_into_view_if_needed(timeout=5000)
        except Exception:pass
        try:locator.click(timeout=5000)
        except Exception as exc:self.progress(f'{what} 클릭 재시도 (DOM 이벤트): {type(exc).__name__}');locator.dispatch_event('click')
        try:return self.wait(verify,f'{what} 클릭 후 상태가 바뀌지 않았습니다.',seconds)
        except AblyCancelled:raise
        except AblySyncError:
            self.progress(f'{what} 클릭 후 변화 없음 → DOM 이벤트로 1회 재시도');locator.dispatch_event('click')
            return self.wait(verify,f'{what} 클릭 후 상태가 바뀌지 않았습니다.',seconds)
    def dismiss_modal(self):
        try:
            if self.open_modal_index()>=0:
                modal=self.open_modal();close=modal.locator('footer button').filter(has_text=exact('닫기'))
                if close.count()==1:close.click(timeout=5000)
                else:self.page.keyboard.press('Escape')
                self.wait(lambda:self.open_modal_index()<0,'발송 창이 닫히지 않았습니다.',10)
            self.clear_checks()
        except AblySyncError:pass
    def toast_text(self):
        """Ably's top toast after sending ('배송지연메시지가 성공적으로 발송되었습니다.' or an error)."""
        try:
            for _ in range(10):
                texts=[t.strip() for t in self.page.locator('.el-message').all_inner_texts() if t.strip()]
                if texts:return ' / '.join(texts)[:200]
                self.page.wait_for_timeout(200)
            return ''
        except Exception:return ''
    def _send_group_relocating(self,number,group):
        """2026-11-04: 발송 직전 행 확인에 실패하면(새 주문 유입으로 행이 다른 페이지로 밀림) 목록을 다시 훑어 페이지를 찾고 한 번 더 시도."""
        try:return self.send_group(number,group)
        except AblyCancelled:raise
        except Exception as exc:
            if getattr(self,'clicked',False) or '발송 직전 상품주문번호' not in str(exc):raise
            self.dismiss_modal();self.first_page_group()
            try:_,_,_,fresh=self._walk_list('행 위치 재확인',tolerant=True)
            except AblySyncError:raise exc
            found=sorted({fresh.get(t['itemId'],0) for t in group})
            if len(found)!=1 or not found[0] or found[0]==number:raise exc
            self.progress(f'행이 {number}→{found[0]}페이지로 옮겨져 다시 시도합니다');self._group_page=found[0]
            self.page_number(found[0]);self.last_step='발송 대상 행 확인'
            return self.send_group(found[0],group)
    def send_group(self,number,group):
        """Select the group's rows on the current page and send one Ably dialog for them."""
        option,due=group[0]['option'],group[0]['dueDate'];idents=[t['itemId'] for t in group];self.clicked=False
        self.clear_checks()
        d=self.list_ready(number) or self.page_number(number);current={i['itemId']:i for i in self.items(d)}
        for t in group:
            i=current.get(t['itemId'])
            if not i or i['orderId']!=t['orderId'] or i['qty']!=t['qty'] or i['noticeSent']:raise AblySyncError(f'발송 직전 상품주문번호 {t["itemId"]}의 주문·수량·미발송 상태를 확인하지 못했습니다.')
        for ident in idents:self.set_checked(ident,True)
        if sorted(self.checked_ids())!=sorted(idents):raise AblySyncError('선택한 행이 발송 대상과 다릅니다.')
        if not self.trusted() or not self.logged_in():raise AblySyncError('발송 처리 전 에이블리 주소·세션을 확인하지 못했습니다.')
        self.step(f'{number}페이지 · {len(idents)}개 선택 → 배송지연메시지 발송 처리 버튼 클릭')
        self.robust_click(self.page.get_by_role('button',name=PUSH_BUTTON,exact=True),'배송지연메시지 발송 처리 버튼',lambda:self.open_modal_index()>=0,15)
        modal=self.open_modal()
        title=modal.locator('.el-dialog__title').first.inner_text().strip() if modal.locator('.el-dialog__title').count() else ''  # a hidden nested confirm dialog has a second, empty title
        if title and title!=SEND_BUTTON:raise AblySyncError('배송지연메시지 발송 창 제목이 다릅니다: '+title)
        self.step(f'발송 창 열림 확인 → 예상 출고일 선택 ({option if option!="date" else "달력 "+due})')
        self.choose_option(modal,option,due)
        if sorted(self.checked_ids())!=sorted(idents):raise AblySyncError('발송 창이 열린 뒤 선택 행이 바뀌었습니다.')
        st=self.modal_state(modal)
        self.step(f'예상 출고일 선택 확인 (버튼 {st["picked"] or "-"} · 달력 {st["date"] or "-"}) → 배송지연메시지 발송 버튼 클릭')
        send=modal.locator('footer button').filter(has_text=exact(SEND_BUTTON))
        if send.count()!=1 or not send.is_enabled():raise AblySyncError('배송지연메시지 발송 버튼을 누를 수 없는 상태입니다.')
        box=self.page.locator('.el-message-box__wrapper:visible');box_text=''
        self.clicked=True
        try:send.click(timeout=10000)
        except Exception as exc:self.progress(f'발송 버튼 클릭 재시도 (DOM 이벤트): {type(exc).__name__}');send.dispatch_event('click')
        nested=modal.locator('.el-dialog:visible')  # Ably keeps a nested 취소/발송 confirm dialog inside the send dialog
        def settled():
            if box.count():return 'box'
            if nested.count() and nested.first.locator('footer button').filter(has_text=exact('발송')).count():return 'confirm'
            return 'closed' if self.open_modal_index()<0 else False
        outcome=self.wait(settled,'발송 결과 화면을 확인하지 못했습니다.',40,ignore_stop=True)
        if outcome=='confirm':
            self.step('발송 확인 창(취소/발송) → 발송 클릭');nested.first.locator('footer button').filter(has_text=exact('발송')).first.click(timeout=10000)
            outcome=self.wait(lambda:settled() if settled()!='confirm' else False,'발송 확인 후 결과 화면을 확인하지 못했습니다.',40,ignore_stop=True)
        if outcome=='box':
            # Ably confirmation/notice box: read, confirm once, then re-check the rows (never retry a send).
            box_text=box.inner_text().strip()[:200];ok=box.locator('button.el-button--primary')
            if ok.count()!=1:raise AblySyncError('확인 창을 처리하지 못했습니다: '+box_text)
            ok.click(timeout=10000)
            self.wait(lambda:not box.count(),'확인 창이 닫히지 않았습니다.',20,ignore_stop=True)
            if self.open_modal_index()>=0:
                close=modal.locator('footer button').filter(has_text=exact('닫기'))
                if close.count()==1:close.click(timeout=10000)
                self.wait(lambda:self.open_modal_index()<0,'발송 창이 닫히지 않았습니다.',20,ignore_stop=True)
        toast=self.toast_text()
        if toast:self.progress('에이블리 안내: '+toast)
        # Confirm on the list itself, reloading the list if the page did not refresh.
        def shown():
            d=self.list_ready(number)
            if not d:return False
            now={i['itemId']:i for i in self.items(d)}
            return {k:now[k] for k in idents if k in now and now[k]['noticeSent']} if all(k in now and now[k]['noticeSent'] for k in idents) else False
        try:result=self.wait(shown,'목록 갱신 대기',25,ignore_stop=True)
        except AblyCancelled:raise
        except AblySyncError:
            self.page.goto(ORDERS,wait_until='domcontentloaded',timeout=30000);self.page_size_100();self.first_page_group();self.page_number(number)
            try:result=self.wait(shown,'목록 갱신 대기',25,ignore_stop=True)
            except AblyCancelled:raise
            except AblySyncError:result=None
        self.clear_checks()
        if result is None:
            d=self.list_ready(number);now={i['itemId']:i for i in self.items(d)} if d else {}
            return [{**t,'status':'sent' if now.get(t['itemId'],{}).get('noticeSent') else 'failed','platformNotice':now.get(t['itemId'],{}).get('noticeDate',''),
                     'reason':'에이블리 목록에서 발송 표시를 확인하지 못했습니다. '+(box_text or toast)} for t in group]
        return [{**t,'status':'sent','platformNotice':result[t['itemId']]['noticeDate'],'reason':''} for t in group]
    def push(self,targets,page_of,pages=None):
        from datetime import datetime
        results=[];stamp=datetime.now().astimezone().isoformat(timespec='seconds')
        try:return self._push(targets,page_of,results)
        finally:
            for r in results:r.setdefault('sentAt',stamp)
    def _push(self,targets,page_of,results):
        groups={}
        for t in targets:groups.setdefault((page_of.get(t['itemId'],0),t['dueDate'],t['option']),[]).append(t)
        done=0;self.first_page_group()
        try:
            for (number,due,option),group in sorted(groups.items()):
                self.check()
                if not number:
                    results.extend({**t,'status':'skipped','platformNotice':'','reason':'전체 목록에서 상품주문번호를 찾지 못했습니다.'} for t in group);continue
                self.progress(f'에이블리 배송지연 메시지 발송 처리 {done+1}~{done+len(group)}/{len(targets)}건 준비 중 ({number}페이지)')
                self.page_number(number)
                self.last_step='발송 대상 행 확인';self._group_page=number
                try:out=self._send_group_relocating(number,group)
                except AblyCancelled:raise
                except Exception as exc:
                    exc=exc if isinstance(exc,AblySyncError) else AblySyncError(f'{getattr(self,"last_step","")} 단계 오류 · {type(exc).__name__}: {str(exc).splitlines()[0][:160] if str(exc) else ""}')
                    if not getattr(self,'clicked',False):
                        # Nothing was sent: close any open dialog, hold this group, continue with the rest.
                        self.dismiss_modal();results.extend({**t,'status':'skipped','platformNotice':'','reason':str(exc)} for t in group);continue
                    # Send was clicked and the outcome is unknown: never retry. Report by what the list shows now.
                    d=self.list_ready(getattr(self,'_group_page',number));now={i['itemId']:i for i in self.items(d)} if d else {}
                    out=[{**t,'status':'sent' if now.get(t['itemId'],{}).get('noticeSent') else 'failed','platformNotice':now.get(t['itemId'],{}).get('noticeDate',''),'reason':str(exc)} for t in group]
                    results.extend(out)
                    if any(o['status']=='failed' for o in out):
                        rest=[t for g in groups.values() for t in g if t['itemId'] not in {o['itemId'] for o in results}]
                        results.extend({**t,'status':'skipped','platformNotice':'','reason':'앞선 발송 처리 오류로 중단'} for t in rest)
                        self.progress('발송 처리 오류로 남은 대상을 보류했습니다: '+str(exc))
                        return results
                    continue
                results.extend(out);done+=len(group)
                failed=[o for o in out if o['status']=='failed']
                if failed:
                    rest=[t for g in groups.values() for t in g if t['itemId'] not in {o['itemId'] for o in results}]
                    results.extend({**t,'status':'skipped','platformNotice':'','reason':'앞선 발송 확인 실패로 중단'} for t in rest)
                    return results
        except AblyCancelled as exc:
            if any(r['status']=='sent' for r in results):
                rest=[t for g in groups.values() for t in g if t['itemId'] not in {o['itemId'] for o in results}]
                results.extend({**t,'status':'skipped','platformNotice':'','reason':'사용자 중단'} for t in rest)
                raise AblyPushAborted('동기화를 중단했습니다. 이미 발송 처리한 건은 기록합니다.',results) from exc
            raise
        return results

def collect(account,stop,progress,cache=None,planner=None,push_only=False):
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        import browser_window as _bw;browser=pw.chromium.launch(**_bw.launch_kwargs())
        context=browser.new_context(viewport={'width':1280,'height':800},device_scale_factor=1,accept_downloads=False)
        import browser_window;browser_window.attach(context)
        pages=[]
        def register(page):
            pages.append(page)
            # Native browser dialogs are never accepted; Ably's own confirm box for
            # the planned delay message is handled explicitly in Reader.send_group.
            page.on('dialog',lambda dialog:dialog.dismiss())
        context.on('page',register);page=context.new_page();reader=Reader(page,stop,progress)
        try:
            reader.login(account)
            if push_only:return reader.push_only(planner)
            return reader.collect(cache,planner)
        finally:context.close();browser.close()
