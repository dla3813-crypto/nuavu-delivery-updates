"""2026-10-19 (공통): 메시지 없는 배송지연 안내 — after 18:00 the platform pushes (Ably/Zigzag hook) can be scheduled for 09:00."""
import unittest
from datetime import datetime,timezone,timedelta
from unittest.mock import patch
from domain import KST
from helpers import Base,Clock
from test_supply_regression import order

class NightManualTests(Base):
    def setUp(self):
        super().setUp()
        self.engine.import_rows({'rows':[order(1),order(2)]})
        self.calls=[];self.engine.manual_notice_hook=lambda keys:self.calls.append(list(keys)) or '에이블리 자동 처리 시작'
        self.keys=[r['key'] for r in self.engine.public_state()['rows'] if r['active'] and r['seller']!='누아브 자사몰']  # 자사몰은 메시지 없는 안내 금지 (v0.6.146)
    def apply(self,schedule,request='req-0123456789abcdef'):
        return self.engine.external_manual({'keys':self.keys,'dueDate':'2026-10-22','templateKey':'first','mode':'set_due_date','requestId':request,'schedule':schedule})
    def test_now_calls_hook_immediately(self):
        Clock.current=datetime(2026,10,19,20,0,tzinfo=KST)
        r=self.apply('now');self.assertEqual(len(self.calls),1);self.assertIn('에이블리 자동 처리 시작',r['message']);self.assertFalse(self.store.read().get('pendingPlatformPushes'))
    def test_morning_defers_hook_until_nine(self):
        Clock.current=datetime(2026,10,19,20,0,tzinfo=KST)
        r=self.apply('morning')
        self.assertEqual(self.calls,[]);self.assertIn('오전 9시',r['message']);self.assertTrue(r['scheduledAt'].startswith('2026-10-20T09:00'))
        pending=self.store.read()['pendingPlatformPushes'];self.assertEqual(len(pending),1);self.assertEqual(sorted(pending[0]['keys']),sorted(self.keys))
        rows={x['key']:x for x in self.engine.public_state()['rows']};self.assertTrue(all(rows[k]['dueDate']=='2026-10-22' for k in self.keys))  # notice itself is recorded now
        self.assertEqual(len(self.engine.public_state()['pendingPlatformPushes']),1)
        # before 09:00 nothing runs; the runner compares the stored UTC time with the real clock, so emulate by editing the stamp
        self.assertEqual(self.engine.run_pending_platform_pushes(),[])
        Clock.current=datetime(2026,10,20,9,0,30,tzinfo=KST)   # 09:00 passed on the app clock
        ran=self.engine.run_pending_platform_pushes();self.assertEqual(len(ran),1);self.assertEqual(sorted(self.calls[0]),sorted(self.keys))
        self.assertEqual(self.store.read()['pendingPlatformPushes'],[]);self.assertEqual(self.engine.run_pending_platform_pushes(),[])
    def test_before_nine_schedules_same_morning(self):
        Clock.current=datetime(2026,10,20,7,30,tzinfo=KST)
        self.assertTrue(self.apply('morning')['scheduledAt'].startswith('2026-10-20T09:00'))
    def test_invalid_schedule_rejected(self):
        from external_notices import ExternalError
        with self.assertRaises(ExternalError):self.apply('tonight')
    def test_without_hook_pending_waits(self):
        Clock.current=datetime(2026,10,19,20,0,tzinfo=KST);self.apply('morning');self.engine.manual_notice_hook=None
        with self.store.edit() as s:s['pendingPlatformPushes'][0]['at']='2000-01-01T00:00:00+00:00'
        self.assertEqual(self.engine.run_pending_platform_pushes(),[]);self.assertEqual(len(self.store.read()['pendingPlatformPushes']),1)

if __name__=='__main__':unittest.main()
