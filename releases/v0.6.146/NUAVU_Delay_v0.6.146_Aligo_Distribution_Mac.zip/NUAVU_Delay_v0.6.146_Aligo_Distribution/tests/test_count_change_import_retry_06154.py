"""[배포판 이식본 · 정시 불러오기 테스트 제외] v0.6.154 (2026-11-04 15:49 사장님)
- 에이블리 배송지연 자동 발송: 목록 확인·전체 대조 중 주문 건수가 바뀌어도(새 주문 유입) 다시 확인하거나 전체 대조 없이 발송한다.
- 정시 주문 불러오기: 실패 시 10초 간격 5회 재시도, 재시도 중엔 알림 없음, 모두 실패하면 한 번 알림."""
import threading,unittest
from unittest.mock import patch
from test_ably_push import FakePage,make_reader,ably_rows,ReaderPushTests

class GrowingList:
    """Reader.page_number 를 감싸 호출마다 새 주문(미발송)을 맨 앞에 끼워 넣는다 — 09:00 새 주문 유입 재현."""
    def __init__(self,reader,page,times):
        self.page=page;self.times=times;self.calls=0;self.orig=reader.page_number
    def __call__(self,number):
        if self.calls<self.times:
            self.calls+=1;n=900+self.calls
            self.page.rows.insert(0,{'itemId':str(n),'orderId':str(20000+n),'qty':1,'notice':'-'})
        return self.orig(number)

class CountChange(ReaderPushTests):
    def test_push_only_retries_once_then_sends(self):
        page=FakePage(ably_rows(3,sent=('803',)));r,stop,msgs=make_reader(page,{})
        r.page_number=GrowingList(r,page,2)   # 첫 확인 중 두 번 늘어남 → 처음부터 다시 → 안정
        snap=r.push_only(self.planner_for([self.target('801'),self.target('802')]))
        self.assertEqual({p['itemId']:p['status'] for p in snap['pushes']},{'801':'sent','802':'sent'})
        self.assertTrue(snap['verified']);self.assertFalse(snap.get('countChanged'))
        self.assertTrue(any('처음부터 다시 확인' in m for m in msgs))
    def test_push_only_keeps_sending_when_count_keeps_changing(self):
        page=FakePage(ably_rows(3,sent=('803',)));r,stop,msgs=make_reader(page,{})
        r.page_number=GrowingList(r,page,999)   # 매번 늘어남 → 3회 재확인 뒤 전체 대조 없이 진행
        snap=r.push_only(self.planner_for([self.target('801'),self.target('802')]))
        self.assertEqual({p['itemId']:p['status'] for p in snap['pushes']},{'801':'sent','802':'sent'})
        self.assertFalse(snap['verified']);self.assertTrue(snap['countChanged'])
        self.assertEqual([s['ids'] for s in page.sent],[['801','802']])
        self.assertTrue(any('전체 대조 없이 진행' in m for m in msgs))
    def test_row_pushed_to_next_page_is_relocated(self):
        # 발송 직전 행 확인 실패(새 주문 유입으로 2페이지로 밀림) → 목록 재탐색 → 새 페이지에서 한 번 더
        from ably_browser import AblySyncError
        page=FakePage(ably_rows(2));r,stop,msgs=make_reader(page,{})
        calls=[]
        def send_group(number,group):
            calls.append(number)
            if number==1:raise AblySyncError('발송 직전 상품주문번호 901의 주문·수량·미발송 상태를 확인하지 못했습니다.')
            return [{**t,'status':'sent','platformNotice':'','reason':''} for t in group]
        r.send_group=send_group;r.dismiss_modal=lambda:None;r.first_page_group=lambda:None;r.page_number=lambda n:None
        r._walk_list=lambda message,tolerant=False:([],1,2,{'901':2})
        t={'itemId':'901','orderId':'20901','qty':1,'key':'k901','dueDate':'2026-10-15','noticeId':'N','option':'내일'}
        out=r.push([t],{'901':1},2)
        self.assertEqual([(o['itemId'],o['status']) for o in out],[('901','sent')]);self.assertEqual(calls,[1,2])
        self.assertTrue(any('페이지로 옮겨져' in m for m in msgs))
        # 재탐색해도 못 찾으면 종전처럼 보류(skipped)
        calls.clear();r._walk_list=lambda message,tolerant=False:([],1,2,{})
        out=r.push([t],{'901':1},2);self.assertEqual([(o['itemId'],o['status']) for o in out],[('901','skipped')]);self.assertEqual(calls,[1])
    def test_collect_restarts_on_count_change(self):
        page=FakePage(ably_rows(3,sent=('803',)));r,stop,msgs=make_reader(page,{'801':'2026-10-15','802':'2026-10-15','803':'2026-10-20'})
        r.page_number=GrowingList(r,page,2)
        snap=r.collect({},self.planner_for([self.target('801')]))
        self.assertEqual({p['itemId']:p['status'] for p in snap['pushes']},{'801':'sent'});self.assertTrue(snap['verified'])
        self.assertTrue(any('처음부터 다시 수집' in m for m in msgs))

for _n in [n for n in dir(ReaderPushTests) if n.startswith('test_')]:setattr(CountChange,_n,None)   # 상속 테스트는 원래 파일에서만

if __name__=='__main__':unittest.main()
