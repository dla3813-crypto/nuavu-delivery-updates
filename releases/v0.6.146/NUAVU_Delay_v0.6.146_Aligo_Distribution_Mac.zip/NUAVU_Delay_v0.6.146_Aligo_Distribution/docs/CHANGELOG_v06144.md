# NUAVU_Delay_v0.6.144_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06143.md

## 2026-11-04 15:49 사장님 (배포 대상: 0.6.143 → 0.6.144) — 누아브판 0.6.154 이식 (patch/apply_06154_ably_count_change_import_retry.py, 에이블리 부분만)
- 에이블리 배송지연 메시지 자동 발송·동기화: 목록 확인·전체 대조 중 주문 건수가 바뀌면(새 주문 유입) 처음부터 최대 3회 다시 확인, 자동 발송은 그래도 바뀌면 전체 대조 없이 진행(발송 직전 행 재확인). 행이 다른 페이지로 밀리면 재탐색.
- 테스트 tests/test_count_change_import_retry_06154.py (4)
