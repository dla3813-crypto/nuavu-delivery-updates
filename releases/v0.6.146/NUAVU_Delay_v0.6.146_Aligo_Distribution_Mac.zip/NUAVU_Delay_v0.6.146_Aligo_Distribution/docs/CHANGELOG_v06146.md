# NUAVU_Delay_v0.6.146_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06145.md

## 2026-11-05 20:52 사장님 (배포 대상: 0.6.145 → 0.6.146) — 누아브판 0.6.157 이식 (patch/apply_dist_06146_manual_plus_auto_match.py)
- supply_workflow: automatic_candidates(row,variants) 분리, auto_added_variants(row,variants,mappings) 추가. candidates(): 수동 규칙(비어 있지 않음) → 수동 선택 행 + 수동 선택과 상품명이 겹치는 자동 후보. 빈 규칙(매칭 취소)은 그대로. supplyInfo.autoVariants.
- web/app.js 수동 매칭 창: autoVariants 체크 + '자동 매칭 추가' 표시.
- 테스트 tests/test_manual_plus_auto_match_06146.py (7). (누아브판 0.6.157의 입고 예정 변경은 배포판에 입고 예정 기능이 없어 해당 없음.)

## 2026-11-05 21:10 사장님 (0.6.146 추가) — 중국어 컬러 행은 '수동매칭 권장'으로 (patch/apply_dist_06146b_chinese_color_recommend.py)
- manual_color_recommendations(row,variants,exclude=(),only_chinese=False): 매칭된 주문에는 번역된 중국어 컬러 행만 권장, 이미 연결된 행 제외. allocation_view에서 매칭된 주문에도 권장 계산. supplyInfo.matchedVariants(수동 매칭 창에 자동 행 체크).
- web/dispatch_view.manualRecommended: matchNeeded 조건 제거. 테스트 tests/test_chinese_color_recommend_06146.py (3)
