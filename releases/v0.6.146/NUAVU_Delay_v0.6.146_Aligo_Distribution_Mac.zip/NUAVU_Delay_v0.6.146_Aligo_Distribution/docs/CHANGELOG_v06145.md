# NUAVU_Delay_v0.6.145_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06144.md

## 2026-11-04 22:01 사장님 긴급 (배포 대상: 0.6.144 → 0.6.145) — 너나우리 설정을 누아브판과 동일하게 (patch/apply_dist_06145_nuna_scheme.py)
- 너나우리 전용 연결 방식 settings['nunaScheme'] (기본 http — 너나우리는 HTTP로만 전송됨). 기존 상태는 시작 시 http로 채움. 알리고용 settings['scheme']('https')과 분리.
- 너나우리 문자 안내 생성 시 scheme=nunaScheme, 발송 직전 검사(aligo_workflow.validate_send_config)도 너나우리는 nunaScheme과 일치해야 함 (알리고 문자는 https 그대로). 연결 방식 변경 시 configRevision+1, 미요청·예약 일시정지.
- Engine.remaining(kind, route=None): route='NUNAURI'(너나우리 계정·nunaScheme으로만), 'ALIGO'(알리고 문자 계정으로만), 비우면 실제 발송 경로. /api/remaining에 route 전달.
- UI: 너나우리 섹션에 연결 방식 select(#nunaScheme, http/https) + 안내문 + SMS/LMS 잔여량 조회 버튼(#checkNunaSMS/#checkNunaLMS → route NUNAURI, 결과 #nunaResult). 알리고 섹션 버튼은 route ALIGO. 저장 시 scheme 전송, nunauriAccount.scheme으로 표시.
- 테스트 tests/test_nunauri_scheme_06145.py (14)
