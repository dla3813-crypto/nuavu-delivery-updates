'use strict';
// Zigzag (카카오스타일 파트너센터): 변경 발송 예정일 sync + app-planned 배송연기 안내. Yellow theme.
document.body.insertAdjacentHTML('beforeend',`
<dialog id="zigzagSyncDialog" class="ably-dialog zigzag-dialog">
 <div class="dialoghead"><div><p class="eyebrow">ZIGZAG</p><h2>지그재그 출고 예정일 동기화</h2></div><button data-zigzag-close="zigzagSyncDialog">닫기</button></div>
 <p>파트너센터 <b>상품준비/배송 관리 → 배송준비중</b> 목록을 조회기간 전체로 읽습니다. <b>변경 발송 예정일</b>이 있는 주문만 앱의 출고 예정일 이력으로 가져옵니다 (시간 제외). 기본 발송 예정일만 있는 주문은 지연 안내가 없는 것으로 보고 건드리지 않습니다.</p>
 <div class="notice"><b>배송연기 안내 자동 전송 규칙</b><br>메시지 없는 배송지연 안내를 처리하면, 지그재그 주문 중 <b>앱 출고 예정일이 지그재그 발송 예정일보다 늦은 건만</b> 배송연기 안내를 보냅니다. 같거나 이르면 보내지 않습니다.<br><small>사유 “상품 입고 지연” · 상세사유 “안녕하세요 고객님 배송 지연으로 불편을 드려 죄송합니다. 최대한 빠르게 보내드리겠습니다.” · 주말·선택 불가일은 다음 영업일로, 7영업일 초과는 보류. 지그재그는 주문당 1회만 가능합니다.</small></div>
 <div class="settings-actions"><button id="zigzagSyncStart" class="yellow-button">배송준비중 전체 동기화</button><button id="zigzagPushStart" class="yellow-button">앱 안내 기준 배송연기 안내 보내기</button><button id="zigzagSyncCancel" disabled>중단</button><button id="zigzagSyncSettings">로그인 설정</button></div>
 <p id="zigzagSyncStatus" class="sub" role="status"></p><p id="zigzagSyncStamp" class="sub"></p>
 <div id="zigzagSyncIssues" class="notice small" hidden></div>
</dialog>
<dialog id="zigzagSettingsDialog" class="ably-dialog zigzag-dialog">
 <div class="dialoghead"><h2>⚙ 지그재그 설정</h2><button data-zigzag-close="zigzagSettingsDialog">닫기</button></div>
 <p>카카오스타일 파트너센터(지그재그) 로그인 계정을 입력하세요. shop.zigzag.kr/<b>스토어 이름</b>/#!/stats 로 들어가 partners.kakaostyle.com 로그인 화면에서 자동 로그인합니다.</p>
 <label>스토어 주소 이름<input id="zigzagShop" autocomplete="off" placeholder="예: nuavu" value="nuavu"></label>
 <label>아이디<input id="zigzagUsername" autocomplete="off"></label>
 <label>비밀번호<input id="zigzagPassword" type="password" autocomplete="new-password" placeholder="비밀번호"></label>
 <p class="sub">macOS 키체인의 별도 항목에 저장합니다. 저장된 비밀번호는 화면에 다시 표시하지 않습니다.</p>
 <button id="zigzagSave" class="primary">로그인 정보 저장</button><p id="zigzagSettingsStatus" class="sub" role="status"></p>
</dialog>`);
let zigzagTimer=null,zigzagPolling=false;
async function zigzagCall(action,username='',password='',shop=''){
 const bridge=window.pywebview?.api;
 if(!state?.desktopMode||!bridge?.zigzag_action)throw Error('지그재그 동기화는 v0.6.92 맥 앱에서 사용할 수 있습니다.');
 const result=await bridge.zigzag_action(token,action,username,password,shop);if(result.error)throw Error(result.error);return result;
}
function zigzagStatus(s){
 $('zigzagSyncStatus').textContent=s.message||'';$('zigzagSyncStatus').classList.toggle('error',s.phase==='error');
 $('zigzagSyncStart').disabled=!!s.running;$('zigzagPushStart').disabled=!!s.running;$('zigzagSyncCancel').disabled=!s.running;
 $('zigzagSyncStamp').textContent=s.lastSync?'마지막 동기화 '+dateTime(s.lastSync):'아직 동기화하지 않았습니다.';
 const issues=s.result?.issues||[];$('zigzagSyncIssues').hidden=!issues.length;
 $('zigzagSyncIssues').textContent=issues.map(x=>'상품주문번호 '+x.itemId+' · '+x.reason).join('\n');
}
async function pollZigzag(){
 if(zigzagPolling)return;zigzagPolling=true;clearTimeout(zigzagTimer);
 try{const s=await zigzagCall('status');zigzagStatus(s);if(s.running)zigzagTimer=setTimeout(pollZigzag,1000);else if(s.phase==='done')await refresh();}
 catch(e){$('zigzagSyncStatus').textContent=e.message;$('zigzagSyncStatus').classList.add('error');}
 finally{zigzagPolling=false;}
}
async function openZigzagSettings(){
 $('zigzagPassword').value='';$('zigzagUsername').value='';$('zigzagSave').disabled=true;
 $('zigzagSettingsDialog').showModal();$('zigzagSettingsStatus').textContent='키체인 저장 상태를 확인합니다.';
 try{const s=await zigzagCall('settings');$('zigzagUsername').value=s.username||'';$('zigzagShop').value=s.shop||'nuavu';$('zigzagPassword').placeholder=s.hasPassword?'저장됨 · 변경할 때만 입력':'비밀번호';$('zigzagSave').disabled=!s.available;$('zigzagSettingsStatus').textContent=s.hasPassword?'저장된 계정이 있습니다.':'계정을 입력하고 저장하세요.';}
 catch(e){$('zigzagSettingsStatus').textContent=e.message;$('zigzagSave').disabled=!window.pywebview?.api?.zigzag_action;}
}
window.openZigzagSettings=openZigzagSettings;
$('zigzagSyncBtn').onclick=async()=>{$('zigzagSyncDialog').showModal();await pollZigzag();};
$('zigzagSettingsBtn').onclick=openZigzagSettings;$('zigzagSyncSettings').onclick=openZigzagSettings;
$('zigzagSyncStart').onclick=async()=>{
 $('zigzagSyncStart').disabled=true;
 try{zigzagStatus(await zigzagCall('start'));await pollZigzag();}
 catch(e){$('zigzagSyncStatus').textContent=e.message;$('zigzagSyncStatus').classList.add('error');$('zigzagSyncStart').disabled=false;}
};
$('zigzagPushStart').onclick=async()=>{
 $('zigzagPushStart').disabled=true;
 try{zigzagStatus(await zigzagCall('start_push'));await pollZigzag();}
 catch(e){$('zigzagSyncStatus').textContent=e.message;$('zigzagSyncStatus').classList.add('error');$('zigzagPushStart').disabled=false;}
};
$('zigzagSyncCancel').onclick=async()=>{
 $('zigzagSyncCancel').disabled=true;
 try{zigzagStatus(await zigzagCall('cancel'));await pollZigzag();}
 catch(e){$('zigzagSyncStatus').textContent=e.message;}
};
$('zigzagSave').onclick=()=>action(async()=>{
 const password=$('zigzagPassword').value;$('zigzagPassword').value='';
 try{const s=await zigzagCall('save',$('zigzagUsername').value,password,$('zigzagShop').value);$('zigzagPassword').placeholder='저장됨 · 변경할 때만 입력';$('zigzagSettingsStatus').textContent=s.message;}
 catch(e){$('zigzagSettingsStatus').textContent=e.message;throw e;}
 finally{$('zigzagPassword').value='';}
},$('zigzagSave'));
$('zigzagSettingsDialog').addEventListener('close',()=>{$('zigzagPassword').value='';});
document.querySelectorAll('[data-zigzag-close]').forEach(b=>b.onclick=()=>$(b.dataset.zigzagClose).close());
