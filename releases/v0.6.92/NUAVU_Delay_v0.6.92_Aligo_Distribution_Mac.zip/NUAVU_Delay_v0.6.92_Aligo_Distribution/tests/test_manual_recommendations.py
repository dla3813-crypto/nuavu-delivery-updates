"""Similar-color suggestions must never auto-allocate or change stored rules."""
import copy
from pathlib import Path

import pytest

from domain import SELLERS
from helpers import Base
from supply_workflow import candidates, manual_color_recommendations, variant_id
from test_supply_regression import order, source_row, xlsx


def variant(product='어텀 트위드', color='아이보리', size='F', brand='N'):
    result = dict(product=product, color=color, size=size, brand=brand)
    result['variant'] = variant_id(result)
    return result


@pytest.mark.parametrize('option,color', [
    ('화이트', '아이보리'), ('아이보리', '화이트'),
    ('카키', '그린'), ('그린', '카키'),
    ('화이트 / FREE', '米白色 아이보리03'),
    ('白色 화 이 트17', '아이 보 리2'),
    ('검정', '블랙'), ('회색', '그레이'), ('남색', '네이비'),
    ('파랑', '블루'), ('분홍', '핑크'),
])
def test_similar_colors_are_suggested_but_never_automatched(option, color):
    row = dict(product='4컬러 어텀 트위드', option=option)
    source = variant(color=color)
    assert not candidates(row, [source], {})[0]
    result = manual_color_recommendations(row, [source])
    assert len(result) == 1
    assert result[0]['variant'] == source['variant']
    assert color in result[0]['reason']


@pytest.mark.parametrize('option,source', [
    ('화이트', variant(product='다른 상품')),
    ('화이트 / 55', variant(size='66')),
    ('화이트 / M', variant(size='L')),
    ('화이트 / 2XL', variant(size='XL')),
    ('화이트 / 미정', variant()),
    ('화이트', variant(color='블랙')),
    ('다크그레이', variant(color='그레이')),
    ('라이트그린', variant(color='카키')),
    ('深灰色17', variant()),
    (' / FREE', variant()),
    ('아이보리', variant(color='米白色 아이보리03')),
])
def test_unknown_unrelated_or_exact_colors_not_suggested(option, source):
    assert manual_color_recommendations(dict(product='4컬러 어텀 트위드', option=option), [source]) == []


def test_exact_product_keeps_precedence_over_shorter_generic_name():
    row = dict(product='어텀 트위드', option='화이트')
    assert manual_color_recommendations(row, [variant(color='블랙'), variant(product='트위드')]) == []


def test_explicit_size_and_bracketed_product_annotation():
    row = dict(product='[4color] 어텀 트위드', option='화이트 / 55')
    assert len(manual_color_recommendations(row, [variant(size='55')])) == 1


class RecommendationWorkflowTests(Base):
    def setUp(self):
        super().setUp()
        self.folder = Path(self.tmp.name) / 'recommendations'
        self.folder.mkdir()
        self.engine.supply_link(str(self.folder))
        self.set_orders([order(1, product='4컬러 어텀 트위드', option='화이트')])

    def set_orders(self, rows):
        self.engine.import_rows(dict(rows=rows, mode='snapshot', scope=SELLERS, replaceConfirmed=True))

    def write(self, rows, name='진행상황_1017.xlsx'):
        (self.folder / name).write_bytes(xlsx([('테스트', rows)]))

    def active(self):
        return {r['orderId']: r for r in self.engine.public_state()['rows'] if r['active']}

    def ivory(self, **kwargs):
        return source_row(product='어텀 트위드', color='米白色 아이보리03', **kwargs)

    def test_suggestion_is_read_only_and_has_no_dates_or_stock(self):
        self.write([self.ivory(office='2026-10-17')])
        self.engine.supply_refresh()
        before = copy.deepcopy(self.store.read())
        row = self.active()['TEST-001']
        info = row['supplyInfo']
        self.assertTrue(info['manualRecommended'])
        self.assertTrue(info['matchNeeded'])
        self.assertFalse(info['matched'])
        self.assertEqual(info['allocatedQty'], 0)
        self.assertEqual(info['sources'], [])
        self.assertFalse(row['stockSecured'])
        self.assertEqual(row['dispatchEnd'], '')
        self.assertEqual(row['progressOfficeDates'], [])
        self.assertEqual(self.store.read(), before)
        self.assertEqual(self.engine.public_state()['supply']['totals']['recommended'], 1)
        self.assertFalse(self.fake.sent)
        self.assertFalse(self.at.sent)

    def test_user_connection_removes_same_option_recommendations(self):
        self.set_orders([order(i, product='4컬러 어텀 트위드', option='화이트') for i in [1, 2]])
        self.write([self.ivory(qty=1)], '솔리아 10월 13일 출고장 (완료).xlsx')
        self.engine.supply_refresh()
        first = self.active()['TEST-001']
        selected = first['supplyInfo']['manualRecommendations'][0]['variant']
        self.engine.supply_match(dict(key=first['key'], variants=[selected]))
        rows = self.active()
        self.assertTrue(rows['TEST-001']['stockSecured'])
        self.assertFalse(rows['TEST-002']['stockSecured'])
        for row in rows.values():
            self.assertFalse(row['supplyInfo']['manualRecommended'])
            self.assertEqual(row['supplyInfo']['matchMethod'], 'manual')
        self.restart()
        self.assertEqual(self.active()['TEST-001']['supplyInfo']['manualVariants'], [selected])
        self.engine.supply_match(dict(key=first['key'], variants=[]))
        self.assertTrue(self.active()['TEST-001']['supplyInfo']['manualRecommended'])

    def test_exact_color_match_even_out_of_stock_not_recommended(self):
        self.write([self.ivory(office='2026-10-17'), source_row(product='어텀 트위드', color='화이트', qty=0)])
        self.engine.supply_refresh()
        info = self.active()['TEST-001']['supplyInfo']
        self.assertTrue(info['matched'])
        self.assertFalse(info['manualRecommended'])
        self.assertEqual(info['allocatedQty'], 0)

    def test_unselected_brand_and_closed_manifest_not_recommended(self):
        self.write([self.ivory(brand='OD')], '솔리아 10월 13일 출고장 (완료).xlsx')
        self.engine.supply_refresh()
        self.assertFalse(self.active()['TEST-001']['supplyInfo']['manualRecommended'])
        self.write([self.ivory()], '솔리아 10월 13일 출고장 (완료).xlsx')
        self.engine.supply_refresh()
        self.assertTrue(self.active()['TEST-001']['supplyInfo']['manualRecommended'])
        self.engine.supply_reset({'confirmed': True})
        self.assertFalse(self.active()['TEST-001']['supplyInfo']['manualRecommended'])

    def test_zero_qty_or_blank_date_can_still_help_manual_identification(self):
        self.write([self.ivory(qty=0)])
        self.engine.supply_refresh()
        self.assertTrue(self.active()['TEST-001']['supplyInfo']['manualRecommended'])
        self.assertEqual(self.active()['TEST-001']['dispatchEnd'], '')

    def test_inactive_review_and_soldout_orders_excluded(self):
        self.write([self.ivory(office='2026-10-17')])
        self.engine.supply_refresh()
        with self.store.edit() as state:
            next(r for r in state['rows'] if r['active'])['review'] = True
        self.assertFalse(self.active()['TEST-001']['supplyInfo']['manualRecommended'])
        with self.store.edit() as state:
            next(r for r in state['rows'] if r['active'])['review'] = False
        row = self.active()['TEST-001']
        self.engine.external_manual(dict(keys=[row['key']], dueDate='2026-10-30'))
        with self.store.edit() as state:
            state['notices'][-1]['noticeType'] = 'soldout_card'
            state['notices'][-1]['dueDate'] = ''
        self.assertFalse(self.active()['TEST-001']['supplyInfo'].get('manualRecommended', False))
        self.set_orders([order(2, product='다른상품', option='블랙')])
        self.assertFalse(any(r['supplyInfo'].get('manualRecommended') for r in self.engine.public_state()['rows']))

    def test_v0616_upgrade_preserves_settings_supply_and_notices(self):
        self.write([self.ivory(office='2026-10-17')])
        self.engine.supply_refresh()
        self.queue(keys=[self.active()['TEST-001']['key']], sendMode='MORNING')
        with self.store.edit() as state:
            state['appVersion'] = '0.6.16'
            state['alerts'].append(dict(code='RESULT_UNCONFIRMED', resolvedAt='', id='TEST', noticeId='EXAMPLE', level='error'))
        before = copy.deepcopy(self.store.read())
        self.restart()
        after = self.store.read()
        for key in ['rows', 'settings', 'supply', 'alerts']:
            self.assertEqual(after[key], before[key], key)
        self.assertEqual(len(after['notices']), len(before['notices']))
        for old, new in zip(before['notices'], after['notices']):
            for key in old.keys() | new.keys():
                if key not in {'events', 'note', 'resumedAt'}:
                    self.assertEqual(new.get(key), old.get(key), key)
        self.assertEqual(after['appVersion'], '0.6.92')
        self.assertFalse(self.fake.sent)
