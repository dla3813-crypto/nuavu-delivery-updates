"""v0.6.92: app-notified but Ably-unsent orders get Ably's 배송지연메시지 발송 처리.

Pure planning / recording tests plus a Reader run against a fake page. No real
Ably, Chrome, Keychain or provider access.
"""
import copy,threading,unittest
from unittest.mock import MagicMock
from helpers import Base
from test_supply_regression import order
from ably_sync import (plan_pushes,push_option,record_pushes,apply_snapshot,AblySyncController,AblySyncError,AblyPushAborted,
                       account_cache_key,PUSH_OPTIONS)
from history_seed import is_external
from domain import CHANGE,SOLDOUT_CARD

TODAY='2026-10-14'

def item(ident='801',oid='12345',qty=1,sent=False,date=''):
    return dict(itemId=ident,orderId=oid,qty=qty,noticeSent=sent,noticeDate=date)

def snapshot(entries=None,total=None,pushes=None):
    entries=entries if entries is not None else []
    total=len(entries) if total is None else total
    s=dict(entries=entries,total=total,notifiedTotal=len(entries),pages=max(1,(total+99)//100),complete=True,verified=True)
    if pushes is not None:s['pushes']=pushes
    return s

class OptionTests(unittest.TestCase):
    def test_quick_buttons_and_calendar(self):
        for delta,label in PUSH_OPTIONS.items():
            with self.subTest(delta=delta):
                due=f'2026-10-{14+delta:02d}' if 14+delta<=31 else '2026-11-%02d'%(14+delta-31)
                self.assertEqual(push_option(due,TODAY),(label,''))
        self.assertEqual(push_option('2026-10-18',TODAY),('date',''))   # +4
        self.assertEqual(push_option('2026-10-14',TODAY),('date',''))   # today is selectable on the calendar
        self.assertEqual(push_option('2026-11-13',TODAY),('date',''))   # +30
    def test_past_and_too_far_are_held(self):
        self.assertEqual(push_option('2026-10-13',TODAY)[0],'');self.assertEqual(push_option('2026-11-14',TODAY)[0],'')
        self.assertEqual(push_option('bad',TODAY)[0],'')

class PlanTests(Base):
    def setUp(self):
        super().setUp()
        with self.store.edit() as s:s['rows']=[]
        self.engine.import_rows({'rows':[order(1)|{'orderId':'12345','orderItemId':'801'},order(2)|{'orderId':'22222','orderItemId':'802'}]})
        rows=self.store.read()['rows'];self.key=rows[0]['key'];self.key2=rows[1]['key']
    def plan(self,items):return plan_pushes(self.store.read(),items,TODAY)
    def test_app_sms_notice_unsent_on_ably_is_target(self):
        n=self.send(keys=[self.key],dueDate='2026-10-15')
        targets,skipped=self.plan([item(),item('802','22222')])
        self.assertEqual([(t['itemId'],t['option'],t['dueDate'],t['noticeId']) for t in targets],[('801','내일','2026-10-15',n['id'])]);self.assertEqual(skipped,[])
    def test_message_less_ack_is_target(self):
        self.engine.external_manual({'keys':[self.key],'dueDate':'2026-10-21'})
        targets,_=self.plan([item()]);self.assertEqual([(t['itemId'],t['option']) for t in targets],[('801','1주 이내')])
    def test_already_sent_on_ably_never_targeted(self):
        self.send(keys=[self.key],dueDate='2026-10-15')
        self.assertEqual(self.plan([item(sent=True,date='2026-10-13')]),([],[]))
    def test_no_app_notice_nothing(self):self.assertEqual(self.plan([item()]),([],[]))
    def test_ably_sync_history_alone_is_not_an_app_notice(self):
        apply_snapshot(self.engine,snapshot([item(sent=True,date='2026-10-13')|{'range':'2026-10-20'}]))
        self.assertEqual(self.plan([item()]),([],[]))
    def test_soldout_queued_failed_test_excluded(self):
        self.send(keys=[self.key],dueDate='',noticeType='soldout_card',template=SOLDOUT_CARD);self.assertEqual(self.plan([item()]),([],[]))
        self.queue(keys=[self.key2],dueDate='2026-10-15');self.assertEqual(self.plan([item('802','22222')]),([],[]))
        with self.store.edit() as s:s['notices'][-1]['status']='FAILED'
        self.assertEqual(self.plan([item('802','22222')]),([],[]))
        with self.store.edit() as s:s['notices'][-1]['status']='DELIVERED';s['notices'][-1]['isTest']=True
        self.assertEqual(self.plan([item('802','22222')]),([],[]))
    def test_past_due_is_held_with_reason(self):
        self.send(keys=[self.key],dueDate='2026-10-15')
        targets,skipped=plan_pushes(self.store.read(),[item()],'2026-10-16')  # the sync runs a day after the promised date;self.assertEqual(targets,[]);self.assertEqual(skipped[0]['status'],'skipped');self.assertIn('지나',skipped[0]['reason'])
    def test_quantity_or_id_mismatch_not_targeted(self):
        self.send(keys=[self.key],dueDate='2026-10-15')
        self.assertEqual(self.plan([item(qty=2)]),([],[]));self.assertEqual(self.plan([item('999')]),([],[]))
    def test_aggregated_row_needs_all_ids_and_sends_only_unsent(self):
        with self.store.edit() as s:s['rows']=[]
        self.engine.import_rows({'rows':[order(1)|{'orderId':'12345','orderItemId':'801'},order(1)|{'orderId':'12345','orderItemId':'802'}]})
        key=self.store.read()['rows'][0]['key'];self.send(keys=[key],dueDate='2026-10-16')
        targets,_=self.plan([item('801',sent=True,date='2026-10-13'),item('802')])
        self.assertEqual([t['itemId'] for t in targets],['802'])
        self.assertEqual(self.plan([item('802')]),([],[]))  # one of two IDs listed: partial, never pushed
    def test_latest_app_date_wins_over_older(self):
        self.send(keys=[self.key],dueDate='2026-10-15');self.clock(12);self.send(keys=[self.key],dueDate='2026-10-28',template=CHANGE)
        targets,_=self.plan([item()]);self.assertEqual(targets[0]['option'],'2주 이내')

class RecordTests(Base):
    def setUp(self):
        super().setUp()
        with self.store.edit() as s:s['rows']=[]
        self.engine.import_rows({'rows':[order(1)|{'orderId':'12345','orderItemId':'801'}]})
        self.key=self.store.read()['rows'][0]['key'];self.n=self.send(keys=[self.key],dueDate='2026-10-15')
    def pushed(self,status='sent',**kw):
        return dict(itemId='801',orderId='12345',qty=1,key=self.key,dueDate='2026-10-15',noticeId=self.n['id'],option='내일',status=status,reason='',sentAt='2026-10-14T10:00:00+09:00',platformNotice='2026-10-14')|kw
    def test_snapshot_with_push_records_log_event_and_marks_sync_notice(self):
        s=snapshot([item(sent=True,date='2026-10-14')|{'range':'2026-10-15'}],pushes=[self.pushed()])
        result=apply_snapshot(self.engine,s)
        self.assertEqual((result['pushed'],result['pushFailed'],result['pushSkipped'],result['items']),(1,0,0,1));self.assertIn('발송 처리 1건',result['message'])
        state=self.store.read();self.assertEqual(state['ablyPushLog'][0]['itemId'],'801')
        src=next(n for n in state['notices'] if n['id']==self.n['id']);self.assertIn('에이블리 배송지연 메시지 발송 처리 완료',src['events'][-1]['note']);self.assertEqual(src['status'],'PENDING')
        sync=state['notices'][-1];self.assertTrue(sync['pushedByApp']);self.assertEqual(sync['pushSources'][0]['noticeId'],self.n['id']);self.assertTrue(is_external(sync))
        self.assertEqual(self.row()['dueDate'],'2026-10-15');self.assertEqual(self.row()['dueDateSource'],'customer_message')
        self.assertEqual(state['audits'][-2]['event'],'에이블리 배송지연 메시지 발송 처리')
    def test_failed_and_skipped_become_issues_without_history(self):
        result=apply_snapshot(self.engine,snapshot(pushes=[self.pushed('failed',reason='확인 실패'),self.pushed('skipped',itemId='802',reason='지난 날짜')]))
        self.assertEqual((result['pushed'],result['pushFailed'],result['pushSkipped']),(0,1,1))
        self.assertEqual([i['itemId'] for i in result['issues']],['801','802']);self.assertIn('에이블리 발송 실패',result['issues'][0]['reason'])
        self.assertEqual(len(self.store.read()['notices']),1);self.assertEqual(len(self.store.read()['notices'][0].get('events',[])),len(self.n.get('events',[])))
    def test_malformed_push_result_rejected_atomically(self):
        before=self.store.read()
        for bad in [[{'status':'sent'}],[{'itemId':'801','status':'weird'}],'x']:
            with self.assertRaises(AblySyncError):apply_snapshot(self.engine,snapshot(pushes=bad))
        self.assertEqual(self.store.read(),before)
    def test_controller_push_flag_plans_from_store_and_records_abort(self):
        vault=MagicMock(available=True);vault.load.return_value=dict(version=1,username='fake',password='FAKE-SECRET')
        seen={}
        def runner(a,stop,progress,cache,planner=None):
            seen['planner']=planner
            if planner is None:return snapshot()
            targets,skipped=planner([item(),item('802','22222')]);seen['targets']=targets
            raise AblyPushAborted('최종 대조 실패',[dict(t,status='sent',reason='',platformNotice='2026-10-14') for t in targets])
        c=AblySyncController(self.engine,runner=runner,vault=vault)
        c.start();c.thread.join(4);self.assertEqual(c.status()['phase'],'done');self.assertIsNone(seen['planner'])
        c.start(push=True);c.thread.join(4);st=c.status()
        self.assertEqual(st['phase'],'error');self.assertIn('최종 대조 실패',st['message']);self.assertIn('발송 처리 1건',st['message']);self.assertTrue(st['push'])
        self.assertEqual([t['itemId'] for t in seen['targets']],['801'])
        self.assertEqual(self.store.read()['ablyPushLog'][0]['status'],'sent');self.assertNotIn('FAKE-SECRET',str(st))
        self.assertEqual(len([n for n in self.store.read()['notices'] if n.get('source')=='ably_sync']),0)
    def test_browser_exception_detail_shown_without_secret(self):
        vault=MagicMock(available=True);vault.load.return_value=dict(version=1,username='fakeuser',password='FAKE-SECRET')
        def runner(a,stop,progress,cache,planner=None):progress('발송 창 열림 확인');raise RuntimeError('Timeout 10000ms exceeded for FAKE-SECRET fakeuser\nCall log: x')
        c=AblySyncController(self.engine,runner=runner,vault=vault);c.start(push=True);c.thread.join(4);msg=c.status()['message']
        self.assertIn('RuntimeError: Timeout 10000ms exceeded',msg);self.assertIn('마지막 단계: 발송 창 열림 확인',msg)
        self.assertNotIn('FAKE-SECRET',msg);self.assertNotIn('fakeuser',msg);self.assertNotIn('Call log',msg)
    def test_controller_cancel_after_sends_still_records(self):
        vault=MagicMock(available=True);vault.load.return_value=dict(version=1,username='fake',password='FAKE-SECRET')
        def runner(a,stop,progress,cache,planner=None):
            targets,_=planner([item()]);stop.set()
            raise AblyPushAborted('동기화를 중단했습니다.',[dict(targets[0],status='sent',reason='',platformNotice='2026-10-14')])
        c=AblySyncController(self.engine,runner=runner,vault=vault);c.start(push=True);c.thread.join(4)
        self.assertEqual(len(self.store.read()['ablyPushLog']),1)

# ---- Reader against a fake Ably page -------------------------------------------------

class FakeLocator:
    """Minimal Playwright-locator stand-in driven by FakePage state."""
    def __init__(self,page,kind,arg=None):self.page=page;self.kind=kind;self.arg=arg
    def count(self):return self.page.count(self.kind,self.arg)
    def is_visible(self):return self.count()>0
    def is_enabled(self):return self.page.enabled(self.kind,self.arg)
    def input_value(self):return self.page.value(self.kind,self.arg)
    def click(self,timeout=None):self.page.click(self.kind,self.arg)
    def dispatch_event(self,name):self.page.click(self.kind,self.arg)
    def scroll_into_view_if_needed(self,timeout=None):pass
    def wait_for(self,state=None,timeout=None):
        if state=='visible' and not self.count():raise AssertionError('not visible: '+self.kind)
    def inner_text(self):return self.page.text(self.kind,self.arg)
    def all_inner_texts(self):return self.page.texts(self.kind,self.arg)
    def filter(self,has=None,has_text=None):
        pattern=has_text.pattern if has_text is not None else (has.arg[1] if has is not None and isinstance(has.arg,tuple) else None)
        return FakeLocator(self.page,self.kind,(self.arg,pattern))
    def locator(self,sel):return FakeLocator(self.page,self.kind+'>'+sel,self.arg)
    def nth(self,i):return self
    def get_by_text(self,text,exact=False):return FakeLocator(self.page,self.kind+'>text',text)
    def get_by_role(self,role,name=None,exact=False):return FakeLocator(self.page,'role:'+name,None)
    def evaluate(self,script):return self.page.modal_state()
    def all(self):return [self]
    first=property(lambda self:self)
    def press(self,key):pass
    def fill(self,v):pass
    def get_attribute(self,name):return None

class FakePage:
    """One page of Ably's 발송 관리 with the delay-message dialog. 100-row pages."""
    def __init__(self,rows,confirm_box=False,refresh=True,today='2026-10-14'):
        self.rows=rows;self.checked=set();self.modal=None;self.sent=[];self.confirm_box=confirm_box;self.refresh=refresh;self.today=today
        self.url='https://my.a-bly.com/sales/order/send';self.active=1;self.size='100개씩 보기';self.box=None;self.closed=False;self.dialog_open=None;self.calendar=None
        self.keyboard=MagicMock()
    # ---- page API used by Reader ----
    def is_closed(self):return self.closed
    def goto(self,url,wait_until=None,timeout=None):self.url=url.split('?')[0];self.checked=set()
    def wait_for_timeout(self,ms):pass
    def locator(self,sel):return FakeLocator(self,sel)
    def get_by_text(self,text,exact=False):return FakeLocator(self,'text',text)
    def get_by_role(self,role,name=None,exact=False):return FakeLocator(self,'role:'+name,None)
    def evaluate(self,script):
        if '배송지연메시지 발송' in script and 'findIndex' in script:return 0 if self.modal else -1
        if 'checked' in script:return [r['itemId'] for r in self.rows if r['itemId'] in self.checked]
        total=len(self.rows)
        return {'loading':False,'total':f'총 {total}건','active':str(self.active),'size':self.size,
                'rows':[[r['itemId'],r['orderId'],str(r['qty']),'에이블리',r['notice']] for r in self.page_rows()]}
    def page_rows(self):return self.rows[(self.active-1)*100:self.active*100]
    def modal_state(self):
        m=self.modal or {}
        return {'picked':[m['picked']] if m.get('picked') else [],'date':m.get('date',''),'send':[bool(m.get('picked') or m.get('date'))] if self.modal else []}
    # ---- behaviour ----
    def count(self,kind,arg):
        if kind=='a[href="/seller"]':return 1
        if kind.startswith('role:'+'배송지연메시지 발송 처리'):return 1
        if kind.startswith('.el-message-box__wrapper:visible'):return 1 if self.box else 0
        if kind.startswith('.notify-delay-modal .el-dialog') or kind.startswith('.el-dialog'):return 1 if self.modal else 0
        if kind.startswith('.el-picker-panel'):return 1 if self.calendar else 0
        if kind.startswith('.el-message:visible'):return 0
        if kind=='table.el-table__body tbody tr':
            pattern=arg[1] if isinstance(arg,tuple) else None
            if pattern is None:return len(self.page_rows())
            return sum(bool(__import__('re').fullmatch(pattern,r['itemId'])) for r in self.page_rows())
        if kind.endswith('.expected-sending-day-button__name'):
            return 1 if arg and arg[1] and any(__import__('re').fullmatch(arg[1],o) for o in PUSH_OPTIONS.values()) else 5
        if kind.endswith('footer button'):return 1
        if kind.endswith('td.available:not(.prev-month):not(.next-month):not(.disabled)'):
            return 1 if self.calendar and arg and arg[1] else 0
        if kind.endswith('button.el-button--primary'):return 1 if self.box else 0
        if kind.endswith('.el-pager>text'):return 1
        return 1
    def enabled(self,kind,arg):return True
    def value(self,kind,arg):
        if '.el-pagination__sizes input' in kind:return self.size
        return ''
    def text(self,kind,arg):
        if kind.endswith('.el-dialog__title'):return '배송지연메시지 발송'
        if kind.startswith('.el-message-box__wrapper'):return self.box or ''
        if kind.endswith('.el-pager'):return '1'
        if kind.endswith('.active'):return str(self.active)
        if kind=='a[href="/seller"]':return '누아브'
        return ''
    def texts(self,kind,arg):
        if kind=='table.el-table__header th':return ['','주문 상태','결제일','상품주문번호','주문번호','택배사','송장번호','상품명','판매자 상품코드','옵션 정보','수량','판매채널','배송지연 메시지 발송']
        if kind.endswith('.el-date-picker__header-label'):return ['2026 년','10월']
        if kind.endswith('.el-message:visible'):return []
        return []
    def click(self,kind,arg):
        if kind.endswith('label.el-checkbox'):
            ident=arg[1].strip('^\\s*$').replace('\\','') if arg and arg[1] else None
            ident=[r['itemId'] for r in self.page_rows() if __import__('re').fullmatch(arg[1],r['itemId'])][0]
            self.checked^={ident};return
        if kind.startswith('role:'+'배송지연메시지 발송 처리'):
            assert self.checked,'dialog without selection';self.modal={'picked':'','date':''};return
        if kind.endswith('.expected-sending-day-button__name'):
            self.modal['picked']=[o for o in PUSH_OPTIONS.values() if __import__('re').fullmatch(arg[1],o)][0];self.modal['date']='';return
        if kind.endswith('.expected-sending-date-picker input'):self.calendar=True;return
        if kind.endswith('td.available:not(.prev-month):not(.next-month):not(.disabled)'):
            day=[d for d in range(1,32) if __import__('re').fullmatch(arg[1],str(d))][0]
            self.modal['date']=f'2026-10-{day:02d}';self.modal['picked']='';self.calendar=None;return
        if kind.endswith('footer button') and arg and arg[1] and '닫기' in arg[1]:self.modal=None;return
        if kind.endswith('footer button'):
            # the send: Ably marks every checked row and may show a confirm box
            self.sent.append({'ids':sorted(self.checked),'option':self.modal['picked'] or self.modal['date']})
            if self.confirm_box:self.box='발송하시겠습니까?';return
            self.apply_send();return
        if kind.endswith('button.el-button--primary'):self.box=None;self.apply_send();return
        if kind.endswith('el-icon-arrow-right'):return
    def apply_send(self):
        self.modal=None
        if self.refresh:
            for r in self.rows:
                if r['itemId'] in self.checked:r['notice']=f'발송 ({self.today})'
        self.checked=set()

class FakeDialogReader:
    """Replace Reader.detail: the fake has no detail dialog; return the due date Ably now shows."""

def make_reader(page,planner_items_due):
    from ably_browser import Reader
    stop=threading.Event();messages=[]
    r=Reader(page,stop,messages.append)
    r.detail=lambda item:planner_items_due.get(item['itemId'],'2026-10-20')
    r.trusted=lambda login=False:True
    r.market='누아브'
    return r,stop,messages

def ably_rows(n,sent=()):
    return [{'itemId':str(800+i),'orderId':str(10000+i),'qty':1,'notice':'발송 (2026-10-13)' if str(800+i) in sent else '-'} for i in range(1,n+1)]

class ReaderPushTests(unittest.TestCase):
    def planner_for(self,targets):
        def planner(items):
            unsent={i['itemId'] for i in items if not i['noticeSent']}
            return [t for t in targets if t['itemId'] in unsent],[]
        return planner
    def target(self,ident,option='내일',due='2026-10-15',oid=None):
        return {'itemId':ident,'orderId':oid or str(10000+int(ident)-800),'qty':1,'key':'k'+ident,'dueDate':due,'noticeId':'N','option':option}
    def test_quick_button_group_and_calendar_date(self):
        page=FakePage(ably_rows(3,sent=('803',)))
        r,stop,msgs=make_reader(page,{'801':'2026-10-15','802':'2026-10-15','803':'2026-10-20'})
        snap=r.collect({},self.planner_for([self.target('801'),self.target('802',option='date',due='2026-10-22')]))
        self.assertEqual(page.sent,[{'ids':['801'],'option':'내일'},{'ids':['802'],'option':'2026-10-22'}])
        self.assertEqual({p['itemId']:p['status'] for p in snap['pushes']},{'801':'sent','802':'sent'})
        self.assertEqual(snap['notifiedTotal'],3);self.assertEqual(sorted(e['itemId'] for e in snap['entries']),['801','802','803'])
        self.assertTrue(all(e['noticeSent'] for e in snap['entries']));self.assertEqual([e['noticeDate'] for e in snap['entries'] if e['itemId']=='801'],['2026-10-14'])
        self.assertTrue(snap['complete'] and snap['verified'])
    def test_push_only_sends_without_detail_reads(self):
        page=FakePage(ably_rows(3,sent=('803',)))
        r,stop,msgs=make_reader(page,{'801':'2026-10-15','802':'2026-10-15','803':'2026-10-20'})
        snap=r.push_only(self.planner_for([self.target('801'),self.target('802',option='date',due='2026-10-22')]))
        self.assertEqual(page.sent,[{'ids':['801'],'option':'내일'},{'ids':['802'],'option':'2026-10-22'}])
        self.assertEqual({p['itemId']:p['status'] for p in snap['pushes']},{'801':'sent','802':'sent'})
        self.assertTrue(snap['pushOnly']);self.assertEqual(snap['entries'],[]);self.assertEqual(snap['planned'],2);self.assertEqual(snap['total'],3)
        self.assertFalse(any('예상출고일 확인' in m for m in msgs))
    def test_same_option_rows_share_one_dialog(self):
        page=FakePage(ably_rows(4));r,stop,msgs=make_reader(page,{})
        snap=r.collect({},self.planner_for([self.target('801'),self.target('803'),self.target('804',option='모레',due='2026-10-16')]))
        self.assertEqual([s['ids'] for s in page.sent],[['801','803'],['804']]);self.assertEqual(sum(p['status']=='sent' for p in snap['pushes']),3)
    def test_confirm_box_is_confirmed_once(self):
        page=FakePage(ably_rows(1),confirm_box=True);r,stop,msgs=make_reader(page,{})
        snap=r.collect({},self.planner_for([self.target('801')]))
        self.assertEqual(len(page.sent),1);self.assertEqual(snap['pushes'][0]['status'],'sent');self.assertIsNone(page.box)
    def test_already_sent_or_changed_row_is_never_clicked(self):
        page=FakePage(ably_rows(2,sent=('801',)));r,stop,msgs=make_reader(page,{})
        snap=r.collect({},self.planner_for([self.target('801'),self.target('802',oid='99999')]))
        self.assertEqual(page.sent,[]);self.assertEqual([p['status'] for p in snap['pushes']],['skipped']);self.assertIn('802',snap['pushes'][0]['itemId'])
    def test_no_refresh_after_send_is_reported_failed_and_stops(self):
        page=FakePage(ably_rows(2),refresh=False);r,stop,msgs=make_reader(page,{})
        r.wait=lambda pred,msg,seconds=30,ignore_stop=False:(_ for _ in ()).throw(AblySyncError(msg)) if (seconds==25 and not pred()) else (pred() or (_ for _ in ()).throw(AblySyncError(msg)))
        snap=r.collect({},self.planner_for([self.target('801'),self.target('802',option='모레',due='2026-10-16')]))
        self.assertEqual(len(page.sent),1);self.assertEqual([(p['itemId'],p['status']) for p in snap['pushes']],[('801','failed'),('802','skipped')])
    def test_cancel_after_a_send_raises_abort_with_results(self):
        page=FakePage(ably_rows(2));r,stop,msgs=make_reader(page,{})
        orig=page.apply_send
        def send_then_cancel():orig();stop.set()
        page.apply_send=send_then_cancel
        with self.assertRaises(AblyPushAborted) as ex:r.collect({},self.planner_for([self.target('801'),self.target('802',option='모레',due='2026-10-16')]))
        self.assertEqual([(p['itemId'],p['status']) for p in ex.exception.pushes],[('801','sent'),('802','skipped')]);self.assertEqual(len(page.sent),1)
    def test_without_planner_nothing_is_clicked(self):
        page=FakePage(ably_rows(2));r,stop,msgs=make_reader(page,{})
        snap=r.collect({});self.assertEqual(page.sent,[]);self.assertEqual(snap['pushes'],[]);self.assertEqual(snap['notifiedTotal'],0)

if __name__=='__main__':unittest.main()
