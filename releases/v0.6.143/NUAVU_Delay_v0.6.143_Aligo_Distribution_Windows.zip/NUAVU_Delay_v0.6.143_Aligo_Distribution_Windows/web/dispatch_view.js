/* Read-only domestic-dispatch lookup. No API calls, no stock or notice mutations. */
(function(root){
'use strict';
function validDate(s){
 if(typeof s!=="string"||!/^\d{4}-\d{2}-\d{2}$/.test(s))return false;
 const d=new Date(s+'T00:00:00Z');return Number.isFinite(+d)&&d.toISOString().slice(0,10)===s;
}
function hasDate(r){
 return !!r&&r.active===true&&validDate(r.dispatchStart)&&validDate(r.dispatchEnd)&&r.dispatchStart<=r.dispatchEnd;
}
// A missing dispatch forecast is independent of notice/reservation/due-date state.
// Use the exact complement of hasDate on current orders, never old/inactive rows.
function missingDate(r){return !!r&&r.active===true&&!hasDate(r);}
function missingStats(rows){
 const eligible=rows.filter(missingDate);
 return {count:eligible.length,orders:new Set(eligible.map(r=>JSON.stringify([r.seller,r.orderId]))).size,
  quantity:eligible.reduce((n,r)=>n+(Number.isFinite(Number(r.qty))?Number(r.qty):0),0)};
}
function rangeKey(r){return hasDate(r)?r.dispatchStart+'|'+r.dispatchEnd:'';}
function matches(r,options={}){
 if(!hasDate(r))return false;
 const source=options.source||'all';
 if(!['all','secured','progress'].includes(source))return false;
 if(source==='secured'&&!r.stockSecured||source==='progress'&&r.stockSecured)return false;
 if(options.rangeKey&&rangeKey(r)!==options.rangeKey)return false;
 if(options.day&&(!validDate(options.day)||options.day<r.dispatchStart||options.day>r.dispatchEnd))return false;
 return true;
}
function groups(rows){
 const out=new Map();
 for(const r of rows){
  if(!hasDate(r))continue;
  const key=rangeKey(r);
  if(!out.has(key))out.set(key,{key,start:r.dispatchStart,end:r.dispatchEnd,count:0,quantity:0,secured:0,progress:0,orders:new Set()});
  const g=out.get(key);g.count++;g.quantity+=Number.isFinite(Number(r.qty))?Number(r.qty):0;
  if(r.stockSecured)g.secured++;else g.progress++;
  g.orders.add(JSON.stringify([r.seller,r.orderId]));
 }
 return [...out.values()].sort((a,b)=>a.end.localeCompare(b.end)||a.start.localeCompare(b.start)).map(g=>({...g,orders:g.orders.size}));
}
function stats(rows){
 const eligible=rows.filter(hasDate);return {count:eligible.length,orders:new Set(eligible.map(r=>JSON.stringify([r.seller,r.orderId]))).size,
  quantity:eligible.reduce((n,r)=>n+(Number.isFinite(Number(r.qty))?Number(r.qty):0),0),
  secured:eligible.filter(r=>r.stockSecured).length,progress:eligible.filter(r=>!r.stockSecured).length};
}

// v0.6.13: these are source-stage lookups, not the old date/blank complement.
function officeDates(r,kind='all'){
 if(!r)return [];
 const kinds=kind==='all'?['progress','manifest']:['progress','manifest'].includes(kind)?[kind]:[];
 const dates=kinds.flatMap(k=>Array.isArray(r[k+'OfficeDates'])?r[k+'OfficeDates']:
  (r.supplyInfo?.sources||[]).filter(s=>s.kind===k).map(s=>s.officeDate));
 return [...new Set(dates.filter(validDate))].sort();
}
function planned(r){return !!r&&r.active===true&&officeDates(r).length>0;}
function unconfirmed(r){return !!r&&r.active===true&&!exchange(r)&&!planned(r)&&!r.stockSecured;}
function exchange(r){return !!r&&r.active===true&&String(r.orderId??'').trim().toUpperCase().startsWith('C');}
function manualRecommended(r){
 return !!r&&r.active===true&&!r.soldoutNotified&&!r.review&&!r.stockSecured&&
  r.supplyInfo?.manualRecommended===true&&r.supplyInfo?.matchNeeded===true&&
  Array.isArray(r.supplyInfo.manualRecommendations)&&r.supplyInfo.manualRecommendations.length>0;
}
function delayRisk(r,stage=''){
 const risk=r?.delayRisk;
 return !!r&&r.active===true&&!r.soldoutNotified&&!r.review&&risk?.shortQty>0&&
  ['watch','confirmed'].includes(risk.stage)&&(!stage||risk.stage===stage);
}
function plannedMatches(r,options={}){
 if(!planned(r))return false;
 const source=options.source||'all';
 if(!['all','secured','progress'].includes(source))return false;
 if(source==='secured'&&!r.stockSecured||source==='progress'&&r.stockSecured)return false;
 if(options.rangeKey==='__undated__')return !hasDate(r)&&!options.day;
 if(options.rangeKey||options.day)return matches(r,{day:options.day,rangeKey:options.rangeKey});
 return true;
}
function rowStats(rows){
 return {count:rows.length,orders:new Set(rows.map(r=>JSON.stringify([r.seller,r.orderId]))).size,
  quantity:rows.reduce((n,r)=>n+(Number.isFinite(Number(r.qty))?Number(r.qty):0),0)};
}
function plannedStats(rows){
 const all=rows.filter(planned),dated=all.filter(hasDate);
 return {...rowStats(all),dated:dated.length,undated:all.length-dated.length,
  secured:all.filter(r=>r.stockSecured).length,progress:all.filter(r=>!r.stockSecured).length};
}
// Compare what is displayed: first domestic dispatch day, then last day.
// Empty/invalid intervals ALWAYS last, for either direction. No stock changes.
function compareDispatch(a,b,descending=false){
 const pair=r=>validDate(r?.dispatchStart)&&validDate(r?.dispatchEnd)&&r.dispatchStart<=r.dispatchEnd;
 const av=pair(a),bv=pair(b);
 if(!av&&bv)return 1;if(av&&!bv)return -1;if(!av&&!bv)return 0;
 return (descending?-1:1)*(a.dispatchStart.localeCompare(b.dispatchStart)||a.dispatchEnd.localeCompare(b.dispatchEnd));
}
const api={validDate,hasDate,missingDate,missingStats,rangeKey,matches,groups,stats,
 officeDates,planned,unconfirmed,exchange,manualRecommended,delayRisk,plannedMatches,rowStats,plannedStats,compareDispatch};root.NuavuDispatchView=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);

/* List presentation only: these helpers never allocate stock or send notices. */
(function(root){
'use strict';
const collator=new Intl.Collator('ko-KR',{numeric:true,sensitivity:'base'});
const text=v=>String(v??'').normalize('NFC').trim();
function compareValue(a,b,desc=false){
 const empty=v=>v===null||v===undefined||v==='';
 if(empty(a)||empty(b))return empty(a)===empty(b)?0:empty(a)?1:-1;
 const n=typeof a==='number'&&typeof b==='number'?a-b:collator.compare(text(a),text(b));
 return desc?-n:n;
}
function noticeGroups(rows,isUnconfirmed,isConfirmedRisk){
 const resend=rows.filter(r=>r.active&&(r.bucket==='overdue'||isConfirmedRisk(r)));
 // Partition before search/seller filters, so a hidden sibling cannot move an order.
 // Original IDs stay untouched. Equal displayed order numbers share one category.
 const ids=new Set(resend.map(r=>text(r.orderId)).filter(Boolean));
 const resendKeys=new Set(resend.map(r=>r.key));
 const unknown=rows.filter(r=>isUnconfirmed(r)&&!resendKeys.has(r.key)&&!ids.has(text(r.orderId)));
 return {notice_resend:resend,notice_undated:unknown,
  notice_undated_seen:unknown.filter(r=>Number(r.delayNoticeCount)>0),
  notice_undated_new:unknown.filter(r=>!(Number(r.delayNoticeCount)>0))};
}
function matchValue(r,loaded,recommended){
 const a=r.supplyInfo;
 if(!r.active||!a||!Object.keys(a).length)return null;
 if(!loaded)return 4;
 if(recommended??(r.manualMatchRecommended||a.manualRecommended&&a.matchNeeded&&a.manualRecommendations?.length))return 0;
 if(a.matchNeeded)return 1;
 return a.matchMethod==='manual'?2:3;
}
function orderLabel(r){return (r.isBundle?'(합포) ':'')+(text(r.orderId).toUpperCase().startsWith('C')?'[교환] ':'')+text(r.orderId);}
function compareRows(a,b,mode,view,noticeLabel,loaded){
 const desc=mode.endsWith('_desc')||mode==='newest',kind=mode.replace(/_(asc|desc)$/,'');
 const num=v=>v!==''&&v!==null&&v!==undefined&&Number.isFinite(Number(v))?Number(v):null;
 const date=v=>view.validDate(v)?v:'';
 const values=r=>({seller:[r.sourceSeller||r.seller],ordernumber:[orderLabel(r)],product:[r.product,r.option],option:[r.option,r.product],qty:[num(r.qty)],customer:[r.buyer||r.recipient||'고객님'],phone:[text(r.phone).replace(/\D/g,'')],due:[r.soldoutNotified?'':date(r.dueDate)],notice:[noticeLabel(r)],recent:[r.externalHistory?'':r.lastNoticeAt||''],noticecount:[num(r.noticeCount)],matching:[matchValue(r,loaded,view.manualRecommended?view.manualRecommended(r):r.manualMatchRecommended)],oldest:[date(r.orderDate)],newest:[date(r.orderDate)]}[kind]||[]);
 if(kind==='receipt'){const c=view.compareDispatch(a,b,desc);if(c)return c;}
 else {const av=values(a),bv=values(b);for(let i=0;i<av.length;i++){const c=compareValue(av[i],bv[i],desc);if(c)return c;}}
 return compareValue(a.orderDate,b.orderDate)||compareValue(a.seller,b.seller)||compareValue(a.orderId,b.orderId)||compareValue(a.product,b.product)||compareValue(a.option,b.option)||compareValue(a.key,b.key);
}
function rangeSelection(rows,selected,anchor,key,checked,shift){
 const keys=rows.filter(r=>r.active||r.selectable).map(r=>r.key),end=keys.indexOf(key),start=keys.indexOf(anchor),next=new Set(selected);   // 2026-11-03: 발송실패 필터에서는 목록 제외 행도 체크 가능 (r.selectable)
 if(end<0)return next;
 const range=shift&&start>=0?keys.slice(Math.min(start,end),Math.max(start,end)+1):[key];
 for(const k of range)checked?next.add(k):next.delete(k);
 return next;
}
const api={noticeGroups,compareRows,compareValue,rangeSelection,matchValue};root.NuavuOrderList=api;
if(typeof module!=='undefined'&&module.exports)module.exports.orderList=api;
})(typeof globalThis!=='undefined'?globalThis:this);

/* Dashboard summaries only. Never change source rows or allocation order. */
(function(root){
 'use strict';
 const orderKey=r=>JSON.stringify([r.seller,String(r.orderId||'').normalize('NFC').trim()]);
 const orders=rows=>new Set(rows.map(orderKey)).size;
 function bundleRows(rows){
  const groups=new Map();for(const r of rows){if(!r.active||!String(r.orderId||'').trim())continue;const k=orderKey(r);if(!groups.has(k))groups.set(k,[]);groups.get(k).push(r.key);}
  return new Set([...groups.values()].filter(keys=>new Set(keys).size>1).flat());
 }
 function summary(rows,D,white,noticeGroups){
  const active=rows.filter(r=>r.active),pending=active.filter(white),planned=active.filter(D.planned),bundles=active.filter(r=>r.isBundle);
  const grouped=new Map();for(const r of bundles){const k=orderKey(r);if(!grouped.has(k))grouped.set(k,[]);grouped.get(k).push(r);}
  const readyBundle=orders(bundles.filter(r=>r.bundleReady===true));
  return {whiteDated:pending.filter(D.hasDate).length,whiteUndated:pending.filter(r=>!D.hasDate(r)).length,
   resend:noticeGroups.notice_resend.length,unknown:noticeGroups.notice_undated.length,unknownSeen:noticeGroups.notice_undated_seen?.length||0,unknownNew:noticeGroups.notice_undated_new?.length||0,
   dates:D.groups(planned),waiting:planned.filter(r=>!D.hasDate(r)).length,
   exchanges:active.filter(D.exchange).length,exchangeReady:active.filter(r=>D.exchange(r)&&r.inventoryReady===true).length,
   readySingle:active.filter(r=>!r.isBundle&&r.inventoryReady===true).length,readyBundle,
   partialBundle:[...grouped.values()].filter(group=>!group.some(r=>r.bundleReady===true)&&group.some(r=>r.inventoryReady===true)&&group.some(r=>r.inventoryReady!==true)).length,
   confirmedPlannedBundle:orders(bundles.filter(r=>['confirmed','planned'].includes(r.bundleType))),
   soldout:active.filter(r=>r.noticeBucket==='soldout'||r.bucket==='soldout').length,checkSoldout:active.filter(r=>r.soldoutCheck&&!r.soldoutCheckHidden).length,
   watch:active.filter(r=>D.delayRisk?D.delayRisk(r,'watch'):r.delayRiskStage==='watch').length,
   confirmedRisk:active.filter(r=>D.delayRisk?D.delayRisk(r,'confirmed'):r.delayRiskStage==='confirmed').length};
 }
 const api={orderKey,orders,bundleRows,summary};if(typeof module!=='undefined'&&module.exports)module.exports.dashboard=api;root.NuavuDashboard=api;
})(typeof globalThis!=='undefined'?globalThis:this);
