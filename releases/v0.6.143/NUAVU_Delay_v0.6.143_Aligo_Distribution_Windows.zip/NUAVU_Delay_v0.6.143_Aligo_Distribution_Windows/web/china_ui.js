'use strict';
/* 2026-10-22 22:55 요청: 중국 취소건 카드(전체 · 1차 · 2차 · 3차 · 수량체크) · 주문 행 표시 · 비슷한 취소상품 확인(반짝임 끄고 켜기). */
(()=>{
 const SPARKLE_KEY='nuavu.chinaSparkle';
 let sparkle=true;try{const v=localStorage.getItem(SPARKLE_KEY);if(v!==null)sparkle=v!=='off';}catch(_){}
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const md=iso=>{const m=String(iso||'').match(/^\d{4}-(\d{2})-(\d{2})/);return m?`${+m[1]}/${+m[2]}`:'';};
 function info(r){return r&&r.active===true?r.chinaCancel:null;}
 window.chinaMatches=function(r,key){
  const c=info(r);if(!c)return false;
  if(key==='china_all')return true;
  if(c.match==='similar')return false;
  if(key==='china_qty')return c.kind==='qty';
  const n=Number(key.slice(-1));return c.kind==='cancel'&&c.stage===n;
 };
 window.chinaRowClass=function(r){
  const c=info(r);if(!c)return '';
  const cls=[c.kind==='qty'?'row-china-qty':c.kind==='delay'?'row-china-delay':'row-china-'+Math.max(1,Math.min(3,c.stage||1))];
  if(c.match==='similar'){cls.push('row-china-similar');if(sparkle)cls.push('china-sparkle');}
  return cls.join(' ');
 };
 window.chinaCell=function(r){
  const c=info(r);if(!c)return '';
  const where=`${c.brand||''} 취소건${c.file?.match(/\((\d{4})\)/)?'('+c.file.match(/\((\d{4})\)/)[1]+')':''} ${c.line?c.line+'행':''}`.trim();
  const re=c.reorder&&c.reorder.length?`<span class="china-reorder">재발주 확인: 진행상황 ${esc(c.reorder[0].file)} ${esc(c.reorder[0].line)}행 · ${esc(md(c.reorder[0].purchaseDate))} 주문</span>`:(c.kind==='cancel'?'<span class="china-reorder muted">재발주 아직 확인 안 됨 (진행상황에 더 늦은 같은 상품·옵션 주문 없음)</span>':'');
  const head=c.match==='similar'
   ?`<b class="china-tag china-tag-similar">매칭 가능한 비슷한 취소상품 발견</b>`
   :`<b class="china-tag china-tag-${c.kind==='cancel'?'s'+Math.max(1,c.stage):c.kind}">${esc(c.label)}</b>`;
  const ask=c.match==='similar'?`<span class="china-ask">취소 상품: <b>${esc(c.product)} / ${esc(c.color||'-')} / ${esc(c.size||'-')}</b> · 같은 상품인가요? <button class="tiny china-decide" data-key="${esc(r.key)}" data-item="${esc(c.itemId)}" data-decision="match">같은 상품 · 매칭</button><button class="tiny china-decide" data-key="${esc(r.key)}" data-item="${esc(c.itemId)}" data-decision="reject" title="다른 상품이거나 재입고가 필요 없는데 잘못 적은 발주(오발주). 같은 상품명의 다른 취소 항목에도 다시 묻지 않습니다.">다른 상품/오발주</button></span>`:`<span class="china-ask"><button class="tiny china-decide" data-key="${esc(r.key)}" data-item="${esc(c.itemId)}" data-decision="reject" title="재입고가 필요 없는데 잘못 적은 발주(오발주)이거나 다른 상품. 이 주문의 취소건 표시를 지우고 흰 행으로 돌립니다.">다른 상품/오발주</button></span>`;
  const how={manual:'수동매칭 기준 연결',auto:'자동매칭',confirmed:'사장님 확인 매칭',similar:'상품명만 같음'}[c.match]||'';
  return `<span class="china-cell">${head}<span class="china-why">사유 · ${esc(c.reasonKind||'')}: ${esc(c.reason||'')}</span>`+
   `<span class="china-src">발견 · ${esc(where)} · 주문번호 ${esc(c.code)}${c.orderDate?' ('+esc(md(c.orderDate))+' 주문)':''}${c.foundOn?' · '+esc(md(c.foundOn))+' 초록행':''}${how?' · '+how:''}</span>`+
   (c.events&&c.events.length>1?`<span class="china-src">취소 이력 · ${c.events.map(e=>esc(md(e.foundOn)+' '+e.code)).join(' → ')}</span>`:'')+re+ask+'</span>';
 };
 function summary(){
  const el=document.getElementById('chinaSummary');if(!el||!state?.rows)return;
  const rows=state.rows.filter(r=>info(r));const n=k=>rows.filter(r=>chinaMatches(r,k)).length;
  const sim=rows.filter(r=>r.chinaCancel.match==='similar').length;
  const parts=['1차 '+n('china_1')+'건','2차 '+n('china_2')+'건','3차 '+n('china_3')+'건','수량체크 '+n('china_qty')+'건'];
  if(sim)parts.push('확인 필요 '+sim+'건');
  el.innerHTML=parts.map(s=>'<span>'+esc(s)+'</span>').join('<i aria-hidden="true"> / </i>');
 }
 function toolbar(){
  const panel=document.getElementById('sectionGroupPanel');if(!panel)return;
  const status=document.getElementById('statusFilter')?.value||'';let bar=document.getElementById('chinaToolbar');
  if(!status.startsWith('china_')){if(bar)bar.hidden=true;return;}
  if(!bar){panel.insertAdjacentHTML('beforeend','<div id="chinaToolbar" class="china-toolbar"><span id="chinaFolderState" class="sub"></span><button id="chinaPickFolder" class="tiny">취소건 폴더 연결</button><button id="chinaRescan" class="tiny">지금 다시 읽기</button><button id="chinaSparkleToggle" class="tiny"></button></div>');bar=document.getElementById('chinaToolbar');wire();}
  bar.hidden=false;
  const v=state?.chinaCancel||{},scan=v.lastScan||{};
  document.getElementById('chinaFolderState').textContent=scan.error?scan.error:(scan.folder?`폴더 · ${scan.folder} · 파일 ${(scan.files||[]).length}개 · 기록된 취소 ${v.events||0}건${scan.at?' · 마지막 확인 '+(typeof dateTime==='function'?dateTime(scan.at):scan.at):''}`:'취소건 폴더를 확인하는 중입니다.');
  document.getElementById('chinaSparkleToggle').textContent='비슷한 취소상품 반짝임 · '+(sparkle?'켜짐':'꺼짐');
  document.getElementById('chinaPickFolder').hidden=!window.pywebview?.api?.pick_china_cancel_folder;
 }
 function wire(){
  document.getElementById('chinaSparkleToggle').onclick=()=>{sparkle=!sparkle;try{localStorage.setItem(SPARKLE_KEY,sparkle?'on':'off');}catch(_){}if(typeof render==='function')render();};
  document.getElementById('chinaRescan').onclick=e=>action(async()=>{const r=await api('china-cancel',{action:'scan'});toast(r.message);},e.currentTarget);
  document.getElementById('chinaPickFolder').onclick=e=>action(async()=>{const r=await window.pywebview.api.pick_china_cancel_folder(token);if(!r)return;if(r.error)throw Error(r.error);toast(r.message);},e.currentTarget);
 }
 document.addEventListener('click',e=>{
  const b=e.target.closest('.china-decide');if(!b)return;
  const d=b.dataset.decision;if(d==='reject'&&!confirm('이 주문은 그 취소 상품과 다른 상품(또는 오발주)으로 표시합니다. 취소건 표시를 지우고 이 주문에는 다시 묻지 않습니다.'))return;
  action(async()=>{const r=await api('china-cancel',{action:'decide',rowKey:b.dataset.key,itemId:b.dataset.item,decision:d});toast(r.message);},b);
 });
 if(typeof renderSectionGroups==='function'){const orig=renderSectionGroups;renderSectionGroups=function(){const out=orig.apply(this,arguments);try{summary();toolbar();}catch(_){}return out;};}
})();
