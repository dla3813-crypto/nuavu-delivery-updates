'use strict';
// 2026-11-03 요청: 발송실패 배지에 계속 남는 건을 사장님이 선택해서 지울 수 있게 — 발송실패 필터에서 체크 → "선택 발송실패 표시 지우기".
// 문자 이력·결과는 그대로 두고 발송실패 분류(빨간 배지·발송실패 색)에서만 뺀다. 목록 제외(출고된) 주문도 이 필터에서는 체크할 수 있다.
function renderFailedDismiss(){
 const b=document.getElementById('dismissFailedBtn');if(!b||!state)return;
 const scope=document.getElementById('statusFilter').value==='failed';
 b.hidden=!scope;
 b.disabled=!scope||!state.rows.some(r=>selected.has(r.key)&&r.color==='failed'&&r.failedNoticeId);
}
document.getElementById('dismissFailedBtn')?.addEventListener('click',()=>action(async()=>{
 const keys=state.rows.filter(r=>selected.has(r.key)&&r.color==='failed'&&r.failedNoticeId).map(r=>r.key);
 if(!keys.length)throw Error('발송실패 표시가 있는 상품을 선택하세요.');
 if(!confirm(`선택한 ${keys.length}개 상품의 발송실패 표시를 지울까요?\n문자 이력과 결과는 그대로 남고, 발송실패 배지와 분류에서만 빠집니다. 다시 보내지는 않습니다.`))return;
 const r=await api('failures-dismiss',{keys});
 toast(r.message);selected.clear();
},document.getElementById('dismissFailedBtn')));
