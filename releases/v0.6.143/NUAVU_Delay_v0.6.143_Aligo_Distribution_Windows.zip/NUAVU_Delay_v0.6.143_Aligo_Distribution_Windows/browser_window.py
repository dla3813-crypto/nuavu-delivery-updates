"""Automation Chrome visibility.

Setting: settings['headlessChrome'] (default off). Headless Chrome has no window at all, so
anything that needs a person in the browser (extra authentication after login, "로그인 확인 후
이어가기") cannot happen; drivers call need_person() at those points and fail with a clear
message instead of waiting. The earlier "minimize" mode is kept only as inert helpers.
"""
import threading,weakref

ENABLED=False    # minimize mode (no longer offered in settings; kept for compatibility)
HEADLESS=False
HEADLESS_MESSAGE='헤드리스 모드에서는 로그인 확인·추가 인증 창을 보여줄 수 없습니다. ⚙ 설정 › 자동화 설정에서 "Chrome 헤드리스"를 끄고 다시 실행하세요.'
_lock=threading.Lock()
_contexts=weakref.WeakSet()   # attached Playwright contexts
_attention=weakref.WeakSet()  # contexts whose window must stay visible

def configure(enabled=False,headless=False):
    global ENABLED,HEADLESS
    ENABLED=bool(enabled);HEADLESS=bool(headless)

_forced=[0]   # >0 while a run was reopened with a visible window (e.g. 이지어드민 캡차)
from contextlib import contextmanager
@contextmanager
def headed():
    with _lock:_forced[0]+=1
    try:yield
    finally:
        with _lock:_forced[0]-=1
def headless():return HEADLESS and not _forced[0]
def launch_kwargs():
    """Playwright launch options for every automation Chrome (Ably, EzAdmin, carriers)."""
    return {'channel':'chrome','headless':HEADLESS,'chromium_sandbox':True}
# 2026-11-01: 이지어드민 주문 불러오기를 사장님 메인 Chrome(이미 로그인된 세션)에서 — main_chrome.py (Mac)
MAIN_CHROME=False
def configure_main_chrome(enabled=False):
    global MAIN_CHROME
    MAIN_CHROME=bool(enabled)
def ezadmin_engine():return 'main' if MAIN_CHROME else 'chrome'
def need_person():
    """Message to fail with when a person would have to act inside the browser but it has no window."""
    return HEADLESS_MESSAGE if headless() else ''

def _bounds(page,state):
    session=page.context.new_cdp_session(page)
    try:
        window=session.send('Browser.getWindowForTarget')
        session.send('Browser.setWindowBounds',{'windowId':window['windowId'],'bounds':{'windowState':state}})
    finally:
        try:session.detach()
        except Exception:pass

def minimize(page):
    try:_bounds(page,'minimized')
    except Exception:pass

def restore(page):
    try:_bounds(page,'normal')
    except Exception:pass
    try:page.bring_to_front()
    except Exception:pass

def attach(context):
    """Minimize every window of this context now and as new pages/popups open (when enabled)."""
    if not ENABLED:return False
    with _lock:_contexts.add(context)
    def on_page(page):
        if context in _attention:return
        minimize(page)
    context.on('page',on_page)
    for page in context.pages:
        if not page.is_closed():minimize(page)
    return True

def reminimize(page):
    """After bring_to_front() in a navigation: hide again unless the person is needed."""
    try:
        context=page.context
        if ENABLED and context in _contexts and context not in _attention:minimize(page)
    except Exception:pass

def attention():
    """A person must look at the browser (login wait, confirmation, extra auth): show every window."""
    if headless():return
    with _lock:contexts=list(_contexts)
    for context in contexts:
        _attention.add(context)
        try:
            for page in context.pages:
                if not page.is_closed():restore(page)
        except Exception:pass

def calm():
    """The person's part is done: hide the automation windows again."""
    with _lock:contexts=list(_contexts)
    for context in contexts:
        _attention.discard(context)
        if not ENABLED:continue
        try:
            for page in context.pages:
                if not page.is_closed():minimize(page)
        except Exception:pass
