"""2026-11-01 요청: "파이어폭스 안되네 내 메인 크롬 작동해서 써라"

이지어드민 주문 불러오기를 사장님이 평소 쓰는 Google Chrome(메인 프로필)에서 실행한다 (Mac 전용).
 · 메인 Chrome 에 이미 로그인된 이지어드민 세션을 그대로 쓴다. 이 모드는 비밀번호를 입력하지 않는다.
   로그인이 풀려 있으면 멈추고 "Chrome 에서 로그인해 주세요"라고 알린다.
 · Chrome 은 AppleScript 로 움직인다 (Playwright 는 Chrome 136 부터 기본 프로필에 붙을 수 없음).
   처음 한 번: Chrome 메뉴 보기 › 개발자 정보 › 'Apple Events의 JavaScript 허용' 켜기 +
   macOS 가 묻는 "Google Chrome 제어" 허용.
 · 순서·확인 조건은 Playwright 판(order_browser.Flow)과 같다: 확장주문검색(DS00) 조건 설정 → 판매처 그룹 →
   조회 → 엑셀 신청(안내 2개 · '확인했습니다' · 접수 확인) → 다운로드관리자(BL30)에서 신청시각이 맞는 1건만 →
   그 파일을 받아 다운로드 폴더에 저장. 캡차가 나오면 사장님이 메인 Chrome 탭에서 직접 처리.
 · 사이트 알림창(alert/confirm)은 이 앱이 연 탭에서만 기록하고 '취소'로 닫는다 (Playwright 기본 동작과 같음).
 · 작업이 끝나면 앱이 연 탭만 닫는다. 사장님이 열어 둔 탭은 건드리지 않는다."""
import base64,json,re,subprocess,sys,time
from datetime import datetime
from urllib.parse import urlsplit
from order_auto import (AmbiguousJob,AMBIGUOUS_RETRY_TIMES,AMBIGUOUS_RETRY_WAIT,OrderAutoError,Cancelled,KST,requested_job,window_text,checked_request_name,checked_link,
                        persist_download,MAX_BYTES)
import order_browser as ob

POLL=.5
CALL_SECONDS=45
# 2026-11-02 12:49 "메인 Chrome 창이 없습니다"(Chrome 은 열려 있음): Google Chrome 이 2개 떠 있었다 (pid 2개 —
# 메인 Chrome + 다른 자동화가 띄운 자동화용 Chrome). 이름("Google Chrome")으로 부르면 macOS 가 엉뚱한 쪽으로 보낸다.
# → JXA 로 바꾸고 메인 Chrome 의 프로세스 번호(pid)로 직접 부른다 (Apple JXA: Application(프로세스 ID)).
SCRIPT=r'''function run(argv){
  var C=Application(parseInt(argv[0],10));var cmd=argv[1];
  function find(tid){var ws=C.windows;var n=ws.length;for(var i=0;i<n;i++){var w=ws[i];var ids=w.tabs.id().map(String);var k=ids.indexOf(tid);if(k>=0)return w.tabs[k];}return null;}
  if(cmd==='open'){
    var u=argv[2],pref=argv[3],skip=argv[4];var ws=C.windows;var n=ws.length;var best=null,bestScore=-1;
    for(var i=0;i<n;i++){var w=ws[i];if(w.mode()!=='normal')continue;var wid=String(w.id());if(skip.indexOf(','+wid+',')>=0)continue;
      var urls=w.tabs.url();var score=urls.length;for(var j=0;j<urls.length;j++)if(String(urls[j]).indexOf('ezadmin.co.kr')>=0)score+=1000;
      if(wid===pref)score+=100000;if(score>bestScore){best=w;bestScore=score;}}
    if(!best)return 'none';
    best.tabs.push(C.Tab({url:u}));var ids=best.tabs.id();
    return String(ids[ids.length-1])+' '+String(best.id());
  }
  if(cmd==='find'){var out=[];var ws=C.windows;var n=ws.length;
    for(var i=0;i<n;i++){var w=ws[i];var ids=w.tabs.id(),urls=w.tabs.url();for(var j=0;j<ids.length;j++)if(String(urls[j]).indexOf(argv[2])>=0)out.push(String(ids[j]));}
    return out.join('\n');}
  if(cmd==='windows'){return String(C.windows.length);}
  var tid=String(argv[2]);var t=find(tid);   // 탭 id 는 Chrome 이 글자(text)로 줄 수 있음 → 글자로 비교
  if(cmd==='info'){if(!t)return 'gone';return (t.loading()?'true':'false')+'\n'+t.url();}
  if(cmd==='close'){if(!t)return 'gone';t.close();return 'closed';}
  if(!t)throw new Error('NUAVU_TAB_GONE');
  if(cmd==='js'){var r=t.execute({javascript:argv[3]});return r===undefined||r===null?'':String(r);}
  throw new Error('unknown command');
}'''
CHROME_BIN=re.compile(r'/Google Chrome\.app/Contents/MacOS/Google Chrome(\s|$)')
AUTOMATION_FLAGS=('--remote-debugging-pipe','--remote-debugging-port','--headless','--enable-automation','playwright')
def main_chrome_pid(run=subprocess.run):
    """메인 Chrome(사장님이 쓰는 Chrome)의 프로세스 번호. 자동화가 띄운 Chrome(원격 디버깅·헤드리스·playwright 프로필)은 뺀다."""
    try:r=run(['/bin/ps','-axww','-o','pid=,command='],capture_output=True,text=True,timeout=10)
    except Exception:raise OrderAutoError('실행 중인 Chrome을 확인하지 못했습니다.') from None
    main=[];other=0
    for line in (r.stdout or '').splitlines():
        pid,_,cmd=line.strip().partition(' ')
        if not pid.isdigit() or not CHROME_BIN.search(cmd):continue
        if any(f in cmd for f in AUTOMATION_FLAGS):other+=1;continue
        main.append((('--user-data-dir' in cmd),int(pid)))
    if not main:
        raise OrderAutoError('메인 Google Chrome이 켜져 있지 않습니다. Chrome을 열고(이지어드민 로그인) 다시 실행하세요.'+(' (자동화용 Chrome만 떠 있습니다)' if other else ''))
    return sorted(main)[0][1]   # 기본 프로필(--user-data-dir 없음) 우선

JS_OFF_MESSAGE=('메인 Chrome에서 "Apple Events의 JavaScript 허용"이 꺼져 있습니다. Chrome 메뉴 › 보기 › 개발자 정보 › '
                '"Apple Events의 JavaScript 허용"을 한 번 켠 뒤 다시 실행하세요.')
PERMISSION_MESSAGE=('누아브 앱이 Google Chrome을 제어하도록 허용되지 않았습니다. 시스템 설정 › 개인정보 보호 및 보안 › 자동화에서 '
                    '누아브(또는 Python) 아래 Google Chrome을 켜고 다시 실행하세요.')
LOGGED_OUT_MESSAGE=('메인 Chrome의 이지어드민 로그인이 풀려 있습니다. Chrome에서 이지어드민에 직접 로그인한 뒤 다시 실행하세요. '
                    '(메인 Chrome 모드는 비밀번호를 입력하지 않습니다)')

class TabGone(OrderAutoError):pass

def explain(stderr):
    s=str(stderr or '')
    if 'NUAVU_TAB_GONE' in s:return 'TAB_GONE'
    if '-1743' in s or 'Not authorized' in s or '권한' in s:return PERMISSION_MESSAGE
    if ('JavaScript' in s or '자바스크립트' in s) and ('Apple' in s or 'turned off' in s or '꺼' in s):return JS_OFF_MESSAGE
    if '-600' in s or '-609' in s or "isn't running" in s:return 'Google Chrome이 응답하지 않습니다. Chrome을 켜 두고 다시 실행하세요.'
    return 'Chrome 제어 중 오류가 났습니다: '+re.sub(r'\s+',' ',s)[:160]

def osa(*args,timeout=CALL_SECONDS,run=subprocess.run,pid=None):
    if sys.platform!='darwin':raise OrderAutoError('메인 Chrome 모드는 Mac에서만 쓸 수 있습니다.')
    pid=pid or main_chrome_pid(run)
    try:r=run(['/usr/bin/osascript','-l','JavaScript','-',str(pid),*[str(a) for a in args]],input=SCRIPT,capture_output=True,text=True,timeout=timeout)
    except subprocess.TimeoutExpired:
        raise OrderAutoError('메인 Chrome이 45초 동안 응답하지 않았습니다. Chrome에 사이트 알림창이나 확인창이 떠 있으면 닫고 다시 실행하세요.') from None
    if r.returncode!=0:
        m=explain(r.stderr)
        if m=='TAB_GONE':raise TabGone('앱이 연 Chrome 탭이 닫혔습니다.')
        raise OrderAutoError(m)
    return r.stdout.rstrip('\n')

# 모든 페이지 코드는 문자열 하나를 돌려준다. 알림창은 기록만 하고 닫는다(취소).
PRELUDE=r'''(function(ARGS){try{
var N=window.__nuavu||(window.__nuavu={dialogs:[]});
if(!N.hooked){N.hooked=true;
 window.alert=function(m){N.dialogs.push('alert:'+String(m).slice(0,300));};
 window.confirm=function(m){N.dialogs.push('confirm:'+String(m).slice(0,300));return false;};
 window.prompt=function(m){N.dialogs.push('prompt:'+String(m).slice(0,300));return null;};}
var docs=function(){var out=[document];var fs=document.querySelectorAll('iframe,frame');for(var i=0;i<fs.length;i++){try{var d=fs[i].contentDocument;if(d&&d.location&&d.location.hostname===location.hostname)out.push(d);}catch(e){}}return out;};
var vis=function(e){if(!e)return false;var r=e.getBoundingClientRect();var cs=(e.ownerDocument.defaultView||window).getComputedStyle(e);return r.width>0&&r.height>0&&cs.visibility!=='hidden'&&cs.display!=='none';};
var q=function(s){return document.querySelector(s);};
var fire=function(e){e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));};
var later=function(e){setTimeout(function(){e.click();},0);};
var txt=function(e){return (e&&(e.innerText||e.textContent)||'').trim();};
var R=(BODY)(ARGS);
return JSON.stringify({ok:true,v:R===undefined?null:R,d:N.dialogs.slice(-5)});
}catch(err){return JSON.stringify({ok:false,e:String(err&&err.message||err).slice(0,300)});}})(ARGS_JSON)'''

def page_code(body,args=None):
    return PRELUDE.replace('(BODY)','('+body+')').replace('ARGS_JSON',json.dumps(args if args is not None else None,ensure_ascii=False))

# ---- 페이지별 코드 (Playwright 판과 같은 선택자·조건)
LOGIN_STATE_JS='''function(host){var u=location;if(u.protocol!=='https:')return 'other';
 if(/^login\\d*\\.ezadmin\\.co\\.kr$/.test(u.hostname))return 'login';
 if(u.hostname!==host)return 'other';
 var d=docs();for(var i=0;i<d.length;i++){var ls=d[i].querySelectorAll('a[href*="logout.php"]');for(var j=0;j<ls.length;j++)if(vis(ls[j]))return 'in';}
 return 'unknown';}'''
VISIBLE_JS='''function(sel){return vis(q(sel));}'''
BODY_HAS_JS='''function(t){return (document.body&&document.body.innerText||'').toLowerCase().indexOf(t)>=0;}'''
SET_SEARCH_JS='''function(a){
 var pick=function(sel,label){var e=q(sel);if(!e)throw Error('없는 항목: '+sel);var o=[].find.call(e.options,function(x){return x.text.trim()===label;});if(!o)throw Error('선택지 없음: '+label);e.value=o.value;fire(e);};
 var val=function(sel,v){var e=q(sel);if(!e)return;var o=[].find.call(e.options,function(x){return x.value===v;});if(o){e.value=v;fire(e);}};
 pick('select[name="date_type"]','발주일');pick('#date_period_sel','최근한달');pick('select[name="status_sel"]','접수+송장');pick('select[name="order_cs_sel"]','정상+교환');
 var p=q('#is_packed');if(p&&p.checked)p.click();
 [['#str_supply_code','0'],['select[name="pack_sel"]','0'],['select[name="check_set_match"]','0'],['select[name="work_type"]','0'],['#trans_corp','99']].forEach(function(x){val(x[0],x[1]);});
 var s=q('input[name="table_search_row_query_str"]');if(s){s.value='';fire(s);}
 return true;}'''
# 판매처 그룹: 사이트 팝업(window.open)은 스크립트로 열면 팝업 차단에 걸린다 → 같은 팝업 주소를 앱 탭으로 열어 그룹 번호(group_id)만 읽고,
# 사이트의 set_shop_group() 과 같은 값을 주문검색 화면에 넣는다 (#multi_shop='' · #multi_shop_group=번호 · 판매처 '상세선택').
SEARCH_PATH='/template35.htm?template=DS00'
DOWNLOAD_PATH='/template40.htm?template=BL30'
GROUP_PATH='/popup25.htm?template=C120'
ADMIN_RE=re.compile(r'ga\d+\.ezadmin\.co\.kr')
NO_ADMIN_MESSAGE=('메인 Chrome에서 이지어드민 관리자 화면을 찾지 못했습니다. Chrome에서 이지어드민에 로그인하고 관리자 화면 탭을 하나 열어 둔 뒤 '
                  '다시 실행하세요. (메인 Chrome 모드는 비밀번호를 입력하지 않습니다)')
GROUP_ID_JS='''function(g){var cs=[].slice.call(document.querySelectorAll('input.chk_group'));if(!cs.length)return {state:'wait'};
 var hit=cs.filter(function(c){var li=c.closest('li')||c.parentElement;return txt(li)===g;});
 if(hit.length!==1)return {state:'nogroup'};var id=hit[0].getAttribute('group_id')||'';if(!/^[0-9A-Za-z_,-]+$/.test(id))return {state:'noid'};return {state:'ok',id:id};}'''
APPLY_GROUP_JS='''function(id){var ms=q('#multi_shop'),mg=q('#multi_shop_group'),all=q('#str_shop_code > option#shop_code_all');
 if(!ms||!mg||!all)return 'missing';ms.value='';mg.value=id;all.textContent='상세선택';all.selected=true;
 var sp=q('#s2id_str_shop_code .select2-choice span');if(sp)sp.textContent='상세선택';return mg.value===id?'ok':'fail';}'''
SHOP_SELECTED_JS='''function(){var o=document.querySelector('#str_shop_code option:checked');return o?o.text.trim():'';}'''
CLICK_JS='''function(sel){var e=q(sel);if(!e)throw Error('없는 버튼: '+sel);later(e);return true;}'''
GRID_JS='''function(){var load=q('#load_grid1');var rows=document.querySelectorAll('#grid1 tr.jqgrow').length;var pager=txt(q('#gridpager'));
 return {loading:vis(load),rows:rows,empty:pager.indexOf('표시할 행이 없습니다')>=0};}'''
SET_DOWNLOAD_JS='''function(){
 var pick=function(sel,label){var e=q(sel);if(!e)throw Error('없는 항목: '+sel);var o=[].find.call(e.options,function(x){return x.text.trim()===label;});if(!o)throw Error('선택지 없음: '+label);e.value=o.value;fire(e);};
 pick('#download_type','상품단위');pick('#download_field','배송지연 전체품목');var s=q('#include_sum');if(s&&!s.checked)s.click();return true;}'''
CHECKED_LABELS_JS='''function(list){return list.map(function(x){var o=document.querySelector(x+' option:checked');return o?o.text.trim():'';});}'''
# 다운로드 안내창: 이미지 팝업(배경 이미지 경로 확인) 또는 같은 제목의 대화상자 안 버튼. 여러 개면 멈춤.
NOTICE_JS='''function(a){var found=[];
 docs().forEach(function(d){
  [].forEach.call(d.querySelectorAll(a.sel),function(p){if(!vis(p))return;var bg=(d.defaultView||window).getComputedStyle(p).backgroundImage||'';
   var m=bg.match(/^url\\(["']?(.*?)["']?\\)$/);if(!m)return;var u;try{u=new URL(m[1],location.href);}catch(e){return;}
   if(u.protocol==='https:'&&u.hostname===location.hostname&&u.pathname===a.img){var b=p.querySelector(a.button);if(b&&vis(b)&&!b.disabled)found.push(b);}});
  [].forEach.call(d.querySelectorAll('[role=dialog],dialog'),function(g){if(!vis(g)||txt(g).indexOf(a.title)<0)return;
   var bs=[].filter.call(g.querySelectorAll('button,[role=button]'),function(b){return txt(b)===a.text&&vis(b)&&!b.disabled;});if(bs.length===1)found.push(bs[0]);});});
 if(found.length>1)return 'many';if(!found.length)return 'none';if(a.click)later(found[0]);return 'found';}'''
ACK_JS='''function(a){var hits=[];
 docs().forEach(function(d){[].forEach.call(d.querySelectorAll('[role=dialog],dialog'),function(g){if(!vis(g)||txt(g).indexOf('다운로드 안내')<0)return;
  var box=g.querySelector('input#swal2-input');var ok=[].filter.call(g.querySelectorAll('button'),function(b){return txt(b)==='확인'&&vis(b)&&!b.disabled;});
  if(box&&vis(box)&&!box.disabled&&ok.length===1)hits.push([box,ok[0]]);});});
 if(hits.length>1)return 'many';if(!hits.length)return 'none';var box=hits[0][0],ok=hits[0][1];
 if(a.mode==='fill'){box.focus();var set=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;set.call(box,a.value);fire(box);box.blur();return box.value;}
 if(a.mode==='check')return box.value;
 if(a.mode==='confirm'){if(box.value!==a.value)return 'changed';later(ok);return 'clicked';}
 return 'found';}'''
RECEIPT_JS='''function(){var hit=false;
 docs().forEach(function(d){[].forEach.call(d.querySelectorAll('#pop_download_complete'),function(p){if(!vis(p))return;var bg=(d.defaultView||window).getComputedStyle(p).backgroundImage||'';if(bg.indexOf('/images/download_info_complete.png')>=0)hit=true;});
  [].forEach.call(d.querySelectorAll('[role=dialog],dialog'),function(g){if(vis(g)&&txt(g).indexOf('요청하신 다운로드 작업이 접수되었습니다.')>=0)hit=true;});});
 return hit;}'''
ROWS_PAGE_JS='function(){return ('+ob.ROWS_JS+')([].slice.call(document.querySelectorAll("#grid1 tr.jqgrow")));}'
FETCH_START_JS='''function(a){window.__nuavuDl={state:'run'};
 fetch(a.href,{credentials:'include'}).then(function(r){if(!r.ok)throw Error('HTTP '+r.status);return r.arrayBuffer();}).then(function(buf){
  if(buf.byteLength>a.max){window.__nuavuDl={state:'error',e:'too big'};return;}
  var b=new Uint8Array(buf),s='',step=0x8000;for(var i=0;i<b.length;i+=step)s+=String.fromCharCode.apply(null,b.subarray(i,i+step));
  window.__nuavuDl={state:'done',b64:btoa(s),size:b.length};}).catch(function(e){window.__nuavuDl={state:'error',e:String(e&&e.message||e).slice(0,200)};});
 return true;}'''
FETCH_STATE_JS='''function(){var d=window.__nuavuDl||{state:'none'};return {state:d.state,size:d.size||0,len:d.b64?d.b64.length:0,e:d.e||''};}'''
FETCH_CHUNK_JS='''function(a){var d=window.__nuavuDl;return d&&d.b64?d.b64.slice(a.at,a.at+a.n):'';}'''
FETCH_CLEAR_JS='''function(){window.__nuavuDl=null;return true;}'''

class BytesDownload:
    """persist_download 이 쓰는 Download 모양 (save_as · failure)."""
    def __init__(self,data):self.data=data
    def save_as(self,path):
        with open(path,'wb') as f:f.write(self.data)
    def failure(self):return None

class MainChromeFlow:
    def __init__(self,controller,osa_call=None,clock=None,sleep=None):
        self.c=controller;self.osa=osa_call or osa;self.clock=clock or time.monotonic;self.sleep=sleep or time.sleep
        self.step='메인 Chrome 연결';self.tabs=[];self.page=None;self.dialogs=[]
        self.export_requested=False;self.export_acknowledged=False;self.export_accepted=False
    # ---- 기본 동작
    def js(self,tab,body,args=None):
        raw=self.osa('js',tab,page_code(body,args))
        try:r=json.loads(raw)
        except ValueError:raise OrderAutoError('메인 Chrome 응답을 읽지 못했습니다. Chrome 탭을 확인하세요.')
        self.dialogs=r.get('d') or self.dialogs
        if not r.get('ok'):raise OrderAutoError('메인 Chrome 화면 처리 오류: '+str(r.get('e'))[:200])
        return r.get('v')
    def pause(self,seconds):
        end=self.clock()+seconds
        while True:
            self.c.check()
            left=end-self.clock()
            if left<=0:return
            self.sleep(min(POLL,left))
    def until(self,pred,timeout,message):
        end=self.clock()+timeout
        while True:
            self.c.check()
            v=pred()
            if v:return v
            if self.clock()>end:
                note=(' 사이트 안내: '+' / '.join(self.dialogs[-2:])) if self.dialogs else ''
                raise ob.StepTimeout(message+note)
            self.sleep(POLL)
    def info(self,tab):
        raw=self.osa('info',tab)
        if raw=='gone':return None
        loading,_,url=raw.partition('\n');return loading.strip()=='true',url.strip()
    def open(self,url):
        skip=set()
        while True:
            raw=self.osa('open',url,getattr(self,'window','') or '-',','+','.join(sorted(skip))+',').strip()
            if raw=='none':
                if skip:raise OrderAutoError(JS_OFF_MESSAGE+' (Chrome 프로필마다 따로 켜야 합니다 · 이지어드민에 로그인된 프로필에서 켜 주세요)')
                raise OrderAutoError('메인 Chrome 창이 없습니다. Chrome 창을 하나 열어 두고 다시 실행하세요.')
            tab,_,win=raw.partition(' ')
            if not tab.isdigit():raise OrderAutoError('메인 Chrome에 새 탭을 열지 못했습니다.')
            self.tabs.append(tab);self.page=tab
            last=['확인 전']
            def loaded():
                i=self.info(tab);last[0]='앱이 연 탭을 찾지 못함' if i is None else ('로딩 중' if i[0] else '열림')
                return i is not None and not i[0]
            try:self.until(loaded,30,'메인 Chrome 탭이 30초 안에 열리지 않았습니다.')
            except ob.StepTimeout:raise ob.StepTimeout(f'메인 Chrome 탭이 30초 안에 열리지 않았습니다 (마지막 상태: {last[0]} · 창 {win or "?"} · 탭 {tab}).') from None
            try:self.osa('js',tab,'"ok"')
            except OrderAutoError as exc:
                if str(exc)!=JS_OFF_MESSAGE or not win:raise
                # 이 창의 프로필은 허용이 꺼져 있음 → 그 탭을 닫고 다른 창(프로필)에서 다시
                try:self.osa('close',tab)
                except Exception:pass
                self.tabs.remove(tab);skip.add(win);continue
            self.window=win
            return tab
    def close_tabs(self):
        for tab in self.tabs:
            try:self.osa('close',tab)
            except Exception:pass
        self.tabs=[]
    def location(self,tab):
        try:i=self.info(tab)
        except Exception:return '확인할 수 없음'
        return ob.safe_location(i[1]) if i else '닫힌 탭'
    def failure_message(self,exc):
        if isinstance(exc,OrderAutoError):reason=str(exc)
        elif isinstance(exc,TimeoutError):reason='화면 응답을 기다리다 시간이 초과되었습니다.'
        else:reason='메인 Chrome 처리 중 문제가 발생했습니다.'
        where=self.location(self.page) if self.page else '탭 열기 전'
        return f'[메인 Chrome] {self.step} 단계에서 중단했습니다. {reason}\n현재 화면: {where}'
    # ---- 관리자 서버: 메인 Chrome 에 열려 있는 이지어드민 탭(ga숫자.ezadmin.co.kr)에서 찾는다 (배포판은 업체마다 다름)
    def admin(self):
        if getattr(self,'admin_host',None):return self.admin_host
        self.step='이지어드민 서버 확인';seen={}
        for tab in [x for x in self.osa('find','ezadmin.co.kr').split() if x.isdigit()]:
            try:i=self.info(tab)
            except OrderAutoError:continue
            if not i:continue
            u=urlsplit(i[1])
            if u.scheme=='https' and ADMIN_RE.fullmatch(u.hostname or '') and not u.path.startswith('/data/'):seen[u.hostname]=seen.get(u.hostname,0)+1
        if len(seen)>1:raise OrderAutoError('메인 Chrome에 서로 다른 이지어드민 서버 탭이 열려 있어 어느 쪽인지 정하지 못했습니다 ('+', '.join(sorted(seen))+'). 쓰는 계정 탭만 남기고 다시 실행하세요.')
        host=next(iter(seen),None)
        if not host:
            fixed=getattr(ob,'SEARCH_URL',None)   # 누아브판: 고정 서버
            host=urlsplit(fixed).hostname if fixed else None
        if not host:raise OrderAutoError(NO_ADMIN_MESSAGE)
        self.admin_host=host;return host
    def url(self,path):return 'https://'+self.admin()+path
    # ---- 로그인 확인 (입력하지 않음)
    def protected_page(self,url,marker):
        if url==self.url(DOWNLOAD_PATH) and not (self.export_acknowledged and self.export_accepted):
            raise OrderAutoError('확인했습니다 입력과 다운로드 접수 완료 전에는 다운로드관리자로 이동하지 않습니다.')
        self.step='주문검색 연결' if url==self.url(SEARCH_PATH) else '다운로드관리자 연결'
        tab=self.open(url)
        def state():
            s=self.js(tab,LOGIN_STATE_JS,self.admin())
            if s=='login':raise OrderAutoError(LOGGED_OUT_MESSAGE)
            if s=='other':raise OrderAutoError('이지어드민이 아닌 화면으로 바뀌어 중단했습니다.')
            return s=='in' and self.js(tab,VISIBLE_JS,marker)
        if self.js(tab,'function(){return !!document.querySelector("input")&&('+ob.SECCODE_JS+')();}'):
            raise OrderAutoError('보안코드 입력 화면이 나와 중단했습니다. 보안코드는 입력하지 않았습니다.')
        if self.js(tab,BODY_HAS_JS,'mysqli'):raise OrderAutoError('로그인 세션을 주문검색에 연결하지 못했습니다. 메인 Chrome의 이지어드민 로그인 상태를 확인하세요.')
        self.until(state,20,'이지어드민 화면을 확인하지 못했습니다.')
        return tab
    # ---- 확장주문검색 → 엑셀 신청
    def grid_ready(self,tab):
        def ok():
            g=self.js(tab,GRID_JS)
            return (not g['loading']) and (g['rows'] or g['empty']) and g
        return self.until(ok,45,'조회가 완료되지 않았습니다. 기존 주문은 유지됩니다.')
    def set_group(self,tab,group):
        self.step='판매처 그룹 설정'
        pop=self.open(self.url(GROUP_PATH))
        def read():
            r=self.js(pop,GROUP_ID_JS,group)
            if r['state']=='wait':return None
            return r
        r=self.until(read,15,'판매처 그룹 화면을 열지 못했습니다.')
        if r['state']=='nogroup':raise OrderAutoError('설정한 판매처 그룹을 찾지 못했습니다. 그룹 이름을 확인하세요.')
        if r['state']!='ok':raise OrderAutoError('판매처 그룹 번호를 확인하지 못했습니다.')
        try:self.osa('close',pop)
        except Exception:pass
        if pop in self.tabs:self.tabs.remove(pop)
        self.page=tab
        if self.js(tab,APPLY_GROUP_JS,r['id'])!='ok':raise OrderAutoError('판매처 그룹을 주문검색에 적용하지 못했습니다.')
        if self.js(tab,SHOP_SELECTED_JS)!='상세선택':raise OrderAutoError('판매처 상세 선택이 적용되지 않았습니다.')
    def notice(self,tab,sel,img,button,title,text,click=True):
        r=self.js(tab,NOTICE_JS,{'sel':sel,'img':img,'button':button,'title':title,'text':text,'click':click})
        if r=='many':raise OrderAutoError('다운로드 안내창이 여러 개 보여 중단했습니다. 메인 Chrome 탭을 확인하세요.')
        return r=='found'
    def export_stage(self,message):
        self.c.check();self.step=message;self.c.update('request','[메인 Chrome] '+message)
    def export_dialogs(self,tab):
        if self.js(tab,RECEIPT_JS):raise OrderAutoError('이전 다운로드 접수 안내가 남아 있습니다. 새 작업으로 처리하지 않습니다.')
        self.export_stage('다운로드 신청 버튼 확인')
        self.until(lambda:self.notice(tab,'#pop_download_info','/images/download_info_request.png','#btn_download_info1','다운로드 변경 안내','다운로드 신청'),
                   20,'다운로드 변경 안내의 다운로드 신청 버튼을 찾지 못했습니다.')
        self.export_stage('개인정보 파기 안내 확인')
        self.until(lambda:self.notice(tab,'#pop_personal_information','/images/personal_infomation_popup.png','.btn_cnf','개인정보 파기 안내','확인'),
                   20,'개인정보 파기 안내의 확인 버튼을 찾지 못했습니다.')
        self.export_stage('확인했습니다 입력')
        def ack():
            r=self.js(tab,ACK_JS,{'mode':'find'})
            if r=='many':raise OrderAutoError('다운로드 확인 입력창이 여러 개 보여 중단했습니다.')
            return r=='found'
        self.until(ack,20,'다운로드 확인 입력란을 찾지 못했습니다.')
        if self.js(tab,ACK_JS,{'mode':'fill','value':'확인했습니다'})!='확인했습니다':
            raise OrderAutoError('확인했습니다 입력을 확인하지 못했습니다. 다운로드관리자로 이동하지 않습니다.')
        self.export_stage('다운로드 최종 확인')
        if self.js(tab,RECEIPT_JS):raise OrderAutoError('최종 확인 전에 접수 안내가 나타나 중단했습니다. 기존 파일은 가져오지 않습니다.')
        self.export_acknowledged=True
        started=datetime.now(KST)
        if self.js(tab,ACK_JS,{'mode':'confirm','value':'확인했습니다'})!='clicked':
            raise OrderAutoError('확인했습니다 입력이 변경되어 다운로드 신청을 중단했습니다.')
        self.export_stage('다운로드 접수 완료 확인')
        self.until(lambda:self.js(tab,RECEIPT_JS),20,'다운로드 접수를 확인하지 못했습니다. 기존 파일은 가져오지 않습니다.')
        self.export_accepted=True
        return started,datetime.now(KST)
    def export_orders(self,cfg):
        if self.export_requested:raise OrderAutoError('이미 엑셀 신청을 시작한 작업입니다. 다시 신청하지 않았습니다.')
        tab=self.protected_page(self.url(SEARCH_PATH),'#date_period_sel')
        self.step='주문 검색조건 설정'
        self.c.update('search','[메인 Chrome] 최근한달 · 접수+송장 · C/S 정상+교환 · 판매처 그룹을 설정합니다.')
        self.js(tab,SET_SEARCH_JS);self.pause(.5)
        self.set_group(tab,cfg['group'])
        self.step='주문 조회';self.js(tab,CLICK_JS,'#search');self.pause(1)
        g=self.grid_ready(tab)
        if not g['rows']:raise OrderAutoError('조회 결과가 0건입니다. 기존 주문은 유지됩니다. 0건 반영은 수동 불러오기에서 확인하세요.')
        self.js(tab,SET_DOWNLOAD_JS)
        self.step='주문 엑셀 신청';self.c.update('request','[메인 Chrome] 배송지연 전체품목 엑셀을 신청합니다.')
        expected=[('#date_period_sel','최근한달'),('select[name="date_type"]','발주일'),('select[name="status_sel"]','접수+송장'),('select[name="order_cs_sel"]','정상+교환'),('#download_type','상품단위'),('#download_field','배송지연 전체품목')]
        if self.js(tab,CHECKED_LABELS_JS,[s for s,_ in expected])!=[l for _,l in expected]:
            raise OrderAutoError('조회 조건이 변경되어 중단했습니다. 자동 불러오기를 다시 시작하세요.')
        self.export_requested=True
        started=datetime.now(KST)
        self.js(tab,CLICK_JS,'#download')
        try:_,accepted=self.export_dialogs(tab)
        except ob.StepTimeout:
            if self.step!='다운로드 신청 버튼 확인':raise
            raise ob.CaptchaNeeded('다운로드 신청에 캡차 인증이 필요합니다.',tab,started) from None
        self.c.update('waiting','다운로드 접수 완료 · 5초 후 새 파일의 완료 여부를 확인합니다.')
        self.pause(5)
        return self.fetch_requested(started,accepted,cfg)
    # ---- 캡차: 사장님이 메인 Chrome 탭에서 직접
    def captcha_download(self,tab,started,cfg):
        self.page=tab;self.step='캡차 인증 대기'
        attempt=int(cfg.get('captchaAttempt',0) or 0)
        msg=('이지어드민 다운로드 신청에 캡차 인증이 나왔습니다. 메인 Chrome의 확장주문검색 탭에서 캡차를 입력하고 다운로드 신청'
             '(안내 확인 · 확인했습니다 입력 · 접수)까지 직접 해 주세요. 끝나면 누아브 앱의 "다운로드 완료" 버튼을 누르세요.'
             f' {ob.CAPTCHA_ANSWER_SECONDS//60}분 안에 응답이 없으면 탭을 닫고 {ob.CAPTCHA_RETRY_GAP//60}분 간격으로 다시 수집합니다'
             f' (최대 {ob.CAPTCHA_RETRY_TIMES}회'+(f' · 지금 {attempt}회째' if attempt else '')+').')
        alert=getattr(self.c,'alert',None)
        if alert and not attempt:
            try:alert('이지어드민 캡차 인증 부탁드립니다',msg,'error')
            except Exception:pass
        self.c.captcha_wait(msg)
        began=self.clock()
        while True:
            command=self.c.take_browser_action()
            if command and command[0]=='downloaded':break
            held=bool(getattr(self.c,'captcha_hold',False))
            if not held and self.clock()>began+ob.CAPTCHA_ANSWER_SECONDS:
                raise ob.CaptchaUnanswered(f'캡차 인증 요청에 {ob.CAPTCHA_ANSWER_SECONDS//60}분 동안 응답이 없었습니다.')
            if self.clock()>began+ob.CAPTCHA_WAIT_SECONDS:raise OrderAutoError('30분 안에 다운로드 완료를 받지 못했습니다. 다운로드관리자에서 파일을 확인하고 수동으로 불러오세요.')
            self.pause(1)
        self.c.end_browser_recovery()
        accepted=datetime.now(KST)
        self.export_acknowledged=True;self.export_accepted=True
        self.c.update('waiting','다운로드 완료 확인 · 다운로드관리자에서 이번 확장주문검색을 찾아 받습니다.')
        return self.fetch_requested(started,accepted,cfg)
    # ---- 다운로드관리자
    def jobs(self,tab):
        self.grid_ready(tab)
        return self.js(tab,ROWS_PAGE_JS) or []
    def wait_download_job(self,tab,started,accepted):
        self.step='다운로드 요청시간 대조'
        deadline=self.clock()+ob.JOB_WAIT_SECONDS;selected=None
        while True:
            self.c.check()
            job=requested_job(self.jobs(tab),started,accepted)
            if job:
                if selected and (selected['id']!=job['id'] or selected['at']!=job['at']):
                    raise OrderAutoError('생성 대기 중 다운로드 작업 번호 또는 요청시간이 바뀌어 중단했습니다. 수동으로 파일을 확인하세요.')
                selected=job;status=job.get('status','').strip()
                if status=='완료':return job
                if '실패' in status or '오류' in status or '취소' in status:
                    raise OrderAutoError('이번 주문 엑셀 작업이 실패하거나 취소되었습니다. 다운로드관리자에서 확인하세요.')
                self.step='주문 엑셀 완료 대기';message=f'요청시간 {job["at"]} 확인 · 상태 {status or "처리 중"} · 5초 후 다시 확인합니다.'
            else:message=f'신청시간 {window_text(started,accepted)}의 확장주문검색을 찾는 중 · 5초 후 다시 확인합니다.'
            if self.clock()+ob.JOB_POLL_SECONDS>deadline:
                if selected is None:raise OrderAutoError(f'신청시간 {window_text(started,accepted)}에 맞는 주문 엑셀을 찾지 못했습니다. 사이트 요청시간과 Mac 시간을 확인하세요. 이전 파일은 가져오지 않았습니다.')
                raise OrderAutoError('이번 주문 엑셀의 완료를 10분 안에 확인하지 못했습니다. 다운로드관리자에서 해당 요청시간의 작업을 확인하세요.')
            self.c.update('waiting','[메인 Chrome] '+message)
            self.pause(ob.JOB_POLL_SECONDS)
            self.step='다운로드 목록 새로고침';self.js(tab,CLICK_JS,'#search');self.pause(1)
    def download_job(self,tab,job,started,folder):
        self.step='완료된 주문 엑셀 확인'
        name=checked_request_name(job['name'],started);checked_link(job['href'],name)
        now=[r for r in self.jobs(tab) if r.get('id')==job['id']]
        if len(now)!=1 or any(now[0].get(k)!=job.get(k) for k in ('id','at','template','name','href')) or now[0].get('status','').strip()!='완료':
            raise OrderAutoError('완료된 다운로드 행이 변경되었습니다. 파일을 가져오지 않았습니다.')
        self.step='주문 엑셀 저장'
        self.c.update('downloading',f'요청시간 {job["at"]} · 완료 확인 · 새 확장주문검색 엑셀을 저장합니다.')
        # 2026-11-01 21:25: 파일은 다른 서버(예: ga90.ezadmin.co.kr/data/…)에 있어 다운로드관리자(ga79)에서 fetch 하면 막힌다(Failed to fetch, CORS).
        # → 파일과 같은 서버의 폴더 주소를 앱 탭으로 열고(403 화면이어도 같은 출처) 거기서 받는다. 주소는 checked_link 로 이미 확인.
        u=urlsplit(job['href']);where=tab
        if u.hostname!=self.admin():
            self.step='주문 엑셀 서버 연결'
            where=self.open('https://'+u.hostname+u.path.rsplit('/',1)[0]+'/')
            i=self.info(where)
            if not i or urlsplit(i[1]).hostname!=u.hostname or urlsplit(i[1]).scheme!='https':
                raise OrderAutoError('주문 엑셀 서버 화면을 열지 못했습니다. 파일을 가져오지 않았습니다.')
            self.step='주문 엑셀 저장'
        tab=where
        self.js(tab,FETCH_START_JS,{'href':job['href'],'max':MAX_BYTES})
        st=self.until(lambda:(lambda s:s if s['state'] in ('done','error') else None)(self.js(tab,FETCH_STATE_JS)),60,'주문 엑셀을 60초 안에 받지 못했습니다.')
        if st['state']!='done':raise OrderAutoError('주문 엑셀을 받지 못했습니다: '+st.get('e','')[:120])
        parts=[];at=0;n=400000
        while at<st['len']:
            part=self.js(tab,FETCH_CHUNK_JS,{'at':at,'n':n})
            if not part:raise OrderAutoError('주문 엑셀을 읽는 중 끊겼습니다.')
            parts.append(part);at+=len(part)
        self.js(tab,FETCH_CLEAR_JS)
        data=base64.b64decode(''.join(parts))
        if len(data)!=st['size']:raise OrderAutoError('주문 엑셀 크기가 맞지 않습니다. 파일을 가져오지 않았습니다.')
        if not (data.startswith(b'\xd0\xcf\x11\xe0') or data.startswith(b'PK\x03\x04') or data.lstrip()[:1]==b'<'):
            raise OrderAutoError('받은 파일이 엑셀이 아닙니다. 파일을 가져오지 않았습니다.')
        return name,persist_download(BytesDownload(data),folder,name)
    def fetch_requested(self,started,accepted,cfg):
        tab=self.protected_page(self.url(DOWNLOAD_PATH),'#search')
        job=self.wait_download_job(tab,started,accepted)
        return self.download_job(tab,job,started,cfg['folder'])

def run(controller,cfg,flow_factory=MainChromeFlow):
    """order_browser._run_export 대신 (설정: 메인 Chrome). 반환: (파일 이름, 데이터)."""
    retries=0;overlaps=0   # overlaps: 2026-11-03 요청시각 겹침 → 새로 신청한 횟수
    while True:
        flow=flow_factory(controller)
        try:
            controller.update('request','[메인 Chrome] 이지어드민 확장주문검색 탭을 엽니다 (이미 로그인된 세션 사용).')
            if cfg.get('loginOnly'):
                flow.protected_page(flow.url(SEARCH_PATH),'#date_period_sel');return None
            try:return flow.export_orders(cfg)
            except ob.CaptchaNeeded as exc:return flow.captcha_download(exc.page,exc.started,cfg)
        except (Cancelled,ob.CaptchaUnanswered):raise
        except Exception as exc:
            message=flow.failure_message(exc)
            # 2026-11-03: 같은 시각에 다른 확장주문검색 요청이 있어 내 것을 못 가리면, 잠시 뒤 새 요청시각으로 다시 신청한다 (최대 3회).
            if isinstance(exc,AmbiguousJob) and overlaps<AMBIGUOUS_RETRY_TIMES:
                overlaps+=1
                controller.update('search',f'[메인 Chrome] 같은 시각에 다른 주문 엑셀 요청이 있어 구분할 수 없습니다 · {AMBIGUOUS_RETRY_WAIT}초 뒤 엑셀을 새로 신청합니다 ({overlaps}/{AMBIGUOUS_RETRY_TIMES})')
                flow.close_tabs();flow.pause(AMBIGUOUS_RETRY_WAIT);continue
            if overlaps:message+=f'\n요청시각이 겹쳐 {AMBIGUOUS_RETRY_WAIT}초 간격으로 {overlaps}회 새로 신청했지만 매번 겹쳤습니다. 같은 이지어드민 계정으로 동시에 엑셀을 신청하는 다른 프로그램이 있는지 확인하세요.'
            timeout=isinstance(exc,ob.StepTimeout) and not flow.export_requested
            if timeout and retries<ob.RETRY_TIMES:
                retries+=1
                controller.update('search',message.splitlines()[0]+f' · {ob.RETRY_WAIT}초 후 다시 시도합니다 ({retries}/{ob.RETRY_TIMES})')
                flow.close_tabs();flow.pause(ob.RETRY_WAIT);continue
            if retries:message+=f'\n시간 초과 후 {ob.RETRY_WAIT}초 간격으로 {retries}회 다시 시도했지만 진행되지 않았습니다.'
            alert=getattr(controller,'alert',None)
            if alert:
                try:alert('이지어드민 주문 불러오기 실패',message,'error')
                except Exception:pass
            raise OrderAutoError(message) from None
        finally:
            flow.close_tabs()
