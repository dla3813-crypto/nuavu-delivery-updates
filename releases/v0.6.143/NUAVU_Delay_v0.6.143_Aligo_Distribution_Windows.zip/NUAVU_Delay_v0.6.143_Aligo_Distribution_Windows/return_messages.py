"""반품 안내 문자 (2026-10-19 23:33 요청): 반품 기한 초과 / 반품 불량 아님 — SMS·LMS only, sent to the return's 수취인.

The notice goes into the ordinary send ledger (QUEUED → SENDING → PENDING/DELIVERED/FAILED with the same reports)
but carries no order-row keys; it is tied to the return record by its 원송장번호 (`returnInvoice`). A return whose
불량 아님 안내 was requested or delivered moves to the 반품/교환 card "반품 불량 아님 안내 완료".
"""
from __future__ import annotations
import re
from datetime import date

RETURN_NOTICE_TYPES={'return_overdue','return_not_defect','return_manual','return_refund_account'}
REFUND_ACCOUNT_SELLERS=('자사몰',)   # 2026-11-03: 자사몰(무통장/반품도착) 안내는 자사몰 반품에만
MANUAL_MAX_CHARS=900
# 오타 정리: 제 17조→제17조, 처리 되었습니다→처리되었습니다, 반품제품 수거되어→반품 제품이 수거되어, 첨부주신→첨부해 주신, 반품처리→반품 처리.
RETURN_OVERDUE=('안녕하세요 고객님 {쇼핑몰}입니다.\n요청주신 반품 건 확인 후 안내드립니다.\n\n요청주신 반품 건은\n'
                '전자상거래 등에서의 소비자보호에 관한 법률 제17조 제1항에 따른 청약철회 가능 기간이\n경과하여 반품 요청은 철회 처리되었습니다.\n\n감사합니다.')
RETURN_NOT_DEFECT_BASE=('안녕하세요 고객님\n{쇼핑몰}입니다.\n\n반품 제품이 수거되어 입고되었으나,\n첨부해 주신 사유는 불량 사유로 인한 반품 처리가 불가하여\n'
                        '귀책 사유 수정 후 반품 처리 도와드려도 괜찮으실까요?')
RETURN_NOT_DEFECT_ABLY=(RETURN_NOT_DEFECT_BASE+'\n\n관련 안내는\n에이블리 앱 > 마이페이지 > 공지사항 > "불량이 아닌 점 안내드려요!" 게시물\n'
                        '에이블리 앱 > 자사 상품 상세페이지 > 문의 > 배송 / 결제 / 교환 반품 안내\n를 참고하여 확인 부탁드립니다.')
# 2026-10-23 18:46 요청: 교환도 불량 아님 문자 · 반품/교환 둘 다 수동 메시지 작성.
EXCHANGE_NOT_DEFECT_BASE=('안녕하세요 고객님\n{쇼핑몰}입니다.\n\n교환 제품이 수거되어 입고되었으나,\n첨부해 주신 사유는 불량 사유로 인한 교환 처리가 불가하여\n'
                          '귀책 사유 수정 후 교환 처리 도와드려도 괜찮으실까요?')
EXCHANGE_NOT_DEFECT_ABLY=(EXCHANGE_NOT_DEFECT_BASE+'\n\n관련 안내는\n에이블리 앱 > 마이페이지 > 공지사항 > "불량이 아닌 점 안내드려요!" 게시물\n'
                          '에이블리 앱 > 자사 상품 상세페이지 > 문의 > 배송 / 결제 / 교환 반품 안내\n를 참고하여 확인 부탁드립니다.')
MANUAL_DRAFT='안녕하세요 고객님\n{쇼핑몰}입니다.\n\n'
# 2026-11-03 18:09 요청: 자사몰 무통장 주문 반품 도착 → 왕복 배송비 제외 환불 · 환불 계좌 요청 (문구 그대로)
RETURN_REFUND_ACCOUNT=('안녕하세요 고객님\n{쇼핑몰}입니다.\n\n보내주신 반품 상품이 도착하여 연락드립니다.\n'
                       '왕복 배송비 6,000원을 제외한 금액으로 환불 도와드리겠습니다.\n'
                       '환불받으실 계좌번호(은행명, 예금주 포함) 남겨주시면 확인 후 입금해드리겠습니다.\n감사합니다.')
LABELS={'return_overdue':'반품 기한 초과 (청약철회 기간 경과)','return_not_defect':'반품 불량 아님','return_manual':'반품/교환 수동 메시지','return_refund_account':'자사몰 반품 도착 · 환불 계좌 안내 (무통장)'}
def label_of(kind,exchange=False):
    if exchange:return {'return_not_defect':'교환 불량 아님','return_manual':'교환 수동 메시지','return_overdue':'교환 기한 초과'}[kind]
    return {'return_manual':'반품 수동 메시지'}.get(kind,LABELS[kind])

def is_ably_seller(seller):return '에이블리' in str(seller or '') or 'ably' in str(seller or '').lower()

def return_template(kind,seller,exchange=False):
    if kind=='return_overdue':return RETURN_OVERDUE
    if kind=='return_not_defect':
        if exchange:return EXCHANGE_NOT_DEFECT_ABLY if is_ably_seller(seller) else EXCHANGE_NOT_DEFECT_BASE
        return RETURN_NOT_DEFECT_ABLY if is_ably_seller(seller) else RETURN_NOT_DEFECT_BASE
    if kind=='return_manual':return MANUAL_DRAFT
    if kind=='return_refund_account':return RETURN_REFUND_ACCOUNT
    raise ValueError(kind)

def render_return_message(kind,seller,shop_name,exchange=False):
    return return_template(kind,seller,exchange).replace('{쇼핑몰}',(shop_name or '쇼핑몰').strip())

def return_notice_state(notices,invoice):
    """{'overdue': status|'', 'notDefect': status|''} — the latest live (queued…delivered) return notice per kind."""
    out={'overdue':'','notDefect':'','manual':'','refundAccount':''}
    live={'QUEUED','SCHEDULED','PAUSED','SENDING','PENDING','UNKNOWN','DELIVERED'}
    for n in notices:
        if n.get('returnInvoice')!=invoice or n.get('isTest') or n['status'] not in live:continue
        k={'return_overdue':'overdue','return_not_defect':'notDefect','return_manual':'manual','return_refund_account':'refundAccount'}.get(n.get('noticeType'),'')
        if k:out[k]=n['status']
    return out

class ReturnMessageMixin:
    def _return_record(self,s,invoice):
        from aftersales_data import public_aftersales
        from domain import today
        view=public_aftersales(s,date.fromisoformat(today()))
        for r in view['rows']+view['exchangeRows']:
            if r.get('invoice')==invoice:return r
        return None

    def _seller_of(self,s,r):
        """Return records come from the 에이블리 반품 page and carry no seller; the matching order row (by 주문번호/상품주문번호)
        decides 에이블리 vs 지그재그·자사몰 wording. Unknown → 에이블리 (the page the record came from)."""
        if r.get('seller') and r['seller']!='에이블리':return r['seller']
        ids={str(r.get('orderId') or '').strip(),str(r.get('itemId') or '').strip()}-{''}
        for o in s.get('rows',[]):
            if str(o.get('orderId') or '').strip() in ids or str(o.get('itemId') or '').strip() in ids:return o.get('seller') or '에이블리'
        return '에이블리'

    def _order_phone(self,s,r,seller):
        """2026-11-03: 반품 목록에 연락처가 없거나 안심번호(050 등)면, 앱에 불러온 주문(이지어드민 확장주문검색의 수령자/주문자 휴대폰)에서 찾는다.
        같은 주문번호(자사몰·지그재그·아무드) 또는 상품주문번호(에이블리)의 주문 행 — 목록 제외된(출고된) 주문도 포함. 010 번호만 쓴다."""
        ids={str(r.get('orderId') or '').strip(),str(r.get('itemId') or '').strip()}-{''}
        if not ids:return ''
        ok=lambda v:bool(re.fullmatch(r'01[016789]\d{7,8}',re.sub(r'\D','',str(v or ''))))
        want=str(seller or '').replace('누아브 ','').strip()
        rows=[o for o in s.get('rows',[]) if str(o.get('orderId') or '').strip() in ids or str(o.get('itemId') or '').strip() in ids
              or any(str(x.get('id') or '').strip() in ids for x in (o.get('orderItems') or []))]
        rows=[o for o in rows if not want or str(o.get('seller') or '').replace('누아브 ','').strip()==want] or rows
        rows.sort(key=lambda o:(not o.get('active',True),o.get('lastSeen') or ''),reverse=False)
        for o in sorted(rows,key=lambda o:(not o.get('active',True),)):
            c=o.get('exportContacts') or {}
            for v in (c.get('recipientMobile'),o.get('phone'),c.get('buyerMobile')):
                if ok(v):return re.sub(r'\D','',str(v))
        return ''

    def return_message_preview(self,p):
        from domain import ValidationError
        from aftersales_data import shop
        s=self.store.read();invoice=str(p.get('invoice') or '').strip();kind=p.get('kind','')
        if kind not in RETURN_NOTICE_TYPES:raise ValidationError('반품 안내 종류를 선택하세요.')
        r=self._return_record(s,invoice)
        if not r:raise ValidationError('반품/교환 조회 결과에서 해당 원송장을 찾지 못했습니다. 반품체크를 먼저 실행하세요.')
        phone=re.sub(r'\D','',str(r.get('recipientPhone') or ''));phone_source='반품 목록'
        exchange=r.get('kind')=='exchange'
        if exchange and kind=='return_overdue':raise ValidationError('교환 건에는 기한 초과 안내를 보내지 않습니다.')
        seller=self._seller_of(s,r)
        if not re.fullmatch(r'01[016789]\d{7,8}',phone):   # 2026-11-03: 자사몰(연락처 없음)·지그재그(안심번호) → 주문 데이터에서 보완
            found=self._order_phone(s,r,seller)
            if found:phone=found;phone_source='주문 데이터(이지어드민 수령자/주문자 휴대폰)'
        if kind=='return_refund_account':
            if exchange:raise ValidationError('교환 건에는 반품 도착 환불 안내를 보내지 않습니다.')
            if str(seller or '').replace('누아브 ','').strip() not in REFUND_ACCOUNT_SELLERS:raise ValidationError('자사몰(무통장/반품도착) 안내는 자사몰 반품에만 보냅니다. 이 건의 판매처: '+str(seller or '미확인'))
        body=render_return_message(kind,seller,shop(s)['shopName'],exchange)
        if kind=='return_manual' and p.get('content') is not None:
            body=str(p.get('content')).replace('\r\n','\n').replace('{쇼핑몰}',(shop(s)['shopName'] or '쇼핑몰').strip()).strip()
            if len(body)>MANUAL_MAX_CHARS:raise ValidationError(f'수동 메시지는 {MANUAL_MAX_CHARS}자 이내로 작성하세요.')
        return {'invoice':invoice,'kind':kind,'label':label_of(kind,exchange),'exchange':exchange,'seller':seller,'orderId':r.get('orderId',''),'product':r.get('product',''),
                'option':(r.get('option') or '')+(' → '+r['exchangeOption'] if r.get('exchangeOption') else ''),
                'phone':phone,'phoneOk':bool(re.fullmatch(r'01[016789]\d{7,8}',phone)),'phoneSource':phone_source,'content':body,'state':return_notice_state(s['notices'],invoice)}

    def return_message_send(self,p):
        from domain import (ValidationError,now,notice_ref,bytecount,fingerprint,send_window,PENDING)
        from aftersales_data import shop
        preview=self.return_message_preview(p);kind=preview['kind'];invoice=preview['invoice']
        if not preview['phoneOk']:raise ValidationError('수취인 연락처를 확인하세요. 안심번호·빈 번호로는 발송하지 않습니다.')
        if kind=='return_manual':
            draft=render_return_message('return_manual','',shop(self.store.read())['shopName']).strip()
            if p.get('content') is None or not preview['content'] or preview['content']==draft:raise ValidationError('보낼 내용을 작성하세요.')
        send_mode=str(p.get('sendMode') or 'AUTO')
        if send_mode not in ('AUTO','IMMEDIATE','MORNING'):raise ValidationError('전송 시점을 확인하세요.')
        request_id=str(p.get('requestId') or '')
        with self.network_lock,self.store.edit() as s:
            if request_id and any(n.get('returnRequestId')==request_id for n in s['notices']):
                return {'count':0,'alreadyAccepted':True,'message':'이미 요청한 반품 안내입니다.'}
            if any(n.get('returnInvoice')==invoice and n.get('noticeType')==kind and n['status'] in PENDING and (kind!='return_manual' or n.get('returnBody')==preview['content']) for n in s['notices']):
                raise ValidationError('같은 반품/교환 건에 같은 안내가 요청·예약 중입니다. 기존 작업을 먼저 확인하세요.')
            cfg=s['settings']
            if not cfg.get('sender'):raise ValidationError('문자 발신번호를 먼저 설정하세요.')
            ref=notice_ref();content=preview['content']+'\n\n안내번호:'+ref
            size=bytecount(content);kind_sms='SMS' if size<=80 else 'LMS'
            if size>2000:raise ValidationError('안내문이 2,000바이트를 넘습니다.')
            cred=self.credential(kind_sms);sender=self.sender_for(s,kind_sms)
            if not sender:raise ValidationError('발신번호를 설정하세요.')
            if preview['phone']==sender:raise ValidationError('수신번호가 발신번호와 같습니다.')
            title=(shop(s)['shopName'] or '쇼핑몰')+(' 교환 안내' if preview['exchange'] else ' 반품 안내')
            n=self.new_notice(kind_sms,content,title,preview['phone'],ref,[],provider=self.sms_provider_for(kind_sms))
            n.update(seller=preview['seller'] or '',orderId=preview['orderId'] or '',products=[{'product':preview['product'],'option':'','qty':1}],dueDate='',noticeType=kind,
                     fingerprint=fingerprint(['return',invoice,kind,preview['phone'],preview['content']]),returnInvoice=invoice,returnRequestId=request_id,returnBody=preview['content'],returnExchange=preview['exchange'],
                     sender=sender,scheme=cfg['scheme'],account=cred.user,configRevision=cfg['configRevision'],sendAuthorizedAt=now(),sendMode=send_mode,
                     note='반품 안내 문자 · 아직 공급사에 요청하지 않았습니다.')
            try:  # 배포판: 발송 시 쇼핑몰 이름·개정 번호를 대조한다 (메인 판에는 branding 모듈이 없다).
                from branding import clean_name
                n.update(shopName=clean_name(cfg.get('shopName','')),shopRevision=cfg.get('shopRevision'))
            except ImportError:pass
            window=send_window(mode=send_mode)
            if window['scheduled']:
                n['scheduledAt']=window['sendAt']
                self.transition(n,'SCHEDULED','오전 9시 예약 선택: 한국 시간 '+window['minDueDate']+' 오전 9시 예약 (아직 공급사에 요청하지 않음)')
            s['notices'].append(n);s['queuePaused']=False
            s['audits'].append({'at':now(),'event':'교환 안내 문자 요청' if preview['exchange'] else '반품 안내 문자 요청','kind':kind,'invoice':invoice,'sendMode':send_mode})
        return {'count':1,'id':n['id'],'scheduled':bool(window['scheduled']),'message':preview['label']+' 문자를 '+('오전 9시에 예약했습니다.' if window['scheduled'] else '요청했습니다. 15초 뒤 결과를 확인합니다.')}
