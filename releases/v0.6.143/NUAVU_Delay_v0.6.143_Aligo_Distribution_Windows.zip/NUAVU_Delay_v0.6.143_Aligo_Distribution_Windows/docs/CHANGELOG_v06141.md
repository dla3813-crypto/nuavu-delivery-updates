# NUAVU_Delay_v0.6.141_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06140.md

## 2026-11-03 누아브판 0.6.148~0.6.150 이식 + 출고장 질문 규칙 (배포 대상: 0.6.139 → 0.6.141)
(0.6.140 미배포분 포함: 메인 Chrome을 프로세스 번호로 지정 · 탭 번호 글자 비교 · 시간 초과 때 마지막 상태 표시)
- 아무드 묶음(추가옵션) 주문: 같은 주문번호·같은 상품주문번호가 옵션만 다른 여러 줄이면 한 주문상품으로 합쳐 불러옴 (domain.merge_amood_bundles). 오류 문구에 판매처·번호 표시. patch/apply_dist_06148_amood_bundle.py
- 이지어드민 엑셀 요청시각 겹침: 같은 시각에 다른 확장주문검색 요청이 있어 내 것을 못 가리면 30초 뒤 새로 신청 (최대 3회, 메인 Chrome·전용 Chrome 모두). patch/apply_dist_06149_overlap_retry.py
- 반품/교환 안내 문자 수신번호: 반품 목록에 010 번호가 없으면(자사몰 연락처 없음·지그재그 안심번호) 불러온 주문의 수령자/주문자 휴대폰으로 보완 (출고된 주문 포함). 미리보기에 출처 표시.
- 새 안내 문자 「자사몰(무통장/반품도착)」: 반품 도착 · 왕복 배송비 6,000원 제외 환불 · 환불 계좌 요청. 자사몰 반품에만 (교환·타 판매처 거부). ※ 배송비 문구는 누아브 기준 고정.
- 발송실패 표시 지우기: 발송실패 필터에서 상품 선택 → 「선택 발송실패 표시 지우기」. 이력·결과 유지, 배지/분류에서만 제외. 목록 제외 행도 그 필터에서는 체크 가능 (rangeSelection 수정). web/failed_dismiss.js + app.py 정적 목록 등록. patch/apply_dist_06150_returns_contact_refund_dismiss.py
- 화요일 출고장 질문: 그 화요일보다 뒤 날짜 출고장이 폴더에 있으면 이전 출고장은 완료돼 치워진 것으로 보고 묻지 않음 (10/27 치워지고 10/31만 남은 사례). patch/apply_ship_delay_later_manifest.py
- 테스트 추가: tests/test_amood_bundle_import.py · test_overlap_retry.py · test_return_contact_refund_dismiss.py (배포판 이식본, 쇼핑몰 이름 '누아브' 설정) · test_ship_delay.py 1건 · clock_helper.py
