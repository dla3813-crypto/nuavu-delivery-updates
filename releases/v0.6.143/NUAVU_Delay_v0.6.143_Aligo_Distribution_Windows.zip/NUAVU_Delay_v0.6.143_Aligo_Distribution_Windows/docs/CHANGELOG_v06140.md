# NUAVU_Delay_v0.6.140_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06139.md

## 메인 Chrome 안정화 (2026-11-02, 누아브판 0.6.146~0.6.147과 같은 수정)
- 메인 Chrome을 프로세스 번호(pid)로 지정 (JXA) · 탭 번호를 글자로 비교 · 시간 초과 때 마지막 상태 표시.
