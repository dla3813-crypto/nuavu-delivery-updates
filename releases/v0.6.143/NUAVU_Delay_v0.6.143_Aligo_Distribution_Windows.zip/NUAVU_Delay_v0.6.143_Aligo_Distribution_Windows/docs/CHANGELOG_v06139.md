# NUAVU_Delay_v0.6.139_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06138.md

## 메인 Chrome으로 주문 불러오기 (2026-11-01)
- 누아브판 0.6.141~0.6.145의 main_chrome.py 이식 (관리자 서버는 열린 이지어드민 탭에서 찾음). Firefox 시험은 넣지 않음.
- ⚙ 설정 › 자동화 설정 스위치 (기본 꺼짐, Mac).
