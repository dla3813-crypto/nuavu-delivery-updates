# NUAVU_Delay_v0.6.142_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06141.md

## 2026-11-04 누아브판 0.6.152 이식 (배포 대상: 0.6.141 → 0.6.142)
- 영어 컬러 매칭: 주문 [Ivory-FREE]·[Gray-FREE]·[One Color-FREE] ↔ 발주 아이보리·그레이·원컬러 자동 매칭 (supply_workflow.color_match_key, 비교 전용). 한글 동의어(검정·회색…)는 기존대로 추천만.
- 중국 취소건: 컬러가 다르면 '비슷한 취소상품'으로 묻지 않음(상품명·컬러 같고 사이즈만 다를 때만). 「다른 상품/오발주」누르면 같은 상품명의 다른 취소 항목에도 다시 묻지 않음. 사무실 도착(V) 잡힌 주문은 취소건 표시 제외 (배포판은 현재고 없음).
- 출고장 표시: "출고장 V · 10-29" → "출고장 · 10-31 (V 10-29)".
- 테스트: tests/test_matching_china_06142.py (4) · tests/test_china_cancel.py 갱신(+2). 패치: patch/apply_dist_06142_matching_china.py · patch_test_china_cancel_06152.py
