"""Platform collection -> atomic local acknowledgement history.

No provider calls, no reservation transitions, no order imports. Browser results
must cover the complete list twice before anything reaches this module.

Optional push (v0.6.143): items the app already notified (real SMS/LMS/AT or a
message-less acknowledgement) but Ably still lists as unsent get Ably's own
"배송지연메시지 발송 처리" with the app's due date. Planning happens here from the
verified list; the browser performs it; results are recorded even when the final
list verification fails, because an Ably message can only be sent once.
"""
from __future__ import annotations
from job_alerts import job_alert
import copy, hashlib, json, re, secrets, threading
from collections import defaultdict
from datetime import date,timedelta
from external_notices import matches
from order_items import ABLY

class AblySyncError(ValueError): pass
class AblyCancelled(AblySyncError): pass
class AblyPushAborted(AblySyncError):
    """Raised by the browser after pushes were made but the final list check failed."""
    def __init__(self,message,pushes):super().__init__(message);self.pushes=pushes

PUSH_OPTIONS={1:'내일',2:'모레',3:'3일 이내',7:'1주 이내',14:'2주 이내'}
PUSH_MAX_DAYS=30  # Ably's date picker: "최대 30일 선택 가능"

def push_option(due,today):
    """Map the app's due date to Ably's quick button, or the calendar ('date').

    Returns (option,reason). option '' means the date cannot be sent on Ably.
    """
    try:d=date.fromisoformat(due);t=date.fromisoformat(today)
    except (ValueError,TypeError):return '','출고 예정일 형식 오류'
    delta=(d-t).days
    if delta<0:return '','출고 예정일이 이미 지나 에이블리에서 선택할 수 없습니다. 새 날짜로 안내 후 다시 동기화하세요.'
    if delta>PUSH_MAX_DAYS:return '',f'출고 예정일이 {PUSH_MAX_DAYS}일을 넘어 에이블리에서 선택할 수 없습니다.'
    return PUSH_OPTIONS.get(delta,'date'),''

def app_delay_notice(s,key):
    """The app's effective delay acknowledgement for a row (same choice as public_state)."""
    from domain import applied_notice,is_soldout
    from history_seed import effective_notice_key
    good=[n for n in s['notices'] if not n.get('isTest') and key in n.get('itemKeys',[]) and applied_notice(n)]
    if not good:return None
    latest=sorted(good,key=effective_notice_key)[-1]
    if is_soldout(latest) or latest.get('source') in ('ably_sync','zigzag_sync') or not latest.get('dueDate'):return None
    return latest

def plan_pushes(s,items,today):
    """Targets: app notified (SMS/LMS/AT accepted/delivered or message-less ack) & Ably unsent.

    `items` is the complete verified Ably list (sent and unsent) so aggregated rows
    with several 상품주문번호 are judged on all of their IDs. Pure function.
    """
    entries=[{'seller':ABLY,'itemId':i['itemId'],'orderId':i['orderId'],'qty':i['qty']} for i in items]
    result=matches(s,entries,'');sent={i['itemId'] for i in items if i.get('noticeSent')}
    targets=[];skipped=[]
    for e in result:
        if e['itemId'] in sent:continue
        if e['status']!='ready':continue  # not an app order / qty differs: nothing to send
        n=app_delay_notice(s,e['key'])
        if not n:continue
        option,reason=push_option(n['dueDate'],today)
        base={'itemId':e['itemId'],'orderId':e['orderId'],'qty':e['qty'],'key':e['key'],'dueDate':n['dueDate'],'noticeId':n['id'],
              'noticeChannel':n.get('channel','')}
        if not option:skipped.append({**base,'status':'skipped','reason':reason});continue
        targets.append({**base,'option':option})
    return targets,skipped

def validate_pushes(pushes):
    if pushes is None:return []
    if not isinstance(pushes,list) or len(pushes)>20000:raise AblySyncError('에이블리 발송 처리 결과 형식을 확인하지 못했습니다.')
    clean=[]
    for raw in pushes:
        if not isinstance(raw,dict) or raw.get('status') not in ('sent','failed','skipped'):raise AblySyncError('에이블리 발송 처리 결과 형식을 확인하지 못했습니다.')
        p={k:raw.get(k,'') for k in ('itemId','orderId','qty','key','dueDate','noticeId','option','status','reason','sentAt','platformNotice')}
        if not isinstance(p['itemId'],str) or not re.fullmatch(r'\d{1,30}',p['itemId']):raise AblySyncError('에이블리 발송 처리 결과의 상품주문번호를 확인하지 못했습니다.')
        clean.append(p)
    return clean

def record_pushes(s,pushes,stamp):
    """Append the push outcome to the store: a bounded log, the source notice's events, an audit."""
    pushes=validate_pushes(pushes)
    if not pushes:return {'pushed':0,'pushFailed':0,'pushSkipped':0}
    by_id={n['id']:n for n in s['notices']}
    log=s.setdefault('ablyPushLog',[])
    for p in pushes:
        log.append({**p,'at':stamp})
        n=by_id.get(p['noticeId'])
        if n is not None and p['status']=='sent':
            n.setdefault('events',[]).append({'at':stamp,'status':n['status'],'note':f"에이블리 배송지연 메시지 발송 처리 완료 (앱 자동) · 상품주문번호 {p['itemId']} · 예상 출고일 {p['dueDate']} ({p['option'] if p['option']!='date' else '날짜 선택'})"})
            n['updatedAt']=stamp
    del log[:-5000]
    counts={'pushed':sum(p['status']=='sent' for p in pushes),'pushFailed':sum(p['status']=='failed' for p in pushes),'pushSkipped':sum(p['status']=='skipped' for p in pushes)}
    s['audits'].append({'at':stamp,'event':'에이블리 배송지연 메시지 발송 처리',**counts})
    return counts

def push_message(counts):
    if not any(counts.get(k) for k in ('pushed','pushFailed','pushSkipped')):return ''
    return f" · 에이블리 메시지 발송 처리 {counts.get('pushed',0)}건 · 실패 {counts.get('pushFailed',0)}건 · 보류 {counts.get('pushSkipped',0)}건"

def account_cache_key(account):
    return hashlib.sha256(('ably:'+account.get('shopName','')+':'+account['username']).encode('utf-8')).hexdigest()

def date_range(value):
    value=str(value or '').strip()
    if value in ('','-'):return ('','')
    m=re.fullmatch(r'(\d{4}-\d{2}-\d{2})(?:\s*~\s*(\d{4}-\d{2}-\d{2}))?',value)
    if not m:raise AblySyncError('에이블리 예상출고일 형식을 확인하지 못했습니다. 기존 이력을 유지합니다.')
    start,end=m[1],m[2] or m[1]
    try:date.fromisoformat(start);date.fromisoformat(end)
    except ValueError:raise AblySyncError('예상출고일에 잘못된 날짜가 있습니다.') from None
    if start>end:raise AblySyncError('예상출고일 범위의 시작과 끝을 확인하세요.')
    return start,end

def validate_snapshot(snapshot):
    if not isinstance(snapshot,dict) or snapshot.get('complete') is not True or snapshot.get('verified') is not True:
        raise AblySyncError('전체 페이지 대조가 끝나지 않아 이력을 반영하지 않았습니다.')
    entries=snapshot.get('entries')
    if not isinstance(entries,list) or type(snapshot.get('total')) is not int or not 0<=len(entries)<=snapshot['total']<=20000 or snapshot.get('notifiedTotal')!=len(entries):
        raise AblySyncError('에이블리 전체 건수와 읽은 상품 수가 다릅니다.')
    if snapshot.get('pages')!=max(1,(snapshot['total']+99)//100):raise AblySyncError('전체 페이지 수를 확인하지 못했습니다.')
    seen=set();clean=[]
    for raw in entries:
        e={k:raw.get(k) for k in ('itemId','orderId','qty','range','noticeDate')}
        if raw.get('noticeSent') is not True:raise AblySyncError('배송지연 메시지 발송 표시가 없는 상품은 반영하지 않습니다.')
        if any(not isinstance(e[k],str) or not re.fullmatch(r'\d{1,30}',e[k]) for k in ('itemId','orderId')) or e['itemId'] in seen:
            raise AblySyncError('중복되거나 잘못된 상품주문번호가 있습니다.')
        if type(e['qty']) is not int or not 0<e['qty']<=100000:raise AblySyncError('주문 수량을 확인하지 못했습니다.')
        start,end=date_range(e['range'])
        if e['noticeDate']:date_range(e['noticeDate'])
        e.update(startDate=start,dueDate=end,seller=ABLY,product='',option='',sheet='에이블리 발송 관리',line=len(clean)+1,
                 fromCache=raw.get('fromCache') is True,readAt=raw.get('readAt',''))
        seen.add(e['itemId']);clean.append(e)
    return clean

def apply_snapshot(engine,snapshot,cache_key='',shop=None):
    from domain import now
    entries=validate_snapshot(snapshot);stamp=now();cached=sum(e['fromCache'] for e in entries)
    pushes=validate_pushes(snapshot.get('pushes'));pushed_ids={p['itemId']:p for p in pushes if p['status']=='sent'}
    if cache_key and not re.fullmatch(r'[a-f0-9]{64}',cache_key):raise AblySyncError('동기화 계정을 확인하지 못했습니다.')
    counts={'scanned':snapshot['total'],'eligible':len(entries),'cached':cached,'fresh':len(entries)-cached,'skippedUnsent':snapshot['total']-len(entries),'pages':snapshot['pages'],'items':0,'unchanged':0,'missingDate':0,'unmatched':0,'protected':0}
    with engine.network_lock,engine.store.edit() as s:
        if shop is not None and any(s['settings'].get(k)!=shop[k] for k in ('shopName','shopRevision')):
            raise AblySyncError('동기화 도중 쇼핑몰 설정이 바뀌었습니다. 새 설정으로 다시 동기화하세요.')
        counts.update(record_pushes(s,pushes,stamp))
        issues=[{'itemId':p['itemId'],'reason':('에이블리 발송 실패 · ' if p['status']=='failed' else '에이블리 발송 보류 · ')+(p['reason'] or '')} for p in pushes if p['status']!='sent']
        result=matches(s,entries,'');groups=defaultdict(list)
        rows={r['key']:r for r in s['rows']}
        for e in result:
            if e['status']!='ready':
                counts['unmatched']+=1;issues.append({'itemId':e['itemId'],'reason':e.get('reason') or '주문번호 불일치'});continue
            groups[e['key']].append(e)
        if any(n['status']=='SENDING' and set(groups).intersection(n.get('itemKeys',[])) for n in s['notices']):
            raise AblySyncError('같은 주문의 고객 안내가 전송 중입니다. 전송 결과 확인 후 다시 동기화하세요.')
        for key,group in groups.items():
            if any(not e['dueDate'] for e in group):
                counts['missingDate']+=1;issues.append({'itemId':', '.join(e['itemId'] for e in group),'reason':'예상출고일 없음 · 기존 안내 유지'});continue
            facts=sorted([{k:e[k] for k in ('itemId','orderId','qty','startDate','dueDate','noticeDate')} for e in group],key=lambda e:e['itemId'])
            signature=hashlib.sha256(json.dumps(facts,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
            old=[n for n in s['notices'] if n.get('source')=='ably_sync' and key in n.get('itemKeys',[])]
            if old and old[-1].get('syncSignature')==signature:counts['unchanged']+=1;continue
            r=rows[key];due=max(e['dueDate'] for e in group)
            protected=any(not n.get('isTest') and n['status'] in ('PENDING','DELIVERED') and n.get('kind') in ('SMS','LMS','AT') and key in n.get('itemKeys',[]) for n in s['notices'])
            counts['protected']+=int(protected)
            note='에이블리 상품주문정보의 예상출고일을 읽었습니다. 날짜 범위는 마지막 날 적용. 사이트 안내 발송일은 별도 보관하며 앱의 실제 발송 성공 이력을 우선합니다.'
            pushed=[pushed_ids[e['itemId']] for e in group if e['itemId'] in pushed_ids]
            if pushed:note='앱의 안내 이력을 바탕으로 에이블리 배송지연 메시지 발송 처리를 실행한 뒤 읽은 예상출고일입니다. '+note
            s['notices'].append({'id':'ABLY-'+secrets.token_urlsafe(16),'ref':'','kind':'EXTERNAL','channel':'에이블리 출고 예정일 동기화',
                **({'pushedByApp':True,'pushedAt':stamp,'pushSources':[{k:p[k] for k in ('itemId','noticeId','dueDate','option')} for p in pushed]} if pushed else {}),
                'title':'에이블리 예상출고일','content':'사이트 조회 기록 · 앱에서 실제 발송 없음','phone':'','seller':ABLY,'orderId':r['orderId'],
                'dueDate':due,'noticeType':'delay','templateKey':'first','itemKeys':[key],
                'products':[{k:r[k] for k in ('product','option','qty')}], 'isTest':False,'status':'IMPORTED','source':'ably_sync',
                'manualAcknowledgement':True,'createdAt':stamp,'updatedAt':stamp,'importedAt':stamp,'logicalCreatedAt':stamp,
                'actualSendDateKnown':False,'platformNoticeDates':sorted({e['noticeDate'] for e in group if e['noticeDate']}),
                'sourceMappings':facts,'sourceReadAt':sorted({e['readAt'] or stamp for e in group}),
                'syncSignature':signature,'note':note,'events':[{'at':stamp,'status':'IMPORTED','note':note}]})
            counts['items']+=1
        if cache_key:
            cache=s.setdefault('ablySyncCache',{}).setdefault(cache_key,{})
            for e in entries:
                # Missing dates/errors stay retryable; unmatched IDs may match a
                # future order import, so retain their successful platform read.
                if e['dueDate']:
                    cache[e['itemId']]={k:e[k] for k in ('itemId','orderId','qty','range','noticeDate')}
                    cache[e['itemId']].update(noticeSent=True,readAt=e['readAt'] or stamp)
        message=f"전체 {counts['scanned']}개 상품 / {counts['pages']}페이지 · 신규 상세 조회 {counts['fresh']}개 · 기존 확인 {counts['cached']}개 재사용 · 미발송 {counts['skippedUnsent']}개 제외 · 새 이력 {counts['items']}개 · 동일 {counts['unchanged']}개 · 날짜 없음 {counts['missingDate']}개 · 미연결 {counts['unmatched']}개 · 고객 안내 우선 {counts['protected']}개"+push_message(counts)
        s['ablySync']={'lastSync':stamp,**counts,'message':message}
        s['audits'].append({'at':stamp,'event':'에이블리 출고 예정일 동기화',**counts})
    if engine.archive:engine.backup_desktop(force=True,reason='ably-sync')
    return {**counts,'message':message,'issues':issues[:200],'lastSync':stamp}

class AblySyncController:
    def __init__(self,engine,runner=None,vault=None):
        from ably_credentials import AblyAccounts
        self.engine=engine;self.runner=runner;self.accounts=AblyAccounts(engine.store.directory,vault)
        self.lock=threading.RLock();self.stop=threading.Event();self.thread=None;self.job={'phase':'idle','message':'동기화를 누르면 100개씩 모든 페이지를 확인합니다.'}
    def status(self):
        with self.lock:return {**copy.deepcopy(self.job),'running':bool(self.thread and self.thread.is_alive()),'lastSync':self.engine.store.read().get('ablySync',{}).get('lastSync','')}
    def settings(self):return self.accounts.info()
    def save(self,username,password):
        with self.lock:
            if self.thread and self.thread.is_alive():raise AblySyncError('동기화 중에는 계정을 변경할 수 없습니다.')
            return self.accounts.save(username,password)
    def start(self,push=False):
        with self.lock:
            if self.thread and self.thread.is_alive():raise AblySyncError('이미 동기화 중입니다.')
            cfg=self.engine.store.read()['settings']
            if not cfg.get('shopName'):raise AblySyncError('쇼핑몰 이름을 먼저 설정하세요.')
            account=self.accounts.for_login();account.update(shopName=cfg['shopName'],shopRevision=cfg.get('shopRevision',0));self.stop.clear()
            self.job={'id':secrets.token_urlsafe(16),'phase':'running','push':bool(push),'message':'전용 Chrome에서 에이블리를 엽니다.'}
            self.thread=threading.Thread(target=self._run,args=(account,bool(push)),daemon=True);self.thread.start()
            return self.status()
    def progress(self,message):
        with self.lock:self.job['message']=message
    def planner(self,items):
        """Called by the browser with the verified complete list; reads the store only."""
        from domain import today
        targets,skipped=plan_pushes(self.engine.store.read(),items,today())
        with self.lock:self.job['planned']={'targets':len(targets),'skipped':len(skipped)}
        return targets,skipped
    def _record_partial(self,pushes):
        """An Ably message is sent once: keep the outcome even if the list check failed."""
        if not pushes:return ''
        from domain import now
        with self.engine.network_lock,self.engine.store.edit() as s:counts=record_pushes(s,pushes,now())
        if self.engine.archive:self.engine.backup_desktop(force=True,reason='ably-push')
        return push_message(counts)+' (예상출고일 이력은 다음 동기화에서 반영)'
    def start_push_only(self,keys):
        """Send Ably 배송지연 messages for these app rows only (after a message-less acknowledgement).
        Ably dates are not imported; the app's own notice stays the source."""
        keys=[k for k in dict.fromkeys(keys or []) if isinstance(k,str)]
        if not keys:raise AblySyncError('에이블리 발송 처리할 주문상품이 없습니다.')
        with self.lock:
            if self.thread and self.thread.is_alive():raise AblySyncError('에이블리 동기화가 진행 중이라 자동 발송 처리를 시작하지 못했습니다. 끝난 뒤 전체 페이지 동기화(발송 처리 포함)를 실행하세요.')
            cfg=self.engine.store.read()['settings']
            if not cfg.get('shopName'):raise AblySyncError('쇼핑몰 이름을 먼저 설정하세요.')
            account=self.accounts.for_login();account.update(shopName=cfg['shopName'],shopRevision=cfg.get('shopRevision',0));self.stop.clear()
            self.job={'id':secrets.token_urlsafe(16),'phase':'running','push':True,'pushOnly':True,'keys':len(keys),'message':'메시지 없는 안내 → 에이블리 배송지연 메시지 발송 처리를 시작합니다.'}
            self.thread=threading.Thread(target=self._run_push_only,args=(account,keys),daemon=True);self.thread.start()
            return self.status()
    def planner_for(self,keys):
        wanted=set(keys)
        def planner(items):
            targets,skipped=self.planner(items)
            targets=[t for t in targets if t['key'] in wanted];skipped=[p for p in skipped if p['key'] in wanted]
            with self.lock:self.job['planned']={'targets':len(targets),'skipped':len(skipped)}
            return targets,skipped
        return planner
    def _run_push_only(self,account,keys):
        try:
            from ably_browser import collect
            runner=self.runner or collect
            snapshot=runner(account,self.stop,self.progress,{},self.planner_for(keys),push_only=True)
            pushes=validate_pushes(snapshot.get('pushes'))
            if self.stop.is_set() and not any(p['status']=='sent' for p in pushes):raise AblyCancelled('에이블리 발송 처리를 중단했습니다.')
            from domain import now
            with self.engine.network_lock,self.engine.store.edit() as s:counts=record_pushes(s,pushes,now())
            if pushes and self.engine.archive:self.engine.backup_desktop(force=True,reason='ably-push')
            planned=snapshot.get('planned',0)
            message=(push_message(counts) if pushes else '에이블리에서 발송 처리할 대상이 없습니다 (이미 발송됨 또는 에이블리 주문과 일치하지 않음).')
            message+=' · 에이블리 예상출고일은 가져오지 않았습니다.'
            with self.lock:self.job.update(phase='done',message=message,result={'counts':counts,'planned':planned,'issues':[{'itemId':p['itemId'],'reason':p.get('reason','')} for p in pushes if p['status']!='sent'][:200]})
            job_alert(self.engine,'에이블리 배송지연 메시지 자동 발송 처리 완료',message)
            blocked=[p for p in pushes if p['status'] in ('failed','skipped')]
            if blocked:
                lines=[f"상품주문번호 {p.get('itemId','')} · {'실패' if p.get('status')=='failed' else '보류'} · {p.get('reason','')}" for p in blocked[:15]]
                job_alert(self.engine,f'에이블리 배송지연 메시지 자동 발송 처리 막힘 {len(blocked)}건','\n'.join(lines)+('\n…' if len(blocked)>15 else ''),'error')
        except AblyPushAborted as exc:
            extra=self._record_partial(exc.pushes)
            with self.lock:self.job.update(phase='error',message=str(exc)+extra)
            job_alert(self.engine,'에이블리 자동 발송 처리 중단 (일부 기록)',str(exc)+extra,'error')
        except Exception as exc:
            detail='' if isinstance(exc,AblySyncError) else f' ({type(exc).__name__}: {self._safe(str(exc),account)})'
            with self.lock:self.job.update(phase='cancelled' if self.stop.is_set() else 'error',message=str(exc) if isinstance(exc,AblySyncError) else '에이블리 화면을 처리하지 못했습니다. 전체 페이지 동기화(발송 처리 포함)로 다시 시도하세요.'+detail+(' · 마지막 단계: '+self.job.get('message','') if self.job.get('message') else ''))
            if not self.stop.is_set():job_alert(self.engine,'에이블리 배송지연 메시지 자동 발송 처리 실패',self.job.get('message',''),'error')
        finally:account.clear()
    def progress(self,message):
        with self.lock:self.job['message']=message
    def planner(self,items):
        """Called by the browser with the verified complete list; reads the store only."""
        from domain import today
        targets,skipped=plan_pushes(self.engine.store.read(),items,today())
        with self.lock:self.job['planned']={'targets':len(targets),'skipped':len(skipped)}
        return targets,skipped
    def _record_partial(self,pushes):
        """An Ably message is sent once: keep the outcome even if the list check failed."""
        if not pushes:return ''
        from domain import now
        with self.engine.network_lock,self.engine.store.edit() as s:counts=record_pushes(s,pushes,now())
        if self.engine.archive:self.engine.backup_desktop(force=True,reason='ably-push')
        return push_message(counts)+' (예상출고일 이력은 다음 동기화에서 반영)'
    def _run(self,account,push=False):
        try:
            from ably_browser import collect
            cache_key=account_cache_key(account)
            cache=self.engine.store.read().get('ablySyncCache',{}).get(cache_key,{})
            runner=self.runner or collect
            snapshot=runner(account,self.stop,self.progress,copy.deepcopy(cache),self.planner) if push else runner(account,self.stop,self.progress,copy.deepcopy(cache))
            with self.lock:
                if self.stop.is_set() and not snapshot.get('pushes'):raise AblyCancelled('동기화를 중단했습니다. 수집한 일부 자료는 반영하지 않았습니다.')
                result=apply_snapshot(self.engine,snapshot,cache_key,{k:account[k] for k in ('shopName','shopRevision')})
                self.job.update(phase='done',message=result['message'],result=result)
            job_alert(self.engine,'에이블리 출고 예정일 동기화 완료',result['message'])
            blocked=[p for p in (snapshot.get('pushes') or []) if isinstance(p,dict) and p.get('status') in ('failed','skipped')]
            if blocked:
                lines=[f"상품주문번호 {p.get('itemId','')} · {'실패' if p.get('status')=='failed' else '보류'} · {p.get('reason','')}" for p in blocked[:15]]
                job_alert(self.engine,f'에이블리 배송지연 메시지 발송 처리 막힘 {len(blocked)}건','\n'.join(lines)+('\n…' if len(blocked)>15 else ''),'error')
        except AblyPushAborted as exc:
            extra=self._record_partial(exc.pushes)
            with self.lock:self.job.update(phase='error',message=str(exc)+extra,result={'issues':[{'itemId':p['itemId'],'reason':p.get('reason','')} for p in exc.pushes if p.get('status')!='sent'][:200]})
            job_alert(self.engine,'에이블리 동기화 중단 (발송 처리 일부 기록)',str(exc)+extra,'error')
        except Exception as exc:
            detail='' if isinstance(exc,AblySyncError) else f' ({type(exc).__name__}: {self._safe(str(exc),account)})'
            with self.lock:self.job.update(phase='cancelled' if self.stop.is_set() else 'error',message=str(exc) if isinstance(exc,AblySyncError) else '에이블리 화면을 처리하지 못했습니다. 기존 이력을 유지합니다. 동기화를 다시 실행하세요.'+detail+(' · 마지막 단계: '+self.job.get('message','') if self.job.get('message') else ''))
            if not self.stop.is_set():job_alert(self.engine,'에이블리 출고 예정일 동기화 실패',self.job.get('message',''),'error')
        finally:account.clear()
    @staticmethod
    def _safe(text,account):
        """First line of a browser error, never echoing the saved credentials."""
        line=(text or '').splitlines()[0] if text else ''
        for secret in (account.get('password',''),account.get('username','')):
            if secret:line=line.replace(secret,'***')
        return line[:200]
    def cancel(self):
        with self.lock:
            if self.thread and self.thread.is_alive() and self.job.get('phase')=='running':self.stop.set();self.job['message']='동기화를 중단하고 창을 닫는 중입니다.'
            return self.status()

# ---- 아무드(일본) 배송지연 메시지 발송 처리 (2026-10-21) — same Ably account/thread, japan tab only ----
def _amood_shop(engine):
    return engine.store.read()['settings'].get('shopName','') or ''

def _amood_start(self,targets_fn,preview=False,label=''):
    with self.lock:
        if self.thread and self.thread.is_alive():raise AblySyncError('에이블리 작업이 진행 중입니다. 끝난 뒤 다시 실행하세요.')
        cfg=self.engine.store.read()['settings']
        if not cfg.get('shopName'):raise AblySyncError('쇼핑몰 이름을 먼저 설정하세요.')
        account=self.accounts.for_login();account.update(shopName=cfg['shopName'],shopRevision=cfg.get('shopRevision',0));self.stop.clear()
        self.job={'id':secrets.token_urlsafe(16),'phase':'running','push':True,'amood':True,'preview':bool(preview),'message':label or '아무드 배송지연 메시지 발송 처리를 시작합니다.'}
        self.thread=threading.Thread(target=self._run_amood,args=(account,targets_fn,bool(preview)),daemon=True);self.thread.start()
        return self.status()

def start_amood_push(self,keys=None):
    """Send 아무드 delay messages for app-notified rows (keys=None: every active 아무드 row). 주문번호 matching only."""
    from domain import today
    from amood_push import plan_amood
    if keys is not None:
        keys=[k for k in dict.fromkeys(keys or []) if isinstance(k,str)]
        if not keys:raise AblySyncError('아무드 발송 처리할 주문상품이 없습니다.')
    def targets():
        return plan_amood(self.engine.store.read(),keys,today(),_amood_shop(self.engine))
    return self._amood_start(targets,False,'아무드 배송지연 메시지 발송 처리를 시작합니다.')

def start_amood_preview(self,order_id,due):
    """Test run for one 주문번호: select → 예상 출고일 → 지연 사유까지, then close without sending."""
    from domain import today
    from amood_push import order_key,reason_text,AMOOD
    oid=order_key(order_id)
    if not re.fullmatch(r'\d{1,30}',oid):raise AblySyncError('아무드 주문번호(숫자)를 입력하세요.')
    try:date.fromisoformat(due)
    except (ValueError,TypeError):raise AblySyncError('예상 출고일을 선택하세요.')
    option,reason=push_option(due,today())
    if not option:raise AblySyncError(reason)
    s=self.engine.store.read()
    rows=[r for r in s.get('rows',[]) if r.get('active') and r.get('seller')==AMOOD and order_key(r.get('orderId'))==oid] or [{'product':'(앱에 이 주문번호의 아무드 주문 없음 · 미리보기용)','option':'','qty':1}]
    ids=[order_key(p.get('id')) for r in rows for p in (r.get('orderItems') or []) if p.get('id')] or [order_key(x) for r in rows for x in (r.get('exportOrderItemIds') or []) if x]
    target={'orderId':oid,'keys':[r['key'] for r in rows if 'key' in r],'noticeIds':[],'dueDate':due,'option':option,'reason':reason_text(_amood_shop(self.engine),rows,due),
            'itemIds':sorted(set(ids)) if all((r.get('orderItems') or r.get('exportOrderItemIds')) for r in rows if 'key' in r) and ids else []}
    return self._amood_start(lambda:([target],[]),True,f'아무드 미리보기 (주문번호 {oid} · 발송 안 함)')

def _run_amood(self,account,targets_fn,preview):
    from domain import now
    try:
        targets,skipped=targets_fn()
        with self.lock:self.job['planned']={'targets':len(targets),'skipped':len(skipped)}
        results=[]
        if targets:
            import amood_push
            runner=getattr(self,'amood_runner',None) or amood_push.run
            out=runner(account,self.stop,self.progress,targets,preview)
            results=out.get('results',[]);steps=out.get('steps',[])
        else:steps=[]
        if preview:
            r=results[0] if results else {}
            message=('아무드 미리보기 완료 · 발송하지 않았습니다.' if r.get('status')=='preview' else '아무드 미리보기 결과: '+(r.get('reason') or r.get('status') or '대상 없음'))
            issues=[{'itemId':'','label':'단계','reason':x} for x in steps]+([{'itemId':'','label':'지연 사유','reason':targets[0]['reason']}] if targets else [])
            with self.lock:self.job.update(phase='done' if r.get('status')=='preview' else 'error',message=message,result={'issues':issues[:200]})
            return
        from amood_push import record_amood,amood_message
        stamp=now();allr=list(skipped)+list(results)
        with self.engine.network_lock,self.engine.store.edit() as s:counts=record_amood(s,allr,stamp)
        if allr and self.engine.archive:self.engine.backup_desktop(force=True,reason='amood-push')
        message=amood_message(counts) if allr else '아무드에서 발송 처리할 대상이 없습니다 (앱 안내 없음 또는 이미 발송).'
        issues=[{'itemId':p['orderId'],'label':'주문번호 '+p['orderId'],'reason':('실패 · ' if p['status']=='failed' else '이미 발송 · ' if p['status']=='already' else '보류 · ')+(p.get('reason') or '')} for p in allr if p['status']!='sent']
        with self.lock:self.job.update(phase='done',message=message,result={'counts':counts,'issues':issues[:200]})
        job_alert(self.engine,'아무드 배송지연 메시지 발송 처리 완료',message)
        blocked=[p for p in allr if p['status'] in ('failed','skipped')]
        if blocked:
            lines=[f"주문번호 {p['orderId']} · {'실패' if p['status']=='failed' else '보류'} · {p.get('reason','')}" for p in blocked[:15]]
            job_alert(self.engine,f'아무드 배송지연 메시지 발송 처리 막힘 {len(blocked)}건','\n'.join(lines)+('\n…' if len(blocked)>15 else ''),'error')
    except Exception as exc:
        detail='' if isinstance(exc,AblySyncError) else f' ({type(exc).__name__}: {self._safe(str(exc),account)})'
        with self.lock:self.job.update(phase='cancelled' if self.stop.is_set() else 'error',message=(str(exc) if isinstance(exc,AblySyncError) else '아무드 화면을 처리하지 못했습니다.'+detail)+(' · 마지막 단계: '+self.job.get('message','') if self.job.get('message') else ''))
        if not self.stop.is_set() and not preview:job_alert(self.engine,'아무드 배송지연 메시지 발송 처리 실패',self.job.get('message',''),'error')
    finally:account.clear()

AblySyncController._amood_start=_amood_start
AblySyncController.start_amood_push=start_amood_push
AblySyncController.start_amood_preview=start_amood_preview
AblySyncController._run_amood=_run_amood
