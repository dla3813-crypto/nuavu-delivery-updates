"""[배포판 이식본] v0.6.150 (2026-11-03 18:09 요청)
1) 반품 안내 문자 수신번호 보완 — 자사몰 반품(카페24 목록에 연락처 없음)·지그재그(안심번호)는 앱에 불러온 주문의 수령자/주문자 휴대폰을 쓴다.
2) 새 안내 '자사몰(무통장/반품도착)' — 자사몰 반품에만. 교환·다른 판매처는 거부.
3) 발송실패 표시 지우기 — 선택한 상품의 실패 문자를 failureDismissed 처리 → 발송실패 배지에서 빠지고 이력은 남는다."""
import sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from domain import Store,Engine,ValidationError,today,now
from return_messages import RETURN_REFUND_ACCOUNT,RETURN_NOTICE_TYPES
from clock_helper import install_day_clock

class FakeProvider:
    def send(self,*a,**k):return 1
    def remaining(self,*a):return '0'
    def report(self,*a):return []

def order(seller,order_id,item_id,phone='',recipient_mobile='',buyer_mobile='',active=True):
    return dict(seller=seller,orderId=order_id,product='테스트 상품',option='블랙',qty=1,orderDate=today(),orderTimestamp=today()+' 10:00:00',
                buyer='고객',recipient='',phone=phone,phoneSource='수령자',needsPhoneApproval=False,
                orderItemId=item_id,orderItems=[{'id':item_id,'qty':1}],orderItemIdMapped=True,exportOrderItemIds=[item_id],
                exportContacts={'recipientMobile':recipient_mobile,'recipientPhone':'','buyerPhone':'','buyerMobile':buyer_mobile})

def ret(seller,order_id,item_id,invoice,phone='',kind='return'):
    return {'seller':seller,'kind':kind,'orderId':order_id,'itemId':item_id,'product':'테스트 상품','option':'블랙','qty':1,
            'requestedAt':today(),'reason':'고객 변심','fee':0,'customer':'고객','recipient':'고객','recipientPhone':phone,
            'invoice':invoice,'returnStatus':'DELIVERED','returnDelivered':today(),'origDelivered':today(),'requestId':item_id}

class Base(unittest.TestCase):
    def setUp(self):
        install_day_clock(self)
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(self.tmp.name);self.engine=Engine(self.store,FakeProvider())
        with self.store.edit() as s:s['settings']['shopName']='누아브'   # 배포판: 판매처 이름을 쇼핑몰 이름으로 정규화하므로 필요
    def tearDown(self):
        try:self.engine.stop.set()
        except Exception:pass
        self.tmp.cleanup()
    def put_returns(self,rows,exchange=()):
        with self.store.edit() as s:
            cfg={'shopName':s['settings'].get('shopName') or '누아브','shopRevision':s['settings'].get('shopRevision',0)}
            s['returnCheck']={**cfg,'rows':list(rows)}
            s['exchangeCheck']={**cfg,'rows':list(exchange)}

class ReturnPhoneFallback(Base):
    def test_cafe24_return_without_phone_uses_order_recipient_mobile(self):
        self.engine.import_rows({'rows':[order('누아브 자사몰','20261101-0000123','20261101-0000123-01',phone='01012345678',recipient_mobile='01012345678')],'mode':'merge'})
        self.put_returns([ret('자사몰','20261101-0000123','20261101-0000123-01','6100000000001')])
        pv=self.engine.return_message_preview({'invoice':'6100000000001','kind':'return_not_defect'})
        self.assertTrue(pv['phoneOk']);self.assertEqual(pv['phone'],'01012345678');self.assertIn('주문 데이터',pv['phoneSource'])
    def test_zigzag_safe_number_replaced_by_order_phone(self):
        self.engine.import_rows({'rows':[order('누아브 지그재그','Z-777','Z-777-1',phone='01099998888',recipient_mobile='01099998888')],'mode':'merge'})
        self.put_returns([ret('지그재그','Z-777','Z-777-1','6100000000002',phone='0502-1234-5678')])
        pv=self.engine.return_message_preview({'invoice':'6100000000002','kind':'return_not_defect'})
        self.assertTrue(pv['phoneOk']);self.assertEqual(pv['phone'],'01099998888')
    def test_return_list_phone_kept_when_valid(self):
        self.engine.import_rows({'rows':[order('누아브 지그재그','Z-1','Z-1-1',phone='01011112222',recipient_mobile='01011112222')],'mode':'merge'})
        self.put_returns([ret('지그재그','Z-1','Z-1-1','6100000000003',phone='010-3333-4444')])
        pv=self.engine.return_message_preview({'invoice':'6100000000003','kind':'return_not_defect'})
        self.assertEqual(pv['phone'],'01033334444');self.assertEqual(pv['phoneSource'],'반품 목록')
    def test_inactive_shipped_order_still_provides_phone(self):
        # 출고되어 목록에서 제외된 주문도 전화번호 출처가 된다 (반품은 보통 출고 뒤에 들어온다)
        self.engine.import_rows({'rows':[order('누아브 자사몰','20261001-0000001','20261001-0000001-01',phone='01055556666',recipient_mobile='01055556666')],'mode':'merge'})
        self.engine.import_rows({'rows':[],'mode':'snapshot','scope':['누아브 자사몰'],'replaceConfirmed':True,'emptyConfirmed':True})
        self.assertFalse(any(r['active'] for r in self.store.read()['rows'] if r['seller']=='누아브 자사몰'))
        self.put_returns([ret('자사몰','20261001-0000001','20261001-0000001-01','6100000000004')])
        pv=self.engine.return_message_preview({'invoice':'6100000000004','kind':'return_not_defect'})
        self.assertTrue(pv['phoneOk']);self.assertEqual(pv['phone'],'01055556666')
    def test_no_phone_anywhere_blocks_send(self):
        self.put_returns([ret('자사몰','20261101-0000999','20261101-0000999-01','6100000000005')])
        pv=self.engine.return_message_preview({'invoice':'6100000000005','kind':'return_not_defect'})
        self.assertFalse(pv['phoneOk'])
        with self.assertRaises(ValidationError):self.engine.return_message_send({'invoice':'6100000000005','kind':'return_not_defect','sendMode':'IMMEDIATE'})

class RefundAccountNotice(Base):
    def test_kind_registered_and_template(self):
        self.assertIn('return_refund_account',RETURN_NOTICE_TYPES)
        self.assertIn('왕복 배송비 6,000원을 제외한 금액으로 환불',RETURN_REFUND_ACCOUNT);self.assertIn('계좌번호(은행명, 예금주 포함)',RETURN_REFUND_ACCOUNT)
    def test_preview_for_cafe24_return(self):
        self.engine.import_rows({'rows':[order('누아브 자사몰','20261101-0000123','20261101-0000123-01',phone='01012345678',recipient_mobile='01012345678')],'mode':'merge'})
        self.put_returns([ret('자사몰','20261101-0000123','20261101-0000123-01','6100000000001')])
        pv=self.engine.return_message_preview({'invoice':'6100000000001','kind':'return_refund_account'})
        self.assertTrue(pv['content'].startswith('안녕하세요 고객님\n누아브입니다.\n\n보내주신 반품 상품이 도착하여 연락드립니다.'))
        self.assertTrue(pv['content'].endswith('감사합니다.'));self.assertTrue(pv['phoneOk'])
    def test_rejected_for_other_sellers_and_exchange(self):
        self.engine.import_rows({'rows':[order('누아브 지그재그','Z-9','Z-9-1',phone='01012345678',recipient_mobile='01012345678'),
                                         order('누아브 자사몰','20261101-0000555','20261101-0000555-01',phone='01012340000',recipient_mobile='01012340000')],'mode':'merge'})
        self.put_returns([ret('지그재그','Z-9','Z-9-1','6100000000010')],exchange=[ret('자사몰','20261101-0000555','20261101-0000555-01','6100000000011',kind='exchange')])
        with self.assertRaises(ValidationError) as c:self.engine.return_message_preview({'invoice':'6100000000010','kind':'return_refund_account'})
        self.assertIn('자사몰 반품에만',str(c.exception))
        with self.assertRaises(ValidationError) as c:self.engine.return_message_preview({'invoice':'6100000000011','kind':'return_refund_account'})
        self.assertIn('교환 건',str(c.exception))
    def test_view_exposes_refund_account_state(self):
        from aftersales_data import public_aftersales
        from datetime import date
        self.put_returns([ret('자사몰','20261101-0000123','20261101-0000123-01','6100000000001')])
        v=public_aftersales(self.store.read(),date.fromisoformat(today()))
        self.assertIn('refundAccountNotice',v['rows'][0])

class FailedDismiss(Base):
    def _failed_row(self):
        self.engine.import_rows({'rows':[order('누아브 에이블리','A-1','A-1-1',phone='01012345678',recipient_mobile='01012345678')],'mode':'merge'})
        with self.store.edit() as s:
            r=s['rows'][0]
            s['notices'].append({'id':'n-fail','kind':'SMS','status':'FAILED','createdAt':now(),'sentAt':now(),'itemKeys':[r['key']],'noticeType':'delay','content':'x','phone':'01012345678','isTest':False,'reason':'실패'})
            s.setdefault('alerts',[]).append({'id':'a1','noticeId':'n-fail','title':'문자 발송 실패','acknowledgedAt':None})
        return r['key']
    def test_failed_row_shows_then_dismiss_clears_badge_keeps_history(self):
        key=self._failed_row()
        st=self.engine.public_state();row=[r for r in st['rows'] if r['key']==key][0]
        self.assertEqual(row['color'],'failed');self.assertEqual(row['failedNoticeId'],'n-fail')
        res=self.engine.dismiss_failures({'keys':[key]})
        self.assertEqual(res['cleared'],1)
        st=self.engine.public_state();row=[r for r in st['rows'] if r['key']==key][0]
        self.assertNotEqual(row['color'],'failed');self.assertEqual(row['failedNoticeId'],'')
        s=self.store.read();n=[n for n in s['notices'] if n['id']=='n-fail'][0]
        self.assertEqual(n['status'],'FAILED');self.assertTrue(n['failureDismissed'])   # 이력·결과는 그대로
        self.assertTrue(all(a['acknowledgedAt'] for a in s['alerts'] if a.get('noticeId')=='n-fail'))
        self.assertTrue(any('발송실패 표시 지움' in a.get('event','') for a in s['audits']))
    def test_dismiss_requires_selection_and_rejects_nothing_to_clear(self):
        with self.assertRaises(ValidationError):self.engine.dismiss_failures({'keys':[]})
        key=self._failed_row()
        self.engine.dismiss_failures({'keys':[key]})
        with self.assertRaises(ValidationError):self.engine.dismiss_failures({'keys':[key]})   # 이미 지움
    def test_dismiss_does_not_touch_delivered_notices(self):
        key=self._failed_row()
        with self.store.edit() as s:s['notices'].append({'id':'n-ok','kind':'SMS','status':'DELIVERED','createdAt':now(),'sentAt':now(),'itemKeys':[key],'noticeType':'delay','content':'x','phone':'01012345678','isTest':False})
        self.engine.dismiss_failures({'keys':[key]})
        s=self.store.read();self.assertFalse([n for n in s['notices'] if n['id']=='n-ok'][0].get('failureDismissed'))

if __name__=='__main__':unittest.main()
