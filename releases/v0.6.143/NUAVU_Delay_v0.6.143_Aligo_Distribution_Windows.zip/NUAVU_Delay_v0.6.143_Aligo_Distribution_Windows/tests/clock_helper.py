"""Freeze pre-scheduling regression tests in the daytime, independent of CI wall time."""
from datetime import datetime,timedelta,timezone
from unittest.mock import patch
class DayClock(datetime):
    current=datetime(2026,10,14,10,0,tzinfo=timezone(timedelta(hours=9)))
    @classmethod
    def now(cls,tz=None):
        return cls.current.astimezone(tz) if tz else cls.current.replace(tzinfo=None)
def install_day_clock(case):
    p=patch('domain.datetime',DayClock);p.start();case.addCleanup(p.stop)
