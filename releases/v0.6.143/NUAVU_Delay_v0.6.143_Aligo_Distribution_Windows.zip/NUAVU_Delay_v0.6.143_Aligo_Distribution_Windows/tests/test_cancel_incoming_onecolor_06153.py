"""v0.6.153 (2026-11-04 04:39) — 누아브판·배포판 공용
- 원컬러 발주 행(컬러 칸에 사이즈만, 사이즈 칸 공란) ↔ 주문 [원컬러-L] 매칭
- 컬러 칸 빈 발주 행은 어느 주문 컬러와도 맞음 (컬러 하나짜리 상품)
- 입고 예정이 있는 주문은 중국 취소건 표시 제외"""
import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from supply_workflow import candidates,variant_id,source_color_size
import china_cancel as cc

def variant(product,color,size,brand='N',kind='progress',qty=2,purchase='2026-10-28'):
    r={'brand':brand,'product':product,'color':color,'size':size,'qty':qty,'sheet':'진행상황','line':1,'sourceFile':'진행상황.xlsx','kind':kind,
       'shipDate':'','basisDate':'','officeDate':'','officeRaw':'','purchaseDate':purchase,'basisType':'office'}
    r['variant']=variant_id(r);return r

class OneColorSourceRows(unittest.TestCase):
    def test_size_in_color_column(self):
        self.assertEqual(source_color_size({'color':'L','size':''}),('','L'))
        self.assertEqual(source_color_size({'color':'XL(77)','size':''}),('','XL(77)'))
        self.assertEqual(source_color_size({'color':'','size':'M'}),('','M'))
        self.assertEqual(source_color_size({'color':'블랙','size':'M'}),('블랙','M'))
        self.assertEqual(source_color_size({'color':'블랙','size':''}),('블랙',''))   # 사이즈 칸만 빈 보통 행은 그대로
    def test_real_case_pleats_pants(self):
        vs=[variant('[레이어드 스커트 일체형]블랙 플리츠 레이어드 롱 팬츠','M',''),variant('[레이어드 스커트 일체형]블랙 플리츠 레이어드 롱 팬츠','S',''),variant('[레이어드 스커트 일체형]블랙 플리츠 레이어드 롱 팬츠','L','')]
        for size,expect in (('L','L'),('M','M')):
            hits,amb,how=candidates({'product':'(SC-8)[레이어드 스커트 일체형]블랙 플리츠 레이어드 롱 팬츠','option':f'[원컬러-{size}]'},vs,{})
            self.assertEqual([h['color'] for h in hits],[expect],size);self.assertFalse(amb)
        hits,amb,how=candidates({'product':'(SC-8)[레이어드 스커트 일체형]블랙 플리츠 레이어드 롱 팬츠','option':'[원컬러-XL]'},vs,{});self.assertEqual(hits,[])
    def test_blank_color_source_matches_any_order_color(self):
        vs=[variant('루미 나폴레옹 버튼 브이넥 반팔 티셔츠','','F')]
        hits,_,_=candidates({'product':'루미 나폴레옹 버튼 브이넥 반팔 티셔츠','option':'[블랙-FREE]'},vs,{});self.assertEqual(len(hits),1)
        hits,_,_=candidates({'product':'루미 나폴레옹 버튼 브이넥 반팔 티셔츠','option':'[원컬러-FREE]'},vs,{});self.assertEqual(len(hits),1)
    def test_colored_source_still_requires_color(self):
        vs=[variant('양털 오버핏 후리스 집업','카키','F')]
        hits,_,_=candidates({'product':'[5color]양털 오버핏 후리스 집업','option':'[블랙-FREE]'},vs,{});self.assertEqual(hits,[])

class IncomingSuppressesCancel(unittest.TestCase):
    def test_incoming_qty_clears_flag(self):
        s={'rows':[{'key':'a','active':True,'chinaCancel':{'match':'manual','stage':2},'incomingQty':8,'supplyInfo':{'sources':[{'kind':'progress','officeDate':''}]}},
                   {'key':'b','active':True,'chinaCancel':{'match':'manual','stage':2},'incomingQty':0,'supplyInfo':{'sources':[]}},
                   {'key':'c','active':True,'chinaCancel':{'match':'auto','stage':1},'supplyInfo':{'incomingQty':3,'sources':[]}}]}
        cc.suppress_supplied(s)
        self.assertIsNone(s['rows'][0].get('chinaCancel'));self.assertTrue(s['rows'][1].get('chinaCancel'));self.assertIsNone(s['rows'][2].get('chinaCancel'))

if __name__=='__main__':unittest.main()
