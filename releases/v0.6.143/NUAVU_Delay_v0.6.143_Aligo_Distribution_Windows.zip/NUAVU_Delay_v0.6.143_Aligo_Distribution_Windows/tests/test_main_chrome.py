"""2026-11-01 요청: "내 메인 크롬 작동해서 써라" — main_chrome.py (AppleScript 로 메인 Chrome).
osascript 대신 가짜 Chrome(Playwright Chromium + 가짜 이지어드민 화면)으로 페이지 코드까지 실제로 돌려 본다."""
import sys,json,tempfile,threading,time,unittest,subprocess
from datetime import datetime
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT)]
import main_chrome as mc
import order_browser as ob
from order_auto import KST,OrderAutoError

STYLE='style="display:none;width:200px;height:60px;background-image:url(/images/{img})"'
DS00='''<!doctype html><meta charset=utf-8><title>확장주문검색2</title><body>
<a href="/logout.php">로그아웃</a>
<select name="date_type"><option value="a">주문일</option><option value="b">발주일</option></select>
<select id="date_period_sel" onchange="window.periodChanged=this.value"><option value="0">오늘</option><option value="m">최근한달</option></select>
<select name="status_sel"><option value="1">전체</option><option value="2">접수+송장</option></select>
<select name="order_cs_sel"><option value="0">정상</option><option value="9">정상+교환</option></select>
<input type=checkbox id=is_packed checked>
<select id="str_supply_code"><option value="5">x</option><option value="0">전체</option></select>
<select id="trans_corp"><option value="1">a</option><option value="99">전체</option></select>
<input name="table_search_row_query_str" value="abc">
<span onclick="javascript:openWinShopDetail()">판매처 상세</span>
<select id="str_shop_code"><option id="shop_code_all" value="0">전체</option><option value="7">에이블리</option></select><input type=hidden id=multi_shop value="x"><input type=hidden id=multi_shop_group value="">
<div id="s2id_str_shop_code"><a class="select2-choice"><span>전체</span></a></div>
<button id="search" onclick="doSearch()">검색</button>
<div id="load_grid1" style="display:none">loading</div><table id="grid1"></table><div id="gridpager">표시할 행이 없습니다</div>
<select id="download_type"><option>주문단위</option><option>상품단위</option></select>
<select id="download_field"><option>기본</option><option>배송지연 전체품목</option></select>
<input type=checkbox id=include_sum>
<button id="download" onclick="startDl()">다운로드</button>
<div id="pop_download_info" STYLE1><button id="btn_download_info1" onclick="hide('pop_download_info');show('pop_personal_information')">신청</button></div>
<div id="pop_personal_information" STYLE2><button class="btn_cnf" onclick="hide('pop_personal_information');show('swal')">확인</button></div>
<div id="swal" role="dialog" style="display:none">다운로드 안내 <input id="swal2-input"><button onclick="ack()">확인</button></div>
<div id="pop_download_complete" STYLE3>done</div>
<script>
function show(i){document.getElementById(i).style.display='block'} function hide(i){document.getElementById(i).style.display='none'}
function openWinShopDetail(){window.open('popup25.htm?template=C120','supply_detail','width=900,height=800')}
window.setGroup=function(){document.querySelector('#str_shop_code').value='d'}
function doSearch(){window.searchedGroup=document.getElementById('multi_shop_group').value;fetch('/api/searched?g='+window.searchedGroup);show('load_grid1');setTimeout(function(){hide('load_grid1');
 if(MODE!=='zero'){document.getElementById('grid1').innerHTML='<tr class="jqgrow"><td>1</td></tr><tr class="jqgrow"><td>2</td></tr>';document.getElementById('gridpager').textContent='1 - 2';}},300)}
function startDl(){if(MODE==='captcha'){show('captcha');return}alert('다운로드를 시작합니다');show('pop_download_info')}
function ack(){if(document.getElementById('swal2-input').value!=='확인했습니다'){alert('확인했습니다를 입력하세요');return}
 fetch('/api/request',{method:'POST'}).then(function(){hide('swal');show('pop_download_complete')})}
</script><div id="captcha" style="display:none">캡차</div>'''.replace('STYLE1',STYLE.format(img='download_info_request.png')).replace('STYLE2',STYLE.format(img='personal_infomation_popup.png')).replace('STYLE3',STYLE.format(img='download_info_complete.png'))
C120='''<!doctype html><meta charset=utf-8><ul><li><input class="chk_group" type=checkbox group_id="3" checked> 기본</li><li><input class="chk_group" type=checkbox group_id="12"> 솔리아,누아브 </li></ul>
<span onclick="javascript:set_shop_group()">적용</span><script>function set_shop_group(){opener.setGroup();window.close()}</script>'''
BL30='''<!doctype html><meta charset=utf-8><a href="/logout.php">로그아웃</a><button id="search" onclick="load()">검색</button>
<div id="load_grid1" style="display:none">loading</div><table id="grid1"></table><div id="gridpager"></div>
<script>function load(){document.getElementById('load_grid1').style.display='block';fetch('/api/jobs').then(r=>r.json()).then(js=>{
 document.getElementById('grid1').innerHTML=js.map(j=>'<tr class="jqgrow"><td><input class="del_worklist" value="'+j.id+'"></td><td aria-describedby="grid1_crdate">'+j.at+'</td><td aria-describedby="grid1_template">확장주문검색2</td><td aria-describedby="grid1_file_name"><a download href="https://ga90.ezadmin.co.kr/data/danimstudio/'+encodeURIComponent(j.name)+'">'+j.name+'</a></td><td aria-describedby="grid1_status">'+j.status+'</td></tr>').join('');
 document.getElementById('gridpager').textContent=js.length?'1 - '+js.length:'표시할 행이 없습니다';document.getElementById('load_grid1').style.display='none';})}
load()</script>'''
LOGIN='<!doctype html><meta charset=utf-8><input id="login-domain">'
DATA=b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1'+bytes(range(256))*300   # 76.8KB 바이너리 (청크·base64 확인)

class FakeEz:
    def __init__(self,mode='ok',logged_in=True):
        self.searched=None;self.file_hits=0;self.hosts=set();self.mode=mode;self.logged_in=logged_in;self.jobs=[];self.loads=0
    def route(self,route):
        u=route.request.url;from urllib.parse import urlsplit as _us;host=_us(u).hostname;path=u.split(host,1)[-1]
        if host and host.startswith('ga') and host!='ga90.ezadmin.co.kr':self.hosts.add(host)
        if host=='ga90.ezadmin.co.kr':   # 파일 서버 (다른 출처 · CORS 없음)
            origin=route.request.headers.get('origin','')
            if origin and 'ga90.ezadmin.co.kr' not in origin:return route.abort('failed')   # 실제 사이트: ga79 에서 fetch → Failed to fetch
            if path.startswith('/data/danimstudio/') and path!='/data/danimstudio/':self.file_hits+=1;return route.fulfill(body=DATA,content_type='application/vnd.ms-excel')
            return route.fulfill(status=403,content_type='text/html',body='<title>403 Forbidden</title>Forbidden')
        if 'login2.ezadmin.co.kr' in u:return route.fulfill(content_type='text/html',body=LOGIN)
        if not self.logged_in and 'template' in path:return route.fulfill(content_type='text/html',body='<script>location.replace("https://login2.ezadmin.co.kr/login.htm")</script>')
        if path.startswith('/template35.htm'):return route.fulfill(content_type='text/html',body=DS00.replace('MODE',json.dumps(self.mode)))
        if path.startswith('/popup25.htm'):return route.fulfill(content_type='text/html',body=C120)
        if path.startswith('/template40.htm'):return route.fulfill(content_type='text/html',body=BL30)
        if path.startswith('/api/searched'):self.searched=path.split('g=',1)[-1];return route.fulfill(body='{}')
        if path=='/api/request':
            now=datetime.now(KST);self.jobs.append({'id':'77','at':now.strftime('%Y-%m-%d %H:%M:%S'),'name':f'확장주문검색_{now:%Y%m%d%H%M%S}_1.xls','status':'진행'})
            return route.fulfill(body='{}')
        if path=='/api/jobs':
            self.loads+=1
            if self.loads>=3:
                for j in self.jobs:j['status']='완료'
            return route.fulfill(content_type='application/json',body=json.dumps(self.jobs))
        if path.startswith('/images/'):return route.fulfill(body=b'',content_type='image/png')
        return route.fulfill(status=404,body='')

class FakeChrome:
    """osascript 명령(open/find/info/js/close)을 Playwright 탭으로."""
    def __init__(self,context,off=()):
        self.ctx=context;self.ids={};self.next=100;self.calls=[];self.win={};self.off=set(off);self.opened_in=[]
        context.on('page',self.track)
    def track(self,page):
        if page not in self.ids.values():self.next+=1;self.ids[str(self.next)]=page
    def __call__(self,cmd,*a):
        self.calls.append(cmd)
        if cmd=='open':   # 창 '1'(탭 많음) · '2'(이지어드민 탭) — 프로필이 다를 수 있음
            url,pref,skip=a
            cands=[w for w in ('1','2') if f',{w},' not in skip]
            if not cands:return 'none'
            w=pref if pref in cands else cands[0]
            p=self.ctx.new_page();self.track(p);p.goto(url);tid=[k for k,v in self.ids.items() if v is p][0]
            self.win[tid]=w;self.opened_in.append(w);return tid+' '+w
        if cmd=='find':return '\n'.join(k for k,p in self.ids.items() if not p.is_closed() and a[0] in p.url)
        p=self.ids.get(str(a[0]))
        if cmd=='info':
            if p is None or p.is_closed():return 'gone'
            return 'false\n'+p.url
        if cmd=='close':
            if p and not p.is_closed():p.close()
            return 'closed'
        if cmd=='js':
            if p is None or p.is_closed():raise mc.TabGone('gone')
            if self.win.get(str(a[0])) in self.off:raise OrderAutoError(mc.JS_OFF_MESSAGE)
            p.wait_for_timeout(20)
            return p.evaluate(a[1])
        raise AssertionError(cmd)

class Ctl:
    def __init__(self):self.updates=[];self.alerts=[];self.actions=[];self.captcha_hold=False
    def update(self,phase,msg):self.updates.append((phase,msg))
    def alert(self,*a):self.alerts.append(a)
    def check(self):pass
    def captcha_wait(self,msg):self.updates.append(('captcha',msg))
    def take_browser_action(self):return self.actions.pop(0) if self.actions else None
    def end_browser_recovery(self):pass

def browser():
    from playwright.sync_api import sync_playwright
    pw=sync_playwright().start();b=pw.chromium.launch();return pw,b

class EndToEnd(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.pw,cls.b=browser()
    @classmethod
    def tearDownClass(cls):cls.b.close();cls.pw.stop()
    def run_flow(self,ez,cfg_extra=None,off=(),pre=('https://ga79.ezadmin.co.kr/index.htm',)):
        ctx=self.b.new_context();ctx.route('https://**/*',ez.route)
        fake=FakeChrome(ctx,off);ctl=Ctl();self.fake=fake
        for u in pre:   # 사장님이 열어 둔 이지어드민 탭
            p=ctx.new_page();fake.track(p);p.goto(u)
        self.pre=len(pre)
        with tempfile.TemporaryDirectory() as tmp,patch.object(ob,'JOB_POLL_SECONDS',1),patch.object(ob,'RETRY_WAIT',0),patch.object(ob,'RETRY_TIMES',0):
            cfg={'group':'솔리아,누아브','folder':tmp,**(cfg_extra or {})}
            try:
                out=mc.run(ctl,cfg,flow_factory=lambda c:mc.MainChromeFlow(c,osa_call=fake))
                saved=[(x.name,x.read_bytes()) for x in sorted(Path(tmp).iterdir())] if out else []
                return out,saved,ctl,fake,[p for p in ctx.pages if not p.is_closed()][self.pre:]
            finally:ctx.close()
    def test_full_import_in_main_chrome(self):
        ez=FakeEz()
        (name,data),saved,ctl,fake,left=self.run_flow(ez)
        self.assertRegex(name,r'확장주문검색_\d{14}_1\.xls');self.assertEqual(data,DATA)
        self.assertEqual(saved,[(name,DATA)])
        self.assertEqual(left,[],'앱이 연 탭은 모두 닫는다')
        self.assertEqual(len(ez.jobs),1,'엑셀 신청은 한 번만')
        self.assertEqual(ez.searched,'12','판매처 그룹 번호로 조회')
        self.assertEqual(ez.file_hits,1,'파일 서버(ga90) 탭에서 한 번 받음')
        self.assertTrue(any('[메인 Chrome]' in m for _,m in ctl.updates))
    def test_profile_with_js_off_is_skipped(self):
        # 2026-11-01 21:34 "허용되어있는데?" — 허용은 Chrome 프로필마다 따로. 꺼진 창(1)은 건너뛰고 켜진 창(2)에서 끝까지.
        ez=FakeEz()
        (name,data),saved,ctl,fake,left=self.run_flow(ez,off={'1'})
        self.assertEqual(data,DATA);self.assertEqual(left,[])
        self.assertEqual(fake.opened_in[0],'1');self.assertTrue(all(w=='2' for w in fake.opened_in[1:]),fake.opened_in)
    def test_every_profile_off_explains(self):
        with self.assertRaises(OrderAutoError) as c:self.run_flow(FakeEz(),off={'1','2'})
        self.assertIn('프로필마다',str(c.exception))
    def test_admin_server_from_open_tab(self):
        # 배포판: 업체마다 관리자 서버가 다름 → 열려 있는 이지어드민 탭의 서버(ga55)를 쓴다.
        ez=FakeEz()
        (name,data),saved,ctl,fake,left=self.run_flow(ez,pre=['https://ga55.ezadmin.co.kr/index.htm'])
        self.assertEqual(data,DATA);self.assertEqual(left,[])
        self.assertTrue(ez.hosts and all(h in ('ga55.ezadmin.co.kr','ga90.ezadmin.co.kr') for h in ez.hosts),ez.hosts)
    def test_two_admin_servers_stop(self):
        with self.assertRaises(OrderAutoError) as c:
            self.run_flow(FakeEz(),pre=['https://ga55.ezadmin.co.kr/index.htm','https://ga12.ezadmin.co.kr/index.htm'])
        self.assertIn('서로 다른 이지어드민 서버',str(c.exception))
    def test_no_admin_tab_without_fixed_server(self):
        with patch.object(ob,'SEARCH_URL',None,create=True):
            with self.assertRaises(OrderAutoError) as c:self.run_flow(FakeEz(),pre=())
        self.assertIn('관리자 화면 탭을 하나 열어',str(c.exception))
    def test_logged_out_stops_without_password(self):
        ez=FakeEz(logged_in=False)
        with self.assertRaises(OrderAutoError) as c:self.run_flow(ez)
        self.assertIn('로그인이 풀려 있습니다',str(c.exception));self.assertIn('비밀번호를 입력하지 않습니다',str(c.exception))
        self.assertEqual(ez.jobs,[])
    def test_zero_rows_keeps_orders(self):
        with self.assertRaises(OrderAutoError) as c:self.run_flow(FakeEz(mode='zero'))
        self.assertIn('0건',str(c.exception))
    def test_captcha_waits_for_person_then_unanswered(self):
        with patch.object(ob,'CAPTCHA_ANSWER_SECONDS',1):
            with self.assertRaises(ob.CaptchaUnanswered):self.run_flow(FakeEz(mode='captcha'))

class Bridge(unittest.TestCase):
    def test_messages_for_mac_settings(self):
        self.assertEqual(mc.explain('execution error: Google Chrome got an error: Executing JavaScript through AppleScript is turned off. (12)'),mc.JS_OFF_MESSAGE)
        self.assertEqual(mc.explain('Not authorized to send Apple events to Google Chrome. (-1743)'),mc.PERMISSION_MESSAGE)
        self.assertEqual(mc.explain('NUAVU_TAB_GONE (-2700)'),'TAB_GONE')
        self.assertEqual(mc.explain('1237:1274: execution error: Google Chrome에 오류 발생: AppleScript를 통한 자바스크립트 실행 기능이 꺼져 있습니다. (12)'),mc.JS_OFF_MESSAGE)
    PS=("  101 /Applications/Google Chrome.app/Contents/MacOS/Google Chrome --remote-debugging-pipe --user-data-dir=/var/folders/x/playwright_chromiumdev_profile-1 --enable-automation\n"
        " 6348 /Applications/Google Chrome.app/Contents/MacOS/Google Chrome\n"
        " 6400 /Applications/Google Chrome.app/Contents/Frameworks/Google Chrome Framework.framework/Versions/1/Helpers/Google Chrome Helper (Renderer).app/Contents/MacOS/Google Chrome Helper (Renderer) --type=renderer\n"
        "63950 /Applications/Google Chrome.app/Contents/MacOS/Google Chrome --headless=new --remote-debugging-pipe --user-data-dir=/tmp/p\n")
    def test_osa_targets_main_chrome_pid_with_jxa(self):
        # 2026-11-02 12:49: Chrome 2개(메인 + 자동화용) → 이름으로 부르면 엉뚱한 쪽. 메인 Chrome pid 로 부른다.
        seen=[]
        def run(args,**kw):
            seen.append((args,kw))
            if args[0]=='/bin/ps':return subprocess.CompletedProcess(args,0,self.PS,'')
            return subprocess.CompletedProcess(args,0,'ok\n','')
        with patch.object(sys,'platform','darwin'):self.assertEqual(mc.osa('js','5','alert("x")',run=run),'ok')
        args,kw=seen[-1]
        self.assertEqual(args[:4],['/usr/bin/osascript','-l','JavaScript','-']);self.assertEqual(args[4:],['6348','js','5','alert("x")'])
        self.assertEqual(kw['input'],mc.SCRIPT);self.assertIn('Application(parseInt(argv[0],10))',mc.SCRIPT)
    def test_only_automation_chrome_running(self):
        ps=''.join(l+'\n' for l in self.PS.splitlines() if ' 6348 ' not in l)
        run=lambda args,**kw:subprocess.CompletedProcess(args,0,ps,'')
        with self.assertRaises(OrderAutoError) as c:mc.main_chrome_pid(run)
        self.assertIn('메인 Google Chrome이 켜져 있지 않습니다',str(c.exception));self.assertIn('자동화용 Chrome만',str(c.exception))
    def test_default_profile_preferred(self):
        ps=" 900 /Applications/Google Chrome.app/Contents/MacOS/Google Chrome --user-data-dir=/Users/x/other\n 950 /Applications/Google Chrome.app/Contents/MacOS/Google Chrome\n"
        self.assertEqual(mc.main_chrome_pid(lambda a,**k:subprocess.CompletedProcess(a,0,ps,'')),950)
    def test_not_mac(self):
        with patch.object(sys,'platform','win32'):
            with self.assertRaises(OrderAutoError):mc.osa('find','x')
    def test_no_password_or_keychain_use(self):
        src=(ROOT/'main_chrome.py').read_text(encoding='utf-8')
        for bad in ('login_account','password','#login-pwd','keychain'):self.assertNotIn(bad,src.replace('비밀번호',''))

class Wiring(unittest.TestCase):
    def tearDown(self):
        import browser_window as bw;bw.configure_main_chrome(False)
    def test_run_export_routes_to_main_chrome(self):
        import browser_window as bw;bw.configure_main_chrome(True)
        with patch('main_chrome.run',return_value=('n',b'd')) as r:self.assertEqual(ob._run_export(object(),{'x':1}),('n',b'd'))
        r.assert_called_once()
    def test_setting_saved_and_applied(self):
        from domain import Engine,Store
        sys.path.insert(0,str(ROOT/'tests'))
        try:from test_v052 import MemoryVault
        except ImportError:from helpers import MemoryVault
        import browser_window as bw
        with tempfile.TemporaryDirectory() as tmp:
            e=Engine(Store(Path(tmp)/'db'),None,MemoryVault())
            r=e.set_ezadmin_main_chrome({'ezadminMainChrome':True})
            self.assertTrue(e.store.read()['settings']['ezadminMainChrome']);self.assertEqual(bw.ezadmin_engine(),'main')
            self.assertIn('Apple Events의 JavaScript 허용',r['message'])
            bw.configure_main_chrome(False);Engine(e.store,None,MemoryVault());self.assertEqual(bw.ezadmin_engine(),'main')
            e.set_ezadmin_main_chrome({'ezadminMainChrome':False});self.assertEqual(bw.ezadmin_engine(),'chrome')
    def test_switch_in_settings_hub(self):
        html=(ROOT/'web/index.html').read_text(encoding='utf-8');js=(ROOT/'web/settings_hub.js').read_text(encoding='utf-8')
        self.assertIn('data-hub-auto="ezadminMainChrome"',html);self.assertIn("api('ezadmin-main-chrome'",js)
        self.assertIn("'/api/ezadmin-main-chrome'",(ROOT/'app.py').read_text(encoding='utf-8'))

if __name__=='__main__':unittest.main()
