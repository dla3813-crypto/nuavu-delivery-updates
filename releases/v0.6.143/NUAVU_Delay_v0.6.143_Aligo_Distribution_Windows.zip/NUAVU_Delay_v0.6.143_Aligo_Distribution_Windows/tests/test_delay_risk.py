"""Promise-aware shortage monitoring: fake providers, temporary files and DB."""
import copy
from datetime import datetime
from pathlib import Path

import pytest

from delay_risk import assess_risk, risk_window, read_day
from domain import KST, SELLERS
from helpers import Base, Clock
from test_supply_regression import order, source_row, xlsx


@pytest.mark.parametrize('due,ship,watch,confirmed', [
    ('2026-10-19','2026-10-13','2026-10-12','2026-10-14'),
    ('2026-10-20','2026-10-13','2026-10-12','2026-10-14'),
    ('2026-10-21','2026-10-17','2026-10-15','2026-10-19'),
    ('2026-10-22','2026-10-17','2026-10-15','2026-10-19'),
    ('2026-10-23','2026-10-17','2026-10-15','2026-10-19'),
    ('2026-10-24','2026-10-17','2026-10-15','2026-10-19'),
    ('2026-10-25','2026-10-17','2026-10-15','2026-10-19'),
    ('2026-10-26','2026-10-20','2026-10-19','2026-10-21'),
    ('2026-11-04','2026-10-31','2026-10-29','2026-11-02'),
    ('2027-01-06','2027-01-02','2026-12-31','2027-01-04'),
])
def test_existing_china_waves_cover_every_promise_weekday(due,ship,watch,confirmed):
    window=risk_window(due)
    assert (window['chinaDate'],window['watchDate'],window['confirmDate']) == (ship,watch,confirmed)


def test_existing_holidays_shift_eligible_wave_not_the_promise():
    window=risk_window('2026-10-19',['2026-10-19'])
    assert window['chinaDate']=='2026-10-10'
    assert window['dispatchStart']=='2026-10-14'


@pytest.mark.parametrize('value',['',None,'2026-02-30','2026-10-1','다음주'])
def test_bad_due_date_has_no_risk_window(value):
    assert risk_window(value) is None


def test_refresh_timestamp_converted_to_korean_date():
    assert read_day('2026-10-18T15:01:00+00:00').isoformat()=='2026-10-19'


@pytest.mark.parametrize('today,expected',[
    ('2026-10-14',''),('2026-10-15','watch'),('2026-10-18','watch'),
    ('2026-10-19','confirmed'),('2026-10-21','confirmed'),('2026-10-22',''),
])
def test_saturday_cycle_boundary_days(today,expected):
    supply=dict(lastReadAt=today+'T10:00:00+09:00',lastScan={'files':[{'selectedRows':1}]},confirmedCalendarYears=[2026])
    row=dict(active=True,qty=1,dueDate='2026-10-21')
    assert assess_risk(row,{},today,supply,risk_window(row['dueDate']))['stage']==expected


@pytest.mark.parametrize('today,expected',[
    ('2026-10-11',''),('2026-10-12','watch'),('2026-10-13','watch'),
    ('2026-10-14','confirmed'),('2026-10-19','confirmed'),('2026-10-20',''),
])
def test_tuesday_cycle_boundary_days(today,expected):
    supply=dict(lastReadAt=today+'T10:00:00+09:00',lastScan={'files':[{'selectedRows':1}]},confirmedCalendarYears=[2026])
    row=dict(active=True,qty=1,dueDate='2026-10-19')
    assert assess_risk(row,{},today,supply,risk_window(row['dueDate']))['stage']==expected


def test_confirm_day_cutoff_four_pm(monkeypatch):
    import domain
    from helpers import Clock
    monkeypatch.setattr(domain,'datetime',Clock)
    supply=dict(lastReadAt='2026-10-18T10:00:00+09:00',lastScan={'files':[{'selectedRows':1}]},confirmedCalendarYears=[2026])
    row=dict(active=True,qty=1,dueDate='2026-10-21');w=risk_window(row['dueDate'])
    Clock.current=datetime(2026,10,19,15,59,tzinfo=KST)
    r=assess_risk(row,{},'2026-10-19',supply,w)
    assert r['stage']=='watch' and r['needsRefresh'] and not r['deadlinePassed'] and r['cutoff']=='2026-10-19 16:00'
    assert '감시 (당일 오후 4시 마감)' in r['reason']
    Clock.current=datetime(2026,10,19,16,0,tzinfo=KST)
    r=assess_risk(row,{},'2026-10-19',supply,w)
    assert r['stage']=='confirmed' and r['deadlinePassed'] and '오후 4시 마감 경과' in r['reason']
    assert assess_risk(row,{},'2026-10-20',supply,w)['stage']=='confirmed'
    assert assess_risk(row,{},'2026-10-19',dict(supply,confirmedCalendarYears=[]),w)['stage']=='watch'


class DelayRiskWorkflowTests(Base):
    def setUp(self):
        super().setUp()
        self.folder=Path(self.tmp.name)/'risk-supply';self.folder.mkdir()
        self.engine.supply_link(str(self.folder))
        self.set_orders([order(1)])
        self.ack()

    def set_orders(self,rows):
        self.engine.import_rows(dict(rows=rows,mode='snapshot',scope=SELLERS,replaceConfirmed=True))
        # These fixtures represent checked order quantities; review exclusion
        # itself is exercised explicitly below.
        self.engine.review_rows([r['key'] for r in self.store.read()['rows'] if r['active'] and r.get('review')])

    def rows(self):
        return {r['orderId']:r for r in self.engine.public_state()['rows'] if r['active']}

    def risk(self,key='TEST-001'):
        return self.rows()[key]['delayRisk']

    def ack(self,due='2026-10-21',keys=None):
        self.engine.external_manual(dict(keys=keys or [r['key'] for r in self.rows().values()],dueDate=due))

    def day(self,day):
        Clock.current=datetime.fromisoformat(day+'T10:00:00').replace(tzinfo=KST)

    def write(self,rows=None,name='진행상황_1019.xlsx',refresh=True):
        (self.folder/name).write_bytes(xlsx([('공급',rows if rows is not None else [source_row()])]))
        if refresh:self.engine.supply_refresh()

    def test_clock_crossing_changes_stage_without_reusing_cached_risk(self):
        self.write()
        revision=self.store.read()['revision']
        self.assertEqual(self.risk()['stage'],'')
        self.day('2026-10-15');self.assertEqual(self.risk()['stage'],'watch')
        self.day('2026-10-19')
        self.assertEqual(self.risk()['stage'],'watch')
        self.assertTrue(self.risk()['needsRefresh'])
        self.assertEqual(self.store.read()['revision'],revision)
        self.engine.supply_refresh()
        self.assertEqual(self.risk()['stage'],'confirmed')
        self.day('2026-10-22');self.assertEqual(self.risk()['stage'],'')
        self.assertEqual(self.rows()['TEST-001']['noticeBucket'],'overdue')

    def test_partial_arrival_reports_missing_quantity(self):
        self.set_orders([order(1,qty=10)]);self.ack();self.day('2026-10-19')
        self.write([source_row(office='2026-10-17',qty=4),source_row(qty=80)])
        risk=self.risk()
        self.assertEqual((risk['stage'],risk['coveredQty'],risk['shortQty']),('confirmed',4,6))
        self.assertEqual(risk['progressQty'],4)

    def test_fifo_earlier_order_exhausts_available_quantity(self):
        self.set_orders([order(2,qty=3),order(1,qty=2)]);self.ack();self.day('2026-10-19')
        self.write([source_row(office='2026-10-17',qty=3)])
        self.assertEqual(self.risk()['stage'],'')
        self.assertEqual(self.risk('TEST-002')['coveredQty'],1)
        self.assertEqual(self.risk('TEST-002')['shortQty'],2)

    def test_unnotified_earlier_order_still_consumes_stock(self):
        self.set_orders([order(1),order(2)])
        with self.store.edit() as s:s['notices']=[]
        self.ack(keys=[self.rows()['TEST-002']['key']]);self.day('2026-10-19')
        self.write([source_row(office='2026-10-17')])
        self.assertEqual(self.risk('TEST-002')['shortQty'],1)
        self.assertEqual(self.risk('TEST-002')['stage'],'confirmed')

    def test_manifest_and_separate_progress_quantities_combine(self):
        self.set_orders([order(1,qty=3)]);self.ack();self.day('2026-10-19')
        self.write([source_row(qty=1)],'솔리아 10월 13일 출고장 (완료).xlsx',False)
        self.write([source_row(qty=1,office='2026-10-17')])
        risk=self.risk()
        self.assertEqual((risk['manifestQty'],risk['progressQty'],risk['shortQty']),(1,1,1))

    def test_same_wave_is_not_counted_twice(self):
        self.set_orders([order(1,qty=2)]);self.ack();self.day('2026-10-19')
        self.write([source_row(color='米白色 아이보리03')],'솔리아 10월 17일 출고장 (완료).xlsx',False)
        self.write([source_row(office='2026-10-17')])
        self.assertEqual(self.risk()['coveredQty'],1)
        self.assertEqual(self.risk()['shortQty'],1)

    def test_full_manifest_clears_risk_despite_blank_V(self):
        self.day('2026-10-19');self.write()
        self.write([source_row()],'솔리아 10월 17일 출고장 (완료).xlsx')
        self.assertEqual(self.risk()['stage'],'')
        self.assertEqual(self.risk()['manifestQty'],1)

    def test_wednesday_promise_accepts_existing_wednesday_thursday_interval(self):
        self.day('2026-10-19');self.write([source_row(office='2026-10-17')])
        self.assertEqual(self.rows()['TEST-001']['dispatchEnd'],'2026-10-22')
        self.assertEqual(self.risk()['stage'],'')

    def test_later_arrival_wave_cannot_clear_earlier_promise(self):
        self.day('2026-10-19');self.write([source_row(office='2026-10-18')])
        risk=self.risk()
        self.assertEqual((risk['coveredQty'],risk['lateQty'],risk['stage']),(0,1,'confirmed'))

    def test_future_V_is_not_arrived_until_that_day_even_with_cached_allocation(self):
        self.day('2026-10-15');self.write([source_row(office='2026-10-17')])
        self.assertEqual((self.risk()['stage'],self.risk()['futureQty']),('watch',1))
        self.day('2026-10-17');self.assertEqual(self.risk()['stage'],'')
        self.assertEqual(self.risk()['coveredQty'],1)

    def test_L_date_never_counts_as_arrival(self):
        self.day('2026-10-19');self.write([source_row(purchase='2026-10-15')])
        self.assertEqual(self.risk()['shortQty'],1)
        self.assertEqual(self.risk()['stage'],'confirmed')

    def test_new_arrival_clears_after_manual_refresh_only(self):
        self.day('2026-10-19');self.write()
        self.write([source_row(office='2026-10-17')],refresh=False)
        self.assertEqual(self.risk()['stage'],'confirmed')
        self.engine.supply_refresh();self.assertEqual(self.risk()['stage'],'')

    def test_other_product_and_wrong_option_stock_cannot_clear_risk(self):
        self.set_orders([order(1,option='아이보리 / M')]);self.ack();self.day('2026-10-19')
        self.write([source_row(product='다른상품',size='M',qty=50,office='2026-10-17'),
                    source_row(size='L',qty=50,office='2026-10-17'),
                    source_row(color='블랙',size='M',qty=50,office='2026-10-17')])
        self.assertEqual(self.risk()['shortQty'],1)
        self.assertTrue(self.risk()['matchNeeded'])

    def test_manual_recommendation_does_not_supply_stock_until_connected(self):
        self.set_orders([order(1,option='화이트')]);self.ack();self.day('2026-10-19')
        self.write([source_row(office='2026-10-17')])
        row=self.rows()['TEST-001']
        self.assertTrue(row['supplyInfo']['manualRecommended'])
        self.assertEqual(row['delayRisk']['stage'],'confirmed')
        vid=row['supplyInfo']['manualRecommendations'][0]['variant']
        self.engine.supply_match(dict(key=row['key'],variants=[vid]))
        self.assertEqual(self.risk()['stage'],'')

    def test_sealed_quantity_is_kept_only_for_original_order(self):
        self.day('2026-10-19')
        self.write([source_row()],'솔리아 10월 17일 출고장 (완료).xlsx')
        self.engine.supply_reset({'confirmed':True})
        self.assertEqual(self.risk()['stage'],'')
        self.set_orders([order(1),order(2)]);self.ack()
        self.write([source_row(office='2026-10-17')])
        self.assertEqual(self.risk('TEST-002')['shortQty'],1)
        self.assertEqual(self.risk('TEST-002')['stage'],'confirmed')

    def test_no_loaded_data_or_wrong_brand_does_not_confirm_every_order(self):
        self.day('2026-10-19')
        self.assertEqual(self.risk()['stage'],'')
        self.assertTrue(self.risk()['needsRefresh'])
        self.write([source_row(brand='OD')])
        self.assertEqual(self.risk()['stage'],'')
        self.assertFalse(self.engine.public_state()['delayRiskSummary']['dataReady'])

    def test_failed_latest_refresh_cannot_confirm_old_data(self):
        self.day('2026-10-15');self.write();self.day('2026-10-19')
        (self.folder/'진행상황_1020.xlsx').write_bytes(b'broken')
        with self.assertRaises(ValueError):self.engine.supply_refresh()
        self.assertEqual(self.risk()['stage'],'watch')
        self.assertTrue(self.risk()['needsRefresh'])

    def test_only_applied_notice_due_date_is_used(self):
        self.day('2026-10-19');self.write()
        n=self.queue(keys=[self.rows()['TEST-001']['key']],sendMode='MORNING',dueDate='2026-10-28')
        # v0.6.143 (23:23 요청): the reserved 재안내 date pre-applies, so the row leaves 초과 예상 right away;
        # cancelling the reservation brings the old date (and the risk) back.
        self.assertEqual(self.risk()['dueDate'],'2026-10-28');self.assertEqual(self.risk()['stage'],'')
        self.engine.queue_control({'action':'cancel_one','id':n['id']})
        self.assertEqual(self.risk()['dueDate'],'2026-10-21');self.assertEqual(self.risk()['stage'],'confirmed')
        self.ack('2026-10-28');self.assertEqual(self.risk()['stage'],'')

    def test_unnotified_review_inactive_and_soldout_not_forecast(self):
        self.set_orders([order(1),order(2)]);self.day('2026-10-19');self.write()
        self.assertEqual(self.risk('TEST-002')['stage'],'')
        with self.store.edit() as s:
            next(r for r in s['rows'] if r['orderId']=='TEST-001' and r['active'])['review']=True
        self.assertEqual(self.risk()['stage'],'')
        with self.store.edit() as s:
            next(r for r in s['rows'] if r['orderId']=='TEST-001' and r['active'])['review']=False
            s['notices'][-1]['noticeType']='soldout_card';s['notices'][-1]['dueDate']=''
        self.assertEqual(self.risk()['stage'],'')
        self.set_orders([order(2)])
        old=next(r for r in self.engine.public_state()['rows'] if r['orderId']=='TEST-001')
        self.assertEqual(old['delayRisk']['stage'],'')

    def test_unknown_calendar_year_stays_watch_until_confirmed(self):
        self.ack('2027-01-06');self.day('2027-01-04');self.write()
        self.assertEqual(self.risk()['stage'],'watch')
        self.assertTrue(self.risk()['needsCalendar'])
        self.engine.supply_settings(dict(year=2027,brands=['N','NS'],holidays=[],calendarConfirmed=True))
        self.assertEqual(self.risk()['stage'],'confirmed')

    def test_public_forecast_is_read_only_and_cannot_send(self):
        self.day('2026-10-19');self.write()
        before=copy.deepcopy(self.store.read())
        self.risk();self.engine.public_state()
        self.assertEqual(self.store.read(),before)
        self.assertFalse(self.fake.sent);self.assertFalse(self.fake.report_calls);self.assertFalse(self.at.sent)

    def test_v0617_upgrade_preserves_existing_data(self):
        self.write()
        with self.store.edit() as s:s['appVersion']='0.6.17'
        before=copy.deepcopy(self.store.read());self.restart();after=self.store.read()
        for field in ['rows','settings','supply','notices']:
            self.assertEqual(after[field],before[field])
        self.assertEqual(after['appVersion'],'0.6.143')
