"""v0.6.149 (2026-11-03): 다운로드관리자 요청시각이 겹쳐 내 요청을 못 가리면(AmbiguousJob) 30초 뒤 새로 신청, 최대 3회.
메인 Chrome 모드 run() 을 가짜 flow 로 검증한다 (실제 Chrome·이지어드민 접속 없음)."""
import sys,unittest
from pathlib import Path
from datetime import datetime,timedelta
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import main_chrome
from order_auto import AmbiguousJob,AMBIGUOUS_RETRY_TIMES,AMBIGUOUS_RETRY_WAIT,OrderAutoError,requested_job,KST

class Controller:
    def __init__(self):self.updates=[];self.alerts=[]
    def update(self,phase,message):self.updates.append((phase,message))
    def alert(self,title,message,level):self.alerts.append((title,message,level))
    def check(self):pass

class FakeFlow:
    """처음 fail_times 번은 요청시각 겹침, 그 다음은 성공."""
    made=[]
    def __init__(self,controller,fail_times):
        self.c=controller;self.fail_times=fail_times;self.export_requested=False;self.page=None;self.step='시작';self.paused=[];self.closed=0
        FakeFlow.made.append(self)
    def export_orders(self,cfg):
        self.export_requested=True
        if len([f for f in FakeFlow.made if f.export_requested])<=self.fail_times:
            self.step='다운로드 요청시간 대조';raise AmbiguousJob('접수한 시간에 주문 엑셀이 여러 개 요청되어 구분할 수 없습니다.')
        return ('확장주문검색_20261103155330_1.xls',b'data')
    def failure_message(self,exc):return f'[메인 Chrome] {self.step} 단계에서 중단했습니다. {exc}'
    def close_tabs(self):self.closed+=1
    def pause(self,seconds):self.paused.append(seconds)

class OverlapRetry(unittest.TestCase):
    def setUp(self):FakeFlow.made=[]
    def test_retries_then_succeeds(self):
        c=Controller();fails=2
        r=main_chrome.run(c,{'group':'g','folder':'/tmp'},flow_factory=lambda ctl:FakeFlow(ctl,fails))
        self.assertEqual(r[0],'확장주문검색_20261103155330_1.xls')
        self.assertEqual(len(FakeFlow.made),3)                       # 2번 겹침 → 3번째 새 요청으로 성공
        self.assertEqual([f.paused for f in FakeFlow.made[:2]],[[AMBIGUOUS_RETRY_WAIT]]*2)
        self.assertTrue(any('새로 신청합니다 (1/3)' in m for _,m in c.updates))
        self.assertEqual(c.alerts,[])                                # 성공했으니 오류 알림 없음
    def test_gives_up_after_limit(self):
        c=Controller()
        with self.assertRaises(OrderAutoError) as cm:
            main_chrome.run(c,{'group':'g','folder':'/tmp'},flow_factory=lambda ctl:FakeFlow(ctl,99))
        self.assertEqual(len(FakeFlow.made),AMBIGUOUS_RETRY_TIMES+1)  # 처음 1회 + 재신청 3회
        self.assertIn('3회 새로 신청했지만 매번 겹쳤습니다',str(cm.exception))
        self.assertEqual(len(c.alerts),1)
    def test_requested_job_raises_ambiguous(self):
        started=datetime(2026,11,3,14,53,17,tzinfo=KST);accepted=started+timedelta(seconds=6)
        rows=[{'id':'1','template':'확장주문검색2','at':'2026-11-03 14:53:18'},{'id':'2','template':'확장주문검색2','at':'2026-11-03 14:53:21'}]
        with self.assertRaises(AmbiguousJob):requested_job(rows,started,accepted)
        self.assertEqual(requested_job(rows[:1],started,accepted)['id'],'1')

if __name__=='__main__':unittest.main()
