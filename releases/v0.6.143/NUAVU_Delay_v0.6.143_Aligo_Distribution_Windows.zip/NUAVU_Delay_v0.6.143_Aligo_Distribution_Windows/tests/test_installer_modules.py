"""Every local module the bundled files import must itself be in the installer's copy list.
(v0.6.143 regression: exchange_reship.py was imported at runtime but never copied into the .app.)"""
import re,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

class InstallerModuleTests(unittest.TestCase):
    def test_all_imported_local_modules_are_bundled(self):
        src=(ROOT/'install_desktop.py').read_text(encoding='utf-8')
        listed=set(re.findall(r"'([a-z_0-9]+\.py)'",src))
        local={p.name for p in ROOT.glob('*.py')}
        missing=set();todo=list(listed);seen=set()
        while todo:
            name=todo.pop()
            if name in seen or not (ROOT/name).exists():continue
            seen.add(name);text=(ROOT/name).read_text(encoding='utf-8')
            for mod in re.findall(r'^\s*(?:from\s+([a-z_0-9]+)\s+import|import\s+([a-z_0-9]+)\b)',text,re.M):
                mod=(mod[0] or mod[1])+'.py'
                if mod in local and mod not in listed:missing.add((name,mod))
                elif mod in local:todo.append(mod)
        self.assertEqual(missing,set(),f'설치 목록에 없는 로컬 모듈: {sorted(missing)}')

if __name__=='__main__':unittest.main()
