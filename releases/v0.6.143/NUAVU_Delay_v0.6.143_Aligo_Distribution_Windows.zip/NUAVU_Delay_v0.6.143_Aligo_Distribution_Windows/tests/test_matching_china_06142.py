"""[배포판 이식본 · 현재고 테스트 제외] v0.6.152 (2026-11-04 04:06 요청)
- 영어/한글 컬러 동의어 매칭 (Ivory ↔ 아이보리, Gray ↔ 그레이, One Color ↔ 원컬러) — 자동 매칭·비슷한 컬러 추천
- 주문 F 사이즈는 발주 S/M/L과 무관하게 매칭(기존 규칙 유지 확인)
- 출고장 물량의 현재고 중복 제외는 도착 예상 기간이 끝난 뒤에만 (10/31 출고장 · 11/4 01:00 현재고 조회 사례)"""
import sys,tempfile,unittest
from datetime import datetime,timedelta,timezone
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from unittest.mock import patch
import supply_workflow as sw
from supply_workflow import candidates,manual_color_recommendations,color_match_key,variant_id,allocation_view,init_supply
from domain import Store,Engine,today

class FakeProvider:
    def send(self,*a,**k):return 1
    def remaining(self,*a):return '0'
    def report(self,*a):return []

def variant(product,color,size,brand='N',kind='manifest',qty=5,ship='2026-10-31',office='2026-10-29'):
    r={'brand':brand,'product':product,'color':color,'size':size,'qty':qty,'sheet':'출고장','line':1,'sourceFile':'f.xlsx','kind':kind,
       'shipDate':ship if kind=='manifest' else '','basisDate':'' if kind=='manifest' else office,'officeDate':office,'officeRaw':office,'purchaseDate':'','basisType':kind}
    r['variant']=variant_id(r);return r

class ColorAliases(unittest.TestCase):
    def test_keys(self):
        for a,b in [('Ivory','아이보리'),('[Gray]','그레이'),('One Color (Brown Star)','원컬러'),('Black','블랙'),('Skyblue','스카이블루'),('블랙1','블랙'),('Charcoal','차콜')]:
            self.assertEqual(color_match_key(a),b,a)
    def test_english_order_matches_korean_source_and_reverse(self):
        vs=[variant('바인 후드 버튼 후리스 후드 집업','아이보리','F'),variant('언발 패턴 웰론 오버핏 숏 패딩','Gray','F'),variant('코렌 스트라이프 미디 스커트','One Color','F')]
        hits,amb,how=candidates({'product':'[2color]바인 후드 버튼 후리스 후드 집업','option':'[Ivory-FREE]'},vs,{});self.assertEqual([h['color'] for h in hits],['아이보리'])
        hits,amb,how=candidates({'product':'[3color]언발 패턴 웰론 오버핏 숏 패딩','option':'[그레이-FREE]'},vs,{});self.assertEqual([h['color'] for h in hits],['Gray'])
        hits,amb,how=candidates({'product':'코렌 스트라이프 미디 스커트','option':'[One Color-FREE]'},vs,{});self.assertEqual(len(hits),1)
        hits,amb,how=candidates({'product':'[2color]바인 후드 버튼 후리스 후드 집업','option':'[Black-FREE]'},vs,{});self.assertEqual(hits,[])   # 다른 컬러는 여전히 불일치
    def test_free_order_size_ignores_source_sizes(self):
        vs=[variant('체크 롱 플리츠 미디 스커트','그레이','S'),variant('체크 롱 플리츠 미디 스커트','그레이','M')]
        hits,amb,how=candidates({'product':'[2color]체크 롱 플리츠 미디 스커트','option':'[Grey-FREE]'},vs,{});self.assertEqual(len(hits),2)
        hits,amb,how=candidates({'product':'[2color]체크 롱 플리츠 미디 스커트','option':'[Grey-L]'},vs,{});self.assertEqual(hits,[])
    def test_similar_color_recommendation_with_english(self):
        vs=[variant('양털 오버핏 후리스 집업','카키','F')]
        rec=manual_color_recommendations({'product':'(CS-9)[5color]양털 오버핏 후리스 집업','option':'[Green-FREE]'},vs)   # 배포판 시그니처(row,variants)
        self.assertEqual([r['sourceColor'] for r in rec],['카키'])   # 배포판 결과 키

if __name__=='__main__':unittest.main()
