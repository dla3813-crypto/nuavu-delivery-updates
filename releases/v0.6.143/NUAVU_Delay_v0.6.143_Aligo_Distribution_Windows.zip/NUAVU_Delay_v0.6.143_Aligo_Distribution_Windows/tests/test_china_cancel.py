"""2026-10-22 22:55 (공통) 중국 취소건: 초록행 기록 · 사유 해석 · 1/2/3차 · 재발주 · 주문 연결 · 교환 우선 배정."""
import io,os,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
import china_cancel as cc

def book(rows,header=True):
    import openpyxl
    from openpyxl.styles import PatternFill
    wb=openpyxl.Workbook();ws=wb.active;ws.title='취소건'
    if header:ws.append(['날짜','주문번호','상품명','옵션(컬러/변형)','사이즈','주문수량','단가(元)','금액(元)','비고','中国备注'])
    for color,vals in rows:
        ws.append(vals)
        if color:
            for c in ws[ws.max_row]:c.fill=PatternFill('solid',fgColor=color)
    b=io.BytesIO();wb.save(b);return b.getvalue()

ROWS=[('FFEB9C',['1014','S1014040','언발 사선 블루 체크 긴팔 셔츠 블라우스','원컬러','S',1,38,38,None,'下架']),
      ('C6EFCE',['1020','S1020019','언발 사선 블루 체크 긴팔 셔츠 블라우스','원컬러','S',1,38,38,None,'下架']),
      ('C6EFCE',['1022','S1022012','[2color]버니 후드 스트링 코튼 백팩','그레이','F',3,31.72,95.16,'링크가 사라졌었요',None]),
      ('C6EFCE',['1002','S1002132','플라워 펀칭 긴팔티','원컬러','S',1,38,38,None,'30件起'])]

class Parse(unittest.TestCase):
    def test_colors_columns_and_meta(self):
        rows=cc.parse_cancel_file('(1022) 1022~0910 누아브 취소건.xlsx',book(ROWS))
        self.assertEqual([r['fill'] for r in rows],['orange','green','green','green'])
        r=rows[1];self.assertEqual((r['brand'],r['fileDay'],r['code'],r['orderDate'],r['noteJ'],r['line']),('누아브','1022','S1020019','2026-10-20','下架',3))
    def test_reasons(self):
        cases={'下架':'soldout','링크가 사라졌었요':'soldout','아직 생산 계획이 없어요':'soldout','이 링크 품절':'soldout','품절':'soldout',
               '50件起做':'qty','10件起':'qty','30件起':'qty','150장 부터':'qty','품절（200장 부터)':'qty','一个颜色10件起':'qty',
               '预计11月5号出':'delay','10/7 1장  품절 환불':'soldout','10/12 1장 불량 환불':'defect','10/14 50장 취소 환불':'other',
               '只有蓝色':'soldout','업체에서 갑자기 전 사이즈 재고가 없다고 하네요':'soldout'}
        for note,kind in cases.items():self.assertEqual(cc.reason_parts(note)[0],kind,note)
        self.assertIn('최소 50장부터',cc.reason_parts('50件起做')[1]);self.assertIn('한 색상당',cc.reason_parts('一个颜色10件起')[1])
        self.assertIn('11월 5일 출고 예정',cc.reason_parts('预计11月5号出')[1]);self.assertIn('블루만 있음',cc.reason_parts('只有蓝色')[1])
        self.assertIn('품절',cc.explain('','下架')[1]);self.assertEqual(cc.explain('','')[0],'other')

class Ledger(unittest.TestCase):
    def test_green_only_dedupe_and_stages(self):
        v={};s={'chinaCancel':v};v=cc.init_china(s)
        rows=cc.parse_cancel_file('(1022) 1022~0910 누아브 취소건.xlsx',book(ROWS))
        self.assertEqual(cc.record_rows(v,rows,'2026-10-22'),3)
        self.assertEqual(cc.record_rows(v,rows,'2026-10-22'),0)          # 같은 주문번호는 한 번만
        blouse=[i for i in v['items'].values() if '블라우스' in i['product']][0]
        self.assertEqual((cc.stage_of(blouse),blouse['events'][0]['foundOn']),(1,'2026-10-22'))
        # 다음 날 재발주한 주문이 또 취소(초록) → 2차, 그 다음 → 3차, 더 있어도 3차
        for day,code in (('1023','S1023001'),('1025','S1025007'),('1027','S1027003')):
            nxt=cc.parse_cancel_file(f'({day}) {day}~0910 누아브 취소건.xlsx',book([('C6EFCE',[day,code,'언발 사선 블루 체크 긴팔 셔츠 블라우스','원컬러','S',1,38,38,'품절',None])]))
            cc.record_rows(v,nxt,'2026-'+day[:2]+'-'+day[2:])
        self.assertEqual(cc.stage_of(blouse),3);self.assertEqual(len(blouse['events']),4)
        qty=[i for i in v['items'].values() if '펀칭' in i['product']][0]
        self.assertEqual((cc.item_kind(qty),cc.stage_of(qty)),('qty',0))

    def test_reorder_from_progress(self):
        s={};v=cc.init_china(s)
        cc.record_rows(v,cc.parse_cancel_file('(1022) 1022~0910 누아브 취소건.xlsx',book(ROWS)),'2026-10-22')
        bag=[i for i in v['items'].values() if '백팩' in i['product']][0]
        prog=[{'product':'버니 후드 스트링 코튼 백팩','color':'그레이','size':'F','purchaseDate':'2026-10-22','sourceFile':'진행상황.xlsx','line':5,'qty':3},
              {'product':'버니 후드 스트링 코튼 백팩','color':'그레이','size':'F','purchaseDate':'2026-10-23','sourceFile':'진행상황.xlsx','line':9,'qty':3}]
        self.assertEqual([x['line'] for x in cc.reorders(bag,prog)],[9])   # 취소된 주문일(10/22)보다 늦은 주문만
        self.assertEqual(cc.reorders(bag,prog[:1]),[])

class Decorate(unittest.TestCase):
    def state(self):
        s={'rows':[{'key':'a','active':True,'product':'언발 사선 블루 체크 긴팔 셔츠 블라우스','option':'원컬러/S','orderId':'1'},
                   {'key':'b','active':True,'product':'[2color]버니 후드 스트링 코튼 백팩','option':'그레이/S','orderId':'2'},   # 2026-11-04: 컬러 같고 사이즈만 다름 → 비슷한 취소상품
                   {'key':'b2','active':True,'product':'[2color]버니 후드 스트링 코튼 백팩','option':'블랙/FREE','orderId':'22'},  # 2026-11-04: 컬러 다름 → 묻지 않음
                   {'key':'b3','active':True,'product':'[2color]버니 후드 스트링 코튼 백팩','option':'Gray/FREE','orderId':'23'},  # 2026-11-04: 영어 컬러 → 자동
                   {'key':'c','active':True,'product':'플라워 펀칭 긴팔티','option':'원컬러/S','orderId':'3'},
                   {'key':'d','active':True,'product':'전혀 다른 상품','option':'블랙/FREE','orderId':'4'},
                   {'key':'e','active':False,'product':'언발 사선 블루 체크 긴팔 셔츠 블라우스','option':'원컬러/S','orderId':'5'}],
           'supply':{'mappings':{},'manifests':{},'progress':[{'product':'버니 후드 스트링 코튼 백팩','color':'그레이','size':'F','purchaseDate':'2026-10-23','sourceFile':'진행상황.xlsx','line':9,'qty':3,'variant':'x'}]}}
        cc.record_rows(cc.init_china(s),cc.parse_cancel_file('(1022) 1022~0910 누아브 취소건.xlsx',book(ROWS)),'2026-10-22')
        return s
    def test_rows(self):
        s=cc.decorate(self.state());r={x['key']:x.get('chinaCancel') for x in s['rows']}
        self.assertEqual((r['a']['match'],r['a']['label'],r['a']['stage']),('auto','중국 취소 1차',1))
        self.assertIn('下架',r['a']['reason']);self.assertEqual(r['a']['code'],'S1020019');self.assertEqual(r['a']['brand'],'누아브')
        self.assertEqual(r['b']['match'],'similar')                    # 상품명·컬러 같음, 사이즈만 다름(S ↔ F)
        self.assertIsNone(r['b2'])                                      # 2026-11-04: 컬러가 다르면(블랙 ↔ 그레이) 비슷한 취소상품으로 묻지 않는다
        self.assertEqual(r['b3']['match'],'auto')                       # 2026-11-04: Gray ↔ 그레이
        self.assertEqual((r['c']['kind'],r['c']['label']),('qty','수량체크'))
        self.assertIsNone(r['d']);self.assertIsNone(r['e'])
        self.assertEqual(s['chinaCancel']['events'],3)
    def test_decisions_and_reorder_label(self):
        s=self.state();iid=[i for i in s['chinaCancel']['items'].values() if '백팩' in i['product']][0]['id']
        cc.decide(s,{'rowKey':'b','itemId':iid,'decision':'match'})
        r=cc.decorate(s)['rows'][1]['chinaCancel'];self.assertEqual((r['match'],r['label']),('confirmed','(1차)재발주'))
        s=self.state();cc.decide(s,{'rowKey':'b','itemId':iid,'decision':'reject'})
        with self.assertRaises(cc.ChinaCancelError):cc.decide(s,{'rowKey':'zz','itemId':iid,'decision':'match'})
        self.assertIsNone(cc.decorate(s)['rows'][1].get('chinaCancel'))
    def test_reject_covers_other_sizes_of_same_product_and_message(self):
        # 2026-11-04: 「다른 상품/오발주」— 같은 상품명의 다른 취소 항목(사이즈별)에도 다시 묻지 않는다
        s=self.state();v=cc.init_china(s)
        extra=cc.parse_cancel_file('(1023) 1023 누아브 취소건.xlsx',book([('C6EFCE',['1023','S1023001','[2color]버니 후드 스트링 코튼 백팩','그레이','M',1,31.72,31.72,None,None])]))
        cc.record_rows(v,extra,'2026-10-23')
        ids=[i['id'] for i in v['items'].values() if '백팩' in i['product']];self.assertEqual(len(ids),2)
        import copy
        self.assertEqual(cc.decorate(copy.deepcopy(s))['rows'][1]['chinaCancel']['match'],'similar')
        r=cc.decide(s,{'rowKey':'b','itemId':ids[0],'decision':'reject'});self.assertIn('다른 상품/오발주',r['message'])
        self.assertIsNone(cc.decorate(copy.deepcopy(s))['rows'][1].get('chinaCancel'))   # 두 번째 백팩 항목(M)으로 다시 묻지 않음
        cc.decide(s,{'rowKey':'b','itemId':ids[0],'decision':'clear'})
        self.assertEqual(cc.decorate(copy.deepcopy(s))['rows'][1]['chinaCancel']['match'],'similar')
    def test_supplied_rows_are_not_flagged(self):
        # 2026-11-04: 출고 가능한 현재고가 있거나 사무실 도착(V)이 잡힌 주문은 취소건 표시를 하지 않는다
        s=cc.decorate(self.state())
        a=[x for x in s['rows'] if x['key']=='a'][0];self.assertTrue(a.get('chinaCancel'))
        a['inventoryReady']=True;cc.suppress_supplied(s);self.assertIsNone(a.get('chinaCancel'))
        s=cc.decorate(self.state());a=[x for x in s['rows'] if x['key']=='a'][0]
        a['supplyInfo']={'sources':[{'kind':'progress','officeDate':'2026-11-03'}]};cc.suppress_supplied(s);self.assertIsNone(a.get('chinaCancel'))
        s=cc.decorate(self.state());a=[x for x in s['rows'] if x['key']=='a'][0]
        a['supplyInfo']={'sources':[{'kind':'progress','officeDate':''}]};cc.suppress_supplied(s);self.assertTrue(a.get('chinaCancel'))   # V 공란이면 그대로
    def test_manual_mapping_rule(self):
        from supply_workflow import order_signature
        s=self.state();row=s['rows'][1]
        s['supply']['mappings'][order_signature(row)]=['v1']
        s['supply']['manifests']={'m':{'rows':[{'variant':'v1','product':'버니 후드 스트링 코튼 백팩','color':'그레이','size':'F'}]}}
        self.assertEqual(cc.decorate(s)['rows'][1]['chinaCancel']['match'],'manual')

class Folder(unittest.TestCase):
    def test_scan_folder_and_watch_signature(self):
        try:from test_v056 import Base
        except ImportError:from helpers import Base
        from domain import Store
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup)
        folder=Path(tmp.name)/'취소건';folder.mkdir()
        (folder/'(1022) 1022~0910 누아브 취소건.xlsx').write_bytes(book(ROWS));(folder/'~$잠금.xlsx').write_bytes(b'x')
        store=Store(Path(tmp.name)/'db');self.addCleanup(store.close)
        eng=SimpleNamespace(store=store,record_error=lambda *a:None)
        with store.edit() as s:cc.init_china(s)['folder']=str(folder)
        r=cc.scan(eng);self.assertEqual((r['changed'],r['added']),(True,3))
        self.assertEqual(cc.scan(eng)['changed'],False)                # 바뀐 게 없으면 다시 읽지 않음
        self.assertEqual(store.read()['chinaCancel']['lastScan']['files'][0]['green'],3)

class ExchangeFirst(unittest.TestCase):
    def test_allocation_sorts_exchange_first(self):
        import inspect,supply_workflow
        src=inspect.getsource(supply_workflow.allocation_view)
        self.assertIn("key=lambda r:(0 if text(r.get('orderId','')).strip().upper().startswith('C') else 1,order_priority(r))",src)
