"""2026-10-25 22:58 요청: 주문 목록에 없는 번호로 수동 문자 + 발송 이력 '수동안내 · 사유' (가짜 발송 큐, 실제 전송 없음)."""
import unittest
from pathlib import Path
if '_Distribution' in Path(__file__).resolve().parents[1].name:
 from helpers import Base,Clock
else:
 from test_v056 import Base,Clock
from domain import ValidationError

class DirectSmsTests(Base):
 def direct(self,**kw):
  base=self.data(noticeType='manual',templateKey='manual',dueDate='',template='안녕하세요 고객님. 회수 기사님이 내일 방문합니다.',deliveryChannel='SMS',keys=[],phones=['010-2222-3333','01044445555','010-2222-3333'],reason='회수 안내')
  return base|kw
 def test_direct_numbers_send_without_order_rows(self):
  p=self.engine.preview(self.direct());self.assertEqual(p['count'],2)
  g=p['groups'][0];self.assertEqual((g['seller'],g['orderId'],g['itemKeys'],g['manualReason'],g['phone']),('직접 입력','',[],'회수 안내','01022223333'))
  self.assertIn('안내번호:',g['content']);self.assertTrue(g['direct'])
  self.engine.commit({'token':p['token']});self.assertTrue(self.engine.send_one())
  n=self.last();self.assertEqual((n['noticeType'],n['manualReason'],n.get('direct'),n['seller']),('manual','회수 안내',True,'직접 입력'))
  self.assertEqual(len(self.fake.sent),1)
  with self.assertRaisesRegex(ValidationError,'이미 안내'):self.engine.preview(self.direct(phones=['01022223333']))   # 같은 번호·문구 중복 막음
 def test_direct_validation(self):
  with self.assertRaisesRegex(ValidationError,'번호를 확인'):self.engine.preview(self.direct(phones=['02-123-4567']))
  with self.assertRaisesRegex(ValidationError,'상품목록'):self.engine.preview(self.direct(template='{상품목록} 회수합니다'))
  with self.assertRaises(ValidationError):self.engine.preview(self.direct(phones=[]))   # 대상 없음
  with self.assertRaises(ValidationError):self.engine.preview(self.direct(noticeType='delay',templateKey='first',template='{상품목록} {출고예정일}',dueDate='2099-01-01'))   # 지연 안내에는 직접 번호 불가
  with self.assertRaises(ValidationError):self.engine.preview(self.direct(phones=['010-1111-%04d'%i for i in range(51)]))
 def test_reason_on_order_manual_and_edit_from_history(self):
  p=self.engine.preview(self.data(noticeType='manual',templateKey='manual',dueDate='',template='안내드립니다.',deliveryChannel='SMS',reason='교환 안내'))
  self.engine.commit({'token':p['token']});n=self.last();self.assertEqual(n['manualReason'],'교환 안내')
  r=self.engine.set_notice_reason({'id':n['id'],'reason':'회수 안내'});self.assertIn('저장',r['message']);self.assertEqual(self.last()['manualReason'],'회수 안내')
  self.assertEqual(self.engine.set_notice_reason({'id':n['id'],'reason':''})['reason'],'')
  with self.assertRaises(ValidationError):self.engine.set_notice_reason({'id':'nope','reason':'x'})
  self.assertEqual(len(self.fake.sent),0)   # 사유 수정은 문자를 보내지 않음
 def test_scheduled_direct_manual_can_be_cancelled(self):
  from datetime import datetime
  from domain import KST
  Clock.current=datetime(2026,10,19,22,0,tzinfo=KST)   # 밤 → 오전 9시 예약 선택 가능
  p=self.engine.preview(self.direct(sendMode='MORNING'));self.engine.commit({'token':p['token']})
  n=self.last();self.assertEqual(n['status'],'SCHEDULED');self.assertEqual(n['manualReason'],'회수 안내')
  self.engine.queue_control({'action':'cancel_one','id':n['id']});self.assertEqual(self.last()['status'],'CANCELLED');self.assertEqual(len(self.fake.sent),0)   # 예약 수동안내 되돌리기
 def test_ui_and_codex_wired(self):
  ROOT=Path(__file__).resolve().parents[1]
  js=(ROOT/'web'/'app.js').read_text(encoding='utf-8');html=(ROOT/'web'/'index.html').read_text(encoding='utf-8')
  for w in ('directPhones','noticeReason','nuavuDirectCompose','notice-reason','수동안내','reason-edit'):self.assertIn(w,js,w)
  for w in ('id="directPhones"','id="noticeReason"','회수 안내','id="directComposeBtn"'):self.assertIn(w,html,w)
  self.assertIn("'/api/notice-reason'",(ROOT/'app.py').read_text(encoding='utf-8'))
  self.assertIn("'phones'",(ROOT/'codex_tools.py').read_text(encoding='utf-8'));self.assertIn('nuavuDirectCompose',(ROOT/'web'/'codex_ui.js').read_text(encoding='utf-8'))
 def test_unique_reason_ids(self):
  ROOT=Path(__file__).resolve().parents[1];html=(ROOT/'web/index.html').read_text(encoding='utf-8')
  self.assertEqual(html.count('id="manualReason"'),1);self.assertEqual(html.count('id="noticeReason"'),1)

if __name__=='__main__':unittest.main()
