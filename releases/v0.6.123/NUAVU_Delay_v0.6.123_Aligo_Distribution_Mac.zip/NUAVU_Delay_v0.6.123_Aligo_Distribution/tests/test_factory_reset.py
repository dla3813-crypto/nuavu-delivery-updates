"""Destructive actions are confined to TemporaryDirectory + memory vaults."""
import copy,json,sqlite3,threading,time,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock,patch
from helpers import Base,MemoryVault,FakeSMS,FakeAT
from domain import Store,Engine
from desktop_backup import DesktopBackup
from desktop import DesktopAPI
from factory_reset import FactoryReset,ResetError,PHRASE,MARKER,complete_pending_reset,operation_lock

class ResetTests(Base):
    def setUp(self):
        super().setUp()
        self.backups=Path(self.tmp.name)/'Desktop'/'배포판백업'
        self.archive=DesktopBackup(self.store,self.backups);self.engine.archive=self.archive
        self.queue(sendMode='MORNING')
        with self.store.edit() as s:
            s['ablySyncCache']={'fake':{'801':{'range':'2026-10-21'}}}
            s['orderAutoImport']={'folder':'/example/Downloads','group':'그룹'}
            s['supply']={'linkedFolder':'/example/supply','batches':[]}
        self.archive.run(force=True)
        self.device=self.archive.device
        self.vaults=[MemoryVault() for _ in range(4)]
        for v in self.vaults:v.save({'secret':'FAKE-ONLY'})
        self.reset=FactoryReset(self.engine,vaults=self.vaults,backup_root=self.backups,join_timeout=.05)
    def tearDown(self):
        if not getattr(self.engine,'reset_store_closed',False):self.store.close()
        self.tmp.cleanup()
    def run_reset(self):return self.reset.run(PHRASE)
    def test_requires_exact_confirmation_without_mutation(self):
        before=self.store.read()
        for phrase in ['',True,'전체 초기화 ',{'confirmation':PHRASE}]:
            with self.assertRaises(ResetError):self.reset.run(phrase)
        self.assertEqual(self.store.read(),before);self.assertFalse(getattr(self.engine,'reset_in_progress',False))
        self.assertTrue(all(v.load() for v in self.vaults))
    def test_full_delete_and_first_launch_state(self):
        (self.store.directory/'backups'/'before-v0.6.123-20261018T001000123456Z.sqlite3').write_bytes(b'old')
        self.assertTrue(self.run_reset()['reset'])
        self.assertFalse(self.store.path.exists());self.assertFalse((self.store.directory/MARKER).exists())
        self.assertFalse((self.store.directory/'backups').exists());self.assertFalse(self.archive.folder.exists())
        self.assertTrue(all(v.load() is None for v in self.vaults));self.assertFalse(self.engine.creds);self.assertFalse(self.engine.plans)
        fresh=Store(self.store.directory)
        try:
            e=Engine(fresh,FakeSMS(),MemoryVault(),aligo_provider=FakeAT(),aligo_vault=MemoryVault())
            s=e.public_state();self.assertEqual(s['rows'],[]);self.assertEqual(s['notices'],[]);self.assertEqual(s['imports'],[])
            self.assertEqual(s['settings']['shopName'],'');self.assertEqual(s['settings']['smsUser'],'');self.assertEqual(s['settings']['tableZoom'],100)
            self.assertNotIn('ablySyncCache',fresh.read());self.assertNotIn('orderAutoImport',fresh.read())
        finally:fresh.close()
    def test_unrelated_files_other_device_and_runtime_preserved(self):
        paths=[self.store.directory/'desktop-runtime-v05'/'sentinel',self.store.directory/'manual.xlsx',self.store.directory/'running.lock',
               self.store.directory/'backups'/'my-export.xlsx',self.archive.folder/'직접보관.xlsx',self.backups/'이맥백업-ffffffffffffffff'/'일별-2026-10-18.sqlite3']
        for p in paths:p.parent.mkdir(exist_ok=True,parents=True);p.write_bytes(b'KEEP')
        self.run_reset()
        for p in paths:self.assertEqual(p.read_bytes(),b'KEEP',str(p))
    def test_no_shutdown_backup_after_reset(self):
        self.run_reset();self.engine.stop_worker()
        self.assertIsNone(self.engine.archive);self.assertFalse(self.store.path.exists());self.assertFalse(self.archive.folder.exists())
    def test_keychain_refusal_keeps_marker_and_db_then_retry(self):
        v=self.vaults[2];v.delete=MagicMock(side_effect=RuntimeError('FAKE SECRET'))
        with self.assertRaises(ResetError) as error:self.run_reset()
        self.assertNotIn('FAKE SECRET',str(error.exception));self.assertTrue(self.store.path.exists());self.assertTrue((self.store.directory/MARKER).exists())
        self.assertTrue(self.engine.reset_store_closed);self.assertIsNone(self.engine.archive)
        v.delete=MagicMock();self.assertTrue(self.run_reset()['reset']);self.assertFalse(self.store.path.exists())
    def test_interrupted_reset_finishes_before_startup(self):
        self.vaults[0].delete=MagicMock(side_effect=RuntimeError())
        with self.assertRaises(ResetError):self.run_reset()
        self.vaults[0].delete=MagicMock()
        self.assertTrue(complete_pending_reset(self.store.directory,vaults=self.vaults,backup_root=self.backups))
        self.assertFalse(self.store.path.exists());self.assertFalse(self.archive.folder.exists())
        self.assertFalse(complete_pending_reset(self.store.directory,vaults=self.vaults,backup_root=self.backups))
    def test_file_delete_failure_is_retryable_not_success(self):
        unlink=Path.unlink;blocked=self.archive.folder/'最近-not-used'
        target=next(self.archive.folder.glob('백업-*.sqlite3'))
        def failing(p,*args,**kwargs):
            if p==target:raise PermissionError('FAKE')
            return unlink(p,*args,**kwargs)
        with patch('pathlib.Path.unlink',failing):
            with self.assertRaises(ResetError):self.run_reset()
        self.assertFalse(self.reset.complete);self.assertTrue((self.store.directory/MARKER).exists())
        self.assertTrue(self.run_reset()['reset']);self.assertFalse(target.exists())
    def test_running_worker_no_delete_until_finished(self):
        stop=threading.Event();self.engine.thread=threading.Thread(target=lambda:stop.wait(2));self.engine.thread.start()
        before=self.store.read()
        try:
            with self.assertRaises(ResetError):self.run_reset()
            self.assertEqual(self.store.read(),before);self.assertFalse((self.store.directory/MARKER).exists());self.assertTrue(all(v.load() for v in self.vaults))
        finally:stop.set();self.engine.thread.join()
        self.assertTrue(self.run_reset()['reset'])
    def test_idle_zigzag_controller_cancel_error_does_not_block_reset(self):
        """10:26 보고 (Windows 첫 실행): ZigzagSync.cancel() raises when nothing runs → reset must still complete."""
        from zigzag_sync import ZigzagSyncController,ZigzagSyncError
        c=ZigzagSyncController(self.engine,vault=MemoryVault())
        with self.assertRaises(ZigzagSyncError):c.cancel()
        self.assertTrue(self.reset.run(PHRASE,[c])['reset'])
    def test_return_snapshot_and_scheduler_reset(self):
        from return_check import ReturnController
        from test_returns import rows_snapshot
        account=MemoryVault();account.save(dict(version=1,username='fake',password='fake'))
        c=ReturnController(self.engine,runner=lambda a,c:rows_snapshot(),vault=account)
        c.save(dict(mode='daily',time='23:59'));c.start();c.thread.join(2);c.start_scheduler()
        self.reset.join_timeout=1
        self.assertTrue(self.reset.run(PHRASE,[c])['reset']);self.assertFalse(c.scheduler_thread.is_alive())
        fresh=Store(self.store.directory)
        try:
            for key in ('returnCheck','returnRun','returnSettings','returnScheduledDay'):self.assertNotIn(key,fresh.read())
        finally:fresh.close()

    def test_supply_watcher_stops_before_factory_reset(self):
        self.engine.supply_watcher.start()
        self.reset.join_timeout=1
        self.assertTrue(self.run_reset()['reset'])
        self.assertFalse(self.engine.supply_watcher.running())
        fresh=Store(self.store.directory)
        try:
            e=Engine(fresh,FakeSMS(),MemoryVault(),aligo_provider=FakeAT(),aligo_vault=MemoryVault())
            self.assertFalse(e.public_state()['supply']['autoEnabled'])
            self.assertFalse(e.public_state()['supply']['progressCutoff'])
        finally:fresh.close()
    def test_busy_supply_watcher_prevents_deletion(self):
        release=threading.Event()
        self.engine.supply_watcher.thread=threading.Thread(target=lambda:release.wait(2))
        self.engine.supply_watcher.thread.start();before=self.store.read()
        try:
            with self.assertRaises(ResetError):self.run_reset()
            self.assertEqual(self.store.read(),before)
            self.assertFalse((self.store.directory/MARKER).exists())
        finally:release.set();self.engine.supply_watcher.thread.join()
        self.assertTrue(self.run_reset()['reset'])

    def test_browser_cancelled_and_joined_before_delete(self):
        stop=threading.Event();c=SimpleNamespace(thread=threading.Thread(target=lambda:stop.wait(2)),cancel=stop.set);c.thread.start()
        self.assertTrue(self.reset.run(PHRASE,[c])['reset']);self.assertFalse(c.thread.is_alive())
    def test_unfinished_browser_retains_data(self):
        stop=threading.Event();c=SimpleNamespace(thread=threading.Thread(target=lambda:stop.wait(2)),cancel=MagicMock());c.thread.start()
        try:
            with self.assertRaises(ResetError):self.reset.run(PHRASE,[c])
            self.assertTrue(self.store.path.exists());self.assertFalse((self.store.directory/MARKER).exists())
        finally:stop.set();c.thread.join()
    def test_network_lock_busy_retains_data(self):
        self.engine.network_lock.acquire()
        try:
            with self.assertRaises(ResetError):self.run_reset()
            self.assertTrue(self.store.path.exists());self.assertFalse((self.store.directory/MARKER).exists())
        finally:self.engine.network_lock.release()
    def test_known_backup_symlink_refuses_no_target_delete(self):
        target=Path(self.tmp.name)/'outside';target.write_bytes(b'KEEP')
        (self.store.directory/'backups'/'2020-01-01.sqlite3').symlink_to(target)
        with self.assertRaises(ResetError):self.run_reset()
        self.assertEqual(target.read_bytes(),b'KEEP');self.assertTrue(self.store.path.exists());self.assertFalse((self.store.directory/MARKER).exists())
    def test_foreign_edition_refused(self):
        with self.store.edit() as s:s['edition']='personal'
        with self.assertRaises(ResetError):self.run_reset()
        self.assertTrue(all(v.load() for v in self.vaults));self.assertTrue(self.store.path.exists())
    def test_tampered_marker_cannot_select_files(self):
        (self.store.directory/MARKER).write_text(json.dumps({'format':1,'edition':'aligo-distribution','device':'../../outside'}))
        with self.assertRaises(ResetError):complete_pending_reset(self.store.directory,vaults=self.vaults,backup_root=self.backups)
        self.assertTrue(all(v.load() for v in self.vaults));self.assertTrue(self.store.path.exists())
    def test_double_reset_does_not_reerase_new_files(self):
        self.run_reset();p=self.store.path;p.write_bytes(b'newly-created')
        self.assertTrue(self.run_reset()['reset']);self.assertEqual(p.read_bytes(),b'newly-created')
    def test_bridge_auth_preview_and_close(self):
        window=MagicMock();window.get_current_url.return_value='http://127.0.0.1:123/'
        b=DesktopAPI(self.engine,'token','http://127.0.0.1:123',MagicMock());b._window=window;b._factory_reset=self.reset
        before=self.store.read();self.assertEqual(b.factory_reset_preview('token')['orders'],3);self.assertEqual(before,self.store.read())
        self.assertIn('error',b.factory_reset('wrong',PHRASE));self.assertIn('error',b.factory_reset_close('token'));window.destroy.assert_not_called()
        window.get_current_url.return_value='https://evil.example/';self.assertIn('error',b.factory_reset('token',PHRASE));self.assertEqual(before,self.store.read())
        window.get_current_url.return_value='http://127.0.0.1:123/'
        self.assertTrue(b.factory_reset('token',PHRASE)['reset']);self.assertIn('error',b.pick_orders('token'))
        self.assertTrue(b.factory_reset_close('token')['closed']);window.destroy.assert_called_once();self.assertFalse(window.confirm_close)
    def test_ui_operation_finishes_before_deletion(self):
        entered=threading.Event();release=threading.Event();done=threading.Event()
        def existing():
            with operation_lock(self.engine):entered.set();release.wait(2)
        t=threading.Thread(target=existing);t.start();entered.wait(1)
        r=threading.Thread(target=lambda:(self.run_reset(),done.set()));r.start()
        self.assertFalse(done.wait(.08));self.assertTrue(self.store.path.exists());release.set();t.join(2);r.join(2);self.assertTrue(done.is_set())
    def test_only_distribution_keychain_queries_deleted(self):
        from fake_security import FakeSecurity
        from credentials import MacKeychain
        from aligo_credentials import AligoKeychain
        from ably_credentials import AblyKeychain
        from ezadmin_credentials import EzadminKeychain
        sec=FakeSecurity();services=[]
        for kind in [MacKeychain,AligoKeychain,AblyKeychain,EzadminKeychain]:
            v=kind(self.store.directory,sec);q=v._query();services.append(q[sec.kSecAttrService])
            self.assertIn('.distribution.',q[sec.kSecAttrService]);self.assertTrue(q[sec.kSecAttrAccount].startswith('profile-'))
            v.delete()
            self.assertEqual(sec.operations[-1],('delete',q))
        self.assertEqual(len(set(services)),4)
    def test_native_bridge_keeps_original_signatures(self):
        import inspect
        for name,method in vars(DesktopAPI).items():
            if name.startswith('_') or not callable(method):continue
            self.assertEqual(inspect.getfullargspec(method),inspect.getfullargspec(method.__wrapped__),name)
    def test_startup_reset_failure_prevents_store_worker_and_backup_creation(self):
        import desktop
        with patch('desktop.sys.platform','darwin'),patch('desktop.IS_MAC',True),patch.dict('sys.modules',{'webview':SimpleNamespace()}),patch('sys.argv',['desktop.py','--data-dir',str(self.store.directory)]),\
             patch('desktop.complete_pending_reset',side_effect=ResetError('초기화 재개 실패')) as resume,patch('desktop.Store') as store,patch('desktop.Engine') as engine,\
             patch('desktop.DesktopBackup') as archive,patch('desktop.show_error') as error:
            self.assertEqual(desktop.main(),1)
            resume.assert_called_once_with(self.store.directory)
            store.assert_not_called();engine.assert_not_called();archive.assert_not_called()
            error.assert_called_once_with('초기화 재개 실패')

class FactoryResetUiGlobalsTests(unittest.TestCase):
    """v0.6.123 regression: the reset click handler referenced `tableZoomTimer` after the table zoom was replaced by
    whole-page zoom, so a ReferenceError stopped it before the bridge call and 전체 초기화 silently never ran."""
    def test_timers_cleared_by_reset_are_declared_or_guarded(self):
        import re
        from pathlib import Path
        web=Path(__file__).resolve().parent.parent/'web'
        ui=(web/'factory_reset_ui.js').read_text()
        declared=set()
        for f in web.glob('*.js'):
            declared.update(re.findall(r'(?:let|const|var|function)\s+([A-Za-z_$][\w$]*)',f.read_text()))
            for decl in re.findall(r'(?:let|const|var)\s+([^;]*);',f.read_text()):declared.update(re.findall(r'(?:^|,)\s*([A-Za-z_$][\w$]*)\s*=',decl))
        for name in re.findall(r'clearTimeout\(([A-Za-z_$][\w$]*)\)',ui):
            guarded=f"typeof {name}!=='undefined'" in ui
            self.assertTrue(name in declared or guarded,f'{name} is neither declared in web/*.js nor typeof-guarded')
        for name in re.findall(r'^\s*([A-Za-z_$][\w$]*)=true;',ui,re.M):
            self.assertTrue(name in declared or f"typeof {name}!=='undefined'" in ui,name)
    def test_regression_tablezoomtimer_is_guarded(self):
        from pathlib import Path
        ui=(Path(__file__).resolve().parent.parent/'web'/'factory_reset_ui.js').read_text()
        self.assertNotIn('clearTimeout(tableZoomTimer);',ui.replace("if(typeof tableZoomTimer!=='undefined')clearTimeout(tableZoomTimer);",''))
