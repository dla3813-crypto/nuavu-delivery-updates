"""EzAdmin DS00 -> BL30 using one fresh headed Chrome browser context per run.

Only UI controls are used. Credentials come only from the app Keychain. Never
read browser cookies/saved passwords, inject site functions,
use private export APIs, or suppress TLS/browser security checks.
"""
from datetime import datetime
import re
import time
import html
import json
from urllib.parse import urlsplit, quote
from order_auto import (OrderAutoError, Cancelled, KST, server_request_window, requested_job, window_text, checked_request_name, checked_link, persist_download)

LOGIN_URL='https://login2.ezadmin.co.kr/login.htm'
SEARCH_PATH='/template35.htm?template=DS00'
DOWNLOAD_PATH='/template40.htm?template=BL30'

def is_admin_host(host):
    return bool(re.fullmatch(r'ga\d+\.ezadmin\.co\.kr',host or ''))
JOB_POLL_SECONDS=5
JOB_WAIT_SECONDS=600
LOGIN_FIELDS=(('#login-domain','domain'),('#login-id','username'),('#login-pwd','password'))

def safe_location(url):
    """Diagnostic categories only: never keep a URL path, query, token or userinfo."""
    try:
        u=urlsplit(url)
        if u.scheme=='chrome-error':return 'Chrome 연결 오류 화면'
        if url=='about:blank':return '빈 화면'
        if (u.hostname=='login2.ezadmin.co.kr' or is_admin_host(u.hostname)):
            return ('HTTPS' if u.scheme=='https' else 'HTTP' if u.scheme=='http' else '다른 연결 방식')+' · '+u.hostname
        if u.hostname and u.hostname.endswith('.ezadmin.co.kr'):return '이지어드민의 다른 서버'
        return '확인되지 않은 외부 주소'
    except ValueError:return '확인할 수 없는 주소'

NETWORK_CODES={'ERR_NAME_NOT_RESOLVED','ERR_CONNECTION_RESET','ERR_CONNECTION_REFUSED',
    'ERR_CONNECTION_CLOSED','ERR_CONNECTION_TIMED_OUT','ERR_TIMED_OUT','ERR_INTERNET_DISCONNECTED',
    'ERR_CERT_AUTHORITY_INVALID','ERR_CERT_DATE_INVALID','ERR_CERT_COMMON_NAME_INVALID',
    'ERR_SSL_PROTOCOL_ERROR','ERR_TOO_MANY_REDIRECTS','ERR_ABORTED','ERR_HTTP_RESPONSE_CODE_FAILURE'}

def network_code(text):
    # Do not expose arbitrary browser exception strings (they may contain form values).
    for code in re.findall(r'\bERR_[A-Z_]+\b',str(text or '')):
        if code in NETWORK_CODES:return code
    return ''

def safe_login_notice(text, account):
    value=str(text or '')
    # Only the redacted notice is allowed in the app's in-memory status.
    for secret in sorted({str(account.get(k,'')) for k in ('domain','username','password')} - {''},key=len,reverse=True):
        for variant in {secret,quote(secret,safe=''),html.escape(secret),json.dumps(secret,ensure_ascii=True)[1:-1]}:
            value=value.replace(variant,'[가림]')
    value=re.sub(r'https?://\S+','[주소]',value)
    value=re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]','',value)
    return value[:600]

def login_notice_kind(text):
    t=re.sub(r'\s+',' ',str(text)).lower()
    if any(word in t for word in ('captcha','recaptcha','자동화','로봇','보안 인증','보안인증','접근 제한','접근제한','차단')):
        return 'security'
    if re.search(r'(비밀번호|패스워드|아이디|도메인).{0,35}(일치하지|틀렸|틀립니다|잘못|존재하지|올바르지)',t):
        return 'credentials'
    if re.search(r'(오류|실패|불가|접속할 수 없|연결할 수 없)',t):return 'technical'
    return 'notice'

class StepTimeout(OrderAutoError):
    """A wait in Flow.until ran out (screen did not respond in time)."""

class CaptchaNeeded(OrderAutoError):
    """다운로드 신청 뒤 안내창 대신 캡차가 떠서 사람이 해야 함."""
    def __init__(self,message,page,started):super().__init__(message);self.page=page;self.started=started
class HeadedRelaunch(Exception):
    """Headless run hit the captcha: reopen with a visible window and start over."""
class CaptchaUnanswered(OrderAutoError):
    """2026-10-29: 캡차 인증 요청에 1분 동안 응답이 없음 → 창을 닫고 2분 뒤 처음부터 다시 수집."""
CAPTCHA_WAIT_SECONDS=1800    # 사람이 [제가 직접 할게요]/[다운로드 완료] 로 맡았을 때
CAPTCHA_ANSWER_SECONDS=60    # 2026-10-29: 이 시간 안에 응답이 없으면 자동 재수집
CAPTCHA_RETRY_GAP=120        # 재수집 간격 (2분)
CAPTCHA_RETRY_TIMES=20       # 최대 재수집 횟수

RETRY_TIMES=3     # 2026-10-21: 시간 초과 후 30초 간격 3회 추가 시도, 그래도 안 되면 오류 + 알림
RETRY_WAIT=30

def retryable_timeout(exc,flow):
    if getattr(flow,'export_requested',False):return False   # an export click is never replayed
    if str(getattr(flow,'step','')).startswith('로그인'):return False   # never re-submit the login
    return isinstance(exc,StepTimeout) or type(exc).__name__=='TimeoutError'

# 2026-10-21: 이지어드민 보안코드 입력 화면 — 입력하지 않는다. 대시보드에서 바로 다음 페이지로 이동한다.
SECCODE_JS=r"""()=>{
  const vis=e=>{const r=e.getBoundingClientRect();const cs=getComputedStyle(e);return r.width>0&&r.height>0&&cs.visibility!=='hidden'&&cs.display!=='none';};
  const labels=[...document.querySelectorAll('body *')].filter(e=>e.children.length<=3&&/보안\s*코드/.test(e.textContent||'')&&(e.textContent||'').length<200&&vis(e));
  for(const l of labels){let box=l;for(let up=0;up<5&&box;up++,box=box.parentElement){
    const inp=[...box.querySelectorAll('input')].find(i=>vis(i)&&!['hidden','checkbox','radio','submit','button','image'].includes(i.type)&&!/^login-/.test(i.id||''));
    if(inp)return true;}}
  return false;}"""

ROWS_JS='''es=>es.map(e=>{const t=n=>e.querySelector('[aria-describedby="grid1_'+n+'"]')?.innerText?.trim()||'';return {id:e.querySelector('.del_worklist')?.value||'',at:t('crdate'),template:t('template'),name:t('file_name'),status:t('status'),percent:t('work_percent'),href:e.querySelector('[aria-describedby="grid1_file_name"] a')?.href||''}})'''

class Flow:
    def __init__(self, controller, context):
        self.c=controller;self.context=context;self.page=None;self.step='브라우저 준비';self.connection_error=''
        self.tabs=[];self.pages_configured=False;self.admin_host=None
        self.export_requested=False
        self.export_acknowledged=False;self.export_accepted=False
        self.manager_clock=None

    def register_page(self,page):
        if page in self.tabs:return
        self.tabs.append(page)
        self.watch_connection(page)
        # Popups belong to the same context: keep their cookies/session and do
        # not close them, cancel requests, or replace the user's browser profile.

    def configure_pages(self):
        if self.pages_configured:return
        self.context.on('page',self.register_page)
        for page in self.context.pages:self.register_page(page)
        self.pages_configured=True

    def live_pages(self):
        return [page for page in self.context.pages if not page.is_closed()]

    def authenticated_page(self):
        for page in self.live_pages():
            if self.authenticated(page):return page
        return None

    def navigate(self,page,url):
        if 'template=BL30' in urlsplit(url).query and not (self.export_acknowledged and self.export_accepted):
            raise OrderAutoError('확인했습니다 입력과 다운로드 접수 완료 전에는 다운로드관리자로 이동하지 않습니다.')
        self.page=page
        page.bring_to_front()
        import browser_window;browser_window.reminimize(page)
        # DOM readiness matches Nuavu Auto; waiting for every external resource
        # to finish can hold an already usable login page indefinitely.
        sent=datetime.now(KST);tick=time.monotonic()
        response=page.goto(url,wait_until='domcontentloaded',timeout=30000)
        received=datetime.now(KST);elapsed=time.monotonic()-tick
        if 'template=BL30' in urlsplit(url).query:
            self.manager_clock=None
            if response and response.url==url and response.status==200 and not response.from_service_worker:
                self.manager_clock=(response.headers.get('date'),sent,received,elapsed,response.headers.get('age','0'))

    def watch_connection(self,page):
        def failed(request):
            try:
                if request.is_navigation_request() and request.frame==page.main_frame:
                    self.connection_error=network_code(request.failure)
            except Exception:pass
        page.on('requestfailed',failed)

    def failure_message(self,exc,account):
        if isinstance(exc,OrderAutoError):reason=safe_login_notice(str(exc),account)
        elif type(exc).__name__=='TimeoutError':reason='화면 응답을 기다리다 시간이 초과되었습니다.'
        else:reason='Chrome과의 연결 또는 화면 처리 중 문제가 발생했습니다.'
        code=network_code(str(exc)) or self.connection_error
        location=safe_location(self.page.url) if self.page else '창 열기 전'
        return f'{self.step} 단계에서 중단했습니다. {reason}\n현재 화면: {location}'+(f' · {code}' if code else '')

    def keep_failure_open(self,message,can_continue=False):
        pages=self.live_pages()
        self.c.browser_failed(message,bool(pages),can_continue)
        def manual_notice(dialog):
            # Secrets were cleared after failure. Do not copy arbitrary dialog
            # contents into app status; the user can inspect the Chrome window.
            accepted=False;expired=False
            try:
                if dialog.type!='prompt':
                    accepted=self.c.ask_login_confirmation(
                        'Chrome에 표시된 사이트 안내를 확인하세요. '+safe_location(dialog.page.url)+
                        '\n확인을 누르면 해당 안내를 승인하고, 취소를 누르면 거절합니다.')
            except OrderAutoError:expired=True
            finally:
                try:
                    if accepted and not self.c.stop.is_set():dialog.accept()
                    else:dialog.dismiss()
                except Exception:pass
            if not self.c.stop.is_set():
                hint=('별도 문자 입력이 필요한 확인창은 취소했습니다. Chrome에서 필요한 인증을 확인하세요.' if dialog.type=='prompt'
                      else '응답을 기다리던 확인 요청을 취소했습니다.' if expired
                      else '사이트 안내를 확인했습니다.' if accepted else '사이트 확인 요청을 취소했습니다.')
                if can_continue:hint+=' 로그인 완료 후 이어가기를 누르세요.'
                self.c.browser_failed(hint,bool(self.live_pages()),can_continue)
        self.context.on('dialog',manual_notice)
        try:
            while pages and not self.c.stop.is_set():
                command=self.c.take_browser_action()
                if command:
                    action,url=command
                    self.connection_error=''
                    if action=='continue':
                        signed_in=self.authenticated_page()
                        if signed_in:
                            self.page=signed_in;self.c.end_browser_recovery()
                            self.c.update('login','로그인 완료를 확인했습니다. 요청한 작업을 이어갑니다.')
                            return signed_in
                        self.c.browser_failed('로그인 완료를 확인하지 못했습니다. Chrome에서 로그인을 완료한 뒤 다시 확인하세요.',True,can_continue)
                    else:
                        page=self.page if self.page and not self.page.is_closed() else pages[0]
                        self.step='로그인 페이지 다시 열기'
                        try:
                            self.navigate(page,url)
                            hint='같은 탭에 로그인 페이지를 열었습니다. '
                            hint+=('Chrome에서 직접 로그인한 뒤 이어가기를 누르세요.' if can_continue else '엑셀 신청을 시작한 작업은 다운로드관리자에서 결과를 확인하세요.')
                            self.c.browser_failed(hint,True,can_continue)
                        except Exception as exc:
                            self.c.browser_failed(self.failure_message(exc,{}),bool(self.live_pages()),can_continue)
                try:pages[0].wait_for_timeout(150)
                except Exception:
                    # A tab may navigate/close while waiting. Keep other live
                    # tabs and the original error instead of closing Chrome.
                    if self.context.browser and not self.context.browser.is_connected():break
                    time.sleep(.15)
                pages=self.live_pages()
        finally:self.context.remove_listener('dialog',manual_notice)

    def clear_password(self):
        pages=list(self.tabs)
        if self.page and self.page not in pages:pages.append(self.page)
        for page in pages:
            try:
                self.trusted_login(page)
                field=page.locator('#login-pwd')
                if field.is_visible():field.fill('',timeout=1000)
            except Exception:pass
    def pause(self, seconds):
        end=time.monotonic()+seconds
        while time.monotonic()<end:
            self.c.check()
            # Keep Playwright's event loop alive while waiting for site changes.
            # This also catches delayed popup closures instead of waiting to timeout.
            page=self.page if self.page and not self.page.is_closed() else next(iter(self.live_pages()),None)
            if page is None:raise OrderAutoError('자동 불러오기 Chrome 창이 닫혔습니다.')
            try:page.wait_for_timeout(min(100,max(1,(end-time.monotonic())*1000)))
            except Exception:
                if not page.is_closed() or not self.live_pages():raise
    def until(self, predicate, timeout, message):
        end=time.monotonic()+timeout
        while time.monotonic()<end:
            self.c.check()
            result=predicate()
            if result: return result
            self.pause(.25)
        raise StepTimeout(message)
    def admin_url(self,path):
        if not self.admin_host:raise OrderAutoError('로그인 서버를 확인하지 못했습니다.')
        return 'https://'+self.admin_host+path

    def known_page(self, page):
        u=urlsplit(page.url)
        if u.scheme!='https' or (not self.admin_host or u.hostname!=self.admin_host) or u.port not in (None,443) or u.username or u.password:
            raise OrderAutoError('이지어드민 연결 또는 보안 확인이 필요합니다. Chrome 창을 확인하세요.')
    def trusted_login(self,page):
        u=urlsplit(page.url)
        if (u.scheme,u.hostname,u.path)!=('https','login2.ezadmin.co.kr','/login.htm') or u.port not in (None,443) or u.username or u.password:
            raise OrderAutoError('로그인 주소를 확인하지 못해 계정을 입력하지 않았습니다.')

    def guard_login_input(self,page):
        self.c.check();self.trusted_login(page)
        if getattr(self,'login_error',None):raise OrderAutoError(self.login_error)

    def verify_login_values(self,page,account):
        # Compare in memory only. Never interpolate credentials into assertions,
        # JavaScript, diagnostics or logs; do not silently trim or repair them.
        for selector,key in LOGIN_FIELDS:
            self.guard_login_input(page)
            if page.locator(selector).input_value()!=account[key]:
                raise OrderAutoError('저장한 계정과 로그인 입력칸의 값이 달라 전송하지 않았습니다. 이지어드민 설정에서 계정을 다시 저장하세요.')
        self.guard_login_input(page)

    def enter_login_fields(self,page,account):
        # Validate every field before sending any keys. A newline/tab could
        # submit or focus another field; a maxlength must not truncate a secret.
        for selector,key in LOGIN_FIELDS:
            self.guard_login_input(page)
            value=account[key]
            if not isinstance(value,str) or not value or any(ord(c)<32 or ord(c)==127 for c in value):
                raise OrderAutoError('로그인 정보에 빈 값이나 줄바꿈·제어문자가 있어 전송하지 않았습니다. 설정에서 다시 저장하세요.')
            limit=page.locator(selector).get_attribute('maxlength')
            if limit and limit.isdecimal() and len(value.encode('utf-16-le'))//2>int(limit):
                raise OrderAutoError('저장한 계정이 로그인 입력칸의 최대 길이를 초과해 전송하지 않았습니다. 설정에서 다시 저장하세요.')
        for selector,key in LOGIN_FIELDS:
            self.guard_login_input(page)
            field=page.locator(selector)
            field.fill('')
            # fill() emits input but not per-character keydown/keypress/keyup.
            # Use browser keyboard events for forms that also track typing.
            for character in account[key]:
                self.guard_login_input(page)
                field.press_sequentially(character,delay=20,timeout=15000)
            self.guard_login_input(page)
            field.press('Tab')  # Finish change/blur handling before submission.
        self.verify_login_values(page,account)

    def seccode_screen(self,page):
        """True when a visible 보안코드 input screen is shown on this admin page (any same-host frame)."""
        try:host=urlsplit(page.url).hostname
        except Exception:return False
        for frame in page.frames:
            try:
                if urlsplit(frame.url).hostname!=host:continue
                if frame.evaluate(SECCODE_JS) is True:return True
            except Exception:continue
        return False
    def close_extra_pages(self):
        pages=self.live_pages()
        if not pages:return
        keep=self.authenticated_page() or pages[0]
        for extra in [x for x in pages if x is not keep]:
            try:extra.close()
            except Exception:pass
    def authenticated(self,page):
        # A driver read lets sync Playwright dispatch pending redirect/dialog
        # events; polling only its cached URL while sleeping can miss login.
        try:page.locator('body').count()
        except Exception:return False
        u=urlsplit(page.url)
        if u.scheme!='https' or not is_admin_host(u.hostname) or (self.admin_host and u.hostname!=self.admin_host) or u.port not in (None,443) or u.username or u.password:return False
        for frame in page.frames:
            f=urlsplit(frame.url)
            if f.scheme!='https' or f.hostname!=u.hostname or f.port not in (None,443) or f.username or f.password:continue
            try:
                links=frame.locator('a[href*="logout.php"]')
                if any(links.nth(i).is_visible() for i in range(links.count())):
                    self.admin_host=u.hostname
                    return True
            except Exception:
                # Login redirects can replace the frame during this read. Retry the
                # visible success check; a browser exception never proves login.
                continue
        if self.seccode_screen(page):
            if 'admin_host' in vars(self) and not self.admin_host:self.admin_host=u.hostname
            if not getattr(self,'seccode_skipped',False):
                self.seccode_skipped=True
                try:self.c.update('login','이지어드민 보안코드 입력 화면 → 보안코드는 입력하지 않고 다음 페이지로 바로 이동합니다.')
                except Exception:pass
            return True
        return False

    def authenticate(self,page,account):
        self.configure_pages()
        self.page=page
        self.step='로그인 페이지 열기'
        self.c.update('login','이지어드민 로그인 페이지를 먼저 엽니다.')
        self.login_error=None;self.login_notice=None;self.had_confirmation=False
        def notice(dialog):
            # Authentication may visit another server. Never type credentials
            # there or auto-approve its dialogs; ask for an explicit choice.
            u=urlsplit(dialog.page.url)
            if u.scheme!='https' or not (u.hostname=='login2.ezadmin.co.kr' or u.hostname==self.admin_host) or u.port not in (None,443) or u.username or u.password:
                self.had_confirmation=True;accepted=False
                try:
                    if dialog.type!='prompt':
                        accepted=self.c.ask_login_confirmation('로그인 중 다른 서버의 안내입니다. '+safe_location(dialog.page.url)+'\n'+safe_login_notice(dialog.message,account))
                except OrderAutoError as exc:self.login_error=str(exc)
                if accepted and not self.c.stop.is_set():dialog.accept()
                else:
                    self.login_error=self.login_error or '추가 인증 안내를 취소했습니다. Chrome 창에서 확인하세요.'
                    dialog.dismiss()
                return
            text=safe_login_notice(dialog.message,account)
            if dialog.type=='confirm':
                if len(str(dialog.message))>600:
                    self.login_error='로그인 확인 안내가 길어 자동 진행을 중단했습니다. 일반 Chrome에서 전체 내용을 확인하세요.'
                    dialog.dismiss();return
                self.had_confirmation=True
                try:accepted=self.c.ask_login_confirmation(text)
                except OrderAutoError as exc:
                    self.login_error=str(exc);accepted=False
                if accepted:dialog.accept()
                else:
                    self.login_error=self.login_error or '로그인 확인 요청을 취소했습니다. 기존 주문은 유지됩니다.'
                    dialog.dismiss()
                return
            kind=login_notice_kind(dialog.message)
            if dialog.type=='prompt':
                self.login_error='로그인에 별도 입력이 필요해 중단했습니다. 일반 Chrome에서 인증 내용을 확인하세요.'
            elif kind=='credentials':
                self.login_error='이지어드민에서 계정 정보 불일치를 안내했습니다. 사이트 안내: '+text
            elif kind=='security':
                self.login_error='이지어드민 보안 확인이 필요합니다. 계정 오류로 판단하지 않았습니다. 사이트 안내: '+text
            elif kind=='technical':
                self.login_error='이지어드민 로그인 처리 중 사이트 오류가 발생했습니다. 계정 오류로 판단하지 않았습니다. 사이트 안내: '+text
            else:
                self.login_notice=text
                self.c.update('login','이지어드민 안내: '+text)
            dialog.dismiss()
        self.context.on('dialog',notice)
        try:
            try:self.navigate(page,LOGIN_URL)
            except Exception:
                if not (page.is_closed() and self.live_pages()):raise
            def ready():
                if self.login_error:raise OrderAutoError(self.login_error)
                return self.authenticated_page() or (not page.is_closed() and page.locator('#login-domain').is_visible())
            self.until(ready,30,'로그인 화면을 열지 못했습니다. 인터넷 연결과 로그인 페이지를 확인하세요.')
            signed_in=self.authenticated_page()
            if signed_in:
                self.page=signed_in
                return signed_in
            self.c.check();self.trusted_login(page)
            self.step='로그인 정보 입력'
            self.c.update('login','키체인에 저장한 계정을 키보드 방식으로 입력하고 확인합니다.')
            self.enter_login_fields(page,account)
            saved=page.locator('#savedomain')
            if saved.count():saved.set_checked(False) # Keychain owns persistence; no password cookie copy.
            self.verify_login_values(page,account)
            self.step='로그인 버튼 처리'
            try:page.get_by_role('button',name='로그인',exact=True).click(timeout=15000)
            except Exception:
                # A human may spend longer than the click timeout on a confirm.
                # Continue observing; never click/re-submit the login a second time.
                if not self.had_confirmation and not (page.is_closed() and self.live_pages()):raise
            self.c.update('login','로그인 완료를 확인합니다. 추가 인증이 나오면 Chrome 창에서 직접 완료하세요.'+(' 사이트 안내: '+self.login_notice if self.login_notice else ''))
            self.step='로그인 결과 확인'
            import time as _t,browser_window
            started=_t.monotonic()
            def finished():
                self.c.check()
                if _t.monotonic()-started>8:
                    if browser_window.need_person():raise OrderAutoError('추가 인증 또는 로그인 확인이 필요합니다. '+browser_window.need_person())
                    browser_window.attention()  # extra authentication likely: let the person see the window
                signed_in=self.authenticated_page()
                if self.login_error:raise OrderAutoError(self.login_error)
                if signed_in:
                    self.page=signed_in
                    return signed_in
                if page.is_closed():return False  # A login popup may outlive its opener.
                # A different domain alone is not a login failure. Observe the
                # redirect/popup until verified server authentication or timeout.
                return False
            return self.until(finished,180,'로그인 완료를 확인하지 못했습니다. 계정 오류로 판단하지 않았습니다. 일반 Chrome에서는 된다면 전용 창의 추가 인증·사이트 연결 상태를 확인하세요.'+(' 사이트 안내: '+self.login_notice if self.login_notice else ''))
        finally:
            self.context.remove_listener('dialog',notice)
            self.clear_password()

    def protected_page(self,page,url,marker):
        self.step='주문검색 연결' if url==self.admin_url(SEARCH_PATH) else '다운로드관리자 연결'
        self.page=page
        self.navigate(page,url);self.known_page(page)
        self.pause(.5)
        if self.seccode_screen(page):raise OrderAutoError('다음 페이지에도 보안코드 입력 화면이 나와 중단했습니다. 보안코드는 입력하지 않았습니다.')
        if 'mysqli' in page.locator('body').inner_text().lower():
            raise OrderAutoError('로그인 세션을 주문검색에 연결하지 못했습니다. 이지어드민 설정과 로그인 상태를 확인하세요.')
        page.locator(marker).wait_for(state='visible',timeout=20000)
        if not self.authenticated(page):
            raise OrderAutoError('로그인이 만료되었습니다. 자동 불러오기를 다시 눌러 로그인부터 시작하세요.')

    def grid_ready(self, page):
        # jqGrid has a visible loading mask while the asynchronous query runs.
        self.until(lambda: page.locator('#grid1 tr.jqgrow').count() or
                   ('표시할 행이 없습니다' in page.locator('#gridpager').inner_text() and not page.locator('#load_grid1').is_visible()),
                   45,'조회가 완료되지 않았습니다. 기존 주문은 유지됩니다.')
    def jobs(self, page):
        # jqGrid can still contain old rows while fetching its next result.
        self.until(lambda: not page.locator('#load_grid1').is_visible() and
                   (page.locator('#grid1 tr.jqgrow').count() or
                    '표시할 행이 없습니다' in page.locator('#gridpager').inner_text()),
                   45,'다운로드 목록 조회가 끝나지 않았습니다. 열린 Chrome에서 목록을 확인하세요.')
        return page.locator('#grid1 tr.jqgrow').evaluate_all(ROWS_JS)

    def wait_download_job(self,manager,started,accepted):
        self.page=manager;self.step='다운로드 요청시간 대조'
        deadline=time.monotonic()+JOB_WAIT_SECONDS;selected_id=None;selected_at=None
        while True:
            self.c.check();self.known_page(manager)
            # Read the initial result before refreshing. Keep the same request
            # ID/time through status changes, rather than choosing the latest file.
            rows=self.jobs(manager);job=requested_job(rows,started,accepted)
            if job:
                if selected_id is not None and (selected_id!=job['id'] or selected_at!=job['at']):
                    raise OrderAutoError('생성 대기 중 다운로드 작업 번호 또는 요청시간이 바뀌어 중단했습니다. 수동으로 파일을 확인하세요.')
                selected_id=job['id'];selected_at=job['at']
                status=job.get('status','').strip()
                if status=='완료':
                    self.c.check()
                    return job
                if '실패' in status or '오류' in status or '취소' in status:
                    raise OrderAutoError('이번 주문 엑셀 작업이 실패하거나 취소되었습니다. 다운로드관리자에서 확인하세요.')
                self.step='주문 엑셀 완료 대기'
                label=status if status in {'대기','대기중','대기 중','진행','진행중','진행 중','작업중','작업 중','처리중','처리 중'} else '처리 중'
                message=f'요청시간 {selected_at} 확인 · 상태 {label} · 5초 후 다시 확인합니다.'
            else:
                self.step='다운로드 요청시간 대조'
                message=f'서버 기준 신청시간 {window_text(started,accepted)}의 확장주문검색을 찾는 중 · 5초 후 다시 확인합니다.'
            if time.monotonic()+JOB_POLL_SECONDS>deadline:
                if selected_id is None:
                    raise OrderAutoError(f'신청시간 {window_text(started,accepted)}에 맞는 주문 엑셀을 찾지 못했습니다. 사이트 요청시간과 Mac 시간을 확인하세요. 이전 파일은 가져오지 않았습니다.')
                raise OrderAutoError('이번 주문 엑셀의 완료를 10분 안에 확인하지 못했습니다. 다운로드관리자에서 해당 요청시간의 작업을 확인하세요.')
            self.c.update('waiting',message)
            self.pause(JOB_POLL_SECONDS);self.c.check()
            # Refresh the list with its search control. Keep the document and
            # session instead of interrupting ongoing navigation with reload().
            self.step='다운로드 목록 새로고침'
            manager.locator('#search').click(timeout=10000)

    def download_job(self,manager,job,started,folder):
        self.step='완료된 주문 엑셀 확인';self.c.check();self.known_page(manager)
        name=checked_request_name(job['name'],started);checked_link(job['href'],name)
        # The authenticated manager may serve exports from another ga server.
        # Bind the download to this verified row's link, not the login host.
        row=manager.locator('#grid1 tr.jqgrow').filter(has=manager.locator(
            'input.del_worklist[value='+json.dumps(str(job['id']))+']'))
        if row.count()!=1:
            raise OrderAutoError('완료된 다운로드 작업을 하나로 확인하지 못했습니다.')
        current=row.evaluate_all(ROWS_JS)[0]
        if any(current.get(k)!=job.get(k) for k in ('id','at','template','name','href')) or current.get('status','').strip()!='완료':
            raise OrderAutoError('완료된 다운로드 행이 변경되었습니다. 파일을 가져오지 않았습니다.')
        link=row.get_by_role('link',name=name,exact=True)
        if link.count()!=1 or link.evaluate('(e)=>e.href')!=job['href']:
            raise OrderAutoError('완료된 주문 엑셀의 다운로드 링크를 확인하지 못했습니다.')
        self.step='주문 엑셀 저장'
        self.c.update('downloading',f'요청시간 {job["at"]} · 완료 확인 · 새 확장주문검색 엑셀을 저장합니다.')
        self.c.check()
        with manager.expect_download(timeout=30000) as result:
            link.click(timeout=10000)
        download=result.value
        if download.suggested_filename!=name:raise OrderAutoError('다운로드 파일명이 요청 결과와 다릅니다.')
        checked_link(download.url,name)
        if download.url!=job['href']:raise OrderAutoError('완료 목록에서 확인한 파일 주소와 달라 저장하지 않았습니다.')
        data=persist_download(download,folder,name)
        self.c.check();return name,data

    def find_text(self, page, text):
        for frame in page.frames:
            loc=frame.get_by_text(text,exact=True)
            for i in range(loc.count()):
                item=loc.nth(i)
                if item.is_visible(): return item
        return None
    def click_text(self,page,text):
        item=self.until(lambda:self.find_text(page,text),20,'이지어드민 확인 화면이 바뀌었습니다. 열린 Chrome 창을 확인하고 수동으로 다운로드하세요.')
        item.click(timeout=10000)
    def export_popup(self,page,selector,image_path):
        """The site's first two notices and receipt are CSS images, not text."""
        self.c.check();self.known_page(page)
        matches=[]
        for frame in page.frames:
            try:self.known_page(frame)
            except OrderAutoError:continue
            loc=frame.locator(selector)
            for i in range(loc.count()):
                item=loc.nth(i)
                if not item.is_visible():continue
                bg=item.evaluate('(e)=>getComputedStyle(e).backgroundImage')
                m=re.fullmatch(r'url\([\"\']?(.*?)[\"\']?\)',bg)
                if not m:continue
                u=urlsplit(m.group(1))
                if (u.scheme=='https' and u.hostname==self.admin_host
                    and u.port in (None,443) and not u.username and not u.password
                    and u.path==image_path):matches.append(item)
        if len(matches)>1:raise OrderAutoError('다운로드 안내창이 여러 개 보여 중단했습니다. 열린 Chrome 창을 확인하세요.')
        return matches[0] if matches else None

    def export_stage(self,message):
        self.c.check();self.step=message;self.c.update('request',message)

    def click_export_notice(self,page,selector,image_path,button,title,text):
        def locate():
            popup=self.export_popup(page,selector,image_path)
            if popup:
                item=popup.locator(button)
                if item.count()==1 and item.is_visible() and item.is_enabled():return item
                return None
            # Text variants must have the expected heading and a button in
            # that same dialog; unrelated page-wide '확인' buttons are ignored.
            matches=[]
            for frame in page.frames:
                try:self.known_page(frame)
                except OrderAutoError:continue
                dialogs=frame.get_by_role('dialog').filter(has_text=title)
                for i in range(dialogs.count()):
                    dialog=dialogs.nth(i);item=dialog.get_by_role('button',name=text,exact=True)
                    if dialog.is_visible() and item.count()==1 and item.is_visible() and item.is_enabled():matches.append(item)
            if len(matches)>1:raise OrderAutoError('다운로드 안내창이 여러 개 보여 중단했습니다.')
            return matches[0] if matches else None
        item=self.until(locate,20,f'{title}의 {text} 버튼을 찾지 못했습니다. 열린 Chrome 창을 확인하세요.')
        self.c.check();self.known_page(page);item.click(timeout=10000)

    def export_receipt(self,page):
        popup=self.export_popup(page,'#pop_download_complete','/images/download_info_complete.png')
        if popup:return popup
        for frame in page.frames:
            try:self.known_page(frame)
            except OrderAutoError:continue
            receipt=frame.get_by_role('dialog').get_by_text('요청하신 다운로드 작업이 접수되었습니다.',exact=True)
            if receipt.count()==1 and receipt.is_visible():return receipt
        return None

    def export_ack_controls(self,page):
        self.c.check();self.known_page(page)
        matches=[]
        for frame in page.frames:
            try:self.known_page(frame)
            except OrderAutoError:continue
            dialogs=frame.get_by_role('dialog').filter(has=frame.get_by_text('다운로드 안내',exact=True))
            for i in range(dialogs.count()):
                dialog=dialogs.nth(i)
                box=dialog.locator('input#swal2-input')
                confirm=dialog.get_by_role('button',name='확인',exact=True)
                if (dialog.is_visible() and box.count()==1 and box.is_visible()
                    and box.is_enabled() and confirm.count()==1 and confirm.is_visible()
                    and confirm.is_enabled()):matches.append((box,confirm))
        if len(matches)>1:raise OrderAutoError('다운로드 확인 입력창이 여러 개 보여 중단했습니다.')
        return matches[0] if matches else None

    def export_dialogs(self,page):
        if self.export_receipt(page):
            raise OrderAutoError('이전 다운로드 접수 안내가 남아 있습니다. 새 작업으로 처리하지 않습니다.')
        self.export_stage('다운로드 신청 버튼 확인')
        self.click_export_notice(page,'#pop_download_info','/images/download_info_request.png',
            '#btn_download_info1','다운로드 변경 안내','다운로드 신청')
        self.export_stage('개인정보 파기 안내 확인')
        self.click_export_notice(page,'#pop_personal_information','/images/personal_infomation_popup.png',
            '.btn_cnf','개인정보 파기 안내','확인')
        self.export_stage('확인했습니다 입력')
        box,confirm=self.until(lambda:self.export_ack_controls(page),20,'다운로드 확인 입력란을 찾지 못했습니다.')
        self.c.update('request','다운로드 안내에 확인했습니다를 입력합니다.')
        box.fill('')
        box.press_sequentially('확인했습니다',delay=20)
        box.press('Tab')
        self.c.check();self.known_page(page)
        if not box.is_visible() or box.input_value()!='확인했습니다':
            raise OrderAutoError('확인했습니다 입력을 확인하지 못했습니다. 다운로드관리자로 이동하지 않습니다.')
        self.export_stage('다운로드 최종 확인')
        if self.export_receipt(page):
            raise OrderAutoError('최종 확인 전에 접수 안내가 나타나 중단했습니다. 기존 파일은 가져오지 않습니다.')
        self.c.check();self.known_page(page)
        if not box.is_visible() or box.input_value()!='확인했습니다':
            raise OrderAutoError('확인했습니다 입력이 변경되어 다운로드 신청을 중단했습니다.')
        self.export_acknowledged=True
        started=datetime.now(KST)
        confirm.click(timeout=10000)
        self.export_stage('다운로드 접수 완료 확인')
        self.until(lambda:self.export_receipt(page),20,'다운로드 접수를 확인하지 못했습니다. 기존 파일은 가져오지 않습니다.')
        self.c.check();self.export_accepted=True
        return started,datetime.now(KST)

    def execute(self,cfg,account):
        self.configure_pages()
        page=self.context.pages[0] if self.context.pages else self.context.new_page()
        page=self.authenticate(page,account)
        if cfg.get('loginOnly'):return None
        return self.export_orders(page,cfg)

    def export_orders(self,page,cfg):
        self.c.check()
        if self.export_requested:raise OrderAutoError('이미 엑셀 신청을 시작한 작업입니다. 다시 신청하지 않았습니다.')
        self.protected_page(page,self.admin_url(SEARCH_PATH),'#date_period_sel')
        self.step='주문 검색조건 설정'
        self.c.update('search','최근한달 · 접수+송장 · C/S 정상+교환 · 판매처 그룹을 설정합니다.')
        page.locator('select[name="date_type"]').select_option(label='발주일')
        page.locator('#date_period_sel').select_option(label='최근한달')
        page.locator('select[name="status_sel"]').select_option(label='접수+송장')
        page.locator('select[name="order_cs_sel"]').select_option(label='정상+교환')   # 2026-10-30: 배송전 교환(옵션 교환 후 출고 대기)도 미출고로 잡는다
        page.locator('#is_packed').set_checked(False)
        # Clear unrelated conditions even if EzAdmin restores a prior query.
        for selector,value in [('#str_supply_code','0'),('select[name="pack_sel"]','0'),('select[name="check_set_match"]','0'),('select[name="work_type"]','0'),('#trans_corp','99')]:
            control=page.locator(selector)
            if control.count(): control.select_option(value=value)
        query=page.locator('input[name="table_search_row_query_str"]')
        if query.count(): query.fill('')
        with page.expect_popup(timeout=15000) as pop:
            page.locator('span[onclick="javascript:openWinShopDetail()"]').click()
        group=pop.value;group.wait_for_load_state('domcontentloaded');self.known_page(group)
        group.locator('input.chk_group').first.wait_for(state='visible',timeout=15000)
        for check in group.locator('input.chk_group').all(): check.set_checked(False)
        target=group.locator('li').filter(has_text=re.compile(r'^\s*'+re.escape(cfg['group'])+r'\s*$')).locator('input.chk_group')
        if target.count()!=1: raise OrderAutoError('설정한 판매처 그룹을 찾지 못했습니다. 그룹 이름을 확인하세요.')
        target.set_checked(True)
        if group.locator('input.chk_group:checked').count()!=1: raise OrderAutoError('판매처 그룹 선택을 확인하지 못했습니다.')
        group.locator('span[onclick="javascript:set_shop_group()"]').click()
        self.until(lambda:group.is_closed(),15,'판매처 그룹 설정을 완료하지 못했습니다.')
        if page.locator('#str_shop_code option:checked').inner_text().strip()!='상세선택': raise OrderAutoError('판매처 상세 선택이 적용되지 않았습니다.')
        page.locator('#search').click();self.grid_ready(page)
        # Fresh queries have no previous rows. Zero results must not clear the app.
        if not page.locator('#grid1 tr.jqgrow').count(): raise OrderAutoError('조회 결과가 0건입니다. 기존 주문은 유지됩니다. 0건 반영은 수동 불러오기에서 확인하세요.')
        page.locator('#download_type').select_option(label='상품단위')
        page.locator('#download_field').select_option(label='배송지연 전체품목')
        page.locator('#include_sum').set_checked(True)
        self.page=page;self.step='주문 엑셀 신청'
        self.c.update('request','배송지연 전체품목 엑셀을 신청합니다.')
        page.bring_to_front()
        import browser_window;browser_window.reminimize(page)
        expected=[('#date_period_sel','최근한달'),('select[name="date_type"]','발주일'),('select[name="status_sel"]','접수+송장'),('select[name="order_cs_sel"]','정상+교환'),('#download_type','상품단위'),('#download_field','배송지연 전체품목')]
        if any(page.locator(selector+' option:checked').inner_text().strip()!=label for selector,label in expected):
            raise OrderAutoError('조회 조건이 변경되어 중단했습니다. 자동 불러오기를 다시 시작하세요.')
        self.export_requested=True  # Uncertain click outcomes must never be replayed.
        # Use the complete submission interval, including request notices.
        started=datetime.now(KST)
        page.locator('#download').click()
        try:_,accepted=self.export_dialogs(page)
        except StepTimeout:
            if self.step!='다운로드 신청 버튼 확인':raise
            # 2026-10-21: 안내창 대신 캡차가 뜬 경우 — 사람이 캡차·다운로드 신청을 하고 '다운로드 완료'를 누른다.
            raise CaptchaNeeded('다운로드 신청에 캡차 인증이 필요합니다.',page,started) from None
        self.c.update('waiting','다운로드 접수 완료 · 5초 후 새 파일의 완료 여부를 확인합니다.')
        self.pause(5)
        self.c.check()
        return self.fetch_requested(started,accepted,cfg)

    def fetch_requested(self,started,accepted,cfg):
        """BL30 다운로드관리자: the one 확장주문검색 job requested between started and accepted."""
        manager=self.context.new_page()
        self.protected_page(manager,self.admin_url(DOWNLOAD_PATH),'#search')
        # Use the same server's HTTP clock, not the Mac's wall clock, to
        # identify the request. No pre-acknowledgement BL30 visit is needed.
        self.step='다운로드 서버 시각 대조'
        if self.manager_clock is None:
            raise OrderAutoError('다운로드관리자의 서버 시각 응답을 확인하지 못했습니다. 열린 Chrome에서 완료 파일을 확인하세요.')
        started,accepted=server_request_window(started,accepted,*self.manager_clock)
        # Include both dates if the request crossed midnight; never rely on
        # the manager's remembered/default date filter.
        changed=False
        for selector,value in [('#start_date',started.strftime('%Y-%m-%d')),('#end_date',accepted.strftime('%Y-%m-%d')),('#start_hour','00:00:00'),('#end_hour','23:59:59')]:
            field=manager.locator(selector)
            if field.count()!=1:raise OrderAutoError('다운로드 요청일자 입력칸을 확인하지 못했습니다.')
            if field.input_value()!=value:field.fill(value);changed=True
        if changed:manager.locator('#search').click(timeout=10000)
        self.c.update('waiting',f'서버 기준 신청시간 {started:%H:%M:%S}~{accepted:%H:%M:%S} 대조 · 이번 완료 파일을 확인합니다.')
        job=self.wait_download_job(manager,started,accepted)
        return self.download_job(manager,job,started,cfg['folder'])

    def captcha_download(self,page,started,cfg):
        """Wait for the person (captcha + 다운로드 신청) → '다운로드 완료' → fetch that job from BL30."""
        self.page=page;self.step='캡차 인증 대기'
        attempt=int(cfg.get('captchaAttempt',0) or 0)
        msg=('이지어드민 다운로드 신청에 캡차 인증이 나왔습니다. 열린 Chrome 창에서 캡차를 입력하고 다운로드 신청'
             '(안내 확인 · 확인했습니다 입력 · 접수)까지 직접 해 주세요. 끝나면 누아브 앱의 "다운로드 완료" 버튼을 누르세요.'
             f' {CAPTCHA_ANSWER_SECONDS//60}분 안에 응답이 없으면 창을 닫고 {CAPTCHA_RETRY_GAP//60}분 간격으로 다시 수집합니다'
             f' (최대 {CAPTCHA_RETRY_TIMES}회'+(f' · 지금 {attempt}회째' if attempt else '')+').')
        alert=getattr(self.c,'alert',None)
        if alert and not attempt:   # 2026-10-29: 재수집 때마다 알림하지 않음 (첫 번째만)
            try:alert('이지어드민 캡차 인증 부탁드립니다',msg,'error')
            except Exception:pass
        self.c.captcha_wait(msg)
        def leave(dialog):pass   # site dialogs stay open for the person; never auto-accepted
        self.context.on('dialog',leave)
        began=time.monotonic()
        try:
            while True:
                command=self.c.take_browser_action()
                if command and command[0]=='downloaded':break
                held=bool(getattr(self.c,'captcha_hold',False))
                if not held and time.monotonic()>began+CAPTCHA_ANSWER_SECONDS:
                    raise CaptchaUnanswered(f'캡차 인증 요청에 {CAPTCHA_ANSWER_SECONDS//60}분 동안 응답이 없었습니다.')
                if time.monotonic()>began+CAPTCHA_WAIT_SECONDS:raise OrderAutoError('30분 안에 다운로드 완료를 받지 못했습니다. 다운로드관리자에서 파일을 확인하고 수동으로 불러오세요.')
                pages=self.live_pages()
                if not pages:raise OrderAutoError('Chrome 창이 닫혀 캡차 인증 뒤 다운로드를 이어가지 못했습니다.')
                try:pages[0].wait_for_timeout(200)
                except Exception:pass
        finally:self.context.remove_listener('dialog',leave)
        self.c.end_browser_recovery()
        accepted=datetime.now(KST)
        self.export_acknowledged=True;self.export_accepted=True   # the person requested the download
        self.step='다운로드관리자 연결'
        self.c.update('waiting','다운로드 완료 확인 · 다운로드관리자에서 이번 확장주문검색을 찾아 받습니다.')
        self.close_extra_pages()
        return self.fetch_requested(started,accepted,cfg)

def run_export(controller,cfg):
    """2026-10-29: 캡차 인증에 1분 동안 응답이 없으면 2분 간격으로 처음부터 다시 수집 (최대 CAPTCHA_RETRY_TIMES 회)."""
    attempt=0
    while True:
        try:return _run_export_once(controller,{**cfg,'captchaAttempt':attempt})
        except CaptchaUnanswered:
            controller.end_browser_recovery()
            if attempt>=CAPTCHA_RETRY_TIMES:
                message=(f'캡차 인증 응답이 없어 {CAPTCHA_RETRY_GAP//60}분 간격으로 {CAPTCHA_RETRY_TIMES}회 다시 수집했지만 매번 캡차가 나와 주문을 가져오지 못했습니다.'
                         ' 기존 주문은 유지됩니다. 자동 불러오기를 직접 실행해 캡차를 입력해 주세요.')
                alert=getattr(controller,'alert',None)
                if alert:
                    try:alert('이지어드민 주문 불러오기 실패',message,'error')
                    except Exception:pass
                raise OrderAutoError(message) from None
            attempt+=1
            end=time.monotonic()+CAPTCHA_RETRY_GAP
            while True:
                left=int(end-time.monotonic())
                if left<=0:break
                controller.update('retry_wait',f'캡차 인증 응답이 없어 Chrome 창을 닫았습니다 · {left//60}분 {left%60:02d}초 뒤 다시 수집합니다 ({attempt}/{CAPTCHA_RETRY_TIMES}) · 기존 주문은 유지됩니다.')
                controller.check()   # [자동 불러오기 중단] → Cancelled
                time.sleep(min(1,max(left,0)))
            controller.update('request',f'다시 수집합니다 ({attempt}/{CAPTCHA_RETRY_TIMES}) · 이지어드민에 로그인합니다.')

def _run_export_once(controller,cfg):
    try:return _run_export(controller,cfg,False)
    except HeadedRelaunch:
        # 캡차는 사람이 봐야 하므로 이번 작업만 창을 보이게 다시 열고 처음부터 (헤드리스 설정은 그대로).
        controller.update('request','다운로드 신청에 캡차 인증이 나와 Chrome 창을 보이게 다시 열고 처음부터 진행합니다.')
        import browser_window
        with browser_window.headed():return _run_export(controller,cfg,True)

def _run_export(controller,cfg,force_headed=False):
    import browser_window as _bw0
    if _bw0.ezadmin_engine()=='main':   # 2026-11-01: 메인 Chrome (기존 로그인 세션 · 비밀번호 입력 안 함)
        import main_chrome;return main_chrome.run(controller,cfg)
    try: from playwright.sync_api import sync_playwright
    except ImportError: raise OrderAutoError('자동 불러오기 구성요소가 없습니다. v0.6.45 배포판 설치기를 다시 실행하세요.')
    account=controller.login_account()
    try:
        with sync_playwright() as p:
            browser=None;context=None
            try:
                try:
                    import browser_window as _bw;launch=_bw.launch_kwargs();launch['headless']=bool(launch.get('headless')) and not force_headed;headless_run=launch['headless'];browser=p.chromium.launch(**launch)
                    context=browser.new_context(viewport={'width':1280,'height':800},
                        device_scale_factor=1,accept_downloads=True)
                except Exception:
                    raise OrderAutoError('Chrome을 열지 못했습니다. Google Chrome 설치 여부를 확인하세요. 샌드박스를 끄고 재시도하지 않습니다.') from None
                flow=Flow(controller,context)
                context.set_default_timeout(15000)
                import browser_window;browser_window.attach(context)
                resume_page=None;retries=0
                while True:
                    try:
                        if resume_page:
                            controller.check()
                            if cfg.get('loginOnly'):return None
                            return flow.export_orders(resume_page,cfg)
                        return flow.execute(cfg,account)
                    except Cancelled:raise
                    except CaptchaNeeded as exc:
                        if headless_run:raise HeadedRelaunch() from None
                        try:return flow.captcha_download(exc.page,exc.started,cfg)
                        except Cancelled:raise
                        except CaptchaUnanswered:raise   # 2026-10-29: 창을 닫고 run_export 가 2분 뒤 다시 수집
                        except CaptchaUnanswered:raise   # 2026-10-29: 창을 닫고 run_export 가 2분 뒤 다시 수집
                        except Exception as exc2:
                            message=flow.failure_message(exc2,account)
                            alert=getattr(controller,'alert',None)
                            if alert:
                                try:alert('이지어드민 주문 불러오기 실패',message,'error')
                                except Exception:pass
                            raise OrderAutoError(message) from None
                    except Exception as exc:
                        message=flow.failure_message(exc,account)
                        if retryable_timeout(exc,flow) and retries<RETRY_TIMES:
                            retries+=1
                            controller.update('search',message.splitlines()[0]+f' · {RETRY_WAIT}초 후 다시 시도합니다 ({retries}/{RETRY_TIMES})')
                            flow.close_extra_pages()
                            try:flow.pause(RETRY_WAIT)
                            except Cancelled:raise
                            except Exception:
                                end=time.monotonic()+RETRY_WAIT
                                while time.monotonic()<end:controller.check();time.sleep(.5)
                            resume_page=flow.authenticated_page()
                            continue
                        if retries:message+=f'\n시간 초과 후 {RETRY_WAIT}초 간격으로 {retries}회 다시 시도했지만 진행되지 않았습니다.'
                        alert=getattr(controller,'alert',None)
                        if alert:
                            try:alert('이지어드민 주문 불러오기 실패',message,'error')
                            except Exception:pass
                        flow.clear_password();account.clear()
                        resume_page=None
                        import browser_window as _bw
                        if headless_run:raise OrderAutoError(message) from None   # no window to inspect: report now
                        try:resume_page=flow.keep_failure_open(message,can_continue=not flow.export_requested)
                        except Cancelled:raise
                        except Exception:pass  # A closed/crashed browser must not hide the original failure.
                        if resume_page:continue
                        raise OrderAutoError(message) from None
            finally:
                # Closing/crashed Chrome must not replace a useful failure or successful receipt.
                for resource in (context,browser):
                    if resource is not None:
                        try:resource.close()
                        except Exception:pass
    finally:account.clear()
