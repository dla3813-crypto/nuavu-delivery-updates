"""Supplier-folder reconciliation and conserved inventory allocations.
Nothing here sends a message, changes a sender, or calls a provider.
"""
from __future__ import annotations
import copy,hashlib,json,re,secrets,threading
from pathlib import Path
from datetime import date,datetime,timezone,timedelta
from collections import defaultdict
from workbook_reader import read_xlsx,text,cell,as_date,integer,WorkbookError,MAX_FILE
from supply_calendar import route
from supply_watch import SupplyWatcher,serialized_supply,scan_signature
from color_labels import color_label

class SupplyError(ValueError):pass

def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def norm(v):return re.sub(r'[^0-9a-z가-힣\u4e00-\u9fff]','',text(v).lower())
def match_color_name(v):
    """Compare color labels without Chinese text, numbers or whitespace.

    Color-only: retain the existing product/size rules and persisted IDs.
    An empty result is unknown, never a match to another unknown color.
    """
    return re.sub(r'[^a-z가-힣]','',text(v).lower())

def supply_wave_key(r):
    """Recognize the same stock in progress/manifest despite color annotations.

    This transient key is not a replacement for the stored variant identifier.
    Unknown colors keep their original identity instead of all collapsing.
    """
    color=match_color_name(r['color'])
    if not color:return r['variant']
    return digest([r['brand'],product_name(r['product']),color,size_name(r['size'])])

def product_name(v):
    s=text(v)
    # Strip only leading management/merchandising annotations; never the core name.
    s=re.sub(r'^(?:\s*\([A-Za-z]+-\d+\)\s*|\s*\[[^\]]+\]\s*)+','',s)
    return norm(s)
def size_name(v):
    s=text(v).upper();s=re.sub(r'\([^)]*\)','',s).strip()
    return 'free' if s in ('F','FREE','프리','프리사이즈','ONE SIZE','ONESIZE') else norm(s)
def legacy_option_parts(v):
    s=text(v)
    s=re.sub(r'(색상|컬러|사이즈|color|size)\s*[:=]\s*','',s,flags=re.I)
    parts=re.split(r'\s*[/,|]\s*',s)
    if len(parts)<2:
        parts=re.split(r'\s*-\s*(?=(?:FREE|F|[0-9]*X*[SML]|[0-9]+(?:\([^)]*\))?)$)',s,flags=re.I)
    if len(parts)>=2:return norm(parts[0]),size_name(parts[-1])
    return norm(s),''
def option_parts(v):
    """Comparison-only parsing. An omitted order size uses the existing FREE rule.

    Keep legacy_option_parts/order_signature/variant_id unchanged: saved mappings,
    order identities and sealed allocation proofs must survive this update.
    Unknown explicit sizes are NOT converted to FREE. A missing color is never
    made into an arbitrary color wildcard.
    """
    s=text(v)
    if s.startswith('[') and s.endswith(']') and s.count('[')==1:s=s[1:-1].strip()
    s=re.sub(r'(색상|컬러|사이즈|color|size)\s*[:=]\s*','',s,flags=re.I)
    s=re.sub(r'\(\s*모델\s*(?:착용)?\s*\)','',s)
    known_size=r'(?:FREE|F|프리(?:사이즈)?|ONE\s*SIZE|[0-9]*X*[SML]|[0-9]+)'
    parts=re.split(r'\s*[/,|]\s*',s)
    if len(parts)<2:
        parts=re.split(r'\s*[-–—]\s*(?='+known_size+r'\s*(?:\([^)]*\))?\s*\]?$)',s,flags=re.I)
    if len(parts)<2:
        single=s.strip().strip('[]').strip()
        # A bare size is not a color-only order; it still needs a color match.
        if re.fullmatch(known_size+r'\s*(?:\([^)]*\))?',single,flags=re.I):
            return '',size_name(single)
        # A trailing empty size field (블랙-) also means size omitted.
        if re.search(r'[-–—]\s*$',single):
            color=re.sub(r'[-–—]\s*$','',single).strip().strip('[]').strip()
            return norm(color),'free'
        # Preserve an unrecognized explicit hyphen suffix instead of silently
        # accepting malformed options such as 화이트-한장만 구매 as FREE.
        if re.search(r'[-–—]',single):return norm(single),''
        return norm(single),'free'
    color=parts[0].strip().strip('[]').strip()
    size=parts[-1].strip().strip('[]').strip()
    return norm(color),size_name(size) if size else 'free'

def order_signature(row):
    # These hashes key existing manual mappings and sealed inventory proofs.
    # Do not rewrite them merely because the comparison parser is corrected.
    return digest([product_name(row.get('product')), *legacy_option_parts(row.get('option'))])
def variant_id(r):return digest([r['brand'],product_name(r['product']),norm(r['color']),size_name(r['size'])])
def source_label(r):return f"{r['brand']} · {r['product']} / {r['color']} / {r['size']}"

def init_supply(s):
    if not isinstance(s.get('supply'),dict):s['supply']={}
    v=s['supply']
    for k,x in {'version':1,'folder':'','year':2026,'brands':['N','NS'],'discovered':[],
                'manifests':{},'progress':[],'mappings':{},'sealed':{},'retiredFingerprints':[],
                'holidays':[],'confirmedCalendarYears':[2026],'warnings':[], 'lastReadAt':'','lastResetAt':'','autoEnabled':False,'watchSignature':'','lastReadMode':'manual','progressCutoff':'','shipDelays':{},'shipDelayAlerted':[],'dispatchOverrides':{}}.items():
        v.setdefault(k,copy.deepcopy(x))
    return v

def manifest_day(name,year):
    s=text(name)
    m=re.search(r'(?:(20\d{2})\s*[년._ -]\s*)?(\d{1,2})\s*월\s*(\d{1,2})\s*일',s)
    if not m:raise SupplyError('출고장 파일명에 X월 X일이 없습니다: '+s)
    try:return date(int(m[1] or year),int(m[2]),int(m[3]))
    except ValueError as e:raise SupplyError('출고장 날짜가 올바르지 않습니다: '+s) from e

# Progress-file dates select a snapshot only. They NEVER substitute for V dates.
def manifest_ids_in_folder(folder,year):
    """IDs ('manifest:YYYY-MM-DD') of the 완료 출고장 files present right now, or None when the folder is unreadable."""
    try:
        root=Path(folder) if folder else None
        if root is None or not root.is_dir():return None
        ids=set()
        for p in root.iterdir():
            if p.is_file() and not p.is_symlink() and not p.name.startswith(('~$','.')) and p.suffix.lower()=='.xlsx' and not skip_supply_file(p.name) and '출고장' in text(p.name) and '완료' in text(p.name):
                try:ids.add('manifest:'+manifest_day(p.name,year).isoformat())
                except SupplyError:continue
        return ids
    except OSError:return None

# 2026-10-20 23:56 요청: 파일명에 "(NS 이미지)" 또는 "색칠"이 든 출고장은 작업용 사본이다 — 수집하지도, 감시(변경 감지)하지도 않는다.
SKIP_SUPPLY_MARKS=('(NS 이미지)','색칠')
def skip_supply_file(name):
    n=text(name).replace('（','(').replace('）',')')
    return any(m in n for m in SKIP_SUPPLY_MARKS) or 'NS 이미지' in n

def is_progress_file(name):
    name=text(name)
    return name.lower().endswith('.xlsx') and bool(re.match(r'^진행\s*상황(?=$|[\s._(\-]|\d)',name[:-5]))

def progress_filename_day(name,year):
    """Read YYYYMMDD / YYYY-MM-DD / MMDD / M월 D일, without today's-date filtering.

    Yearless names use the same explicit base year as the supplier workspace.
    The user can avoid year-boundary ambiguity with YYYYMMDD filenames.
    """
    body=re.sub(r'^진행\s*상황','',text(name)[:-5]).strip()
    # Finder/browser duplicate numbers are not dates. A four-digit (1017) is.
    body=re.sub(r'\s*\(\d{1,3}\)\s*$','',body).strip()
    match=re.search(r'(?<!\d)(20\d{2})(\d{2})(\d{2})(?!\d)',body)
    if not match:
        match=re.search(r'(?<!\d)(20\d{2})\s*(?:[-._/]|년|\s)\s*(\d{1,2})\s*(?:[-._/]|월|\s)\s*(\d{1,2})(?!\d)',body)
    if match:parts=tuple(map(int,match.groups()))
    else:
        match=re.search(r'(?<!\d)(\d{1,2})\s*월\s*(\d{1,2})\s*일',body)
        if not match:match=re.search(r'(?<!\d)(\d{1,2})\s*[-._/]\s*(\d{1,2})(?!\d)',body)
        if not match:match=re.search(r'(?<!\d)(\d{2})(\d{2})(?!\d)',body)
        if not match:
            if re.search(r'\d',body):
                raise SupplyError('진행상황 파일명 날짜를 읽을 수 없습니다: '+text(name)+' · MMDD 또는 YYYYMMDD로 표기하세요. 이전 자료를 유지했습니다.')
            return None
        parts=(year,*map(int,match.groups()))
    try:return date(*parts)
    except ValueError as e:
        raise SupplyError('진행상황 파일명 날짜가 올바르지 않습니다: '+text(name)+' · 이전 자료를 유지했습니다.') from e

def latest_progress_files(paths,year):
    """Return top-ranked candidates and audit metadata; do not open old snapshots.

    Named dates take precedence over undated files. For the newest date choose
    the most recently modified file. Undated files are used only when no dated
    file exists. Exactly tied, different contents are checked by the caller.
    """
    if not paths:return [],None
    candidates=[]
    for path in paths:
        stat=path.stat();day=progress_filename_day(path.name,year)
        candidates.append({'path':path,'stat':stat,'day':day})
    dated=[c for c in candidates if c['day'] is not None]
    pool=dated or candidates
    def rank(c):return ((c['day'] or date.min).isoformat(),c['stat'].st_mtime_ns)
    top=max(map(rank,pool))
    chosen=sorted([c for c in pool if rank(c)==top],key=lambda c:text(c['path'].name))
    if len(chosen)>100:raise SupplyError('최신 날짜·수정시각이 같은 진행상황 파일이 너무 많습니다. 최종 파일을 확인하세요. 이전 자료를 유지했습니다.')
    first=chosen[0];modified=datetime.fromtimestamp(first['stat'].st_mtime,timezone(timedelta(hours=9)))
    info={'name':text(first['path'].name),'date':first['day'].isoformat() if first['day'] else '',
          'dateSource':'filename' if dated else 'modified','modifiedAt':modified.isoformat(timespec='seconds'),
          'candidateCount':len(candidates),'ignoredCount':len(candidates)-1,'tiedCount':len(chosen)}
    return chosen,info


def read_supplier(name,raw,year,kind):
    sheets=read_xlsx(raw);ship=manifest_day(name,year) if kind=='manifest' else None
    if ship and ship.weekday() not in (1,4,5):raise SupplyError('출고장 날짜가 화/금/토가 아닙니다. 기준연도·파일명을 확인하세요: '+name)
    rows=[];warnings=[];brands=set()
    for sheet in sheets:
        for number,values in enumerate(sheet['rows'],1):
            brand=text(cell(values,4)).upper();product=text(cell(values,5))
            if not re.fullmatch(r'[A-Z][A-Z0-9_-]{0,11}',brand) or not product:continue
            brands.add(brand)
            qty=integer(cell(values,9))
            if qty is None:
                warnings.append(f'{name} / {sheet["name"]} {number}행: J열 수량을 읽지 못해 배정 제외');continue
            if not qty and kind=='manifest':continue # zero progress qty still records V arrival evidence
            arrival=as_date(cell(values,21),year,sheet['epoch1904'])
            order=as_date(cell(values,11),year,sheet['epoch1904']) if kind=='progress' else None
            raw_arrival=text(cell(values,21))
            # Manifest V is display evidence only. Preserve its existing ship-date
            # calculation and stock fingerprint (historically empty basisDate).
            basis=arrival if kind=='progress' else None
            r={'brand':brand,'product':product,'color':text(cell(values,6)),'size':text(cell(values,7)),
                'qty':qty,'sheet':sheet['name'],'line':number,'sourceFile':text(name),'kind':kind,
                'shipDate':ship.isoformat() if ship else '', 'basisDate':basis.isoformat() if basis else '',
                'officeDate':arrival.isoformat() if arrival else '', 'purchaseDate':order.isoformat() if order else '',
                'officeRaw':raw_arrival,
                'basisType':'manifest' if ship else 'office' if arrival else 'unknown'}
            r['variant']=variant_id(r)
            if kind=='progress' and not basis:warnings.append(f'{name} {number}행: V열 중국 사무실 도착일 없음/해석 불가 · 출고 예상일 공란 (L열 미사용)')
            rows.append(r)
    if not brands:raise SupplyError('E/F/J열의 브랜드·상품·수량 구조를 찾지 못했습니다: '+name)
    # Identity deliberately ignores ZIP metadata, row position and formatting.
    payload=sorted([[r['brand'],r['product'],r['color'],r['size'],r['qty'],r['basisDate']] for r in rows])
    stable=digest([kind,ship.isoformat() if ship else '',payload])
    # Two copies with different V dates must not arbitrarily choose evidence.
    # Keep this separate from stock identity and retired fingerprints.
    evidence=digest([stable,sorted([[r['brand'],r['product'],r['color'],r['size'],r['qty'],r['officeDate']] for r in rows])])
    # One dispatch date represents one combined daily manifest, matching these source files.
    ident=('manifest:'+ship.isoformat()) if ship else ('progress:'+text(name))
    return {'id':ident,'name':text(name),'date':ship.isoformat() if ship else '',
            'rows':rows,'fingerprint':stable,'evidenceFingerprint':evidence,
            'brands':sorted(brands),'warnings':warnings,'closed':False}

def catalogue(v,selected=True):
    variants={}
    sources=[r for b in v['manifests'].values() if not b.get('closed') for r in b['rows']]+effective_progress(v)
    for r in sources:
        if selected and r['brand'] not in v['brands']:continue
        item=variants.setdefault(r['variant'],{k:r[k] for k in ('variant','brand','product','color','size')}|{'origins':[],'officeDates':[]})
        label=color_label(r['color'])
        item.update(colorLabel=label['label'],colorHasChinese=label['hasChinese'],
                    colorTranslated=label['translated'],colorTranslationNeedsReview=label['needsReview'])
        if r['kind'] not in item['origins']:item['origins'].append(r['kind'])
        if r['kind']=='progress':
            d=progress_day(r,v['year'])
            if d and d.isoformat() not in item['officeDates']:item['officeDates'].append(d.isoformat())
    return sorted(variants.values(),key=lambda r:(r['brand'],product_name(r['product']),r['color'],r['size']))

# v0.6.139/v0.6.139 자동매칭 (comparison only): leading merchandising tags are not part of the product identity.
# "F7 [❤️‍🔥지금부터쭉/신상초특가] 4color 더블 카라 브이 반팔 니트" = "F7 더블 카라 브이 반팔 니트" = "더블 카라 브이 반팔 니트".
# Stripped while they lead the name: (A-6)/[…]/{…} groups, short codes like F7·D5·B-14·F14-1·NA-6, "4color"/"3size"/"2컬러",
# and any leading symbols/emoji. The core name that follows is compared as before.
LEADING_PRODUCT_TAGS=re.compile(r'^(?:\s*(?:\([^)]*\)|\[[^\]]*\]|\{[^}]*\}|[A-Za-z]{1,3}-?\d{1,3}(?:-\d{1,3})?(?=[\s\[(\]가-힣]|$)|\d{1,2}\s*(?:colors?|sizes?|컬러|색상|사이즈)(?=[\s\[(]|$)|[^\w가-힣\u4e00-\u9fff(\[{]+))+',re.I)
LEADING_PRODUCT_CODES=re.compile(r'^(?:\s*(?:[A-Za-z]{1,3}-?\d{1,3}(?:-\d{1,3})?(?=[\s\[(\]가-힣]|$)|\d{1,2}\s*(?:colors?|sizes?|컬러|색상|사이즈)(?=[\s\[(]|$)|[^\w가-힣\u4e00-\u9fff]+))+',re.I)
def match_product_name(value):
    """Comparison-only normalization; persisted SKU hashes must not change."""
    s=text(value)
    s=re.sub(r'^\s*\(\d+\s*colors?[^)]*\)\s*','',s,flags=re.I)
    s=LEADING_PRODUCT_TAGS.sub('',s)
    return product_name(s)
def product_forms(value):
    """Every comparison form of a product name. Two names are the same product when their forms overlap.
    · tags form: leading codes AND bracket groups removed ("S6 [긴팔] 가디건" → 가디건)
    · words form: leading codes removed but bracket text kept as words ("S6 [긴팔] 가디건" → 긴팔가디건 = "S6 긴팔 가디건")"""
    s=text(value)
    out={match_product_name(s)}
    words=re.sub(r'[\[\]{}()]',' ',s)
    for _ in range(3):words=LEADING_PRODUCT_CODES.sub('',words)
    words=norm(words)
    if words:out.add(words)
    return {f for f in out if f}
def same_product(a,b):
    return bool(product_forms(a)&product_forms(b))
# 2026-10-26 15:04 요청: 진행상황 NS 행 '베이직'(灰色/黑色)이 '긱시크 베이직 레이스 슬림핏 반팔 셔츠 블라우스'에 자동 매칭됨.
# 포함 매칭은 '더 짧은 공급 자료 이름이 주문 상품명 안에 있을 때'의 보조 규칙인데, 이름이 '베이직'·'후드'처럼 한 단어 일반명사면
# 거의 모든 주문에 들어가므로 보조 규칙에서 뺀다 (정확히 같은 이름이면 same_product 로 여전히 매칭).
GENERIC_PRODUCT_WORDS={'베이직','기본','데일리','신상','후드','후디','코트','니트','셔츠','티셔츠','티','팬츠','바지','스커트','치마','가디건','원피스',
    '자켓','재킷','블라우스','점퍼','패딩','조끼','베스트','맨투맨','슬랙스','청바지','데님','레깅스','반팔','긴팔','나시','민소매','스카프','양말',
    '모자','가방','백팩','세트','투피스','탑','원컬러','상의','하의','아우터','이너','롱','숏','오버핏','슬림핏','루즈핏','크롭'}
def specific_product_form(form):
    """포함 매칭에 쓸 수 있는 이름인가: 4글자 이상이고 일반명사 한 단어가 아니어야 한다."""
    return bool(form) and len(form)>=4 and form not in GENERIC_PRODUCT_WORDS
def product_within(order_name,variant_name):
    """Fallback: a (shorter, specific) source name contained in the order name, in any form."""
    vf={v for v in product_forms(variant_name) if specific_product_form(v)};of=product_forms(order_name)
    return any(v in o for v in vf for o in of)
def shared_product(names):
    """True when every name shares at least one comparison form (used for the ambiguity check)."""
    forms=[product_forms(n) for n in names]
    return bool(forms) and bool(set.intersection(*forms))

def progress_day(row,year):
    # Never trust an older cached basisDate (v0.6.9 allowed L+3).
    # Manual matching changes identity only, never arrival/date evidence.
    return as_date(row.get('officeDate',''),year)

# Suggestions only: these colors are NOT interchangeable for allocation.
SIMILAR_COLOR_GROUPS=(
    frozenset(('화이트','아이보리','흰색','백색','white','ivory')),
    frozenset(('카키','그린','녹색','초록','초록색','khaki','green')),
    frozenset(('블랙','검정','검정색','검은색','black')),
    frozenset(('그레이','회색','gray','grey')),
    frozenset(('네이비','남색','navy')),
    frozenset(('블루','파랑','파란색','청색','blue')),
    frozenset(('핑크','분홍','분홍색','pink')),
)

def named_variants(row,variants):
    pn=product_forms(row['product'])
    # Resolve product identity BEFORE color/date/stock, including suggestions.
    exact=[v for v in variants if pn and same_product(row['product'],v['product'])]
    return exact or [v for v in variants if pn and product_within(row['product'],v['product'])]

def manual_color_recommendations(row,variants):
    """Read-only alternatives including translated Chinese colors; never allocate."""
    raw_order_color,os=option_parts(row.get('option',''));order_label=color_label(raw_order_color)
    oc=match_color_name(order_label['label'] if order_label['translated'] else raw_order_color)
    if not oc or not os:return []
    group=next((g for g in SIMILAR_COLOR_GROUPS if oc in g),frozenset())
    result=[]
    for v in named_variants(row,variants):
        source_label=color_label(v['color'])
        color=match_color_name(source_label['label'] if source_label['translated'] else v['color'])
        translated=order_label['translated'] or source_label['translated']
        if not color:continue
        if not ((color==oc and translated) or (color!=oc and color in group)):continue
        if os!='free' and size_name(v['size'])!=os:continue
        order_display=order_label['label'];source_display=source_label['label']
        if order_label['hasChinese']:order_display+=f" (원문: {raw_order_color})"
        if source_label['hasChinese']:source_display+=f" (원문: {v['color']})"
        reason=f"주문 {order_display} ↔ 공급 {source_display} · "+('중국어 컬러 번역 확인' if translated else '유사 컬러 확인')
        result.append({'variant':v['variant'],'orderColor':oc,'sourceColor':v['color'],
                       'orderColorLabel':order_label['label'],'sourceColorLabel':source_label['label'],
                       'translated':translated,'reason':reason})
    return result


def progress_cutoff(v):
    # Keep the last successfully observed dispatch date even after files vanish.
    dates=[v.get('progressCutoff','')]+[b.get('date','') for b in v['manifests'].values()]
    return max((d for d in dates if isinstance(d,str) and re.fullmatch(r'\d{4}-\d{2}-\d{2}',d) and as_date(d,v['year'])),default='')

def remember_progress_cutoff(v,batches=()):
    days=[progress_cutoff(v)]+[b.get('date','') for b in batches if b.get('date')]
    v['progressCutoff']=max(days)

def excluded_progress(row,v,cutoff=None):
    day=progress_day(row,v['year']);cutoff=progress_cutoff(v) if cutoff is None else cutoff
    return bool(day and cutoff and day.isoformat()<=cutoff)

def effective_progress(v):
    cutoff=progress_cutoff(v)
    return [r for r in v['progress'] if not excluded_progress(r,v,cutoff)]

def candidates(row,variants,mappings):
    rule=mappings.get(order_signature(row))
    if rule is not None:
        wanted=set(rule);return [v for v in variants if v['variant'] in wanted],False,'manual'
    oc,os=option_parts(row.get('option',''))
    oc=match_color_name(oc)
    # Resolve product identity BEFORE testing date availability or stock. An exact
    # product with blank V must not fall through to a dated generic '후드'.
    named=named_variants(row,variants)
    hits=[]
    for v in named:
        if oc!='원컬러' and (not oc or match_color_name(v['color'])!=oc):continue
        if os!='free' and (not os or size_name(v['size'])!=os):continue
        hits.append(v)
    # N/NS (or other deliberately selected codes) can supply the same exact SKU.
    # Distinct core product names remain ambiguous and require an explicit rule.
    ambiguous=bool(hits) and not shared_product([v['product'] for v in hits])
    return ([] if ambiguous else hits),ambiguous,'automatic'

def source_evidence(v,variant_ids):
    """Read-only source cell facts, also for matched rows with no date/stock."""
    result=[]
    sources=[r for b in v['manifests'].values() if not b.get('closed') for r in b['rows']]+effective_progress(v)
    for r in sources:
        if r['variant'] not in variant_ids or r['brand'] not in v['brands']:continue
        result.append({k:r.get(k,'') for k in ('variant','kind','sourceFile','sheet','line','brand','product','color','size','qty','officeDate','officeRaw','purchaseDate','shipDate')})
    return result

def progress_facts(info, year):
    """V-date presence is an SKU source fact, not an allocation success flag.
    No cross-option/product rescue, no L+3, no notice-date inference.
    """
    sources=[x for x in info.get('sources',[]) if x.get('kind')=='progress']
    dates=sorted({d.isoformat() for x in sources if (d:=progress_day(x,year)) is not None})
    manifests=[x for x in info.get('sources',[]) if x.get('kind')=='manifest']
    manifest_dates=sorted({d.isoformat() for x in manifests if (d:=as_date(x.get('officeDate',''),year)) is not None})
    return {'hasProgressSource':bool(sources), 'progressHasOfficeDate':bool(dates),
            'progressOfficeDates':dates,
            'hasManifestSource':bool(manifests), 'manifestHasOfficeDate':bool(manifest_dates),
            'manifestOfficeDates':manifest_dates, 'officeDates':sorted(set(dates+manifest_dates)),
            'progressStage':('PLANNED' if dates else 'MANIFEST_SECURED' if info.get('fullManifest')
                             else 'UNCONFIRMED' if info.get('matched') else 'UNMATCHED')}

def order_priority(r):
    # Never use UI sort order or names/phone numbers as identity/priority.
    numeric=re.sub(r'\D','',r.get('orderId',''))
    d=as_date(r.get('orderDate'),2026)
    raw=text(r.get('orderTimestamp'));clock=re.search(r'[ T](\d{1,2}):(\d{2})(?::(\d{2}))?',raw)
    t=tuple(map(int,clock.groups(default='0'))) if clock else (0,0,0)
    if t[0]>23 or t[1]>59 or t[2]>59:t=(0,0,0)
    return ((d or date.max).isoformat(),t,int(numeric or 0),r.get('seller',''),r['key'])

def reallocation_info(v):
    stamp=v.get('lastResetAt','');snapshot=v.get('lastResetRestore',{})
    ids=set(snapshot.get('batches',{})) if snapshot.get('at')==stamp else None
    targets=[b for b in v['manifests'].values() if stamp and b.get('closed') and b.get('closedAt')==stamp
             and (ids is None or b['id'] in ids)]
    cached=snapshot.get('at')==stamp and set(snapshot.get('batches',{}))=={b['id'] for b in targets}
    token=(snapshot.get('token') if cached else digest([stamp,v['folder'],v['year'],sorted((b['id'],b['fingerprint']) for b in targets)])) if targets else ''
    return {'available':bool(targets),'at':stamp,'token':token,'requiresOriginal':bool(targets) and not cached,
            'names':[b['name'] for b in targets], 'batchIds':[b['id'] for b in targets],
            'qty':sum(r['qty'] for b in snapshot.get('batches',{}).values() for r in b['rows'] if r['brand'] in v['brands']) if cached else None}

def ship_delay_question(v,now_kst=None):
    """From Wednesday 18:00 KST until the next Tuesday: this week's Tuesday has no 출고장 and no answer yet → ask."""
    if not v.get('folder'):return None
    if now_kst is None:
        import domain
        from datetime import timezone
        now_kst=domain.datetime.now(timezone(timedelta(hours=9)))
    wd=now_kst.weekday()
    if wd==1 or (wd==2 and now_kst.hour<18):return None
    tue=now_kst.date()-timedelta(days=(wd-1)%7)
    key=tue.isoformat()
    if key in (v.get('shipDelays') or {}):return None
    if any(b.get('date')==key for b in (v.get('manifests') or {}).values()):return None
    return {'tuesday':key,'friday':(tue+timedelta(days=3)).isoformat(),'saturday':(tue+timedelta(days=4)).isoformat()}

def apply_dispatch_override(path,overrides):
    """2026-10-24 요청: 사장님이 정한 실 출고 예상일 (중국 출고일 = 그 출고분 전체 단위).
    앱 내부 예상일만 바뀐다. 고객에게 안내한 출고 예정일·발송 이력은 바꾸지 않는다."""
    if not path or not path.get('chinaDate'):return path
    o=(overrides or {}).get(path['chinaDate'])
    if not isinstance(o,dict) or not o.get('start') or not o.get('end'):return path
    try:lo,hi=date.fromisoformat(o['start']),date.fromisoformat(o['end'])
    except (TypeError,ValueError):return path
    out=dict(path);out['overriddenFrom']={'koreaStart':path.get('koreaStart',''),'koreaEnd':path.get('koreaEnd','')}
    out.update(koreaStart=lo.isoformat(),koreaEnd=hi.isoformat(),koreaLatest=hi.isoformat(),
               receiptStart=(lo+timedelta(days=1)).isoformat(),receiptEnd=(hi+timedelta(days=1)).isoformat(),receiptLatest=(hi+timedelta(days=1)).isoformat(),
               dispatchOverride=True,calendarKnown=bool(path.get('calendarKnown',True)) and lo.year==2026 and hi.year==2026)
    return out

def dispatch_waves(s,projection,overrides=None):
    """중국 출고분(출고장·진행상황)별 지금 실 출고 예상일과 해당 주문상품 수. 출고 예상일 변경 창·Codex 제안 확인용."""
    overrides=overrides if overrides is not None else (init_supply(s).get('dispatchOverrides') or {});waves={}
    rows={r['key']:r for r in s['rows'] if r.get('active')}
    for key,a in projection.items():
        if key not in rows:continue
        seen=set()
        for part in a.get('parts',[]):
            path=part.get('path') or {}
            c=path.get('chinaDate')
            if part.get('kind')=='inventory' or not c:continue
            w=waves.setdefault(c,{'chinaDate':c,'koreaStart':path.get('koreaStart',''),'koreaEnd':path.get('koreaEnd',''),'items':0,'qty':0,'kinds':set(),
                                  'override':copy.deepcopy(overrides.get(c)),'original':copy.deepcopy(path.get('overriddenFrom') or {'koreaStart':path.get('koreaStart',''),'koreaEnd':path.get('koreaEnd','')})})
            w['koreaStart']=min(w['koreaStart'] or path.get('koreaStart',''),path.get('koreaStart',''));w['koreaEnd']=max(w['koreaEnd'],path.get('koreaEnd',''))
            w['qty']+=int(part.get('allocated') or 0);w['kinds'].add('출고장' if part.get('kind')=='manifest' else '진행상황')
            if c not in seen:w['items']+=1;seen.add(c)
    for c,o in overrides.items():   # 지금 배정된 상품이 없어도 지정해 둔 값은 보여 준다 (해제할 수 있게)
        waves.setdefault(c,{'chinaDate':c,'koreaStart':o.get('start',''),'koreaEnd':o.get('end',''),'items':0,'qty':0,'kinds':set(),'override':copy.deepcopy(o),'original':{}})
    out=[]
    for w in sorted(waves.values(),key=lambda w:w['chinaDate'],reverse=True):
        w['kinds']=sorted(w['kinds']);out.append(w)
    return out

def allocation_view(s):
    from domain import applied_notice,is_soldout,notice_sort_key
    v=init_supply(s);variants=catalogue(v);extra=set(v['holidays']);known=set(v['confirmedCalendarYears'])
    notices={}
    for n in sorted(s['notices'],key=notice_sort_key):
        if applied_notice(n):
            for key in n.get('itemKeys',[]):notices[key]=n
    # 2026-10-22 22:55 요청: 출고장·진행상황 수량이 모자랄 때는 교환(C 주문번호) 송장을 먼저 배정한다.
    active=sorted([r for r in s['rows'] if r.get('active') and not is_soldout(notices.get(r['key'],{}))],key=lambda r:(0 if text(r.get('orderId','')).strip().upper().startswith('C') else 1,order_priority(r)))
    lots=[];latest_manifest={}
    for b in v['manifests'].values():
        for r in b['rows']:
            wave=supply_wave_key(r)
            latest_manifest[wave]=max(latest_manifest.get(wave,''),b['date'])
            if b.get('closed') or r['brand'] not in v['brands']:continue
            d=date.fromisoformat(b['date']);path=apply_dispatch_override(route(d,extra,departure=d),v.get('dispatchOverrides'))
            if path:
                lots.append({**r,'path':path,'remaining':r['qty'],'batchId':b['id']})
    for r in effective_progress(v):
        office=progress_day(r,v['year'])
        if r['brand'] not in v['brands'] or office is None:continue
        path=apply_dispatch_override(route(office,extra,delays=v.get('shipDelays') or {}),v.get('dispatchOverrides'))
        if not path:continue
        # A progress record assigned to a wave already represented by a manifest
        # is NOT extra stock. No reliable supplier item ID exists in these files.
        if latest_manifest.get(supply_wave_key(r),'')>=path['chinaDate']:continue
        lots.append({**r,'basisType':'office','basisDate':office.isoformat(),'path':path,'remaining':r['qty'],'batchId':''})
    lots.sort(key=lambda r:(0 if r['kind']=='manifest' else 1,r['path']['koreaEnd'],r['sourceFile'],r['line']))
    by_variant=defaultdict(list)
    for lot in lots:by_variant[lot['variant']].append(lot)
    output={};totals={'full':0,'partial':0,'unmatched':0,'ambiguous':0,'withoutDate':0,'automatic':0,'manual':0,'recommended':0,'awaitingOffice':0,'shortage':0}
    for row in active:
        key=row['key'];qty=row['qty'];hits,ambiguous,method=candidates(row,variants,v['mappings'])
        a={'parts':[],'matched':bool(hits),'matchMethod':method,'ambiguous':ambiguous,
           'qty':qty,'manifestQty':0,'plannedQty':0,'receiptStart':'','receiptEnd':'','koreaStart':'','koreaEnd':'',
           'dispatchStart':'','dispatchEnd':'',
           'fullManifest':False,'matchNeeded':not hits or ambiguous,'calendarKnown':True,
           'manualRecommended':False,'manualRecommendations':[],
           'manualVariants':copy.deepcopy(v['mappings'].get(order_signature(row),[])),
           'parsedColor':option_parts(row.get('option'))[0],'parsedSize':option_parts(row.get('option'))[1]}
        a['excluded']=method=='manual' and v['mappings'].get(order_signature(row))==[]   # 2026-10-26: 사장님이 매칭 취소(연결 안 함)
        a['sources']=source_evidence(v,{h['variant'] for h in hits})
        if row.get('review'):
            a['reason']='주문정보 변경 확인 필요';a['reasonCode']='ORDER_REVIEW';totals['withoutDate']+=1;output[key]=a;continue
        sealed=v['sealed'].get(key)
        if sealed and sealed.get('signature')==order_signature(row) and sealed.get('originalQty')==qty:
            for part in copy.deepcopy(sealed['parts']):
                if part['brand'] in v['brands']:
                    part['sealed']=True
                    oldpath=part['path'];updated_path=apply_dispatch_override(route(date.fromisoformat(oldpath['basisDate']),extra,departure=date.fromisoformat(oldpath['chinaDate'])),v.get('dispatchOverrides'))
                    if updated_path:part['path']=updated_path
                    a['parts'].append(part);a['manifestQty']+=part['allocated']
        remaining=max(0,qty-a['manifestQty']);pool=[]
        for h in hits:pool.extend(by_variant[h['variant']])
        pool.sort(key=lambda r:(0 if r['kind']=='manifest' else 1,r['path']['koreaEnd'],r['sourceFile'],r['line']))
        for lot in pool:
            if not remaining:break
            take=min(remaining,lot['remaining'])
            if take<=0:continue
            lot['remaining']-=take;remaining-=take
            part={k:lot[k] for k in ('brand','product','color','size','variant','kind','sourceFile','line','batchId','basisType')}
            part.update(allocated=take,path=lot['path'],sealed=False)
            a['parts'].append(part)
            if lot['kind']=='manifest':a['manifestQty']+=take
            else:a['plannedQty']+=take
        a['fullManifest']=a['manifestQty']>=qty
        a['matched']=a['matched'] or bool(a['parts']);a['matchNeeded']=(not a['matched'] or ambiguous) and not a['excluded']
        if not a['matched']:
            a['manualRecommendations']=manual_color_recommendations(row,variants)
            a['manualRecommended']=bool(a['manualRecommendations'])
            if a['manualRecommended']:totals['recommended']+=1
        a['allocatedQty']=a['manifestQty']+a['plannedQty']
        a['calendarKnown']=all(all(int(p['path'][f][:4]) in known for f in ('basisDate','chinaDate','koreaEnd','receiptEnd')) for p in a['parts'])
        if a['allocatedQty']>=qty:
            a['koreaStart']=max(p['path']['koreaStart'] for p in a['parts'])
            a['receiptStart']=max(p['path']['receiptStart'] for p in a['parts'])
            a['receiptEnd']=max(p['path']['receiptEnd'] for p in a['parts'])
            a['koreaEnd']=max(p['path']['koreaEnd'] for p in a['parts'])
            a['dispatchStart']=a['koreaStart'];a['dispatchEnd']=a['koreaEnd']
            totals['full']+=1
        elif a['allocatedQty']:totals['partial']+=1
        elif a['matchNeeded']:totals['unmatched']+=1
        if a['allocatedQty']<qty:totals['withoutDate']+=1
        if ambiguous:totals['ambiguous']+=1
        if a['matched']:totals['manual' if method=='manual' else 'automatic']+=1
        if a['excluded'] and not a['matched']:a['reasonCode']='EXCLUDED';a['reason']='매칭 취소됨 · 자동 연결 안 함 (수동 매칭에서 다시 연결 가능)'
        elif ambiguous:a['reasonCode']='AMBIGUOUS';a['reason']='서로 다른 상품 후보 · 수동 매칭 필요'
        elif a['matchNeeded']:a['reasonCode']='UNMATCHED';a['reason']='상품명·컬러·사이즈 미연결 · 수동 매칭 필요'
        elif not a['dispatchEnd']:
            progress_sources=[x for x in a['sources'] if x['kind']=='progress']
            without_office=[x for x in progress_sources if progress_day(x,v['year']) is None]
            if not a['allocatedQty'] and not pool and without_office:
                a['reasonCode']='OFFICE_UNARRIVED';a['reason']='매칭됨 · 중국 사무실 도착일 없음(V 공란/확인 필요)'
                totals['awaitingOffice']+=1
            else:
                a['reasonCode']='SHORTAGE_OR_DATE';a['reason']=f"매칭됨 · 날짜 확인된 물량 {a['allocatedQty']}/{qty}개 · 수량 부족"
                if without_office:a['reason']+=' / V 공란 물량 미사용'
                totals['shortage']+=1
        elif a['fullManifest']:a['reasonCode']='SECURED';a['reason']='출고장 물량 확보'
        else:a['reasonCode']='OFFICE_SCHEDULE';a['reason']='V열 중국 사무실 도착일 기준'
        output[key]=a
    return output,totals

class SupplyWorkflow:
    def setup_supply(self):
        self.supply_io_lock=threading.RLock()
        self.supply_watcher=SupplyWatcher(self)
        with self.store.edit() as s:
            v=init_supply(s)
            remember_progress_cutoff(v)
            if v.get('datePolicy')!='office-only-v1':
                from domain import now
                changed=0
                for r in v['progress']:
                    office=progress_day(r,v['year']);basis=office.isoformat() if office else ''
                    if r.get('basisDate','')!=basis:changed+=1
                    r['basisDate']=basis;r['basisType']='office' if office else 'unknown'
                v['datePolicy']='office-only-v1'
                v['warnings']=[w for w in v.get('warnings',[]) if 'V/L' not in w and 'L+3' not in w]
                s['audits'].append({'at':now(),'event':'진행상황 V열 날짜만 사용 · L+3 추정 폐기',
                    'clearedLegacyEstimates':changed,'messagesChanged':0})
        self._supply_cached=None

    @serialized_supply
    def supply_link(self,path):
        from domain import now
        p=Path(path).expanduser().resolve()
        if not p.is_dir():raise SupplyError('선택한 폴더를 찾을 수 없습니다.')
        with self.store.edit() as s:
            v=init_supply(s)
            if v['folder'] and v['folder']!=str(p) and any(not b.get('closed') for b in v['manifests'].values()):
                raise SupplyError('기억 중인 출고장이 있습니다. 기존 출고 물량을 마감한 뒤 다른 폴더를 연결하세요.')
            v['folder']=str(p);self.supply_watcher.reset();s['audits'].append({'at':now(),'event':'진행상황 폴더 연결 (읽기 전)','path':str(p)})
        return {'folder':str(p),'message':'폴더를 연결했습니다. 수동갱신하거나 자동 반영을 켜세요.'}

    @serialized_supply
    def supply_settings(self,p):
        from domain import now
        year=p.get('year');brands=p.get('brands');holidays=p.get('holidays',[])
        if not isinstance(year,int) or not 2020<=year<=2100:raise SupplyError('기준연도를 확인하세요.')
        if not isinstance(brands,list) or len(brands)>100 or any(not isinstance(x,str) or not re.fullmatch(r'[A-Z][A-Z0-9_-]{0,11}',x) for x in brands):raise SupplyError('브랜드 코드 선택 오류')
        if not isinstance(holidays,list) or len(holidays)>2000:raise SupplyError('휴무일 설정 오류')
        for d in holidays:
            if not isinstance(d,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',d) or as_date(d,year) is None:raise SupplyError('휴무일은 YYYY-MM-DD 형식으로 입력하세요.')
        with self.store.edit() as s:
            v=init_supply(s)
            if v['year']!=year:v['watchSignature']=''
            v.update(year=year,brands=list(dict.fromkeys(brands)),holidays=list(dict.fromkeys(holidays)))
            if p.get('calendarConfirmed') is True and year not in v['confirmedCalendarYears']:v['confirmedCalendarYears'].append(year)
            elif p.get('calendarConfirmed') is False and year!=2026:v['confirmedCalendarYears']=[y for y in v['confirmedCalendarYears'] if y!=year]
            s['audits'].append({'at':now(),'event':'진행상황 설정 저장','brands':v['brands'],'year':year})
        return {'message':'설정을 저장했습니다. 자동 반영이 켜져 있으면 파일 변경을 확인합니다.'}

    @serialized_supply
    def supply_auto_settings(self,p):
        from domain import now
        enabled=p.get('enabled')
        if type(enabled) is not bool:raise SupplyError('자동 반영 켜기/끄기를 선택하세요.')
        with self.store.edit() as s:
            v=init_supply(s)
            if enabled and (not v['folder'] or not Path(v['folder']).is_dir()):raise SupplyError('진행상황 폴더를 먼저 연결하세요.')
            v['autoEnabled']=enabled
            s['audits'].append({'at':now(),'event':'진행상황 자동 반영 켜기' if enabled else '진행상황 자동 반영 끄기'})
        self.supply_watcher.reset()
        if not enabled:self.supply_watcher.update(phase='off',message='자동 반영 꺼짐')
        return {'message':'자동 반영을 켰습니다. 5초마다 변경을 확인하고 저장 완료 후 반영합니다.' if enabled else '자동 반영을 껐습니다. 수동갱신은 계속 사용할 수 있습니다.'}

    @serialized_supply
    def supply_refresh(self,p=None,*,_automatic=False,_expected_signature=None):
        from domain import now
        before=self.store.read();v=init_supply(before);folder=Path(v['folder']) if v['folder'] else None
        if folder is None:raise SupplyError('진행상황 폴더를 먼저 연결하세요.')
        if not folder.is_dir():raise SupplyError('연결 폴더에 접근할 수 없습니다. 이전 자료는 그대로 유지했습니다.')
        signature=scan_signature(str(folder))
        if _expected_signature is not None and signature!=_expected_signature:raise SupplyError('저장 중인 엑셀입니다. 변경이 멈춘 뒤 다시 확인합니다.')
        try:
            paths=[p for p in folder.iterdir() if p.is_file() and not p.is_symlink() and not p.name.startswith(('~$','.')) and p.suffix.lower()=='.xlsx' and not skip_supply_file(p.name)]
            manifest_paths=[p for p in paths if '출고장' in text(p.name) and '완료' in text(p.name)]
            progress_paths=[p for p in paths if is_progress_file(p.name) and p not in manifest_paths]
            # Historical daily progress snapshots are metadata-only candidates;
            # they do not count toward the manifest-reading limit or add stock.
            if len(manifest_paths)>100:raise SupplyError('폴더의 완료 출고장이 100개를 넘습니다. 과거 완료 파일을 정리하세요.')
            latest,progress_selection=latest_progress_files(progress_paths,v['year']);_cx_read=[]
            def load(path,kind,expected=None):
                a=path.stat()
                if expected is not None and (a.st_size,a.st_mtime_ns)!=(expected.st_size,expected.st_mtime_ns):
                    raise SupplyError('선택 중에 엑셀이 변경됐습니다. 저장 완료 후 다시 갱신하세요. 이전 자료를 유지했습니다.')
                if a.st_size>MAX_FILE:raise SupplyError('20MB를 넘는 파일입니다: '+text(path.name))
                raw=path.read_bytes();b=path.stat()
                if (a.st_size,a.st_mtime_ns)!=(b.st_size,b.st_mtime_ns):raise SupplyError('저장 중인 엑셀입니다. 저장 완료 후 다시 갱신하세요. 이전 자료를 유지했습니다.')
                try:
                    _b=read_supplier(path.name,raw,v['year'],kind);_cx_read.append((path,raw,_b));return _b
                except WorkbookError as e:
                    raise SupplyError('엑셀 읽기 실패: '+text(path.name)+' · '+str(e)+' · 이전 자료를 유지했습니다.') from e
            # A broken latest file must not silently fall back to stale stock.
            progress_batches=[load(c['path'],'progress',c['stat']) for c in latest]
            if len({b['fingerprint'] for b in progress_batches})>1:
                raise SupplyError('최신 날짜와 수정시각이 같은 진행상황 파일의 내용이 서로 다릅니다. 최종 파일을 확인하세요. 이전 자료를 유지했습니다.')
            loaded=[load(path,'manifest') for path in sorted(manifest_paths)]
            if progress_batches:loaded.append(progress_batches[0])
        except (OSError,WorkbookError) as e:raise SupplyError('파일 읽기 실패. 이전 자료를 유지했습니다. '+str(e)) from e
        manifests=[b for b in loaded if b['id'].startswith('manifest:')]
        dates=defaultdict(set)
        for b in manifests:dates[b['date']].add(b['evidenceFingerprint'])
        if any(len(f)>1 for f in dates.values()):raise SupplyError('같은 날짜에 내용이 다른 출고장이 여러 개입니다. 날짜별 최종 파일 한 개만 두세요. 이전 자료를 유지했습니다.')
        with self.network_lock,self.store.edit() as s:
            cur=init_supply(s)
            if (cur['folder'],cur['year'])!=(v['folder'],v['year']):raise SupplyError('읽는 동안 폴더/연도 설정이 바뀌었습니다. 다시 갱신하세요.')
            if _automatic and (not cur['autoEnabled'] or self.stop.is_set() or getattr(self,'reset_in_progress',False)):raise SupplyError('자동 반영을 중단했습니다. 이전 자료를 유지합니다.')
            if scan_signature(str(folder))!=signature:raise SupplyError('읽는 동안 폴더 파일이 바뀌었습니다. 이전 자료를 유지합니다.')
            remember_progress_cutoff(cur,manifests)
            warnings=[];seen=set();skipped=0
            for batch in loaded:
                if batch['rows'] and not any(r['brand'] in cur['brands'] for r in batch['rows']):
                    warnings.append(batch['name']+': 선택 브랜드에 해당하는 행이 0개입니다. 파일 E열 브랜드 '+', '.join(batch['brands'])+' 중 자신의 쇼핑몰 코드를 선택한 뒤 수동갱신하세요. (현재 선택: '+(', '.join(cur['brands']) or '없음')+')')
            if not loaded:warnings.append('읽은 파일 0개: 연결 폴더 바로 아래의 파일명과 위치를 확인하세요. 완료 물량은 기억하고, 없는 진행상황의 예상 물량은 제외합니다.')
            cur['progress']=[]
            for b in loaded:
                warnings+=b['warnings'];cur['discovered']=sorted(set(cur['discovered'])|set(b['brands']))
                if b['id'].startswith('progress:'):
                    cur['progress']=b['rows'];continue
                if b['fingerprint'] in seen:skipped+=1;continue
                seen.add(b['fingerprint'])
                old=cur['manifests'].get(b['id'])
                if (old and old.get('closed')) or b['fingerprint'] in cur['retiredFingerprints']:
                    skipped+=1;warnings.append(b['name']+': 마감한 출고장이라 다시 수량을 넣지 않았습니다.');continue
                b['lastReadAt']=now();cur['manifests'][b['id']]=b
            present={b['id'] for b in manifests}
            for b in cur['manifests'].values():b['fileMissing']=b['id'] not in present
            cur['warnings']=warnings;cur['lastReadAt']=now()
            cur['watchSignature']=signature;cur['lastReadMode']='automatic' if _automatic else 'manual'
            cur['lastScan']={'at':cur['lastReadAt'],'error':'','progressSelection':progress_selection,'files':[
                {'name':b['name'],'kind':'manifest' if b['id'].startswith('manifest:') else 'progress',
                 'rows':len(b['rows']),'selectedRows':sum(r['brand'] in cur['brands'] for r in b['rows'])} for b in loaded]}
            s['audits'].append({'at':now(),'event':'출고장/진행상황 자동 반영' if _automatic else '출고장/진행상황 수동갱신','files':len(loaded),'duplicateOrRetired':skipped,'progressSelection':copy.deepcopy(progress_selection)})
        view,totals=allocation_view(self.store.read())
        message=f"{len(loaded)}개 파일 읽음 · 출고예상일 {totals['full']}개 상품 · 일부 수량 {totals['partial']}개 · 매칭 필요 {totals['unmatched']}개. 실제 발송 없음."
        if progress_selection:message='진행상황 '+progress_selection['name']+' 반영 · '+message
        try:   # 2026-10-25 Codex 자료 목록: 반영에 성공한 진행상황·출고장 (같은 반영 = 같은 회차)
            import codex_catalog,uuid as _uuid;_run='scan-'+_uuid.uuid4().hex[:10];_used={id(b) for b in loaded}
            for _p,_raw,_b in _cx_read:
                if id(_b) not in _used:continue
                _m=str(_b.get('id','')).startswith('manifest:')
                codex_catalog.record_bytes('shipment' if _m else 'progress',_p.name,_raw,role='input',source=str(_p),basis=str(_b.get('date') or '') if _m else '',run=_run)
        except Exception:pass
        return {'files':len(loaded),'skipped':skipped,'progressSelection':progress_selection,'warnings':warnings,'totals':totals,'message':message}

    @serialized_supply
    def supply_match(self,p):
        from domain import now
        keys=p.get('variants');key=p.get('key')
        if not isinstance(keys,list) or len(keys)>200 or any(not isinstance(x,str) for x in keys):raise SupplyError('매칭할 상품·컬러·사이즈를 선택하세요.')
        with self.network_lock,self.store.edit() as s:
            v=init_supply(s);row=next((r for r in s['rows'] if r['key']==key and r['active']),None)
            if not row:raise SupplyError('현재 미출고 주문을 선택하세요.')
            allowed={x['variant'] for x in catalogue(v)}
            if any(x not in allowed for x in keys):raise SupplyError('현재 선택 브랜드의 상품이 아닙니다. 목록을 다시 열어주세요.')
            sig=order_signature(row);exclude=p.get('exclude') is True and not keys   # 2026-10-26 15:22 요청: 매칭 취소(연결 안 함)
            if keys:v['mappings'][sig]=list(dict.fromkeys(keys))
            elif exclude:v['mappings'][sig]=[]
            else:v['mappings'].pop(sig,None)
            # An explicitly changed SKU mapping invalidates sealed proofs for that SKU.
            for k in [k for k,pin in v['sealed'].items() if pin.get('signature')==sig]:del v['sealed'][k]
            s['audits'].append({'at':now(),'event':'상품명/옵션 매칭 저장' if keys else '자동 매칭 취소(연결 안 함)' if exclude else '수동 매칭 해제(자동 매칭으로)','signature':sig,'variants':keys})
        if exclude:return {'message':'이 상품명·옵션은 자동 매칭하지 않습니다(연결 안 함). 같은 상품명·옵션의 다른 주문에도 적용했습니다. 다시 연결하려면 수동 매칭에서 고르거나 [저장한 매칭 해제]로 자동 매칭으로 돌리세요. 문자는 발송하지 않았습니다.'}
        if not keys:return {'message':'저장한 매칭을 해제했습니다. 이제 자동 매칭 규칙을 다시 따릅니다. 문자는 발송하지 않았습니다.'}
        return {'message':'같은 상품명·옵션의 다른 주문에도 매칭을 적용했습니다. 문자는 발송하지 않았습니다.'}

    @serialized_supply
    def supply_reset(self,p):
        from domain import now
        if p.get('confirmed') is not True:raise SupplyError('출고가 진행된 당일의 물량 마감인지 확인하세요.')
        if self.archive:self.backup_desktop(force=True,reason='before-manifest-reset')
        with self.network_lock,self.store.edit() as s:
            v=init_supply(s)
            # 2026-10-19: look at the folder first. A remembered manifest whose file is gone (e.g. 10월 13일 출고장 (완료))
            # is forgotten completely — its rows, closed flag and the sealed proofs that came from it — instead of
            # staying as '파일 없음 · 기억 유지'. Only files present right now stay in memory.
            present=manifest_ids_in_folder(v['folder'],v['year'])
            forgotten=[b for b in v['manifests'].values() if present is not None and b['id'] not in present]
            for b in forgotten:
                del v['manifests'][b['id']]
                for key,pin in list(v['sealed'].items()):
                    pin['parts']=[part for part in pin['parts'] if part.get('batchId')!=b['id']]
                    if not pin['parts']:del v['sealed'][key]
            if forgotten:
                s['audits'].append({'at':now(),'event':'출고장 갱신 · 폴더에 없는 출고장 기억 삭제','batches':[b['name'] for b in forgotten],'remaining':len(present or [])})
            projection,_=allocation_view(s);bykey={r['key']:r for r in s['rows'] if r['active']}
            targets=[b for b in v['manifests'].values() if not b.get('closed')]
            gone=(' 폴더에 없는 출고장 '+', '.join(b['name'] for b in forgotten)+' 기억 삭제.') if forgotten else ''
            if present is not None:gone=f' 폴더 출고장 {len(present)}개 확인.'+gone
            if not targets:return {'batches':0,'qty':0,'forgotten':[b['name'] for b in forgotten],'message':'마감할 열린 출고장이 없습니다. 이전 재배치 기록은 유지했습니다.'+gone}
            stamp=now()
            v['lastResetRestore']={'at':stamp,'token':secrets.token_urlsafe(20),
                                  'batches':{b['id']:copy.deepcopy(b) for b in targets}}
            # Freeze existing evidence to these specific orders. It is NOT a pool
            # of reusable stock, and disappears rather than freeing stock when the order leaves.
            for key,a in projection.items():
                parts=[p for p in a['parts'] if p['kind']=='manifest']
                if parts and key in bykey:
                    v['sealed'][key]={'signature':order_signature(bykey[key]),'originalQty':bykey[key]['qty'],'parts':parts,'at':now()}
            total=sum(r['qty'] for b in targets for r in b['rows'] if r['brand'] in v['brands'])
            for b in targets:
                b['closed']=True;b['closedAt']=stamp
                v['retiredFingerprints'].append(b['fingerprint'])
                for r in b['rows']:r['qty']=0
            v['retiredFingerprints']=list(dict.fromkeys(v['retiredFingerprints']));v['lastResetAt']=stamp
            s['audits'].append({'at':now(),'event':'출고장 수량 마감 (재배정 금지)','batches':len(targets),'qty':total})
        if self.archive:self.backup_desktop(force=True,reason='manifest-reset')
        return {'batches':len(targets),'qty':total,'forgotten':[b['name'] for b in forgotten],'message':f'출고장 {len(targets)}개 물량을 마감했습니다. 다시 배정할 수량은 0이고 기존 주문의 확보 근거만 유지합니다.'+gone}

    @serialized_supply
    def supply_reallocate(self,p):
        from domain import now
        if p.get('confirmed') is not True:raise SupplyError('실제 출고하지 않은 물량을 복원하는지 확인하세요.')
        before=self.store.read();v=init_supply(before);info=reallocation_info(v)
        if not info['available']:raise SupplyError('재배치할 최근 출고장 갱신 기록이 없습니다.')
        if p.get('token')!=info['token']:raise SupplyError('출고장 마감 기록이 변경됐습니다. 창을 다시 열어 확인하세요.')
        if info['requiresOriginal']:
            restored={};folder=Path(v['folder']) if v['folder'] else None
            if folder is None or not folder.is_dir():raise SupplyError('이전 버전에서 마감한 출고장은 원본 파일이 있는 폴더를 연결해야 재배치할 수 있습니다.')
            for ident in info['batchIds']:
                old=v['manifests'][ident];name=old['name']
                if Path(name).name!=name:raise SupplyError('출고장 파일 이름을 확인하세요.')
                path=folder/name
                try:
                    if path.is_symlink():raise SupplyError('원본 출고장은 연결 폴더 안의 일반 파일이어야 합니다.')
                    a=path.stat()
                    if a.st_size>MAX_FILE:raise SupplyError('원본 출고장 파일이 20MB를 넘습니다.')
                    raw=path.read_bytes();b=path.stat()
                    if (a.st_size,a.st_mtime_ns)!=(b.st_size,b.st_mtime_ns):raise SupplyError('출고장이 저장 중입니다. 저장 완료 후 다시 재배치하세요.')
                    batch=read_supplier(name,raw,v['year'],'manifest')
                except (OSError,WorkbookError) as exc:raise SupplyError('재배치할 원본 출고장을 읽지 못했습니다: '+name) from exc
                if batch['id']!=ident or batch['fingerprint']!=old['fingerprint']:
                    raise SupplyError('마감 당시와 원본 출고장의 상품·수량이 다릅니다: '+name+' · 재배치하지 않았습니다.')
                restored[ident]=batch
        else:restored=copy.deepcopy(v['lastResetRestore']['batches'])
        if self.archive:self.backup_desktop(force=True,reason='before-manifest-reallocate')
        with self.network_lock,self.store.edit() as s:
            current=init_supply(s)
            if reallocation_info(current)['token']!=info['token']:raise SupplyError('읽는 동안 출고장 기록이 변경됐습니다. 다시 확인하세요.')
            target_ids=set(restored)
            # Remove only these batches' fixed proofs before putting their stock
            # back into the FIFO pool; all earlier closed waves remain closed.
            for key,pin in list(current['sealed'].items()):
                pin['parts']=[part for part in pin['parts'] if part.get('batchId') not in target_ids]
                if not pin['parts']:del current['sealed'][key]
            fingerprints={b['fingerprint'] for b in restored.values()}
            for ident,batch in restored.items():
                batch['closed']=False;batch.pop('closedAt',None)
                batch['fileMissing']=current['manifests'][ident].get('fileMissing',False)
                current['manifests'][ident]=batch
            current['retiredFingerprints']=[x for x in current['retiredFingerprints'] if x not in fingerprints]
            current['lastResetRestore']={'at':info['at'],'restored':True};current['lastReallocateAt']=now()
            current['warnings']=[w for w in current['warnings'] if not ('마감한 출고장' in w and any(w.startswith(b['name']+':') for b in restored.values()))]
            total=sum(r['qty'] for b in restored.values() for r in b['rows'] if r['brand'] in current['brands'])
            s['audits'].append({'at':now(),'event':'최근 출고장 갱신 취소 · 현재 주문에 재배치',
                                'batches':list(restored),'qty':total,'resetAt':info['at']})
        if self.archive:self.backup_desktop(force=True,reason='manifest-reallocate')
        return {'batches':len(restored),'qty':total,'message':f'출고장 {len(restored)}개 · 선택 브랜드 {total}개 물량을 복원해 현재 주문 순서대로 재배치했습니다. 실제 발송 없음.'}

    def supply_after_import(self,s):
        v=init_supply(s);keys={r['key'] for r in s['rows'] if r['active']}
        # Closed/used allocations never return to an available pool.
        v['sealed']={k:a for k,a in v['sealed'].items() if k in keys}

    def ship_delay_answer(self,p):
        """2026-10-21 20:33: answer for a Tuesday whose 출고장 did not show up by Wednesday 18:00."""
        from domain import now
        tue=p.get('tuesday');ans=p.get('answer')
        try:d=date.fromisoformat(tue)
        except (TypeError,ValueError):raise SupplyError('화요일 날짜를 확인하세요.')
        if d.weekday()!=1 or d.isoformat()!=tue:raise SupplyError('화요일 날짜가 아닙니다.')
        if ans not in ('shipped','delayed','undo'):raise SupplyError('답을 확인하세요.')
        with self.store.edit() as s:
            v=init_supply(s);delays=v.setdefault('shipDelays',{})
            if ans=='undo':delays.pop(tue,None);msg=f'{d.month}/{d.day}(화) 출고 지연 표시를 지웠습니다. 예상 출고일을 원래대로 계산합니다.'
            elif ans=='shipped':delays[tue]={'status':'shipped','at':now()};msg=f'{d.month}/{d.day}(화) 출고는 진행된 것으로 기록했습니다. 출고장이 들어오면 그대로 반영합니다.'
            else:
                dep=p.get('departure')
                if dep not in ('fri','sat'):raise SupplyError('다음 출고일(금요일/토요일)을 고르세요.')
                new=d+timedelta(days=3 if dep=='fri' else 4)
                delays[tue]={'status':'delayed','departure':new.isoformat(),'at':now()}
                msg=f"{d.month}/{d.day}(화) 출고분을 {'금요일' if dep=='fri' else '토요일'} {new.month}/{new.day} 중국 출고로 바꿨습니다 · 실 출고 예상 다음주 {'화~수' if dep=='fri' else '수~목'}요일. 예상 출고일을 다시 계산합니다."
            s['audits'].append({'at':now(),'event':'화요일 출고 지연 답변','tuesday':tue,'answer':ans,'departure':(delays.get(tue) or {}).get('departure','')})
        self._supply_cached=None
        return {'message':msg,'shipDelays':copy.deepcopy(self.store.read().get('supply',{}).get('shipDelays',{}))}
    def dispatch_override(self,p):
        """2026-10-24 요청: 출고장(중국 출고분)의 실 출고 예상일을 사장님이 직접 지정/해제. 고객 메시지는 보내지 않는다."""
        from domain import now,today
        china=str(p.get('chinaDate') or '')
        try:cd=date.fromisoformat(china)
        except ValueError:raise SupplyError('중국 출고일(출고장 날짜)을 다시 골라 주세요.') from None
        if p.get('clear'):
            with self.store.edit() as s:
                v=init_supply(s);old=(v.get('dispatchOverrides') or {}).pop(china,None)
                if not old:raise SupplyError('지정해 둔 출고 예상일이 없습니다.')
                s['audits'].append({'at':now(),'event':'출고 예상일 직접 지정 해제','chinaDate':china,'was':old})
            self._supply_cached=None
            return {'message':f'{cd.month}/{cd.day} 중국 출고분의 직접 지정을 지웠습니다. 출고 예상일을 원래 규칙대로 다시 계산합니다. 고객 메시지는 보내지 않았습니다.'}
        try:lo=date.fromisoformat(str(p.get('start') or ''));hi=date.fromisoformat(str(p.get('end') or p.get('start') or ''))
        except ValueError:raise SupplyError('바꿀 출고 예상일을 날짜로 골라 주세요.') from None
        if hi<lo:raise SupplyError('끝 날짜가 시작 날짜보다 빠릅니다.')
        if lo<cd:raise SupplyError('출고 예상일이 중국 출고일보다 빠릅니다.')
        if (hi-lo).days>14 or (lo-cd).days>60:raise SupplyError('날짜 범위가 너무 넓습니다. 다시 확인해 주세요.')
        with self.store.edit() as s:
            v=init_supply(s);o=v.setdefault('dispatchOverrides',{})
            o[china]={'start':lo.isoformat(),'end':hi.isoformat(),'at':now(),'source':str(p.get('source') or 'app')[:20],'note':str(p.get('note') or '')[:200]}
            s['audits'].append({'at':now(),'event':'출고 예상일 직접 지정','chinaDate':china,'start':lo.isoformat(),'end':hi.isoformat(),'source':o[china]['source']})
        self._supply_cached=None
        span=f'{lo.month}/{lo.day}' if lo==hi else f'{lo.month}/{lo.day}~{hi.month}/{hi.day}'
        warn=' (오늘보다 이전 날짜입니다)' if lo.isoformat()<today() else ''
        return {'message':f'{cd.month}/{cd.day} 중국 출고분의 출고 예상일을 {span}로 바꿨습니다{warn}. 고객에게 안내한 출고 예정일과 발송 이력은 그대로이고, 메시지는 보내지 않았습니다.'}
    def supply_public(self,s):
        from delay_risk import decorate_risks
        v=init_supply(s)
        try:s['shipDelayQuestion']=ship_delay_question(v)
        except Exception:s['shipDelayQuestion']=None
        revision=s.get('revision')
        if self._supply_cached and self._supply_cached[0]==revision:
            projection,totals=copy.deepcopy(self._supply_cached[1:])
        else:
            projection,totals=allocation_view(s);self._supply_cached=(revision,copy.deepcopy(projection),copy.deepcopy(totals))
        variants=catalogue(v)
        for r in s['rows']:
            a=projection.get(r['key'],{})
            # Sold-out rows do not consume inventory, but retain a read-only
            # source match for the user's V-date lookup cards.
            if r.get('active') and not a:
                hits,ambiguous,method=candidates(r,variants,v['mappings'])
                a={'matched':bool(hits),'ambiguous':ambiguous,'matchNeeded':not hits or ambiguous,
                   'matchMethod':method,'sources':source_evidence(v,{h['variant'] for h in hits}),
                   'parts':[],'fullManifest':False,'manifestQty':0,'plannedQty':0,
                   'manualVariants':copy.deepcopy(v['mappings'].get(order_signature(r),[])),
                   'reason':'품절 안내 상품 · 수량 배정 없음','reasonCode':'SOLDOUT_NO_ALLOCATION'}
            r['supplyInfo']=a
            r.update(progress_facts(a,v['year']))
            # Display metadata only. Never add the label to persisted order IDs.
            r['isExchange']=text(r.get('orderId','')).upper().startswith('C')
            r['displayOrderId']=('[교환] ' if r['isExchange'] else '')+r.get('orderId','')
            r['receiptStart']=a.get('receiptStart','');r['receiptEnd']=a.get('receiptEnd','')
            r['dispatchStart']=a.get('dispatchStart','');r['dispatchEnd']=a.get('dispatchEnd','')
            r['stockSecured']=bool(a.get('fullManifest'))
            if r['bucket']=='within' and a.get('fullManifest') and a.get('calendarKnown') and a.get('koreaEnd') and a['koreaEnd']<=r['dueDate']:
                r['bucket']='within_confirmed';r['color']='confirmed'
        if v['autoEnabled'] and self.supply_watcher.status().get('error'):
            v['lastScan']=dict(v.get('lastScan',{}),error=self.supply_watcher.status()['error'])
        decorate_risks(s,v)
        s['supply']={k:copy.deepcopy(v[k]) for k in ('folder','year','brands','discovered','holidays','confirmedCalendarYears','warnings','lastReadAt','lastResetAt')}
        s['supply']['lastScan']=copy.deepcopy(v.get('lastScan',{}))
        s['supply']['dispatchWaves']=dispatch_waves(s,projection,v.get('dispatchOverrides') or {})   # 2026-10-25: 출고 예상일 변경 창
        s['supply'].update(autoEnabled=v['autoEnabled'],lastReadMode=v['lastReadMode'],progressCutoff=progress_cutoff(v),watch=self.supply_watcher.status())
        if v['autoEnabled'] and s['supply']['watch'].get('error'):s['supply']['lastScan']['error']=s['supply']['watch']['error']
        excluded=[r for r in v['progress'] if r['brand'] in v['brands'] and excluded_progress(r,v,s['supply']['progressCutoff'])]
        s['supply']['excludedProgress']={'rows':len(excluded),'qty':sum(r['qty'] for r in excluded)}
        s['supply']['reallocation']=reallocation_info(v)
        s['supply']['loadedCounts']={
            'manifestRows':sum(1 for b in v['manifests'].values() if not b.get('closed') for r in b['rows'] if r['brand'] in v['brands']),
            'manifestQty':sum(r['qty'] for b in v['manifests'].values() if not b.get('closed') for r in b['rows'] if r['brand'] in v['brands']),
            'progressRows':sum(r['brand'] in v['brands'] for r in effective_progress(v)),
            'progressWithDate':sum(r['brand'] in v['brands'] and progress_day(r,v['year']) is not None for r in effective_progress(v)),
            'progressWithoutOffice':sum(r['brand'] in v['brands'] and progress_day(r,v['year']) is None for r in effective_progress(v)),
            'securedItems':sum(r.get('stockSecured',False) for r in s['rows'] if r.get('active')),
            'confirmedItems':sum(r.get('bucket')=='within_confirmed' for r in s['rows'] if r.get('active'))}
        # 11:38 요청 "수동매칭 필요": 출고장·진행상황에는 있는데 현재 미출고 주문 어느 것에도(자동·수동) 연결되지 않은 상품·옵션.
        matched_ids={x['variant'] for r in s['rows'] if r.get('active') for x in (r.get('supplyInfo') or {}).get('sources',[])}
        all_sources=[r for b in v['manifests'].values() if not b.get('closed') for r in b['rows']]+effective_progress(v)
        qty_of={}
        for x in all_sources:
            if x['brand'] in v['brands']:qty_of[x['variant']]=qty_of.get(x['variant'],0)+int(x.get('qty') or 0)
        unmatched=[dict(x,qty=qty_of.get(x['variant'],0)) for x in catalogue(v) if x['variant'] not in matched_ids]
        s['supply']['unmatchedVariants']=unmatched;s['supply']['manualNeededCount']=len(unmatched)
        s['supply'].update(variants=catalogue(v),rules=copy.deepcopy(v['mappings']),totals=totals,
             batches=[{k:b.get(k) for k in ('id','name','date','closed','fileMissing')}|{'qty':sum(r['qty'] for r in b['rows'] if r['brand'] in v['brands'])} for b in v['manifests'].values()],
             manualOnly=False)
        return s
