"""Zigzag (카카오스타일 파트너센터) 상품준비/배송 관리: read the list, send 배송연기 안내 one order at a time.

Observed on 2026-10-19 in the partner center (shop nuavu):
- https://shop.zigzag.kr/<shop>/#!/stats redirects to https://partners.kakaostyle.com/login; after login the
  dashboard is https://partners.kakaostyle.com/shop/<shop>/stats.
- List: /shop/<shop>/order_item/list/pre_shipment?status_option=awaiting_shipment&date_from=946652400000
  (date_from = 2000-01-01 selects 조회기간 전체 and loads the list without pressing 조회).
  Table headers include 상품주문번호, 주문번호, 발송 예정일 ("2026.10.21 23:59:59 (3 영업일)"), 변경 발송 예정일,
  자체상품코드, 상품명, 옵션정보, 수량, 수령인명. Pagination buttons carry aria-label "N 페이지" / "다음 페이지".
- 배송연기 안내: check one row → button "배송연기 안내" (not the status tab) → modal .pds-modal-wrapper with
  변경 발송 예정일 (text input "날짜를 선택하세요." + react-day-picker: only weekdays after the current
  발송 예정일, up to 7 business days, are enabled), 배송연기 사유 (combobox → li[role=option]
  "상품 입고 지연"), 상세사유 (textarea, 50 chars max), submit button "배송연기 안내". Ably-style rules:
  once per order, never retried after the submit click.
"""
import re,time
from urllib.parse import urlsplit
from datetime import date,timedelta

REASON='상품 입고 지연'
DETAIL='안녕하세요 고객님 배송 지연으로 불편을 드려 죄송합니다.\n최대한 빠르게 보내드리겠습니다.'
ENTRY='https://shop.zigzag.kr/{shop}/#!/stats'
PARTNERS='https://partners.kakaostyle.com'
LIST=PARTNERS+'/shop/{shop}/order_item/list/pre_shipment?status_option=awaiting_shipment&date_from=946652400000'
MAX_BUSINESS_DAYS=7
COLUMNS={'itemId':'상품주문번호','orderId':'주문번호','status':'주문상태','shipBy':'발송 예정일','changedShipBy':'변경 발송 예정일',
         'product':'상품명','option':'옵션정보','qty':'수량','recipient':'수령인명','sku':'자체상품코드','orderedAt':'주문일시'}

class ZigzagError(ValueError):pass
class ZigzagCancelled(ZigzagError):pass
class ZigzagPushAborted(ZigzagError):
    """Some 배송연기 안내 were already sent when the run stopped; the outcome must be recorded."""
    def __init__(self,message,pushes):super().__init__(message);self.pushes=pushes

def iso_day(text):
    """'2026.10.21 23:59:59 (3 영업일)' / '2026-10-21' → '2026-10-21' ('' when absent)."""
    m=re.search(r'(\d{4})[.\-/](\d{2})[.\-/](\d{2})',str(text or ''))
    return f'{m[1]}-{m[2]}-{m[3]}' if m else ''

def business_days_after(start,count):
    """Business days strictly after `start` (a date), `count` of them. 2026-10-23: weekends and public holidays
    (zigzag_rules / supply_calendar 2026 table) are skipped, like the partner-center calendar."""
    from zigzag_rules import business_after
    return business_after(start,count)

def choose_change_date(app_due,current):
    """The app's 출고 예정일 vs Zigzag's current 발송 예정일 (변경 발송 예정일 if set).

    Returns (iso_date,reason). '' when nothing should be sent: app date not later than Zigzag's
    (no delay to announce), or beyond the selectable range. A weekend/earlier-than-allowed app date
    moves to the first selectable weekday on or after it.
    """
    try:a=date.fromisoformat(app_due);c=date.fromisoformat(current)
    except (TypeError,ValueError):return '','출고 예정일 또는 지그재그 발송 예정일 형식 오류'
    if a<=c:return '',f'지그재그 발송 예정일({c.isoformat()}) 이후가 아니어서 안내하지 않습니다.'
    allowed=business_days_after(c,MAX_BUSINESS_DAYS)
    for d in allowed:
        if d>=a:return d.isoformat(),('' if d==a else f'{a.isoformat()}은 선택 불가(주말)라 {d.isoformat()}으로 안내')
    return '',f'출고 예정일 {a.isoformat()}이 지그재그 선택 범위({allowed[0].isoformat()}~{allowed[-1].isoformat()}, 발송 예정일 이후 7영업일)를 넘습니다.'

LIST_JS=r'''()=>{
 const t=document.querySelector('table');if(!t)return null;
 const heads=[...t.querySelectorAll('thead th')].map(th=>th.innerText.trim().replace(/\s+/g,' '));
 const rows=[...t.querySelectorAll('tbody tr')].map(tr=>{const tds=[...tr.querySelectorAll('td')].map(td=>td.innerText.trim().replace(/\s+/g,' '));const o={};heads.forEach((h,i)=>{if(h)o[h]=tds[i]??'';});o.__checked=!!tr.querySelector('input[type=checkbox]:checked');return o;});
 const total=(document.body.innerText.match(/배송준비중 목록 \((\d+)건\)/)||[])[1];
 const pages=[...document.querySelectorAll('button[aria-label$=" 페이지"]')].map(b=>b.getAttribute('aria-label')).filter(x=>/^\d+ 페이지$/.test(x)).length;
 const next=document.querySelector('button[aria-label="다음 페이지"]');
 return {heads,rows,total:total?Number(total):null,pages,hasNext:!!next&&!next.disabled};
}'''

class Reader:
    def __init__(self,page,stop,progress,context=None):self.page=page;self.stop=stop;self.progress=progress;self.step='';self.clicked=False;self.context=context or page.context;self.shop=getattr(self,'shop',None)   # 2026-10-23 19:03: ZigzagClaims 가 먼저 정한 shop 을 지우지 않는다 (/shop/None/stats 버그)
    def check(self):
        if self.stop.is_set():raise ZigzagCancelled('지그재그 작업을 중단했습니다.')
    def wait(self,predicate,message,seconds=30):
        until=time.monotonic()+seconds
        while time.monotonic()<until:
            self.check()
            value=predicate()
            if value:return value
            self.page.wait_for_timeout(150)
        raise ZigzagError(message)
    def on_partners(self):return self.live_page().url.startswith(PARTNERS+'/')
    def logged_in(self,shop):return self.live_page().url.startswith(f'{PARTNERS}/shop/{shop}/')
    # ---- login (same rules as Ably: saved account, keyboard typing, one submission, no retry) ----
    def live_page(self):
        """shop.zigzag.kr may hand off to a new tab and close the first one: keep working on an open page."""
        if self.page and not self.page.is_closed():return self.page
        context=self.context
        open_pages=[p for p in context.pages if not p.is_closed()]
        self.page=open_pages[-1] if open_pages else context.new_page()
        return self.page
    def login_form(self):
        p=self.live_page()
        try:return self.on_partners() and '/login' in p.url and p.locator('input[type="password"]:visible').count()==1
        except Exception:return False
    def dashboard(self,shop):
        p=self.live_page()
        try:return self.logged_in(shop) and p.locator('input[type="password"]:visible').count()==0 and p.locator('body').inner_text(timeout=3000).strip()!=''
        except Exception:return False
    # ---- 06:53 보고: 로그인 뒤 가끔 https://partners.kakaostyle.com/home (입점 스토어 목록) 에 떨어진다. 스토어 카드(누아브판 '누아브',
    # 배포판은 설정의 쇼핑몰 이름)를 눌러 들어간다. 06:55 크롬 확인: 이름 글자를 누르면 /shop/<shop>/stats 로 이동.
    def store_chooser(self):
        p=self.live_page()
        try:return self.on_partners() and urlsplit(p.url).path.rstrip('/')=='/home' and '입점 스토어' in p.locator('body').inner_text(timeout=3000)
        except Exception:return False
    def choose_store(self,shop,shop_name):
        p=self.live_page();names=[n for n in dict.fromkeys([shop_name,shop]) if n]
        self.step='지그재그 입점 스토어 선택';self.progress(f'입점 스토어 목록입니다. {names[0]} 스토어를 선택합니다.')
        picked=p.evaluate("""(names)=>{const leaves=[...document.querySelectorAll('*')].filter(e=>e.children.length===0&&e.textContent.trim());
          for(const n of names){const low=n.toLowerCase();const el=leaves.find(e=>e.textContent.trim()===n)||leaves.find(e=>e.textContent.trim().toLowerCase()===low);if(el){el.click();return el.textContent.trim();}}
          return '';}""",names)
        if not picked:raise ZigzagError('입점 스토어 목록에서 "'+names[0]+'" 스토어를 찾지 못했습니다. 설정의 쇼핑몰 이름과 지그재그 스토어 이름이 같은지 확인하세요.')
        self.wait(lambda:self.dashboard(shop),f'"{picked}" 스토어를 눌렀지만 대시보드가 열리지 않았습니다.',30)
    def entered(self,shop,shop_name):
        """dashboard, or the store chooser handled on the spot."""
        if self.dashboard(shop):return True
        if self.store_chooser():self.choose_store(shop,shop_name);return True
        return False
    def login(self,account):
        shop=account['shop'];shop_name=account.get('shopName') or '';self.step='지그재그 로그인 화면 열기'
        self.progress('지그재그 파트너센터 로그인 화면을 엽니다.')
        try:self.live_page().goto(ENTRY.format(shop=shop),wait_until='domcontentloaded',timeout=30000)
        except Exception:pass
        # Wait up to 3s for the hand-off; if neither the login form nor the dashboard shows, open the login page directly (once).
        end=time.monotonic()+3
        while time.monotonic()<end and not (self.login_form() or self.entered(shop,shop_name)):self.live_page().wait_for_timeout(200)
        if not (self.login_form() or self.entered(shop,shop_name)):
            self.progress('지그재그 로그인 화면으로 직접 이동합니다.')
            self.live_page().goto(PARTNERS+'/login',wait_until='domcontentloaded',timeout=30000)
            self.wait(lambda:self.login_form() or self.entered(shop,shop_name),'지그재그 로그인 화면이 열리지 않았습니다.',30)
        if not self.entered(shop,shop_name):
            page=self.live_page();self.step='지그재그 계정 입력'
            if not self.login_form():raise ZigzagError('지그재그 로그인 주소를 확인하지 못했습니다. 계정을 입력하지 않았습니다.')
            pw=page.locator('input[type="password"]:visible')
            user=page.locator('input[type="text"]:visible, input[type="email"]:visible, input:not([type]):visible')
            if user.count()!=1:raise ZigzagError('로그인 아이디 입력칸을 구분하지 못했습니다.')
            for loc,value in ((user,account['username']),(pw,account['password'])):
                self.check()
                if '/login' not in page.url:raise ZigzagError('로그인 입력 중 주소가 바뀌었습니다.')
                loc.fill('');loc.press_sequentially(value,delay=20)
                if loc.input_value()!=value:raise ZigzagError('로그인 입력값이 일치하지 않습니다. 저장 계정을 확인하세요.')
            self.check()
            button=page.get_by_role('button',name=re.compile(r'^\s*로그인\s*$'))
            if button.count():button.first.click(timeout=10000)
            else:pw.press('Enter')
            self.progress('로그인 확인 중입니다. 추가 인증이 나오면 Chrome에서 직접 완료하세요. 자동 재시도하지 않습니다.')
            import browser_window;started=time.monotonic()
            def signed():
                if time.monotonic()-started>8:
                    if browser_window.need_person():raise ZigzagError('추가 인증 또는 로그인 확인이 필요합니다. '+browser_window.need_person())
                    browser_window.attention()
                return self.entered(shop,shop_name)
            self.wait(signed,'지그재그 로그인을 확인하지 못했습니다. 계정 또는 추가 인증을 확인하고 다시 실행하세요.',120)
            browser_window.calm()
        self.progress('지그재그 로그인 확인. 상품준비/배송 관리 목록을 엽니다.')
    # ---- list ----
    def list_settled(self):
        """The list renders in stages (title '0건' first, rows later): accept only a consistent title/rows pair."""
        d=self.read_page()
        if not d or d['total'] is None:return None
        rows=[r for r in d['rows'] if re.fullmatch(r'\d{6,30}',str(r.get('상품주문번호','')))]
        if d['total']==0 and not rows:return d
        if d['total']>0 and rows and (d['pages']>1 or len(rows)==d['total']):return d
        return None
    def open_list(self,shop):
        self.step='상품준비/배송 관리 목록 열기'
        self.page=self.live_page();self.page.goto(LIST.format(shop=shop),wait_until='domcontentloaded',timeout=30000)
        self.wait(self.list_settled,'지그재그 배송준비중 목록을 읽지 못했습니다 (목록 건수와 표가 맞지 않음).',45)
        self.page.wait_for_timeout(800)
    def read_page(self):
        try:return self.page.evaluate(LIST_JS)
        except Exception:return None
    def page_rows(self):
        d=self.wait(lambda:self.read_page(),'지그재그 목록 표를 읽지 못했습니다.')
        missing=[v for v in COLUMNS.values() if v not in d['heads']]
        if missing:raise ZigzagError('지그재그 목록 열 이름이 달라졌습니다: '+', '.join(missing))
        rows=[]
        for r in d['rows']:
            item={k:r.get(v,'') for k,v in COLUMNS.items()}
            if not re.fullmatch(r'\d{6,30}',item['itemId']):continue
            item['shipByDate']=iso_day(item['shipBy']);item['changedDate']=iso_day(item['changedShipBy'])
            item['currentDate']=item['changedDate'] or item['shipByDate']
            item['qty']=int(re.sub(r'\D','',item['qty']) or 0)
            rows.append(item)
        return d,rows
    def current_page(self):
        try:return int(self.page.evaluate("()=>{const b=[...document.querySelectorAll('button[aria-label$=\" 페이지\"]')].find(b=>b.getAttribute('aria-current')||/current|active|selected/i.test(b.className)||b.closest('li')?.className.includes('r7d4ay'));return b?parseInt(b.getAttribute('aria-label')):1;}"))
        except Exception:return 1
    def goto_page(self,number):
        if self.current_page()==number:return
        button=self.page.locator(f'button[aria-label="{number} 페이지"]')
        if not button.count():raise ZigzagError(f'{number}페이지 버튼을 찾지 못했습니다.')
        before=self.read_page()
        button.first.click(timeout=10000)
        self.wait(lambda:(self.read_page() or {}).get('rows')!=(before or {}).get('rows'),'페이지 이동을 확인하지 못했습니다.')
        self.page.wait_for_timeout(400)
    def collect(self,shop):
        """Every row of 배송준비중 (전체 기간). Returns (rows,total,pages,page_of)."""
        self.shop=shop;self.open_list(shop)
        d=self.wait(self.list_settled,'지그재그 배송준비중 목록을 읽지 못했습니다.',30);_,rows=self.page_rows();total=d['total'];pages=max(1,d['pages']);all_rows=[];page_of={};seen=set()
        for number in range(1,pages+1):
            if number>1:self.goto_page(number)
            self.progress(f'지그재그 목록 {number}/{pages}페이지 읽는 중')
            d,rows=self.page_rows()
            for r in rows:
                if r['itemId'] in seen:raise ZigzagError('페이지 사이에 중복 상품주문번호가 있습니다. 다시 실행하세요.')
                seen.add(r['itemId']);page_of[r['itemId']]=number;all_rows.append(r)
        if total is not None and len(all_rows)!=total:
            # Late re-render: re-read the title once more before giving up.
            self.page.wait_for_timeout(2000);again=self.read_page();total=again['total'] if again and again['total'] is not None else total
            if len(all_rows)!=total:raise ZigzagError(f'목록 건수({total})와 읽은 행({len(all_rows)})이 다릅니다. 다시 실행하세요.')
        return all_rows,total,pages,page_of
    # ---- 배송연기 안내 ----
    def modal(self):
        """The 배송연기 안내 form dialog (the partner center may stack a second dialog on top, e.g. a completion notice)."""
        return self.page.locator('.pds-modal-wrapper').filter(has_text='변경 발송 예정일')
    def form_open(self):
        try:return self.modal().count()>0
        except Exception:return False
    def dismiss_notice(self):
        """Close any other dialog (completion/notice) with its 확인/닫기 button; never the form itself."""
        try:
            others=self.page.locator('.pds-modal-wrapper').filter(has_not_text='변경 발송 예정일')
            for i in range(min(others.count(),3)):
                btn=others.nth(i).locator('button').filter(has_text=re.compile(r'^\s*(확인|닫기)\s*$'))
                if btn.count():btn.first.click(timeout=3000);self.page.wait_for_timeout(300)
        except Exception:pass
    def set_checked(self,item_id,on):
        row=self.page.locator('tbody tr').filter(has=self.page.locator('td').filter(has_text=re.compile(r'^\s*'+re.escape(item_id)+r'\s*$')))
        if row.count()!=1:raise ZigzagError(f'상품주문번호 {item_id} 행을 하나로 찾지 못했습니다.')
        box=row.first.locator('input[type=checkbox]')
        if box.count()!=1:raise ZigzagError(f'상품주문번호 {item_id} 행의 선택 상자를 찾지 못했습니다.')
        if box.is_checked()!=on:
            try:row.first.scroll_into_view_if_needed(timeout=3000)
            except Exception:pass
            # The partner center styles its checkboxes (the input itself may be hidden behind a label):
            # a normal click can time out, so fall back to a DOM click, then verify the state either way.
            if box.is_visible():
                try:box.click(timeout=3000)
                except Exception:box.evaluate('e=>e.click()')
            else:box.evaluate('e=>e.click()')
        self.wait(lambda:box.is_checked()==on,'행 선택을 확인하지 못했습니다.',10)
    def clear_checks(self):
        self.page.evaluate("()=>{const h=document.querySelector('thead input[type=checkbox]');if(h&&h.checked)h.click();document.querySelectorAll('tbody input[type=checkbox]:checked').forEach(b=>b.click());}")
        self.wait(lambda:self.page.locator('tbody input[type=checkbox]:checked').count()==0,'기존 선택을 해제하지 못했습니다.',10)
    def calendar_month(self):
        """(year,month) the open react-day-picker shows, read from any 'YYYY년 M월' text inside it."""
        try:
            m=self.page.evaluate("()=>{const r=document.querySelector('.rdp-month, .rdp');if(!r)return null;const t=(r.innerText||'').match(/(\\d{4})\\s*년\\s*(\\d{1,2})\\s*월/);return t?[Number(t[1]),Number(t[2])]:null;}")
            return tuple(m) if m else None
        except Exception:return None
    def open_calendar(self,field):
        """Single click opens the picker; if it does not, try a double click, then typing the date."""
        for attempt in range(2):
            try:
                (field.first.click if attempt==0 else field.first.dblclick)(timeout=5000)
            except Exception:pass
            try:self.wait(lambda:self.page.locator('button.rdp-day').count()>0,'',4);return True
            except ZigzagError:continue
        return False
    def pick_date(self,modal,iso):
        y,m,d=iso.split('-');dotted=f'{y}.{m}.{d}'
        field=modal.locator('input.pds-input[placeholder*="날짜"]')
        if field.count()!=1:raise ZigzagError('변경 발송 예정일 입력칸을 찾지 못했습니다.')
        if not self.open_calendar(field):
            # Fallback: type the date and confirm it stuck (React input).
            field.first.fill(dotted);field.first.press('Enter');self.page.wait_for_timeout(400)
            if field.first.input_value().strip()!=dotted:raise ZigzagError('달력이 열리지 않아 변경 발송 예정일을 선택하지 못했습니다.')
            return
        # Move the calendar to the wanted month.
        for _ in range(4):
            cur=self.calendar_month()
            if cur is None or cur==(int(y),int(m)):break
            nav=self.page.locator('.rdp-month button, .rdp-nav button, .rdp-caption button').all()
            label=lambda b:(b.get_attribute('aria-label') or b.get_attribute('name') or b.get_attribute('class') or '')
            nxt=[b for b in nav if re.search('next|다음',label(b),re.I) and not re.search('year|연도|년',label(b),re.I)]
            if not nxt:raise ZigzagError('달력에서 다음 달로 이동하지 못했습니다.')
            nxt[-1].click(timeout=5000);self.page.wait_for_timeout(300)
        day=self.page.locator('button.rdp-day:not(.rdp-day_outside)').filter(has_text=re.compile(r'^\s*'+str(int(d))+r'\s*$'))
        if day.count()!=1:raise ZigzagError(f'달력에서 {dotted} 날짜 칸을 하나로 찾지 못했습니다.')
        if 'rdp-day_disabled' in (day.first.get_attribute('class') or ''):raise ZigzagError(f'{dotted}은 지그재그에서 선택할 수 없는 날짜입니다 (발송 예정일 이후 7영업일, 주말·휴일 제외).')
        day.first.click(timeout=10000)
        self.wait(lambda:field.first.input_value().strip()==dotted,'변경 발송 예정일이 선택되지 않았습니다.',10)
    def send_one(self,target):
        """One 배송연기 안내. Returns the push record; never clicks 배송연기 안내 twice."""
        item_id=target['itemId'];iso=target['sendDate'];self.clicked=False
        self.step='발송 대상 행 선택';self.clear_checks();self.set_checked(item_id,True)
        self.step='배송연기 안내 창 열기'
        button=self.page.locator('button:not([role="tab"])').filter(has_text=re.compile(r'^\s*배송연기 안내\s*$'))
        if button.count()!=1:raise ZigzagError('배송연기 안내 버튼을 하나로 찾지 못했습니다.')
        # 2026-10-23 실측: 발송 예정일이 지난 주문(또는 이미 1회 안내한 주문)을 고르면 버튼이 꺼져 있어 클릭이 10초 뒤 막혔다.
        try:off=button.first.is_disabled()
        except Exception:off=False
        if off:raise ZigzagError('지그재그에서 배송연기 안내 버튼이 꺼져 있습니다 (발송 예정일이 지났거나 이미 1회 안내한 주문). 고객 안내 문자 작성으로 안내하세요.')
        button.first.click(timeout=10000)
        modal=self.wait(lambda:self.modal().first if self.form_open() else None,'배송연기 안내 창이 열리지 않았습니다.',15)
        self.step='배송연기 사유 선택'
        combo=modal.locator('[role="combobox"]')
        if combo.count()!=1:raise ZigzagError('배송연기 사유 선택란을 찾지 못했습니다.')
        combo.first.click(timeout=10000)
        option=self.page.locator('li[role="option"]').filter(has_text=re.compile(r'^\s*'+re.escape(REASON)+r'\s*$'))
        self.wait(lambda:option.count()==1,'배송연기 사유 목록이 열리지 않았습니다.',10)
        option.first.click(timeout=10000)
        self.wait(lambda:REASON in combo.first.inner_text(),'배송연기 사유가 선택되지 않았습니다.',10)
        self.step='상세사유 입력'
        ta=modal.locator('textarea')
        if ta.count()!=1:raise ZigzagError('상세사유 입력칸을 찾지 못했습니다.')
        ta.first.fill(DETAIL)
        if ta.first.input_value()!=DETAIL:raise ZigzagError('상세사유 입력값을 확인하지 못했습니다.')
        self.step='변경 발송 예정일 선택';self.pick_date(modal,iso)
        try:modal.get_by_text('상세사유',exact=True).first.click(timeout=3000)  # closes the calendar popup without touching the form
        except Exception:pass
        self.step='배송연기 안내 전송'
        submit=modal.locator('button').filter(has_text=re.compile(r'^\s*배송연기 안내\s*$'))
        if submit.count()!=1:raise ZigzagError('전송 버튼을 하나로 찾지 못했습니다.')
        self.wait(lambda:not submit.first.is_disabled(),'전송 버튼이 활성화되지 않았습니다. 입력값을 확인하세요.',10)
        field=modal.locator('input.pds-input[placeholder*="날짜"]').first.input_value().strip()
        if field!=iso.replace('-','.'):raise ZigzagError('전송 직전 변경 발송 예정일이 다릅니다.')
        self.check();self.clicked=True
        submit.first.click(timeout=10000)
        self.wait(lambda:not self.form_open(),'배송연기 안내 창이 닫히지 않았습니다.',30)
        self.page.wait_for_timeout(800);self.dismiss_notice()
        # 20:38 보고: 전송은 됐는데 목록이 아직 다시 그려지기 전에 읽어 '변경 발송 예정일이 공란' 실패로 기록됨 → 반영될 때까지
        # 최대 15초 다시 읽는다. 끝까지 공란이면 (창이 정상 종료됐으므로) 전송으로 보고 확인 메모만 남긴다; 다른 날짜가 보이면 실패.
        got='';end=time.monotonic()+15
        while True:
            try:
                _,rows=self.page_rows();got=next((r['changedDate'] for r in rows if r['itemId']==item_id),'')
            except Exception:got=''
            if got or time.monotonic()>=end:break
            self.page.wait_for_timeout(1000);self.dismiss_notice()
        if got==iso:return {**target,'status':'sent','platformNotice':got,'reason':''}
        if got:return {**target,'status':'failed','platformNotice':got,'reason':f'전송 후 변경 발송 예정일이 {got}입니다(요청 {iso}). 지그재그에서 확인하세요.'}
        return {**target,'status':'sent','platformNotice':iso,'reason':'전송 창은 정상 종료됐으나 목록에 변경 발송 예정일 반영을 15초 안에 확인하지 못했습니다. 지그재그 목록에서 한 번 확인하세요.'}
    def recover(self):
        """Leave the list ready for the next order: cancel our open form (never its submit), close notices, clear
        checks. If a dialog still blocks the page, reopen the list. Returns False when the page could not be restored."""
        try:
            if self.form_open():
                cancel=self.modal().first.locator('button').filter(has_text=re.compile(r'^\s*취소\s*$'))
                if cancel.count():cancel.first.click(timeout=5000);self.page.wait_for_timeout(400)
            self.dismiss_notice()
            if self.page.locator('.pds-modal-wrapper').count():
                try:self.page.keyboard.press('Escape');self.page.wait_for_timeout(300)
                except Exception:pass
            if not self.page.locator('.pds-modal-wrapper').count():
                self.clear_checks();return True
        except Exception:pass
        if not self.shop:return False
        try:
            self.progress('지그재그 목록을 다시 엽니다 (앞 주문 화면 정리)');self.open_list(self.shop);self.clear_checks();return True
        except Exception:return False
    def find_page(self,item_id,hint):
        """The list page that shows `item_id` now (the hinted page first, then every page)."""
        if hint:
            self.goto_page(hint)
            if any(r['itemId']==item_id for r in self.page_rows()[1]):return hint
        d=self.read_page() or {};pages=max(1,d.get('pages') or 1)
        for number in range(1,pages+1):
            if number==hint:continue
            self.goto_page(number)
            if any(r['itemId']==item_id for r in self.page_rows()[1]):return number
        return None
    def push(self,targets,page_of):
        """2026-10-23 요청: 막히는 주문은 보류로 남기고 나머지는 전부 안내한다. 한 주문의 오류가 다음 주문을 막지 않는다.
        전송 버튼을 누른 뒤의 오류도 그 주문만 '실패'로 기록하고(다시 누르지 않음) 화면을 정리한 뒤 다음 주문으로 간다."""
        results=[]
        try:
            for n,t in enumerate(targets,1):
                self.check();self.progress(f'지그재그 배송연기 안내 {n}/{len(targets)} · 상품주문번호 {t["itemId"]}')
                hint=page_of.get(t['itemId']);self.clicked=False;self.step='목록에서 주문 찾기'
                try:
                    number=self.find_page(t['itemId'],hint) if hint else None
                    if not number:results.append({**t,'status':'skipped','platformNotice':'','reason':'배송준비중 목록에서 상품주문번호를 찾지 못했습니다.'});continue
                    results.append(self.send_one(t))
                except ZigzagCancelled:raise
                except Exception as exc:
                    msg=str(exc) if isinstance(exc,ZigzagError) else f'{self.step} 단계 오류 · {type(exc).__name__}: {str(exc).splitlines()[0][:160] if str(exc) else ""}'
                    if not self.clicked:
                        results.append({**t,'status':'skipped','platformNotice':'','reason':msg})
                    else:
                        # Send was clicked and something went wrong afterwards: judge by what the list shows now, never retry.
                        got=''
                        try:
                            self.dismiss_notice();self.page.wait_for_timeout(800);_,rows=self.page_rows();got=next((r['changedDate'] for r in rows if r['itemId']==t['itemId']),'')
                        except Exception:pass
                        if got==t['sendDate']:results.append({**t,'status':'sent','platformNotice':got,'reason':''})
                        else:results.append({**t,'status':'failed','platformNotice':got,'reason':msg+(f' · 목록의 변경 발송 예정일: {got}' if got else '')+' · 다시 보내지 않았습니다. 지그재그에서 확인하세요.'})
                    if not self.recover():
                        rest=[x for x in targets if x['itemId'] not in {r['itemId'] for r in results}]
                        results.extend({**x,'status':'skipped','platformNotice':'','reason':'앞 주문 뒤 지그재그 화면을 정리하지 못해 멈춤 · 다시 실행하세요'} for x in rest)
                        return results
                    continue
        except ZigzagCancelled as exc:
            if any(r['status']=='sent' for r in results):
                rest=[x for x in targets if x['itemId'] not in {r['itemId'] for r in results}]
                results.extend({**x,'status':'skipped','platformNotice':'','reason':'사용자 중단'} for x in rest)
                raise ZigzagPushAborted('지그재그 작업을 중단했습니다. 이미 보낸 배송연기 안내는 기록합니다.',results) from exc
            raise
        return results

def run(account,stop,progress,planner=None,push_only=False):
    """Open Chrome, log in, read the list; with a planner also send the planned 배송연기 안내."""
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        import browser_window as _bw;browser=pw.chromium.launch(**_bw.launch_kwargs())
        context=browser.new_context(viewport={'width':1360,'height':900},device_scale_factor=1,accept_downloads=False)
        _bw.attach(context)
        reader=None
        def register(page):
            # Native dialogs: accept only a confirmation raised by our own submit click; dismiss anything else.
            def on_dialog(dialog):
                if reader is not None and reader.clicked and dialog.type=='confirm' and not re.search('삭제|취소',dialog.message or ''):dialog.accept()
                else:dialog.dismiss()
            page.on('dialog',on_dialog)
        context.on('page',register);page=context.new_page();register(page);reader=Reader(page,stop,progress,context)
        try:
            reader.login(account)
            rows,total,pages,page_of=reader.collect(account['shop'])
            pushes=[]
            if planner is not None:
                targets,skipped=planner(rows);pushes=list(skipped)
                if targets:pushes.extend(reader.push(targets,page_of))
            return {'rows':rows,'total':total,'pages':pages,'pushes':pushes,'pushOnly':bool(push_only),'complete':True}
        finally:context.close();browser.close()
