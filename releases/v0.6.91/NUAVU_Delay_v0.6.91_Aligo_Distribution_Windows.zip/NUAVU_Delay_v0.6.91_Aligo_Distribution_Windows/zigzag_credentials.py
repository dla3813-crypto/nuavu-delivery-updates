"""Zigzag(카카오스타일 파트너센터)-only macOS Keychain item. No plaintext fallback or secret UI return."""
from __future__ import annotations
import hashlib
import json
import re
import sys
from credentials import MacKeychain, UnavailableVault, VaultError

SERVICE='kr.nuavu.deliverynotice.zigzag'

class ZigzagKeychain(MacKeychain):
    def _query(self):
        q=super()._query();q[self._api().kSecAttrService]=SERVICE;return q

    def save(self, payload):
        s=self._api()
        raw=json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode('utf-8')
        if len(raw)>16384:raise VaultError('지그재그 계정 정보가 너무 큽니다.')
        query=self._query()
        try:
            status=s.SecItemUpdate(query,{s.kSecValueData:raw})
            if status==s.errSecItemNotFound:
                add={**query,s.kSecValueData:raw,s.kSecAttrLabel:'누아브 지그재그 로그인'}
                status,_=s.SecItemAdd(add,None)
                if status==s.errSecDuplicateItem:status=s.SecItemUpdate(query,{s.kSecValueData:raw})
            self._check(status)
        except Exception:
            raise VaultError('지그재그 계정을 키체인에 저장하지 못했습니다. 키체인 접근을 허용한 뒤 다시 저장하세요. 평문으로 대신 저장하지 않습니다.') from None

    def load(self):
        try:return super().load()
        except Exception:
            raise VaultError('지그재그 계정을 키체인에서 읽지 못했습니다. 키체인 접근을 허용하고 지그재그 설정을 다시 여세요.') from None

def payload(username,password,shop='nuavu'):
    if not isinstance(username,str) or not username.strip() or len(username)>200 or any(ord(c)<32 for c in username):raise VaultError('지그재그 아이디를 확인하세요.')
    if not isinstance(password,str) or not password or len(password)>4096 or any(ord(c)<32 for c in password):raise VaultError('지그재그 비밀번호를 입력하세요.')
    shop=str(shop or '').strip().lower()
    if not re.fullmatch(r'[a-z0-9_-]{1,60}',shop):raise VaultError('지그재그 스토어 주소 이름(예: nuavu)을 확인하세요.')
    return {'version':1,'username':username.strip(),'password':password,'shop':shop}

class ZigzagAccounts:
    def __init__(self,directory,vault=None):self.vault=vault if vault is not None else __import__('windows_credentials').platform_vault(directory,SERVICE,'배송안내 배포판 지그재그 로그인',ZigzagKeychain)
    def load(self):
        try:
            saved=self.vault.load()
            if saved is None:return None
            if saved.get('version')!=1:raise ValueError()
            return payload(saved.get('username'),saved.get('password'),saved.get('shop','nuavu'))
        except Exception:raise VaultError('지그재그 키체인을 읽지 못했습니다. 설정에서 계정을 다시 저장하세요.') from None
    def info(self):
        saved=self.load()
        return {'username':saved['username'] if saved else '','shop':saved['shop'] if saved else 'nuavu','hasPassword':bool(saved),'available':bool(self.vault.available),'storage':'macOS 키체인'}
    def save(self,username,password,shop='nuavu'):
        if password=='':
            old=self.load()
            if not old or old['username']!=str(username).strip():raise VaultError('새 계정의 비밀번호를 입력하세요.')
            password=old['password']
        account=payload(username,password,shop)
        try:self.vault.save(account)
        except Exception:raise VaultError('지그재그 계정을 키체인에 저장하지 못했습니다. 접근 권한을 확인하세요.') from None
        return {**self.info(),'message':'지그재그 로그인 정보를 키체인에 저장했습니다.'}
    def for_login(self):
        account=self.load()
        if not account:raise VaultError('⚙ 설정 › 로그인의 지그재그 설정에서 아이디와 비밀번호를 먼저 저장하세요.')
        return account
