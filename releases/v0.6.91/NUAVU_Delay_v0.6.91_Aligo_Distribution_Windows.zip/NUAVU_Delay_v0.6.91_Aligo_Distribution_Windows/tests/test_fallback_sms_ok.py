"""2026-10-21: 알림톡 실패 → 알리고 문자 대체 접수/수신이면 정상 안내로 보고, 이력에 남긴다."""
import json,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
try:
    from test_v056 import Base
except ImportError:
    from helpers import Base
from domain import now,display_status

class FallbackSmsTests(Base):
    def make(self,child_status):
        r=self.row();t=now()
        raw=json.dumps({"msgid":"53613076","status":"3","rslt":"8","rslt_message":"메시지를 전송할 수 없는 상태","rsltdate":"2026-10-20 09:01:28","smid":"0"},ensure_ascii=False)
        base=dict(isTest=False,seller=r['seller'],orderId=r['orderId'],itemKeys=[r['key']],dueDate='2099-01-02',noticeType='delay',templateKey='first',
                  createdAt=t,updatedAt=t,logicalCreatedAt=t,phone='01000000000',content='x',products=[],events=[])
        with self.store.edit() as s:
            s['notices'].append(dict(base,id='AT1',kind='AT',status='FAILED',rawResult=raw,fallbackId='LMS1',fallbackDecision='ENQUEUED',aligoFailureConfirmed=True))
            s['notices'].append(dict(base,id='LMS1',kind='LMS',status=child_status,fallbackOf='AT1',logicalId='AT1'))
            s.setdefault('alerts',[]).append({'id':'A1','noticeId':'AT1','code':'DELIVERY_FAILED','level':'error','message':'x','at':t,'acknowledgedAt':None})
        return r['key']
    def test_fallback_pending_counts_as_normal_and_logs(self):
        key=self.make('PENDING')
        self.assertEqual(self.engine.sweep_fallback_sms(),1)
        n=next(x for x in self.store.read()['notices'] if x['id']=='AT1')
        self.assertTrue(n['fallbackSmsOk']);self.assertEqual(display_status(n),'FALLBACK_SMS')
        self.assertIn('알림톡 불가(메시지를 전송할 수 없는 상태)로 문자(알리고 LMS)로 안내됨',n['events'][-1]['note'])
        row=next(r for r in self.engine.public_state()['rows'] if r['key']==key)
        self.assertNotEqual(row['bucket'],'failed');self.assertEqual(row['dueDate'],'2099-01-02')
        self.assertTrue(next(a for a in self.store.read()['alerts'] if a['id']=='A1').get('resolvedAt'))
        self.assertEqual(self.engine.sweep_fallback_sms(),0)  # once only
    def test_fallback_failed_stays_failed(self):
        self.make('FAILED')
        self.assertEqual(self.engine.sweep_fallback_sms(),0)
        n=next(x for x in self.store.read()['notices'] if x['id']=='AT1');self.assertFalse(n.get('fallbackSmsOk'))
    def test_ui_label(self):
        js=(ROOT/'web'/'app.js').read_text(encoding='utf-8')
        self.assertIn("FALLBACK_SMS:'알림톡 불가 → 문자 안내'",js);self.assertIn("n.status==='FAILED'&&!n.fallbackSmsOk",js)

if __name__=='__main__':unittest.main()
