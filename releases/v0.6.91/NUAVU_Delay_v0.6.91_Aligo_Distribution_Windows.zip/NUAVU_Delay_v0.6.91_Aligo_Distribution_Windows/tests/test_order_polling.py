import unittest
from datetime import datetime,timedelta
from unittest.mock import MagicMock,patch
import order_browser
from order_browser import Flow
from order_auto import KST,OrderAutoError,Cancelled

class DownloadPollingTests(unittest.TestCase):
    def setUp(self):
        self.start=datetime(2026,10,17,21,42,5,tzinfo=KST)
        self.end=self.start+timedelta(seconds=3)
        self.row={'id':'777','at':'2026-10-17 21:42:07','template':'확장주문검색2',
                  'name':'확장주문검색_20261017214209_987.xls','status':'완료','percent':'',
                  'href':'https://ga90.ezadmin.co.kr/data/test/file.xls'}
        self.clock=0;self.pauses=[];self.c=MagicMock();self.manager=MagicMock()
        self.flow=Flow(self.c,MagicMock());self.flow.known_page=MagicMock()
        def pause(n):self.pauses.append(n);self.clock+=n;self.c.check()
        self.flow.pause=pause
        self.monotonic=patch.object(order_browser.time,'monotonic',lambda:self.clock)
        self.monotonic.start();self.addCleanup(self.monotonic.stop)
    def run_rows(self,rows):
        self.flow.jobs=MagicMock(side_effect=rows)
        return self.flow.wait_download_job(self.manager,self.start,self.end)
    def test_completed_without_progress_downloads_initial_result(self):
        self.assertEqual(self.run_rows([[self.row]]),self.row)
        self.assertEqual(self.pauses,[]);self.manager.reload.assert_not_called()
        self.manager.locator.assert_not_called()
    def test_completed_with_stale_percent_is_complete(self):
        self.assertEqual(self.run_rows([[dict(self.row,percent='50%')]])['status'],'완료')
        self.assertEqual(self.pauses,[])
    def test_pending_even_100_percent_waits_five_seconds(self):
        self.run_rows([[dict(self.row,status='진행중',percent='100%')],[self.row]])
        self.assertEqual(self.pauses,[5]);self.manager.locator.assert_called_with('#search')
        self.manager.reload.assert_not_called()
        self.assertIn(self.row['at'],self.c.update.call_args.args[1])
    def test_absent_then_pending_then_completed(self):
        self.run_rows([[],[dict(self.row,status='대기')],[self.row]])
        self.assertEqual(self.pauses,[5,5])
    def test_older_completed_row_is_not_a_fallback(self):
        old=dict(self.row,id='old',at='2026-10-17 21:42:04')
        self.run_rows([[old],[old,self.row]])
        self.assertEqual(self.pauses,[5])
    def test_same_request_id_is_required_after_refresh(self):
        with self.assertRaisesRegex(OrderAutoError,'작업 번호'):
            self.run_rows([[dict(self.row,status='작업중')],[dict(self.row,id='778')]])
    def test_same_request_time_is_required_after_refresh(self):
        with self.assertRaisesRegex(OrderAutoError,'요청시간'):
            self.run_rows([[dict(self.row,status='작업중')],[dict(self.row,at='2026-10-17 21:42:08')]])
    def test_multiple_requests_in_window_stop(self):
        with self.assertRaisesRegex(OrderAutoError,'여러 개'):
            self.run_rows([[self.row,dict(self.row,id='778')]])
        self.assertEqual(self.pauses,[])
    def test_failure_error_cancel_stop_without_refresh(self):
        for status in ['실패','오류','취소']:
            with self.subTest(status=status),self.assertRaisesRegex(OrderAutoError,'실패하거나 취소'):
                self.run_rows([[dict(self.row,status=status)]])
        self.assertEqual(self.pauses,[])
    def test_cancel_during_wait_does_not_refresh(self):
        def cancel(_):raise Cancelled('stopped')
        self.flow.pause=cancel
        with self.assertRaises(Cancelled):self.run_rows([[dict(self.row,status='대기')]])
        self.manager.locator.assert_not_called()
    def test_pending_timeout_is_not_success(self):
        with patch.object(order_browser,'JOB_WAIT_SECONDS',10):
            with self.assertRaisesRegex(OrderAutoError,'완료를 10분'):
                self.run_rows([[dict(self.row,status='대기')]]*4)
        self.assertEqual(self.pauses,[5,5])
    def test_missing_request_timeout_reports_time_without_selecting_old(self):
        with patch.object(order_browser,'JOB_WAIT_SECONDS',5):
            with self.assertRaisesRegex(OrderAutoError,'21:42:05~21:42:08'):
                self.run_rows([[],[]])
    def test_incomplete_without_name_can_be_tracked(self):
        self.run_rows([[dict(self.row,status='대기',name='',href='')],[self.row]])
        self.assertEqual(self.pauses,[5])
    def test_manager_waits_for_loader_even_when_rows_exist(self):
        loader=MagicMock();loader.is_visible.side_effect=[True,False]
        rows=MagicMock();rows.count.return_value=1;rows.evaluate_all.return_value=[self.row]
        self.manager.locator.side_effect=lambda sel:loader if sel=='#load_grid1' else rows
        observed=[]
        def until(predicate,*_):
            observed.append(bool(predicate()));observed.append(bool(predicate()))
            self.assertEqual(observed,[False,True])
        self.flow.until=until
        self.assertEqual(self.flow.jobs(self.manager),[self.row])
    def test_empty_finished_list_can_be_polled_again(self):
        loader=MagicMock();loader.is_visible.return_value=False
        rows=MagicMock();rows.count.return_value=0;rows.evaluate_all.return_value=[]
        pager=MagicMock();pager.inner_text.return_value='표시할 행이 없습니다'
        self.manager.locator.side_effect=lambda sel:{'#load_grid1':loader,'#grid1 tr.jqgrow':rows,'#gridpager':pager}[sel]
        self.flow.until=lambda predicate,*_:self.assertTrue(predicate())
        self.assertEqual(self.flow.jobs(self.manager),[])
