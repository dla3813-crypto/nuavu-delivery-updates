'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),D=require('../web/dispatch_view.js');
const row=(key,extra={})=>({key,orderId:'ORDER-'+key,seller:'가상 에이블리',active:true,bucket:'unnotified',delayNoticeCount:0,qty:1,...extra});
const groups=rows=>D.orderList.noticeGroups(rows,D.unconfirmed,r=>D.delayRisk?D.delayRisk(r,'confirmed'):r.delayRiskStage==='confirmed');
test('unknown partition is complete and disjoint',()=>{
 const rows=[row('a',{delayNoticeCount:2}),row('b'),row('c',{noticeCount:3})],g=groups(rows);
 assert.deepEqual(g.notice_undated_seen,[rows[0]]);assert.deepEqual(g.notice_undated_new,[rows[1],rows[2]]);
 assert.deepEqual(new Set([...g.notice_undated_seen,...g.notice_undated_new]),new Set(g.notice_undated));
});
test('overdue order siblings excluded from both new subfilters',()=>{
 const rows=[row('a',{orderId:'one',bucket:'overdue'}),row('b',{orderId:'one',delayNoticeCount:1}),row('c',{orderId:'one'})],g=groups(rows);
 assert.deepEqual(g.notice_resend,[rows[0]]);assert.equal(g.notice_undated_seen.length+g.notice_undated_new.length,0);
});
test('confirmed risk priority unchanged before search',()=>{
 const rows=[row('a',{orderId:'one',delayRiskStage:'confirmed',delayRisk:{stage:'confirmed',shortQty:1}}),row('b',{orderId:'one',delayNoticeCount:1})];
 assert.equal(groups(rows).notice_undated_seen.length,0);
});
test('inactive, exchange, dated arrival and secured remain excluded',()=>{
 const rows=[row('a',{active:false,delayNoticeCount:1}),row('b',{orderId:'C123',delayNoticeCount:1}),row('c',{progressOfficeDates:['2026-10-18'],delayNoticeCount:1}),row('d',{stockSecured:true})],g=groups(rows);
 assert.equal(g.notice_undated_seen.length+g.notice_undated_new.length,0);
});
test('only product with history goes in history subset even in shared order',()=>{
 const rows=[row('a',{orderId:'one',delayNoticeCount:1}),row('b',{orderId:'one'})],g=groups(rows);
 assert.deepEqual(g.notice_undated_seen,[rows[0]]);assert.deepEqual(g.notice_undated_new,[rows[1]]);
});
test('newly acknowledged product moves between filters on refresh',()=>{
 const a=row('a');assert.deepEqual(groups([a]).notice_undated_new,[a]);const updated={...a,delayNoticeCount:1};assert.deepEqual(groups([updated]).notice_undated_seen,[updated]);assert.equal(groups([updated]).notice_undated_new.length,0);
});
test('summary partitions add up without double counting',()=>{
 const rows=[row('a',{delayNoticeCount:1}),row('b'),row('c',{bucket:'overdue'})],v=D.dashboard.summary(rows,D,()=>true,groups(rows));
 assert.equal(v.unknownSeen,1);assert.equal(v.unknownNew,1);assert.equal(v.unknown,v.unknownSeen+v.unknownNew);assert.equal(v.resend,1);
});
test('splitting leaves source rows, history counts, and quantity untouched',()=>{
 const rows=[row('a',{delayNoticeCount:1}),row('b')],before=JSON.stringify(rows);groups(rows);assert.equal(JSON.stringify(rows),before);
});
