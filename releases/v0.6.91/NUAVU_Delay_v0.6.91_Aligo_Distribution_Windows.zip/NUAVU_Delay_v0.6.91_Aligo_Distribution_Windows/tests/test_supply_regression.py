"""v0.6.8 offline-only tests. Synthetic OOXML, temporary DB and fake providers.
No live account, SMS, Alimtalk, real stock or macOS state is touched.
"""
import base64,copy,io,json,tempfile,unittest,zipfile
from pathlib import Path
from datetime import date,datetime,timedelta
from xml.sax.saxutils import escape
from unittest.mock import patch
from domain import Engine,Store,SELLERS,FIRST,KST,notice_sort_key,applied_notice
from external_notices import ably_entries,ExternalError
from supply_workflow import (SupplyError,read_supplier,variant_id,catalogue,candidates,
    product_name,option_parts,order_signature,order_priority,allocation_view)
from supply_calendar import china_departure,route,business
from workbook_reader import read_xlsx,as_date,integer,WorkbookError
from helpers import Base,Clock

# Minimal test protocol fixtures, not exported customer spreadsheets.
def xlsx(sheets):
    out=io.BytesIO();ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('xl/workbook.xml',f'<workbook xmlns="{ns}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'+''.join(f'<sheet name="{escape(name)}" sheetId="{i}" r:id="rId{i}"/>' for i,(name,_) in enumerate(sheets,1))+'</sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+''.join(f'<Relationship Id="rId{i}" Target="worksheets/sheet{i}.xml"/>' for i in range(1,len(sheets)+1))+'</Relationships>')
        for i,(_,rows) in enumerate(sheets,1):
            body=[]
            for rn,row in enumerate(rows,1):
                cells=[]
                for cn,value in enumerate(row,1):
                    if value is None:continue
                    n=cn;col=''
                    while n:n,r=divmod(n-1,26);col=chr(65+r)+col
                    ref=f'{col}{rn}'
                    if isinstance(value,(int,float)):cells.append(f'<c r="{ref}"><v>{value}</v></c>')
                    else:cells.append(f'<c r="{ref}" t="inlineStr"><is><t>{escape(str(value))}</t></is></c>')
                body.append(f'<row r="{rn}">'+''.join(cells)+'</row>')
            z.writestr(f'xl/worksheets/sheet{i}.xml',f'<worksheet xmlns="{ns}"><sheetData>'+''.join(body)+'</sheetData></worksheet>')
    return out.getvalue()

def source_row(product='가디건',color='아이보리',size='F',qty=1,brand='N',office=None,purchase=None):
    r=[None]*22;r[4:10]=[brand,product,color,size,'image',qty];r[11]=purchase;r[21]=office;return r

def ably_file(rows,include_instructions=True):
    header=['주문번호','상품명','옵션 정보','수량','판매채널','상품주문번호']
    sheets=[('엑셀 일괄 발송 처리 유의사항',[header,['SAMPLE','샘플','블랙/FREE',1,'에이블리','EXAMPLE']])] if include_instructions else []
    sheets.append(('20261016_에이블리_발송 관리',[header]+[[r['orderId'],r['product'],r['option'],r['qty'],r['seller'].replace('누아브 ',''),r.get('orderItemId') or f'ITEM-{i}'] for i,r in enumerate(rows)]))
    return xlsx(sheets)

def order(i,product='가디건',option='아이보리 / FREE',qty=1,day='2026-10-13'):
    return dict(seller='누아브 에이블리',orderId=f'TEST-{i:03}',product=product,option=option,qty=qty,orderDate=day,buyer='가상 고객',recipient='',phone='01000000000',needsPhoneApproval=False)

class ReaderTests(unittest.TestCase):
    def test_read_basic(self):self.assertEqual(read_xlsx(xlsx([('가상',[[1,'a',None],[None,'b']])]))[0]['rows'],[[1,'a'],[None,'b']])
    def test_malformed_zip(self):
        with self.assertRaises(WorkbookError):read_xlsx(b'not-zip')
    def test_bad_xml(self):
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w') as z:z.writestr('xl/workbook.xml','<!DOCTYPE x [<!ENTITY y "bad">]><x/>')
        with self.assertRaises(WorkbookError):read_xlsx(b.getvalue())
    def test_empty_value(self):self.assertIsNone(as_date('',2026))
    def test_excel_date(self):self.assertEqual(as_date(46311,2026),date(2026,10,16))
    def test_1904_epoch(self):self.assertEqual(as_date(1,2026,True),date(1904,1,2))
    def test_korean_mmdd(self):self.assertEqual(as_date('10월 17일',2026),date(2026,10,17))
    def test_iso_date(self):self.assertEqual(as_date('2026-10-17 15:30',2026),date(2026,10,17))
    def test_bad_date(self):
        for d in ['2026-02-30','아직 미도착','-',True,float('nan'),-10]:self.assertIsNone(as_date(d,2026))
    def test_integer_only(self):
        for v in [1.5,True,-1,'준비중',None,'#EXCEL_ERROR']:self.assertIsNone(integer(v))
        self.assertEqual(integer('1,234'),1234);self.assertEqual(integer(0),0)
    def test_ably_skips_instruction_example(self):
        entries=ably_entries(ably_file([order(1)]));self.assertEqual(len(entries),1);self.assertEqual(entries[0]['orderId'],'TEST-001')
    def test_ably_does_not_read_U_as_date(self):self.assertNotIn('dueDate',ably_entries(ably_file([order(1)]))[0])
    def test_ably_no_header(self):
        with self.assertRaises(ExternalError):ably_entries(xlsx([('main',[[1,2,3]])]))
    def test_bad_supplier_structure(self):
        with self.assertRaises(SupplyError):read_supplier('진행상황.xlsx',xlsx([('main',[[1,2]])]),2026,'progress')
    def test_V_precedes_L(self):
        b=read_supplier('진행상황.xlsx',xlsx([('main',[source_row(office='2026-10-17',purchase='2026-10-12')])]),2026,'progress')
        self.assertEqual(b['rows'][0]['basisDate'],'2026-10-17');self.assertEqual(b['rows'][0]['basisType'],'office')
    def test_V_blank_never_infers_L_plus3(self):
        b=read_supplier('진행상황.xlsx',xlsx([('main',[source_row(purchase='2026-10-14'),source_row(purchase='2026-10-14',office='미도착')])]),2026,'progress')
        self.assertEqual(b['rows'][0]['basisDate'],'');self.assertEqual(b['rows'][1]['basisDate'],'')
    def test_negative_quantity_skipped(self):
        b=read_supplier('진행상황.xlsx',xlsx([('main',[source_row(qty=-1),source_row(qty=0),source_row(qty=2)])]),2026,'progress')
        self.assertEqual(len(b['rows']),2);self.assertTrue(b['warnings']);self.assertEqual(b['rows'][0]['qty'],0)
    def test_wrong_weekday_manifest(self):
        with self.assertRaises(SupplyError):read_supplier('솔리아 10월 14일 출고장 (완료).xlsx',xlsx([('main',[source_row()])]),2026,'manifest')

class CalendarTests(unittest.TestCase):
    def test_Monday_to_Tuesday(self):self.assertEqual(china_departure(date(2026,10,12)),date(2026,10,13))
    def test_Tuesday_same_day(self):self.assertEqual(china_departure(date(2026,10,13)),date(2026,10,13))
    def test_Wednesday_to_Saturday(self):self.assertEqual(china_departure(date(2026,10,14)),date(2026,10,17))
    def test_Thursday_to_Saturday(self):self.assertEqual(china_departure(date(2026,10,15)),date(2026,10,17))
    def test_Friday_to_Saturday(self):self.assertEqual(china_departure(date(2026,10,16)),date(2026,10,17))
    def test_Saturday_same_day(self):self.assertEqual(china_departure(date(2026,10,17)),date(2026,10,17))
    def test_Sunday_to_Tuesday(self):self.assertEqual(china_departure(date(2026,10,18)),date(2026,10,20))
    def test_manifest_Tuesday_route(self):
        p=route(date(2026,10,13));self.assertEqual((p['koreaStart'],p['koreaEnd'],p['receiptEnd']),('2026-10-19','2026-10-19','2026-10-20'))
    def test_Saturday_route(self):
        p=route(date(2026,10,17));self.assertEqual((p['koreaStart'],p['koreaEnd'],p['receiptStart'],p['receiptEnd']),('2026-10-21','2026-10-22','2026-10-22','2026-10-23'))
    def test_actual_Friday_manifest_same_wave(self):
        self.assertEqual(route(date(2026,10,16),departure=date(2026,10,16))['koreaEnd'],'2026-10-22')
    def test_month_boundary(self):
        p=route(date(2026,11,27));self.assertEqual((p['chinaDate'],p['koreaStart'],p['receiptEnd']),('2026-11-28','2026-12-02','2026-12-04'))
    def test_holiday_shift(self):
        self.assertEqual(business(date(2026,10,3),()),date(2026,10,6))
    def test_custom_holiday(self):self.assertEqual(route(date(2026,10,13),['2026-10-19'])['koreaStart'],'2026-10-20')
    def test_future_calendar_not_verified(self):self.assertFalse(route(date(2027,1,5))['calendarKnown'])

class SupplyTests(Base):
    def setUp(self):
        super().setUp();self.folder=Path(self.tmp.name)/'자료';self.folder.mkdir();self.engine.supply_link(str(self.folder))
        self.set_orders([order(1),order(2),order(3,product='다른상품')])
    def set_orders(self,rs):self.engine.import_rows({'rows':rs,'mode':'snapshot','scope':SELLERS,'replaceConfirmed':True})
    def file(self,rows,name='솔리아 10월 13일 출고장 (완료).xlsx'):
        path=self.folder/name;path.write_bytes(xlsx([('가상 출고장',rows)]));return path
    def refresh(self,rows=None):
        if rows is not None:self.file(rows)
        return self.engine.supply_refresh()
    def active(self):return [r for r in self.engine.public_state()['rows'] if r['active']]
    def ack(self):self.engine.external_manual({'keys':[r['key'] for r in self.active()],'dueDate':'2026-10-21'})
    def test_link_does_not_read(self):self.file([source_row()]);self.assertFalse(self.store.read()['supply']['manifests'])
    def test_engine_start_does_not_scan(self):
        self.file([source_row()]);self.restart();self.assertFalse(self.store.read()['supply']['manifests'])
    def test_refresh_does_not_send(self):self.refresh([source_row()]);self.assertFalse(self.fake.sent);self.assertFalse(self.fake.report_calls)
    def test_brand_discovery(self):
        self.refresh([source_row(brand=b) for b in ['N','NS','OD','M','A']]);self.assertEqual(self.engine.public_state()['supply']['discovered'],['A','M','N','NS','OD'])
    def test_brand_multiselect_default_excludes_other(self):
        self.refresh([source_row(brand='OD'),source_row(brand='A')]);self.assertEqual(self.active()[0]['receiptEnd'],'')
        self.engine.supply_settings({'year':2026,'brands':['OD'],'holidays':[]});self.assertEqual(self.active()[0]['receiptEnd'],'2026-10-20')
    def test_no_brands_does_not_mean_all(self):
        self.refresh([source_row()]);self.engine.supply_settings({'year':2026,'brands':[]});self.assertFalse(any(r['stockSecured'] for r in self.active()))
    def test_fifo_one_garment_only_oldest(self):
        self.refresh([source_row(qty=1)]);a=self.active();self.assertTrue(a[0]['stockSecured']);self.assertFalse(a[1]['stockSecured'])
    def test_fifo_not_name_or_display_sort(self):
        self.set_orders([order(2),order(1)]);self.refresh([source_row()]);a={r['orderId']:r for r in self.active()};self.assertTrue(a['TEST-001']['stockSecured']);self.assertFalse(a['TEST-002']['stockSecured'])
    def test_exact_time_precedence(self):
        r1=order(1);r2=order(2);r1['orderTimestamp']='2026-10-13 16:00';r2['orderTimestamp']='2026-10-13 09:00';self.set_orders([r1,r2]);self.refresh([source_row()]);self.assertTrue(next(r for r in self.active() if r['orderId']=='TEST-002')['stockSecured'])
    def test_qty2_requires2_partial_no_date(self):
        self.set_orders([order(1,qty=2),order(2)]);self.refresh([source_row(qty=1)]);r=self.active()[0];self.assertFalse(r['stockSecured']);self.assertEqual(r['supplyInfo']['manifestQty'],1);self.assertEqual(r['receiptEnd'],'')
    def test_97_units_not_98(self):
        self.set_orders([order(i) for i in range(1,99)]);self.refresh([source_row(qty=97)]);self.assertEqual(sum(r['stockSecured'] for r in self.active()),97)
    def test_order_side_wildcards(self):
        self.set_orders([order(1,option='원컬러-FREE')]);self.refresh([source_row(color='화이트',size='XL')]);self.assertTrue(self.active()[0]['stockSecured'])
    def test_source_side_wildcard_not_used(self):
        self.set_orders([order(1,option='화이트 / L')]);self.refresh([source_row(color='원컬러',size='FREE')]);self.assertFalse(self.active()[0]['stockSecured'])
    def test_product_prefix_stripped(self):
        self.set_orders([order(1,product='(BC-4)[4color]예쁜 가디건')]);self.refresh([source_row(product='예쁜 가디건')]);self.assertTrue(self.active()[0]['stockSecured'])
    def test_same_exact_product_in_selected_N_NS_pools(self):
        self.refresh([source_row(brand='N'),source_row(brand='NS')]);self.assertFalse(self.active()[0]['supplyInfo']['ambiguous']);self.assertEqual(sum(r['stockSecured'] for r in self.active()),2)
    def test_manual_mapping_applies_other_orders(self):
        self.refresh([source_row(product='번역다른니트',qty=2)]);r=self.active()[0];vid=self.engine.public_state()['supply']['variants'][0]['variant'];self.engine.supply_match({'key':r['key'],'variants':[vid]});self.assertEqual(sum(r['stockSecured'] for r in self.active()),2)
    def test_mapping_persists_and_is_not_customer_key(self):
        self.refresh([source_row(product='번역다른니트',qty=2)]);r=self.active()[0];vid=self.engine.public_state()['supply']['variants'][0]['variant'];self.engine.supply_match({'key':r['key'],'variants':[vid]});self.restart();self.assertIn(order_signature(r),self.store.read()['supply']['mappings']);self.assertNotIn(r['key'],self.store.read()['supply']['mappings'])
    def test_manual_mapping_empty_qty_still_shown(self):
        self.refresh([source_row(product='번역다른니트')]);r=self.active()[0];vid=self.engine.public_state()['supply']['variants'][0]['variant'];self.engine.supply_match({'key':r['key'],'variants':[vid]});self.assertEqual(self.active()[1]['supplyInfo']['manualVariants'],[vid])
    def test_match_clear(self):
        self.refresh([source_row(product='번역다른니트')]);r=self.active()[0];vid=self.engine.public_state()['supply']['variants'][0]['variant'];self.engine.supply_match({'key':r['key'],'variants':[vid]});self.engine.supply_match({'key':r['key'],'variants':[]});self.assertFalse(self.active()[0]['stockSecured'])
    def test_bad_match_rejected(self):
        with self.assertRaises(SupplyError):self.engine.supply_match({'key':self.active()[0]['key'],'variants':['invented']})
    def test_progress_only_never_confirmed(self):
        self.file([source_row(office='2026-10-17')],'진행상황.xlsx');self.refresh();self.ack();r=self.active()[0];self.assertEqual(r['receiptEnd'],'2026-10-23');self.assertFalse(r['stockSecured']);self.assertEqual(r['bucket'],'within')
    def test_progress_missing_dates_blank(self):
        self.file([source_row()],'진행상황.xlsx');self.refresh();self.assertEqual(self.active()[0]['receiptEnd'],'')
    def test_actual_manifest_confirmed_before_due(self):
        self.refresh([source_row()]);self.ack();self.assertEqual(self.active()[0]['bucket'],'within_confirmed');self.assertEqual(self.active()[1]['bucket'],'within')
    def test_future_manifest_after_promised_due_not_confirmed(self):
        self.file([source_row()],'솔리아 10월 17일 출고장 (완료).xlsx');self.refresh();self.ack();self.assertEqual(self.active()[0]['bucket'],'within')
    def test_due_today_not_forever_within(self):
        self.refresh([source_row()]);self.ack();Clock.current=datetime(2026,10,21,10,tzinfo=KST);self.assertEqual(self.active()[0]['bucket'],'due_today');self.assertTrue(self.active()[0]['stockSecured'])
    def test_overdue_keeps_stock_evidence(self):
        self.refresh([source_row()]);self.ack();Clock.current=datetime(2026,10,22,10,tzinfo=KST);self.assertEqual(self.active()[0]['bucket'],'overdue');self.assertTrue(self.active()[0]['stockSecured'])
    def test_removed_manifest_keeps_stock(self):
        p=self.file([source_row()]);self.refresh();p.unlink();self.refresh();self.assertTrue(self.active()[0]['stockSecured']);self.assertTrue(self.engine.public_state()['supply']['batches'][0]['fileMissing'])
    def test_repeated_refresh_not_multiply_stock(self):
        self.refresh([source_row()]);self.refresh();self.refresh();self.assertEqual(sum(r['stockSecured'] for r in self.active()),1)
    def test_same_day_different_files_rejected_atomically(self):
        self.refresh([source_row()]);before=self.store.read()['supply'];self.file([source_row(qty=9)],'솔리아 10월 13일 출고장 (완료) 복사.xlsx')
        with self.assertRaises(SupplyError):self.refresh()
        self.assertEqual(before,self.store.read()['supply'])
    def test_corrupt_refresh_preserves_previous(self):
        self.refresh([source_row()]);before=self.store.read()['supply'];(self.folder/'진행상황.xlsx').write_bytes(b'broken')
        with self.assertRaises(SupplyError):self.refresh()
        self.assertEqual(before,self.store.read()['supply'])
    def test_progress_missing_clears_estimate_only(self):
        p=self.file([source_row(office='2026-10-17')],'진행상황.xlsx');self.refresh();p.unlink();self.refresh();self.assertEqual(self.active()[0]['receiptEnd'],'')
    def test_same_wave_progress_not_double_counted(self):
        self.file([source_row(office='2026-10-13')],'진행상황.xlsx');self.refresh([source_row()]);self.assertFalse(self.active()[1]['receiptEnd'])
    def test_later_wave_progress_remaining_order(self):
        self.file([source_row(office='2026-10-17')],'진행상황.xlsx');self.refresh([source_row()]);self.assertEqual(self.active()[1]['receiptEnd'],'2026-10-23')
    def test_removed_order_before_closing_moves_fifo(self):
        self.refresh([source_row()]);self.set_orders([order(2),order(3,product='다른상품')]);self.assertTrue(self.active()[0]['stockSecured'])
    def test_reset_requires_confirm(self):
        with self.assertRaises(SupplyError):self.engine.supply_reset({})
    def test_reset_zero_stock_preserves_specific_order_proof(self):
        self.refresh([source_row()]);self.ack();r=self.engine.supply_reset({'confirmed':True});self.assertEqual(r['qty'],1);self.assertEqual(self.engine.public_state()['supply']['batches'][0]['qty'],0);self.assertEqual(self.active()[0]['bucket'],'within_confirmed')
    def test_closed_order_removal_does_not_free_stock(self):
        self.refresh([source_row()]);self.engine.supply_reset({'confirmed':True});self.set_orders([order(2),order(3,product='다른상품')]);self.assertFalse(self.active()[0]['stockSecured'])
    def test_closed_file_does_not_resurrect(self):
        self.refresh([source_row()]);self.engine.supply_reset({'confirmed':True});self.refresh();self.assertEqual(self.engine.public_state()['supply']['batches'][0]['qty'],0);self.assertFalse(self.active()[1]['stockSecured'])
    def test_renamed_closed_file_does_not_resurrect(self):
        p=self.file([source_row()]);self.refresh();self.engine.supply_reset({'confirmed':True});p.rename(self.folder/'복사 솔리아 10월 13일 출고장 (완료).xlsx');self.refresh();self.assertEqual(self.engine.public_state()['supply']['batches'][0]['qty'],0)
    def test_closed_date_edited_quantity_does_not_resurrect(self):
        self.refresh([source_row()]);self.engine.supply_reset({'confirmed':True});self.refresh([source_row(qty=100)]);self.assertFalse(self.active()[1]['stockSecured'])
    def test_new_date_can_load_after_reset(self):
        self.refresh([source_row()]);self.engine.supply_reset({'confirmed':True});self.file([source_row()],'솔리아 10월 17일 출고장 (완료).xlsx');self.refresh();self.assertTrue(self.active()[1]['stockSecured'])
    def test_reset_does_not_change_notices(self):
        self.refresh([source_row()]);self.ack();n=copy.deepcopy(self.store.read()['notices']);self.engine.supply_reset({'confirmed':True});self.assertEqual(n,self.store.read()['notices']);self.assertFalse(self.fake.sent)
    def test_restart_preserves_closed_tombstone(self):
        self.refresh([source_row()]);self.engine.supply_reset({'confirmed':True});self.restart();self.refresh();self.assertEqual(self.engine.public_state()['supply']['batches'][0]['qty'],0)
    def test_review_row_not_allocated(self):
        with self.store.edit() as s:next(r for r in s['rows'] if r['active'])['review']=True
        self.refresh([source_row()]);self.assertFalse(self.active()[0]['stockSecured']);self.assertTrue(self.active()[1]['stockSecured'])
    def test_invalid_holiday_atomic(self):
        before=self.store.read()
        with self.assertRaises(SupplyError):self.engine.supply_settings({'year':2026,'brands':['N'],'holidays':['10월 17일']})
        self.assertEqual(before,self.store.read())

class ExternalTests(Base):
    def setUp(self):
        super().setUp()
        # The external Excel feature now targets Ably line IDs only.
        from domain import rowkey
        with self.store.edit() as s:
            for i,r in enumerate(s['rows']):
                r['seller']='누아브 에이블리';r['orderItemId']=f'ITEM-{i}';r['orderItems']=[{'id':f'ITEM-{i}','qty':r['qty']}];r['key']=rowkey(r)
    def keys(self):return [r['key'] for r in self.store.read()['rows'] if r['active']]
    def test_manual_no_send_or_query(self):
        r=self.engine.external_manual({'keys':self.keys(),'dueDate':'2026-10-21'});self.assertEqual(r['items'],3);self.assertFalse(self.fake.sent);self.assertFalse(self.fake.report_calls);self.assertFalse(self.engine.send_one())
    def test_date_is_promised_shipping_date_not_fake_delivery(self):
        self.engine.external_manual({'keys':self.keys(),'dueDate':'2026-10-21'});r=self.row();self.assertEqual(r['dueDate'],'2026-10-21');self.assertFalse(r['deliveryVerified']);self.assertTrue(r['externalHistory'])
    def test_manual_repeat_idempotent(self):
        p={'keys':self.keys(),'dueDate':'2026-10-21'};self.engine.external_manual(p);n=len(self.store.read()['notices']);res=self.engine.external_manual(p);self.assertEqual(res['items'],0);self.assertEqual(len(self.store.read()['notices']),n)
    def test_changed_date_adds_new_history(self):
        self.engine.external_manual({'keys':self.keys(),'dueDate':'2026-10-21'});Clock.current+=timedelta(seconds=1);self.engine.external_manual({'keys':self.keys(),'dueDate':'2026-10-22','templateKey':'change'});self.assertEqual(self.row()['dueDate'],'2026-10-22')
    def test_selected_only(self):
        self.engine.external_manual({'keys':self.keys()[:1],'dueDate':'2026-10-21'});self.assertEqual(sum(r['noticeCount']>0 for r in self.engine.public_state()['rows']),1)
    def test_cancel_intersecting_unsent_batch_only(self):
        self.queue(sendMode='MORNING');res=self.engine.external_manual({'keys':self.keys()[:1],'dueDate':'2026-10-21'});self.assertEqual(res['cancelled'],1);self.assertEqual(self.store.read()['notices'][0]['status'],'CANCELLED')
    def test_do_not_cancel_accepted_message(self):
        self.send();before=copy.deepcopy(self.store.read()['notices'][0]);self.engine.external_manual({'keys':self.keys(),'dueDate':'2026-10-21'});self.assertEqual(before,self.store.read()['notices'][0]);self.assertEqual(len(self.fake.sent),1)
    def test_sending_inflight_blocked(self):
        self.queue()
        with self.store.edit() as s:s['notices'][0]['status']='SENDING'
        with self.assertRaises(ExternalError):self.engine.external_manual({'keys':self.keys(),'dueDate':'2026-10-21'})
    def test_source_file_missing_orders_does_not_remove_main(self):
        rows=self.store.read()['rows'];raw=ably_file(rows[:1]);p=self.engine.external_preview({'data':base64.b64encode(raw).decode(),'fileName':'test.xlsx','dueDate':'2026-10-21'});self.engine.external_apply({'token':p['token']});self.assertEqual(len([r for r in self.store.read()['rows'] if r['active']]),3)
    def test_unmatched_source_never_creates_order(self):
        raw=ably_file([order(999,product='없는 상품')|{'orderItemId':'UNKNOWN-ITEM'}]);p=self.engine.external_preview({'data':base64.b64encode(raw).decode(),'fileName':'test.xlsx','dueDate':'2026-10-21'});self.assertEqual(p['ready'],0);self.assertEqual(len(self.store.read()['rows']),3)
    def test_source_date_caller_not_filename(self):
        raw=ably_file(self.store.read()['rows']);p=self.engine.external_preview({'data':base64.b64encode(raw).decode(),'fileName':'20261016_에이블리_발송관리.xlsx','dueDate':'2026-10-29'});self.engine.external_apply({'token':p['token']});self.assertEqual(self.row()['dueDate'],'2026-10-29')
    def test_preview_is_read_only_and_apply_is_single_use(self):
        raw=ably_file(self.store.read()['rows']);before=self.store.read();p=self.engine.external_preview({'data':base64.b64encode(raw).decode(),'fileName':'test.xlsx','dueDate':'2026-10-21'});self.assertEqual(before,self.store.read());self.engine.external_apply({'token':p['token']})
        with self.assertRaises(ExternalError):self.engine.external_apply({'token':p['token']})
    def test_changed_order_after_preview_rejected(self):
        raw=ably_file(self.store.read()['rows']);p=self.engine.external_preview({'data':base64.b64encode(raw).decode(),'fileName':'test.xlsx','dueDate':'2026-10-21'})
        with self.store.edit() as s:s['rows'][0]['qty']=99
        with self.assertRaises(ExternalError):self.engine.external_apply({'token':p['token']})
    def test_invalid_date_is_not_recorded(self):
        before=self.store.read()
        with self.assertRaises(ExternalError):self.engine.external_manual({'keys':self.keys(),'dueDate':'not a date'})
        self.assertEqual(before,self.store.read())
    def test_old_external_and_new_application_notice_order(self):
        self.send();Clock.current+=timedelta(seconds=1);self.engine.external_manual({'keys':self.keys(),'dueDate':'2026-10-25'});self.assertEqual(self.row()['dueDate'],'2026-10-21')
    def test_reread_v068_restart_preserves_notice(self):
        self.engine.external_manual({'keys':self.keys(),'dueDate':'2026-10-21'});before=self.store.read()['notices'];self.restart();self.assertEqual(before,self.store.read()['notices'])

