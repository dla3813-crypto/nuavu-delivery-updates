"""Exchange re-shipment (C+주문번호) lookup: pure helpers and the controller's login prompt. No EzAdmin access."""
import threading,time,unittest
from exchange_reship import reship_of,reship_state,annotate,check_reships

ROWS=[{'pack':'735731','orderId':'C1791011162800','collectDate':'2026-10-13','status':'8','transStatus':'0','shop':'누아브 에이블리'},
      {'pack':'730717','orderId':'1791011162800','collectDate':'2026-10-05','status':'8','transStatus':'0','shop':'누아브 에이블리'},
      {'pack':'1','orderId':'C1791011162800999','collectDate':'2026-10-13','status':'1','transStatus':'0','shop':'x'}]

class HelperTests(unittest.TestCase):
    def test_only_exact_c_order(self):
        self.assertEqual([r['pack'] for r in reship_of('1791011162800',ROWS)],['735731'])
        self.assertEqual(reship_of('999',ROWS),[])
    def test_status_labels(self):
        self.assertEqual(reship_state('8','70','6082036587970','2026-10-14 10:40'),('배송','배송완료'))
        self.assertEqual(reship_state('7','','6082036587970',''),('송장',''))
        self.assertEqual(reship_state('1','','',''),('접수',''))
        self.assertEqual(reship_state('','','608',''),('송장',''))   # unknown code: fall back to the detail
        self.assertEqual(reship_state('','','','2026-10-14'),('배송',''))
    def test_annotate_marks_done_only_with_invoice(self):
        rows=[{'orderId':'1791011162800','itemId':'660355844'},{'orderId':'1791978778154','itemId':'664487103'}]
        found={'1791011162800':[{'orderId':'C1791011162800','pack':'735731','collectDate':'2026-10-13','status':'배송','deliveryStatus':'','carrier':'우체국택배','invoice':'6082036587970','invoiceAt':'2026-10-14 10:26:26','posAt':'2026-10-14 10:40:14','itemId':'660355844'}],
               '1791978778154':[]}
        annotate(rows,found)
        self.assertTrue(rows[0]['reshipDone']);self.assertEqual((rows[0]['reshipOrderId'],rows[0]['reshipInvoice'],rows[0]['reshipStatus']),('C1791011162800','6082036587970','배송'))
        self.assertFalse(rows[1]['reshipDone']);self.assertTrue(rows[1]['reshipChecked']);self.assertEqual(rows[1]['reship'],[])
    def test_annotate_error_keeps_rows_and_flags(self):
        rows=[{'orderId':'1','itemId':'a'}];annotate(rows,{},'세션 만료')
        self.assertFalse(rows[0]['reshipDone']);self.assertFalse(rows[0]['reshipChecked']);self.assertEqual(rows[0]['reshipError'],'세션 만료')
    def test_item_specific_hit_preferred(self):
        rows=[{'orderId':'1','itemId':'b'}]
        found={'1':[{'orderId':'C1','invoice':'111','status':'송장','itemId':'a','collectDate':'2026-10-01','invoiceAt':'','posAt':'','carrier':'','deliveryStatus':'','pack':''},
                    {'orderId':'C1','invoice':'222','status':'배송','itemId':'b','collectDate':'2026-10-02','invoiceAt':'','posAt':'','carrier':'','deliveryStatus':'','pack':''}]}
        annotate(rows,found);self.assertEqual(rows[0]['reshipInvoice'],'222')
    def test_without_account_hook_no_browser(self):
        class C:pass
        rows=[{'orderId':'1','itemId':'a'}];check_reships(C(),rows)
        self.assertIn('이지어드민 계정',rows[0]['reshipError']);self.assertFalse(rows[0]['reshipDone'])
        c=C();c.ezadmin_account=lambda:(_ for _ in ()).throw(ValueError('계정을 먼저 저장하세요'))
        rows=[{'orderId':'1','itemId':'a'}];check_reships(c,rows);self.assertIn('계정을 먼저 저장하세요',rows[0]['reshipError'])

class ControllerPromptTests(unittest.TestCase):
    def make(self):
        import tempfile
        from domain import Store,Engine
        from return_check import ReturnController
        from helpers import FakeSMS as FakeProvider
        tmp=tempfile.TemporaryDirectory();store=Store(tmp.name);engine=Engine(store,FakeProvider())
        c=ReturnController(engine,local=True);c.job={'id':'j','phase':'running'};return c,tmp,store
    def test_continue_accepts_and_timeout_declines(self):
        c,tmp,store=self.make()
        try:
            out={}
            t=threading.Thread(target=lambda:out.setdefault('v',c.ask_login_confirmation('다른 곳에서 로그인 중입니다. 계속하시겠습니까?')));t.start()
            time.sleep(.3);self.assertEqual(c.job['phase'],'login_wait');self.assertTrue(c.job['canContinue']);self.assertIn('이지어드민 확인 요청',c.job['message'])
            c.command=('continue',None);t.join(3);self.assertTrue(out['v']);self.assertEqual(c.job['phase'],'running');self.assertFalse(c.job['canContinue'])
            c.stop.set()
            with self.assertRaises(Exception):c.ask_login_confirmation('x')
        finally:store.close();tmp.cleanup()

if __name__=='__main__':unittest.main()
