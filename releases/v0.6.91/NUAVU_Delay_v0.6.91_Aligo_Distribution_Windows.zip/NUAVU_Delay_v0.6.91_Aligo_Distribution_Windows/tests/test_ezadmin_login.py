"""EzAdmin login credential isolation. No real Keychain or site requests."""
import json
from pathlib import Path
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from credentials import MacKeychain, UnavailableVault, VaultError
from aligo_credentials import AligoKeychain
from ezadmin_credentials import EzadminAccounts, EzadminKeychain, SERVICE, account_profile
from order_auto import OrderAutoController, OrderAutoError
from desktop import DesktopAPI
from domain import Store
from fake_security import MemoryVault, FakeSecurity

class LoginAccountsTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.vault=MemoryVault();self.accounts=EzadminAccounts(self.root,self.vault)
        self.secret='FAKE-ONLY-LOGIN-0623';self.domain='test-shop';self.username='test-user'
    def tearDown(self):self.tmp.cleanup()
    def save(self,password=None):return self.accounts.save(self.domain,self.username,self.secret if password is None else password)
    def test_separate_keychain_services(self):
        sec=FakeSecurity();services=[c(self.root,sec)._query()[sec.kSecAttrService] for c in [MacKeychain,AligoKeychain,EzadminKeychain]]
        self.assertEqual(len(set(services)),3);self.assertIn(SERVICE,services)
    def test_keychain_round_trip_with_fake_security(self):
        v=EzadminKeychain(self.root,FakeSecurity());a=EzadminAccounts(self.root,v);a.save(self.domain,self.username,self.secret)
        self.assertEqual(a.for_login()['password'],self.secret)
        self.assertNotIn(self.secret,json.dumps(a.info()))
    def test_settings_never_return_password(self):
        response=self.save();info=self.accounts.info()
        for data in [response,info]:
            self.assertNotIn('password',data);self.assertNotIn(self.secret,json.dumps(data));self.assertTrue(data['hasPassword'])
        self.assertEqual(info['username'],self.username)
    def test_blank_preserves_password_only_for_same_identity(self):
        self.save();self.save('');self.assertEqual(self.accounts.for_login()['password'],self.secret)
        with self.assertRaises(VaultError):self.accounts.save(self.domain,'changed-user','')
        self.assertEqual(self.accounts.for_login()['username'],self.username)
    def test_password_whitespace_is_preserved(self):
        self.save(' '+self.secret+' ');self.assertEqual(self.accounts.for_login()['password'],' '+self.secret+' ')
    def test_password_can_be_changed(self):
        self.save();self.save('FAKE-NEW');self.assertEqual(self.accounts.for_login()['password'],'FAKE-NEW')
    def test_failed_save_preserves_previous_keychain_account(self):
        self.save();self.vault.fail_save=True
        with self.assertRaises(VaultError):self.save('FAKE-CHANGED')
        self.assertEqual(self.accounts.for_login()['password'],self.secret)
    def test_first_save_requires_password(self):
        with self.assertRaises(VaultError):self.save('')
    def test_bad_identity_and_password_rejected(self):
        for d,u,p in [('https://evil.test','user','x'),('ok','u\nx','x'),('ok','u','\0'),('ok','u','x'*4097),('ok','','x')]:
            with self.assertRaises(VaultError):self.accounts.save(d,u,p)
    def test_profile_bound_to_identity_not_password(self):
        self.save();a=self.accounts.for_login();self.assertEqual(account_profile(a),account_profile({**a,'password':'changed'}))
        self.assertNotEqual(account_profile(a),account_profile({**a,'username':'other'}))
        self.assertNotIn(self.domain,account_profile(a))
    def test_unavailable_never_writes_plaintext(self):
        a=EzadminAccounts(self.root,UnavailableVault())
        with self.assertRaises(VaultError):a.save(self.domain,self.username,self.secret)
        self.assertFalse(list(self.root.iterdir()))
    def test_failures_redact_provider_exceptions(self):
        class BadVault:
            available=True
            def load(s):raise RuntimeError('FAKE-ONLY-LOGIN-0623 private detail')
            def save(s,p):raise RuntimeError(p['password'])
        a=EzadminAccounts(self.root,BadVault())
        for fn in [a.info,lambda:a.save(self.domain,self.username,self.secret)]:
            with self.assertRaises(VaultError) as caught:fn()
            self.assertNotIn(self.secret,str(caught.exception))
    def test_missing_account_gives_settings_instruction(self):
        with self.assertRaisesRegex(VaultError,'이지어드민 설정'):self.accounts.for_login()
    def test_corrupted_item_not_used(self):
        self.vault.save({'version':1,'domain':'test','username':'test','password':None})
        with self.assertRaises(VaultError):self.accounts.for_login()
    def test_save_acknowledged_but_missing_item_is_not_success(self):
        self.vault.save=lambda payload:None
        with self.assertRaisesRegex(VaultError,'다시 확인하지 못'):self.save()
    def test_save_readback_wrong_account_is_not_success(self):
        original=self.vault.save
        self.vault.save=lambda payload:original({**payload,'username':'different-user'})
        with self.assertRaisesRegex(VaultError,'다시 확인하지 못'):self.save()
    def test_save_readback_error_is_safe_and_not_success(self):
        original=self.vault.save
        def save(payload):original(payload);self.vault.fail_load=True
        self.vault.save=save
        with self.assertRaises(VaultError) as caught:self.save()
        self.assertIn('다시 읽지 못',str(caught.exception));self.assertNotIn(self.secret,str(caught.exception))

class LoginControllerTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(self.tmp.name);self.vault=MemoryVault()
        with self.store.edit() as s:s['settings'].update(shopName='데모스토어',shopRevision=1)
        self.c=OrderAutoController(self.store,runner=lambda *_:('fake',b'fake'),login_vault=self.vault)
        self.b=DesktopAPI(SimpleNamespace(store=self.store),'token','http://127.0.0.1:1234',None);self.b._order_auto=self.c
        self.b._window=SimpleNamespace(get_current_url=lambda:'http://127.0.0.1:1234/')
    def tearDown(self):
        self.c.cancel()
        if self.c.thread:self.c.thread.join(2)
        self.store.close();self.tmp.cleanup()
    def test_save_does_not_change_state_and_secrets_not_in_status(self):
        before=self.store.read();self.c.save_login_settings('test-shop','test-user','FAKE-SECRET')
        self.assertEqual(before,self.store.read());self.assertNotIn('FAKE-SECRET',json.dumps(self.c.status()))
        for p in Path(self.tmp.name).rglob('*'):
            if p.is_file():self.assertNotIn(b'FAKE-SECRET',p.read_bytes())
    def test_missing_credential_login_does_not_fall_back(self):
        with self.assertRaises(OrderAutoError):self.c.login_account()
        self.assertEqual(self.c.status()['phase'],'idle')
    def test_new_bridge_methods_require_token_and_origin(self):
        for token,url in [('bad','http://127.0.0.1:1234/'),('token','https://login1.ezadmin.co.kr/login.htm')]:
            self.b._window.get_current_url=lambda:url
            self.assertIn('error',self.b.ezadmin_login_settings(token))
            self.assertIn('error',self.b.ezadmin_login_save(token,'test','test','FAKE'))
        self.assertIsNone(self.vault.load())
    def test_bridge_save_and_info_redacted(self):
        result=self.b.ezadmin_login_save('token','test','test','FAKE-SECRET');self.assertNotIn('error',result)
        self.assertNotIn('FAKE-SECRET',json.dumps(self.b.ezadmin_login_settings('token')))
    def test_credentials_cannot_change_during_active_import(self):
        done=threading.Event()
        self.c.runner=lambda *_:(done.wait(1) and 'fake',b'fake')
        self.c.configure(folder=self.tmp.name);self.c.start()
        with self.assertRaises(OrderAutoError):self.c.save_login_settings('x','x','FAKE')
        done.set();self.c.thread.join(2)
    def test_browser_exception_cannot_leak_credentials_or_deliver_file(self):
        def fail(*_):raise RuntimeError('fake-browser-error FAKE-SECRET')
        self.c.runner=fail;self.c.configure(folder=self.tmp.name);self.c.start();self.c.thread.join(2)
        self.assertEqual(self.c.status()['phase'],'error');self.assertIsNone(self.c.receipt)
        self.assertNotIn('FAKE-SECRET',json.dumps(self.c.status()))
    def test_successful_save_clears_finished_missing_account_error_without_restart(self):
        self.c.runner=lambda c,cfg:c.login_account()
        self.c.start(login_only=True);self.c.thread.join(2)
        self.assertEqual(self.c.status()['phase'],'error');previous=self.c.thread
        self.c.save_login_settings('demo','demo','FAKE')
        self.assertEqual(self.c.status()['phase'],'idle');self.assertIs(self.c.thread,previous)
        self.assertFalse(self.c.status()['running'])
        self.c.start(login_only=True);self.c.thread.join(2)
        self.assertEqual(self.c.status()['phase'],'login_ready')
    def test_failed_save_preserves_previous_error(self):
        self.c.job={'id':'old','phase':'error','message':'이전 오류'}
        self.vault.fail_save=True
        with self.assertRaises(VaultError):self.c.save_login_settings('demo','demo','FAKE')
        self.assertEqual(self.c.job,{'id':'old','phase':'error','message':'이전 오류'})
    def test_failed_readback_preserves_previous_error(self):
        self.c.job={'id':'old','phase':'error','message':'이전 오류'}
        self.vault.save=lambda payload:None
        with self.assertRaises(VaultError):self.c.save_login_settings('demo','demo','FAKE')
        self.assertEqual(self.c.job,{'id':'old','phase':'error','message':'이전 오류'})
    def test_save_does_not_discard_pending_download_receipt(self):
        self.c.job={'id':'file1','phase':'ready','message':'다운로드 완료'}
        self.c.receipt={'id':'file1','data':'FAKE-FILE'}
        self.c.save_login_settings('demo','demo','FAKE')
        self.assertEqual(self.c.job['phase'],'ready');self.assertEqual(self.c.receipt,{'id':'file1','data':'FAKE-FILE'})

if __name__=='__main__':unittest.main()
