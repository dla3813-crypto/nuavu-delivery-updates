"""자동매칭 양식 (2026-10-19, 공통): leading tags are not identity; bracket words count as words; color digits ignored."""
import pytest
from supply_workflow import candidates, variant_id, match_product_name, product_forms, same_product

def candidate(option,color,source_size='F',product='가디건',source_product='가디건'):
    source=dict(brand='N',product=source_product,color=color,size=source_size);source['variant']=variant_id(source)
    return candidates(dict(product=product,option=option),[source],{})[0]

LONG='F7 [❤️‍🔥지금부터쭉/신상초특가] 4color 더블 카라 브이 반팔 니트'
MID='F7 더블 카라 브이 반팔 니트'
CORE='더블 카라 브이 반팔 니트'

@pytest.mark.parametrize('a,b',[(LONG,MID),(LONG,CORE),(MID,CORE),('(A-6)[3color] 더블 카라 브이 반팔 니트',CORE),('4color 더블 카라 브이 반팔 니트',CORE),('F7[세일] 더블 카라 브이 반팔 니트',CORE)])
def test_leading_tags_do_not_change_identity(a,b):
    assert match_product_name(a)==match_product_name(b)==match_product_name(CORE) and same_product(a,b)

def test_core_name_difference_still_distinct():
    assert not same_product(LONG,'F7 더블 카라 라운드 반팔 니트')
    assert not same_product('56 스타 자수 팬츠','57 스타 자수 팬츠')

@pytest.mark.parametrize('order_name,source_name',[(LONG,CORE),(CORE,LONG),(MID,LONG),(LONG,MID)])
def test_order_and_source_match_either_way(order_name,source_name):
    assert len(candidate('블랙 / FREE','블랙',product=order_name,source_product=source_name))==1

@pytest.mark.parametrize('color',['블랙1','블랙2','블랙3','1블랙','2블랙','블랙 1'])
def test_color_digits_ignored_on_source(color):
    assert len(candidate('블랙 / FREE',color))==1

@pytest.mark.parametrize('option',['블랙1 / FREE','1블랙 / FREE','블랙2-FREE'])
def test_color_digits_ignored_on_order(option):
    assert len(candidate(option,'블랙'))==1

def test_other_color_still_rejected():
    assert len(candidate('블랙 / FREE','화이트1'))==0

def test_numbered_colors_are_separate_variants_but_both_match():
    sources=[]
    for color in ('블랙1','블랙2'):
        s=dict(brand='N',product=CORE,color=color,size='F');s['variant']=variant_id(s);sources.append(s)
    assert len({s['variant'] for s in sources})==2
    hits,ambiguous,mode=candidates(dict(product=LONG,option='블랙 / FREE'),sources,{})
    assert len(hits)==2 and not ambiguous and mode=='automatic'

def test_persisted_variant_id_unchanged_by_tags():
    a=dict(brand='N',product=LONG,color='블랙',size='F');b=dict(brand='N',product=CORE,color='블랙',size='F')
    assert variant_id(a)!=variant_id(b)  # saved mappings/ids keep the original name; only comparison strips tags

@pytest.mark.parametrize('order_name,source_name,option,color',[
    ('[F14-1] 루미너스 리본 홀터 원피스','F14-1 루미너스 리본 홀터 원피스','[블랙]','블랙1'),   # 2026-10-19 21:03 screenshot
    ('[F14-1] 루미너스 리본 홀터 원피스','F14-1루미너스 리본 홀터 원피스','블랙','블랙'),
    ('NA-6 웰론 후드','[NA-6] 웰론 후드','그린 / FREE','그린2'),
    ('S6 [긴팔] 버터플라이 레이어 가디건','S6 긴팔 버터플라이 레이어 가디건','[블랙]','블랙1'),   # 2026-10-19 21:22 screenshot: bracket word is a word
    ('S6 긴팔 버터플라이 레이어 가디건','S6 [긴팔] 버터플라이 레이어 가디건','블랙','블랙'),
])
def test_dashed_codes_and_bracket_words(order_name,source_name,option,color):
    assert same_product(order_name,source_name)
    assert len(candidate(option,color,product=order_name,source_product=source_name))==1

def test_long_sku_code_is_not_a_leading_tag():
    assert match_product_name('S37644 니트')=='s37644니트'

def test_forms_contain_both_readings():
    assert product_forms('S6 [긴팔] 버터플라이 레이어 가디건')=={'긴팔버터플라이레이어가디건','버터플라이레이어가디건'}
