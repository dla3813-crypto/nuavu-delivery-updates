"""v0.6.10: bracket options, Ably detail IDs and normalized phone search.
Synthetic orders/OOXML only; fake providers; no real account or Mac writes.
"""
import base64,copy,json,subprocess,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from datetime import datetime
from domain import Engine,Store,SELLERS,KST,rowkey,ValidationError
from order_items import ABLY,item_id,ItemIdError,items_of
from external_notices import matches,ExternalError
from supply_workflow import option_parts,legacy_option_parts,order_signature,digest,product_name
from helpers import Base,Clock
from test_supply_regression import order,source_row,xlsx,ably_file

ROOT=Path(__file__).resolve().parents[1]

class OptionFormatTests(unittest.TestCase):
    def test_actual_bracket_free(self):self.assertEqual(option_parts('[원컬러-FREE]'),('원컬러','free'))
    def test_actual_bracket_5xl(self):self.assertEqual(option_parts('[그린-5XL(55)]'),('그린','5xl'))
    def test_actual_bracket_model_worn(self):self.assertEqual(option_parts('[차콜(모델착용)-FREE]'),('차콜','free'))
    def test_bracket_color_note_spaces(self):self.assertEqual(option_parts('[ 베이지(모델 착용) - FREE ]'),('베이지','free'))
    def test_slash_still_works(self):self.assertEqual(option_parts('블랙 / FREE'),('블랙','free'))
    def test_part_brackets(self):self.assertEqual(option_parts('[블랙] / [FREE]'),('블랙','free'))
    def test_dimension_labels(self):self.assertEqual(option_parts('컬러: 블랙 / 사이즈: M'),('블랙','m'))
    def test_nfd(self):
        import unicodedata
        self.assertEqual(option_parts(unicodedata.normalize('NFD','[그린-FREE]')),('그린','free'))
    def test_unknown_not_free(self):self.assertNotEqual(option_parts('[화이트-한장만 구매]')[1],'free')
    def test_plain_missing_size_is_free(self):self.assertEqual(option_parts('블랙')[1],'free')
    def test_stable_existing_mapping_hash(self):
        r=order(1,option='[원컬러-FREE]')
        self.assertEqual(order_signature(r),digest([product_name(r['product']),*legacy_option_parts(r['option'])]))
    def test_item_id_numeric(self):self.assertEqual(item_id(123456789),'123456789')
    def test_item_id_text_leading_zero(self):self.assertEqual(item_id(' 00123456 '),'00123456')
    def test_item_id_scientific_rejected(self):
        with self.assertRaises(ItemIdError):item_id('1.2345e+18')
    def test_item_id_unsafe_number_rejected(self):
        with self.assertRaises(ItemIdError):item_id(123456789012345678)
    def test_item_id_fraction_rejected(self):
        with self.assertRaises(ItemIdError):item_id(123.5)

class DetailIdTests(Base):
    def setUp(self):
        super().setUp()
        with self.store.edit() as s:s['rows']=[]
    def add(self,i=1,detail='801',**kwargs):
        r=order(i,**kwargs);r['orderItemId']=detail
        self.engine.import_rows({'rows':[r],'mode':'merge'})
        return next(x for x in self.store.read()['rows'] if x['orderId']==r['orderId'])
    def entry(self,detail='801',**kwargs):
        return {'seller':ABLY,'orderId':'different-platform-order','product':'다른 표시 이름','option':'달라도됨','qty':1,'itemId':detail,'sheet':'발송관리','line':2}|kwargs
    def match(self,e):return matches(self.store.read(),[e],'2026-10-21')[0]
    def test_metadata_imported(self):
        r=self.add();self.assertEqual(r['orderItemId'],'801');self.assertEqual(r['orderItems'],[{'id':'801','qty':1}])
    def test_identity_unchanged(self):
        r=self.add();self.assertEqual(r['key'],rowkey(order(1)))
    def test_detail_only_ignores_name_option_order(self):
        r=self.add();m=self.match(self.entry());self.assertEqual(m['status'],'ready');self.assertEqual(m['key'],r['key'])
    def test_other_seller_excluded(self):
        self.add();self.assertEqual(self.match(self.entry(seller='누아브 자사몰'))['status'],'excluded')
    def test_missing_id_no_fuzzy_fallback(self):
        self.add();self.assertEqual(self.match(self.entry(detail='',orderId='TEST-001',product='가디건',option='아이보리 / FREE'))['status'],'missing_id')
    def test_unknown_id_no_fuzzy_fallback(self):
        self.add();self.assertEqual(self.match(self.entry('not-known',orderId='TEST-001',product='가디건',option='아이보리 / FREE'))['status'],'missing')
    def test_quantity_difference(self):
        self.add();self.assertEqual(self.match(self.entry(qty=2))['status'],'quantity')
    def test_inactive_never_acknowledged(self):
        self.add()
        with self.store.edit() as s:s['rows'][0]['active']=False
        self.assertEqual(self.match(self.entry())['status'],'missing')
    def test_no_cross_seller_match(self):
        self.engine.import_rows({'rows':[order(1)|{'seller':'누아브 자사몰','orderItemId':'801'}]})
        self.assertEqual(self.match(self.entry())['status'],'missing')
    def test_other_seller_bad_M_not_required(self):
        self.engine.import_rows({'rows':[order(1)|{'seller':'누아브 지그재그','orderItemId':'1.99e+25'}]})
        self.assertNotIn('orderItemId',self.store.read()['rows'][0])
    def test_legacy_record_enriched_no_duplicate(self):
        self.add(detail='');key=self.store.read()['rows'][0]['key'];self.engine.external_manual({'keys':[key],'dueDate':'2026-10-21'});ledger=copy.deepcopy(self.store.read()['notices'])
        self.add();s=self.store.read();self.assertEqual(len(s['rows']),1);self.assertEqual(s['notices'],ledger);self.assertFalse(s['rows'][0]['review'])
    def test_adding_id_keeps_existing_reservation(self):
        r=self.add(detail='');self.queue(keys=[r['key']],sendMode='MORNING');before=self.last()
        self.add();self.assertEqual(self.last(),before)
    def test_old_no_column_preserves_known_metadata(self):
        self.add();self.engine.import_rows({'rows':[order(1)]});self.assertEqual(self.store.read()['rows'][0]['orderItemId'],'801')
    def test_explicit_blank_column_clears_metadata(self):
        self.add();self.engine.import_rows({'rows':[order(1)|{'orderItemIdMapped':True,'orderItemId':''}]});self.assertEqual(self.store.read()['rows'][0]['orderItems'],[])
    def test_aggregate_two_ids_one_sku(self):
        r=order(1);self.engine.import_rows({'rows':[r|{'orderItemId':'801'},r|{'orderItemId':'802'}]})
        row=self.store.read()['rows'][0];self.assertEqual(row['qty'],2);self.assertEqual(len(row['orderItems']),2);self.assertEqual(row['key'],rowkey(r))
    def test_partial_aggregate_not_whole_notified(self):
        r=order(1);self.engine.import_rows({'rows':[r|{'orderItemId':'801'},r|{'orderItemId':'802'}]})
        self.assertEqual(self.match(self.entry())['status'],'partial')
    def test_full_aggregate_can_ack(self):
        r=order(1);self.engine.import_rows({'rows':[r|{'orderItemId':'801'},r|{'orderItemId':'802'}]})
        result=matches(self.store.read(),[self.entry(),self.entry('802')],'2026-10-21');self.assertTrue(all(x['status']=='ready' for x in result))
    def test_duplicate_input_id_rejected(self):
        r=order(1)|{'orderItemId':'801'}
        with self.assertRaises(ValidationError):self.engine.import_rows({'rows':[r,r]})
        self.assertFalse(self.store.read()['rows'])
    def test_id_repeated_in_different_rows_rejected(self):
        with self.assertRaises(ValidationError):self.engine.import_rows({'rows':[order(1)|{'orderItemId':'801'},order(2)|{'orderItemId':'801'}]})
    def test_preexisting_duplicate_id_not_guessed(self):
        self.add();self.add(2,'802')
        with self.store.edit() as s:s['rows'][1]['orderItemId']='801';s['rows'][1]['orderItems']=[{'id':'801','qty':1}]
        self.assertEqual(self.match(self.entry())['status'],'ambiguous')
    def test_external_excel_uses_ID_and_sends_zero(self):
        r=self.add();file=ably_file([order(999,product='다른 이름',option='블랙 / L')|{'orderItemId':'801'}]);p=self.engine.external_preview({'fileName':'발송관리.xlsx','data':base64.b64encode(file).decode(),'dueDate':'2026-10-21'})
        self.assertEqual(p['ready'],1);result=self.engine.external_apply({'token':p['token']});self.assertEqual(result['items'],1)
        self.assertEqual(self.engine.public_state()['rows'][0]['dueDate'],'2026-10-21');self.assertFalse(self.fake.sent);self.assertFalse(self.fake.report_calls)
        self.assertEqual(self.last()['sourceMappings'][0]['itemId'],'801')
    def test_conflict_introduced_after_preview_blocked(self):
        self.add();raw=ably_file([order(1)|{'orderItemId':'801'}]);p=self.engine.external_preview({'data':base64.b64encode(raw).decode(),'fileName':'x.xlsx','dueDate':'2026-10-21'})
        with self.store.edit() as s:
            row=copy.deepcopy(s['rows'][0]);row.update(orderId='TEST-OTHER',product='other');row['key']=rowkey(row);s['rows'].append(row)
        with self.assertRaises(ExternalError):self.engine.external_apply({'token':p['token']})
    def test_restart_keeps_metadata_and_history(self):
        r=self.add();self.engine.external_manual({'keys':[r['key']],'dueDate':'2026-10-21'});before=self.store.read();self.restart();after=self.store.read()
        self.assertEqual(after['rows'],before['rows']);self.assertEqual(after['notices'],before['notices'])

# Reuse the setup only (do not inherit and double-count the entire existing suite).
class BracketAllocationTests(Base):
    def setUp(self):
        super().setUp()
        with self.store.edit() as s:s['rows']=[]
        self.folder=Path(self.tmp.name)/'클로드';self.folder.mkdir();self.engine.supply_link(str(self.folder))
    def scan(self,rows,source=None):
        self.engine.import_rows({'rows':rows});file=self.folder/'솔리아 10월 13일 출고장 (완료).xlsx';file.write_bytes(xlsx([('출고장',[source or source_row(qty=1)])]));self.engine.supply_refresh();return self.engine.public_state()['rows']
    def test_brackets_have_eta(self):self.assertEqual(self.scan([order(1,option='[아이보리-FREE]')])[0]['receiptEnd'],'2026-10-20')
    def test_bracket_free_wildcards(self):self.assertTrue(self.scan([order(1,option='[원컬러-FREE]')],source_row(color='화이트',size='L'))[0]['stockSecured'])
    def test_explicit_size_mismatch_stays_blank(self):self.assertEqual(self.scan([order(1,option='[아이보리-M]')],source_row(size='L'))[0]['receiptEnd'],'')
    def test_awaiting_ack_not_confirmed_by_supply_alone(self):self.assertEqual(self.scan([order(1,option='[아이보리-FREE]')])[0]['bucket'],'unnotified')
    def test_ack_and_supply_confirms(self):
        r=self.scan([order(1,option='[아이보리-FREE]')])[0];self.engine.external_manual({'keys':[r['key']],'dueDate':'2026-10-21'});self.assertEqual(self.engine.public_state()['rows'][0]['bucket'],'within_confirmed')
    def test_fifo_with_bracket_options(self):
        rows=self.scan([order(2,option='[아이보리-FREE]'),order(1,option='[아이보리-FREE]')]);byid={r['orderId']:r for r in rows};self.assertTrue(byid['TEST-001']['stockSecured']);self.assertFalse(byid['TEST-002']['stockSecured'])
    def test_manual_rule_hash_not_reset(self):
        rows=self.scan([order(1,product='매칭한상품',option='[원컬러-FREE]')]);vid=self.engine.public_state()['supply']['variants'][0]['variant'];self.engine.supply_match({'key':rows[0]['key'],'variants':[vid]});old=self.store.read()['supply']['mappings'];self.restart();self.assertEqual(self.store.read()['supply']['mappings'],old);self.assertTrue(self.engine.public_state()['rows'][0]['stockSecured'])
    def test_sealed_proof_kept_and_no_qty_resurrection(self):
        r=self.scan([order(1,option='[아이보리-FREE]')])[0];self.engine.supply_reset({'confirmed':True});self.restart();self.engine.supply_refresh();self.assertTrue(self.engine.public_state()['rows'][0]['stockSecured']);self.assertTrue(self.engine.public_state()['supply']['batches'][0]['closed'])
    def test_new_diagnostic_counts(self):
        self.scan([order(1,option='[아이보리-FREE]')]);s=self.engine.public_state()['supply'];self.assertEqual(s['loadedCounts']['manifestRows'],1);self.assertEqual(len(s['lastScan']['files']),1)
    def test_missing_file_scan_has_warning(self):
        result=self.engine.supply_refresh();self.assertEqual(result['files'],0);self.assertTrue(result['warnings'])
    def test_blank_eta_has_reason(self):
        rows=self.scan([order(1,option='[아이보리-FREE]'),order(2,option='[아이보리-FREE]')]);self.assertEqual(rows[1]['supplyInfo']['reasonCode'],'SHORTAGE_OR_DATE')

class ImportAndSearchJavaScriptTests(unittest.TestCase):
    def run_js(self,body):
        code="const C=require('./web/import.js');"+body
        result=subprocess.run(['node','-e',code],cwd=ROOT,text=True,capture_output=True,timeout=10)
        self.assertEqual(result.returncode,0,result.stderr)
        return json.loads(result.stdout)
    def test_phone_variations_and_fields(self):
        got=self.run_js("""const r={phone:'01012345678',product:'기모 티셔츠',option:'블랙-FREE',orderId:'ORDER1'};console.log(JSON.stringify(['010-1234-5678','01012345678','010 1234 5678','1234-5678','5678','+82 10-1234-5678','010–1234–5678'].map(q=>C.matchesSearch(r,q,'customer'))));""")
        self.assertTrue(all(got))
    def test_phone_not_searched_from_product_field(self):
        self.assertFalse(self.run_js("console.log(JSON.stringify(C.matchesSearch({phone:'01012345678',product:'티셔츠'},'010-1234-5678','productName')));"))
    def test_letters_not_stripped_into_phone(self):self.assertFalse(self.run_js("console.log(JSON.stringify(C.matchesSearch({phone:'01012345678'},'가디건01012345678','all')));"))
    def test_M_header_and_distinct_order_column(self):
        out=self.run_js("console.log(JSON.stringify(C.guessMapping(['상품명','옵션명','주문수량','주문일','주문시간','수령자이름','수령자휴대폰','수령자전화','판매처','주문자전화','주문자휴대폰','주문번호','주문 상세번호'])));")
        self.assertEqual(out['orderItemId'],12);self.assertEqual(out['orderId'],11)
    def test_M_position_not_silently_other_field(self):
        self.assertEqual(self.run_js("console.log(JSON.stringify(C.guessMapping(['상품명','옵션명','수량','주문일','시간','수령자','번호','전화','판매처','전화','휴대폰','주문번호','다른 코드']).orderItemId));"),-1)
    def test_JS_full_parse_M_header(self):
        result=self.run_js("const h=['판매처','주문번호','상품명','옵션명','주문수량','주문 상세번호'];const p=C.parseRows([h,['누아브 에이블리','TEST','가디건','[원컬러-FREE]',1,'801']],0,C.guessMapping(h));console.log(JSON.stringify(p));")
        self.assertFalse(result['errors']);self.assertEqual(result['rows'][0]['orderItems'],[{'id':'801','qty':1}])
    def test_JS_aggregated_two_distinct_ids(self):
        result=self.run_js("const h=['판매처','주문번호','상품명','옵션명','수량','주문 상세번호'];const rs=['801','802'].map(id=>['누아브 에이블리','TEST','가디건','[원컬러-FREE]',1,id]);console.log(JSON.stringify(C.parseRows([h,...rs],0,C.guessMapping(h))));")
        self.assertFalse(result['errors']);self.assertEqual(len(result['rows']),1);self.assertEqual(len(result['rows'][0]['orderItems']),2)
    def test_JS_scientific_id_errors(self):
        result=self.run_js("const h=['판매처','주문번호','상품명','주문 상세번호'];console.log(JSON.stringify(C.parseRows([h,['누아브 에이블리','TEST','가디건','1.234e+16']],0,C.guessMapping(h))));")
        self.assertTrue(result['errors'])
    def test_detail_id_search(self):self.assertTrue(self.run_js("console.log(JSON.stringify(C.matchesSearch({orderId:'TEST',orderItems:[{id:'8012',qty:1}]},'8012','orderId')));"))

if __name__=='__main__':unittest.main()
