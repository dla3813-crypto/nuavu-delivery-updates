"""아무드(일본) 배송지연 메시지: 주문번호로만 매칭, 고정 지연 사유, 1회 발송 기록."""
import sys,unittest
from datetime import date,timedelta
from pathlib import Path
from unittest.mock import MagicMock
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
try:
    from test_v056 import Base
except ImportError:
    from helpers import Base
try:
    from test_v068 import order
except ImportError:
    from test_supply_regression import order
from ably_sync import AblySyncController,AblySyncError
import amood_push
from amood_push import AMOOD,plan_amood,reason_text,AmoodPusher,order_key
from domain import today

def due(days):return (date.fromisoformat(today())+timedelta(days=days)).isoformat()

class AmoodPushTests(Base):
    def setUp(self):
        super().setUp()
        with self.store.edit() as s:
            s['rows']=[];s['settings']['shopName']='누아브'
        self.engine.import_rows({'rows':[order(1)|{'orderId':'2307473','seller':AMOOD,'product':'숏 더블 크롭 코트 자켓','option':'그레이/FREE'},
                                         order(2)|{'orderId':'2307473','seller':AMOOD,'product':'베이직 니트','option':''},
                                         order(3)|{'orderId':'2325592','seller':AMOOD},
                                         order(4)|{'orderId':'2307473','seller':'누아브 자사몰'}]})
        rows=self.store.read()['rows'];self.rows=rows
        self.amood=[r['key'] for r in rows if r['seller']==AMOOD]
        self.vault=MagicMock(available=True);self.vault.load.return_value=dict(version=1,username='fake',password='FAKE-SECRET')
        self.c=AblySyncController(self.engine,vault=self.vault);self.calls=[]
        def runner(account,stop,progress,targets,preview=False):
            self.calls.append(([dict(t) for t in targets],preview))
            st='preview' if preview else 'sent'
            return {'results':[dict(t,status=st,reason='',platformNotice='1차 발송') for t in targets],'steps':['아무드 주문 목록 확인']}
        self.c.amood_runner=runner
    def test_plan_groups_by_order_number_only(self):
        self.engine.external_manual({'keys':self.amood,'dueDate':due(2)})
        targets,skipped=plan_amood(self.store.read(),None,today())
        self.assertEqual([t['orderId'] for t in targets],['2307473','2325592']);self.assertEqual(skipped,[])
        t=targets[0];self.assertEqual(len(t['keys']),2);self.assertEqual(t['option'],'모레')
        self.assertIn('숏 더블 크롭 코트 자켓 (그레이/FREE) × 1\n베이직 니트 × 1',t['reason'])
    def test_reason_is_the_owner_template(self):
        text=reason_text('누아브',[{'product':'A','option':'B','qty':2}],'2026-10-27')
        self.assertEqual(text,'안녕하세요 고객님\n누아브입니다.\n\n주문하신 상품의 입고가 지연되어 안내드립니다.\n\n상품: A (B) × 2\n출고 예정일: 2026년 10월 27일\n\n기다리게 해드려 정말 죄송합니다.\n입고되는 대로 꼼꼼히 검수하여 빠르게 출고하겠습니다.\n\n기다려주셔서 감사합니다.')
    def test_rows_without_app_notice_are_not_planned(self):
        self.assertEqual(plan_amood(self.store.read(),None,today()),([],[]))
    def test_out_of_range_due_is_held(self):
        self.engine.external_manual({'keys':self.amood[:1],'dueDate':due(40)})
        targets,skipped=plan_amood(self.store.read(),None,today())
        self.assertEqual(targets,[]);self.assertEqual(skipped[0]['orderId'],'2307473');self.assertIn('30일',skipped[0]['reason'])
    def test_push_records_once_and_never_replans(self):
        self.engine.external_manual({'keys':self.amood,'dueDate':due(1)})
        self.c.start_amood_push(None);self.c.thread.join(4);st=self.c.status()
        self.assertEqual(st['phase'],'done',st);self.assertIn('발송 처리 2건',st['message'])
        self.assertFalse(self.calls[0][1])
        log=self.store.read()['amoodPushLog'];self.assertEqual(sorted(p['orderId'] for p in log),['2307473','2325592'])
        notes=[n for n in self.store.read()['notices'] if any('아무드 배송지연 메시지 발송 처리 완료' in e.get('note','') for e in n.get('events',[]))]
        self.assertTrue(notes)
        self.assertEqual(plan_amood(self.store.read(),None,today()),([],[]))
    def test_preview_never_records(self):
        self.c.start_amood_preview('2307473',due(3));self.c.thread.join(4);st=self.c.status()
        self.assertEqual(st['phase'],'done',st);self.assertIn('발송하지 않았습니다',st['message'])
        self.assertTrue(self.calls[0][1]);self.assertEqual(self.calls[0][0][0]['option'],'3일 이내')
        self.assertNotIn('amoodPushLog',self.store.read())
        with self.assertRaises(AblySyncError):self.c.start_amood_preview('abc',due(3))
    def test_keys_filter(self):
        self.engine.external_manual({'keys':self.amood,'dueDate':due(1)})
        k=[r['key'] for r in self.rows if r['orderId']=='2325592' and r['seller']==AMOOD]
        targets,_=plan_amood(self.store.read(),k,today());self.assertEqual([t['orderId'] for t in targets],['2325592'])

    def test_jasamol_blocked_for_message_less_notice(self):
        from external_notices import ExternalError
        jasa=[r['key'] for r in self.rows if r['seller']=='누아브 자사몰']
        with self.assertRaises(ExternalError) as cm:self.engine.external_manual({'keys':self.amood+jasa,'dueDate':due(1)})
        self.assertIn('자사몰 주문건이 끼어있습니다. 자사몰을 해제 후 보내주세요.',str(cm.exception))
        self.assertFalse([n for n in self.store.read()['notices'] if set(n.get('itemKeys',[]))&set(jasa)])
        self.assertIn('자사몰을 해제 후',open(Path(ROOT)/'web'/'app.js',encoding='utf-8').read())

class RowMatchTests(unittest.TestCase):
    def test_rows_of_matches_order_number_cell_only(self):
        p=AmoodPusher(MagicMock(),MagicMock(),lambda m:None)
        d={'headers':['','결제일','상품주문번호','주문번호','상품명','배송지연메시지발송여부'],
           'rows':[{'cells':['','x','2307473','111','A\n에이블리 상품상세','미발송'],'checked':False},
                   {'cells':['','x','7605204','2307473','숏 더블 크롭 코트 자켓\n에이블리 상품상세','미발송'],'checked':True}]}
        rows=p.rows_of(d,'2307473')
        self.assertEqual(rows,[{'itemId':'7605204','notice':'미발송','checked':True,'product':'숏 더블 크롭 코트 자켓'}])
        self.assertEqual(order_key(' 2307 473 '),'2307473')

class AmoodDetailIdTests(Base):
    def setUp(self):
        super().setUp()
        with self.store.edit() as s:s['rows']=[];s['settings']['shopName']='누아브'
        self.engine.import_rows({'rows':[order(1)|{'orderId':'2318744','seller':AMOOD,'orderItemId':'7638420','product':'베이직 쉬폰 스카프'},
                                         order(2)|{'orderId':'2318744','seller':AMOOD,'orderItemId':'7638421','product':'코트'}]})
        self.rows=[r for r in self.store.read()['rows'] if r['seller']==AMOOD]
    def test_import_keeps_amood_detail_ids(self):
        self.assertEqual(sorted(p['id'] for r in self.rows for p in r['orderItems']),['7638420','7638421'])
    def test_plan_carries_detail_ids(self):
        self.engine.external_manual({'keys':[self.rows[0]['key']],'dueDate':due(2)})
        t,_=plan_amood(self.store.read(),None,today());self.assertEqual(t[0]['itemIds'],[self.rows[0]['orderItems'][0]['id']])
    def test_detail_mismatch_is_held_not_sent(self):
        p=AmoodPusher(MagicMock(),MagicMock(is_set=lambda:False),lambda m:None)
        p.find_rows=lambda oid:[{'itemId':'9999999','notice':'미발송','checked':False,'product':'x'}]
        r=p.run_order({'orderId':'2318744','itemIds':['7638420'],'option':'내일','dueDate':due(1),'reason':'x'})
        self.assertEqual(r['status'],'skipped');self.assertIn('주문상세번호 불일치',r['reason'])

class AfterSendTests(unittest.TestCase):
    def pusher(self,verified):
        p=AmoodPusher(MagicMock(is_closed=lambda:False),MagicMock(is_set=lambda:False),lambda m:None)
        p.open=lambda:None;p.close_dialog=lambda:None;p.clear_checks=lambda:None;p.verify_sent=lambda t:verified
        def boom(t,preview=False):
            p.clicked=True;raise TimeoutError('Locator.click: Timeout 5000ms exceeded.')
        p.run_order=boom;return p
    def test_error_after_send_but_list_shows_sent_counts_as_sent(self):
        r=self.pusher('1차 발송').run([{'orderId':'2318744'},{'orderId':'2325592'}])
        self.assertEqual([x['status'] for x in r],['sent','sent']);self.assertIn('발송 표시 확인',r[0]['note'])
    def test_error_after_send_unverified_stops_the_rest(self):
        r=self.pusher('').run([{'orderId':'2318744'},{'orderId':'2325592'}])
        self.assertEqual([x['status'] for x in r],['failed','skipped'])
    def test_search_type_must_be_order_number_before_typing(self):
        src=(ROOT/'amood_push.py').read_text(encoding='utf-8')
        self.assertIn("raise AblySyncError('검색 기준이 주문번호가 아닙니다.')",src)
        self.assertIn('self.page.wait_for_timeout(600)',src)

class QueueWhenBusyTests(unittest.TestCase):
    def test_busy_queues_instead_of_error(self):
        from desktop import DesktopAPI
        from types import SimpleNamespace
        rows=[{'key':'A','seller':'누아브 에이블리'},{'key':'M','seller':AMOOD}]
        queued=[]
        fake=SimpleNamespace(_engine=SimpleNamespace(store=SimpleNamespace(read=lambda:{'settings':{},'rows':rows})),
            _after_busy=lambda exclude='':True,_ably_controller=lambda:None,_zigzag_controller=lambda:None,
            _queue_chain=lambda steps:queued.append([n for n,_ in steps]))
        note=DesktopAPI._auto_ably_push(fake,['A','M'])
        self.assertEqual(queued,[['에이블리','아무드']]);self.assertIn('대기열',note)

if __name__=='__main__':unittest.main()
