import copy
from helpers import Base, sample_rows
from domain import SELLERS,ValidationError,Store,Engine
from branding import import_seller

class ImportScopeTests(Base):
    def scoped(self,rows,scope=None,**kw):
        scope=scope if scope is not None else [SELLERS[0]]
        self.engine.configure_import_scope({'scope':scope})
        p=dict(rows=rows,scope=scope,mode='snapshot',scopeFilter=True,shopRevision=self.store.read()['settings']['shopRevision'],replaceConfirmed=True)
        p.update(kw);return self.engine.import_rows(p)
    def order(self,channel='에이블리',shop='데모스토어',**kw):
        r=sample_rows()[0]|dict(orderId='SCOPED',seller='누아브 '+channel,sourceSeller=shop+' '+channel)
        r.update(kw);return r
    def test_setting_persists_after_database_reopen_and_keeps_business_data(self):
        before=copy.deepcopy(self.store.read())
        self.engine.configure_import_scope({'scope':[SELLERS[2]]})
        for k in ('rows','notices','imports','supply'):self.assertEqual(self.store.read().get(k),before.get(k))
        self.store.close();self.store=Store(self.tmp.name);self.restart()
        self.assertEqual(self.engine.public_state()['settings']['importScope'],[SELLERS[2]])
    def test_empty_selection_is_saved_and_never_defaults_to_all(self):
        self.engine.configure_import_scope({'scope':[]});self.restart()
        self.assertEqual(self.store.read()['settings']['importScope'],[])
        with self.assertRaises(ValidationError):self.scoped([],scope=[],emptyConfirmed=True)
    def test_all_seller_file_filters_other_shop_and_unchecked_channels_before_validation(self):
        before=copy.deepcopy(self.store.read()['rows'])
        res=self.scoped([self.order(),self.order(shop='앤로랑',qty=-1),self.order(shop='누아브',qty=-1),self.order(channel='자사몰',qty=-1)])
        self.assertEqual(res['added'],1)
        after=self.store.read()['rows'];self.assertEqual(after[:len(before)],before)
        self.assertEqual(after[-1]['orderId'],'SCOPED')
    def test_unselected_channel_reservation_survives_snapshot(self):
        n=copy.deepcopy(self.queue())
        self.scoped([self.order()])
        self.assertEqual(self.last(),n)
        self.assertTrue(all(r['active'] for r in self.store.read()['rows']))
    def test_selected_empty_confirmation_required_and_other_channels_retained(self):
        self.engine.import_rows({'rows':[self.order()]})
        before=copy.deepcopy(self.store.read()['rows'])
        with self.assertRaises(ValidationError):self.scoped([])
        self.assertEqual(self.store.read()['rows'],before)
        self.scoped([],emptyConfirmed=True)
        self.assertEqual([r['active'] for r in self.store.read()['rows']],[True,True,True,False])
    def test_merge_obeys_same_selection_without_removing_existing(self):
        res=self.scoped([self.order(),self.order(channel='지그재그')],mode='merge')
        self.assertEqual(res['added'],1);self.assertEqual(res['inactive'],0)
    def test_stale_scope_or_shop_revision_is_rejected_without_order_mutation(self):
        self.engine.configure_import_scope({'scope':[SELLERS[0]]})
        before=copy.deepcopy(self.store.read()['rows'])
        p=dict(rows=[self.order()],scope=[SELLERS[1]],scopeFilter=True,mode='merge',shopRevision=1)
        with self.assertRaises(ValidationError):self.engine.import_rows(p)
        p['scope']=[SELLERS[0]];p['shopRevision']=-1
        with self.assertRaises(ValidationError):self.engine.import_rows(p)
        self.assertEqual(self.store.read()['rows'],before)
    def test_missing_original_seller_cannot_bypass_filter(self):
        r=self.order();del r['sourceSeller']
        with self.assertRaises(ValidationError):self.scoped([r])
    def test_invalid_scope_values_are_rejected(self):
        for scope in [None,True,'에이블리',[True],['없는몰'],[SELLERS[0],SELLERS[0]]]:
            with self.assertRaises(ValidationError):self.engine.configure_import_scope({'scope':scope})
    def test_shop_matching_is_exact_not_substring_or_legacy_alias(self):
        self.assertEqual(import_seller('메이아워 에이블리','메이아워'),SELLERS[0])
        for label in ['앤로랑 에이블리','누아브 에이블리','뉴메이아워 에이블리']:
            self.assertIsNone(import_seller(label,'메이아워'))
