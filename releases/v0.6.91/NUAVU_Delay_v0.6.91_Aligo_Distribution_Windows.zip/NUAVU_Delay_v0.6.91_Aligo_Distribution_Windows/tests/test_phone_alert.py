"""2026-10-23 아이폰 알림 (아이메시지): 사장님이 적어 준 시험 항목 그대로."""
import json,sys,tempfile,threading,time,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import phone_alert as pa

class Clock:
    def __init__(self):self.t=1_800_000_000.0
    def __call__(self):return self.t

def red(i=1,code='DELIVERY_FAILED'):return {'id':f'a{i}','noticeId':f'n{i}','code':code,'level':'error','message':f'전송 실패 {i}','at':'x'}
def job(title='에이블리 동기화 실패',msg='로그인 풀림',level='error'):return {'id':'j','noticeId':'','code':'JOB_FAILED','job':True,'title':title,'level':level,'message':msg}

class Base(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.d=Path(self.tmp.name);self.sent=[];self.clock=Clock()
        self.n=pa.PhoneAlerts(self.d,sender=lambda to,text:self.sent.append((to,text)),platform='darwin',clock=self.clock,delay=0)
    def tearDown(self):self.tmp.cleanup()
    def on(self,to='010-1234-5678'):self.n.save(True,to)

class RuleTests(Base):
    def test_normalize(self):
        self.assertEqual(pa.normalize_to('010-1234-5678'),'+821012345678');self.assertEqual(pa.normalize_to(' Boss@iCloud.com '),'boss@icloud.com')
        self.assertEqual(pa.normalize_to('+82 10 1234 5678'),'+821012345678')
        with self.assertRaisesRegex(pa.PhoneAlertError,'9자리'):pa.normalize_to('010-123')
        self.on();self.assertEqual(json.loads((self.d/'phone_alert.json').read_text()),{'enabled':True,'to':'+821012345678'})
    def test_off_or_empty_sends_nothing(self):
        self.n.process(red());self.assertEqual(self.sent,[])
        self.n.save(False,'010-1234-5678');self.n.process(red());self.assertEqual(self.sent,[])
        with self.assertRaisesRegex(pa.PhoneAlertError,'받는 곳'):self.n.save(True,'')
    def test_one_red_alert_one_message_and_repeat_stays_one(self):
        self.on();self.n.process(red());self.n.process(red())
        self.assertEqual(len(self.sent),1);self.assertEqual(self.sent[0],('+821012345678','[누아브 배송안내] 전송 실패 확정\n전송 실패 1'))
        self.n.process(job());self.n.process(job());self.assertEqual(len(self.sent),2)
        self.assertTrue(self.sent[1][1].startswith('[누아브 배송안내] 에이블리 동기화 실패\n로그인 풀림'))
        self.clock.t+=7*3600;self.n.process(job());self.assertEqual(len(self.sent),3)   # 같은 막힘이 6시간 뒤 또 생기면 다시 알림
    def test_green_and_transient_alerts_send_nothing(self):
        self.on();self.n.process(job(title='작업완료!',level='info'));self.n.process(red(code='RESULT_UNCONFIRMED_15S')|{'level':'warning'})
        self.assertEqual(self.sent,[])
        self.n.process(red(2,'REQUEST_UNKNOWN')|{'level':'warning'});self.assertEqual(len(self.sent),1)   # 확인 필요(주황)도 문제로 보냄
    def test_content_trimmed_to_300(self):
        self.on();self.n.process(red()|{'message':'가'*500});self.assertEqual(len(self.sent[0][1].split('\n',1)[1]),300)
    def test_hourly_cap_20_then_resumes(self):
        self.on()
        for i in range(25):self.n.process(red(i))
        self.assertEqual(len(self.sent),20)
        self.clock.t+=3601;self.n.process(red(30));self.assertEqual(len(self.sent),21)
        self.n.process(red(21));self.assertEqual(len(self.sent),22)   # 넘쳐서 버린 알림은 기록하지 않았으므로 새로 생기면 보냄
    def test_failure_keeps_app_running_and_shows_reason(self):
        errors=[]
        def boom(to,text):raise pa.PhoneAlertError('메시지 앱 제어 권한이 없습니다. '+pa.AUTOMATION_HELP)
        n=pa.PhoneAlerts(self.d,sender=boom,platform='darwin',clock=self.clock,delay=0,on_error=lambda *a:errors.append(a))
        n.save(True,'010-1234-5678');n.process(red())
        s=n.status();self.assertFalse(s['last']['ok']);self.assertIn('자동화에서 허용',s['last']['error']);self.assertEqual(errors[0][0],'아이폰 알림 보내기 실패')
    def test_windows_is_disabled(self):
        n=pa.PhoneAlerts(self.d,sender=lambda *a:self.fail('sent'),platform='win32',delay=0)
        self.assertFalse(n.status()['supported']);self.assertEqual(n.status()['unsupportedReason'],'아이메시지는 Mac 버전에서만 됩니다')
        with self.assertRaisesRegex(pa.PhoneAlertError,'Mac 버전'):n.save(True,'010-1234-5678')
        with self.assertRaisesRegex(pa.PhoneAlertError,'Mac 버전'):n.send_test('010-1234-5678')
    def test_test_message(self):
        self.on();self.n.send_test();self.assertEqual(self.sent[-1],('+821012345678',pa.TEST_TEXT))
    def test_mac_osascript_arguments_and_permission_error(self):
        class R:returncode=1;stdout='';stderr='execution error: Not authorized to send Apple events to Messages. (-1743)'
        with patch('phone_alert.subprocess.run',return_value=R()) as run:
            with self.assertRaisesRegex(pa.PhoneAlertError,'자동화에서 허용'):pa.mac_send('+821012345678','hi')
        args=run.call_args[0][0];self.assertEqual(args[:2],['/usr/bin/osascript','-e']);self.assertEqual(args[3:],['+821012345678','hi'])
        self.assertIn('service type = iMessage',args[2])

class AppHookTests(unittest.TestCase):
    """앱이 알림을 저장하는 그 자리(add_alert · add_job_alert)에서 offer가 불리고, 백그라운드로 보낸다."""
    def test_engine_alerts_reach_phone_in_background(self):
        try:
            from test_v056 import Base as EB
        except ImportError:
            from helpers import Base as EB
        class T(EB):
            def runTest(inner):pass
        t=T();t.setUp()
        try:
            sent=[];gate=threading.Event()
            def slow(to,text):gate.wait(5);sent.append(text)
            n=pa.install(pa.PhoneAlerts(t.store.directory,sender=slow,platform='darwin',delay=0,
                exists=lambda aid:any(a.get('id')==aid for a in t.store.read().get('alerts',[]))))
            n.save(True,'010-1234-5678')
            started=time.monotonic();t.engine.add_job_alert('주문 불러오기 막힘','이지어드민 로그인 풀림','error')
            self.assertLess(time.monotonic()-started,1.0)   # 화면(호출한 쪽)은 기다리지 않는다
            t.engine.add_job_alert('작업완료! 주문 불러오기','12건','info')
            gate.set();n.thread.join(5)
            self.assertEqual(sent,['[누아브 배송안내] 주문 불러오기 막힘\n이지어드민 로그인 풀림'])
            r=t.engine.phone_alert({'action':'status'});self.assertTrue(r['enabled']);self.assertTrue(r['last']['ok'])
        finally:
            pa.install(None);t.tearDown()

if __name__=='__main__':unittest.main()
