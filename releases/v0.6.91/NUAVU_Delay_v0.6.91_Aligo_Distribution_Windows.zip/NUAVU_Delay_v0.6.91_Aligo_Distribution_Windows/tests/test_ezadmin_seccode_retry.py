"""2026-10-21: 이지어드민 보안코드 화면은 입력하지 않고 다음 페이지로, 시간 초과는 30초 간격 3회 재시도 후 오류+알림."""
import sys,unittest
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT)]
import order_browser as ob
from order_auto import OrderAutoError

class RetryRuleTests(unittest.TestCase):
    def test_retryable(self):
        f=SimpleNamespace(export_requested=False,step='주문 검색조건 설정')
        class TimeoutError(Exception):pass
        self.assertTrue(ob.retryable_timeout(TimeoutError('x'),f))
        self.assertTrue(ob.retryable_timeout(ob.StepTimeout('조회가 완료되지 않았습니다.'),f))
        self.assertFalse(ob.retryable_timeout(OrderAutoError('조회 결과가 0건입니다.'),f))
        self.assertFalse(ob.retryable_timeout(TimeoutError('x'),SimpleNamespace(export_requested=True,step='주문 엑셀 신청')))
        self.assertFalse(ob.retryable_timeout(TimeoutError('x'),SimpleNamespace(export_requested=False,step='로그인 결과 확인')))
        self.assertEqual((ob.RETRY_TIMES,ob.RETRY_WAIT),(3,30))
        self.assertTrue(issubclass(ob.StepTimeout,OrderAutoError))
    def test_source_wiring(self):
        src=(ROOT/'order_browser.py').read_text(encoding='utf-8')
        self.assertIn("raise StepTimeout(message)",src)
        self.assertIn("alert('이지어드민 주문 불러오기 실패'",src)
        self.assertIn('다음 페이지에도 보안코드 입력 화면이 나와 중단했습니다',src)
        self.assertIn('_order_auto.alert=',(ROOT/'desktop.py').read_text(encoding='utf-8'))
        # the code is never typed: no fill/press on a 보안코드 field anywhere
        self.assertNotRegex(src,r'보안코드[^\n]*\.fill\(')

class SeccodeDetectTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            from playwright.sync_api import sync_playwright
            cls.pw=sync_playwright().start();cls.browser=cls.pw.chromium.launch()
        except Exception as exc:raise unittest.SkipTest(f'chromium unavailable: {exc}')
    @classmethod
    def tearDownClass(cls):
        cls.browser.close();cls.pw.stop()
    def check(self,body):
        page=self.browser.new_page();page.set_content(body)
        try:return page.evaluate(ob.SECCODE_JS)
        finally:page.close()
    def test_detects_visible_code_input(self):
        self.assertTrue(self.check('<div><p>보안코드를 입력하세요</p><input type="text" id="sec"><button>확인</button></div>'))
    def test_ignores_text_without_input_or_hidden(self):
        self.assertFalse(self.check('<div><a>보안코드 설정 안내</a></div><a href="/logout.php">로그아웃</a>'))
        self.assertFalse(self.check('<div style="display:none"><p>보안코드</p><input type="text"></div>'))
        self.assertFalse(self.check('<div><p>보안코드</p><input type="hidden"></div>'))

if __name__=='__main__':unittest.main()
