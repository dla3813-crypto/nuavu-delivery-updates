"""09:05 요청: 유휴 CPU 최적화 — 저장소 revision 미러, 변경 없을 때 1초 작업 스캔 생략(2초), /api/version 으로 가벼운 변경 확인."""
import unittest
from unittest.mock import patch
from domain import WORKER_IDLE_SECONDS
try:from test_v056 import Base
except ImportError:from helpers import Base

class IdleWorker(Base):
    def test_version_mirror_and_idle_skip(self):
        v=self.store.version;self.assertEqual(v,self.store.read()['revision'])
        with self.store.edit() as s:s['audits'].append({'at':'x','event':'t'})
        self.assertEqual(self.store.version,v+1);self.assertEqual(self.store.version,self.store.read()['revision'])
        calls=[]
        with patch.object(self.engine,'send_one',side_effect=lambda:calls.append(1) or False):
            for _ in range(5):self.engine.worker_tick()
            self.assertEqual(len(calls),1)                       # idle: scanned once, then skipped within WORKER_IDLE_SECONDS
            with self.store.edit() as s:s['audits'].append({'at':'y','event':'u'})
            self.engine.worker_tick();self.assertEqual(len(calls),2)   # a change wakes the scan at once
            self.engine._idle_until=0;self.engine.worker_tick();self.assertEqual(len(calls),3)   # and so does the idle timer
        self.assertLessEqual(WORKER_IDLE_SECONDS,2.0)   # 09:00 예약은 2초 안에 시작
    def test_version_endpoint_and_ui_gating_present(self):
        import inspect,app
        from pathlib import Path
        src=inspect.getsource(app)
        self.assertIn("path=='/api/version'",src);self.assertIn("state['stateVersion']=self.server.engine.store.version",src)
        js=(Path(app.__file__).resolve().parent/'web'/'app.js').read_text(encoding='utf-8')
        self.assertIn("api('version')",js);self.assertIn("v.version!==state?.stateVersion",js);self.assertNotIn("setInterval(()=>{if(!busy)refresh();},3500)",js)
if __name__=='__main__':unittest.main()
