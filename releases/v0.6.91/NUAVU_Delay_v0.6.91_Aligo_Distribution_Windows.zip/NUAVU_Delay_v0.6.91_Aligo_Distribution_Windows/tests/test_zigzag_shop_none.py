"""2026-10-23 19:03 보고: 지그재그 로그인 뒤 https://partners.kakaostyle.com/shop/None/stats 로 들어가던 문제 (v0.6.91/0.6.86 회귀)."""
import sys,unittest
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import zigzag_browser as zb

class FakeContext:
    def new_page(self):return SimpleNamespace(context=self)

class ShopKeptTests(unittest.TestCase):
    def test_claims_keep_shop_after_reader_init(self):
        from zigzag_returns import ZigzagClaims
        c=SimpleNamespace(stop=SimpleNamespace(is_set=lambda:False),update=lambda *a:None)
        flow=ZigzagClaims(c,FakeContext(),'nuavu')
        self.assertEqual(flow.shop,'nuavu')
    def test_cancel_flow_keeps_shop(self):
        from soldout_cancel import _zz_flow_class
        c=SimpleNamespace(stop=SimpleNamespace(is_set=lambda:False),update=lambda *a:None)
        self.assertEqual(_zz_flow_class()(c,FakeContext(),'nuavu').shop,'nuavu')
    def test_plain_reader_starts_without_shop(self):
        self.assertIsNone(zb.Reader(SimpleNamespace(context=None),None,lambda m:None).shop)

if __name__=='__main__':unittest.main()
