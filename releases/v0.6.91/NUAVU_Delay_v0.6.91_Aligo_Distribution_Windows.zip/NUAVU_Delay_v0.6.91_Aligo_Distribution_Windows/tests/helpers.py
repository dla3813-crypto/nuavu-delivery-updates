"""Synthetic orders, isolated temporary DB, memory vault, fake Aligo HTTP.
No real account, customer, Keychain write or live send is used in these tests.
"""
import copy, tempfile, unittest
from datetime import datetime,timedelta,timezone
from unittest.mock import patch
from domain import Store,Engine,KST,FIRST,today,now,parse_time
from provider import AligoSMS,UncertainError,ProviderError

class MemoryVault:
    name='test-memory';available=True
    def __init__(self):self.value=None
    def load(self):return copy.deepcopy(self.value)
    def save(self,value):self.value=copy.deepcopy(value)
    def delete(self):self.value=None

class Clock(datetime):
    current=datetime(2026,10,14,10,tzinfo=KST)
    @classmethod
    def now(cls,tz=None):return cls.current.astimezone(tz) if tz else cls.current.replace(tzinfo=None)

class FakeSMS(AligoSMS):
    def __init__(self):
        self.calls=[];self.sent=[];self.report_calls=[];self.result='발송완료';self.empty=False
        self.report_error=False;self.duplicate=False;self.error=None;self.response_override=None;self.row_override={}
        super().__init__(self.transport_fake)
    def transport_fake(self,path,fields):
        self.calls.append((path,copy.deepcopy(fields)))
        if path=='/send/':
            if self.error:raise self.error
            mid=str(1000+len(self.sent))
            self.sent.append({'mid':mid,'fields':copy.deepcopy(fields)})
            return self.response_override or {'result_code':1,'msg_id':mid,'success_cnt':1,'error_cnt':0,'msg_type':fields['msg_type']}
        if path=='/remain/':return {'result_code':1,'SMS_CNT':'1234','LMS_CNT':'432'}
        if path=='/sms_list/':
            self.report_calls.append(fields['mid'])
            if self.report_error:raise UncertainError('synthetic query error')
            entry=next((r for r in self.sent if r['mid']==fields['mid']),None)
            if self.empty or not entry:return {'result_code':1,'list':[],'next_yn':'N'}
            f=entry['fields'];row={'mdid':str(int(entry['mid'])+9000),'type':f['msg_type'],'sender':f['sender'],
                'receiver':f['receiver'],'sms_state':self.result,'reg_date':now(),'send_date':now(),'reserve_date':''}
            row.update(self.row_override)
            return {'result_code':1,'list':[row,row.copy()] if self.duplicate else [row],'next_yn':'N'}
        raise AssertionError('Unexpected fake endpoint: '+path)

class FakeAT:
    def __init__(self):self.sent=[];self.calls=[];self.result='정상 발송';self.empty=False;self.smid='0';self.body=None;self.error=None;self.buttons=[]
    def template(self,cred,code):
        self.calls.append(('template',code))
        from branding import render_template
        return {'code':code,'name':'배송 안내','body':self.body or render_template(FIRST,'데모스토어').replace('{상품목록}','#{상품명}').replace('{출고예정일}','#{출고예정일}'),
                'buttons':copy.deepcopy(self.buttons),'emtitle':'','verified':True}
    def send(self,cred,notice):
        if self.error:raise self.error
        mid=str(5000+len(self.sent));self.sent.append(copy.deepcopy(notice)|{'mid':mid});return mid
    def detail(self,cred,mid):
        self.calls.append(('detail',mid))
        if self.empty:return []
        n=next(x for x in self.sent if x['mid']==mid)
        return [{'type':'AT','phone':n['phone'],'sender':n['sender'],'tpl_code':n['aligoCode'],'message':n['content'],
                 'senderKey':cred.senderkey,'msgid':'900','status':'3','rslt':'1000','rslt_message':self.result,
                 'rsltdate':now(),'smid':self.smid}]

def sample_rows():
    common=dict(seller='누아브 자사몰',orderId='TEST-001',qty=1,orderDate=today(),buyer='가상 고객',recipient='',phone='01000001234',phoneSource='주문자',needsPhoneApproval=False)
    return [common|dict(product='리본 티셔츠',option='블랙 / FREE'), common|dict(product='데님 팬츠',option='블루 / M'),
        common|dict(seller='누아브 지그재그',orderId='TEST-002',product='가디건',option='크림',qty=2,phone='01000001235',buyer='가상 고객2')]

class Base(unittest.TestCase):
    def setUp(self):
        Clock.current=datetime(2026,10,14,10,tzinfo=KST)
        self.patch=patch('domain.datetime',Clock);self.patch.start();self.addCleanup(self.patch.stop)
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(self.tmp.name)
        self.fake=FakeSMS();self.vault=MemoryVault();self.at=FakeAT();self.atvault=MemoryVault()
        self.engine=Engine(self.store,self.fake,self.vault,aligo_provider=self.at,aligo_vault=self.atvault)
        self.engine.configure_shop({'shopName':'데모스토어'})
        self.engine.configure({'user':'DEMO','apikey':'FAKE-KEY-OFFLINE-ONLY','sender':'0212345678'})
        self.engine.import_rows({'rows':sample_rows(),'mode':'merge'})
    def tearDown(self):self.store.close();self.tmp.cleanup()
    def data(self,**kw):
        p={'keys':[r['key'] for r in self.store.read()['rows'][:2]],'sendMode':'IMMEDIATE','dueDate':'2026-10-21',
           'template':FIRST,'kind':'LMS','title':'데모스토어 안내','templateKey':'first'};p.update(kw);return p
    def queue(self,**kw):
        p=self.engine.preview(self.data(**kw));self.engine.commit({'token':p['token']});return self.last()
    def send(self,**kw):self.queue(**kw);self.assertTrue(self.engine.send_one());return self.last()
    def last(self):return self.store.read()['notices'][-1]
    def row(self):return self.engine.public_state()['rows'][0]
    def restart(self):self.engine=Engine(self.store,self.fake,self.vault,aligo_provider=self.at,aligo_vault=self.atvault)
    def at_age(self,n,hours=0,seconds=0):Clock.current=parse_time(n.get('acceptedAt') or n['attemptedAt'])+timedelta(hours=hours,seconds=seconds)
    def clock(self,hour,day=14,minute=0,second=0):Clock.current=datetime(2026,10,day,hour,minute,second,tzinfo=KST)
    def setup_at(self):
        self.engine.configure_aligo({'user':'DEMO-AT','apikey':'FAKE-AT-KEY','senderkey':'FAKE-SENDER-KEY','sender':'0212345678',
              'enabled':True,'templateCodes':{'first':'DEMO_FIRST','change':'DEMO_CHANGE'}})
        return self.engine.refresh_aligo_templates()
