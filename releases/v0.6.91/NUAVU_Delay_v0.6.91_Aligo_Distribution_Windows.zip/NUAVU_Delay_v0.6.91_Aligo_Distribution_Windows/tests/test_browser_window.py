"""Minimized automation Chrome: CDP window state calls, attention/calm, and the persisted setting."""
import unittest
import browser_window as bw
from helpers import Base

class FakeSession:
    def __init__(self,log):self.log=log
    def send(self,method,params=None):
        self.log.append((method,(params or {}).get('bounds',{}).get('windowState')))
        return {'windowId':7} if method=='Browser.getWindowForTarget' else {}
    def detach(self):pass
class FakePage:
    def __init__(self,context):self.context=context;self.closed=False;self.front=0
    def is_closed(self):return self.closed
    def bring_to_front(self):self.front+=1
class FakeContext:
    def __init__(self):self.pages=[];self.handlers=[];self.log=[]
    def on(self,event,fn):self.handlers.append(fn)
    def new_cdp_session(self,page):return FakeSession(self.log)
    def open(self):
        p=FakePage(self);self.pages.append(p)
        for h in self.handlers:h(p)
        return p
def states(ctx):return [s for m,s in ctx.log if m=='Browser.setWindowBounds']

class WindowTests(unittest.TestCase):
    def setUp(self):bw.configure(False)
    def tearDown(self):bw.configure(False)
    def test_disabled_never_touches_windows(self):
        ctx=FakeContext();self.assertFalse(bw.attach(ctx));ctx.open();bw.reminimize(ctx.pages[0]);self.assertEqual(ctx.log,[])
    def test_enabled_minimizes_existing_and_new_pages(self):
        bw.configure(True,False);ctx=FakeContext();p0=ctx.open();self.assertTrue(bw.attach(ctx));p1=ctx.open()
        self.assertEqual(states(ctx),['minimized','minimized'])
        bw.reminimize(p1);self.assertEqual(states(ctx)[-1],'minimized')
    def test_attention_restores_and_blocks_reminimize_until_calm(self):
        bw.configure(True,False);ctx=FakeContext();bw.attach(ctx);p=ctx.open()
        bw.attention();self.assertEqual(states(ctx)[-1],'normal');self.assertEqual(p.front,1)
        bw.reminimize(p);self.assertEqual(states(ctx)[-1],'normal')   # person is looking: stay visible
        q=ctx.open();self.assertEqual(states(ctx)[-1],'normal')        # popups during attention stay visible too
        bw.calm();self.assertEqual(states(ctx)[-1],'minimized')
    def test_cdp_failure_is_swallowed(self):
        bw.configure(True,False)
        class Broken(FakeContext):
            def new_cdp_session(self,page):raise RuntimeError('no cdp')
        ctx=Broken();bw.attach(ctx);ctx.open();bw.attention();bw.calm()  # no exception

class SettingTests(Base):
    def tearDown(self):bw.configure(False);super().tearDown()
    def test_headless_setting_persists_and_configures(self):
        self.assertFalse(bw.HEADLESS);self.assertFalse(self.store.read()['settings'].get('headlessChrome',False))
        self.assertEqual(bw.launch_kwargs(),{'channel':'chrome','headless':False,'chromium_sandbox':True});self.assertEqual(bw.need_person(),'')
        r=self.engine.set_browser_window({'headlessChrome':True});self.assertTrue(r['headlessChrome']);self.assertTrue(bw.HEADLESS)
        self.assertTrue(bw.launch_kwargs()['headless']);self.assertIn('헤드리스',bw.need_person())
        self.assertTrue(self.store.read()['settings']['headlessChrome']);self.assertTrue(self.engine.public_state()['settings']['headlessChrome'])
        self.restart();self.assertTrue(bw.HEADLESS)   # loaded again at startup
        self.engine.set_browser_window({});self.assertFalse(bw.HEADLESS);self.assertFalse(bw.ENABLED)
    def test_old_minimize_setting_is_dropped(self):
        with self.store.edit() as s:s['settings']['minimizeChrome']=True
        self.engine.set_browser_window({'headlessChrome':False});self.assertNotIn('minimizeChrome',self.store.read()['settings'])
    def test_attention_is_a_noop_when_headless(self):
        bw.configure(False,True);ctx=FakeContext();bw.attach(ctx);ctx.open();bw.attention();self.assertEqual(states(ctx),[])

if __name__=='__main__':unittest.main()
