"""Native launcher behavior; all OS commands replaced by temporary fixtures."""
from pathlib import Path
import json
import os
import plistlib
import shlex
import subprocess
import sys
import tempfile
import unittest
from install_desktop import build_bundle


class NativeLauncherTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='nuavu-native-')
        self.base = Path(self.tmp.name)
        self.calls = self.base / 'calls.jsonl'
        self.python = self.base / "실행 경로 'quoted'/python3"
        self.python.parent.mkdir()
        self.python.write_text('#!/bin/bash\nexit 0\n')
        self.python.chmod(0o755)
        self.bundle = build_bundle(self.base / 'Test.app', self.python)

    def tearDown(self):
        self.tmp.cleanup()

    def helper(self, name, code):
        p = self.base / name
        p.write_text('#!' + sys.executable + '\nimport sys,json,os\n' + code)
        p.chmod(0o755)
        return p

    def run_launcher(self, arm=True, valid=True, present=True):
        record = f"with open({str(self.calls)!r},'a') as f:f.write(json.dumps(sys.argv[1:])+chr(10))\n"
        sysctl = self.helper('sysctl', f'print({"1" if arm else "0"!r})\n')
        arch = self.helper('arch', record + f'sys.exit({0 if valid else 1})\n')
        alert = self.helper('alert', record)
        self.python.write_text('#!' + sys.executable + '\nimport sys,json\n' + record)
        if not present:
            self.python.unlink()
        p = self.bundle / 'Contents/MacOS/NUAVU'
        s = p.read_text().replace('/usr/sbin/sysctl', shlex.quote(str(sysctl))).replace('/usr/bin/arch', shlex.quote(str(arch))).replace('/usr/bin/osascript', shlex.quote(str(alert)))
        s=s.replace('LOGDIR="$HOME/Library/Logs/NUAVU Delay Distribution"','LOGDIR='+shlex.quote(str(self.base/'logs')))
        p.write_text(s)
        r = subprocess.run(['/bin/bash', str(p)], capture_output=True, text=True, timeout=20)
        calls = [json.loads(x) for x in self.calls.read_text().splitlines()] if self.calls.exists() else []
        return r, calls

    def test_bundle_prefers_native_architecture(self):
        info = plistlib.loads((self.bundle / 'Contents/Info.plist').read_bytes())
        self.assertEqual(info['LSArchitecturePriority'], ['arm64', 'x86_64'])

    def test_apple_silicon_preflight_then_native_exec_with_quoted_path(self):
        r, calls = self.run_launcher()
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[0][:4], ['-arm64', str(self.python), '-I', '-c'])
        self.assertIn('playwright.sync_api', calls[0][4])
        self.assertEqual(calls[1], ['-arm64', str(self.python), str(self.bundle / 'Contents/Resources/desktop.py')])

    def test_failed_native_dependencies_stop_before_app_and_database(self):
        r, calls = self.run_launcher(valid=False)
        self.assertEqual(r.returncode, 1)
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[1][0], '-e')
        self.assertIn('Apple Silicon', calls[1][1])
        self.assertFalse(any(any(a.endswith('/desktop.py') for a in c) for c in calls))

    def test_intel_retains_direct_python_launch(self):
        r, calls = self.run_launcher(arm=False)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(calls, [[str(self.bundle / 'Contents/Resources/desktop.py')]])

    def test_missing_python_keeps_existing_error_and_never_runs_app(self):
        r, calls = self.run_launcher(present=False)
        self.assertEqual(r.returncode, 1)
        self.assertEqual(len(calls), 1)
        self.assertIn('실행 구성요소가 없습니다', calls[0][1])

    def test_generated_launcher_shell_syntax(self):
        r = subprocess.run(['/bin/bash', '-n', str(self.bundle / 'Contents/MacOS/NUAVU')], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr)


if __name__ == '__main__':
    unittest.main()
