import copy,datetime as dt,io,threading,time,unittest
from unittest.mock import Mock,patch
from return_data import *
from return_check import ReturnController,KST
from helpers import Base,MemoryVault
from desktop import DesktopAPI
from factory_reset import operation_lock

TODAY=dt.date(2026,10,18)
def entry(**kw):
    return dict(key='test',requestedAt='2026-10-10',orderId='12345',itemId='123456',product='테스트 코트',option='화이트 FREE',customer='가상 고객',reason='구매자(단순변심)',invoice='510000000001',fee=0,**kw)
def track(**kw):
    return dict(carrier='CJ',orig_delivered='2026-10-04',return_no='520000000001',return_status='DELIVERED',return_delivered='2026-10-11')|kw
def rows_snapshot(**kw):return make_snapshot([entry()],{'510000000001':track(**kw)},1,TODAY)
def classified(**kw):return classify(rows_snapshot(**kw)['rows'][0],TODAY)
def xlsx(rows,headers=None):
    from test_supply_regression import xlsx as fixture
    values=[[((v.date()-dt.date(1899,12,30)).days if isinstance(v,dt.datetime) else v) for v in r] for r in rows]
    return fixture([('반품 진행 관리',[headers or list(HEADERS.values())]+values)])
def xlrow():return ['2026-10-10','가상 고객','구매자','510000000001',-3000,'12345','테스트 상품']

class DataTests(unittest.TestCase):
    def test_seven_days_green_eight_pink(self):
        self.assertEqual(classified()['category'],'arrived')
        self.assertEqual(classified(return_delivered='2026-10-10')['category'],'urgent')
    def test_late_boundary_and_precedence(self):
        self.assertEqual(classified(orig_delivered='2026-10-03')['category'],'arrived')
        r=classified(orig_delivered='2026-10-02',return_delivered='2026-10-10')
        self.assertEqual(r['category'],'late');self.assertTrue(r['urgent'])
    def test_blue_fee_and_seller(self):
        e=entry();e.update(fee=-3000,reason='판매자(상품에 문제가 있어요)')
        r=classify(make_snapshot([e],{e['invoice']:track(return_status='IN_TRANSIT',return_delivered='')},1,TODAY)['rows'][0],TODAY)
        self.assertEqual(r['category'],'transit');self.assertTrue(r['blueFee']);self.assertTrue(r['sellerReason'])
    def test_late_transit_fee_keeps_yellow_priority(self):
        e=entry();e['fee']=-3000
        row=e|clean_tracking(track(orig_delivered='2026-10-01',return_status='IN_TRANSIT',return_delivered=''),e['invoice'],TODAY)
        r=classify(row,TODAY);self.assertEqual(r['category'],'late');self.assertFalse(r['blueFee']);self.assertTrue(r['transitFee'])
        row['issue']='날짜 확인 필요';self.assertEqual(classify(row,TODAY)['category'],'unknown')
    def test_fee_without_tracking_and_none(self):
        e=entry();e['fee']=-3000
        raw={e['invoice']:track(return_status='NONE',return_no='',return_delivered='')}
        r=classify(make_snapshot([e],raw,1,TODAY)['rows'][0],TODAY);self.assertEqual((r['category'],r['logistics']),('fee','undelivered'))
        e['fee']=0;r=classify(make_snapshot([e],raw,1,TODAY)['rows'][0],TODAY);self.assertEqual(r['category'],'uncollected')
    def test_unknown_not_undelivered(self):
        r=clean_tracking({'error':'raw private site message'},'510000000001',TODAY)
        self.assertEqual(r['returnStatus'],'UNKNOWN');self.assertNotIn('private',r['issue'])
    def test_all_error_preserves(self):
        with self.assertRaises(ReturnError):make_snapshot([entry()],{'510000000001':{'carrier':'CJ','error':'HTTP'}},1,TODAY)
    def test_partial_error_separate_count(self):
        a=entry();b=entry();b.update(key='b',invoice='610000000001')
        snap=make_snapshot([a,b],{a['invoice']:track(),b['invoice']:{'carrier':'EPOST','error':'failed'}},2,TODAY)
        s={'settings':{'shopName':'테스트','shopRevision':1},'returnCheck':dict(shopName='테스트',shopRevision=1,rows=snap['rows'],lastChecked='test')}
        out=public_returns(s,TODAY);self.assertEqual(out['counts'],dict(arrived=1,transit=0,undelivered=0,unknown=1,total=2))
    def test_missing_carrier_and_invoice(self):
        self.assertTrue(clean_tracking({},'',TODAY)['issue']);self.assertEqual(carrier_of('110000000001'),'UNKNOWN')
    def test_invalid_future_dates_no_arrived(self):
        for raw in [track(return_delivered='2026-10-19'),track(return_delivered='bad'),track(return_no='bad'),track(return_status='weird')]:
            self.assertEqual(clean_tracking(raw,'510000000001',TODAY)['returnStatus'],'UNKNOWN')
    def test_named_headers_required(self):
        self.assertEqual(read_returns(xlsx([xlrow()]),1,TODAY)[0]['fee'],-3000)
        with self.assertRaises(ReturnError):read_returns(xlsx([xlrow()],['wrong']*7),1,TODAY)
    def test_option_and_qty_aliases(self):
        row=xlrow()+['화이트 FREE',2]
        parsed=read_returns(xlsx([row],list(HEADERS.values())+['옵션 정보','주문 수량']),1,TODAY)
        self.assertEqual(parsed[0]['option'],'화이트 FREE');self.assertEqual(parsed[0]['qty'],'2')
    def test_fee_query_error_remains_unknown(self):
        e=entry();e['fee']=-3000
        r=classify(e|clean_tracking({'error':'failure'},e['invoice'],TODAY),TODAY)
        self.assertEqual(r['category'],'unknown');self.assertTrue(r['feeFlag']);self.assertIsNone(r['daysAfterReturn'])
    def test_count_missing_and_duplicates(self):
        for raw,total in [(xlsx([xlrow()]),2),(xlsx([xlrow(),xlrow()]),2)]:
            with self.assertRaises(ReturnError):read_returns(raw,total,TODAY)
    def test_excel_dates_supported_and_zero(self):
        row=xlrow();row[0]=dt.datetime(2026,10,10)
        self.assertEqual(read_returns(xlsx([row]),1,TODAY)[0]['requestedAt'],'2026-10-10')
        self.assertEqual(read_returns(xlsx([]),0,TODAY),[])
    def test_header_reorder_and_bad_fee(self):
        row=xlrow();headers=list(HEADERS.values());self.assertEqual(read_returns(xlsx([list(reversed(row))],list(reversed(headers))),1,TODAY)[0]['orderId'],'12345')
        row[4]='미확인'
        with self.assertRaises(ReturnError):read_returns(xlsx([row]),1,TODAY)
    def test_day_reclassification(self):
        row=rows_snapshot()['rows'][0];self.assertEqual(classify(row,TODAY+dt.timedelta(days=1))['category'],'urgent')
    def test_shop_revision_hides_stale(self):
        s={'settings':{'shopName':'B','shopRevision':2},'returnCheck':dict(shopName='A',shopRevision=1,rows=rows_snapshot()['rows'])}
        self.assertEqual(public_returns(s,TODAY)['rows'],[]);self.assertTrue(public_returns(s,TODAY)['scopeChanged'])

class ControllerTests(Base):
    def setUp(self):
        super().setUp();self.accounts=MemoryVault();self.accounts.save(dict(version=1,username='test-only',password='synthetic-only'))
        self.now=dt.datetime(2026,10,18,10,0,tzinfo=KST)
        self.c=ReturnController(self.engine,runner=lambda a,c:rows_snapshot(),vault=self.accounts,clock=lambda:self.now)
    def tearDown(self):
        self.c.shutdown()
        if self.c.thread:self.c.thread.join(3)
        if self.c.scheduler_thread:self.c.scheduler_thread.join(3)
        super().tearDown()
    def run_job(self):self.c.start();self.c.thread.join(3);self.assertFalse(self.c.running())
    def test_atomic_success_and_unrelated_state_unchanged(self):
        before=copy.deepcopy(self.store.read());self.run_job();after=self.store.read()
        for k in ('rows','notices','settings','imports'):self.assertEqual(before[k],after[k])
        self.assertEqual(self.c.status()['phase'],'done');self.assertEqual(len(after['returnCheck']['rows']),1)
        self.assertEqual(len(self.fake.sent),0)
        self.assertNotIn('returnCheck',self.engine.public_state());self.assertIn('returns',self.engine.public_state())
    def test_cancellation_and_failure_preserve(self):
        self.run_job();before=self.store.read()['returnCheck']
        def fail(a,c):raise RuntimeError('password=secret')
        self.c.runner=fail;self.run_job();self.assertEqual(self.store.read()['returnCheck'],before);self.assertNotIn('secret',str(self.c.status()))
        def cancel(a,c):c.stop.set();return rows_snapshot()
        self.c.runner=cancel;self.run_job();self.assertEqual(self.store.read()['returnCheck'],before);self.assertEqual(self.c.status()['phase'],'cancelled')
    def test_empty_valid_snapshot_replaces(self):
        self.run_job();self.c.runner=lambda a,c:{'complete':True,'total':0,'rows':[]};self.run_job();self.assertEqual(self.c.status()['data']['rows'],[])
    def test_incomplete_does_not_replace(self):
        self.run_job();before=self.store.read()['returnCheck'];self.c.runner=lambda a,c:{'complete':False,'total':1,'rows':[]};self.run_job();self.assertEqual(self.store.read()['returnCheck'],before)
    def test_shop_change_prevents_commit(self):
        def run(a,c):
            with self.store.edit() as s:s['settings']['shopRevision']+=1
            return rows_snapshot()
        self.c.runner=run;self.run_job();self.assertNotIn('returnCheck',self.store.read());self.assertEqual(self.c.status()['phase'],'error')
    def test_default_manual_and_config_validation(self):
        self.assertFalse(self.c.tick());self.assertEqual(self.c.config()['mode'],'manual')
        for cfg in ({'mode':'daily','time':'24:00'},{'mode':'weekly','time':'09:00'},None):
            with self.assertRaises(ReturnError):self.c.save(cfg)
    def test_daily_once_restart_and_next_day(self):
        self.c.save(dict(mode='daily',time='10:01'));self.assertFalse(self.c.tick())
        self.now+=dt.timedelta(minutes=1);self.assertTrue(self.c.tick());self.c.thread.join(3);self.assertFalse(self.c.tick())
        other=ReturnController(self.engine,runner=lambda a,c:rows_snapshot(),vault=self.accounts,clock=lambda:self.now)
        self.assertFalse(other.tick());self.now+=dt.timedelta(days=1);self.assertTrue(other.tick());other.thread.join(3);other.shutdown()
    def test_daily_failed_account_not_retried(self):
        self.accounts.delete();self.c.save(dict(mode='daily',time='09:00'));self.assertTrue(self.c.tick());self.assertFalse(self.c.tick());self.assertEqual(self.c.status()['phase'],'error')
    def test_cancel_manual_can_run_again(self):
        self.c.cancel();self.run_job();self.assertEqual(self.c.status()['phase'],'done')
    def test_single_worker_and_busy_sync(self):
        entered=threading.Event();release=threading.Event()
        def block(a,c):entered.set();release.wait(2);return rows_snapshot()
        self.c.runner=block;self.c.start();entered.wait(2)
        with self.assertRaises(ReturnError):self.c.start()
        release.set();self.c.thread.join(3);self.c.busy=lambda:True
        with self.assertRaises(ReturnError):self.c.start()
    def test_reset_lock_tick_does_not_deadlock(self):
        results=[]
        with operation_lock(self.engine):
            th=threading.Thread(target=lambda:results.append(self.c.tick()));th.start();th.join(1)
            self.assertFalse(th.is_alive())
        self.assertEqual(results,[False])
    def test_login_continue_job_id(self):
        entered=threading.Event();release=threading.Event()
        def block(a,c):c.browser_failed('로그인 확인',True,True);entered.set();release.wait(2);return rows_snapshot()
        self.c.runner=block;s=self.c.start();entered.wait(2)
        with self.assertRaises(ReturnError):self.c.continue_login('old')
        self.c.continue_login(s['id']);self.assertEqual(self.c.take_browser_action(),('continue',None));release.set();self.c.thread.join(3)
    def test_native_auth_and_mutual_ably_lock(self):
        window=Mock();window.get_current_url.return_value='http://127.0.0.1:1234/'
        bridge=DesktopAPI(self.engine,'token','http://127.0.0.1:1234',Mock());bridge._window=window;bridge._returns=self.c
        self.assertIn('error',bridge.return_action('bad','start'))
        self.assertEqual(bridge.return_action('token','status')['settings']['mode'],'manual')
        window.get_current_url.return_value='https://example.com/';self.assertIn('error',bridge.return_action('token','status'))
    def test_prior_failure_visible_after_restart(self):
        with self.store.edit() as s:s['returnRun']={'phase':'error','message':'저장된 오류 안내'}
        self.assertEqual(self.c.status()['message'],'저장된 오류 안내')
        with self.store.edit() as s:s['returnRun']={'phase':'running','message':'이전 조회중'}
        self.assertIn('완료되지',self.c.status()['message']);self.assertFalse(self.c.status()['running'])
    def test_scheduler_shutdown(self):
        self.c.start_scheduler();self.c.shutdown();self.c.scheduler_thread.join(1);self.assertFalse(self.c.scheduler_thread.is_alive())
        with self.assertRaises(ReturnError):self.c.start()

if __name__=='__main__':unittest.main()
