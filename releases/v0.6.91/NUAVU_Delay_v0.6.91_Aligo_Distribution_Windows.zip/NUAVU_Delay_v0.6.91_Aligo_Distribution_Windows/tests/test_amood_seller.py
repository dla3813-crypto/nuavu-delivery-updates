"""2026-10-21 01:29 요청 (공통): 판매처 아무드 추가 — 에이블리·아무드·자사몰·지그재그."""
import unittest,importlib.util
from domain import SELLERS
try:from test_v056 import Base
except ImportError:from helpers import Base
try:from test_v068 import order
except ImportError:from test_supply_regression import order
DIST=importlib.util.find_spec('branding') is not None

class Amood(Base):
    def test_seller_list(self):
        self.assertEqual(SELLERS,['누아브 에이블리','누아브 자사몰','누아브 지그재그','누아브 아무드'])
    def test_import_and_alias(self):
        if DIST:
            from branding import import_seller
            self.assertEqual(import_seller('아무드 누아브','누아브'),'누아브 아무드');self.assertEqual(import_seller('누아브 아무드','누아브'),'누아브 아무드')
            with self.store.edit() as s:s['settings']['shopName']='누아브'
            a=order(1,product='티셔츠');a['seller']='누아브 아무드';a['sourceSeller']='아무드 누아브';a['orderId']='AM-1'
            self.engine.import_rows({'rows':[a],'mode':'merge','labelScope':['아무드 누아브']} if 'labelScope' in open(__import__('domain').__file__).read() else {'rows':[a],'mode':'merge'})
        else:
            import external_notices as en
            self.assertEqual(en.SELLERS['아무드누아브'],'누아브 아무드');self.assertEqual(en.SELLERS['아무드'],'누아브 아무드')
            a=order(1,product='티셔츠');a['seller']='누아브 아무드';a['orderId']='AM-1'
            self.engine.import_rows({'rows':[a],'mode':'merge'})
        rows=[r for r in self.engine.public_state()['rows'] if r['orderId']=='AM-1'];self.assertEqual(len(rows),1);self.assertEqual(rows[0]['seller'],'누아브 아무드')
if __name__=='__main__':unittest.main()
