"""20:38 보고: 배송연기 안내 전송 뒤 목록이 늦게 다시 그려져 '변경 발송 예정일이 공란' 실패로 기록되던 문제 — 반영을 기다리고, 끝내 공란이면 전송으로 본다."""
import os,shutil,unittest
import zigzag_browser as zb
from test_zigzag_browser import PAGE,FakeStop

TARGET={'itemId':'185478058381080807','sendDate':'2026-10-23','orderId':'139777491508015680','key':'k','dueDate':'2026-10-23','noticeId':'n','zigzagDate':'2026-10-21','adjusted':''}
def run(page_html,fn):
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b=pw.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or '/opt/pw-browsers/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
        try:page=b.new_page();page.set_content(page_html);return fn(page)
        finally:b.close()

class LateList(unittest.TestCase):
    def test_list_updates_three_seconds_later_is_sent(self):
        html=PAGE.replace("row.querySelector('.chg').textContent=input.value+' 23:59:59';","const v=input.value;setTimeout(()=>{row.querySelector('.chg').textContent=v+' 23:59:59';},3000);")
        self.assertNotEqual(html,PAGE)
        def go(page):
            r=zb.Reader(page,FakeStop(),lambda m:None);r.wait(r.list_settled,'settle',10)
            out=r.push([TARGET],{TARGET['itemId']:1});self.assertEqual(out[0]['status'],'sent');self.assertEqual(out[0]['platformNotice'],'2026-10-23');self.assertEqual(out[0]['reason'],'')
        run(html,go)
    def test_list_never_updates_is_sent_with_note(self):
        html=PAGE.replace("row.querySelector('.chg').textContent=input.value+' 23:59:59';","")
        self.assertNotEqual(html,PAGE)
        def go(page):
            r=zb.Reader(page,FakeStop(),lambda m:None);r.wait(r.list_settled,'settle',10)
            out=r.push([TARGET],{TARGET['itemId']:1});self.assertEqual(out[0]['status'],'sent');self.assertIn('확인하지 못했습니다',out[0]['reason'])
        run(html,go)
    def test_list_shows_other_date_is_failed(self):
        html=PAGE.replace("row.querySelector('.chg').textContent=input.value+' 23:59:59';","row.querySelector('.chg').textContent='2026.10.30 23:59:59';")
        def go(page):
            r=zb.Reader(page,FakeStop(),lambda m:None);r.wait(r.list_settled,'settle',10)
            out=r.push([TARGET],{TARGET['itemId']:1});self.assertEqual(out[0]['status'],'failed');self.assertIn('2026-10-30',out[0]['reason'])
        run(html,go)
if __name__=='__main__':unittest.main()
