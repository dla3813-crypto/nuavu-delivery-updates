"""Reader.push against a fake partner-center page that mimics the observed DOM (table, checkbox, 배송연기 안내 modal,
pds combobox + li[role=option], 50-char textarea, react-day-picker calendar with disabled days, pagination buttons)."""
import os,shutil,sys,threading,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import zigzag_browser as zb

PAGE='''<!doctype html><html><head><style>tbody input[type=checkbox]{opacity:0;width:0;height:0;position:absolute}</style></head><body>
<div id="title">배송준비중 목록 (0건)</div>
<table><thead><tr><th></th><th>상품주문번호</th><th>주문번호</th><th>결제일</th><th>주문상태</th><th>예약 발송</th><th>발송지시일</th><th>발송 예정일</th><th>배송지연 경과일</th><th>변경 발송 예정일</th><th>발송 상태</th><th>구매자명</th><th>주문일시</th><th>자체상품코드</th><th>상품명</th><th>옵션정보</th><th>수량</th><th>수령인명</th></tr></thead>
<tbody>
<tr><td><input type="checkbox"></td><td>185478058381080807</td><td>139777491508015680</td><td>2026.10.18</td><td>배송준비중</td><td>N</td><td>2026.10.18</td><td>2026.10.21 23:59:59 (3 영업일)</td><td>-</td><td class="chg">-</td><td>-</td><td>k</td><td>2026.10.18 13:21:26</td><td></td><td>민트 후드 집업</td><td>색상: 원컬러 사이즈: FREE</td><td>1</td><td>김나영</td></tr>
<tr><td><input type="checkbox"></td><td>185478581000517890</td><td>139777805906310084</td><td>2026.10.18</td><td>배송준비중</td><td>N</td><td>2026.10.18</td><td>2026.10.21 23:59:59 (3 영업일)</td><td>-</td><td class="chg">-</td><td>-</td><td>k</td><td>2026.10.18</td><td></td><td>다른 상품</td><td>FREE</td><td>2</td><td>홍길동</td></tr>
</tbody></table>
<ul><li><button type="button" aria-label="이전 페이지" disabled></button></li><li class="css-r7d4ay"><button type="button" aria-label="1 페이지" aria-current="page">1</button></li><li><button type="button" aria-label="다음 페이지" disabled></button></li></ul>
<button type="button" role="tab">배송연기 안내 완료 1건</button>
<button type="button" id="open">배송연기 안내</button>
<div id="modalHost"></div>
<script>
window.sent=[];setTimeout(()=>{document.getElementById('title').textContent='배송준비중 목록 (2건)';},1200);
const DISABLED=new Set([19,20,21,24,25,31]);
document.getElementById('open').onclick=()=>{
 const checked=[...document.querySelectorAll('tbody input[type=checkbox]:checked')];if(checked.length!==1)return;
 const row=checked[0].closest('tr');const item=row.children[1].textContent.trim();
 const host=document.getElementById('modalHost');
 host.innerHTML=`<div class="pds-modal-wrapper"><h2>배송연기 안내</h2><table><tr><td>변경 발송 예정일</td><td><input class="pds-input" placeholder="날짜를 선택하세요." value="2026.10.22"><div id="cal"></div></td></tr>
 <tr><td>배송연기 사유</td><td><div role="combobox" class="pds-dropdown-label">배송연기사유 선택</div></td></tr>
 <tr><td>상세사유</td><td><textarea class="pds-input" maxlength="50"></textarea></td></tr></table>
 <button type="button" id="cancel">취소</button><button type="button" id="submit" disabled>배송연기 안내</button></div><ul id="opts" hidden></ul>`;
 const modal=host.querySelector('.pds-modal-wrapper');const input=modal.querySelector('input.pds-input');const ta=modal.querySelector('textarea');const combo=modal.querySelector('[role=combobox]');const submit=modal.querySelector('#submit');
 let reason='';const refresh=()=>{submit.disabled=!(reason&&ta.value.trim()&&!DISABLED.has(parseInt(input.value.split('.')[2])));};
 combo.onclick=()=>{const ul=document.getElementById('opts');ul.hidden=false;ul.innerHTML=['배송연기사유 선택','상품 입고 지연','주문제작','고객요청','예약 발송','기타사유'].map(t=>'<li role="option">'+t+'</li>').join('');[...ul.children].forEach(li=>li.onclick=()=>{reason=li.textContent;combo.textContent=li.textContent;ul.hidden=true;refresh();});};
 ta.oninput=refresh;
 input.onclick=()=>{const cal=modal.querySelector('#cal');cal.innerHTML='<div class="rdp-month"><div class="rdp-caption"><div class="rdp-caption_label">2026년 10월</div><button aria-label="previous-month"></button><button aria-label="next-month"></button></div><table><tr>'+Array.from({length:31},(_,i)=>i+1).map(d=>'<td class="rdp-cell"><button class="rdp-button rdp-day'+(DISABLED.has(d)?' rdp-day_disabled':'')+(d===22?' rdp-day_selected':'')+'">'+d+'</button></td>').join('')+'</tr></table></div>';
  [...cal.querySelectorAll('button.rdp-day')].forEach(b=>b.onclick=()=>{if(b.classList.contains('rdp-day_disabled'))return;input.value='2026.10.'+String(b.textContent).padStart(2,'0');cal.innerHTML='';refresh();});};
 modal.querySelector('#cancel').onclick=()=>{host.innerHTML='';};
 submit.onclick=()=>{window.sent.push({item,date:input.value,reason,detail:ta.value});row.querySelector('.chg').textContent=input.value+' 23:59:59';checked[0].checked=false;host.insertAdjacentHTML('beforeend','<div class="pds-modal-wrapper" id="done"><p>배송연기 안내가 완료되었습니다.</p><button type="button" id="ok">확인</button></div>');setTimeout(()=>{modal.remove();},300);document.getElementById('ok').onclick=()=>document.getElementById('done').remove();};
};
</script></body></html>'''

class FakeStop:
    def __init__(self):self.flag=False
    def is_set(self):return self.flag

def with_page(fn):
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b=pw.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or '/opt/pw-browsers/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
        try:
            page=b.new_page();page.set_content(PAGE);return fn(page)
        finally:b.close()

class ZigzagReaderTests(unittest.TestCase):
    def test_title_rendering_late_is_waited_for(self):
        def run(page):
            r=zb.Reader(page,FakeStop(),lambda m:None)
            self.assertIsNone(r.list_settled())
            d=r.wait(r.list_settled,'settle',10);self.assertEqual(d['total'],2)
        with_page(run)
    def test_list_rows_and_send(self):
        def run(page):
            msgs=[];r=zb.Reader(page,FakeStop(),msgs.append)
            d=r.wait(r.list_settled,'settle',10);_,rows=r.page_rows()
            self.assertEqual([(x['itemId'],x['orderId'],x['shipByDate'],x['changedDate'],x['currentDate'],x['qty']) for x in rows],
                             [('185478058381080807','139777491508015680','2026-10-21','','2026-10-21',1),('185478581000517890','139777805906310084','2026-10-21','','2026-10-21',2)])
            self.assertEqual(d['total'],2);self.assertEqual(d['pages'],1);self.assertEqual(r.current_page(),1)
            out=r.push([{'itemId':'185478058381080807','sendDate':'2026-10-23','orderId':'139777491508015680','key':'k','dueDate':'2026-10-23','noticeId':'n','zigzagDate':'2026-10-21','adjusted':''},
                        {'itemId':'185478581000517890','sendDate':'2026-10-24','orderId':'139777805906310084','key':'k2','dueDate':'2026-10-24','noticeId':'n2','zigzagDate':'2026-10-21','adjusted':''}],
                       {'185478058381080807':1,'185478581000517890':1})
            sent=page.evaluate('window.sent')
            self.assertEqual(sent,[{'item':'185478058381080807','date':'2026.10.23','reason':zb.REASON,'detail':zb.DETAIL}])
            self.assertEqual([(p['itemId'],p['status']) for p in out],[('185478058381080807','sent'),('185478581000517890','skipped')])
            self.assertIn('선택할 수 없는 날짜',out[1]['reason'])
            self.assertEqual(out[0]['platformNotice'],'2026-10-23')
            self.assertFalse(page.locator('.pds-modal-wrapper').count())  # form closed, completion notice dismissed, held one cancelled
            self.assertEqual(len(zb.DETAIL),49)
        with_page(run)
    def test_missing_row_is_skipped_without_clicking(self):
        def run(page):
            r=zb.Reader(page,FakeStop(),lambda m:None)
            out=r.push([{'itemId':'999','sendDate':'2026-10-23','orderId':'x','key':'k','dueDate':'','noticeId':'','zigzagDate':'','adjusted':''}],{})
            self.assertEqual(out[0]['status'],'skipped');self.assertEqual(page.evaluate('window.sent'),[])
        with_page(run)

if __name__=='__main__':unittest.main()

LOGIN_HTML='''<!doctype html><html><body><h1>파트너센터 로그인</h1><form onsubmit="event.preventDefault();if(document.getElementById('u').value==='user1'&&document.getElementById('p').value==='pw1')location.href='https://partners.kakaostyle.com/shop/nuavu/stats';else document.getElementById('err').textContent='bad';">
<input id="u" type="text" placeholder="아이디"><input id="p" type="password" placeholder="비밀번호"><button type="submit">로그인</button><div id="err"></div></form></body></html>'''
DASH_HTML='<!doctype html><html><body><nav>누아브 · 주문 · 상품준비/배송</nav><h1>대시보드</h1></body></html>'

class LoginTests(unittest.TestCase):
    def test_entry_without_form_falls_back_to_direct_login_once(self):
        from playwright.sync_api import sync_playwright
        hits=[]
        with sync_playwright() as pw:
            b=pw.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or '/opt/pw-browsers/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
            try:
                ctx=b.new_context()
                def route(r):
                    url=r.request.url;hits.append(url)
                    if 'shop.zigzag.kr' in url:body='<html><body>loading…</body></html>'
                    elif url.startswith('https://partners.kakaostyle.com/login'):body=LOGIN_HTML
                    elif '/shop/nuavu/' in url:body=DASH_HTML
                    else:body='<html><body></body></html>'
                    r.fulfill(status=200,content_type='text/html; charset=utf-8',body=body)
                ctx.route('**/*',route)
                page=ctx.new_page();msgs=[];r=zb.Reader(page,FakeStop(),msgs.append,ctx)
                r.login({'shop':'nuavu','username':'user1','password':'pw1'})
                self.assertTrue(r.dashboard('nuavu'));self.assertEqual(sum('partners.kakaostyle.com/login' in h for h in hits),1)
                self.assertTrue(any('직접 이동' in m for m in msgs))
            finally:b.close()
    def test_wrong_password_fails_without_retry(self):
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            b=pw.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or '/opt/pw-browsers/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
            try:
                ctx=b.new_context()
                ctx.route('**/*',lambda r:r.fulfill(status=200,content_type='text/html; charset=utf-8',body=LOGIN_HTML if '/login' in r.request.url else '<html><body></body></html>'))
                page=ctx.new_page();r=zb.Reader(page,FakeStop(),lambda m:None,ctx)
                import browser_window;browser_window.configure(False,True)  # headless: no person can help → fail fast after 8s
                try:
                    with self.assertRaises(zb.ZigzagError) as cm:r.login({'shop':'nuavu','username':'user1','password':'wrong'})
                finally:browser_window.configure(False,False)
                self.assertIn('추가 인증 또는 로그인 확인',str(cm.exception))
                self.assertEqual(page.locator('#err').inner_text(),'bad')
            finally:b.close()
