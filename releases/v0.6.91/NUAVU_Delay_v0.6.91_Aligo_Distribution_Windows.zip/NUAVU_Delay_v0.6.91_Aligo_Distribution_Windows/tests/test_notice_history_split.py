"""Read-only delay-history classification, fake providers and isolated stores."""
import copy,unittest
from pathlib import Path
if '_Distribution' in Path(__file__).resolve().parents[1].name:
 from helpers import Base
 from test_supply_regression import order
 from test_ably_sync import snapshot
else:
 from test_v056 import Base
 from test_v068 import order
 from test_v0638 import snapshot
from ably_sync import apply_snapshot
import test_dashboard_export as export_fixture

class DelayHistoryMetadataTests(Base):
 def setUp(self):
  super().setUp()
  with self.store.edit() as s:s['rows']=[]
  self.engine.import_rows({'rows':[order(1)|{'orderId':'12345','orderItemId':'801'}]})
  self.key=self.store.read()['rows'][0]['key']
 def manual(self):self.engine.external_manual({'keys':[self.key],'dueDate':'2026-10-30'})
 def test_no_history_zero(self):self.assertEqual(self.row()['delayNoticeCount'],0)
 def test_manual_acknowledgement_counts(self):
  self.manual();self.assertEqual(self.row()['delayNoticeCount'],1);self.assertEqual(len(self.fake.sent),0)
 def test_ably_synced_history_counts(self):
  apply_snapshot(self.engine,snapshot());self.assertEqual(self.row()['delayNoticeCount'],1);self.assertEqual(len(self.fake.sent),0)
 def test_real_accepted_and_delivered_counts(self):
  self.send(keys=[self.key]);self.assertEqual(self.row()['delayNoticeCount'],1)
  with self.store.edit() as s:s['notices'][0]['status']='DELIVERED'
  self.assertEqual(self.row()['delayNoticeCount'],1)
 def test_queued_reserved_failed_unknown_cancelled_are_not_history(self):
  self.queue(keys=[self.key]);base=copy.deepcopy(self.last())
  for status in ['QUEUED','SCHEDULED','PAUSED','SENDING','FAILED','UNKNOWN','CANCELLED']:
   with self.store.edit() as s:s['notices']=[dict(base,status=status)]
   with self.subTest(status=status):self.assertEqual(self.row()['delayNoticeCount'],0)
 def test_test_messages_are_excluded(self):
  self.manual()
  with self.store.edit() as s:s['notices'][0]['isTest']=True
  self.assertEqual(self.row()['delayNoticeCount'],0)
 def test_soldout_only_is_not_delay_history(self):
  self.manual()
  for kind in ['soldout_card','soldout_bank']:
   with self.store.edit() as s:s['notices'][0]['noticeType']=kind
   with self.subTest(kind=kind):self.assertEqual(self.row()['delayNoticeCount'],0);self.assertEqual(self.row()['noticeCount'],1)
 def test_old_notice_without_type_is_delay_history(self):
  self.manual()
  with self.store.edit() as s:s['notices'][0].pop('noticeType')
  self.assertEqual(self.row()['delayNoticeCount'],1)
 def test_only_notified_item_gets_history_in_shared_order(self):
  self.engine.import_rows({'rows':[order(2)|{'orderId':'12345','orderItemId':'802','product':'다른 가상 상품'}]});self.manual()
  rows=self.engine.public_state()['rows'];self.assertEqual(len(rows),2)
  self.assertEqual({r['key']:r['delayNoticeCount'] for r in rows},{r['key']:int(r['key']==self.key) for r in rows})
 def test_lookup_does_not_change_stored_history_or_orders(self):
  self.manual();before=self.store.read();self.engine.public_state();self.assertEqual(self.store.read(),before)

class SplitSectionExportTests(unittest.TestCase):
 setUp=export_fixture.DashboardExportTests.setUp
 export=export_fixture.DashboardExportTests.export
 def test_history_section_filename(self):self.assertEqual(self.export({'section':'notice_undated_seen'})[0],'출고 예정일자 (미확정)_이력 있음_1018.xlsx')
 def test_new_section_filename(self):self.assertEqual(self.export({'section':'notice_undated_new'})[0],'출고 예정일자 (미확정)_이력 없음_1018.xlsx')
