"""'작업완료!' notifications: written by finished background jobs, dismissed with the existing alert acknowledgement."""
import unittest
from unittest.mock import MagicMock
from helpers import Base
from ably_sync import AblySyncController

def snapshot():return dict(entries=[],total=0,notifiedTotal=0,pages=1,complete=True,verified=True)

class JobAlertTests(Base):
    def active(self):return [a for a in self.store.read().get('alerts',[]) if not a.get('acknowledgedAt')]
    def test_add_and_dismiss(self):
        self.engine.add_job_alert('테스트 작업','완료 메시지')
        a=self.active();self.assertEqual(len(a),1);self.assertEqual((a[0]['code'],a[0]['level'],a[0]['title'],a[0]['noticeId'],a[0]['job']),('JOB_DONE','info','테스트 작업','',True))
        self.assertIn(a[0],self.engine.public_state()['alerts'])
        self.engine.acknowledge_alerts({'ids':[a[0]['id']]});self.assertEqual(self.active(),[])
        self.engine.add_job_alert('실패 작업','오류','error');self.assertEqual(self.active()[0]['code'],'JOB_FAILED')
    def test_acknowledged_job_history_is_bounded(self):
        for i in range(230):
            self.engine.add_job_alert(f'작업 {i}','x')
            with self.store.edit() as s:s['alerts'][-1]['acknowledgedAt']='2026-10-18T00:00:00+00:00'
        self.assertLessEqual(len([a for a in self.store.read()['alerts'] if a.get('job')]),201)
    def test_ably_sync_done_and_failed_add_alerts(self):
        vault=MagicMock(available=True);vault.load.return_value=dict(version=1,username='fake',password='FAKE-SECRET')
        c=AblySyncController(self.engine,runner=lambda a,s,p,cache:snapshot(),vault=vault);c.start();c.thread.join(4)
        self.assertEqual([a['title'] for a in self.active()],['에이블리 출고 예정일 동기화 완료'])
        c=AblySyncController(self.engine,runner=lambda a,s,p,cache:(_ for _ in ()).throw(RuntimeError('boom FAKE-SECRET')),vault=vault);c.start();c.thread.join(4)
        a=self.active()[-1];self.assertEqual((a['title'],a['level']),('에이블리 출고 예정일 동기화 실패','error'));self.assertNotIn('FAKE-SECRET',a['message'])
    def test_blocked_pushes_add_red_alert_next_to_green_completion(self):
        vault=MagicMock(available=True);vault.load.return_value=dict(version=1,username='fake',password='FAKE-SECRET')
        pushes=[dict(itemId='801',orderId='1',qty=1,key='k',dueDate='2026-10-20',noticeId='n',option='내일',status='failed',reason='목록에서 발송 표시를 확인하지 못했습니다.',sentAt='',platformNotice=''),
                dict(itemId='802',orderId='2',qty=1,key='k2',dueDate='2026-10-10',noticeId='n',option='',status='skipped',reason='출고 예정일이 이미 지났습니다.',sentAt='',platformNotice='')]
        c=AblySyncController(self.engine,runner=lambda a,s,p,cache,planner=None:dict(snapshot(),pushes=pushes),vault=vault);c.start(push=True);c.thread.join(4)
        titles=[(a['title'],a['level']) for a in self.active()]
        self.assertIn(('에이블리 출고 예정일 동기화 완료','info'),titles)
        red=[a for a in self.active() if a['level']=='error'];self.assertEqual(len(red),1);self.assertIn('막힘 2건',red[0]['title'])
        self.assertIn('801',red[0]['message']);self.assertIn('보류',red[0]['message']);self.assertIn('지났습니다',red[0]['message'])
    def test_cancelled_sync_adds_no_alert(self):
        vault=MagicMock(available=True);vault.load.return_value=dict(version=1,username='fake',password='FAKE-SECRET')
        def runner(a,stop,p,cache):stop.set();return snapshot()
        c=AblySyncController(self.engine,runner=runner,vault=vault);c.start();c.thread.join(4)
        self.assertEqual(self.active(),[])

if __name__=='__main__':unittest.main()
