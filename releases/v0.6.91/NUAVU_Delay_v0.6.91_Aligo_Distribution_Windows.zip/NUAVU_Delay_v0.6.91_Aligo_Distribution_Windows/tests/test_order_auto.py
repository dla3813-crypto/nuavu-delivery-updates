"""Auto import receipts, freshness, cancellation and bridge auth; fake exports only."""
import base64
from datetime import datetime,timedelta
import json
import os
from pathlib import Path
import tempfile
import threading
import unittest
from types import SimpleNamespace
from order_auto import *
from domain import Store
from desktop import DesktopAPI

class FakeDownload:
    def __init__(self,data=b'<table>fake</table>'):self.data=data
    def save_as(self,path):Path(path).write_bytes(self.data)
    def failure(self):return None

class AutoTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.store=Store(self.root/'data');self.folder=self.root/'Downloads';self.folder.mkdir()
        with self.store.edit() as s:s['settings'].update(shopName='데모스토어',shopRevision=1)
        self.started=datetime.now(KST);self.name='확장주문검색_'+self.started.strftime('%Y%m%d%H%M%S')+'_123.xls'
        self.c=OrderAutoController(self.store,runner=lambda *_:(self.name,b'fake'))
    def tearDown(self):
        self.c.cancel()
        if self.c.thread:self.c.thread.join(2)
        self.store.close();self.tmp.cleanup()
    def configure(self):self.c.configure(str(self.folder.resolve()))
    def test_requires_folder(self):
        with self.assertRaises(OrderAutoError):self.c.start()
    def test_latest_receipt_once_only_no_order_changes(self):
        with self.store.edit() as s:s['rows']=[{'private':'existing'}];s['notices']=[{'status':'UNKNOWN'}]
        before=self.store.read();self.configure();job=self.c.start();self.c.thread.join(2)
        r=self.c.take_result(job['id']);self.assertEqual(base64.b64decode(r['data']),b'fake')
        with self.assertRaises(OrderAutoError):self.c.take_result(job['id'])
        after=self.store.read()
        for key in ['rows','notices','schema']:self.assertEqual(before[key],after[key])
    def test_wrong_receipt_cannot_take(self):
        self.configure();self.c.start();self.c.thread.join(2)
        with self.assertRaises(OrderAutoError):self.c.take_result('wrong')
        self.assertIsNotNone(self.c.receipt)
    def test_concurrent_start_and_settings_rejected(self):
        done=threading.Event()
        self.c.runner=lambda *_:(done.wait(1) and self.name,b'fake')
        self.configure();self.c.start()
        with self.assertRaises(OrderAutoError):self.c.start()
        with self.assertRaises(OrderAutoError):self.c.configure(group='다른 그룹')
        done.set();self.c.thread.join(2)
    def test_cancellation_discards_received_file(self):
        done=threading.Event()
        def run(c,cfg):done.wait(1);return self.name,b'fake'
        self.c.runner=run;self.configure();self.c.start();self.c.cancel();done.set();self.c.thread.join(2)
        self.assertIsNone(self.c.receipt);self.assertEqual(self.c.status()['phase'],'cancelled')
    def test_exception_does_not_leak_browser_payload(self):
        def run(*_):raise RuntimeError('private customer payload')
        self.c.runner=run;self.configure();self.c.start();self.c.thread.join(2)
        self.assertNotIn('private customer payload',json.dumps(self.c.status()));self.assertEqual(self.c.status()['phase'],'error')
    def test_no_old_download_fallback(self):
        (self.folder/self.name).write_bytes(b'old')
        def run(*_):raise OrderAutoError('failed')
        self.c.runner=run;self.configure();self.c.start();self.c.thread.join(2)
        self.assertIsNone(self.c.receipt);self.assertEqual((self.folder/self.name).read_bytes(),b'old')
    def test_settings_persist(self):
        self.configure();self.c.configure(group='그룹 예시');new=OrderAutoController(self.store)
        self.assertEqual(new.settings()['group'],'그룹 예시');self.assertEqual(new.settings()['folder'],str(self.folder.resolve()))
    def test_bad_groups(self):
        for g in ['','a\nb','a'*81]:
            with self.assertRaises(OrderAutoError):self.c.configure(group=g)
    def test_file_name_freshness(self):
        self.assertEqual(checked_name(self.name,self.started),self.name)
        for n in ['../'+self.name,'현재고조회_20261017120000_1.xls','확장주문검색_20260101120000_1.xls',self.name+'.crdownload','확장주문검색_20269999120000_1.xls']:
            with self.assertRaises(OrderAutoError):checked_name(n,self.started)
    def test_download_url_allowlist(self):
        from urllib.parse import quote
        good='https://ga90.ezadmin.co.kr/data/shop/'+quote(self.name)
        self.assertEqual(checked_link(good,self.name),good)
        for u in [good.replace('https:','http:'),good.replace('ga90.ezadmin.co.kr','evil.example'),good+'?x=1',good.replace('/data/','/delete/'),good.replace('https://','https://user:pass@')]:
            with self.assertRaises(OrderAutoError):checked_link(u,self.name)
    def test_job_not_merely_latest(self):
        r={'id':'fresh','template':'확장주문검색2','at':self.started.strftime('%Y-%m-%d %H:%M:%S')}
        self.assertEqual(new_job([r],set(),self.started),r)
        self.assertIsNone(new_job([r],{'fresh'},self.started))
        with self.assertRaises(OrderAutoError):new_job([r,{**r,'id':'other'}],set(),self.started)
        self.assertIsNone(new_job([{**r,'template':'현재고조회'}],set(),self.started))
        self.assertIsNone(new_job([{**r,'at':'2020-01-01 00:00:00'}],set(),self.started))
    def test_download_atomic_private_and_no_overwrite(self):
        self.assertEqual(persist_download(FakeDownload(),self.folder,self.name),b'<table>fake</table>')
        self.assertEqual((self.folder/self.name).stat().st_mode&0o777,0o600)
        with self.assertRaises(OrderAutoError):persist_download(FakeDownload(b'new'),self.folder,self.name)
        self.assertFalse(list(self.folder.glob('*.part')))
    def test_symlink_not_overwritten(self):
        target=self.root/'safe';target.write_bytes(b'safe');(self.folder/self.name).symlink_to(target)
        with self.assertRaises(OrderAutoError):persist_download(FakeDownload(),self.folder,self.name)
        self.assertEqual(target.read_bytes(),b'safe')
    def test_empty_and_large_rejected(self):
        for data in [b'',b'x'*(MAX_BYTES+1)]:
            with self.assertRaises(OrderAutoError):persist_download(FakeDownload(data),self.folder,self.name)
        self.assertFalse(list(self.folder.iterdir()))
    def test_bridge_origin_and_token_gate_every_method(self):
        b=DesktopAPI(SimpleNamespace(store=self.store),'token','http://127.0.0.1:1234',None)
        b._window=SimpleNamespace(get_current_url=lambda:'http://127.0.0.1:1234/')
        for args in [('order_auto_status',),('order_auto_start',),('order_auto_result','x'),('order_auto_settings','x'),('order_auto_cancel',),('pick_order_download_folder',)]:
            self.assertIn('error',getattr(b,args[0])('bad',*args[1:]))
        self.assertIsNone(b._order_auto)
        b._window.get_current_url=lambda:'https://ga79.ezadmin.co.kr/'
        self.assertIn('error',b.order_auto_status('token'));self.assertIsNone(b._order_auto)

if __name__=='__main__':unittest.main()
