"""2026-10-21 19:25: 자사몰(카페24) 반품 관리 → 반품/교환 화면 · 회수접수 대상."""
import sys,unittest
from datetime import date
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT)]
import cafe24_returns as cr

LIST_HTML='''<div class="mPaginate"><strong>1</strong></div><table id="searchResultList" class="eChkBody"><thead><tr><th></th><th>No</th><th>반품신청일 (반품접수일)</th><th>품목별 주문번호/ 취소번호</th><th>주문자</th><th>사업자 회원 정보</th><th>상품명/옵션</th><th>상품명(관리용)</th><th>자체 상품코드</th><th>자체 품목코드</th><th>수량</th><th>운송장정보</th><th>주문 라벨</th><th>주문상태</th><th>반품처리</th><th>메모</th></tr></thead><tbody>
<tr class="center"><td><input type="checkbox"></td><td>1</td><td>2026-10-21 19:18:44</td><td><img alt="모바일웹"> <a href="#" id="eItemCode" data-orderid="20261021-0000029">20261021-0000029-01</a></td><td><span class="buyerName"><a href="#">임경민</a></span> <a class="btnIcon icoSms"><span>SMS</span></a><br><span id="sMemberId">test@k [일반회원]</span></td><td></td>
<td><div class="gGoods"><p><a href="#" class="btnOrdIcon icoHistory eLayerClick"><span>내역</span></a> <a href="#" title="새창 열림">프릴 하트 도트 레이어드 긴팔 티셔츠<br>(P0000DHG)</a></p><ul class="etc"><li>색상 : 블루</li><li>사이즈 : FREE</li></ul></div></td><td></td><td></td><td></td><td>5</td><td>6082036144359 <p><a class="btnNormal"><span>배송추적</span></a></p></td><td>추가</td><td>반품신청 <br><span class="txtLight">[구매자]</span></td><td>처리</td><td>USER ADMIN</td></tr>
<tr class="center"><td></td><td>2</td><td>2026-09-01 10:00:00</td><td><a data-orderid="20260901-0000001">20260901-0000001-01</a></td><td><span class="buyerName"><a>홍길동</a></span></td><td></td><td><div><p><a title="새창 열림">바지 (P0000AAA)</a></p><ul class="etc"><li>사이즈 : M</li></ul></div></td><td></td><td></td><td></td><td>1</td><td>6082036140000</td><td></td><td>반품완료</td><td></td><td></td></tr>
</tbody></table>'''
HANDLING_HTML='''<table><tr><td><input type="checkbox" checked></td><td>프릴 하트</td></tr><tr><td colspan="2"><ul><li><span>접수내용 : </span><strong>고객변심</strong> | 사이즈가 커요</li></ul></td></tr></table>'''

class ParseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            from playwright.sync_api import sync_playwright
            cls.pw=sync_playwright().start();cls.b=cls.pw.chromium.launch()
        except Exception as exc:raise unittest.SkipTest(f'chromium unavailable: {exc}')
    @classmethod
    def tearDownClass(cls):cls.b.close();cls.pw.stop()
    def ev(self,html,js,*args):
        pg=self.b.new_page();pg.set_content(html)
        try:return pg.evaluate(js,*args)
        finally:pg.close()
    def test_list_row_and_entry(self):
        d=self.ev(LIST_HTML,cr.ROWS_JS,'반품신청일')
        self.assertEqual(len(d['rows']),2);raw=d['rows'][0]
        self.assertEqual((raw['itemId'],raw['orderId'],raw['customer'],raw['qty']),('20261021-0000029-01','20261021-0000029','임경민','5'))
        self.assertTrue(cr.is_active(raw['status']));self.assertFalse(cr.is_active(d['rows'][1]['status']))
        why=self.ev(HANDLING_HTML,cr.REASON_JS,'20261021-0000029-01')
        self.assertEqual(why,{'kind':'고객변심','detail':'사이즈가 커요'})
        r=cr.entry(raw,why)
        self.assertEqual(r['seller'],'자사몰');self.assertEqual(r['product'],'프릴 하트 도트 레이어드 긴팔 티셔츠');self.assertEqual(r['option'],'블루 / FREE')
        self.assertEqual(r['requestedAt'],'2026-10-21');self.assertEqual(r['invoice'],'6082036144359');self.assertEqual(r['qty'],5)
        self.assertEqual(r['reason'],'고객(고객변심 · 사이즈가 커요)');self.assertTrue(r['key'].startswith('cafe24:'))
    def test_handling_url_uses_order_and_item_codes(self):
        u=cr.Cafe24Returns(SimpleNamespace(page=None),'nuavu.cafe24.com').handling_url('20261021-0000029','20261021-0000029-01')
        self.assertEqual(u,'https://nuavu.cafe24.com/admin/php/shop1/s_new/order_return_handling.php?order_id=20261021-0000029&menu_no=78&sSelectOrdItemCode=20261021-0000029-01&sIsOpenFromCsList=T')

class ExchangeParseTests(ParseTests):
    EX_LIST=LIST_HTML.replace('반품신청일 (반품접수일)','교환신청일 (교환접수일)').replace('품목별 주문번호/ 취소번호','품목별 주문번호/ 교환번호').replace('<th>운송장정보</th>','').replace('<td>6082036144359 <p><a class="btnNormal"><span>배송추적</span></a></p></td>','').replace('<td>6082036140000</td>','').replace('반품신청 <br>','교환신청 <br>').replace('반품완료','교환완료')
    DETAIL='<table><thead><tr><th>품목별주문번호/배송번호(교환번호)</th><th>공급사</th><th>상품명/옵션</th><th>수량</th><th>상품구매금액(판매가)</th><th>상품별할인금액</th><th>운송장번호</th><th>주문상태</th><th>교환처리</th><th>계</th></tr></thead><tbody><tr><td>20261021-0000029-01 D-20261021-0000029-0</td><td>자체공급</td><td>상품</td><td>1</td><td>29,800</td><td>0</td><td>6082036144359</td><td>교환신청</td><td>상세</td><td></td></tr></tbody></table>'
    def test_list_row_and_entry(self):
        d=self.ev(self.EX_LIST,cr.ROWS_JS,'교환신청일')
        self.assertEqual(len(d['rows']),2);raw=d['rows'][0];self.assertEqual(raw['invoiceText'],'')
        self.assertTrue(cr.is_active(raw['status'],'exchange'));self.assertFalse(cr.is_active(d['rows'][1]['status'],'exchange'))
        det=self.ev(self.DETAIL,cr.EXCHANGE_INVOICE_JS,'20261021-0000029-01')
        self.assertEqual(det['invoice'],'6082036144359')
        r=cr.entry(raw,None,'exchange',det['invoice'])
        self.assertEqual((r['kind'],r['invoice'],r['exchangeStatus']),('exchange','6082036144359','교환신청 [구매자]'));self.assertTrue(r['key'].startswith('cafe24-exchange:'))
    def test_handling_url_uses_order_and_item_codes(self):pass

class RuleTests(unittest.TestCase):
    def test_period_is_one_month(self):
        src=(ROOT/'cafe24_returns.py').read_text(encoding='utf-8')
        self.assertIn("filter(has_text=re.compile(r'^\\s*1개월\\s*$'))",src);self.assertNotIn('3개월',src.replace('3개월 → 1개월',''))
    def test_seller_fault_reason(self):
        self.assertEqual(cr.reason_text('상품불량',''),'판매자(상품불량)');self.assertEqual(cr.reason_text('',''),'고객(사유 없음)')
    def test_pickup_never_sends_cafe24_rows_to_ably_accept(self):
        src=(ROOT/'pickup_controller.py').read_text(encoding='utf-8')
        self.assertIn("t['seller'] not in ('지그재그','자사몰') and t['kind']!='exchange'",src)
    def test_merge_appends_cafe24_rows_and_survives_failure(self):
        import aftersales_collect as ac
        ctl=SimpleNamespace(engine=SimpleNamespace(store=SimpleNamespace(directory='x')),update=lambda *a:None,clock=lambda:SimpleNamespace(date=lambda:date(2026,10,21)))
        old=(cr.cafe24_enabled,cr.collect_cafe24)
        import cafe24_credentials as cc
        oldacc=cc.Cafe24Accounts
        try:
            cr.cafe24_enabled=lambda d:({'hasPassword':True},'')
            cc.Cafe24Accounts=lambda d:SimpleNamespace(for_login=lambda:{'username':'u','password':'p'})
            cr.collect_cafe24=lambda c,a,t,**k:{'rows':[{'seller':'자사몰','key':'cafe24:1'}],'exchangeRows':[{'seller':'자사몰','kind':'exchange','key':'cafe24-exchange:1'}],'totals':{'반품 진행 중':1}}
            res=ac.merge_cafe24({'rows':[{'seller':'에이블리'}],'total':1},{'kind':'return'},ctl)
            self.assertEqual([r['seller'] for r in res['rows']],['에이블리','자사몰']);self.assertEqual(res['total'],2)
            self.assertEqual([r['key'] for r in res['cafe24ExchangeRows']],['cafe24-exchange:1'])
            ex=ac.merge_cafe24({'rows':[],'total':0},{'kind':'exchange'},ctl);self.assertEqual([r['key'] for r in ex['rows']],['cafe24-exchange:1'])
            def boom(*a,**k):raise RuntimeError('카페24 화면 오류')
            cr.collect_cafe24=boom
            res=ac.merge_cafe24({'rows':[{'seller':'에이블리'}],'total':1},{'kind':'return'},ctl)
            self.assertEqual(len(res['rows']),1);self.assertIn('카페24 화면 오류',res['cafe24']['error'])
        finally:cr.cafe24_enabled,cr.collect_cafe24=old;cc.Cafe24Accounts=oldacc

if __name__=='__main__':unittest.main()
