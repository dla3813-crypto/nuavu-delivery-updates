"""Freeform text uses the existing fake delivery queue, never live providers."""
import copy, unittest
from pathlib import Path
if '_Distribution' in Path(__file__).resolve().parents[1].name:
 from helpers import Base
else:
 from test_v056 import Base
from domain import ValidationError
import test_dashboard_export as exports

class ManualComposeTests(Base):
 def manual(self,**kw):
  return self.data(noticeType='manual',templateKey='manual',dueDate='',template='요청하신 내용을 확인했습니다. 감사합니다.',deliveryChannel='SMS')|kw
 def submit_manual(self,**kw):
  plan=self.engine.preview(self.manual(**kw));self.engine.commit({'token':plan['token']});self.assertTrue(self.engine.send_one());return self.last()
 def test_preview_without_date_or_products_variable(self):
  p=self.engine.preview(self.manual());self.assertEqual(p['count'],1)
  g=p['groups'][0];self.assertEqual(g['dueDate'],'');self.assertEqual(g['noticeType'],'manual');self.assertIn('안내번호:',g['content']);self.assertEqual(g['base'],self.manual()['template'])
  self.assertEqual(len(self.fake.sent),0)
 def test_optional_product_variable_expands(self):
  g=self.engine.preview(self.manual(template='확인한 상품: {상품목록}'))['groups'][0]
  self.assertIn('리본 티셔츠',g['base']);self.assertNotIn('{상품목록}',g['base'])
 def test_reject_blank_body(self):
  for body in ['', '  \n\t']:
   with self.subTest(body=body),self.assertRaises(ValidationError):self.engine.preview(self.manual(template=body))
 def test_reject_due_date_and_due_variable(self):
  for extra in [{'dueDate':'2026-10-30'},{'template':'{출고예정일} 안내'}]:
   with self.subTest(extra=extra),self.assertRaises(ValidationError):self.engine.preview(self.manual(**extra))
 def test_reject_alimtalk(self):
  with self.assertRaisesRegex(ValidationError,'문자'):self.engine.preview(self.manual(deliveryChannel='AT'))
 def test_existing_message_byte_limit(self):
  with self.assertRaises(ValidationError):self.engine.preview(self.manual(template='가'*1100))
 def test_duplicate_commit_and_accepted_duplicate_blocked(self):
  plan=self.engine.preview(self.manual());token=plan['token']
  self.engine.commit({'token':token});self.assertTrue(self.engine.commit({'token':token})['alreadyAccepted'])
  self.assertTrue(self.engine.send_one());self.assertFalse(self.engine.send_one());self.assertEqual(len(self.fake.sent),1)
  with self.assertRaises(ValidationError):self.engine.preview(self.manual())
 def test_block_unknown_outcome_before_another_text(self):
  self.submit_manual()
  with self.store.edit() as s:s['notices'][-1]['status']='UNKNOWN'
  with self.assertRaises(ValidationError):self.engine.preview(self.manual(template='다른 내용'))
 def test_phone_approval_and_review_guards(self):
  for field in ['review','needsPhoneApproval']:
   with self.store.edit() as s:s['rows'][0][field]=True
   with self.subTest(field=field),self.assertRaises(ValidationError):self.engine.preview(self.manual())
   with self.store.edit() as s:s['rows'][0][field]=False
 def test_manual_only_does_not_mark_shipping_notice(self):
  self.submit_manual();r=self.row()
  self.assertEqual((r['dueDate'],r['noticeCount'],r['delayNoticeCount'],r['bucket']),('',0,0,'unnotified'))
  self.assertTrue(r['lastNoticeId']);self.assertEqual(len(self.engine.public_state()['notices']),1)
 def test_manual_preserves_existing_shipping_date_and_count(self):
  self.send();before=self.row();self.submit_manual();after=self.row()
  for k in ['dueDate','noticeCount','delayNoticeCount','bucket','noticeType','dueDateSource']:
   self.assertEqual(before[k],after[k],k)
  self.assertEqual(len(self.fake.sent),2)
 def test_manual_failure_preserves_shipping_promise_but_is_in_history(self):
  self.send();before=self.row();self.submit_manual()
  with self.store.edit() as s:s['notices'][-1]['status']='FAILED'
  after=self.row();self.assertEqual(after['dueDate'],before['dueDate']);self.assertEqual(after['noticeCount'],before['noticeCount']);self.assertEqual(after['bucket'],'failed');self.assertEqual(after['lastState'],'FAILED')
 def test_following_real_delay_still_updates_shipping_date(self):
  self.submit_manual();self.send(dueDate='2026-10-30')
  self.assertEqual(self.row()['dueDate'],'2026-10-30');self.assertEqual(self.row()['noticeCount'],1)
 def test_body_is_not_saved_as_next_template(self):
  before=copy.deepcopy(self.store.read()['settings']);self.submit_manual()
  after=self.store.read()['settings']
  for k in ['defaultTemplate','template','templateType','smsTemplates']:self.assertEqual(before[k],after[k],k)
 def test_manual_default_survives_restart(self):
  self.engine.save_preferences({'defaultTemplate':'manual'});self.restart()
  self.assertEqual(self.store.read()['settings']['defaultTemplate'],'manual');self.assertEqual(len(self.fake.sent),0)
 def test_morning_reservation_without_due_date_and_cancel(self):
  self.clock(20);p=self.engine.preview(self.manual(sendMode='MORNING'));self.engine.commit({'token':p['token']})
  self.assertEqual(self.last()['status'],'SCHEDULED');self.assertEqual(self.last()['dueDate'],'');self.assertFalse(self.engine.send_one())
  self.engine.queue_control({'action':'cancel'});self.assertEqual(self.last()['status'],'CANCELLED');self.assertEqual(len(self.fake.sent),0)
 def test_night_immediate_manual_keeps_explicit_mode(self):
  self.clock(20);n=self.submit_manual(sendMode='IMMEDIATE');self.assertEqual(n['sendMode'],'IMMEDIATE');self.assertEqual(len(self.fake.sent),1)
 def test_soldout_allocation_is_unchanged_after_manual_text(self):
  from domain import SOLDOUT_CARD
  from supply_workflow import allocation_view
  self.send(noticeType='soldout_card',dueDate='',template=SOLDOUT_CARD,templateKey='soldout_card')
  before=allocation_view(self.store.read());self.submit_manual();after=allocation_view(self.store.read())
  self.assertEqual(before,after);self.assertTrue(self.row()['soldoutNotified']);self.assertTrue(self.row()['removeIfExcludedSoldout'])
 def test_next_different_manual_has_repeat_warning(self):
  self.submit_manual();p=self.engine.preview(self.manual(template='추가로 확인했습니다.'))
  self.assertEqual(p['repeatCount'],1)
 def test_legacy_delay_requires_both_placeholders_and_date(self):
  for extra in [{'dueDate':''},{'template':'수동 문구'}]:
   with self.subTest(extra=extra),self.assertRaises(ValidationError):self.engine.preview(self.data(**extra))

class BeforeNoticeExports(unittest.TestCase):
 setUp=exports.DashboardExportTests.setUp
 export=exports.DashboardExportTests.export
 def test_dated_filename(self):self.assertEqual(self.export({'section':'white_dated'})[0],'안내 전_일정 확정_1018.xlsx')
 def test_undated_filename(self):self.assertEqual(self.export({'section':'white_undated'})[0],'안내 전_일정 미확정_1018.xlsx')
