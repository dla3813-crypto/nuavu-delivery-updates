"""Synthetic files/temp DB only: live folders, accounts and senders are not used."""
import copy,os,threading,time
from pathlib import Path
from unittest.mock import patch
from domain import Engine,SELLERS
from supply_workflow import SupplyError,read_supplier,init_supply,effective_progress,progress_cutoff
from supply_watch import scan_signature
try:
    from helpers import Base
    from test_supply_regression import order,source_row,xlsx
    PERSONAL=False
except ImportError:
    from test_v056 import Base
    from test_v068 import order,source_row,xlsx
    PERSONAL=True

class SupplyAutoTests(Base):
    def setUp(self):
        super().setUp()
        self.folder=Path(self.tmp.name)/'supplier';self.folder.mkdir()
        self.engine.supply_link(str(self.folder))
        with self.store.edit() as s:s['rows']=[];s['notices']=[];s['imports']=[]
        self.engine.import_rows({'rows':[order(1,qty=20)]})
    def put(self,name='진행상황.xlsx',rows=None):
        p=self.folder/name;p.write_bytes(xlsx([('공급',rows if rows is not None else [source_row(office='2026-10-18',qty=2)])]));return p
    def manifest(self,day=17,product='다른상품',qty=3):
        return self.put(f'솔리아 10월 {day}일 출고장 (완료).xlsx',[source_row(product=product,qty=qty)])
    def on(self):self.engine.supply_auto_settings({'enabled':True})
    def tick(self,n):self.engine.supply_watcher.tick(n)
    def data(self):
        """Store without the additive '작업 완료/막힘' notifications."""
        d=self.store.read();d.pop('alerts',None);d.pop('revision',None);d.pop('errorLog',None);return d   # errorLog = 막힘 알림의 상세 사본
    def settle(self,n=0):self.tick(n);self.tick(n+5)
    def public(self):return self.engine.public_state()
    def supplier(self):return self.store.read()['supply']
    def target(self):return next(r for r in self.public()['rows'] if r['orderId']=='TEST-001')
    def test_default_off_and_no_startup_folder_read(self):
        self.put();self.tick(0);self.tick(10)
        self.assertFalse(self.supplier()['autoEnabled']);self.assertFalse(self.supplier()['progress'])
        self.restart();self.assertFalse(self.supplier()['progress']);self.assertFalse(self.engine.supply_watcher.running())
    def test_enable_requires_folder_and_bool(self):
        for value in ['true',1,None]:
            with self.assertRaises(SupplyError):self.engine.supply_auto_settings({'enabled':value})
        with self.store.edit() as s:s['supply']['folder']=''
        with self.assertRaises(SupplyError):self.on()
    def test_two_stable_observations_before_import(self):
        self.put();self.on();self.tick(0);self.tick(4)
        self.assertFalse(self.supplier()['progress'])
        self.tick(5);self.assertEqual(self.target()['supplyInfo']['plannedQty'],2)
        self.assertEqual(self.supplier()['lastReadMode'],'automatic')
    def test_save_debounce_and_no_repeat_when_unchanged(self):
        self.put();self.on();self.tick(0)
        self.put(rows=[source_row(office='2026-10-18',qty=4)]);self.tick(4);self.tick(8)
        self.assertFalse(self.supplier()['progress']);self.tick(9)
        before=self.data();self.tick(50);self.tick(80)
        self.assertEqual(self.data(),before);self.assertEqual(self.target()['supplyInfo']['plannedQty'],4)
    def test_new_manifest_excludes_all_old_dated_products(self):
        self.put(rows=[source_row(office='2026-10-16',qty=2),source_row(office='2026-10-17',qty=3),source_row(office='2026-10-18',qty=4)])
        self.on();self.settle();self.assertEqual(self.target()['supplyInfo']['plannedQty'],9)
        self.manifest();self.settle(10)
        r=self.target();v=self.public()['supply']
        self.assertEqual(r['supplyInfo']['plannedQty'],4)
        self.assertEqual(r['progressOfficeDates'],['2026-10-18'])
        self.assertEqual(v['progressCutoff'],'2026-10-17');self.assertEqual(v['excludedProgress'],{'rows':2,'qty':5})
        self.assertEqual(len(self.supplier()['progress']),3)
    def test_oct20_includes_boundary_and_earlier_different_product(self):
        self.put(rows=[source_row(office=d,qty=q) for d,q in [('2026-10-17',2),('2026-10-20',3),('2026-10-21',5)]])
        self.manifest(20);self.engine.supply_refresh()
        self.assertEqual(self.target()['supplyInfo']['plannedQty'],5)
        self.assertEqual(self.public()['supply']['excludedProgress'],{'rows':2,'qty':5})
    def test_last_cutoff_survives_deletion_reset_restart(self):
        self.put(rows=[source_row(office='2026-10-17',qty=4)]);p=self.manifest();self.engine.supply_refresh()
        self.engine.supply_reset({'confirmed':True});p.unlink();self.engine.supply_refresh();self.restart()
        self.assertEqual(self.public()['supply']['progressCutoff'],'2026-10-17')
        self.assertEqual(self.target()['supplyInfo']['plannedQty'],0)
        self.assertFalse(self.target()['progressHasOfficeDate'])
    def test_older_manifest_cannot_lower_cutoff(self):
        p=self.manifest(20);self.engine.supply_refresh();p.unlink();self.manifest(17);self.engine.supply_refresh()
        self.assertEqual(self.public()['supply']['progressCutoff'],'2026-10-20')
    def test_blank_or_invalid_V_never_uses_L_or_filename(self):
        self.put(rows=[source_row(office='',purchase='2026-10-01',qty=4),source_row(office='미도착',qty=6)])
        self.manifest();self.engine.supply_refresh();v=self.public()['supply']
        self.assertEqual(v['excludedProgress']['rows'],0);self.assertEqual(v['loadedCounts']['progressWithoutOffice'],2)
        self.assertEqual(self.target()['supplyInfo']['plannedQty'],0)
    def test_manifest_quantity_preserved_same_product(self):
        self.put(rows=[source_row(office='2026-10-17',qty=7)]);self.manifest(product='가디건',qty=3);self.engine.supply_refresh()
        a=self.target()['supplyInfo'];self.assertEqual(a['manifestQty'],3);self.assertEqual(a['plannedQty'],0)
        if PERSONAL:self.assertEqual(a['incomingQty'],3)
    def test_cutoff_not_limited_to_same_variant_or_selected_brand(self):
        self.put(rows=[source_row(office='2026-10-17',qty=3,brand='NS')]);self.manifest(product='전혀 다른 상품');self.engine.supply_refresh()
        self.assertEqual(self.public()['supply']['excludedProgress']['qty'],3)
    def test_global_cutoff_source_catalogue_does_not_claim_old_V(self):
        self.put(rows=[source_row(office='2026-10-17',qty=5)]);self.manifest();self.engine.supply_refresh()
        r=self.target();self.assertFalse(r['hasProgressSource']);self.assertFalse(r['supplyInfo']['sources'])
        self.assertFalse(any(x['product']=='가디건' for x in self.public()['supply']['variants']))
    def test_unchanged_manual_snapshot_not_reimported_when_auto_enabled(self):
        self.put();self.engine.supply_refresh();self.on();before=self.data();self.settle()
        self.assertEqual(self.data(),before)
    def test_off_stops_updates_and_manual_still_works(self):
        self.put();self.on();self.settle();self.engine.supply_auto_settings({'enabled':False})
        self.put(rows=[source_row(office='2026-10-18',qty=7)]);before=self.data();self.settle(10)
        self.assertEqual(self.data(),before);self.engine.supply_refresh();self.assertEqual(self.target()['supplyInfo']['plannedQty'],7)
    def test_error_retains_snapshot_and_recovers_only_on_file_change(self):
        p=self.put();self.on();self.settle();before=copy.deepcopy(self.supplier());p.write_bytes(b'broken')
        self.settle(10);self.assertEqual(self.supplier(),before);self.assertEqual(self.engine.supply_watcher.status()['phase'],'error')
        with patch('supply_workflow.read_supplier',side_effect=AssertionError('no retry unchanged')):self.settle(20)
        self.put(rows=[source_row(office='2026-10-18',qty=6)]);self.settle(30)
        self.assertEqual(self.target()['supplyInfo']['plannedQty'],6);self.assertFalse(self.engine.supply_watcher.status()['error'])
    def test_bad_new_manifest_does_not_advance_cutoff(self):
        self.manifest();self.engine.supply_refresh();self.on()
        self.put('솔리아 10월 20일 출고장 (완료).xlsx',[[1,'bad']]);self.settle()
        self.assertEqual(self.public()['supply']['progressCutoff'],'2026-10-17')
    def test_changed_during_read_preserves_all_previous_data(self):
        p=self.put();self.engine.supply_refresh();before=self.data()
        original=read_supplier
        def changing(*args):
            result=original(*args);p.write_bytes(b'now changing');return result
        with patch('supply_workflow.read_supplier',side_effect=changing):
            with self.assertRaises(SupplyError):self.engine.supply_refresh()
        self.assertEqual(self.data(),before)
    def test_stop_before_commit_preserves_data(self):
        self.put();self.on();before=self.data();original=read_supplier
        def stopping(*args):self.engine.stop.set();return original(*args)
        with patch('supply_workflow.read_supplier',side_effect=stopping):self.settle()
        self.assertEqual(self.data(),before)
    def test_missing_folder_error_preserves_data(self):
        self.put();self.on();self.settle();before=self.data();new=self.folder.with_name('moved');self.folder.rename(new)
        self.settle(10);self.assertEqual(self.data(),before);self.assertTrue(self.engine.supply_watcher.status()['error'])
        new.rename(self.folder);self.tick(20);self.assertFalse(self.engine.supply_watcher.status()['error'])
    def test_only_target_files_trigger_changes(self):
        self.put();self.engine.supply_refresh();self.on();signature=scan_signature(str(self.folder))
        for name in ['~$진행상황.xlsx','.진행상황.xlsx','다른자료.xlsx','진행상황.xlsx.tmp']:(self.folder/name).write_bytes(b'ignored')
        (self.folder/'진행상황 (8).xlsx').symlink_to(self.folder/'진행상황.xlsx')
        self.assertEqual(scan_signature(str(self.folder)),signature);before=self.data();self.settle();self.assertEqual(self.data(),before)
    def test_duplicate_date_conflict_preserves_snapshot(self):
        self.manifest();self.engine.supply_refresh();self.on();before=self.data()
        self.put('복사 10월 17일 출고장 (완료).xlsx',[source_row(qty=50)])
        self.settle();self.assertEqual(self.data(),before)
    def test_auto_preserves_orders_notices_mappings_and_identity(self):
        self.put();self.engine.supply_refresh();r=self.target();variant=r['supplyInfo']['sources'][0]['variant']
        self.engine.supply_match({'key':r['key'],'variants':[variant]});self.on();before=self.data()
        self.manifest();self.settle();after=self.store.read()
        for key in ['rows','notices','imports','settings']:self.assertEqual(before[key],after[key])
        self.assertEqual(before['supply']['mappings'],after['supply']['mappings'])
        self.assertFalse(self.fake.sent)
    def test_restart_retains_setting_and_unchanged_baseline(self):
        self.put();self.on();self.settle();self.restart();before=self.data();self.settle(20)
        self.assertTrue(self.supplier()['autoEnabled']);self.assertEqual(self.data(),before)
    def test_background_thread_lifecycle(self):
        self.put();self.on()
        with patch('supply_watch.POLL_SECONDS',0.02),patch('supply_watch.STABLE_SECONDS',0),patch.object(self.engine,'worker_tick'):
            self.engine.start_worker()
            try:
                end=time.monotonic()+3
                while not self.supplier()['progress'] and time.monotonic()<end:time.sleep(.01)
                self.assertTrue(self.supplier()['progress']);self.assertTrue(self.engine.supply_watcher.running())
            finally:self.engine.stop_worker()
        self.assertFalse(self.engine.supply_watcher.running());self.assertFalse(self.engine.thread.is_alive())
    def test_new_file_addition_then_change_is_detected(self):
        self.on();self.settle();self.put();self.settle(10);self.assertEqual(self.target()['supplyInfo']['plannedQty'],2)
        self.put(rows=[source_row(office='2026-10-18',qty=8)]);self.settle(20)
        self.assertEqual(self.target()['supplyInfo']['plannedQty'],8)
    def test_persisted_old_snapshot_migration_keeps_cutoff_without_file_io(self):
        self.manifest();self.engine.supply_refresh()
        with self.store.edit() as s:s['supply'].pop('progressCutoff')
        with patch('supply_watch.scan_signature',side_effect=AssertionError('startup file I/O')):self.restart()
        self.assertEqual(self.supplier()['progressCutoff'],'2026-10-17')

    def test_uppercase_extension_auto_and_manual_use_same_file(self):
        self.put('진행상황.XLSX');self.on();self.settle()
        self.assertEqual(self.target()['supplyInfo']['plannedQty'],2)
        self.engine.supply_auto_settings({'enabled':False})
        self.put('진행상황.XLSX',rows=[source_row(office='2026-10-18',qty=6)])
        self.engine.supply_refresh()
        self.assertEqual(self.target()['supplyInfo']['plannedQty'],6)
