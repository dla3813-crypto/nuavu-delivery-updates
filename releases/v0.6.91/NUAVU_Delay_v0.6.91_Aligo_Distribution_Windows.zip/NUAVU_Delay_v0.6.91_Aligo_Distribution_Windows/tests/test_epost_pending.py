"""우체국 원송장 페이지의 '반품등기번호 … (접수전)' → REGISTERED (반품등기번호 자체 페이지에는 아직 이력이 없음).
Fixtures mirror the live page shapes observed for 6082036779861 / 7897114110294 on 2026-10-19."""
import os,shutil,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import return_browser

ORIG='''<html><body><table><tr><th>등기번호</th></tr><tr><td>6082036779861</td><td>N*A<br>2026.10.16</td><td>김*미</td><td>김*미<br>2026.10.17</td><td></td><td>배달완료</td></tr></table>
<table><tr><th>날짜</th><th>시간</th><th>발생국</th><th>처리현황</th></tr>
<tr><td>2026.10.16</td><td>16:42</td><td>광주우체국</td><td>집하완료</td></tr>
<tr><td>2026.10.16</td><td>17:34</td><td>광주우체국</td><td>접수</td></tr>
<tr><td>2026.10.17</td><td>12:40</td><td>홍산우체국</td><td>배달완료 ( 배달 )<br>(수령인:김*미님 - 본인)</td></tr></table>
<p>반품등기번호:7897114110294<br>(접수전)</p></body></html>'''
PENDING_RTN='''<html><body><p>7897114110294</p><p>현재 고객님이 신청하신 접수번호에 대하여 배달정보를 찾지
못했습니다. 정보가 아직 입력되지 않았거나 처리 중입니다.</p><table><tr><th>날짜</th><th>시간</th><th>발생국</th><th>처리현황</th></tr></table></body></html>'''
TRANSIT_RTN='''<html><body><table><tr><th>날짜</th><th>시간</th><th>발생국</th><th>처리현황</th></tr>
<tr><td>2026.10.18</td><td>10:00</td><td>홍산우체국</td><td>접수</td></tr><tr><td>2026.10.18</td><td>15:00</td><td>홍산우체국</td><td>발송</td></tr></table></body></html>'''
# 2026-10-19 21:47 live shape (7091402789162 for 6082036775651): pickup registered, courier not yet collected.
PICKUP_RTN='''<html><body><table><tr><th>날짜</th><th>시간</th><th>발생국</th><th>처리현황</th></tr>
<tr><td>2026.10.18</td><td>22:03</td><td>광주우체국</td><td>운송장출력</td></tr>
<tr><td>2026.10.19</td><td>08:10</td><td>광주우체국</td><td>수거준비  \n\t\t\t\t\n\n                      픽업담당자:서*환</td></tr>
<tr><td>2026.10.19</td><td>18:30</td><td>광주우체국</td><td>미수거  \n\t\t\t\n\n                      송하인부재</td></tr></table></body></html>'''
ODD_RTN='''<html><body><table><tr><th>날짜</th><th>시간</th><th>발생국</th><th>처리현황</th></tr>
<tr><td>2026.10.19</td><td>08:10</td><td>광주우체국</td><td>알수없는상태</td></tr></table></body></html>'''
NO_RTN=ORIG.replace('<p>반품등기번호:7897114110294<br>(접수전)</p>','')

def run(pages):
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b=pw.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or '/opt/pw-browsers/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
        try:
            page=b.new_page();page.set_content('<html><body></body></html>')
            page.route('**/*',lambda route:route.fulfill(status=200,content_type='text/html; charset=utf-8',body=next(body for key,body in pages if key in route.request.url)))
            return page.evaluate(return_browser.EPOST_JS,[['6082036779861'],'https://service.epost.go.kr/trace.RetrieveDomRigiTraceList.comm?sid1=%s&postNum=%s'])
        finally:b.close()

class EpostPendingTests(unittest.TestCase):
    def test_pending_return_number_is_registered(self):
        rec=run([('7897114110294',PENDING_RTN),('6082036779861',ORIG)])['6082036779861']
        self.assertEqual((rec['return_status'],rec['return_no'],rec['orig_delivered']),('REGISTERED','7897114110294','2026-10-17'))
        self.assertNotIn('error',rec)
    def test_return_number_with_events_is_in_transit(self):
        rec=run([('7897114110294',TRANSIT_RTN),('6082036779861',ORIG)])['6082036779861']
        self.assertEqual(rec['return_status'],'IN_TRANSIT')
    def test_pre_collection_events_are_registered(self):
        rec=run([('7897114110294',PICKUP_RTN),('6082036779861',ORIG)])['6082036779861']
        self.assertEqual(rec['return_status'],'REGISTERED');self.assertNotIn('error',rec)
    def test_unknown_return_events_fall_back_to_pending_mark(self):
        rec=run([('7897114110294',ODD_RTN),('6082036779861',ORIG)])['6082036779861']
        self.assertEqual(rec['return_status'],'REGISTERED')
        rec=run([('7897114110294',ODD_RTN),('6082036779861',ORIG.replace('<br>(접수전)',''))])['6082036779861']
        self.assertIn('error',rec)
    def test_no_return_number_is_none(self):
        rec=run([('6082036779861',NO_RTN)])['6082036779861']
        self.assertEqual((rec['return_status'],rec['return_no']),('NONE',''))

if __name__=='__main__':unittest.main()
