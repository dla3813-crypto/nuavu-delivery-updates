import copy
from pathlib import Path
import pytest
from domain import SELLERS
from helpers import Base
from supply_workflow import SupplyError
from test_supply_regression import order,source_row,xlsx

class ReallocationTests(Base):
    def setUp(self):
        super().setUp();self.folder=Path(self.tmp.name)/'supply';self.folder.mkdir()
        with self.store.edit() as s:s['rows']=[]
        self.engine.import_rows({'rows':[order(1),order(2),order(3)]})
        self.engine.supply_link(str(self.folder));self.file=self.manifest(13,2)

    def manifest(self,day,qty):
        path=self.folder/f'솔리아 10월 {day}일 출고장 (완료).xlsx'
        path.write_bytes(xlsx([('출고장',[source_row(qty=qty,office=f'2026-10-{day:02}')])]))
        self.engine.supply_refresh();return path
    def info(self):return self.engine.public_state()['supply']['reallocation']
    def restore(self):return self.engine.supply_reallocate({'confirmed':True,'token':self.info()['token']})
    def allocated(self):return sum(r['supplyInfo'].get('manifestQty',0) for r in self.engine.public_state()['rows'] if r['active'])

    def test_reset_then_restore_returns_original_FIFO_without_duplicate_proofs(self):
        before=copy.deepcopy(self.engine.public_state()['rows']);self.engine.supply_reset({'confirmed':True})
        assert self.info()['available'] and self.info()['qty']==2
        self.restore();after=self.engine.public_state()['rows']
        assert [r['supplyInfo']['parts'] for r in before]==[r['supplyInfo']['parts'] for r in after]
        assert not self.store.read()['supply']['sealed'] and self.allocated()==2
        assert not self.info()['available']

    def test_snapshot_restore_survives_restart_and_missing_original(self):
        self.engine.supply_reset({'confirmed':True});self.file.unlink();self.restart()
        assert not self.info()['requiresOriginal'];self.restore();assert self.allocated()==2

    def test_legacy_reset_restores_from_same_original_file(self):
        self.engine.supply_reset({'confirmed':True})
        with self.store.edit() as s:s['supply'].pop('lastResetRestore')
        self.restart();assert self.info()['requiresOriginal'];self.restore();assert self.allocated()==2

    def test_legacy_changed_source_fails_without_partial_restore(self):
        self.manifest(17,1);self.engine.supply_reset({'confirmed':True})
        with self.store.edit() as s:s['supply'].pop('lastResetRestore')
        self.file.write_bytes(xlsx([('출고장',[source_row(qty=99)])]));before=copy.deepcopy(self.store.read())
        with pytest.raises(SupplyError,match='수량이 다릅니다'):self.restore()
        assert self.store.read()==before

    def test_legacy_missing_file_reports_error_and_keeps_state(self):
        self.engine.supply_reset({'confirmed':True})
        with self.store.edit() as s:s['supply'].pop('lastResetRestore')
        self.file.unlink();before=copy.deepcopy(self.store.read())
        with pytest.raises(SupplyError,match='읽지 못했습니다'):self.restore()
        assert self.store.read()==before

    def test_only_latest_reset_is_restored_even_if_timestamps_are_equal(self):
        self.engine.supply_reset({'confirmed':True});self.manifest(17,1);self.engine.supply_reset({'confirmed':True})
        assert self.info()['batchIds']==['manifest:2026-10-17'];self.restore()
        v=self.store.read()['supply'];assert v['manifests']['manifest:2026-10-13']['closed']
        assert not v['manifests']['manifest:2026-10-17']['closed']
        assert not self.info()['available'] and self.allocated()==3
        assert sum(p['allocated'] for pin in v['sealed'].values() for p in pin['parts'])==2

    def test_new_open_batch_and_prior_seals_survive_restore(self):
        self.engine.supply_reset({'confirmed':True});self.manifest(17,1)
        assert self.allocated()==3;self.restore();assert self.allocated()==3
        assert len(self.store.read()['supply']['manifests'])==2

    def test_restore_uses_current_orders_after_import(self):
        self.engine.supply_reset({'confirmed':True})
        self.engine.import_rows({'rows':[order(8),order(9),order(10)],'mode':'snapshot','scope':SELLERS,'replaceConfirmed':True})
        assert self.allocated()==0;self.restore();assert self.allocated()==2
        rows=[r for r in self.engine.public_state()['rows'] if r['active']]
        assert {r['orderId'] for r in rows if r['supplyInfo']['manifestQty']}=={'TEST-008','TEST-009'}

    def test_empty_repeat_reset_preserves_restore_snapshot(self):
        self.engine.supply_reset({'confirmed':True});token=self.info()['token']
        result=self.engine.supply_reset({'confirmed':True})
        assert result['batches']==0 and self.info()['token']==token
        self.restore();assert self.allocated()==2

    def test_double_click_missing_confirmation_and_stale_token_rejected(self):
        with pytest.raises(SupplyError):self.restore()
        self.engine.supply_reset({'confirmed':True});token=self.info()['token']
        with pytest.raises(SupplyError):self.engine.supply_reallocate({'token':token})
        self.manifest(17,1);self.engine.supply_reset({'confirmed':True})
        with pytest.raises(SupplyError):self.engine.supply_reallocate({'confirmed':True,'token':token})
        self.restore()
        with pytest.raises(SupplyError):self.restore()

    def test_restore_does_not_rewrite_orders_notices_settings_or_fresh_read_time(self):
        key=self.engine.public_state()['rows'][0]['key'];self.engine.external_manual({'keys':[key],'dueDate':'2026-10-21'})
        self.engine.supply_reset({'confirmed':True});before=copy.deepcopy(self.store.read())
        self.restore();after=self.store.read()
        for key in ('rows','notices','settings'):assert after[key]==before[key]
        assert after['supply']['lastReadAt']==before['supply']['lastReadAt']
        assert not self.fake.sent and not self.at.sent

    def test_rereading_after_restore_does_not_add_another_copy(self):
        self.engine.supply_reset({'confirmed':True});self.restore();self.engine.supply_refresh()
        assert self.allocated()==2 and len(self.store.read()['supply']['manifests'])==1
