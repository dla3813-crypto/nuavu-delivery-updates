// 2026-10-21 아무드 판매처: 이지어드민 "아무드 누아브" → 누아브 아무드
const assert=require('node:assert');const C=require('../web/import.js');
if(C.setShopName)C.setShopName('누아브');
assert.ok(C.SELLERS.includes('누아브 아무드'));
const rows=[['판매처','주문번호','상품명','옵션','수량','주문자','연락처','주문일'],['아무드 누아브','A1','티셔츠','블랙/FREE',1,'글로벌운영팀','02-6212-4109','2026-10-21'],['누아브 아무드','A2','티셔츠','블랙/FREE',1,'글로벌운영팀','02-6212-4109','2026-10-21'],['쿠팡','A3','티셔츠','블랙/FREE',1,'x','010-1111-2222','2026-10-21']];
const h=C.findHeader(rows);const r=C.parseRows(rows,h,C.guessMapping(rows[h]));
assert.deepStrictEqual(r.rows.map(x=>x.seller),['누아브 아무드','누아브 아무드']);assert.deepStrictEqual(Object.keys(r.excluded),['쿠팡']);
console.log('ok amood seller');
