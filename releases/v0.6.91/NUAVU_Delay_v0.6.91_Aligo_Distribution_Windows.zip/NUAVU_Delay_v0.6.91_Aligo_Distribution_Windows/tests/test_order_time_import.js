'use strict';
// 2026-10-19 23:04: 확장주문검색 has a separate 주문시간 column; the importer must keep it (당일/익일 출고 판정 uses it).
const test=require('node:test'),assert=require('node:assert/strict'),I=require('../web/import.js');
const H=['상품명','옵션명','주문수량','주문일','주문시간','수령자이름','수령자휴대폰','판매처','주문자휴대폰','주문번호','주문상세번호'];
const row=(id,date,time)=>['가디건','블랙/FREE','1',date,time,'홍','010','누아브 에이블리','010',id,'1'];
function parse(rows){const m=[H,...rows];return I.parseRows(m,0,I.guessMapping(H)).rows;}
test('date + time columns combine into orderTimestamp',()=>{
 const r=parse([row('1792412209537','2026-10-19','21:16:05')])[0];
 assert.equal(r.orderTimestamp,'2026-10-19 21:16:05');assert.equal(r.orderDate,'2026-10-19');
});
test('time without seconds and missing time column',()=>{
 assert.equal(parse([row('a','2026-10-19','9:05')])[0].orderTimestamp,'2026-10-19 09:05:00');
 assert.equal(parse([row('b','2026-10-19','')])[0].orderTimestamp,'2026-10-19');
 const noTime=['상품명','옵션명','주문수량','주문일','수령자이름','수령자휴대폰','판매처','주문자휴대폰','주문번호'];
 const rows=I.parseRows([noTime,['가디건','블랙/FREE','1','2026-10-18 15:35','홍','010','누아브 에이블리','010','1792305316627']],0,I.guessMapping(noTime)).rows;
 assert.equal(rows[0].orderTimestamp,'2026-10-18 15:35');
});
test('a 주문일 that already carries a time is not doubled',()=>{
 assert.equal(parse([row('c','2026-10-19 10:00','21:16:05')])[0].orderTimestamp,'2026-10-19 10:00');
});
