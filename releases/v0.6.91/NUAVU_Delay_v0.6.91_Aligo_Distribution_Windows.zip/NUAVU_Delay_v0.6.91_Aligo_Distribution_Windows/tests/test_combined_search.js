'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const C=require('../web/import.js');
const padding='(NA-6)[5color,3size,기획특가]웰론 후드 경량 패딩';
const vest='[묶음할인,3color]부유방 커버 나시';
const sweatshirt='[5color]도트 E 로고 레터링 프린트 나염 언발 오버핏 오프숄더 맨투맨';
const rows=[
 {key:'p-green-4xl',product:padding,option:'[그린-4XL(44)]'},
 {key:'p-green-5xl',product:padding,option:'[그린-5XL(55)]'},
 {key:'p-black-4xl',product:padding,option:'[블랙-4XL(44)]'},
 {key:'p-green-14xl',product:padding,option:'[그린-14XL]'},
 {key:'v-x-gray',product:vest,option:'[★★캡내장X★★-그레이]'},
 {key:'v-o-gray',product:vest,option:'[캡내장O-그레이]'},
 {key:'v-o-xl',product:vest,option:'캡내장 O 그레이 XL'},
 {key:'s-navy',product:sweatshirt,option:'[네이비-FREE]'},
 {key:'s-black',product:sweatshirt,option:'[블랙-FREE]'},
];
const found=(q,field='all')=>rows.filter(r=>C.matchesSearch(r,q,field)).map(r=>r.key);
for(const field of ['all','product']){
 test(field+' full padding plus color and size',()=>assert.deepEqual(found(padding+' 그린 4XL',field),['p-green-4xl']));
 test(field+' padding color only',()=>assert.deepEqual(found(padding+' 그린',field),['p-green-4xl','p-green-5xl','p-green-14xl']));
 test(field+' padding size only',()=>assert.deepEqual(found(padding+' 4XL',field),['p-green-4xl','p-black-4xl']));
 test(field+' cap marker X separate from O and XL',()=>assert.deepEqual(found(vest+' 캡내장 X',field),['v-x-gray']));
 test(field+' vest color only',()=>assert.deepEqual(found(vest+' 그레이',field),['v-x-gray','v-o-gray','v-o-xl']));
 test(field+' sweatshirt color only',()=>assert.deepEqual(found(sweatshirt+' 네이비',field),['s-navy']));
}
test('partial name and reversed token order',()=>assert.deepEqual(found('4xl 그린 경량 패딩'),['p-green-4xl']));
test('punctuation and spacing variants',()=>assert.deepEqual(found('경량 패딩 [그린 / 4XL]'),['p-green-4xl']));
test('normal whitespace NFD and fullwidth size',()=>assert.deepEqual(found(('후드\t경량  패딩\n그린 ４ｘｌ').normalize('NFD')),['p-green-4xl']));
test('joined marker and separated marker agree',()=>assert.deepEqual(found('부유방 캡내장X'),found('부유방 캡내장 X')));
test('all required terms belong to this row',()=>assert.deepEqual(found('패딩 그린 네이비'),[]));
test('unrelated customer name cannot supply missing product color',()=>assert.equal(C.matchesSearch({product:padding,option:'블랙-4XL',buyer:'그린'},'패딩 그린 4XL'),false));
test('productName and option scope preserved',()=>{assert.deepEqual(found('패딩 그린','productName'),[]);assert.equal(found('그린 4XL','option').length,1);assert.deepEqual(found('패딩 그린','option'),[]);});
test('identifiers do not become unordered word search',()=>{const r={orderId:'ORDER-24680',orderItems:[{id:'8012'}]};assert.equal(C.matchesSearch(r,'8012','orderId'),true);assert.equal(C.matchesSearch(r,'24680 ORDER','orderId'),false);});
test('phone normalization unchanged',()=>{const r={phone:'01012345678'};for(const q of ['010-1234-5678','010 1234 5678','+82 10-1234-5678','5678']){assert.equal(C.matchesSearch(r,q,'all'),true);assert.equal(C.matchesSearch(r,q,'customer'),true);assert.equal(C.matchesSearch(r,q,'product'),false);}});
test('partial names and empty queries continue working',()=>{assert.equal(found('패딩').length,4);assert.equal(C.matchesSearch({product:'HOODIE'},'hood','productName'),true);assert.equal(found('  ').length,rows.length);});
test('no matching aliases or stored mutations',()=>{const before=JSON.stringify(rows);assert.deepEqual(found('패딩 카키'),[]);found('그린 패딩');assert.equal(JSON.stringify(rows),before);});
