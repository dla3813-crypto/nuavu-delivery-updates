import copy,threading,unittest
from unittest.mock import MagicMock
from helpers import Base,MemoryVault
from test_ably_sync import snapshot
from ably_sync import AblySyncController,apply_snapshot,AblySyncError,account_cache_key
from order_browser import Flow
from order_auto import OrderAutoError,OrderAutoController

class ShopIsolationTests(Base):
    def test_changed_shop_rejects_complete_snapshot_atomically(self):
        expected={k:self.store.read()['settings'][k] for k in ('shopName','shopRevision')}
        self.engine.configure_shop({'shopName':'다른마켓'})
        before=self.store.read()
        with self.assertRaises(AblySyncError):apply_snapshot(self.engine,snapshot(),shop=expected)
        self.assertEqual(self.store.read(),before)
    def test_shop_revision_rejects_switch_back(self):
        expected={k:self.store.read()['settings'][k] for k in ('shopName','shopRevision')}
        self.engine.configure_shop({'shopName':'다른마켓'});self.engine.configure_shop({'shopName':'데모스토어'})
        with self.assertRaises(AblySyncError):apply_snapshot(self.engine,snapshot(),shop=expected)
    def test_cache_is_separate_per_shop_and_account(self):
        self.assertNotEqual(account_cache_key({'username':'same','shopName':'A'}),account_cache_key({'username':'same','shopName':'B'}))
    def test_controller_passes_selected_market_and_rejects_changed_shop(self):
        v=MemoryVault();v.save({'version':1,'username':'fake','password':'FAKE'})
        received=[]
        def collect(a,stop,progress,cache):
            received.append(copy.deepcopy(a));self.engine.configure_shop({'shopName':'다른마켓'});return snapshot()
        c=AblySyncController(self.engine,runner=collect,vault=v);c.start();c.thread.join(3)
        self.assertEqual(received[0]['shopName'],'데모스토어');self.assertEqual(c.status()['phase'],'error')
        self.assertFalse(self.store.read()['notices']);self.assertNotIn('ablySyncCache',self.store.read())
    def test_receipt_binds_original_shop_revision(self):
        def download(c,cfg):
            self.assertEqual(cfg['group'],'데모스토어');self.engine.configure_shop({'shopName':'다른마켓'});return 'fake.xls',b'fake'
        c=OrderAutoController(self.store,runner=download);c.configure(folder=self.tmp.name);c.start();c.thread.join(3)
        receipt=c.take_result(c.status()['id'])
        self.assertEqual(receipt['shopName'],'데모스토어');self.assertNotEqual(receipt['shopRevision'],self.store.read()['settings']['shopRevision'])

class HostBindingTests(unittest.TestCase):
    def flow(self):return Flow(MagicMock(),MagicMock())
    def page(self,url,visible=True):
        page=MagicMock();page.url=url;page.frames=[page];page.locator.return_value.count.return_value=1;page.locator.return_value.nth.return_value.is_visible.return_value=visible;return page
    def test_bind_only_visible_same_host_authentication(self):
        f=self.flow();p=self.page('https://ga90.ezadmin.co.kr/index.htm',False)
        self.assertFalse(f.authenticated(p));self.assertIsNone(f.admin_host)
        p.locator.return_value.nth.return_value.is_visible.return_value=True
        self.assertTrue(f.authenticated(p));self.assertEqual(f.admin_host,'ga90.ezadmin.co.kr')
        self.assertEqual(f.admin_url('/template35.htm?template=DS00'),'https://ga90.ezadmin.co.kr/template35.htm?template=DS00')
        self.assertFalse(f.authenticated(self.page('https://ga91.ezadmin.co.kr/index.htm')))
    def test_foreign_port_http_or_similar_domains_never_bind(self):
        for url in ['http://ga90.ezadmin.co.kr/','https://ga90.ezadmin.co.kr.evil.test/','https://evil.test/','https://ga90.ezadmin.co.kr:444/','https://u:p@ga90.ezadmin.co.kr/']:
            f=self.flow();self.assertFalse(f.authenticated(self.page(url)));self.assertIsNone(f.admin_host)
    def test_cross_origin_frame_cannot_prove_login(self):
        f=self.flow();p=self.page('https://ga90.ezadmin.co.kr/index.htm');p.frames=[self.page('https://ga91.ezadmin.co.kr/index.htm')]
        self.assertFalse(f.authenticated(p));self.assertIsNone(f.admin_host)
    def test_BL30_blocked_before_ack_and_receipt_on_every_server(self):
        for host in ['ga79','ga90']:
            f=self.flow();p=self.page('https://'+host+'.ezadmin.co.kr/index.htm')
            for ack,accepted in [(False,False),(True,False),(False,True)]:
                f.export_acknowledged=ack;f.export_accepted=accepted
                with self.assertRaises(OrderAutoError):f.navigate(p,'https://'+host+'.ezadmin.co.kr/template40.htm?template=BL30')
                p.goto.assert_not_called()
    def test_account_input_still_login2_only(self):
        for url in ['https://ga90.ezadmin.co.kr/login.htm','https://login1.ezadmin.co.kr/login.htm','https://evil.test/login.htm']:
            with self.assertRaises(OrderAutoError):self.flow().trusted_login(self.page(url))
