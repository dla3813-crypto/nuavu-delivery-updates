"""2026-10-22 19:44~19:45 (배포판): '최근 카카오톡을 미사용자'는 실패 · 수동 문자 대체 버튼."""
import unittest
from pathlib import Path
from aligo_provider import delivery_result
ROOT=Path(__file__).resolve().parents[1]
class Classifier(unittest.TestCase):
    def test_recent_kakao_non_user_is_failure(self):
        row={'msgid':'53921527','status':'3','rslt':'9','rslt_message':'최근 카카오톡을 미사용자','rsltdate':'2026-10-22 09:00:51','smid':'0'}
        self.assertEqual(delivery_result(row),'FAILED');self.assertEqual(delivery_result({**row,'rslt_message':'알수없는코드'}),'PENDING')
    def test_manual_fallback_wired(self):
        self.assertIn("'/api/aligo-fallback':lambda:engine.manual_fallback(p)",(ROOT/'app.py').read_text(encoding='utf-8'))
        self.assertIn('def manual_fallback(self,p):',(ROOT/'aligo_workflow.py').read_text(encoding='utf-8'))
        self.assertIn('fallback-sms',(ROOT/'web/error_log.js').read_text(encoding='utf-8'))
