import copy
from helpers import Base,sample_rows
from domain import Store,ValidationError,FIRST
from branding import import_seller,seller_identity,selected_seller_labels

class ExcelSellerTests(Base):
    def setUp(self):
        super().setUp();self.engine.configure_shop({'shopName':'메이아워'})
    def prefs(self,available,scope):
        self.engine.configure_import_scope(dict(scopeLabels=True,available=available,scope=scope,shopRevision=self.store.read()['settings']['shopRevision']))
    def load(self,rows,available=None,scope=None,**extra):
        available=available or list(dict.fromkeys(r['sourceSeller'] for r in rows))
        scope=available if scope is None else scope
        self.prefs(available,scope)
        p=dict(scopeLabels=True,scopeFilter=True,available=available,scope=scope,rows=rows,mode='snapshot',replaceConfirmed=True,shopRevision=self.store.read()['settings']['shopRevision'])
        p.update(extra);return self.engine.import_rows(p)
    def row(self,label,oid='NEW',**extra):
        return sample_rows()[0]|dict(sourceSeller=label,orderId=oid,**extra)
    def test_names_on_either_side_and_amood(self):
        self.assertEqual(import_seller('에이블리 멜릿','멜릿'),'누아브 에이블리')
        self.assertEqual(import_seller('메이아워 아무드','메이아워'),'누아브 아무드')
        self.assertEqual(import_seller('아무드 메이아워','메이아워'),'누아브 아무드')
        self.assertEqual(import_seller('메이아워 새채널','메이아워'),'누아브 새채널')
        for label in ['앤로랑 에이블리','뉴메이아워 에이블리','메이아워2 에이블리']:
            self.assertIsNone(import_seller(label,'메이아워'))
    def test_choices_remember_absent_seller_and_database_restart(self):
        a,b='메이아워 에이블리','메이아워 아무드'
        before=copy.deepcopy(self.store.read())
        self.prefs([a,b],[a]);self.prefs([a],[a]);self.store.close();self.store=Store(self.tmp.name);self.restart()
        self.assertEqual(selected_seller_labels(self.store.read()['settings'],[a,b]),[a])
        for k in ('rows','notices','imports','supply'):self.assertEqual(self.store.read().get(k),before.get(k))
    def test_prefs_separate_shops_and_retain_empty(self):
        self.prefs(['메이아워 에이블리'],[])
        self.engine.configure_shop({'shopName':'멜릿'})
        self.prefs(['에이블리 멜릿'],['에이블리 멜릿'])
        self.engine.configure_shop({'shopName':'메이아워'})
        self.assertEqual(selected_seller_labels(self.store.read()['settings'],['메이아워 에이블리']),[])
    def test_imports_amood_and_keeps_original_seller_label(self):
        self.load([self.row('메이아워 에이블리','A'),self.row('메이아워 아무드','B')])
        a,b=self.store.read()['rows'][-2:]
        self.assertEqual((a['seller'],b['seller']),('누아브 에이블리','누아브 아무드'))
        self.assertEqual(b['sourceSeller'],'메이아워 아무드')
        self.assertTrue(any(r['orderId']=='B' for r in self.engine.public_state()['rows']))
    def test_amood_sms_preview_works_without_sending(self):
        self.load([self.row('메이아워 아무드')])
        key=self.store.read()['rows'][-1]['key']
        groups=self.engine.build_sms_groups(self.store.read(),dict(keys=[key],dueDate='2026-10-30',template=FIRST,kind='AUTO'))
        self.assertEqual(groups[0]['seller'],'누아브 아무드')
        self.assertEqual(len(groups),1)
    def test_absent_seller_and_its_reservation_survive_snapshot(self):
        self.load([self.row('메이아워 아무드','B'),self.row('메이아워 에이블리','A')])
        before=copy.deepcopy(self.store.read()['rows'][-2])
        with self.store.edit() as s:
            s['notices'].append({'id':'FAKE','status':'SCHEDULED','seller':before['seller'],'itemKeys':[before['key']]})
        self.load([self.row('메이아워 에이블리','C')])
        self.assertEqual(next(r for r in self.store.read()['rows'] if r['orderId']=='B'),before)
        self.assertEqual(self.store.read()['notices'][-1]['status'],'SCHEDULED')
        self.assertFalse(next(r for r in self.store.read()['rows'] if r['orderId']=='A')['active'])
    def test_unchecked_rows_ignored_before_validation(self):
        a,b='메이아워 에이블리','메이아워 아무드'
        result=self.load([self.row(a),self.row(b,qty=-1),self.row('앤로랑 아무드',qty=-1)],[a,b],[a])
        self.assertEqual(result['added'],1)
    def test_existing_ably_key_and_ledger_are_preserved(self):
        self.engine.import_rows({'rows':[self.row('메이아워 에이블리')|{'seller':'누아브 에이블리'}]})
        old=copy.deepcopy(self.store.read()['rows'][-1])
        self.load([self.row('에이블리 메이아워')])
        new=next(r for r in self.store.read()['rows'] if r['orderId']=='NEW')
        self.assertEqual(old['key'],new['key']);self.assertTrue(new['active'])
    def test_missing_raw_source_and_stale_selection_rejected(self):
        a='메이아워 에이블리';self.prefs([a],[a])
        before=copy.deepcopy(self.store.read()['rows'])
        p=dict(scopeLabels=True,available=[a],scope=[a],shopRevision=self.store.read()['settings']['shopRevision'],rows=[sample_rows()[0]],mode='merge')
        with self.assertRaises(ValidationError):self.engine.import_rows(p)
        self.prefs([a],[]);p['rows']=[self.row(a)]
        with self.assertRaises(ValidationError):self.engine.import_rows(p)
        self.assertEqual(before,self.store.read()['rows'])
    def test_invisible_or_other_shop_scope_rejected(self):
        a='메이아워 에이블리'
        for available,scope in [([a],['메이아워 아무드']),(['앤로랑 아무드'],[]),([a,a],[a])]:
            with self.assertRaises(ValidationError):self.prefs(available,scope)
    def test_unchecked_alias_not_removed_by_same_channel_snapshot(self):
        a,b='메이아워 에이블리','에이블리 메이아워'
        self.load([self.row(a,'A'),self.row(b,'B')])
        before=copy.deepcopy(next(r for r in self.store.read()['rows'] if r['orderId']=='B'))
        self.load([self.row(a,'C')],[a,b],[a])
        self.assertEqual(next(r for r in self.store.read()['rows'] if r['orderId']=='B'),before)
    def test_same_id_in_unselected_alias_is_not_overwritten(self):
        a,b='메이아워 에이블리','에이블리 메이아워'
        self.load([self.row(a)])
        before=copy.deepcopy(self.store.read()['rows'])
        with self.assertRaises(ValidationError):self.load([self.row(b)])
        self.assertEqual(before,self.store.read()['rows'])
