import unittest
from return_browser import return_status_counts
from return_data import ReturnError,read_returns
from test_returns import xlsx,TODAY

def card(title,n):return {'title':title,'text':title+'\n\n'+str(n)+'건'}
def cards(requested=5,waiting=22):return [card('반품요청 (접수필요)',requested),card('검수대기',waiting)]

class ReturnCountTests(unittest.TestCase):
 def test_user_case_and_other_statuses_excluded(self):
  parsed=return_status_counts(cards()+[card('검수완료 후 환불요청',100),card('반품완료',200)])
  self.assertEqual(parsed,{'requested':5,'waiting':22});self.assertEqual(sum(parsed.values()),27)
 def test_zero_requested_still_includes_waiting(self):
  self.assertEqual(sum(return_status_counts(cards(0,22)).values()),22)
  self.assertEqual(sum(return_status_counts(cards(0,0)).values()),0)
 def test_whitespace_and_comma_format(self):
  self.assertEqual(return_status_counts([card('반품 요청',0),card('검수 대기','1,234')]),{'requested':0,'waiting':1234})
 def test_missing_or_duplicate_status_fails(self):
  for rows in [[],cards()[:1],cards()[1:],cards()+[card('검수대기',22)],cards()+[card('반품요청',5)]]:
   with self.subTest(rows=rows),self.assertRaises(ReturnError):return_status_counts(rows)
 def test_bad_numbers_and_limit_fail(self):
  for value in ['','로딩 중','-1','1.5','1,23','22개','22건 3','20001']:
   with self.subTest(value=value),self.assertRaises(ReturnError):return_status_counts(cards(0,value))
  with self.assertRaises(ReturnError):return_status_counts(cards(10001,10000))
 def test_twenty_seven_rows_allowed_and_mismatch_reports_both_counts(self):
  rows=[['2026-10-10','가상 고객','구매자','510000000001',0,'ORDER'+str(i),'가상 상품'] for i in range(27)]
  total=sum(return_status_counts(cards()).values())
  self.assertEqual(len(read_returns(xlsx(rows),total,TODAY)),27)
  with self.assertRaisesRegex(ReturnError,'합계 27건과 엑셀 상품 26개'):read_returns(xlsx(rows[:-1]),total,TODAY)
