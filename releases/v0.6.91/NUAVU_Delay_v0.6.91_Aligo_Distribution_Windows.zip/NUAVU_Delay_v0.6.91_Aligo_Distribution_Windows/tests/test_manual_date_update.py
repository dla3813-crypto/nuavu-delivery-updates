"""Explicit no-send date actions; isolated stores and fake message providers."""
import copy,unittest,uuid
from pathlib import Path
from external_notices import ExternalError
if '_Distribution' in Path(__file__).resolve().parents[1].name:
 from helpers import Base
 from test_supply_regression import order
 from test_ably_sync import snapshot
else:
 from test_v056 import Base
 from test_v068 import order
 from test_v0638 import snapshot
from ably_sync import apply_snapshot

class ManualDateUpdateTests(Base):
 def setUp(self):
  super().setUp()
  with self.store.edit() as s:s['rows']=[]
  self.engine.import_rows({'rows':[order(1)|{'orderId':'12345','orderItemId':'801'}]})
  self.key=self.store.read()['rows'][0]['key']
 def payload(self,**kwargs):return {'keys':[self.key],'dueDate':'2026-10-30','mode':'set_due_date','requestId':str(uuid.uuid4()),'templateKey':'first',**kwargs}
 def record(self,**kwargs):return self.engine.external_manual(self.payload(**kwargs))
 def test_date_changes_and_each_intent_adds_history_even_same_date(self):
  self.record();self.assertEqual(self.row()['dueDate'],'2026-10-30');self.assertEqual(self.row()['noticeCount'],1)
  self.record();self.assertEqual(self.row()['noticeCount'],2)
  self.record(dueDate='2026-11-02',templateKey='change');self.assertEqual(self.row()['dueDate'],'2026-11-02');self.assertEqual(self.row()['noticeCount'],3)
  self.assertEqual(len(self.fake.sent),0)
 def test_retry_same_request_uses_persisted_history_and_does_not_stack(self):
  p=self.payload();self.engine.external_manual(p);before=copy.deepcopy(self.store.read()['notices'])
  result=self.engine.external_manual(p);self.assertTrue(result['replayed']);self.assertEqual(self.store.read()['notices'],before)
 def test_reused_request_changed_payload_rejected(self):
  p=self.payload();self.engine.external_manual(p);before=self.store.read()
  for edit in [{'dueDate':'2026-11-01'},{'keys':[self.key,'missing']},{'templateKey':'change'}]:
   with self.subTest(edit=edit),self.assertRaises(ExternalError):self.engine.external_manual(p|edit)
  self.assertEqual(self.store.read(),before)
 def test_explicit_action_overrides_older_actual_notice_and_keeps_it(self):
  self.send(keys=[self.key],dueDate='2026-10-25');old=copy.deepcopy(self.last());self.clock(12)
  sent=len(self.fake.sent);self.record();self.assertEqual(self.row()['dueDate'],'2026-10-30');self.assertEqual(self.row()['noticeCount'],2)
  self.assertEqual(self.store.read()['notices'][0],old);self.assertEqual(len(self.fake.sent),sent)
 def test_new_actual_notice_after_explicit_action_wins(self):
  self.record();self.clock(12);self.send(keys=[self.key],dueDate='2026-11-04')
  self.assertEqual(self.row()['dueDate'],'2026-11-04')
 def test_sync_cannot_undo_explicit_new_date(self):
  apply_snapshot(self.engine,snapshot());self.clock(12);self.record();self.assertEqual(self.row()['dueDate'],'2026-10-30')
  self.clock(13);s=snapshot();s['entries'][0]['range']='2026-10-23';apply_snapshot(self.engine,s)
  self.assertEqual(self.row()['dueDate'],'2026-10-30')
 def test_legacy_manual_and_excel_priority_unchanged(self):
  apply_snapshot(self.engine,snapshot());self.clock(12)
  self.engine.external_manual({'keys':[self.key],'dueDate':'2026-10-30'})
  self.assertEqual(self.row()['dueDate'],'2026-10-22')
 def test_sending_rejects_atomic(self):
  self.queue(keys=[self.key])
  with self.store.edit() as s:s['notices'][0]['status']='SENDING'
  before=self.store.read()
  with self.assertRaises(ExternalError):self.record()
  self.assertEqual(self.store.read(),before)
 def test_queued_batch_cancelled_without_send(self):
  self.queue(keys=[self.key]);self.record();self.assertEqual(self.store.read()['notices'][0]['status'],'CANCELLED');self.assertEqual(len(self.fake.sent),0)
 def test_bad_mode_request_date_and_missing_key_reject_without_mutation(self):
  before=self.store.read()
  for edit in [{'mode':'send'},{'requestId':''},{'requestId':12},{'dueDate':'2026-02-31'},{'keys':[self.key,'missing']},{'templateKey':'soldout'}]:
   with self.subTest(edit=edit),self.assertRaises(ExternalError):self.record(**edit)
  self.assertEqual(self.store.read(),before)
 def test_multiple_orders_same_request_stack_once_per_product(self):
  self.engine.import_rows({'rows':[order(2)|{'orderId':'other','orderItemId':'802'}]})
  keys=[r['key'] for r in self.store.read()['rows'] if r['active']];self.assertEqual(len(keys),2)
  p=self.payload(keys=keys);self.engine.external_manual(p);self.engine.external_manual(p)
  self.assertEqual([r['noticeCount'] for r in self.engine.public_state()['rows']],[1,1])
 def test_no_original_order_values_changed(self):
  before=copy.deepcopy(self.store.read()['rows']);self.record();self.assertEqual(self.store.read()['rows'],before)
