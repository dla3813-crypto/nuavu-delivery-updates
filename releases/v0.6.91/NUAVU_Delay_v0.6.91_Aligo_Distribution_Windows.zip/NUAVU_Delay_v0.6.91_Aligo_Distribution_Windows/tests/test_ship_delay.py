"""2026-10-21 20:33: 화요일 중국 출고가 밀린 주 — 수 18시 질문, 금요일 → 다음주 화~수 / 토요일 → 다음주 수~목."""
import sys,unittest
from datetime import date,datetime,timedelta,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from supply_calendar import route
from supply_workflow import ship_delay_question,SupplyError
try:
    from test_v056 import Base
except ImportError:
    from helpers import Base
KST=timezone(timedelta(hours=9))
TUE=date(2026,10,20)

class RouteTests(unittest.TestCase):
    def test_normal_tuesday_wave_unchanged(self):
        p=route(date(2026,10,19))
        self.assertEqual((p['chinaDate'],p['koreaStart'],p['koreaEnd']),('2026-10-20','2026-10-26','2026-10-26'))
    def test_friday_delay_next_tue_wed(self):
        p=route(date(2026,10,19),delays={'2026-10-20':{'status':'delayed','departure':'2026-10-23'}})
        self.assertEqual((p['chinaDate'],p['koreaStart'],p['koreaEnd'],p['delayedFrom']),('2026-10-23','2026-10-27','2026-10-28','2026-10-20'))
    def test_saturday_delay_next_wed_thu(self):
        p=route(date(2026,10,19),delays={'2026-10-20':{'status':'delayed','departure':'2026-10-24'}})
        self.assertEqual((p['chinaDate'],p['koreaStart'],p['koreaEnd']),('2026-10-24','2026-10-28','2026-10-29'))
    def test_shipped_answer_and_real_manifest_keep_dates(self):
        self.assertEqual(route(date(2026,10,19),delays={'2026-10-20':{'status':'shipped'}})['chinaDate'],'2026-10-20')
        p=route(TUE,departure=TUE,delays={'2026-10-20':{'status':'delayed','departure':'2026-10-23'}})
        self.assertEqual(p['chinaDate'],'2026-10-20')   # a real Tuesday 출고장 is never moved
    def test_existing_friday_manifest_rule_untouched(self):
        p=route(date(2026,10,23),departure=date(2026,10,23))
        self.assertEqual((p['koreaStart'],p['koreaEnd']),('2026-10-28','2026-10-29'))

class QuestionTests(unittest.TestCase):
    V={'folder':'/x','manifests':{},'shipDelays':{}}
    def q(self,dt,v=None):return ship_delay_question(v or self.V,dt)
    def test_window(self):
        self.assertIsNone(self.q(datetime(2026,10,21,17,59,tzinfo=KST)))
        self.assertEqual(self.q(datetime(2026,10,21,18,0,tzinfo=KST)),{'tuesday':'2026-10-20','friday':'2026-10-23','saturday':'2026-10-24'})
        self.assertEqual(self.q(datetime(2026,10,26,9,tzinfo=KST))['tuesday'],'2026-10-20')   # still open on Monday
        self.assertIsNone(self.q(datetime(2026,10,27,9,tzinfo=KST)))                       # new Tuesday
    def test_no_question_when_manifest_answer_or_no_folder(self):
        dt=datetime(2026,10,21,19,tzinfo=KST)
        self.assertIsNone(self.q(dt,{**self.V,'manifests':{'manifest:2026-10-20':{'date':'2026-10-20'}}}))
        self.assertIsNone(self.q(dt,{**self.V,'shipDelays':{'2026-10-20':{'status':'shipped'}}}))
        self.assertIsNone(self.q(dt,{**self.V,'folder':''}))

class AnswerTests(Base):
    def test_answer_records_and_validates(self):
        r=self.engine.ship_delay_answer({'tuesday':'2026-10-20','answer':'delayed','departure':'fri'})
        self.assertIn('금요일 10/23',r['message']);self.assertEqual(r['shipDelays']['2026-10-20']['departure'],'2026-10-23')
        self.engine.ship_delay_answer({'tuesday':'2026-10-20','answer':'delayed','departure':'sat'})
        self.assertEqual(self.store.read()['supply']['shipDelays']['2026-10-20']['departure'],'2026-10-24')
        self.engine.ship_delay_answer({'tuesday':'2026-10-20','answer':'undo'});self.assertNotIn('2026-10-20',self.store.read()['supply']['shipDelays'])
        for bad in ({'tuesday':'2026-10-21','answer':'shipped'},{'tuesday':'2026-10-20','answer':'delayed','departure':'mon'},{'tuesday':'x','answer':'shipped'}):
            with self.subTest(bad=bad),self.assertRaises(SupplyError):self.engine.ship_delay_answer(bad)
    def test_ui_wired(self):
        self.assertIn('ship_delay.js',(ROOT/'web'/'index.html').read_text(encoding='utf-8'))
        self.assertIn("'/ship_delay.js':'ship_delay.js'",(ROOT/'app.py').read_text(encoding='utf-8'))

if __name__=='__main__':unittest.main()
