"""06:53 보고: 지그재그 로그인 뒤 https://partners.kakaostyle.com/home (입점 스토어 목록)에 떨어지면 쇼핑몰 이름 카드를 눌러 들어간다."""
import os,shutil,sys,threading,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import zigzag_browser as zb

HOME='''<!doctype html><html><body><h2>입점 스토어</h2>
<div onclick="location.href='/shop/nuavu/stats'"><span>패션</span><p>누아브</p></div>
<div onclick="location.href='/shop/solia/stats'"><span>패션</span><p>솔리아</p></div></body></html>'''
STATS='<!doctype html><html><body><h1>대시보드</h1><p>반품요청 3건 · 교환요청 1건</p></body></html>'
class FakeStop:
    def is_set(self):return False

def serve(ctx):
    def handle(route,request):
        path=request.url.split('kakaostyle.com',1)[1].split('?')[0]
        if path=='/home':route.fulfill(status=200,content_type='text/html; charset=utf-8',body=HOME)
        elif path.startswith('/shop/'):route.fulfill(status=200,content_type='text/html; charset=utf-8',body=STATS)
        else:route.fulfill(status=404,body='')
    ctx.route('https://partners.kakaostyle.com/**',handle)

class StoreChooser(unittest.TestCase):
    def test_picks_store_by_shop_name_then_slug(self):
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            b=pw.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or '/opt/pw-browsers/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
            try:
                ctx=b.new_context();serve(ctx);page=ctx.new_page();msgs=[];r=zb.Reader(page,FakeStop(),msgs.append,ctx)
                page.goto('https://partners.kakaostyle.com/home')
                self.assertTrue(r.store_chooser());self.assertFalse(r.dashboard('nuavu'))
                self.assertTrue(r.entered('nuavu','누아브'));self.assertTrue(r.dashboard('nuavu'));self.assertIn('/shop/nuavu/stats',page.url)
                self.assertTrue(any('누아브 스토어를 선택' in m for m in msgs))
                # 배포판: a different 쇼핑몰 이름 → that card; unknown name → clear error
                page.goto('https://partners.kakaostyle.com/home');self.assertTrue(r.entered('solia','솔리아'));self.assertIn('/shop/solia/stats',page.url)
                page.goto('https://partners.kakaostyle.com/home')
                with self.assertRaises(zb.ZigzagError) as cm:r.entered('nuavu','없는상점')
                self.assertIn('없는상점',str(cm.exception))
                # already on the dashboard: nothing to click
                page.goto('https://partners.kakaostyle.com/shop/nuavu/stats');self.assertFalse(r.store_chooser());self.assertTrue(r.entered('nuavu','누아브'))
            finally:b.close()
if __name__=='__main__':unittest.main()
