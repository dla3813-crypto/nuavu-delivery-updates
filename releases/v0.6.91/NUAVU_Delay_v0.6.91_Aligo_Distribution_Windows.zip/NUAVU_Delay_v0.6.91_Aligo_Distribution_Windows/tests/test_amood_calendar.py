"""2026-10-21 18:47: 아무드 '날짜로 선택하기' 달력 (Oct 2026 · ‹ › · 다른 달 회색) 선택."""
import sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT)]
from amood_push import CAL_JS,CONFIRM_JS,spaced,SEARCH_MARK_JS,SEARCH_GUARD_JS
def month(y,m,first_dow,days,prev_days,disabled_upto=0):
    cells=[]
    for k in range(first_dow):cells.append(('ant-picker-cell',prev_days-first_dow+1+k))
    for d in range(1,days+1):cells.append(('ant-picker-cell ant-picker-cell-in-view'+(' ant-picker-cell-disabled' if d<=disabled_upto else ''),d))
    n=1
    while len(cells)%7 or len(cells)<42:cells.append(('ant-picker-cell',n));n+=1
    rows=''.join('<tr>'+''.join(f'<td class="{c}"><div class="ant-picker-cell-inner">{d}</div></td>' for c,d in cells[i:i+7])+'</tr>' for i in range(0,len(cells),7))
    return rows
html=lambda y,mn,rows:f'''<div class="dlg">2026 rules 2026<div class="ant-picker-dropdown"><div class="ant-picker-panel"><div class="ant-picker-header"><button class="ant-picker-header-super-prev-btn">«</button><button class="ant-picker-header-prev-btn">‹</button><div class="ant-picker-header-view"><button>{mn}</button> <button>{y}</button></div><button class="ant-picker-header-next-btn" onclick="window.nextClicked=1">›</button><button class="ant-picker-header-super-next-btn">»</button></div><table><thead><tr><th>Su</th><th>Mo</th><th>Tu</th><th>We</th><th>Th</th><th>Fr</th><th>Sa</th></tr></thead><tbody>{rows}</tbody></table><div>Today</div></div></div></div>'''

class CalendarTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            from playwright.sync_api import sync_playwright
            cls.pw=sync_playwright().start();cls.b=cls.pw.chromium.launch()
        except Exception as exc:raise unittest.SkipTest(f'chromium unavailable: {exc}')
    @classmethod
    def tearDownClass(cls):cls.b.close();cls.pw.stop()
    def run_cal(self,y,mn,rows,due):
        pg=self.b.new_page();pg.set_content(html(y,mn,rows))
        try:
            r=pg.evaluate(CAL_JS,due)
            day=pg.evaluate("(()=>{const e=document.querySelector('[data-nuavu-day]');return e?[e.textContent,e.closest('td').className]:null})()")
            nxt=pg.evaluate("!!document.querySelector('[data-nuavu-next]')")
            return r,day,nxt
        finally:pg.close()
    def test_picks_day_in_current_month_not_grey_neighbour(self):
        r,day,_=self.run_cal(2026,'Oct',month(2026,10,4,31,30,21),'2026-10-27')
        self.assertEqual(r['state'],'cell');self.assertEqual(day[0],'27');self.assertIn('in-view',day[1])
    def test_disabled_day_is_not_clicked(self):
        r,day,_=self.run_cal(2026,'Oct',month(2026,10,4,31,30,21),'2026-10-15')
        self.assertEqual(r['state'],'disabled');self.assertIsNone(day)
    def test_moves_to_next_month(self):
        r,_,nxt=self.run_cal(2026,'Oct',month(2026,10,4,31,30,21),'2026-11-03')
        self.assertEqual(r['state'],'next');self.assertTrue(nxt)
        r,day,_=self.run_cal(2026,'Nov',month(2026,11,0,30,31),'2026-11-03')
        self.assertEqual((r['state'],day[0]),('cell','3'));self.assertIn('in-view',day[1])

    def test_confirm_box_ok_button_with_spaced_korean(self):
        """2026-10-21 18:55: '배송지연 메시지를 발송 하시겠습니까?' — antd renders '확 인'."""
        pg=self.b.new_page()
        try:
            pg.set_content('<div class="ant-modal-content"><div>1차 배송 지연 메시지 발송</div><button>배송 지연 메시지 발송</button></div>'
                           '<div class="ant-modal-confirm"><div>배송지연 메시지를 발송 하시겠습니까?<br>예상 출고일 2026-10-27</div>'
                           '<div class="btns"><button class="ant-btn">취 소</button><button class="ant-btn ant-btn-primary">확 인</button></div></div>')
            r=pg.evaluate(CONFIRM_JS)
            self.assertTrue(r['ok']);self.assertEqual(r['name'],'확인')
            self.assertEqual(pg.evaluate("document.querySelector('[data-nuavu-ok]').textContent"),'확 인')
            self.assertTrue(spaced('확인').match('확 인'));self.assertFalse(spaced('발송').match('배송 지연 메시지 발송'))
        finally:pg.close()

    FORM=('<div style="display:flex;gap:8px;align-items:center;height:40px"><label style="width:80px">검색어</label>'
          '<div class="ant-select" style="width:120px"><div class="ant-select-selector">전체</div></div>{inp}</div>')
    TABLE=('<table class="ant-table"><thead><tr><th>주문번호</th><th>송장번호</th></tr></thead><tbody>'
           '<tr><td>2318744</td><td><input type="text" placeholder="송장번호 입력" style="width:140px"></td></tr></tbody></table>')
    def mark(self,inp):
        pg=self.b.new_page()
        try:
            pg.set_content('<div>'+self.FORM.format(inp=inp)+'<div style="height:400px"></div>'+self.TABLE+'</div>')
            r=pg.evaluate(SEARCH_MARK_JS)
            el=pg.query_selector('[data-nuavu-search="1"]')
            return r,(el.get_attribute('placeholder') if el else None),(pg.evaluate(SEARCH_GUARD_JS,el) if el else None),pg.query_selector('[data-nuavu-searchtype="1"]') is not None
        finally:pg.close()
    def test_search_box_is_the_form_input_even_when_disabled(self):
        """2026-10-21 19:10: 주문번호가 표의 송장번호 칸에 입력되던 문제."""
        r,ph,guard,sel=self.mark('<input type="text" disabled placeholder="검색어를 입력해주세요" style="width:200px">')
        self.assertTrue(r['input']);self.assertEqual(ph,'검색어를 입력해주세요');self.assertTrue(guard);self.assertTrue(sel);self.assertTrue(r['disabled'])
    def test_never_marks_table_invoice_input(self):
        r,ph,guard,sel=self.mark('')
        self.assertFalse(r['input']);self.assertIsNone(ph)

if __name__=='__main__':unittest.main()
