"""메시지 없는 배송지연 안내 → 해당 에이블리 주문에 배송지연 메시지만 발송 처리 (예상출고일 미수집)."""
import sys,unittest
from pathlib import Path
from unittest.mock import MagicMock
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
try:
    from test_v056 import Base
except ImportError:
    from helpers import Base
try:
    from test_v068 import order
except ImportError:
    from test_supply_regression import order
from ably_sync import AblySyncController,AblySyncError
from order_items import ABLY

def item(ident='801',oid='12345',qty=1,sent=False,date=''):return dict(itemId=ident,orderId=oid,qty=qty,noticeSent=sent,noticeDate=date)

class AutoPushTests(Base):
    def setUp(self):
        super().setUp()
        with self.store.edit() as s:
            s['rows']=[];s['settings']['shopName']=s['settings'].get('shopName') or '누아브'
        self.engine.import_rows({'rows':[order(1)|{'orderId':'12345','orderItemId':'801','seller':ABLY},order(2)|{'orderId':'22222','orderItemId':'802','seller':ABLY},order(3)|{'orderId':'33333','seller':'누아브 자사몰'}]})
        rows=self.store.read()['rows'];self.keys={r['orderId']:r['key'] for r in rows}
        self.vault=MagicMock(available=True);self.vault.load.return_value=dict(version=1,username='fake',password='FAKE-SECRET')
        self.calls=[]
        def runner(a,stop,progress,cache,planner=None,push_only=False):
            self.calls.append(push_only)
            targets,skipped=planner([item(),item('802','22222')])
            return {'entries':[],'total':2,'notifiedTotal':0,'pages':1,'complete':True,'verified':True,'pushOnly':True,'planned':len(targets),
                    'pushes':list(skipped)+[dict(t,status='sent',reason='',platformNotice='2026-10-14') for t in targets]}
        self.c=AblySyncController(self.engine,runner=runner,vault=self.vault)
    def test_push_only_sends_for_given_keys_without_importing_dates(self):
        self.engine.external_manual({'keys':[self.keys['12345'],self.keys['22222']],'dueDate':'2026-10-21'})
        before=len(self.store.read()['notices'])
        self.c.start_push_only([self.keys['12345']]);self.c.thread.join(4);st=self.c.status()
        self.assertEqual(st['phase'],'done',st);self.assertTrue(st['pushOnly']);self.assertEqual(self.calls,[True])
        log=self.store.read()['ablyPushLog'];self.assertEqual([(p['itemId'],p['status']) for p in log],[('801','sent')])
        self.assertIn('예상출고일은 가져오지 않았습니다',st['message'])
        self.assertEqual(len(self.store.read()['notices']),before)  # no ably_sync notices added
        self.assertEqual(self.store.read().get('ablySync',{}).get('lastSync',''),'')
        self.assertTrue(any('자동 발송 처리 완료' in a['title'] for a in self.store.read().get('alerts',[])))
    def test_no_target_reports_cleanly(self):
        self.c.start_push_only([self.keys['12345']]);self.c.thread.join(4);st=self.c.status()
        self.assertEqual(st['phase'],'done');self.assertIn('대상이 없습니다',st['message']);self.assertNotIn('ablyPushLog',self.store.read())
    def test_requires_keys_and_rejects_while_running(self):
        with self.assertRaises(AblySyncError):self.c.start_push_only([])
    def test_manual_notice_hook_receives_keys_and_respects_setting(self):
        seen=[]
        self.engine.manual_notice_hook=lambda keys:(seen.append(list(keys)) or '에이블리 발송 처리 시작')
        r=self.engine.external_manual({'keys':[self.keys['12345']],'dueDate':'2026-10-21'})
        self.assertEqual(seen,[[self.keys['12345']]]);self.assertIn('에이블리 발송 처리 시작',r['message'])
        self.engine.external_manual({'keys':[self.keys['22222']],'dueDate':'2026-10-22'})
        self.assertEqual(len(seen),2)  # the desktop hook decides per platform switch; the engine always hands the keys over
        self.assertFalse(self.engine.set_auto_ably_push({'autoAblyPush':False})['autoAblyPush']);self.assertFalse(self.store.read()['settings']['autoAblyPush'])
    def test_hook_failure_becomes_red_alert_not_error(self):
        def boom(keys):raise RuntimeError('다른 웹 작업 진행 중')
        self.engine.manual_notice_hook=boom
        r=self.engine.external_manual({'keys':[self.keys['12345']],'dueDate':'2026-10-21'})
        self.assertEqual(r['items'],1)
        alerts=self.store.read().get('alerts',[]);self.assertTrue(any(a['level']=='error' and '자동 발송 처리 시작 실패' in a['title'] for a in alerts))

if __name__=='__main__':unittest.main()
