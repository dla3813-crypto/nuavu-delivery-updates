"""2026-10-20 11:38 요청 (공통): 수동매칭 › 수동매칭 필요 — 출고장·진행상황에만 있고 연결된 주문이 없는 거래처 상품·옵션."""
import unittest,importlib.util
from pathlib import Path
import importlib
_mod=importlib.import_module('test_v068') if importlib.util.find_spec('test_v068') else importlib.import_module('test_supply_regression')
source_row,order=_mod.source_row,_mod.order
def _st():return _mod.SupplyTests   # keep the class out of this module's namespace so pytest doesn't collect it twice

from pathlib import Path as _P
class ManualNeeded(_st().__mro__[1]):
    # Base + the SupplyTests fixture (copied) without re-collecting its tests
    def setUp(self):
        super().setUp();self.folder=_P(self.tmp.name)/'자료';self.folder.mkdir();self.engine.supply_link(str(self.folder))
        self.set_orders([order(1),order(2),order(3,product='다른상품')])
    set_orders=_st().set_orders;file=_st().file;refresh=_st().refresh;active=_st().active
    def unmatched(self):return self.engine.public_state()['supply']['unmatchedVariants']
    def test_unmatched_variants_listed_until_linked(self):
        # 가디건 아이보리 → order(1)/(2)와 자동 연결; '번역다른니트 블랙' 은 어떤 주문에도 없음 → 수동매칭 필요
        self.refresh([source_row(),source_row(product='번역다른니트',color='블랙',qty=3)])
        s=self.engine.public_state()['supply'];self.assertEqual(s['manualNeededCount'],1)
        [v]=self.unmatched();self.assertEqual((v['product'],v['color'],v['size'],v['qty']),('번역다른니트','블랙','F',3));self.assertIn('manifest',v['origins'])
        # 연결: 기존 수동 규칙을 지우지 않고 덧붙인다
        row=next(r for r in self.active() if r['product']=='다른상품')
        self.engine.supply_match({'key':row['key'],'variants':(row['supplyInfo'].get('manualVariants') or [])+[v['variant']]})
        self.assertEqual(self.unmatched(),[]);self.assertEqual(self.engine.public_state()['supply']['manualNeededCount'],0)
        row=next(r for r in self.active() if r['product']=='다른상품');self.assertEqual(row['supplyInfo']['manualVariants'],[v['variant']])
    def test_sold_out_and_inactive_rows_do_not_count_as_matched(self):
        self.refresh([source_row(product='다른상품')])
        self.assertEqual(self.unmatched(),[])
        self.set_orders([order(1),order(2)])   # 다른상품 주문이 사라지면 다시 필요 목록으로
        self.assertEqual([v['product'] for v in self.unmatched()],['다른상품'])
if __name__=='__main__':unittest.main()
