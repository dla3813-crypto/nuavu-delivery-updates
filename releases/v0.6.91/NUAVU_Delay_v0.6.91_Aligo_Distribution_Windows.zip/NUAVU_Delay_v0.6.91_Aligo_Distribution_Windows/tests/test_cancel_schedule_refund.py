"""2026-10-22 (공통) 품절 주문취소: 지그재그 대상 · 지금/오전 9시 예약취소 · 예약 문자 10분 전 자동 취소 · 자사몰 환불 대기/환불완료."""
import unittest,tempfile,threading,time
from datetime import datetime,timezone,timedelta
from pathlib import Path
from types import SimpleNamespace
from domain import SOLDOUT_BANK,SOLDOUT_CARD,SELLERS
from soldout_display import SoldoutDisplayController,DisplayError,CANCEL_LEAD
from soldout_cancel import cancel_targets
try:from test_v056 import Base
except ImportError:from helpers import Base
try:from test_app import sample_rows
except ImportError:from helpers import sample_rows

class ZigzagTargets(unittest.TestCase):
    def test_zigzag_order_and_item(self):
        t=cancel_targets([{'seller':'누아브 지그재그','orderId':'139775599329591174','orderItemId':'185474977508990796'},
                          {'seller':'누아브 지그재그','orderId':'139780604017291662','orderItemId':''},
                          {'seller':'누아브 지그재그','orderId':'TEST-002','orderItemId':''}])
        self.assertEqual([(x['platform'],x['orderId'],x['itemId']) for x in t],[('zigzag','139775599329591174','185474977508990796'),('zigzag','139780604017291662','')])
    def test_row_key_and_send_at_carried(self):
        t=cancel_targets([{'seller':'누아브 에이블리','orderId':'A','orderItemId':'666332484','rowKey':'k','sendAt':'2026-10-23T00:00:00+00:00'}])
        self.assertEqual((t[0]['rowKey'],t[0]['sendAt']),('k','2026-10-23T00:00:00+00:00'))

class Sched(unittest.TestCase):
    def setUp(self):
        from domain import Store
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(Path(self.tmp.name)/'db')
        self.engine=SimpleNamespace(store=self.store,stop=threading.Event(),add_job_alert=lambda *a,**k:None)
        with self.store.edit() as s:
            s['rows']=[{'key':'z1','seller':'누아브 지그재그','orderId':'139775599329591174','orderItemId':'185474977508990796','product':'P','option':''},
                       {'key':'a1','seller':'누아브 에이블리','orderId':'A1','orderItems':[{'id':'666332484'}],'product':'Q','option':''}]
            s['notices']=[]
        self.calls=[]
        c=SoldoutDisplayController(self.engine,runner=lambda ctrl,batch,*a:[{**b,'cafe24':'','ably':'에이블리 처리 완료'} for b in batch],busy=lambda:False);self.addCleanup(c.shutdown)
        c._accounts=lambda:(None,None,'s','')   # no Ably account: zigzag-only batches must still run
        def cancel_runner(ctrl,targets,cafe,ably):
            self.calls.append([dict(t) for t in targets]);return [{**t,'result':{'zigzag':'지그재그','cafe24':'자사몰'}.get(t['platform'],'에이블리')+' 취소 완료','detail':''} for t in targets]
        c.cancel_runner=cancel_runner;self.c=c
    def tearDown(self):self.store.close();self.tmp.cleanup()
    def wait(self):
        for _ in range(200):
            if not self.c.running():return
            time.sleep(.02)
    def test_now_button_runs_zigzag_without_ably_account(self):
        r=self.c.cancel_only({'keys':['z1'],'when':'now'});self.wait()
        self.assertEqual(r['started'],1);self.assertEqual(self.calls[0][0]['platform'],'zigzag')
    def test_morning_button_schedules_0850_and_runs_when_due(self):
        r=self.c.cancel_only({'keys':['z1','a1'],'when':'morning'})
        at=datetime.fromisoformat(r['at']);self.assertEqual((at.astimezone(timezone(timedelta(hours=9))).hour,at.astimezone(timezone(timedelta(hours=9))).minute),(8,50))
        self.assertEqual(self.calls,[]);self.assertEqual(len(r['cancelSchedule']),1)
        self.assertFalse(self.c.run_due())                       # not yet
        with self.store.edit() as s:s['soldoutCancelSchedule'][0]['at']=(datetime.now(timezone.utc)-timedelta(seconds=1)).isoformat()
        self.assertTrue(self.c.run_due());self.wait()
        self.assertEqual(sorted(t['platform'] for t in self.calls[0]),['ably','zigzag']);self.assertEqual(self.store.read()['soldoutCancelSchedule'],[])
    def test_unschedule(self):
        r=self.c.cancel_only({'keys':['z1'],'when':'morning'});sid=r['cancelSchedule'][0]['id']
        self.assertEqual(self.c.unschedule({'id':sid})['cancelSchedule'],[])
        with self.assertRaises(DisplayError):self.c.unschedule({'id':sid})
    def test_reserved_notice_cancels_10_minutes_before(self):
        send=(datetime.now(timezone.utc)+timedelta(hours=3)).isoformat(timespec='seconds')
        self.c.enqueue([{'product':'P','option':'','seller':'누아브 지그재그','orderId':'139775599329591174','orderItemIds':['185474977508990796'],'key':'z1','sendAt':send}],'notice');self.wait()
        self.assertEqual(self.calls,[])                          # 미진열은 바로, 주문취소는 예약
        sc=self.store.read()['soldoutCancelSchedule'];self.assertEqual(len(sc),1)
        self.assertEqual(datetime.fromisoformat(sc[0]['at']),datetime.fromisoformat(send)-CANCEL_LEAD);self.assertEqual(sc[0]['source'],'notice')
    def test_immediate_notice_cancels_now(self):
        self.c.enqueue([{'product':'P','option':'','seller':'누아브 지그재그','orderId':'139775599329591174','orderItemIds':['185474977508990796'],'key':'z1','sendAt':''}],'notice');self.wait()
        self.assertEqual(len(self.calls),1);self.assertEqual(self.store.read()['soldoutCancelSchedule'],[])
    def test_cancelled_reserved_notice_skips_cancel(self):
        send=(datetime.now(timezone.utc)+timedelta(hours=3)).isoformat(timespec='seconds')
        self.c.enqueue([{'product':'P','option':'','seller':'누아브 지그재그','orderId':'139775599329591174','orderItemIds':['185474977508990796'],'key':'z1','sendAt':send}],'notice');self.wait()
        with self.store.edit() as s:
            s['notices']=[{'itemKeys':['z1'],'noticeType':'soldout_card','scheduledAt':send,'status':'CANCELLED'}]
            s['soldoutCancelSchedule'][0]['at']=(datetime.now(timezone.utc)-timedelta(seconds=1)).isoformat()
        self.assertFalse(self.c.run_due());self.assertEqual(self.calls,[])
        self.assertEqual(self.store.read()['soldoutCancelLog'][-1]['result'],'주문취소 안 함')

class RefundHold(Base):
    def bank(self,**kw):
        self.clock(10);return self.send(noticeType='soldout_bank',template=SOLDOUT_BANK,templateKey='soldout_bank',dueDate='',**kw)
    def test_cafe24_bank_rows_survive_snapshot_until_refund_done(self):
        self.bank()
        keys=[r['key'] for r in self.store.read()['rows'][:2]]
        self.engine.import_rows({'rows':sample_rows()[2:],'mode':'snapshot','scope':SELLERS,'replaceConfirmed':True})
        rows={r['key']:r for r in self.engine.public_state()['rows']}
        for k in keys:
            self.assertTrue(rows[k]['active']);self.assertTrue(rows[k]['refundHold']);self.assertTrue(rows[k].get('refundHoldMissing'))
        self.assertNotEqual(self.last()['status'],'CANCELLED')
        r=self.engine.refund_done({'keys':keys});self.assertEqual(r['count'],2)
        rows={r['key']:r for r in self.engine.public_state()['rows']}
        for k in keys:self.assertFalse(rows[k]['active']);self.assertFalse(rows[k]['refundHold'])
        from domain import ValidationError
        with self.assertRaises(ValidationError):self.engine.refund_done({'keys':keys})
    def test_reserved_bank_held_only_when_app_cancelled_the_order(self):
        self.clock(20);n=self.queue(sendMode='MORNING',noticeType='soldout_bank',template=SOLDOUT_BANK,templateKey='soldout_bank',dueDate='')
        with self.store.edit() as s:s['soldoutCancelLog']=[{'platform':'cafe24','orderId':'TEST-001','result':'자사몰 취소 완료'}]
        r=self.engine.import_rows({'rows':sample_rows()[2:],'mode':'snapshot','scope':SELLERS,'replaceConfirmed':True})
        self.assertEqual(r['cancelled'],0);self.assertEqual(self.last()['status'],'SCHEDULED')
        self.assertTrue(all(x['refundHold'] for x in self.engine.public_state()['rows'] if x['orderId']=='TEST-001'))
    def test_card_template_is_not_held(self):
        self.clock(10);self.queue(noticeType='soldout_card',template=SOLDOUT_CARD,dueDate='')
        keys=[r['key'] for r in self.store.read()['rows'][:2]]
        self.engine.import_rows({'rows':sample_rows()[2:],'mode':'snapshot','scope':SELLERS,'replaceConfirmed':True})
        state={r['key']:r for r in self.engine.public_state()['rows']}
        for k in keys:self.assertFalse(state.get(k,{}).get('refundHold',False))

class SendHold(Base):
    """02:35: 08:50 앱 품절 취소 → 08:55 주문엑셀 → 09:00 예약 품절 문자: 문자는 그대로 나가야 한다."""
    def test_reserved_card_notice_survives_import_when_app_cancelled(self):
        self.clock(20);n=self.queue(sendMode='MORNING',noticeType='soldout_card',template=SOLDOUT_CARD,templateKey='soldout_card',dueDate='')
        with self.store.edit() as s:s['soldoutCancelLog']=[{'platform':'cafe24','orderId':'TEST-001','result':'자사몰 취소 완료'}]
        self.clock(8,day=15,minute=55)
        r=self.engine.import_rows({'rows':sample_rows()[2:],'mode':'snapshot','scope':SELLERS,'replaceConfirmed':True})
        self.assertEqual(r['cancelled'],0);self.assertEqual(self.last()['status'],'SCHEDULED')
        rows=[x for x in self.engine.public_state()['rows'] if x['orderId']=='TEST-001']
        self.assertTrue(rows and all(x['active'] and x['sendHold'] and x.get('sendHoldMissing') for x in rows))
        self.clock(9,day=15,minute=1);self.assertTrue(self.engine.send_one());self.assertEqual(len(self.fake.sent),1)
        # 문자가 나간 뒤 다음 엑셀에서는 평소처럼 빠진다 (카드 품절은 환불 대기 아님)
        self.engine.import_rows({'rows':sample_rows()[2:],'mode':'snapshot','scope':SELLERS,'replaceConfirmed':True})
        self.assertFalse(any(x['active'] for x in self.engine.public_state()['rows'] if x['orderId']=='TEST-001'))
    def test_reserved_notice_cancelled_when_not_app_cancelled(self):
        self.clock(20);self.queue(sendMode='MORNING',noticeType='soldout_card',template=SOLDOUT_CARD,templateKey='soldout_card',dueDate='')
        r=self.engine.import_rows({'rows':sample_rows()[2:],'mode':'snapshot','scope':SELLERS,'replaceConfirmed':True})
        self.assertEqual(r['cancelled'],1);self.assertEqual(self.last()['status'],'CANCELLED')
    def test_app_cancelled_matching(self):
        from domain import app_cancelled,app_cancelled_index
        idx=app_cancelled_index({'soldoutCancelLog':[{'platform':'ably','sno':'666332484','result':'에이블리 취소 완료'},{'platform':'zigzag','orderId':'139775599329591174','result':'지그재그 취소 완료'},
                                                     {'platform':'ably','sno':'1','result':'에이블리 취소 실패'},{'platform':'cafe24','orderId':'X','result':'자사몰 취소 완료','test':True}]})
        self.assertTrue(app_cancelled({'seller':'누아브 에이블리','orderItems':[{'id':'666332484'}]},idx))
        self.assertFalse(app_cancelled({'seller':'누아브 에이블리','orderItemId':'1'},idx))
        self.assertTrue(app_cancelled({'seller':'누아브 지그재그','orderId':'139775599329591174'},idx))
        self.assertFalse(app_cancelled({'seller':'누아브 자사몰','orderId':'X'},idx))
