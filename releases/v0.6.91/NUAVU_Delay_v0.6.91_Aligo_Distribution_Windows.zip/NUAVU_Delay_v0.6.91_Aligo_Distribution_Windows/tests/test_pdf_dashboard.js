'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),D=require('../web/dispatch_view.js'),H=D.dashboard;
const row=(key,extra={})=>({key,orderId:key,seller:'가상 에이블리',active:true,bucket:'unnotified',qty:1,...extra});
const sum=rows=>H.summary(rows,D,r=>r.bucket==='unnotified',{notice_resend:[],notice_undated:[]});
const dated={progressOfficeDates:['2026-10-16'],dispatchStart:'2026-10-21',dispatchEnd:'2026-10-22'};
test('bundle display groups same seller and order, not distinct sellers or inactive siblings',()=>{
 const rows=[row('a',{orderId:'001'}),row('b',{orderId:'001'}),row('c',{orderId:'001',seller:'다른 판매처'}),row('d',{orderId:'002'}),row('e',{orderId:'002',active:false})];
 assert.deepEqual([...H.bundleRows(rows)],['a','b']);
});
test('blank order numbers and duplicate row keys do not create bundles',()=>assert.equal(H.bundleRows([row('a',{orderId:''}),row('b',{orderId:''}),row('c'),row('c')]).size,0));
test('summary date known and unknown partition pending notices',()=>{const v=sum([row('a',dated),row('b'),row('c',{active:false}),row('d',{bucket:'within'})]);assert.equal(v.whiteDated,1);assert.equal(v.whiteUndated,1);});
test('date ranges preserve intervals and missing quantity dates enter waiting',()=>{const v=sum([row('a',dated),row('b',{...dated,dispatchStart:'2026-10-19',dispatchEnd:'2026-10-19'}),row('c',{progressOfficeDates:['2026-10-16']}),row('d')]);assert.equal(v.dates.length,2);assert.equal(v.dates[0].start,'2026-10-19');assert.equal(v.dates[1].end,'2026-10-22');assert.equal(v.waiting,1);});
test('two sources on same product count once',()=>{const v=sum([row('a',{...dated,manifestOfficeDates:['2026-10-16']})]);assert.equal(v.dates[0].count,1);});
test('bundle ready counts orders while partial requires ready and unready products',()=>{
 const rows=[row('a',{orderId:'1',isBundle:true,inventoryReady:true,bundleReady:true}),row('b',{orderId:'1',isBundle:true,inventoryReady:true,bundleReady:true}),row('c',{orderId:'2',isBundle:true,inventoryReady:true}),row('d',{orderId:'2',isBundle:true}),row('e',{orderId:'3',isBundle:true,bundleScheduled:true}),row('f',{orderId:'3',isBundle:true}),row('g',{inventoryReady:true})];
 const v=sum(rows);assert.equal(v.readyBundle,1);assert.equal(v.partialBundle,1);assert.equal(v.readySingle,1);
});
test('confirmed plus planned bundle union counts each order once',()=>assert.equal(sum([row('a',{orderId:'1',isBundle:true,bundleType:'confirmed'}),row('b',{orderId:'1',isBundle:true,bundleType:'planned'})]).confirmedPlannedBundle,1));
test('summaries never mutate source or allocation',()=>{const rows=[row('a',dated),row('b',{inventoryReady:true})],saved=JSON.stringify(rows);sum(rows);H.bundleRows(rows);assert.equal(JSON.stringify(rows),saved);});
