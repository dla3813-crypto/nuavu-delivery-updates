"""Completed-row identity and browser lifetime; no real accounts/network."""
from datetime import datetime
from types import SimpleNamespace
from unittest.mock import MagicMock,patch
import tempfile,threading,unittest
from pathlib import Path
from urllib.parse import quote
from order_auto import OrderAutoError,OrderAutoController,KST
from order_browser import Flow
from domain import Store

class DownloadServerTests(unittest.TestCase):
    def setUp(self):
        self.start=datetime.now(KST)
        self.name='확장주문검색_'+self.start.strftime('%Y%m%d%H%M%S')+'_123.xls'
        self.href='https://ga90.ezadmin.co.kr/data/test/'+quote(self.name)
        self.job=dict(id='7',at=self.start.strftime('%Y-%m-%d %H:%M:%S'),template='확장주문검색2',name=self.name,href=self.href,status='완료')
        self.manager=MagicMock();self.c=MagicMock();self.flow=Flow(self.c,MagicMock());self.flow.admin_host='ga79.ezadmin.co.kr'
        self.flow.known_page=MagicMock()
        self.row=self.manager.locator.return_value.filter.return_value
        self.row.count.return_value=1;self.row.evaluate_all.return_value=[dict(self.job)]
        self.link=self.row.get_by_role.return_value;self.link.count.return_value=1;self.link.evaluate.return_value=self.href
        self.download=self.manager.expect_download.return_value.__enter__.return_value.value
        self.download.url=self.href;self.download.suggested_filename=self.name
        self.persist=patch('order_browser.persist_download',return_value=b'synthetic').start();self.addCleanup(patch.stopall)
    def run_download(self):return self.flow.download_job(self.manager,self.job,self.start,'synthetic-folder')
    def test_cross_server_uses_verified_link(self):
        self.assertEqual(self.run_download(),(self.name,b'synthetic'));self.persist.assert_called_once()
    def test_same_server_still_works(self):
        self.flow.admin_host='ga90.ezadmin.co.kr';self.run_download();self.persist.assert_called_once()
    def test_other_official_file_server_works(self):
        href=self.href.replace('ga90','ga21');self.job['href']=href;self.row.evaluate_all.return_value=[dict(self.job)];self.link.evaluate.return_value=href;self.download.url=href
        self.run_download();self.persist.assert_called_once()
    def test_untrusted_or_invalid_links_never_clicked(self):
        for bad in [self.href.replace('https:','http:'),self.href.replace('ga90.ezadmin.co.kr','ga90.ezadmin.co.kr.evil.test'),self.href.replace('ga90.ezadmin.co.kr','other.ezadmin.co.kr'),self.href.replace('https://','https://user@'),self.href.replace('.kr/', '.kr:444/'),self.href+'?x=1',self.href+'#x',self.href.replace('/data/','/other/')]:
            with self.subTest(url=bad),self.assertRaises(OrderAutoError):
                self.job['href']=bad;self.run_download()
        self.link.click.assert_not_called();self.persist.assert_not_called()
    def test_changed_row_does_not_download(self):
        for key,value in [('id','8'),('at','2020-01-01 00:00:00'),('template','현재고조회'),('status','진행중'),('name','other.xls'),('href',self.href.replace('/test/','/other/'))]:
            with self.subTest(key=key),self.assertRaises(OrderAutoError):
                self.row.evaluate_all.return_value=[dict(self.job,**{key:value})];self.run_download()
        self.link.click.assert_not_called();self.persist.assert_not_called()
    def test_duplicate_rows_stop(self):
        self.row.count.return_value=2
        with self.assertRaises(OrderAutoError):self.run_download()
        self.persist.assert_not_called()
    def test_changed_link_stops_before_click(self):
        self.link.evaluate.return_value=self.href.replace('ga90','ga21')
        with self.assertRaises(OrderAutoError):self.run_download()
        self.link.click.assert_not_called()
    def test_wrong_download_name_not_saved(self):
        self.download.suggested_filename='different.xls'
        with self.assertRaises(OrderAutoError):self.run_download()
        self.persist.assert_not_called()
    def test_download_event_must_match_verified_link(self):
        for url in [self.href.replace('ga90','ga21'),self.href.replace('/test/','/other/'),self.href.replace('ga90.ezadmin.co.kr','evil.test')]:
            with self.subTest(url=url),self.assertRaises(OrderAutoError):
                self.download.url=url;self.run_download()
        self.persist.assert_not_called()
    def test_cancel_before_click(self):
        self.c.check.side_effect=OrderAutoError('cancelled')
        with self.assertRaises(OrderAutoError):self.run_download()
        self.link.click.assert_not_called();self.persist.assert_not_called()

class RecoveryTests(unittest.TestCase):
    def test_after_request_no_login_navigation_or_resume(self):
        with tempfile.TemporaryDirectory() as tmp:
            c=OrderAutoController(Store(Path(tmp)));c.thread=SimpleNamespace(is_alive=lambda:True)
            c.job={'id':'job','phase':'error_open'};c.browser_recovery=True;c.browser_can_continue=False
            for action in ['open','continue']:
                with self.subTest(action=action),self.assertRaisesRegex(OrderAutoError,'이미 엑셀 신청'):
                    c.request_browser_action('job',action)
            self.assertIsNone(c.browser_command);self.assertEqual(c.job['phase'],'error_open')
            c.browser_can_continue=True;c.request_browser_action('job','open')
            self.assertEqual(c.take_browser_action()[0],'open')
    def setup_flow(self):
        c=MagicMock();c.stop=threading.Event();c.take_browser_action.return_value=None
        context=MagicMock();page=MagicMock();page.is_closed.return_value=False
        context.pages=[page];context.browser.is_connected.return_value=True
        return c,context,page,Flow(c,context)
    def test_transient_wait_error_keeps_browser_until_cancel(self):
        c,context,page,flow=self.setup_flow();calls=[]
        def wait(_):
            calls.append(1)
            if len(calls)==1:raise RuntimeError('transient navigation')
            c.stop.set()
        page.wait_for_timeout.side_effect=wait
        with patch('order_browser.time.sleep'):flow.keep_failure_open('original download error')
        self.assertEqual(len(calls),2);context.close.assert_not_called()
        c.browser_failed.assert_called_once_with('original download error',True,False)
    def test_closed_first_tab_retains_other_tab(self):
        c,context,page,flow=self.setup_flow();popup=MagicMock();popup.is_closed.return_value=False
        def close(_):
            page.is_closed.return_value=True;context.pages=[popup];raise RuntimeError('closed')
        page.wait_for_timeout.side_effect=close;popup.wait_for_timeout.side_effect=lambda _:c.stop.set()
        with patch('order_browser.time.sleep'):flow.keep_failure_open('original')
        popup.wait_for_timeout.assert_called_once();context.close.assert_not_called()
    def test_disconnected_browser_ends_wait(self):
        c,context,page,flow=self.setup_flow();context.browser.is_connected.return_value=False
        page.wait_for_timeout.side_effect=RuntimeError('disconnected')
        flow.keep_failure_open('original');page.wait_for_timeout.assert_called_once()
