"""2026-10-20 (공통) 판매처별 자동 회수접수 선택: 에이블리/자사몰/지그재그 중 고른 판매처만 자동 후보에 든다."""
import unittest,tempfile,threading
from datetime import date
from pathlib import Path
from types import SimpleNamespace
from aftersales_data import auto_candidates,pickup_sellers,PICKUP_SELLERS
from pickup_controller import PickupController
from order_auto import OrderAutoError

class SellerSelection(unittest.TestCase):
    def test_defaults_all_on_and_legacy_bool(self):
        self.assertEqual(pickup_sellers({}),{s:True for s in PICKUP_SELLERS})
        self.assertEqual(pickup_sellers({'pickupSettings':{'enabled':True}}),{s:True for s in PICKUP_SELLERS})
        self.assertEqual(pickup_sellers({'pickupSettings':{'enabled':True,'sellers':{'에이블리':False}}}),{'에이블리':False,'자사몰':True,'지그재그':True})
    def test_candidates_filtered_by_seller(self):
        import aftersales_data as ad
        rows=[{'key':'a','invoice':'1111111111','seller':'에이블리','category':'uncollected','recipient':'','recipientPhone':''},
              {'key':'b','invoice':'2222222222','seller':'지그재그','category':'uncollected','recipient':'','recipientPhone':''},
              {'key':'c','invoice':'3333333333','category':'uncollected','recipient':'','recipientPhone':''}]
        orig=ad.public_aftersales
        ad.public_aftersales=lambda state,today:{'rows':rows,'exchangeRows':[]}
        try:
            state={'settings':{'shopName':'누아브'},'pickupSettings':{'enabled':True,'sellers':{'에이블리':False}}}
            got=[c['invoice'] for c in auto_candidates(state,date(2026,10,20))]
            self.assertEqual(got,['2222222222'])   # seller-less rows count as 에이블리
            state['pickupSettings']['sellers']={'지그재그':False}
            self.assertEqual([c['invoice'] for c in auto_candidates(state,date(2026,10,20))],['1111111111','3333333333'])
        finally:ad.public_aftersales=orig

class SaveTests(unittest.TestCase):
    def setUp(self):
        from domain import Store
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(Path(self.tmp.name)/'db')
        with self.store.edit() as s:s['settings']['shopName']='누아브'
        self.engine=SimpleNamespace(store=self.store,stop=threading.Event(),add_job_alert=lambda *a,**k:None)
        self.c=PickupController(self.engine,runner=lambda *a:None,busy=lambda:False);self.addCleanup(self.c.shutdown)
    def tearDown(self):self.store.close();self.tmp.cleanup()
    def test_save_dict_and_bool(self):
        self.c.save({'enabled':True,'sellers':{'에이블리':False,'지그재그':True}})
        self.assertEqual(self.c.config(),{'enabled':True,'sellers':{'에이블리':False,'자사몰':True,'지그재그':True}})
        self.c.save({'enabled':False})   # hub master toggle keeps the seller choice
        self.assertEqual(self.c.config(),{'enabled':False,'sellers':{'에이블리':False,'자사몰':True,'지그재그':True}})
        self.c.save(True);self.assertTrue(self.c.config()['enabled']);self.assertFalse(self.c.config()['sellers']['에이블리'])
        with self.assertRaises(OrderAutoError):self.c.save({'enabled':True,'sellers':{'쿠팡':True}})
        with self.assertRaises(OrderAutoError):self.c.save({'enabled':'yes'})
if __name__=='__main__':unittest.main()
