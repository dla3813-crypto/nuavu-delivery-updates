"""2026-10-20 (공통) 지그재그 반품/교환: 파트너센터 목록 → 에이블리 반품 행 모양, 회수접수 뒤 플랫폼 단계 분기, 교환 건은 에이블리 접수 단계 없음."""
import unittest,tempfile,threading
from pathlib import Path
from datetime import date,datetime
from zoneinfo import ZoneInfo
from types import SimpleNamespace
from unittest.mock import patch
from domain import Store
from zigzag_returns import (parse_option,reason_text,parse_orig,parse_day,return_entry,exchange_entries,is_email_login,list_total,zigzag_enabled,ZIGZAG)
from aftersales_data import public_aftersales,auto_candidates,platform_of
from test_aftersales_new import row,snapshot
from pickup_controller import PickupController
import aftersales_collect
try:from helpers import MemoryVault
except ImportError:from test_v052 import MemoryVault
NOW=datetime(2026,10,20,10,tzinfo=ZoneInfo('Asia/Seoul'))

def zz_raw(item='185400000000000001',status='반품요청',pay='차감',orig='우체국 6082036144359',**kw):
    r={'itemId':item,'orderId':'139700000000000001','requestedAt':'2026.10.15 21:31:43','status':status,'reason':'사이즈가 맞지 않음','orig':orig,'returnNo':'-',
       'customer':'구매자','recipient':'수령인','recipientPhone':'010-0000-1234','product':'[3color]스타 자수 긴팔 티셔츠','option':'색상: 차콜(모델착용) 사이즈: FREE','qty':'1','payMethod':pay,'requestId':'C100','checkbox':True}
    r.update(kw);return r

class Parsing(unittest.TestCase):
    def test_option_and_reason(self):
        self.assertEqual(parse_option('색상: 차콜(모델착용) 사이즈: FREE'),'차콜(모델착용) / FREE')
        self.assertEqual(parse_option('- 색상: 원컬러 - 사이즈: L'),'원컬러 / L')
        self.assertEqual(reason_text('사이즈가 맞지 않음','차감'),'고객(사이즈가 맞지 않음)')
        self.assertEqual(reason_text('상품 설명이 실제와 다름','-'),'판매자(상품 설명이 실제와 다름)')
    def test_orig_and_dates(self):
        self.assertEqual(parse_orig('우체국 6082036144359'),('우체국','6082036144359'))
        self.assertEqual(parse_orig('-'),('-',''));self.assertEqual(parse_day('2026.10.15 21:31:43'),'2026-10-15')
        self.assertEqual(list_total('반품수거중 목록 (1,206건)'),1206);self.assertIsNone(list_total('목록'))
        self.assertTrue(is_email_login('shop@example.com'));self.assertFalse(is_email_login('nuavu'));self.assertFalse(is_email_login(''))
    def test_return_entry_shape_matches_ably_rows(self):
        r=return_entry(zz_raw(),'반품요청')
        self.assertEqual((r['seller'],r['kind'],r['zigzagStatus'],r['invoice'],r['option'],r['qty'],r['requestedAt'],r['reason'],r['requestId']),
                         (ZIGZAG,'return','반품요청','6082036144359','차콜(모델착용) / FREE',1,'2026-10-15','고객(사이즈가 맞지 않음)','C100'))
        self.assertTrue(r['key'].startswith('zigzag:'));self.assertEqual(r['returnNo'],'');self.assertEqual(r['fee'],0)
        self.assertNotEqual(return_entry(zz_raw(item='185400000000000002'),'반품요청')['key'],r['key'])
    def test_exchange_pairs(self):
        raws=[dict(zz_raw(part='교환전',status='교환수거중',option='- 색상: 원컬러 - 사이즈: L',qty='1개')),dict(zz_raw(part='교환후',status='',option='- 색상: 원컬러 - 사이즈: M',itemId='185400000000000009')),
              dict(zz_raw(part='교환전',item='185400000000000003',option='색상: 블랙 사이즈: FREE'))]
        out=exchange_entries(raws,'교환수거중')
        self.assertEqual(len(out),2);self.assertEqual(out[0]['option'],'원컬러 / L');self.assertEqual(out[0]['exchangeOption'],'원컬러 / M');self.assertEqual(out[0]['kind'],'exchange')
        self.assertEqual(out[0]['exchangeAfterItemId'],'185400000000000009');self.assertEqual(out[1]['exchangeOption'],'');self.assertTrue(out[1]['key'].startswith('zigzag-exchange:'))
    def test_enabled_requires_email_login(self):
        class V:
            available=True
            def __init__(self,saved):self.saved=saved
            def load(self):return self.saved
        with patch('zigzag_credentials.ZigzagAccounts') as ZA:
            ZA.return_value.info.return_value={'username':'nuavu','hasPassword':True}
            self.assertIsNone(zigzag_enabled('/tmp')[0]);self.assertIn('이메일',zigzag_enabled('/tmp')[1])
            ZA.return_value.info.return_value={'username':'me@nuavu.kr','hasPassword':True}
            self.assertTrue(zigzag_enabled('/tmp')[0])
            ZA.return_value.info.return_value={'username':'','hasPassword':False}
            self.assertIn('계정 없음',zigzag_enabled('/tmp')[1])

class ViewTests(unittest.TestCase):
    def state(self):
        zz=dict(return_entry(zz_raw(),'반품요청'),returnStatus='NONE',issue='',origDelivered='2026-10-13',returnDelivered='',carrier='EPOST')
        ex=dict(exchange_entries([zz_raw(part='교환전',item='185400000000000005',status='교환요청',orig='')],'교환요청')[0],invoice='6082036144360',returnStatus='NONE',issue='',origDelivered='2026-10-14',returnDelivered='',carrier='EPOST')
        return {'settings':{'shopName':'테스트상점','shopRevision':1},'returnCheck':snapshot([row(),zz])|{'zigzag':{'enabled':True,'totals':{'반품요청':1,'반품수거중':0}}},'exchangeCheck':snapshot([row('610000000005')|{'kind':'exchange'},ex])}
    def test_public_view_sellers_and_zigzag_summary(self):
        v=public_aftersales(self.state(),date(2026,10,20))
        self.assertEqual([r['seller'] for r in v['rows']],['에이블리',ZIGZAG]);self.assertEqual(v['zigzag']['totals']['반품요청'],1)
        zz=next(r for r in v['rows'] if r['seller']==ZIGZAG);self.assertEqual(zz['category'],'uncollected');self.assertEqual(zz['zigzagStatus'],'반품요청')
    def test_auto_candidates_and_platform_of(self):
        s=self.state();today=date(2026,10,20)
        cands=auto_candidates(s,today);self.assertIn('6082036144359',[c['invoice'] for c in cands]);self.assertIn('6082036144360',[c['invoice'] for c in cands])
        self.assertEqual(platform_of(s,today,'6082036144359'),{'seller':ZIGZAG,'kind':'return','itemId':'185400000000000001','zigzagStatus':'반품요청'})
        self.assertEqual(platform_of(s,today,'6082036144360')['kind'],'exchange');self.assertEqual(platform_of(s,today,'610000000005')['kind'],'exchange')
        self.assertEqual(platform_of(s,today,'999')['seller'],'에이블리')

class CollectMerge(unittest.TestCase):
    def test_merge_appends_zigzag_rows_and_keeps_ably_on_failure(self):
        c=SimpleNamespace(engine=SimpleNamespace(store=SimpleNamespace(directory='/tmp')),update=lambda *a:None,clock=lambda:NOW,stop=threading.Event())
        base={'complete':True,'total':1,'rows':[row()],'exchangeRows':[]}
        with patch('zigzag_returns.zigzag_enabled',return_value=({'username':'a@b.c'},'')),patch('zigzag_credentials.ZigzagAccounts') as ZA,\
             patch('zigzag_returns.collect_zigzag',return_value={'rows':[return_entry(zz_raw(),'반품요청')],'exchangeRows':[exchange_entries([zz_raw(part='교환전')],'교환요청')[0]],'totals':{'반품요청':1},'actions':[]}):
            ZA.return_value.for_login.return_value={'username':'a@b.c','password':'x','shop':'nuavu'}
            out=aftersales_collect.merge_zigzag(dict(base,rows=[row()]),{'kind':'return'},c)
            self.assertEqual(out['total'],2);self.assertEqual(out['rows'][1]['seller'],ZIGZAG);self.assertEqual(len(out['zigzagExchangeRows']),1);self.assertTrue(out['zigzag']['enabled'])
            out=aftersales_collect.merge_zigzag(dict(base,rows=[row()],exchangeRows=[]),{'kind':'all'},c)
            self.assertEqual(len(out['exchangeRows']),1);self.assertNotIn('zigzagExchangeRows',out)
        with patch('zigzag_returns.zigzag_enabled',return_value=({'username':'a@b.c'},'')),patch('zigzag_credentials.ZigzagAccounts') as ZA,\
             patch('zigzag_returns.collect_zigzag',side_effect=RuntimeError('boom')):
            ZA.return_value.for_login.return_value={'username':'a@b.c','password':'x','shop':'nuavu'}
            out=aftersales_collect.merge_zigzag(dict(base,rows=[row()]),{'kind':'return'},c)
            self.assertEqual(out['total'],1);self.assertEqual(out['zigzag']['error'],'boom')
        with patch('zigzag_returns.zigzag_enabled',return_value=(None,'지그재그 계정 없음')):
            out=aftersales_collect.merge_zigzag(dict(base,rows=[row()]),{'kind':'return'},c)
            self.assertFalse(out['zigzag']['enabled']);self.assertEqual(len(out['rows']),1)

class PickupRouting(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(Path(self.tmp.name)/'db')
        zz=dict(return_entry(zz_raw(),'반품요청'),returnStatus='NONE',issue='',origDelivered='2026-10-13',returnDelivered='',carrier='EPOST')
        with self.store.edit() as s:
            s['settings'].update(shopName='테스트상점',shopRevision=1)
            s['returnCheck']=snapshot([row(),zz]);s['exchangeCheck']=snapshot([row('610000000005')|{'kind':'exchange'}])
        self.engine=SimpleNamespace(store=self.store,stop=threading.Event());self.cs=[]
        self.report=patch('pickup_report.save_report',return_value=str(Path(self.tmp.name)/'result.xlsx'));self.report.start();self.addCleanup(self.report.stop)
    def tearDown(self):
        for c in self.cs:c.shutdown();c.thread.join(2) if c.thread else None
        self.store.close();self.tmp.cleanup()
    def test_exchange_skips_ably_and_zigzag_goes_to_partner_center(self):
        def run(c,rows,shop,inspect):
            for inv in ('610000000001','610000000005','6082036144359'):c.before_submit(inv);c.record({'invoice':inv,'result':'접수 완료'})
        calls={'ably':[],'zz':[]}
        def ably(c,targets,today):calls['ably'].append([t['invoice'] for t in targets]);return {t['invoice']:{'ablyResult':'에이블리 접수 완료','ablyNote':''} for t in targets}
        def zz(c,targets,today):calls['zz'].append([(t['invoice'],t['itemId'],t['kind'],t['zigzagStatus']) for t in targets]);return {t['invoice']:{'ablyResult':'지그재그 반품접수 완료','ablyNote':'반품수거중 카드에서 확인'} for t in targets}
        c=PickupController(self.engine,runner=run,vault=MemoryVault(),clock=lambda:NOW);c.ably_runner=ably;c.zigzag_runner=zz;self.cs.append(c)
        c.start_pickups([row(),row('610000000005'),{'invoice':'6082036144359','customer':'수령인','phone':'01000001234'}]);c.thread.join(3)
        self.assertEqual(calls['ably'],[['610000000001']]);self.assertEqual(calls['zz'],[[('6082036144359','185400000000000001','return','반품요청')]])
        by={h['invoice']:h for h in self.store.read()['pickupHistory']}
        self.assertEqual(by['610000000005']['ablyResult'],'에이블리 교환 건 · 접수 단계 없음');self.assertEqual(by['6082036144359']['ablyResult'],'지그재그 반품접수 완료');self.assertEqual(by['610000000001']['ablyResult'],'에이블리 접수 완료')

if __name__=='__main__':unittest.main()
