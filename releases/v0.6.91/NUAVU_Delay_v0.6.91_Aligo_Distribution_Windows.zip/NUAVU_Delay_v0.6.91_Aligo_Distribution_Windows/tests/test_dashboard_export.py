"""New lookup labels retain existing XLSX and stale-snapshot protections."""
import copy,io,unittest,zipfile
from datetime import datetime,timezone
from types import SimpleNamespace
from xml.etree import ElementTree as ET
import order_export as E
from domain import ValidationError

class DashboardExportTests(unittest.TestCase):
 def setUp(self):
  self.state={'revision':7,'today':'2026-10-18','settings':{'shopName':'가상몰'},'rows':[{'key':'one','seller':'누아브 에이블리','orderId':'000123','product':'가상 상품','option':'화이트','qty':2,'buyer':'가상고객','recipient':'가상 수령자','orderDate':'2026-10-01','exportContacts':{'recipientMobile':'01000000000'}}]}
  self.engine=SimpleNamespace(public_state=lambda:copy.deepcopy(self.state))
  self.payload={'keys':['one'],'revision':7,'section':'notice_resend','active':'active'}
 def export(self,changes=None):
  p={**self.payload,**(changes or {})}
  if hasattr(E,'prepare_export'):return E.prepare_export(self.engine,p,clock=datetime(2026,10,18,tzinfo=timezone.utc))[:2]
  r=E.export_orders(self.engine,p);return r['name'],r['data']
 def test_resend_section_filename(self):self.assertEqual(self.export()[0],'출고 예정일 재발송 필요_1018.xlsx')
 def test_unknown_section_filename(self):self.assertEqual(self.export({'section':'notice_undated'})[0],'출고 예정일자 (미확정)_1018.xlsx')
 def test_filter_and_original_order_contact_text_survive(self):
  raw=self.export()[1]
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   xml=z.read('xl/worksheets/sheet1.xml');root=ET.fromstring(xml);ns={'m':E.NS}
   self.assertIsNotNone(root.find('m:autoFilter',ns));self.assertIn(b'000123',xml);self.assertIn(b'01000000000',xml.replace(b'-',b''))
 def test_stale_and_unknown_key_are_rejected(self):
  for change in [{'revision':6},{'keys':['missing']}]:
   with self.subTest(change=change),self.assertRaises(ValidationError):self.export(change)
 def test_no_state_mutation(self):
  before=copy.deepcopy(self.state);self.export();self.assertEqual(self.state,before)

class OrderPrefixTests(DashboardExportTests):
 """주문번호 cell: '(합포)' for 2+ active order-products in one order, '(교환)' for C… exchange orders, both when both."""
 def cell_i(self,raw):
  with zipfile.ZipFile(io.BytesIO(raw)) as z:root=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
  ns={'m':E.NS};return [''.join(c.itertext()) for r in root.find('m:sheetData',ns) if r.get('r')!='1' for c in r if c.get('r').startswith('I')]
 def rows(self,*specs):
  base=self.state['rows'][0];out=[]
  for key,order_id,active in specs:out.append({**copy.deepcopy(base),'key':key,'orderId':order_id,'active':active})
  self.state['rows']=out
 def test_single_order_has_no_prefix(self):
  self.assertEqual(self.cell_i(self.export()[1]),['000123'])
 def test_bundle_exchange_and_both(self):
  self.rows(('a','000200',True),('b','000200',True),('c','C00300',True),('d','C00400',True),('e','C00400',True),('f','000500',True),('g','000500',False))
  cells=self.cell_i(self.export({'keys':['a','b','c','d','f','g']})[1])
  self.assertEqual(cells,['(합포)000200','(합포)000200','(교환)C00300','(합포)(교환)C00400','000500','000500'])
 def test_prefix_is_export_only(self):
  self.rows(('a','000200',True),('b','000200',True));before=copy.deepcopy(self.state);self.export({'keys':['a','b']})
  self.assertEqual(self.state,before);self.assertNotIn('exportOrderPrefix',self.state['rows'][0])

class DetailIdColumnTests(OrderPrefixTests):
 """v0.6.91: J=상세주문번호, one id per line (누아브 메인과 동일); later columns shift right."""
 def cell(self,raw,col):
  with zipfile.ZipFile(io.BytesIO(raw)) as z:root=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
  ns={'m':E.NS};return [''.join(c.itertext()) for r in root.find('m:sheetData',ns) if r.get('r')!='1' for c in r if c.get('r').startswith(col)]
 def test_detail_ids_in_column_j(self):
  self.state['rows'][0]['orderItems']=[{'id':'664883869'},{'id':'664883870'}]
  raw=self.export()[1];self.assertEqual(self.cell(raw,'J'),['664883869\n664883870']);self.assertEqual(self.cell(raw,'I'),['000123'])
  with zipfile.ZipFile(io.BytesIO(raw)) as z:xml=z.read('xl/worksheets/sheet1.xml')
  self.assertIn(b'\xec\x83\x81\xec\x84\xb8\xec\xa3\xbc\xeb\xac\xb8\xeb\xb2\x88\xed\x98\xb8',xml)  # 상세주문번호 header
 def test_no_ids_leaves_cell_empty(self):
  self.assertEqual(self.cell(self.export()[1],'J'),[''])
