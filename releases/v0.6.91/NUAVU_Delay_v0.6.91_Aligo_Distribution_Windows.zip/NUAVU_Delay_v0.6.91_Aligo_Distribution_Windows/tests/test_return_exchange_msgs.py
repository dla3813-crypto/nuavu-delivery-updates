"""2026-10-23 18:46 요청: 반품/교환 창 — 전체 반품/교환 탭, 교환 불량 아님 문자, 반품·교환 수동 메시지 작성."""
import subprocess,unittest
from datetime import date
from pathlib import Path
try:from test_v056 import Base
except ImportError:from helpers import Base
from test_aftersales_new import row,snapshot
from domain import ValidationError
from aftersales_data import public_aftersales
from return_messages import render_return_message
ROOT=Path(__file__).resolve().parents[1]
INV='610000000001';EX='610000000005'

class Templates(unittest.TestCase):
    def test_exchange_not_defect_wording(self):
        t=render_return_message('return_not_defect','에이블리','누아브',exchange=True)
        self.assertIn('교환 제품이 수거되어',t);self.assertIn('교환 처리가 불가',t);self.assertIn('귀책 사유 수정 후 교환 처리',t);self.assertIn('공지사항',t)
        self.assertNotIn('반품 처리',t)
        self.assertNotIn('공지사항',render_return_message('return_not_defect','지그재그','누아브',exchange=True))
    def test_manual_draft(self):
        self.assertEqual(render_return_message('return_manual','','누아브'),'안녕하세요 고객님\n누아브입니다.\n\n')

class Flow(Base):
    def setUp(self):
        super().setUp()
        with self.store.edit() as s:
            s['settings'].update(shopName='테스트상점',shopRevision=1)
            s['returnCheck']=snapshot([row(INV)]);s['exchangeCheck']=snapshot([row(EX)])
    def view(self):return public_aftersales(self.store.read(),date(2026,10,14))
    def test_exchange_not_defect_preview_and_send(self):
        pv=self.engine.return_message_preview({'invoice':EX,'kind':'return_not_defect'})
        self.assertTrue(pv['exchange']);self.assertEqual(pv['label'],'교환 불량 아님');self.assertIn('교환 제품이 수거되어',pv['content'])
        self.clock(10);r=self.engine.return_message_send({'invoice':EX,'kind':'return_not_defect','sendMode':'IMMEDIATE','requestId':'x-1'})
        self.assertIn('교환 불량 아님',r['message']);n=self.last()
        self.assertTrue(n['returnExchange']);self.assertIn('교환 안내',n['title']);self.assertIn('교환 제품이 수거되어',n['content'])
        self.assertEqual(self.view()['exchangeRows'][0]['notDefectNotice'],'QUEUED')
    def test_exchange_has_no_overdue(self):
        with self.assertRaises(ValidationError):self.engine.return_message_preview({'invoice':EX,'kind':'return_overdue'})
    def test_manual_message_both_kinds(self):
        self.clock(10)
        for inv,word in ((INV,'반품'),(EX,'교환')):
            pv=self.engine.return_message_preview({'invoice':inv,'kind':'return_manual'})
            self.assertEqual(pv['content'].strip(),'안녕하세요 고객님\n테스트상점입니다.');self.assertEqual(pv['label'],word+' 수동 메시지')
            with self.assertRaisesRegex(ValidationError,'작성'):self.engine.return_message_send({'invoice':inv,'kind':'return_manual','sendMode':'IMMEDIATE','requestId':'m0'+inv})
            body='안녕하세요 고객님\n{쇼핑몰}입니다.\n\n회수 기사님 방문이 하루 늦어집니다.'
            r=self.engine.return_message_send({'invoice':inv,'kind':'return_manual','content':body,'sendMode':'IMMEDIATE','requestId':'m1'+inv})
            n=self.last();self.assertTrue(n['content'].startswith('안녕하세요 고객님\n테스트상점입니다.\n\n회수 기사님 방문이 하루 늦어집니다.\n\n안내번호:'))
            self.assertEqual(n['noticeType'],'return_manual');self.assertEqual(n['itemKeys'],[]);self.assertIn(word+' 수동 메시지',r['message'])
            # 같은 내용은 대기 중 중복 차단, 다른 내용은 보낼 수 있음
            with self.assertRaises(ValidationError):self.engine.return_message_send({'invoice':inv,'kind':'return_manual','content':body,'sendMode':'IMMEDIATE','requestId':'m2'+inv})
            self.engine.return_message_send({'invoice':inv,'kind':'return_manual','content':body+' 죄송합니다.','sendMode':'IMMEDIATE','requestId':'m3'+inv})
        v=self.view();self.assertEqual(v['rows'][0]['manualNotice'],'QUEUED');self.assertEqual(v['exchangeRows'][0]['manualNotice'],'QUEUED')
        self.assertNotEqual(v['rows'][0]['category'],'not_defect_done')   # 수동 메시지는 카드 이동 없음
    def test_manual_length_limit(self):
        with self.assertRaisesRegex(ValidationError,'900자'):self.engine.return_message_preview({'invoice':INV,'kind':'return_manual','content':'가'*901})

class UiTests(unittest.TestCase):
    def test_all_tab_shows_returns_and_exchanges_and_buttons(self):
        js=(ROOT/'web/returns_ui.js').read_text(encoding='utf-8')
        self.assertIn("['','전체 반품/교환']",js);self.assertIn('category?data.rows:[...data.rows,...(data.exchangeRows||[])]',js)
        self.assertIn('sRows.length+sEx.length',js);self.assertIn('data-msg-kind="return_manual"',js)
        # 불량 아님 버튼은 교환 조건 밖(반품·교환 공통), 기한 초과만 반품 전용
        i=js.index('data-msg-kind="return_overdue"');j=js.index('data-msg-kind="return_not_defect"');self.assertLess(js.index("`}",i),j)

if __name__=='__main__':unittest.main()
