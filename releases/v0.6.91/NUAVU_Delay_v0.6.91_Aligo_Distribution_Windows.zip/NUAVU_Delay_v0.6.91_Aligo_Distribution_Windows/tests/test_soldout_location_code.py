"""2026-10-22 01:29: (C-13) 위치 코드가 붙은 상품명으로 에이블리를 검색해 결과가 없던 문제."""
import sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT)]
import soldout_display as sd

class AblySearchNameTests(unittest.TestCase):
    def test_location_code_dropped_and_empty_result_falls_through(self):
        f=sd.AblyDisplayFlow.__new__(sd.AblyDisplayFlow);asked=[]
        def search(name):
            asked.append(name)
            if name.startswith('['):raise sd.DisplayError('에이블리 검색 결과가 표시되지 않았습니다.')
            return [{'no':'777','name':'스타 프린트 퍼 기모 오버핏 후드 집업'}]
        f.search=search
        hit,tried=f.find_product('(C-13)[2color]스타 프린트 퍼 기모 오버핏 후드 집업')
        self.assertEqual(hit['no'],'777')
        self.assertFalse(any(n.startswith('(C-13)') for n in asked))
        self.assertEqual(asked,['[2color]스타 프린트 퍼 기모 오버핏 후드 집업','스타 프린트 퍼 기모 오버핏 후드 집업'])
        self.assertIn('(결과 없음)',tried[0])
    def test_plain_name_unchanged(self):
        f=sd.AblyDisplayFlow.__new__(sd.AblyDisplayFlow);asked=[]
        f.search=lambda n:(asked.append(n) or [{'no':'1','name':n}])
        f.find_product('(C-13)스타 프린트 퍼 기모 오버핏 후드 집업')
        self.assertEqual(asked,['스타 프린트 퍼 기모 오버핏 후드 집업'])

if __name__=='__main__':unittest.main()
