"""우체국 (접수전)·CJ 접수/예약/등록 반품송장 → 회수 접수 완료."""
import sys,unittest
from datetime import date
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from return_data import clean_tracking,classify,LABELS,PRIORITY

TODAY=date(2026,10,19)
def row(**kw):
    base={'invoice':'6082036587970','requestedAt':'2026-10-15','fee':0,'reason':'단순 변심'}
    base.update(kw);return base

class RegisteredTests(unittest.TestCase):
    def test_clean_tracking_accepts_registered(self):
        tr=clean_tracking({'carrier':'EPOST','orig_delivered':'2026-10-12','return_no':'6082036587999','return_status':'REGISTERED','return_delivered':''},'6082036587970',TODAY)
        self.assertEqual(tr['issue'],'');self.assertEqual(tr['returnStatus'],'REGISTERED')
    def test_registered_is_its_own_category(self):
        r=classify(row(returnStatus='REGISTERED',origDelivered='2026-10-12',issue=''),TODAY)
        self.assertEqual(r['category'],'registered');self.assertEqual(r['label'],'회수 접수 완료');self.assertTrue(r['registered'])
        self.assertEqual(r['logistics'],'undelivered')  # still counted as 미배송 on the card
        self.assertLess(PRIORITY['registered'],PRIORITY['uncollected'])
    def test_fee_row_keeps_registered_flag(self):
        r=classify(row(returnStatus='REGISTERED',origDelivered='2026-10-12',issue='',fee=-3000),TODAY)
        self.assertEqual(r['category'],'fee');self.assertTrue(r['registered'])
    def test_uncollected_without_events(self):
        r=classify(row(returnStatus='NONE',origDelivered='2026-10-12',issue=''),TODAY)
        self.assertEqual(r['category'],'uncollected');self.assertFalse(r['registered'])
    def test_unknown_status_still_needs_check(self):
        tr=clean_tracking({'carrier':'EPOST','return_no':'6082036587999','return_status':'WEIRD'},'6082036587970',TODAY)
        self.assertEqual(tr['issue'],'택배사 상태 확인 필요');self.assertEqual(classify(row(**tr),TODAY)['category'],'unknown')

if __name__=='__main__':unittest.main()
