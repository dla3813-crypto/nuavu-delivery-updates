"""Real Chromium UI + local authenticated server; only synthetic providers.
No background sender thread is started. All outgoing network other than this
loopback server is blocked by the browser route. Run from the project directory:
    python tests/browser_qa.py
Requires Playwright and Chromium; use CHROMIUM_PATH to choose its executable.
"""
import os,sys,json,tempfile,threading,shutil,copy,time,http.client,base64
from urllib.parse import urlsplit
from pathlib import Path
from unittest.mock import patch
from datetime import datetime
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from playwright.sync_api import sync_playwright
from app import LocalServer
from domain import Engine,Store,KST,SELLERS
from helpers import Clock,MemoryVault,FakeSMS,FakeAT
from test_supply_regression import order,source_row,xlsx
checks=[]
def check(name,condition):
    if not condition:raise AssertionError(name)
    checks.append(name)

def run():
 with tempfile.TemporaryDirectory() as tmp,patch('domain.datetime',Clock):
    Clock.current=datetime(2026,10,16,11,tzinfo=KST)
    store=Store(tmp);sms=FakeSMS();at=FakeAT();engine=Engine(store,sms,MemoryVault(),aligo_provider=at,aligo_vault=MemoryVault())
    engine.import_rows({'rows':[order(1,product='리본 니트'),order(2,product='도착 예정 티셔츠',option='아이보리'),
       order(3,product='교환 가디건')|{'orderId':'C00003'},order(4,product='미확정 팬츠'),
       order(5,product='교환 도착 스커트')|{'orderId':'c00005'},order(6,product='수량부족 후드',qty=3),
       order(7,product='확보된 재킷',option='아이보리'),order(8,product='도착 수량0 모자')]})
    folder=Path(tmp)/'synthetic-supply';folder.mkdir()
    (folder/'진행상황_1017.xlsx').write_bytes(xlsx([('진행상황',[source_row(product='도착 예정 티셔츠',office='2026-10-16',qty=2),
      source_row(product='교환 도착 스커트',office='2026-10-16',qty=1),source_row(product='수량부족 후드',office='2026-10-16',qty=1),
      source_row(product='도착 수량0 모자',office='2026-10-16',qty=0)])]))
    (folder/'솔리아 10월 13일 출고장 (완료).xlsx').write_bytes(xlsx([('출고장',[source_row(product='확보된 재킷',qty=1)])]))
    (folder/'진행상황_1016.xlsx').write_bytes(xlsx([('진행상황',[source_row(product='옛날자료',office='2026-10-13',qty=50)])]))
    engine.supply_link(str(folder));engine.supply_refresh()
    server=LocalServer(engine);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    out=ROOT/'docs/qa';out.mkdir(parents=True,exist_ok=True)
    try:
     with sync_playwright() as pw:
      browser=pw.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium'),args=['--no-sandbox','--disable-dev-shm-usage'])
      errors=[];console_errors=[];requests=[];external=[]
      # Browser navigation is disabled in this test environment. Inject only
      # the local bundled assets; use an exposed Python bridge to the actual
      # authenticated HTTP API. This is NOT a macOS/native navigation test.
      def bridge(_source,request):
          requests.append((request.get('method','GET'),request['path']))
          conn=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=20)
          headers=dict(request.get('headers') or {});headers['Origin']=server.origin
          body=request['body'].encode('utf-8') if request.get('body') else None
          conn.request(request.get('method','GET'),request['path'],body,headers)
          response=conn.getresponse();result={'status':response.status,'headers':dict(response.getheaders()),'body':base64.b64encode(response.read()).decode()};conn.close();return result
      response=bridge(None,{'path':'/','method':'GET'})
      boot="window.fetch=async(path,opts={})=>{const r=await window.__localApi({path,method:opts.method||'GET',headers:opts.headers||{},body:opts.body});return new Response(Uint8Array.from(atob(r.body),c=>c.charCodeAt(0)),{status:r.status,headers:r.headers});};"
      nonce='offline-qa-assets-2026'
      # Trusted injected copies need a nonce. Inline style attributes and
      # untrusted code remain forbidden; production uses external self assets.
      csp="default-src 'none'; script-src 'nonce-"+nonce+"' 'unsafe-eval'; style-src 'nonce-"+nonce+"'; img-src data:; connect-src 'none'; base-uri 'none'"
      html=base64.b64decode(response['body']).decode().replace('<head>','<head><meta http-equiv="Content-Security-Policy" content="'+csp+'">')
      html=html.replace('<link rel="stylesheet" href="style.css">','<style nonce="'+nonce+'">'+(ROOT/'web/style.css').read_text()+'</style>')
      for name in ['import.js','excel.js','dispatch_view.js','app.js','order_auto_ui.js','ably_ui.js','factory_reset_ui.js']:
          js=(ROOT/'web'/name).read_text()
          if name=='app.js':
              a=js.index('const token=');b=js.index('let state=');js=boot+js[:a]+'const token='+json.dumps(server.token)+';\n'+js[b:]
          html=html.replace('<script src="'+name+'"></script>','<script nonce="'+nonce+'">'+js+'</script>')
      def start_page():
          p=browser.new_page(viewport={'width':1540,'height':1100},locale='ko-KR');p.set_default_timeout(8000)
          p.on('pageerror',lambda e:errors.append(str(e)))
          p.on('console',lambda m:console_errors.append(m.text) if m.type=='error' else None)
          p.route('**/*',lambda r:(external.append(r.request.url),r.abort()))
          p.expose_binding('__localApi',bridge);p.set_content(html);return p
      page=start_page()
      page.wait_for_function("document.getElementById('totalCount').textContent==='8'")
      check('server response uses self-only style CSP',"style-src 'self'" in response['headers']['Content-Security-Policy'])
      check('fresh shop is blank',page.locator('#shopBrandName').inner_text()=='배송안내')
      check('gear button present',page.get_by_role('button',name='쇼핑몰 이름 설정').is_visible())
      check('exchange count kept',page.locator('#exchangeCount').inner_text()=='2')
      check('unconfirmed count excludes exchanges and secured',page.locator('#dispatchUndatedCount').inner_text()=='2')
      check('planned includes shortage, zero quantity, exchange',page.locator('#dispatchCount').inner_text()=='4')
      page.click('#supplyBtn')
      check('latest progress filename visible', '진행상황_1017.xlsx' in page.locator('#supplyLatestProgress').inner_text())
      check('candidate count and single snapshot visible', '후보 2개 중 1개만 사용' in page.locator('#supplyLatestProgress').inner_text())
      check('older progress is not read', '진행상황_1016.xlsx' not in page.locator('#supplyFilesRead').inner_text())
      check('matching brand does not show false warning', not page.locator('#supplyBrandHint').is_visible())
      page.screenshot(path=str(out/'04_최신진행상황_반영.png'),full_page=True)
      page.click('[data-close=supplyDialog]')
      data=engine.public_state()['rows']
      check('color-only order matches progress',next(r for r in data if r['product']=='도착 예정 티셔츠')['supplyInfo']['matched'])
      check('color-only order matches manifest',next(r for r in data if r['product']=='확보된 재킷')['stockSecured'])
      page.click('#dispatchUndatedCard');page.wait_for_function("document.querySelectorAll('#rows tr').length===2")
      check('unconfirmed rows no C orders',page.locator('#rows .exchange-label').count()==0)
      page.click('#selectAllBtn');check('select all only visible unconfirmed rows',page.locator('#selectionCount').inner_text().startswith('2개'))
      page.click('#composeBtn');check('missing identity opens name settings',page.locator('#shopDialog').evaluate('(e)=>e.open'))
      page.fill('#shopName','데모스토어');check('name greeting preview',page.locator('#shopGreeting').inner_text()=='안녕하세요. 고객님\n데모스토어입니다.')
      page.click('#saveShopBtn');page.wait_for_function("!document.getElementById('shopDialog').open && document.getElementById('shopBrandName').textContent==='데모스토어'")
      check('shop settings persisted',store.read()['settings']['shopName']=='데모스토어')
      page.click('#settingsBtn');check('Aligo API Key input present',page.locator('#smsApiKey').is_visible());check('legacy password and scheme fields gone',page.locator('#smsPassword,#sameAccount,#scheme').count()==0)
      page.fill('#smsUser','DEMO');page.fill('#smsApiKey','OFFLINE-UI-FAKE-KEY');page.fill('#sender','0212345678');page.click('#saveSettingsBtn')
      page.wait_for_function("document.getElementById('smsApiKey').value==='' && document.getElementById('accountState').textContent.includes('사용 준비됨')")
      page.click('#checkLMS');page.wait_for_function("document.getElementById('settingsResult').textContent.includes('432건')")
      check('save/remain did not send',not sms.sent)
      page.click('[data-close=settingsDialog]')
      page.click('#composeBtn');page.wait_for_function("document.getElementById('composeDialog').open")
      for button,kind in [('firstTemplateBtn','first'),('changeTemplateBtn','change'),('soldoutCardTemplateBtn','card'),('soldoutBankTemplateBtn','bank')]:
          page.click('#'+button);body=page.input_value('#template');title=page.input_value('#messageTitle')
          check(kind+' shop name in body/title','데모스토어입니다.' in body and title.startswith('데모스토어'))
          check(kind+' no foreign branding/link','누아브' not in body and 'nuavu.kr' not in body)
      page.screenshot(path=str(out/'02_다른쇼핑몰_품절문구.png'),full_page=True)
      page.click('[data-close=composeDialog]');page.click('#clearBtn');page.click('#exchangeCard')
      page.wait_for_function("document.querySelectorAll('#rows tr').length===2")
      check('exchange view still has both rows',page.locator('#rows .exchange-label').count()==2)
      check('exchange default sort oldest',page.input_value('#sortOrder')=='oldest')
      page.click('#dispatchCard');page.wait_for_function("document.querySelectorAll('#rows tr').length===4")
      check('planned view retains exchange',page.locator('#rows .exchange-label').count()==1)
      page.click('#resetBtn');page.wait_for_function("document.querySelectorAll('#rows tr').length===8")
      before=copy.deepcopy(store.read()['rows']);ledger=copy.deepcopy(store.read()['notices'])
      top_height=page.locator('header').bounding_box()['height']
      original_height=page.locator('#rows tr').first.bounding_box()['height']
      page.locator('#orderTableViewport').scroll_into_view_if_needed();box=page.locator('#orderTableViewport').bounding_box();page.mouse.move(box['x']+box['width']/2,box['y']+90)
      page.keyboard.down('Meta');page.mouse.wheel(0,100);page.keyboard.up('Meta')
      page.wait_for_function("document.getElementById('orderTableViewport').dataset.zoom==='90'")
      check('Cmd+wheel changes CSS zoom',abs(float(page.locator('#orderTable').evaluate('(e)=>getComputedStyle(e).zoom'))-.9)<.001)
      check('row height actually shrinks',page.locator('#rows tr').first.bounding_box()['height']<original_height)
      check('header not zoomed',abs(page.locator('header').bounding_box()['height']-top_height)<.1)
      page.wait_for_timeout(700);check('table zoom saved server-side',store.read()['settings']['tableZoom']==90)
      page.mouse.wheel(0,60);page.wait_for_timeout(100);check('ordinary wheel does not zoom',page.locator('#tableZoomReset').inner_text()=='90%')
      page.close();page=start_page();page.wait_for_function("document.getElementById('tableZoomReset').textContent==='90%'")
      check('table zoom restored after reload',page.locator('#orderTableViewport').get_attribute('data-zoom')=='90')
      check('shop restored after reload',page.locator('#shopBrandName').inner_text()=='데모스토어')
      page.click('#tableZoomReset');page.wait_for_timeout(450);check('reset to100',page.locator('#tableZoomReset').inner_text()=='100%')
      for i in range(12):page.click('#tableZoomIn')
      check('maximum160 clamped',page.locator('#tableZoomReset').inner_text()=='160%' and page.locator('#tableZoomIn').is_disabled())
      for i in range(20):page.click('#tableZoomOut')
      check('minimum60 clamped',page.locator('#tableZoomReset').inner_text()=='60%' and page.locator('#tableZoomOut').is_disabled())
      page.click('#tableZoomReset');page.click('#tableZoomOut');page.locator('#orderTableViewport').scroll_into_view_if_needed()
      box=page.locator('#orderTableViewport').bounding_box();page.mouse.move(box['x']+100,box['y']+100);page.keyboard.press('Meta+0')
      check('Cmd0 resets only table',page.locator('#tableZoomReset').inner_text()=='100%')
      page.click('#tableZoomOut');page.click('#tableZoomOut');page.click('#tableZoomOut');page.click('#tableZoomOut');page.wait_for_timeout(550)
      check('zoom does not alter orders or notices',store.read()['rows']==before and store.read()['notices']==ledger)
      page.evaluate('window.scrollTo(0,0)');page.screenshot(path=str(out/'01_주문목록_80퍼센트.png'),full_page=True)
      page.click('#shopSettingsBtn');page.screenshot(path=str(out/'03_쇼핑몰이름설정.png'),full_page=True);page.click('[data-close=shopDialog]')
      page.click('#aligoSettingsBtn');check('Alimtalk credentials blank',page.input_value('#aligoUser')=='' and page.input_value('#aligoFirstCode')=='' and page.input_value('#aligoChangeCode')=='');page.click('[data-close=aligoDialog]')
      page.set_viewport_size({'width':1024,'height':900});page.wait_for_timeout(100)
      gear=page.locator('#shopSettingsBtn').bounding_box();check('gear accessible at1024',gear['x']>=0 and gear['x']+gear['width']<=1024)
      page.set_viewport_size({'width':1540,'height':1100})
      page.click('#shopSettingsBtn');page.fill('#shopName','두번째몰');page.click('#saveShopBtn');page.wait_for_function("document.getElementById('shopBrandName').textContent==='두번째몰'")
      check('name updates after later save',store.read()['settings']['shopName']=='두번째몰')
      # New file arrival is metadata only until the user presses refresh.
      (folder/'진행상황_1018.xlsx').write_bytes(xlsx([('진행상황',[source_row(product='도착 예정 티셔츠',office='2026-10-20',qty=1)])]))
      page.click('#supplyBtn')
      check('no automatic folder reread on opening', '진행상황_1017.xlsx' in page.locator('#supplyLatestProgress').inner_text())
      page.click('#refreshSupply')
      page.wait_for_function("document.getElementById('supplyLatestProgress').textContent.includes('진행상황_1018.xlsx')")
      check('manual button selects next latest',store.read()['supply']['lastScan']['progressSelection']['name']=='진행상황_1018.xlsx')
      check('manual refresh replaces not merges progress',len(store.read()['supply']['progress'])==1)
      check('refresh kept selected brand choices',store.read()['supply']['brands']==['N','NS'])
      # Explain why a foreign store brand has no matching stock, never auto-select all.
      (folder/'진행상황_1019.xlsx').write_bytes(xlsx([('진행상황',[source_row(product='도착 예정 티셔츠',office='2026-10-20',brand='OD')])]))
      page.click('#refreshSupply')
      page.wait_for_function("document.getElementById('supplyLatestProgress').textContent.includes('진행상황_1019.xlsx')")
      check('unselected source brand has explicit warning','OD' in page.locator('#supplyWarnings').inner_text() and '선택 브랜드' in page.locator('#supplyWarnings').inner_text())
      check('new brand discovered as selectable checkbox',page.locator('#brandChoices input[value=OD]').count()==1)
      check('new brand never selected automatically',not page.locator('#brandChoices input[value=OD]').is_checked())
      page.locator('#brandChoices input[value=OD]').check();page.click('#refreshSupply')
      page.wait_for_function("document.getElementById('supplyLoadDetail').textContent.includes('진행상황 1행')")
      check('own brand choice enables match',next(r for r in engine.public_state()['rows'] if r['product']=='도착 예정 티셔츠')['supplyInfo']['matched'])
      page.click('[data-close=supplyDialog]')
      # v0.6.17: recommendations are a read-only queue until explicitly saved.
      new_orders=[order(201,product='4컬러 어텀 트위드',option='화이트'),
                  order(202,product='4컬러 어텀 트위드',option='화이트'),
                  order(203,product='카고 팬츠',option='카키 / M'),
                  order(204,product='사이즈 다른 니트',option='화이트 / 55'),
                  order(205,product='자료 없는 상품',option='화이트'),
                  order(206,product='자동 연결 재킷',option='블랙')]
      engine.import_rows(dict(rows=new_orders,mode='snapshot',scope=SELLERS,replaceConfirmed=True))
      (folder/'진행상황_1020.xlsx').write_bytes(xlsx([('권장 테스트',[
          source_row(product='어텀 트위드',color='米白色 아이보리03',qty=2,office='2026-10-17'),
          source_row(product='카고 팬츠',color='그린',size='M',office='2026-10-17'),
          source_row(product='사이즈 다른 니트',color='아이보리',size='66',office='2026-10-17'),
          source_row(product='자동 연결 재킷',color='黑色 블랙2',office='2026-10-17')])]))
      engine.supply_refresh()
      page.evaluate('refresh()');page.click('#resetBtn')
      page.wait_for_function("document.getElementById('manualMatchCount').textContent==='3'")
      before_recommendations=copy.deepcopy(store.read())
      page.click('#manualMatchCard')
      page.wait_for_function("document.querySelectorAll('#rows tr').length===3")
      check('recommendation card activates filter',page.input_value('#statusFilter')=='manual_recommended')
      check('recommendation card shows own count and panel',page.locator('#manualMatchPanel').is_visible() and '3개 상품 / 3개 주문' in page.locator('#manualMatchSummary').inner_text())
      check('recommendation filter is current-only',page.locator('#activeFilter').is_disabled())
      check('recommendation filter excludes wrong size and unrelated products','사이즈 다른 니트' not in page.locator('#rows').inner_text() and '자료 없는 상품' not in page.locator('#rows').inner_text())
      check('recommendations show both user color pairs','화이트' in page.locator('#rows').inner_text() and '아이보리' in page.locator('#rows').inner_text() and '카키' in page.locator('#rows').inner_text() and '그린' in page.locator('#rows').inner_text())
      check('suggestions do not assign dates',all(not r['dispatchEnd'] for r in engine.public_state()['rows'] if r['active'] and r['orderId'] in {'TEST-201','TEST-202','TEST-203'}))
      page.locator('.cards').screenshot(path=str(out/'05_수동매칭_권장카드.png'))
      page.fill('#search','어텀');page.wait_for_function("document.querySelectorAll('#rows tr').length===2")
      check('recommendation filter combines with search',page.locator('#rows tr').count()==2)
      page.click('#selectAllBtn');check('select all respects recommendation search',page.locator('#selectionCount').inner_text().startswith('2개'))
      page.click('#clearBtn');page.locator('#rows .rowmatch').first.click()
      page.wait_for_function("document.getElementById('matchDialog').open")
      check('recommended choices shown first and only',page.locator('#matchCandidates tbody tr').count()==1 and page.locator('#matchRecommendedOnly').is_checked())
      check('no suggestion is preselected',page.locator('#matchCandidates input:checked').count()==0)
      check('recommendation reason includes original source label','米白色 아이보리03' in page.locator('#matchingReason').inner_text())
      page.locator('#matchDialog').screenshot(path=str(out/'06_수동매칭_권장후보.png'))
      page.locator('#matchRecommendedOnly').uncheck()
      check('all existing manual candidates remain available',page.locator('#matchCandidates tbody tr').count()>1)
      check('suggested row stays first in all-candidate view',page.locator('#matchCandidates tbody tr').first.get_attribute('class')=='match-recommended-row')
      page.locator('#matchRecommendedOnly').check()
      page.click('[data-close=matchDialog]')
      check('opening filtering and dismissing recommendations changes no data',store.read()==before_recommendations)
      page.locator('#rows .rowmatch').first.click()
      page.locator('#matchCandidates .match-check').first.check();page.click('#saveMatchBtn')
      page.wait_for_function("!document.getElementById('matchDialog').open && document.getElementById('manualMatchCount').textContent==='1'")
      check('saving mapping removes all same-option orders from recommendation queue',page.locator('#rows tr').count()==0)
      linked=[r for r in engine.public_state()['rows'] if r['active'] and r['orderId'] in {'TEST-201','TEST-202'}]
      check('only explicit save enables manual allocation',all(r['supplyInfo']['matchMethod']=='manual' and r['dispatchEnd'] for r in linked))
      page.fill('#search','');page.wait_for_function("document.querySelectorAll('#rows tr').length===1")
      check('remaining recommendation is khaki versus green','카고 팬츠' in page.locator('#rows').inner_text())
      for width in [1024,620]:
          page.set_viewport_size({'width':width,'height':1000})
          box=page.locator('#manualMatchCard').bounding_box()
          check('recommendation card fits viewport '+str(width),box['x']>=0 and box['x']+box['width']<=width)
      page.set_viewport_size({'width':1540,'height':1100})
      page.close();page=start_page()
      page.wait_for_function("document.getElementById('manualMatchCount').textContent==='1'")
      check('saved manual mapping persists on page reload',len(store.read()['supply']['mappings'])==1)
      # v0.6.18: half-width pink card, separate watch/confirmed shortages.
      Clock.current=datetime(2026,10,19,11,tzinfo=KST)
      forecast_orders=[order(301,product='어텀 미도착',qty=2),order(302,product='부분 입고 니트',qty=3),
                       order(303,product='다음 회차 대기'),order(304,product='출고장 전량 확보'),
                       order(305,product='사무실 전량 도착'),order(306,product='안내 전 상품'),
                       order(307,product='이미 예정일 경과')]
      engine.import_rows(dict(rows=forecast_orders,mode='snapshot',scope=SELLERS,replaceConfirmed=True))
      active={r['orderId']:r for r in engine.public_state()['rows'] if r['active']}
      for ids,due in [([301,302,304,305],'2026-10-21'),([303],'2026-10-26'),([307],'2026-10-18')]:
          engine.external_manual(dict(keys=[active[f'TEST-{i}']['key'] for i in ids],dueDate=due))
      forecast_sources=[source_row(product='어텀 미도착',qty=2),source_row(product='부분 입고 니트',qty=1,office='2026-10-17'),
                        source_row(product='다음 회차 대기'),source_row(product='출고장 전량 확보'),
                        source_row(product='사무실 전량 도착',office='2026-10-17'),
                        source_row(product='안내 전 상품'),source_row(product='이미 예정일 경과')]
      (folder/'진행상황_1021.xlsx').write_bytes(xlsx([('초과 예상',forecast_sources)]))
      (folder/'솔리아 10월 17일 출고장 (완료).xlsx').write_bytes(xlsx([('출고장',[source_row(product='출고장 전량 확보')])]))
      engine.supply_refresh();page.evaluate('refresh()');page.click('#resetBtn')
      page.wait_for_function("document.getElementById('delayRiskCount').textContent==='3'")
      check('risk card shows watch and confirmed counts','감시 1 · 확정 2'==page.locator('#delayRiskCounts').inner_text())
      left=page.locator('#manualMatchCard').bounding_box();right=page.locator('#delayRiskCard').bounding_box()
      check('manual and risk cards share half-width row',abs(left['y']-right['y'])<1 and abs(left['width']-right['width'])<1 and right['x']>left['x'])
      page.mouse.move(0,0)
      check('risk card is pink',page.locator('#delayRiskCard').evaluate('(e)=>getComputedStyle(e).backgroundColor')=='rgb(255, 244, 248)')
      page.locator('.cards').screenshot(path=str(out/'07_초과예상_카드.png'))
      before_forecast=copy.deepcopy(store.read())
      page.click('#delayRiskCard');page.wait_for_function("document.querySelectorAll('#rows tr').length===1")
      check('risk card opens watch section','다음 회차 대기' in page.locator('#rows').inner_text() and page.locator('#riskWatchBtn').get_attribute('aria-pressed')=='true')
      check('risk filter locks current orders',page.locator('#activeFilter').is_disabled())
      check('watch summary uses missing quantity','부족 1개' in page.locator('#delayRiskSummary').inner_text())
      page.click('#riskConfirmedBtn');page.wait_for_function("document.querySelectorAll('#rows tr').length===2")
      check('confirmed section contains partial and absent supply','부분 입고 니트' in page.locator('#rows').inner_text() and '어텀 미도착' in page.locator('#rows').inner_text())
      check('confirmed summary conserves quantities','부족 4개' in page.locator('#delayRiskSummary').inner_text())
      check('covered unnotified and already overdue excluded',all(x not in page.locator('#rows').inner_text() for x in ['전량 확보','전량 도착','안내 전 상품','이미 예정일 경과']))
      page.fill('#search','부분');page.wait_for_function("document.querySelectorAll('#rows tr').length===1")
      check('risk search updates scope and shortage summary','부족 2개' in page.locator('#delayRiskSummary').inner_text() and page.locator('#riskConfirmedCount').inner_text()=='1')
      page.click('#selectAllBtn');check('risk select-all stays within filtered section',page.locator('#selectionCount').inner_text().startswith('1개'))
      page.click('#clearBtn');page.locator('#rows .risk-details').click()
      page.wait_for_function("document.getElementById('delayRiskDialog').open")
      check('risk detail explains October 15 and 19 criteria',all(x in page.locator('#delayRiskDetails').inner_text() for x in ['2026-10-15','2026-10-19','2026-10-21','부족 수량 2개','진행상황 1']))
      page.locator('#delayRiskDialog').screenshot(path=str(out/'09_초과예상_부족수량.png'))
      page.click('[data-close=delayRiskDialog]');page.fill('#search','')
      page.evaluate('window.scrollTo(0,0)');page.screenshot(path=str(out/'08_초과예상_확정목록.png'),full_page=True)
      check('viewing risk sections and evidence does not mutate business data',store.read()==before_forecast)
      for width in [1024,620]:
          page.set_viewport_size({'width':width,'height':1000});box=page.locator('#delayRiskCard').bounding_box()
          check('risk card fits viewport '+str(width),box['x']>=0 and box['x']+box['width']<=width)
      page.set_viewport_size({'width':1540,'height':1100})
      changed=copy.deepcopy(forecast_sources);changed[0][21]='2026-10-17';changed[1][9]=3
      (folder/'진행상황_1022.xlsx').write_bytes(xlsx([('초과 예상',changed)]))
      check('new file alone cannot clear forecast',page.locator('#delayRiskCount').inner_text()=='3')
      page.click('#supplyBtn');page.click('#refreshSupply')
      page.wait_for_function("document.getElementById('delayRiskCount').textContent==='1'")
      page.click('[data-close=supplyDialog]')
      check('manual refresh clears supplied confirmed rows',page.locator('#riskConfirmedCount').inner_text()=='0')
      Clock.current=datetime(2026,10,21,0,1,tzinfo=KST);page.evaluate('refresh()')
      page.wait_for_function("document.getElementById('delayRiskReadAt').textContent.includes('2026-10-21')")
      page.click('#riskWatchBtn')
      check('next cycle remains watched until updated evidence','갱신 대기 1개' in page.locator('#delayRiskSummary').inner_text())
      page.click('#supplyBtn');page.click('#refreshSupply')
      page.wait_for_function("document.getElementById('delayRiskCounts').textContent==='감시 0 · 확정 1'")
      page.click('[data-close=supplyDialog]');page.click('#riskConfirmedBtn')
      check('Tuesday cycle advances after Wednesday refresh','다음 회차 대기' in page.locator('#rows').inner_text())
      Clock.current=datetime(2026,10,27,10,tzinfo=KST);page.evaluate('refresh()')
      page.wait_for_function("document.getElementById('delayRiskCount').textContent==='0'")
      check('past promises move out of forecast to existing overdue classification',all(r['noticeBucket']=='overdue' for r in engine.public_state()['rows'] if r['active'] and r.get('dueDate')))
      # v0.6.19: include both V columns, without adding stock or inventing dates.
      Clock.current=datetime(2026,10,17,11,tzinfo=KST)
      arrival_orders=[order(401,product='진행상황만 니트'),order(402,product='출고장만 셔츠'),
                      order(403,product='양쪽 도착 가디건',qty=2),order(404,product='V 없는 재킷',qty=2),
                      order(405,product='V 오류 팬츠',qty=2),order(406,product='다른 옵션 치마',option='블랙 / M'),
                      order(407,product='순서 배정 모자'),order(408,product='순서 배정 모자')]
      engine.import_rows(dict(rows=arrival_orders,mode='snapshot',scope=SELLERS,replaceConfirmed=True))
      (folder/'진행상황_1023.xlsx').write_bytes(xlsx([('진행상황',[
          source_row(product='진행상황만 니트',office='2026-10-16'),
          source_row(product='양쪽 도착 가디건',office='2026-10-15')])]))
      arrival_manifests=[source_row(product='출고장만 셔츠',office='2026-10-15'),
          source_row(product='양쪽 도착 가디건',office='2026-10-16'),
          source_row(product='V 없는 재킷'),
          source_row(product='V 오류 팬츠',office='미도착 <img src=x onerror=alert(1)>'),
          source_row(product='다른 옵션 치마',color='화이트',size='M',office='2026-10-16'),
          source_row(product='순서 배정 모자',office='2026-10-16')]
      arrival_path=folder/'솔리아 10월 17일 출고장 (완료).xlsx'
      arrival_path.write_bytes(xlsx([('출고장',arrival_manifests)]))
      engine.supply_refresh();page.evaluate('refresh()');page.click('#resetBtn')
      page.wait_for_function("document.getElementById('totalCount').textContent==='8' && document.getElementById('dispatchCount').textContent==='5'")
      before_arrivals=copy.deepcopy(store.read())
      check('planned card explicitly includes both V columns','진행상황·출고장 V 도착일 있음' in page.locator('#dispatchCard').inner_text())
      check('planned card counts both-source order once',page.locator('#dispatchCount').inner_text()=='5')
      page.click('#dispatchCard');page.wait_for_function("document.querySelectorAll('#rows tr').length===5")
      check('manifest-only and progress-only orders both visible',all(x in page.locator('#rows').inner_text() for x in ['진행상황만 니트','출고장만 셔츠','양쪽 도착 가디건']))
      check('blank invalid and wrong-option V excluded from planned',all(x not in page.locator('#rows').inner_text() for x in ['V 없는 재킷','V 오류 팬츠','다른 옵션 치마']))
      page.locator('.cards').screenshot(path=str(out/'10_양쪽V_카드.png'))
      page.fill('#search','양쪽');page.wait_for_function("document.querySelectorAll('#rows tr').length===1")
      check('both V dates have distinct labels on order row',all(x in page.locator('#rows').inner_text() for x in ['진행상황 V · 2026-10-15','출고장 V · 2026-10-16']))
      check('shortage row exposes dates with no full dispatch date','도착일 근거 보기' in page.locator('#rows').inner_text())
      page.click('#selectAllBtn');check('both-source order is selected once',page.locator('#selectionCount').inner_text().startswith('1개'))
      page.click('#clearBtn');page.locator('#rows .receipt-details').click()
      page.wait_for_function("document.getElementById('receiptDialog').open")
      detail=page.locator('#receiptDetails').inner_text()
      check('detail separates V office arrivals and manifest dispatch basis',all(x in detail for x in ['V 사무실 도착일','진행상황 V · 2026-10-15','출고장 V · 2026-10-16','완료 출고장 2026-10-17']))
      check('both V dates do not duplicate same-wave allocation','출고장 확보 1개 / 진행상황 날짜 확인 물량 0개' in detail)
      page.locator('#receiptDialog').screenshot(path=str(out/'11_양쪽V_도착일상세.png'))
      page.click('[data-close=receiptDialog]');page.fill('#search','')
      page.select_option('#dispatchSource','secured');page.wait_for_function("document.querySelectorAll('#rows tr').length===2")
      check('secured filter includes dated manifests',page.locator('#rows tr').count()==2)
      page.select_option('#dispatchSource','progress');page.wait_for_function("document.querySelectorAll('#rows tr').length===3")
      check('not fully secured filter includes partial manifests',page.locator('#rows tr').count()==3)
      page.select_option('#dispatchSource','all')
      page.locator('[data-range=__undated__]').click();page.wait_for_function("document.querySelectorAll('#rows tr').length===2")
      check('calculation-pending includes shortage and FIFO-later manifest arrivals','양쪽 도착 가디건' in page.locator('#rows').inner_text() and 'TEST-408' in page.locator('#rows').inner_text())
      page.click('#dispatchClear');page.evaluate('window.scrollTo(0,0)')
      page.locator('#toast').wait_for(state='hidden')
      page.screenshot(path=str(out/'12_양쪽V_주문목록.png'),full_page=True)
      page.click('#dispatchUndatedCard');page.wait_for_function("document.querySelectorAll('#rows tr').length===3")
      check('unconfirmed excludes valid V from either source',all(x in page.locator('#rows').inner_text() for x in ['V 없는 재킷','V 오류 팬츠','다른 옵션 치마']))
      page.fill('#search','V 오류');page.locator('#rows .source-details').click()
      page.wait_for_function("document.getElementById('receiptDialog').open")
      check('invalid manifest V is displayed as text not executable HTML','미도착 <img src=x onerror=alert(1)>' in page.locator('#receiptDetails').inner_text() and page.locator('#receiptDetails img').count()==0)
      page.click('[data-close=receiptDialog]')
      check('reading both V columns does not modify records',store.read()==before_arrivals)
      arrival_manifests[0][21]='2026-10-14';arrival_path.write_bytes(xlsx([('출고장',arrival_manifests)]))
      page.click('#resetBtn');page.click('#dispatchCard');page.fill('#search','출고장만')
      check('new manifest V stays unchanged before refresh','출고장 V · 2026-10-15' in page.locator('#rows').inner_text())
      page.click('#supplyBtn');page.click('#refreshSupply')
      page.wait_for_function("document.getElementById('rows').textContent.includes('출고장 V · 2026-10-14')")
      page.click('[data-close=supplyDialog]')
      check('manual refresh updates manifest V display','출고장 V · 2026-10-14' in page.locator('#rows').inner_text())
      # v0.6.20: download current section/selection and reverse latest accidental close.
      from workbook_reader import read_xlsx
      from order_export import HEADERS
      contact=dict(recipientMobile='010-0000-0011',recipientPhone='02-000-1111',buyerPhone='02-000-2222',buyerMobile='010-0000-0022',sellerLabel='가상 쇼핑몰')
      for r in arrival_orders:r['exportContacts']=contact
      engine.import_rows(dict(rows=arrival_orders,mode='snapshot',scope=SELLERS,replaceConfirmed=True))
      page.evaluate('refresh()');page.click('#resetBtn')
      page.select_option('#statusFilter','white')
      page.wait_for_function("document.querySelectorAll('#rows tr').length===8")
      export_box=page.locator('#orderExportBtn').bounding_box();notice_box=page.locator('#noSendBtn').bounding_box()
      check('order download is left of message-free notice',export_box['x']<notice_box['x'] and abs(export_box['y']-notice_box['y'])<1)
      check('order download is green',page.locator('#orderExportBtn').evaluate('(e)=>getComputedStyle(e).backgroundColor')=='rgb(224, 245, 233)')
      before_export=copy.deepcopy(store.read())
      with page.expect_download() as exported:page.click('#orderExportBtn')
      download=exported.value
      sample=ROOT.parent/'v0622_export_sample.xlsx';download.save_as(sample)
      exported_rows=read_xlsx(sample.read_bytes())[0]['rows']
      check('section export uses label and Korean current date',download.suggested_filename=='안내 전_1017.xlsx')
      check('unselected section exports all eight orders in 12 columns',exported_rows[0]==HEADERS and len(exported_rows)==9 and all(len(r)==12 for r in exported_rows))
      check('recipient mobile and remaining buyer fields survive download',all(r[4:8]==['010-0000-0011','가상 쇼핑몰','02-000-2222','010-0000-0022'] for r in exported_rows[1:]))
      page.click('#dispatchCard');page.fill('#search','순서')
      page.wait_for_function("document.querySelectorAll('#rows tr').length===2")
      page.locator('#rows input[type=checkbox]').first.check()
      with page.expect_download() as selected_export:page.click('#orderExportBtn')
      selected_file=Path(tmp)/'selected.xlsx';selected_export.value.save_as(selected_file)
      check('selected export respects current filter and selected row',len(read_xlsx(selected_file.read_bytes())[0]['rows'])==2)
      check('planned section filename follows active card',selected_export.value.suggested_filename=='출고 예정일자(예정)_1017.xlsx')
      page.fill('#search','출고장만');page.wait_for_function("document.querySelectorAll('#rows tr').length===1")
      request_count=sum(path=='/api/order-export' for method,path in requests)
      page.click('#orderExportBtn');page.wait_for_function("document.getElementById('toast').textContent.includes('현재 섹션에서 선택한 주문이 없습니다')")
      check('hidden selections are not exported',sum(path=='/api/order-export' for method,path in requests)==request_count)
      page.click('#clearBtn')
      with page.expect_download() as filtered_export:page.click('#orderExportBtn')
      filtered_file=Path(tmp)/'filtered.xlsx';filtered_export.value.save_as(filtered_file)
      filtered_rows=read_xlsx(filtered_file.read_bytes())[0]['rows']
      check('without selection search exports only matching orders',len(filtered_rows)==2 and filtered_rows[1][0].startswith('출고장만 셔츠/'))
      check('Excel basis comes from allocated manifest',filtered_rows[1][11]=='출고장')
      check('downloads do not change orders notices or allocation',store.read()==before_export)
      page.click('#dismissOrderExportBtn')
      page.fill('#search','없는검색어');check('empty result disables order download',page.locator('#orderExportBtn').is_disabled())
      page.click('#resetBtn');page.locator('.toolbar').screenshot(path=str(out/'13_주문엑셀_다운로드.png'))
      for width in [1024,620]:
          page.set_viewport_size({'width':width,'height':1000});box=page.locator('#orderExportBtn').bounding_box()
          check('download button fits viewport '+str(width),box['x']>=0 and box['x']+box['width']<=width)
      page.set_viewport_size({'width':1540,'height':1100})
      before_restore=copy.deepcopy(engine.public_state()['rows']);before_business=copy.deepcopy(store.read())
      page.click('#supplyBtn')
      reset_box=page.locator('#resetManifestBtn').bounding_box();restore_box=page.locator('#reallocateManifestBtn').bounding_box()
      check('reallocation button sits next to reset',restore_box['x']>reset_box['x'] and abs(restore_box['y']-reset_box['y'])<1)
      page.once('dialog',lambda d:d.accept());page.click('#resetManifestBtn')
      page.wait_for_function("!document.getElementById('reallocateManifestBtn').disabled && document.getElementById('reallocateHint').textContent.includes('복원 가능 수량')")
      check('reset exposes exact latest recovery and quantity',engine.public_state()['supply']['reallocation']['available'] and '개 출고장' in page.locator('#reallocateHint').inner_text())
      page.locator('#supplyDialog').screenshot(path=str(out/'14_출고장_재배치.png'))
      closed=copy.deepcopy(store.read());dialogs=[]
      page.once('dialog',lambda d:(dialogs.append(d.message),d.dismiss()));page.click('#reallocateManifestBtn')
      page.wait_for_function("!document.getElementById('reallocateManifestBtn').disabled")
      check('cancelling reallocation keeps closed stock unchanged',store.read()==closed)
      check('reallocation confirmation names sources and explains current order assignment','현재 주문 순서대로' in dialogs[0] and '솔리아 10월 17일 출고장' in dialogs[0])
      page.once('dialog',lambda d:d.accept());page.click('#reallocateManifestBtn')
      page.wait_for_function("document.getElementById('reallocateManifestBtn').disabled && document.getElementById('reallocateHint').textContent.includes('최근 마감한 출고장이 있으면')")
      after_restore=engine.public_state()['rows'];after_business=store.read()
      check('reallocation restores exact order quantities and dates',[(r['key'],r['supplyInfo'].get('parts',[]),r['dispatchStart'],r['dispatchEnd']) for r in before_restore]==[(r['key'],r['supplyInfo'].get('parts',[]),r['dispatchStart'],r['dispatchEnd']) for r in after_restore])
      check('reallocation preserves orders notices and shop settings',all(before_business[k]==after_business[k] for k in ('rows','notices','settings')))
      check('completed reallocation cannot run twice',not engine.public_state()['supply']['reallocation']['available'] and page.locator('#reallocateManifestBtn').is_disabled())
      page.click('[data-close=supplyDialog]')
      # v0.6.21: translated Chinese colors stay in the manual recommendation queue.
      translated_orders=[order(601,product='중국 컬러 가디건',option='베이지'),
          order(602,product='중국 컬러 티셔츠',option='화이트'),order(603,product='중국 컬러 팬츠',option='다크그레이'),
          order(604,product='미등록 컬러 니트',option='블랙'),order(605,product='사이즈 확인 셔츠',option='베이지 / 55')]
      engine.import_rows(dict(rows=translated_orders,mode='snapshot',scope=SELLERS,replaceConfirmed=True))
      (folder/'진행상황_1024.xlsx').write_bytes(xlsx([('번역 테스트',[
          source_row(product='중국 컬러 가디건',color='卡其色17',office='2026-10-17'),
          source_row(product='중국 컬러 티셔츠',color='米白色',office='2026-10-17'),
          source_row(product='중국 컬러 팬츠',color='深灰色',office='2026-10-17'),
          source_row(product='미등록 컬러 니트',color='未知灰色 <img src=x onerror=alert(1)>',office='2026-10-17'),
          source_row(product='사이즈 확인 셔츠',color='卡其色',size='66',office='2026-10-17')])]))
      engine.supply_refresh();page.evaluate('refresh()');page.click('#resetBtn')
      page.wait_for_function("document.getElementById('manualMatchCount').textContent==='3'")
      before_translation=copy.deepcopy(store.read())
      page.click('#manualMatchCard');page.wait_for_function("document.querySelectorAll('#rows tr').length===3")
      check('Chinese-only colors join manual recommendations',all(x in page.locator('#rows').inner_text() for x in ['중국 컬러 가디건','중국 컬러 티셔츠','중국 컬러 팬츠']))
      check('unknown colors and wrong sizes do not get translated recommendations',all(x not in page.locator('#rows').inner_text() for x in ['미등록 컬러 니트','사이즈 확인 셔츠']))
      check('recommendation reasons show Korean translation and original',all(x in page.locator('#rows').inner_text() for x in ['공급 베이지 (원문: 卡其色17)','공급 아이보리 (원문: 米白色)','공급 다크그레이 (원문: 深灰色)']))
      check('translated recommendation does not assign stock or a date',all(not r['dispatchEnd'] and not r['supplyInfo']['allocatedQty'] for r in engine.public_state()['rows'] if r['active']))
      page.fill('#search','가디건');page.locator('#rows .rowmatch').click()
      page.wait_for_function("document.getElementById('matchDialog').open")
      source_cell=page.locator('#matchCandidates tbody tr').first.locator('td').nth(3)
      check('Chinese source color is displayed Korean first',source_cell.inner_text().startswith('베이지') and '원문: 卡其色17' in source_cell.inner_text())
      check('translated candidate is never preselected',page.locator('#matchCandidates input:checked').count()==0)
      page.fill('#matchSearch','베이지');check('translated Korean color is searchable',page.locator('#matchCandidates tbody tr').count()==1)
      page.fill('#matchSearch','卡其色');check('original Chinese color remains searchable',page.locator('#matchCandidates tbody tr').count()==1)
      page.fill('#matchSearch','');page.locator('#matchDialog').screenshot(path=str(out/'15_중국어컬러_한국어표시.png'))
      page.locator('#matchRecommendedOnly').uncheck();page.fill('#matchSearch','未知灰色')
      check('unknown translation is explicitly labelled',page.locator('#matchCandidates tbody tr').count()==1 and '번역 확인 필요' in page.locator('#matchCandidates').inner_text())
      check('Chinese original is escaped rather than executable HTML',page.locator('#matchCandidates img').count()==0 and '<img src=x onerror=alert(1)>' in page.locator('#matchCandidates').inner_text())
      page.click('[data-close=matchDialog]')
      check('translation browsing never rewrites original data',store.read()==before_translation)
      page.locator('#rows .rowmatch').click();page.locator('#matchCandidates .match-check').first.check()
      expected_id=page.locator('#matchCandidates .match-check').first.get_attribute('value')
      page.click('#saveMatchBtn');page.wait_for_function("!document.getElementById('matchDialog').open && document.getElementById('manualMatchCount').textContent==='2'")
      translated_row=next(r for r in engine.public_state()['rows'] if r['active'] and r['orderId']=='TEST-601')
      check('explicit selection connects original variant with conserved quantity',translated_row['supplyInfo']['manualVariants']==[expected_id] and translated_row['supplyInfo']['allocatedQty']==1)
      check('saving a translation mapping keeps Chinese source unchanged',any(r['color']=='卡其色17' and r['variant']==expected_id for r in store.read()['supply']['progress']))
      page.close();page=start_page();page.wait_for_function("document.getElementById('manualMatchCount').textContent==='2'")
      check('translation and manual mapping survive UI reload',any(r['colorLabel']=='베이지' for r in engine.public_state()['supply']['variants']) and next(r for r in engine.public_state()['rows'] if r['orderId']=='TEST-601')['supplyInfo']['matchMethod']=='manual')
      # v0.6.22: old orders get mobile numbers, 12-column filters, saved-file Finder button.
      from desktop import DesktopAPI
      from types import SimpleNamespace
      from xml.etree import ElementTree as ET
      import zipfile
      export_orders_94=[order(i,product='휴대폰 출력 확인')|{'recipient':'가상 수령자','phoneSource':'주문자'} for i in range(700,794)]
      engine.import_rows(dict(rows=export_orders_94,mode='snapshot',scope=SELLERS,replaceConfirmed=True))
      page.evaluate('refresh()');page.click('#resetBtn')
      page.wait_for_function("document.getElementById('totalCount').textContent==='94'")
      before_mobile_export=copy.deepcopy(store.read())
      with page.expect_download() as mobile_export:page.click('#orderExportBtn')
      mobile_file=ROOT.parent/'v0622_export_sample.xlsx';mobile_export.value.save_as(mobile_file)
      mobile_rows=read_xlsx(mobile_file.read_bytes())[0]['rows']
      check('94 old order items export recipient mobiles without reimport',len(mobile_rows)==95 and all(r[4].startswith('010-') and len(r[4])==13 for r in mobile_rows[1:]))
      check('recipient landline column is removed without shifting remaining values',len(mobile_rows[0])==12 and '수령자전화' not in mobile_rows[0] and all(r[8].startswith('TEST-') for r in mobile_rows[1:]))
      with zipfile.ZipFile(mobile_file) as archive:
          xml=ET.fromstring(archive.read('xl/worksheets/sheet1.xml'))
          filter_node=xml.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}autoFilter')
          check('header filters cover all 94 items',filter_node is not None and filter_node.get('ref')=='A1:L95')
      check('browser receipt does not pretend to know native download path',page.locator('#revealOrderExportBtn').is_hidden() and page.locator('#openOrderExportBtn').is_hidden() and '94개 주문상품 엑셀' in page.locator('#orderExportMessage').inner_text())
      class ExportWindow:
          destination=Path(tmp)/'직접 선택한 저장명.xlsx'
          def get_current_url(self):return server.origin+'/'
          def create_file_dialog(self,*args,**kwargs):return str(self.destination) if self.destination else None
      window=ExportWindow();native=DesktopAPI(engine,server.token,server.origin,SimpleNamespace(FileDialog=SimpleNamespace(SAVE='save')));native._window=window
      finder_calls=[];file_open_calls=[]
      def native_save(_source,request):return native.save_export(request['token'],request['kind'],request['payload'])
      def native_reveal(_source,request):
          with patch('desktop.sys.platform','darwin'),patch('desktop.subprocess.run') as opened:
              result=native.reveal_export(request['token'],request['id'])
              if opened.called:finder_calls.append(opened.call_args.args[0])
              return result
      def native_open(_source,request):
          with patch('desktop.sys.platform','darwin'),patch('desktop.subprocess.run') as opened:
              result=native.open_export(request['token'],request['id'])
              if opened.called:file_open_calls.append(opened.call_args.args[0])
              return result
      page.expose_binding('__nativeSave',native_save);page.expose_binding('__nativeReveal',native_reveal);page.expose_binding('__nativeOpen',native_open)
      page.evaluate("window.pywebview={api:{save_export:(token,kind,payload)=>window.__nativeSave({token,kind,payload}),reveal_export:(token,id)=>window.__nativeReveal({token,id}),open_export:(token,id)=>window.__nativeOpen({token,id})}}")
      server.desktop=True;page.evaluate('refresh()');page.click('#orderExportBtn')
      page.wait_for_function("!document.getElementById('revealOrderExportBtn').hidden && document.getElementById('orderExportMessage').textContent==='94개 주문상품 엑셀을 저장했습니다.'")
      check('native save receipt uses actual chosen filename',page.locator('#orderExportFilename').inner_text()==window.destination.name)
      check('Finder button does not open Finder automatically',not finder_calls and not file_open_calls)
      check('native file contains all phone-filled rows',len(read_xlsx(window.destination.read_bytes())[0]['rows'])==95 and all(r[4] for r in read_xlsx(window.destination.read_bytes())[0]['rows'][1:]))
      page.locator('#orderExportResult').screenshot(path=str(out/'17_엑셀저장_Finder_열기.png'))
      page.click('#revealOrderExportBtn');page.wait_for_function("!document.getElementById('revealOrderExportBtn').disabled")
      check('Finder button requests selection of exact saved file',finder_calls==[['/usr/bin/open','-R',str(window.destination)]])
      reveal_box=page.locator('#revealOrderExportBtn').bounding_box();open_box=page.locator('#openOrderExportBtn').bounding_box()
      check('Open is next to Finder in save receipt',open_box['x']>reveal_box['x'] and abs(open_box['y']-reveal_box['y'])<1)
      page.click('#openOrderExportBtn');page.wait_for_function("!document.getElementById('openOrderExportBtn').disabled")
      check('Open launches exact saved XLSX using default associated application',file_open_calls==[['/usr/bin/open',str(window.destination)]])
      for width in [1024,620]:
          page.set_viewport_size({'width':width,'height':1000});box=page.locator('#orderExportResult').bounding_box()
          check('saved-file receipt fits viewport '+str(width),box['x']>=0 and box['x']+box['width']<=width)
      page.set_viewport_size({'width':1540,'height':1100})
      saved_path=window.destination;window.destination=None
      page.click('#orderExportBtn');page.wait_for_function("!document.getElementById('orderExportBtn').disabled")
      check('cancelled save keeps prior file and valid Finder receipt',page.locator('#orderExportFilename').inner_text()==saved_path.name and saved_path.exists())
      saved_path.unlink();page.click('#revealOrderExportBtn')
      page.wait_for_function("document.getElementById('toast').textContent.includes('저장한 파일을 찾지 못했습니다')")
      check('moved or deleted export is reported without opening another file',len(finder_calls)==1)
      page.click('#openOrderExportBtn');page.wait_for_function("!document.getElementById('openOrderExportBtn').disabled")
      check('Open rejects deleted saved file without another launch',len(file_open_calls)==1 and '저장한 파일을 찾지 못했습니다' in page.locator('#toast').inner_text())
      page.click('#dismissOrderExportBtn');check('save receipt can be dismissed',page.locator('#orderExportResult').is_hidden())
      check('exporting mobile numbers does not alter notice recipients or business data',store.read()==before_mobile_export)
      # v0.6.25: remembered channel selection + real selected-only full snapshot.
      server.desktop=False;engine.configure_shop({'shopName':'메이아워'})
      engine.import_rows({'rows':[order(901,product='유지할 지그재그 상품')|{'seller':SELLERS[2]}]})
      keep=copy.deepcopy(next(r for r in store.read()['rows'] if r['orderId']=='TEST-901'))
      scoped_page=start_page();scoped_page.set_viewport_size({'width':1540,'height':1800})
      scoped_page.wait_for_function("document.getElementById('shopBrandName').textContent==='메이아워'")
      sample=('판매처,주문번호,상품명,옵션명,주문수량,주문자휴대폰\n'
              '메이아워 에이블리,SCOPE-1,안내 대상 니트,블랙,1,01000000000\n'
              '메이아워 자사몰,SCOPE-2,선택 제외,화이트,1,01000000000\n'
              '메이아워 지그재그,SCOPE-3,선택 제외,화이트,1,01000000000\n'
              '앤로랑 에이블리,SCOPE-4,다른 쇼핑몰,화이트,1,01000000000\n'
              '누아브 에이블리,SCOPE-5,다른 쇼핑몰,화이트,1,01000000000\n').encode()
      upload={'name':'전체판매처_미출고.csv','mimeType':'text/csv','buffer':sample}
      scoped_page.locator('#fileInput').set_input_files(upload)
      scoped_page.wait_for_selector('#importDialog[open]')
      check('mixed-shop file filters other named stores including legacy NUAVU', '반영 대상 3개 상품' in scoped_page.locator('#importSummary').inner_text() and '앤로랑' in scoped_page.locator('#importSummary').inner_text())
      scoped_page.locator('#scopeChecks input').nth(1).uncheck();scoped_page.locator('#scopeChecks input').nth(2).uncheck()
      scoped_page.wait_for_function("document.getElementById('scopeSaveState').textContent.includes('저장됨')")
      check('unchecked channels immediately disappear from preview','반영 대상 1개 상품' in scoped_page.locator('#importSummary').inner_text())
      check('persisted channel choices are labeled with current shop', '메이아워 에이블리' in scoped_page.locator('#scopeChecks').inner_text() and store.read()['settings']['importSellerChoices']['메이아워']=={'메이아워에이블리':True,'메이아워자사몰':False,'메이아워지그재그':False})
      scoped_page.locator('[data-map=buyer]').select_option('-1')
      check('column remapping does not reset selected channels',scoped_page.locator('#scopeChecks input:checked').count()==1)
      scoped_page.click('[data-close=importDialog]');scoped_page.locator('#fileInput').set_input_files(upload)
      check('reopening workbook restores channel selection but requires fresh consent',scoped_page.locator('#scopeChecks input:checked').count()==1 and not scoped_page.locator('#replaceConfirmed').is_checked())
      scoped_page.locator('#importDialog').screenshot(path=str(out/'18_판매처선택_저장.png'))
      scoped_page.locator('#replaceConfirmed').check();scoped_page.click('#applyImportBtn')
      scoped_page.wait_for_function("!document.getElementById('importDialog').open")
      check('actual snapshot imports only selected store channel',any(r['orderId']=='SCOPE-1' for r in store.read()['rows']) and not any(r['orderId'] in {'SCOPE-2','SCOPE-3','SCOPE-4','SCOPE-5'} for r in store.read()['rows']))
      check('unchecked existing order remains byte-for-byte unchanged',next(r for r in store.read()['rows'] if r['orderId']=='TEST-901')==keep)
      scoped_page.close();scoped_page=start_page();scoped_page.set_viewport_size({'width':1540,'height':1800})
      scoped_page.wait_for_function("document.getElementById('shopBrandName').textContent==='메이아워'")
      scoped_page.locator('#fileInput').set_input_files(upload)
      check('new app page restores remembered scope',scoped_page.locator('#scopeChecks input:checked').count()==1)
      scoped_page.locator('#scopeChecks input').nth(0).uncheck()
      scoped_page.wait_for_function("document.getElementById('scopeSaveState').textContent.includes('저장됨')")
      check('empty choice is retained and import remains disabled',not any(store.read()['settings']['importSellerChoices']['메이아워'].values()) and scoped_page.locator('#applyImportBtn').is_disabled())
      scoped_page.click('[data-close=importDialog]');scoped_page.locator('#fileInput').set_input_files(upload)
      check('empty selection does not become select-all on reopen',scoped_page.locator('#scopeChecks input:checked').count()==0)
      scoped_page.click('[data-close=importDialog]');scoped_page.click('#historySeedBtn');scoped_page.click('#ablyLegacyImport')
      check('external notice explicitly requires manually entered promised date','엑셀에서 에이블리의 배송지연 안내 날짜를 가져올 수 없습니다' in scoped_page.locator('#externalDialog').inner_text())
      scoped_page.locator('#externalDialog').screenshot(path=str(out/'19_에이블리_수동날짜안내.png'))
      scoped_page.close()
      # v0.6.25: exact source names from column I, reverse shop name and additional channels.
      engine.configure_shop({'shopName':'멜릿'})
      dynamic=start_page();dynamic.set_viewport_size({'width':1540,'height':1800})
      dynamic.wait_for_function("document.getElementById('shopBrandName').textContent==='멜릿'")
      def excel_sellers(labels):
          h=['주문번호','상품명','옵션명','주문수량','주문자휴대폰','기타1','기타2','기타3','판매처']
          lines=[h]+[[f"DYNAMIC-{'MELLIT' if '멜릿' in label else 'MAYHOUR' if '메이아워' in label else 'OTHER'}-{i}",f'예시 상품 {i}','블랙',1,'01000000000','','','',label] for i,label in enumerate(labels)]
          return {'name':'확장주문검색_판매처예시.xlsx','mimeType':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','buffer':xlsx([('Worksheet',lines)])}
      def open_sellers(labels):
          dynamic.locator('#fileInput').set_input_files(excel_sellers(labels))
          dynamic.wait_for_selector('#importDialog[open]')
          dynamic.wait_for_function("document.getElementById('scopeSaveState').textContent.includes('저장됨') && !importScopeSaving")
      def choices():return dynamic.locator('#scopeChecks label').all_text_contents()
      open_sellers(['에이블리 멜릿','앤로랑 에이블리'])
      check('column I discovers only actual Mellit seller with reversed shop name',choices()==['에이블리 멜릿'])
      check('absent Mellit own-site and Zigzag have no checkboxes',dynamic.locator('#scopeChecks input').count()==1)
      dynamic.locator('#importDialog').screenshot(path=str(out/'20_엑셀판매처_멜릿.png'))
      dynamic.locator('#replaceConfirmed').check();dynamic.click('#applyImportBtn')
      dynamic.wait_for_function("!document.getElementById('importDialog').open")
      check('reversed Ably source imports with original label',any(r.get('sourceSeller')=='에이블리 멜릿' and r['seller']==SELLERS[0] for r in store.read()['rows']))
      dynamic.close();engine.configure_shop({'shopName':'메이아워'})
      dynamic=start_page();dynamic.set_viewport_size({'width':1540,'height':1800})
      dynamic.wait_for_function("document.getElementById('shopBrandName').textContent==='메이아워'")
      open_sellers(['메이아워 에이블리','메이아워 아무드','앤로랑 아무드'])
      check('Mayhour displays exactly Ably and Amood source names',choices()==['메이아워 에이블리','메이아워 아무드'])
      dynamic.locator('#scopeChecks input').nth(0).check()
      dynamic.wait_for_function("!importScopeSaving")
      check('Amood is imported as an independent seller in preview','메이아워 아무드 1개' in dynamic.locator('#importSummary').inner_text())
      dynamic.locator('#importDialog').screenshot(path=str(out/'21_엑셀판매처_메이아워.png'))
      dynamic.locator('#scopeBox').screenshot(path=str(out/'22_엑셀판매처_체크.png'))
      dynamic.locator('#replaceConfirmed').check();dynamic.click('#applyImportBtn')
      dynamic.wait_for_function("!document.getElementById('importDialog').open")
      check('Amood source survives server import and has a main filter',any(r.get('sourceSeller')=='메이아워 아무드' for r in store.read()['rows']) and '메이아워 아무드' in dynamic.locator('#sellerTabs').inner_text())
      open_sellers(['메이아워 에이블리','메이아워 아무드'])
      dynamic.locator('#scopeChecks input').nth(1).uncheck();dynamic.wait_for_function("!importScopeSaving")
      dynamic.click('[data-close=importDialog]');open_sellers(['메이아워 에이블리'])
      check('seller absent in next file is hidden even when remembered',choices()==['메이아워 에이블리'])
      dynamic.click('[data-close=importDialog]');open_sellers(['메이아워 에이블리','메이아워 아무드'])
      check('returning Amood seller retains unchecked state',not dynamic.locator('#scopeChecks input').nth(1).is_checked())
      dynamic.locator('[data-map=seller]').select_option('5')
      dynamic.wait_for_function("!importScopeSaving")
      check('seller remapping recalculates choices and blocks empty import',dynamic.locator('#scopeChecks input').count()==0 and dynamic.locator('#applyImportBtn').is_disabled())
      dynamic.locator('[data-map=seller]').select_option('8');dynamic.wait_for_function("!importScopeSaving")
      check('restoring I column restores saved labels and checks',choices()==['메이아워 에이블리','메이아워 아무드'] and dynamic.locator('#scopeChecks input:checked').count()==1)
      dynamic.close();dynamic=start_page();dynamic.set_viewport_size({'width':1540,'height':1800})
      dynamic.wait_for_function("document.getElementById('shopBrandName').textContent==='메이아워'")
      open_sellers(['메이아워 아무드'])
      check('relaunch shows only present seller with its unchecked preference',choices()==['메이아워 아무드'] and dynamic.locator('#scopeChecks input:checked').count()==0)
      dynamic.close()
      check('no outgoing send calls in UI test' ,not sms.sent and not at.sent)
      check('no external browser requests',not external)
      check('no JS errors',not errors)
      check('no CSP/console errors',not console_errors)
      check('authenticated APIs respond',any('/api/shop-settings' in u for m,u in requests) and any('/api/view-settings' in u for m,u in requests))
      browser.close()
    finally:
      server.shutdown();server.server_close();store.close()
    report={'checks':checks,'passed':len(checks),'live_messages_sent':0,'scope':'Chromium injected local assets with strict nonce test CSP; actual authenticated local API via Python bridge; not macOS WKWebView/native navigation or live Aligo'}
    (ROOT/'docs/browser_qa.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':run()
