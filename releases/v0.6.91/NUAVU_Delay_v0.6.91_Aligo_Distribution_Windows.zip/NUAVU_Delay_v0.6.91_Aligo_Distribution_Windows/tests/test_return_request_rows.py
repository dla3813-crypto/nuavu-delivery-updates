"""Screen request counts and spreadsheet product rows are different units."""
import copy,datetime as dt,unittest
from return_data import HEADERS,ReturnError,read_returns,make_snapshot,verify_return_count
from return_check import ReturnController,KST
from workbook_reader import read_xlsx
from test_returns import xlsx,TODAY,track
from helpers import Base,MemoryVault

HEADS=list(HEADERS.values())+['반품 접수번호','상품주문번호','수량']

def products(count=27,extra=False):
    rows=[['2026-10-10','가상 고객','구매자','510000000001',0,'ORDER'+str(i),
           '가상 상품','RETURN'+str(i),'ITEM'+str(i),1] for i in range(count)]
    if extra:
        r=list(rows[0]);r[6]='같은 반품의 다른 상품';r[-2]='ITEM_EXTRA';r[-1]=2;rows.append(r)
    return rows

def snapshot(rows,total=27):
    entries=read_returns(xlsx(rows,HEADS),total,TODAY)
    return make_snapshot(entries,{'510000000001':track()},total,TODAY)

class ReturnRequestRowsTests(unittest.TestCase):
    def test_physical_28_rows_means_header_plus_27_products(self):
        raw=xlsx(products(),HEADS)
        self.assertEqual(len(read_xlsx(raw)[0]['rows']),28)
        entries=read_returns(raw,27,TODAY)
        self.assertEqual(len(entries),27)
        self.assertEqual(entries[0]['requestId'],'RETURN0')

    def test_27_requests_28_products_all_retained_quantity_not_a_request(self):
        out=snapshot(products(extra=True))
        self.assertTrue(out['complete']);self.assertEqual(out['requestTotal'],27)
        self.assertEqual(out['total'],28);self.assertEqual(len(out['rows']),28)
        self.assertEqual(sum(int(r['qty']) for r in out['rows']),29)

    def test_blank_rows_do_not_count_or_drop_final_product(self):
        rows=products();rows.insert(5,[]);rows.extend([[],['']*len(HEADS)])
        out=snapshot(rows)
        self.assertEqual(out['total'],27);self.assertEqual(out['rows'][-1]['requestId'],'RETURN26')

    def test_missing_request_rejected_even_with_27_product_rows(self):
        rows=products(26,extra=True)
        with self.assertRaisesRegex(ReturnError,'반품 접수 26건.*상품 27개'):snapshot(rows)

    def test_extra_request_rejected(self):
        with self.assertRaisesRegex(ReturnError,'반품 접수 28건.*상품 28개'):snapshot(products(28))

    def test_blank_request_id_cannot_fall_back_to_product_count(self):
        for which in ('one','all'):
            rows=products()
            for row in rows if which=='all' else rows[:1]:row[7]=''
            with self.subTest(which=which),self.assertRaisesRegex(ReturnError,'접수번호가 빠진'):snapshot(rows)

    def test_duplicate_request_header_is_not_silently_ignored(self):
        rows=[r+['OTHER'] for r in products()]
        with self.assertRaisesRegex(ReturnError,'접수번호 열이 중복'):
            read_returns(xlsx(rows,HEADS+['반품 접수번호']),27,TODAY)

    def test_same_order_distinct_return_requests_are_separate(self):
        rows=products(2);rows[1]=list(rows[0]);rows[1][7]='RETURN1'
        out=snapshot(rows,2)
        self.assertEqual(out['total'],2);self.assertEqual(len({r['key'] for r in out['rows']}),2)

    def test_exact_duplicate_product_in_same_request_still_rejected(self):
        rows=products(1);rows.append(list(rows[0]))
        with self.assertRaisesRegex(ReturnError,'중복 상품 행'):snapshot(rows,1)

    def test_inconsistent_order_or_date_in_same_request_rejected(self):
        for field,value in [(5,'OTHER_ORDER'),(0,'2026-10-11')]:
            rows=products(1,extra=True);rows[-1][field]=value
            with self.subTest(field=field),self.assertRaisesRegex(ReturnError,'주문번호·요청일이 달라'):snapshot(rows,1)

    def test_legacy_without_request_column_needs_exact_product_count(self):
        rows=[r[:7] for r in products()]
        self.assertEqual(len(read_returns(xlsx(rows),27,TODAY)),27)
        with self.assertRaisesRegex(ReturnError,'제목 행 제외.*접수번호 열이 없어'):
            read_returns(xlsx(rows+[products(28)[-1][:7]]),27,TODAY)

    def test_snapshot_revalidates_request_count_and_bounds(self):
        entries=read_returns(xlsx(products(extra=True),HEADS),27,TODAY)
        with self.assertRaises(ReturnError):make_snapshot(entries,{},28,TODAY)
        entries[0].pop('requestId')
        with self.assertRaisesRegex(ReturnError,'접수번호가 빠진'):verify_return_count(entries,27)
        for total in (True,-1,20001,'27'):
            with self.subTest(total=total),self.assertRaises(ReturnError):verify_return_count([],total)

    def test_header_only_zero_is_valid(self):
        self.assertEqual(snapshot([],0)['total'],0)

class ReturnRequestCommitTests(Base):
    def test_all_products_committed_and_bad_count_preserves_snapshot(self):
        vault=MemoryVault();vault.save(dict(version=1,username='test-only',password='synthetic-only'))
        c=ReturnController(self.engine,runner=lambda a,c:snapshot(products(extra=True)),vault=vault,
                           clock=lambda:dt.datetime(2026,10,18,12,0,tzinfo=KST))
        before=copy.deepcopy(self.store.read())
        try:
            c.start();c.thread.join(3);self.assertFalse(c.running())
            self.assertEqual(c.status()['phase'],'done')
            self.assertEqual(c.status()['data']['counts']['total'],28)
            saved=copy.deepcopy(self.store.read()['returnCheck'])
            for key in ('rows','notices','settings','imports'):self.assertEqual(self.store.read()[key],before[key])
            c.runner=lambda a,c:snapshot(products(26,extra=True))
            c.start();c.thread.join(3);self.assertFalse(c.running())
            self.assertEqual(c.status()['phase'],'error')
            self.assertEqual(self.store.read()['returnCheck'],saved)
            self.assertEqual(len(self.fake.sent),0)
        finally:
            c.shutdown()
            if c.thread:c.thread.join(3)
