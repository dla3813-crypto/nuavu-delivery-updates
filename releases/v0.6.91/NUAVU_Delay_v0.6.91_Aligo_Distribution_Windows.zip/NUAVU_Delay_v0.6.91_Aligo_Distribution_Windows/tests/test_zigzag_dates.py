"""2026-10-23 지그재그 배송연기 안내: 날짜 규칙 (사장님 예시 + 파트너센터 실측), 막힌 주문 건너뛰고 계속, 발송 예정일 미리 표시."""
import os,shutil,sys,unittest
from datetime import date
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import zigzag_rules as zr
import zigzag_browser as zb

class RuleTests(unittest.TestCase):
    def test_send_deadline_examples_from_owner(self):
        # 10/19→10/22, 10/20→10/23, 10/21(주말 낌)→10/26; 실측 10/22→10/27, 10/17(토)·10/18(일)→10/21
        for od,sb in [('2026-10-19','2026-10-22'),('2026-10-20','2026-10-23'),('2026-10-21','2026-10-26'),('2026-10-22','2026-10-27'),('2026-10-17','2026-10-21'),('2026-10-18','2026-10-21')]:
            self.assertEqual(zr.ship_by(date.fromisoformat(od)).isoformat(),sb,od)
    def test_calendar_range_measured_on_partner_center(self):
        w=zr.window('2026.10.22 17:09:28','2026-10-23')
        self.assertEqual((w['min'],w['max'],w['open']),('2026-10-28','2026-11-05',True))
        self.assertEqual(w['allowed'],['2026-10-28','2026-10-29','2026-10-30','2026-11-02','2026-11-03','2026-11-04','2026-11-05'])
    def test_deadline_passed(self):
        w=zr.window('2026-10-19','2026-10-23');self.assertFalse(w['open']);self.assertEqual(w['shipBy'],'2026-10-22')
        self.assertTrue(zr.window('2026-10-19','2026-10-22')['open'])   # 발송 예정일 당일 23:59까지 가능
    def test_holidays_are_skipped_and_listed(self):
        # 2026-09-24~26 추석, 10/3 개천절(토)·10/5 대체, 10/9 한글날
        self.assertEqual(zr.ship_by(date(2026,9,23)).isoformat(),'2026-09-30')
        w=zr.window('2026-10-06','2026-10-06');self.assertEqual(w['shipBy'],'2026-10-12');self.assertIn('2026-10-09',w['holidays'])
        self.assertNotIn('2026-10-09',w['allowed'])
        self.assertEqual(zb.business_days_after(date(2026,10,8),2),[date(2026,10,12),date(2026,10,13)])
    def test_unknown_year_flag(self):self.assertFalse(zr.window('2026-12-30','2026-12-30')['calendarKnown'])
    def test_combined_and_check(self):
        s={'notices':[],'zigzagPushLog':[]}
        rows=[{'key':'a','seller':zr.ZIGZAG,'orderDate':'2026-10-22','orderId':'1'},{'key':'b','seller':zr.ZIGZAG,'orderDate':'2026-10-21','orderId':'2'},
              {'key':'c','seller':zr.ZIGZAG,'orderDate':'2026-10-19','orderId':'3'},{'key':'d','seller':'누아브 에이블리','orderDate':'2026-10-01'}]
        c=zr.combined(s,rows,'2026-10-23')
        self.assertEqual((c['open'],c['min'],c['max']),(2,'2026-10-28','2026-11-04'))  # 10/21: 10/27~11/4, 10/22: 10/28~11/5
        self.assertEqual([x['key'] for x in c['closed']],['c'])
        self.assertEqual(zr.check_due(s,rows,'2026-10-30','2026-10-23'),'')
        self.assertIn('2026-10-28 ~ 2026-11-04',zr.check_due(s,rows,'2026-11-05','2026-10-23'))
        self.assertIn('평일',zr.check_due(s,rows,'2026-10-31','2026-10-23'))
        self.assertEqual(zr.check_due(s,rows[2:],'2027-01-30','2026-10-23'),'')   # 마감 지난 주문만: 제한 없음
        s['zigzagPushLog']=[{'key':'a','status':'sent'}];self.assertEqual(zr.combined(s,rows,'2026-10-23')['open'],1)

class PlanTests(unittest.TestCase):
    def test_past_ship_by_is_rule_without_browser(self):
        from unittest.mock import patch
        import zigzag_sync as zs
        item={'itemId':'185479854659016197','orderId':'1','shipByDate':'2026-10-22','changedDate':'','currentDate':'2026-10-22'}
        row={'key':'k','seller':zs.ZIGZAG,'active':True,'orderItemId':'185479854659016197','orderId':'1'}
        with patch('ably_sync.app_delay_notice',lambda s,k:{'id':'n','dueDate':'2026-10-28'}):
            t,sk=zs.plan_pushes({'rows':[row],'notices':[]},[item],['k'],'2026-10-23')
            self.assertEqual(t,[]);self.assertTrue(sk[0]['quiet']);self.assertIn('발송 예정일(2026-10-22)이 지나',sk[0]['reason'])
            t,sk=zs.plan_pushes({'rows':[row],'notices':[]},[item],['k'],'2026-10-22')
            self.assertEqual([x['sendDate'] for x in t],['2026-10-28'])

PAGE='''<!doctype html><html><body><div>배송준비중 목록 (3건)</div>
<table><thead><tr><th></th><th>상품주문번호</th><th>주문번호</th><th>발송 예정일</th><th>변경 발송 예정일</th><th>주문상태</th><th>상품명</th><th>옵션정보</th><th>수량</th><th>수령인명</th><th>자체상품코드</th><th>주문일시</th></tr></thead><tbody>
<tr><td><input type="checkbox"></td><td>185479854659016197</td><td>o1</td><td>2026.10.22 23:59:59 (3 영업일)</td><td class="chg">-</td><td>배송준비중</td><td>A</td><td>-</td><td>1</td><td>x</td><td></td><td>2026.10.19</td></tr>
<tr><td><input type="checkbox"></td><td>185484072300690916</td><td>o2</td><td>2026.10.27 23:59:59 (3 영업일)</td><td class="chg">-</td><td>배송준비중</td><td>B</td><td>-</td><td>1</td><td>x</td><td></td><td>2026.10.22</td></tr>
<tr><td><input type="checkbox"></td><td>185484072300690999</td><td>o3</td><td>2026.10.27 23:59:59 (3 영업일)</td><td class="chg">-</td><td>배송준비중</td><td>C</td><td>-</td><td>1</td><td>x</td><td></td><td>2026.10.22</td></tr>
</tbody></table>
<ul><li><button type="button" aria-label="1 페이지" aria-current="page">1</button></li></ul>
<button type="button" id="open" disabled>배송연기 안내</button><div id="host"></div>
<script>
window.sent=[];const OVERDUE=new Set(['185479854659016197']);
document.addEventListener('change',()=>{const c=[...document.querySelectorAll('tbody input:checked')];document.getElementById('open').disabled=!(c.length===1&&!OVERDUE.has(c[0].closest('tr').children[1].textContent));});
document.getElementById('open').onclick=()=>{const c=[...document.querySelectorAll('tbody input:checked')];const row=c[0].closest('tr');const item=row.children[1].textContent;
 const host=document.getElementById('host');host.innerHTML=`<div class="pds-modal-wrapper"><p>변경 발송 예정일</p><input class="pds-input" placeholder="날짜를 선택하세요." value=""><div id="cal"></div><div role="combobox">배송연기사유 선택</div><p>상세사유</p><textarea></textarea><button type="button" id="cancel">취소</button><button type="button" id="submit" disabled>배송연기 안내</button></div><ul id="opts"></ul>`;
 const m=host.firstChild,input=m.querySelector('input'),ta=m.querySelector('textarea'),combo=m.querySelector('[role=combobox]'),submit=m.querySelector('#submit');let reason='';
 const refresh=()=>{submit.disabled=!(reason&&ta.value&&input.value);};
 combo.onclick=()=>{const ul=document.getElementById('opts');ul.innerHTML='<li role="option">상품 입고 지연</li>';ul.firstChild.onclick=()=>{reason='상품 입고 지연';combo.textContent=reason;ul.innerHTML='';refresh();};};
 ta.oninput=refresh;
 input.onclick=()=>{m.querySelector('#cal').innerHTML='<div class="rdp-month"><span>2026년 10월</span>'+[27,28,29,30].map(d=>'<button class="rdp-day'+(d<28?' rdp-day_disabled':'')+'">'+d+'</button>').join('')+'</div>';m.querySelectorAll('.rdp-day').forEach(b=>b.onclick=()=>{if(b.className.includes('disabled'))return;input.value='2026.10.'+b.textContent;m.querySelector('#cal').innerHTML='';refresh();});};
 m.querySelector('#cancel').onclick=()=>{host.innerHTML='';};
 submit.onclick=()=>{window.sent.push(item);if(item==='185484072300690916'){return;}row.querySelector('.chg').textContent=input.value+' 23:59:59';c[0].checked=false;host.innerHTML='';};
};
</script></body></html>'''

class FakeStop:
    def is_set(self):return False

class PushLoopTests(unittest.TestCase):
    def test_blocked_orders_do_not_stop_the_rest(self):
        """111: 버튼 꺼짐(발송 예정일 지남) → 보류, 222: 전송 클릭 뒤 창이 안 닫힘 → 실패(재전송 없음), 333: 정상 전송."""
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            b=pw.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or '/opt/pw-browsers/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
            try:
                page=b.new_page();page.set_content(PAGE)
                r=zb.Reader(page,FakeStop(),lambda m:None)
                orig=r.wait
                def fast(pred,msg,seconds=30):return orig(pred,msg,min(seconds,3))
                r.wait=fast
                t=lambda i,d:{'itemId':i,'sendDate':d,'orderId':'o','key':'k'+i,'dueDate':d,'noticeId':'n','zigzagDate':'','adjusted':''}
                out=r.push([t('185479854659016197','2026-10-28'),t('185484072300690916','2026-10-28'),t('185484072300690999','2026-10-29')],{'185479854659016197':1,'185484072300690916':1,'185484072300690999':1})
                self.assertEqual([(p['itemId'],p['status']) for p in out],[('185479854659016197','skipped'),('185484072300690916','failed'),('185484072300690999','sent')],[p['reason'] for p in out])
                self.assertIn('버튼이 꺼져',out[0]['reason']);self.assertIn('다시 보내지 않았습니다',out[1]['reason'])
                self.assertEqual(page.evaluate('window.sent'),['185484072300690916','185484072300690999'])   # 222 clicked once only
            finally:b.close()

try:
    from test_v056 import Base
except ImportError:
    from helpers import Base
try:
    from test_v068 import order
except ImportError:
    from test_supply_regression import order

class AppTests(Base):
    def setUp(self):
        super().setUp()
        with self.store.edit() as s:s['rows']=[]
        self.engine.import_rows({'rows':[order(1)|{'orderId':'139780000000000001','orderItemId':'185484072300690916','seller':zr.ZIGZAG,'orderDate':'2026-10-22'},
                                         order(2)|{'orderId':'139780000000000002','seller':zr.ZIGZAG,'orderDate':'2026-10-19'},
                                         order(3)|{'orderId':'12345','orderItemId':'801','seller':'누아브 에이블리','orderDate':'2026-10-22'}]})
    def rows(self):
        from unittest.mock import patch
        with patch('domain.today',lambda:'2026-10-23'):return {r['orderId']:r for r in self.engine.public_state()['rows']}
    def test_ship_by_shown_from_import_then_replaced(self):
        r=self.rows()
        a=r['139780000000000001'];self.assertEqual((a['dueDate'],a['color'],a['bucket']),('2026-10-27','white','unnotified'));self.assertTrue(a['zigzagDefaultDue'])
        self.assertTrue(a['zigzagWindow']['open']);self.assertIn(a['dueDateSource'],('지그재그 발송 예정일 · 메시지 없는 안내 (주문 수집 시 자동)','zigzag_default'))
        b=r['139780000000000002'];self.assertEqual((b['dueDate'],b['color']),('2026-10-22','white'));self.assertFalse(b['zigzagWindow']['open'])
        self.assertEqual(r['12345']['dueDate'],'');self.assertIsNone(r['12345']['zigzagWindow'])
        self.engine.external_manual({'keys':[a['key']],'dueDate':'2026-10-30'})
        a=self.rows()['139780000000000001'];self.assertEqual(a['dueDate'],'2026-10-30');self.assertFalse(a['zigzagDefaultDue'])
    def test_dialog_rejects_dates_zigzag_cannot_pick(self):
        from unittest.mock import patch
        import secrets
        a=self.rows()['139780000000000001']
        with patch('domain.today',lambda:'2026-10-23'):
            with self.assertRaises(Exception) as cm:self.engine.external_manual({'keys':[a['key']],'dueDate':'2026-11-06','mode':'set_due_date','requestId':secrets.token_urlsafe(18)})
            self.assertIn('2026-10-28 ~ 2026-11-05',str(cm.exception))
            self.engine.external_manual({'keys':[a['key']],'dueDate':'2026-11-05','mode':'set_due_date','requestId':secrets.token_urlsafe(18)})

if __name__=='__main__':unittest.main()
