"""2026-10-20 08:42 요청: 배포판 Windows 버전 — DPAPI 보호 저장소, 실행 잠금, 경로, 자동 플랫폼 선택. (Linux에서 가짜 crypt32로 검증)"""
import os,sys,tempfile,unittest
from pathlib import Path
import platform_support as ps
from windows_credentials import WindowsDpapiVault,platform_vault
from credentials import VaultError,UnavailableVault,MacKeychain

class FakeCrypt:
    """Reversible stand-in for CryptProtectData/CryptUnprotectData: prefix + xor."""
    def __init__(self):self.descriptions=[]
    def protect(self,raw,description):self.descriptions.append(description.value if hasattr(description,'value') else description);return b'DPAPI1'+bytes(b^0x5A for b in raw)
    def unprotect(self,blob):
        if not blob.startswith(b'DPAPI1'):raise OSError(13)
        return bytes(b^0x5A for b in blob[6:])

class DpapiVault(unittest.TestCase):
    def test_roundtrip_delete_and_errors(self):
        with tempfile.TemporaryDirectory() as d:
            v=WindowsDpapiVault(d,'kr.nuavu.test','테스트 계정',api=FakeCrypt())
            self.assertIsNone(v.load())
            v.save({'version':1,'username':'u','password':'p'})
            self.assertTrue(v.path.is_file());raw=v.path.read_bytes();self.assertNotIn(b'"password"',raw);self.assertNotIn(b'p',raw[6:7]*0+b'')   # encrypted blob, no plaintext json
            self.assertNotIn(b'username',raw)
            self.assertEqual(v.load(),{'version':1,'username':'u','password':'p'})
            self.assertEqual(v._api.descriptions,['테스트 계정'])
            # a second service in the same directory gets its own file
            w=WindowsDpapiVault(d,'kr.nuavu.other','다른 계정',api=FakeCrypt());self.assertNotEqual(v.path,w.path);self.assertIsNone(w.load())
            v.path.write_bytes(b'garbage')
            with self.assertRaises(VaultError):v.load()
            v.delete();self.assertFalse(v.path.exists());v.delete()
            with self.assertRaises(VaultError):v.save({'version':1,'x':'y'*20000})
    def test_platform_vault_selection(self):
        with tempfile.TemporaryDirectory() as d:
            picked=platform_vault(d,'svc','라벨',MacKeychain)
            if sys.platform=='darwin':self.assertIsInstance(picked,MacKeychain)
            elif sys.platform=='win32':self.assertIsInstance(picked,WindowsDpapiVault)
            else:self.assertIsInstance(picked,UnavailableVault)
            self.assertIsInstance(platform_vault(d,'svc','라벨',MacKeychain,api=FakeCrypt()),WindowsDpapiVault)
    def test_every_account_module_uses_platform_vault(self):
        import inspect,credentials,aligo_credentials,ezadmin_credentials,ably_credentials,zigzag_credentials,cafe24_credentials,factory_reset
        for m in (credentials,aligo_credentials,ezadmin_credentials,ably_credentials,zigzag_credentials,cafe24_credentials,factory_reset):
            self.assertIn('platform_vault',inspect.getsource(m),m.__name__)
            self.assertNotIn("if sys.platform=='darwin' else UnavailableVault()",inspect.getsource(m),m.__name__)

class Lock(unittest.TestCase):
    def test_process_lock_exclusive(self):
        with tempfile.TemporaryDirectory() as d:
            a=ps.ProcessLock(d);self.assertTrue(a.acquire())
            b=ps.ProcessLock(d);self.assertFalse(b.acquire())
            a.release();self.assertTrue(b.acquire());b.release()

class Paths(unittest.TestCase):
    def test_data_dir_by_platform(self):
        d=ps.data_dir()
        if sys.platform=='darwin':self.assertTrue(str(d).endswith('Library/Application Support/NUAVU Delay Distribution'))
        elif sys.platform=='win32':self.assertTrue(str(d).endswith('NUAVU Delay Distribution'));self.assertIn('AppData',str(d))
        else:self.assertTrue(str(d).endswith('.local/share/nuavu-delay-distribution'))
        ps.sync_directory(tempfile.gettempdir())   # never raises on the current platform
    def test_windows_files_present(self):
        root=Path(__file__).resolve().parents[1]
        for n in ('처음한번_앱설치.bat','배송안내_실행.bat','문제확인용_웹실행.bat','문제확인용_앱창실행.bat','windows/install.ps1','windows/run.ps1','windows/web.ps1','windows/desktop_console.ps1','먼저읽기_윈도우.txt','assets/CS-Pink.ico'):
            self.assertTrue((root/n).is_file(),n)
        for n in ('처음한번_앱설치.bat','배송안내_실행.bat','문제확인용_웹실행.bat'):(root/n).read_bytes().decode('ascii')   # cmd-safe
        for n in ('windows/install.ps1','windows/run.ps1','windows/web.ps1'):self.assertTrue((root/n).read_bytes().startswith(b'\xef\xbb\xbf'),n)   # UTF-8 BOM for PowerShell
        src=(root/'windows/install.ps1').read_text(encoding='utf-8')
        for must in ('pywebview==6.2.1','playwright==1.64.0','certifi','tzdata','desktop-runtime-win','WScript.Shell','pythonw.exe','WebView2'):self.assertIn(must,src)
        for n in ('install.ps1','run.ps1','web.ps1','desktop_console.ps1'):   # scripts live in windows\ → the app root is one level up (10:09 보고)
            self.assertIn('Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)',(root/'windows'/n).read_text(encoding='utf-8'),n)
if __name__=='__main__':unittest.main()
