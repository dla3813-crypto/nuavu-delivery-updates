"""2026-10-21: 다운로드 신청 캡차 → 창 보이게 + 알림, 사람이 캡차·신청 후 '다운로드 완료' → BL30에서 받아 반영."""
import sys,tempfile,threading,unittest
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT)]
import browser_window,order_browser as ob
from order_auto import OrderAutoController,OrderAutoError,KST
from domain import Store

class ControllerTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(Path(self.tmp.name)/'data')
        self.c=OrderAutoController(self.store);self.gate=threading.Event()
        self.c.thread=threading.Thread(target=self.gate.wait,daemon=True);self.c.thread.start();self.c.job={'id':'J1','phase':'running','message':''}
    def tearDown(self):
        self.gate.set();self.c.thread.join(2);self.store.close();self.tmp.cleanup()
    def test_downloaded_only_while_captcha(self):
        with self.assertRaises(OrderAutoError):self.c.request_browser_action('J1','downloaded')
        self.c.captcha_wait('캡차 부탁')
        st=self.c.status();self.assertTrue(st['captchaWait']);self.assertEqual(st['phase'],'error_open');self.assertTrue(st['browserRecovery']);self.assertFalse(st['browserCanContinue'])
        with self.assertRaises(OrderAutoError):self.c.request_browser_action('J1','continue')
        self.c.request_browser_action('J1','downloaded')
        self.assertEqual(self.c.take_browser_action(),('downloaded',''))
        self.c.end_browser_recovery();self.assertFalse(self.c.status()['captchaWait'])

class FlowTests(unittest.TestCase):
    def test_captcha_download_waits_for_person_then_fetches(self):
        alerts=[];calls=[]
        commands=iter([None,None,('downloaded','')])
        c=SimpleNamespace(alert=lambda *a:alerts.append(a),captcha_wait=lambda m:calls.append(('wait',m)),
                          take_browser_action=lambda:next(commands),end_browser_recovery=lambda:calls.append('end'),update=lambda *a:None)
        page=SimpleNamespace(is_closed=lambda:False,wait_for_timeout=lambda ms:None)
        ctx=SimpleNamespace(on=lambda *a:None,remove_listener=lambda *a:None,pages=[page])
        f=ob.Flow.__new__(ob.Flow);f.c=c;f.context=ctx;f.page=None;f.step='';f.export_acknowledged=False;f.export_accepted=False
        f.close_extra_pages=lambda:None;started=datetime.now(KST)
        f.fetch_requested=lambda s,a,cfg:(calls.append(('fetch',s,a)) or ('확장주문검색_x.xls',b'data'))
        self.assertEqual(f.captcha_download(page,started,{'folder':'x'}),('확장주문검색_x.xls',b'data'))
        self.assertEqual(alerts[0][0],'이지어드민 캡차 인증 부탁드립니다');self.assertEqual(alerts[0][2],'error')
        self.assertIn('다운로드 완료',alerts[0][1])
        self.assertTrue(f.export_acknowledged and f.export_accepted)
        fetch=[x for x in calls if isinstance(x,tuple) and x[0]=='fetch'][0];self.assertEqual(fetch[1],started);self.assertGreaterEqual(fetch[2],started)
    def test_headed_override_lifts_headless_only_inside(self):
        old=browser_window.HEADLESS
        try:
            browser_window.HEADLESS=True
            self.assertTrue(browser_window.headless());self.assertTrue(browser_window.need_person())
            with browser_window.headed():
                self.assertFalse(browser_window.headless());self.assertEqual(browser_window.need_person(),'')
            self.assertTrue(browser_window.headless())
        finally:browser_window.HEADLESS=old
    def test_source_wiring(self):
        src=(ROOT/'order_browser.py').read_text(encoding='utf-8')
        self.assertIn("if self.step!='다운로드 신청 버튼 확인':raise",src)
        self.assertIn('raise HeadedRelaunch()',src);self.assertIn('with browser_window.headed():return _run_export(controller,cfg,True)',src)
        ui=''.join((ROOT/'web'/n).read_text(encoding='utf-8') for n in ('index.html','app.js')+(('order_auto_ui.js',) if (ROOT/'web'/'order_auto_ui.js').exists() else ()))
        self.assertIn('id="captchaDoneOrderBrowser"',ui);self.assertIn("orderBrowserAction('downloaded')",ui)

if __name__=='__main__':unittest.main()
