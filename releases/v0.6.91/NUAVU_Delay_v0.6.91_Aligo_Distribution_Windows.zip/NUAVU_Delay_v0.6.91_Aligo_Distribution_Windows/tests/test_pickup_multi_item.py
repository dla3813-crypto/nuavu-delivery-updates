"""2026-10-23 19:21 보고: '확인창의 접수 건수가 1개가 아니어서 접수하지 않았습니다' — 상품 여러 개짜리 반품요청도 접수하고 알림."""
import tempfile,threading,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from ably_return_accept import request_size,dialog_count
from pickup_controller import PickupController
from domain import Store
from test_aftersales_new import NOW,row,snapshot,MemoryVault

ROWS=[{'index':0,'selectable':True,'invoice':'6082037162245'},{'index':1,'selectable':False,'invoice':''},{'index':2,'selectable':False,'invoice':''},
      {'index':3,'selectable':True,'invoice':'6082037162246'},{'index':4,'selectable':True,'invoice':'6082037162247'}]

class Helpers(unittest.TestCase):
    def test_request_size_counts_extra_item_rows(self):
        self.assertEqual(request_size(ROWS,0),3);self.assertEqual(request_size(ROWS,3),1);self.assertEqual(request_size(ROWS,4),1)
    def test_dialog_count(self):
        self.assertEqual(dialog_count('반품요청 접수\n반품요청 3개를 접수합니다.'),3);self.assertEqual(dialog_count('반품요청 1개를 접수합니다'),1);self.assertIsNone(dialog_count('다른 창'))

class ControllerAlert(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(Path(self.tmp.name)/'db')
        with self.store.edit() as s:s['settings'].update(shopName='테스트상점',shopRevision=1);s['returnCheck']=snapshot([row()])
        self.alerts=[]
        self.engine=SimpleNamespace(store=self.store,stop=threading.Event(),add_job_alert=lambda t,m,l='info':self.alerts.append((t,m,l)))
        self.report=patch('pickup_report.save_report',return_value=str(Path(self.tmp.name)/'r.xlsx'));self.report.start();self.addCleanup(self.report.stop)
    def tearDown(self):self.store.close();self.tmp.cleanup()
    def test_multi_item_request_is_accepted_and_alerted(self):
        def run(c,rows,shop,inspect):c.before_submit('610000000001');c.record({'invoice':'610000000001','result':'접수 완료'})
        ably=lambda c,targets,today:{'610000000001':{'ablyResult':'에이블리 접수 완료','ablyRequestNo':'66338855','ablyMulti':3,'ablyNote':'상품 3개 반품요청 · 검수대기 카드에서 확인'}}
        c=PickupController(self.engine,runner=run,vault=MemoryVault(),clock=lambda:NOW);c.ably_runner=ably
        try:
            c.start_pickups([row()]);c.thread.join(3)
            r=c.status()['rows'][0];self.assertEqual(r['ablyResult'],'에이블리 접수 완료');self.assertEqual(r['ablyMulti'],3)
            multi=[a for a in self.alerts if '상품 여러 개' in a[0]]
            self.assertEqual(len(multi),1);self.assertIn('회수접수는 진행되었으나, 상품이 3개입니다',multi[0][1]);self.assertEqual(multi[0][2],'error')
            self.assertFalse(any('확인 필요' in a[0] for a in self.alerts))   # 정상 접수라 '접수 확인 필요'는 아님
        finally:
            c.shutdown()
            if c.thread:c.thread.join(2)
    def test_ezadmin_item_count_alerts_even_without_ably_count(self):
        # 자사몰처럼 에이블리 단계가 없어도, 이지어드민 회수 화면의 상품 줄이 2개면 회수접수 후 알림
        def run(c,rows,shop,inspect):c.before_submit('610000000001');c.record({'invoice':'610000000001','result':'접수 완료','items':2})
        c=PickupController(self.engine,runner=run,vault=MemoryVault(),clock=lambda:NOW);c.ably_runner=lambda *a:{'610000000001':{'ablyResult':'에이블리 접수 완료'}}
        try:
            c.start_pickups([row()]);c.thread.join(3)
            multi=[a for a in self.alerts if '상품 여러 개' in a[0]];self.assertEqual(len(multi),1);self.assertIn('상품이 2개입니다',multi[0][1])
        finally:
            c.shutdown()
            if c.thread:c.thread.join(2)
    def test_single_item_no_alert(self):
        def run(c,rows,shop,inspect):c.before_submit('610000000001');c.record({'invoice':'610000000001','result':'접수 완료','items':1})
        c=PickupController(self.engine,runner=run,vault=MemoryVault(),clock=lambda:NOW);c.ably_runner=lambda *a:{'610000000001':{'ablyResult':'에이블리 접수 완료'}}
        try:
            c.start_pickups([row()]);c.thread.join(3);self.assertFalse([a for a in self.alerts if '상품 여러 개' in a[0]])
        finally:
            c.shutdown()
            if c.thread:c.thread.join(2)

if __name__=='__main__':unittest.main()
