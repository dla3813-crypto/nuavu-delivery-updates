"""2026-10-19 (공통) 반품 안내 문자: 반품 기한 초과 / 반품 불량 아님 — SMS only, 쇼핑몰 이름은 설정값, 에이블리 외 채널은 공지사항 블록 없음.
불량 아님 안내가 나간 반품은 반품/교환의 '반품 불량 아님 안내 완료' 카드로 이동한다."""
import unittest
from datetime import date
try:from test_v056 import Base
except ImportError:from helpers import Base
from test_aftersales_new import row,snapshot
from domain import ValidationError
from aftersales_data import public_aftersales
from return_messages import render_return_message,return_notice_state,LABELS,RETURN_NOTICE_TYPES

INV='610000000001'
class Templates(unittest.TestCase):
    def test_overdue_uses_shop_name_and_law(self):
        t=render_return_message('return_overdue','에이블리','누아브')
        self.assertTrue(t.startswith('안녕하세요 고객님 누아브입니다.'));self.assertIn('제17조 제1항',t);self.assertIn('철회 처리되었습니다',t);self.assertNotIn('{쇼핑몰}',t)
    def test_not_defect_ably_has_notice_block(self):
        t=render_return_message('return_not_defect','에이블리','테스트상점')
        self.assertIn('테스트상점입니다.',t);self.assertIn('공지사항',t);self.assertIn('불량이 아닌 점 안내드려요!',t);self.assertIn('귀책 사유 수정 후',t)
    def test_not_defect_other_channel_without_block(self):
        for seller in ('지그재그','자사몰',''):
            t=render_return_message('return_not_defect',seller,'테스트상점')
            self.assertNotIn('공지사항',t);self.assertNotIn('에이블리 앱',t);self.assertIn('귀책 사유 수정 후',t)
    def test_typos_fixed(self):
        for k in RETURN_NOTICE_TYPES:
            t=render_return_message(k,'에이블리','누아브')
            self.assertNotIn('제 17조',t);self.assertNotIn('처리 되었습니다',t);self.assertNotIn('첨부주신',t);self.assertNotIn('반품제품',t)
        self.assertEqual(set(LABELS),RETURN_NOTICE_TYPES)
    def test_notice_state_ignores_failed_and_test(self):
        ns=[{'returnInvoice':INV,'noticeType':'return_not_defect','status':'FAILED'},{'returnInvoice':INV,'noticeType':'return_overdue','status':'DELIVERED','isTest':True}]
        self.assertEqual(return_notice_state(ns,INV),{'overdue':'','notDefect':'','manual':''})
        ns.append({'returnInvoice':INV,'noticeType':'return_not_defect','status':'SCHEDULED'})
        self.assertEqual(return_notice_state(ns,INV)['notDefect'],'SCHEDULED')

class SendTests(Base):
    def setUp(self):
        super().setUp()
        with self.store.edit() as s:
            s['settings'].update(shopName='테스트상점',shopRevision=1)
            s['returnCheck']=snapshot([row(INV),row('610000000002')|{'recipientPhone':'0507-1234-5678'}])
            s['exchangeCheck']=snapshot([row('610000000005')])
    def aftersales(self):return public_aftersales(self.store.read(),date(2026,10,14))
    def category(self,inv=INV):return next(r['category'] for r in self.aftersales()['rows'] if r['invoice']==inv)
    def test_preview_defaults_to_ably_wording(self):
        pv=self.engine.return_message_preview({'invoice':INV,'kind':'return_not_defect'})
        self.assertEqual(pv['seller'],'에이블리');self.assertIn('공지사항',pv['content']);self.assertIn('테스트상점',pv['content']);self.assertTrue(pv['phoneOk']);self.assertEqual(pv['phone'],'01000001234')
    def test_preview_uses_order_row_seller(self):
        with self.store.edit() as s:s['rows'][0]['orderId']='TEST-'+INV;s['rows'][0]['seller']='지그재그'
        pv=self.engine.return_message_preview({'invoice':INV,'kind':'return_not_defect'})
        self.assertEqual(pv['seller'],'지그재그');self.assertNotIn('공지사항',pv['content'])
    def test_preview_rejects_unknown(self):
        with self.assertRaises(ValidationError):self.engine.return_message_preview({'invoice':'999','kind':'return_overdue'})
        with self.assertRaises(ValidationError):self.engine.return_message_preview({'invoice':INV,'kind':'delay'})
    def test_send_not_defect_moves_card(self):
        self.clock(10)
        r=self.engine.return_message_send({'invoice':INV,'kind':'return_not_defect','sendMode':'IMMEDIATE','requestId':'req-1'})
        self.assertEqual(r['count'],1);n=self.last()
        self.assertEqual(n['status'],'QUEUED');self.assertEqual(n['itemKeys'],[]);self.assertEqual(n['returnInvoice'],INV);self.assertEqual(n['noticeType'],'return_not_defect')
        self.assertIn(n['kind'],('SMS','LMS'));self.assertIn('안내번호:',n['content']);self.assertEqual(n['phone'],'01000001234')
        self.assertEqual(self.category(),'not_defect_done')  # already while queued
        self.assertTrue(self.engine.send_one());n=self.last();self.at_age(n,0,20);self.engine.poll();self.assertEqual(self.last()['status'],'DELIVERED')
        self.assertEqual(self.category(),'not_defect_done')
        view=self.aftersales();self.assertEqual(view['rows'][0]['notDefectNotice'],'DELIVERED');self.assertEqual(view['rows'][0]['label'],'반품 불량 아님 안내 완료')
        # order rows are untouched: no due date, no notice count
        self.assertEqual(self.row()['noticeCount'],0)
    def test_overdue_does_not_move_card(self):
        self.clock(10);before=self.category()
        self.engine.return_message_send({'invoice':INV,'kind':'return_overdue','sendMode':'IMMEDIATE','requestId':'req-2'})
        self.assertEqual(self.category(),before);self.assertEqual(self.aftersales()['rows'][0]['overdueNotice'],'QUEUED')
    def test_failed_send_reverts_card(self):
        self.clock(10);self.engine.return_message_send({'invoice':INV,'kind':'return_not_defect','sendMode':'IMMEDIATE','requestId':'req-3'})
        self.fake.result='실패';self.assertTrue(self.engine.send_one());n=self.last();self.at_age(n,12);self.engine.poll()
        self.assertEqual(self.last()['status'],'FAILED');self.assertNotEqual(self.category(),'not_defect_done')
    def test_night_morning_schedules(self):
        self.clock(20);r=self.engine.return_message_send({'invoice':INV,'kind':'return_not_defect','sendMode':'MORNING','requestId':'req-4'})
        self.assertTrue(r['scheduled']);self.assertEqual(self.last()['status'],'SCHEDULED');self.assertEqual(self.category(),'not_defect_done')
    def test_duplicate_guard_and_idempotent_request(self):
        self.clock(10);self.engine.return_message_send({'invoice':INV,'kind':'return_overdue','sendMode':'IMMEDIATE','requestId':'req-5'})
        again=self.engine.return_message_send({'invoice':INV,'kind':'return_overdue','sendMode':'IMMEDIATE','requestId':'req-5'})
        self.assertTrue(again['alreadyAccepted']);self.assertEqual(len([n for n in self.store.read()['notices'] if n.get('returnInvoice')]),1)
        with self.assertRaises(ValidationError):self.engine.return_message_send({'invoice':INV,'kind':'return_overdue','sendMode':'IMMEDIATE','requestId':'req-6'})
    def test_safe_number_rejected(self):
        with self.assertRaises(ValidationError):self.engine.return_message_send({'invoice':'610000000002','kind':'return_overdue','sendMode':'IMMEDIATE','requestId':'req-7'})
    def test_exchange_row_never_moves(self):
        self.clock(10);self.engine.return_message_send({'invoice':'610000000005','kind':'return_not_defect','sendMode':'IMMEDIATE','requestId':'req-8'})
        self.assertNotEqual(self.aftersales()['exchangeRows'][0]['category'],'not_defect_done')

if __name__=='__main__':unittest.main()
