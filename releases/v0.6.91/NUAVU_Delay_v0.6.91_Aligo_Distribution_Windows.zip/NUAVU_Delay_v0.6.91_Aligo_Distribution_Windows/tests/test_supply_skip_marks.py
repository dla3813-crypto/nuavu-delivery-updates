"""2026-10-20 23:56 규칙: 파일명에 (NS 이미지) 또는 색칠이 든 출고장/진행상황은 수집도 감시도 하지 않는다."""
import unittest,tempfile,importlib,importlib.util
from pathlib import Path
from supply_workflow import skip_supply_file
from supply_watch import scan_signature
_mod=importlib.import_module('test_v068') if importlib.util.find_spec('test_v068') else importlib.import_module('test_supply_regression')
source_row,order,xlsx=_mod.source_row,_mod.order,_mod.xlsx
def _st():return _mod.SupplyTests

class Marks(unittest.TestCase):
    def test_names(self):
        self.assertTrue(skip_supply_file('(NS 이미지) 솔리아 10월 13일 출고장 (완료).xlsx'))
        self.assertTrue(skip_supply_file('솔리아 10월 13일 출고장 (완료) 색칠.xlsx'))
        self.assertTrue(skip_supply_file('（NS 이미지）솔리아 10월 13일 출고장 (완료).xlsx'))
        self.assertFalse(skip_supply_file('솔리아 10월 13일 출고장 (완료).xlsx'));self.assertFalse(skip_supply_file('진행상황.xlsx'))
    def test_watch_signature_ignores_marked_copies(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d)/'솔리아 10월 13일 출고장 (완료).xlsx').write_bytes(b'a');s1=scan_signature(d)
            (Path(d)/'(NS 이미지) 솔리아 10월 13일 출고장 (완료).xlsx').write_bytes(b'b');(Path(d)/'솔리아 10월 13일 출고장 (완료) 색칠.xlsx').write_bytes(b'c')
            self.assertEqual(s1,scan_signature(d))
            (Path(d)/'솔리아 10월 14일 출고장 (완료).xlsx').write_bytes(b'd');self.assertNotEqual(s1,scan_signature(d))

class Collect(_st().__mro__[1]):
    def setUp(self):
        super().setUp();self.folder=Path(self.tmp.name)/'자료';self.folder.mkdir();self.engine.supply_link(str(self.folder))
        self.set_orders([order(1),order(2),order(3,product='다른상품')])
    set_orders=_st().set_orders;file=_st().file;refresh=_st().refresh;active=_st().active
    def test_marked_copy_not_collected(self):
        self.file([source_row(qty=9)],'(NS 이미지) 솔리아 10월 13일 출고장 (완료).xlsx');self.file([source_row(qty=9)],'솔리아 10월 13일 출고장 (완료) 색칠.xlsx')
        self.refresh()
        self.assertEqual(self.store.read()['supply']['manifests'],{})
        self.file([source_row(qty=2)],'솔리아 10월 13일 출고장 (완료).xlsx');self.refresh()
        self.assertEqual(len(self.store.read()['supply']['manifests']),1)
if __name__=='__main__':unittest.main()
