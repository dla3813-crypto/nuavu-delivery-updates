'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),D=require('../web/dispatch_view.js');
const row=(o={})=>({active:true,orderId:'A123',seller:'누아브 에이블리',qty:1,dispatchStart:'',dispatchEnd:'',stockSecured:false,progressOfficeDates:[],...o});
test('V blank without dates unconfirmed',()=>assert.equal(D.unconfirmed(row()),true));
test('V date -> planned even if no full forecast',()=>{let r=row({progressOfficeDates:['2026-10-16']});assert.equal(D.planned(r),true);assert.equal(D.unconfirmed(r),false);assert.equal(D.plannedMatches(r),true)});
test('valid source V fallback',()=>assert.equal(D.planned({active:true,supplyInfo:{sources:[{kind:'progress',officeDate:'2026-10-16'}]}}),true));
test('invalid V is not planned',()=>{for(let d of ['','2026-02-30','내일','2026-10-1'])assert.equal(D.planned(row({progressOfficeDates:[d]})),false)});
test('customer promise not V evidence',()=>assert.equal(D.planned(row({dueDate:'2026-10-30'})),false));
test('computed dispatch alone not V evidence',()=>assert.equal(D.planned(row({dispatchStart:'2026-10-19',dispatchEnd:'2026-10-19'})),false));
test('secured manifest not put in unconfirmed due to blank V',()=>assert.equal(D.unconfirmed(row({stockSecured:true})),false));
test('inactive not classified in source-stage cards',()=>{let r=row({active:false,progressOfficeDates:['2026-10-16']});assert.equal(D.planned(r),false);assert.equal(D.unconfirmed(r),false)});
test('planned undated chip only shows arrivals without full dates',()=>{let r=row({progressOfficeDates:['2026-10-16']});assert.equal(D.plannedMatches(r,{rangeKey:'__undated__'}),true);assert.equal(D.plannedMatches({...r,dispatchStart:'2026-10-21',dispatchEnd:'2026-10-22'},{rangeKey:'__undated__'}),false)});
test('calendar does not invent dates for partial supply',()=>assert.equal(D.plannedMatches(row({progressOfficeDates:['2026-10-16']}),{day:'2026-10-21'}),false));
test('planned range filter remains functional',()=>assert.equal(D.plannedMatches(row({progressOfficeDates:['2026-10-16'],dispatchStart:'2026-10-21',dispatchEnd:'2026-10-22'}),{day:'2026-10-22'}),true));
test('planned totals include undated arrivals',()=>{let a=row({progressOfficeDates:['2026-10-16']}),b={...a,orderId:'B',dispatchStart:'2026-10-21',dispatchEnd:'2026-10-22'};assert.deepEqual(D.plannedStats([a,b,row()]),{count:2,orders:2,quantity:2,dated:1,undated:1,secured:0,progress:2})});
test('exchange only prefix C including lowercase',()=>{for(let id of ['C123','c123',' C001 '])assert.equal(D.exchange(row({orderId:id})),true);for(let id of ['12C3','AC123','','123'])assert.equal(D.exchange(row({orderId:id})),false)});
test('inactive exchange not in current exchange card',()=>assert.equal(D.exchange(row({orderId:'C123',active:false})),false));
const dateRow=(key,s,e=s)=>row({key,dispatchStart:s,dispatchEnd:e});
test('sort uses displayed start date not old end-first priority',()=>{let a=dateRow('early','2026-10-19','2026-10-29'),b=dateRow('late','2026-10-21');assert.ok(D.compareDispatch(a,b)<0);assert.ok(D.compareDispatch(a,b,true)>0)});
test('start tie sorts end date',()=>{let a=dateRow('a','2026-10-21'),b=dateRow('b','2026-10-21','2026-10-22');assert.ok(D.compareDispatch(a,b)<0)});
test('empty invalid dates last in both directions',()=>{for(let desc of [true,false])for(let b of [dateRow('blank',''),dateRow('bad','2026-02-30'),dateRow('inverted','2026-10-21','2026-10-20')])assert.ok(D.compareDispatch(dateRow('good','2026-10-21'),b,desc)<0)});
test('sort equality with two blanks is stable',()=>assert.equal(D.compareDispatch(row(),row()),0));
test('sort compares domestic not receipt or customer due date',()=>{let a=dateRow('a','2026-10-19'),b=dateRow('b','2026-10-21');a.receiptEnd='2026-12-30';a.dueDate='2027-01-01';assert.ok(D.compareDispatch(a,b)<0)});
test('sort neither changes quantities nor IDs',()=>{const rows=[dateRow('b','2026-10-21'),dateRow('a','2026-10-19')],before=JSON.stringify(rows);[...rows].sort(D.compareDispatch);assert.equal(JSON.stringify(rows),before)});
for(const id of ['C123','c123',' C123 '])test('exchange '+id+' excluded from unconfirmed',()=>assert.equal(D.unconfirmed(row({orderId:id})),false));
test('ordinary with internal C stays unconfirmed',()=>assert.equal(D.unconfirmed(row({orderId:'123C456'})),true));
test('exchange stays in planned when V exists',()=>assert.equal(D.planned(row({orderId:'C123',progressOfficeDates:['2026-10-16']})),true));
const I=require('../web/import.js');
test('configured shop aliases accepted, unrelated shop rejected',()=>{I.setShopName('데모스토어');assert.equal(I.seller('데모스토어 에이블리'),I.SELLERS[0]);assert.equal(I.seller('데모스토어자사몰'),I.SELLERS[1]);assert.equal(I.seller('다른몰 에이블리'),null);assert.equal(I.seller('지그재그'),I.SELLERS[2]);});
const suggested=()=>row({supplyInfo:{manualRecommended:true,matchNeeded:true,manualRecommendations:[{variant:'test',reason:'화이트 ↔ 아이보리'}]}});
test('manual suggestion card includes unmatched recommended orders',()=>assert.equal(D.manualRecommended(suggested()),true));
for(const excluded of [{active:false},{soldoutNotified:true},{review:true},{stockSecured:true}])test('manual card excludes '+JSON.stringify(excluded),()=>assert.equal(D.manualRecommended({...suggested(),...excluded}),false));
test('manual card excludes already linked and missing candidate evidence',()=>{for(const change of [{manualRecommended:false},{matchNeeded:false},{manualRecommendations:[]},{manualRecommendations:null}]){const r=suggested();Object.assign(r.supplyInfo,change);assert.equal(D.manualRecommended(r),false)}});
test('recommendation counts are order rows, not number of supplier alternatives',()=>{const r=suggested();r.supplyInfo.manualRecommendations.push({variant:'second'});assert.equal([r,row()].filter(D.manualRecommended).length,1)});
test('reading suggestion leaves order and stock untouched',()=>{const r=suggested(),before=JSON.stringify(r);D.manualRecommended(r);assert.equal(JSON.stringify(r),before)});
const riskRow=(stage='watch')=>row({delayRisk:{stage,shortQty:2,coveredQty:1,requiredQty:3}});
for(const stage of ['watch','confirmed'])test('risk card and subsection '+stage,()=>{const r=riskRow(stage);assert.equal(D.delayRisk(r),true);assert.equal(D.delayRisk(r,stage),true);assert.equal(D.delayRisk(r,stage==='watch'?'confirmed':'watch'),false)});
test('risk card ignores inactive soldout and review rows',()=>{for(const changed of [{active:false},{soldoutNotified:true},{review:true}])assert.equal(D.delayRisk({...riskRow(),...changed}),false)});
test('risk card ignores fully covered and not-started rows',()=>{for(const risk of [{stage:'watch',shortQty:0},{stage:'',shortQty:2},{stage:'other',shortQty:2}])assert.equal(D.delayRisk(row({delayRisk:risk})),false)});
test('forecast count differs from quantity and does not mutate row',()=>{const rows=[riskRow('watch'),riskRow('confirmed')],before=JSON.stringify(rows);assert.equal(rows.filter(r=>D.delayRisk(r)).length,2);assert.equal(rows.filter(r=>D.delayRisk(r,'watch')).reduce((n,r)=>n+r.delayRisk.shortQty,0),2);assert.equal(JSON.stringify(rows),before)});
test('late manifest can require forecast even if quantity secured',()=>assert.equal(D.delayRisk({...riskRow('confirmed'),stockSecured:true}),true));
test('manifest V alone enters planned even without full allocation',()=>{const r=row({manifestOfficeDates:['2026-10-12']});assert.equal(D.planned(r),true);assert.equal(D.unconfirmed(r),false);assert.equal(D.plannedMatches(r,{rangeKey:'__undated__'}),true)});
test('both source V dates have one planned order count',()=>{const r=row({progressOfficeDates:['2026-10-16'],manifestOfficeDates:['2026-10-12']});assert.deepEqual(D.officeDates(r),['2026-10-12','2026-10-16']);assert.equal(D.plannedStats([r]).count,1)});
test('source labels can distinguish equal V dates',()=>{const r=row({progressOfficeDates:['2026-10-16'],manifestOfficeDates:['2026-10-16']});assert.deepEqual(D.officeDates(r),['2026-10-16']);assert.deepEqual(D.officeDates(r,'manifest'),['2026-10-16']);assert.deepEqual(D.officeDates(r,'progress'),['2026-10-16'])});
test('legacy progress array does not hide manifest source fallback',()=>assert.equal(D.planned(row({supplyInfo:{sources:[{kind:'manifest',officeDate:'2026-10-12'}]}})),true));
test('manifest ship and calculated dates never substitute for V',()=>{const r=row({supplyInfo:{sources:[{kind:'manifest',shipDate:'2026-10-13',officeDate:'미도착'}]},dispatchStart:'2026-10-19',dispatchEnd:'2026-10-19'});assert.equal(D.planned(r),false)});
test('inactive manifest V stays out of planned',()=>assert.equal(D.planned(row({active:false,manifestOfficeDates:['2026-10-12']})),false));
test('bad manifest V dates do not enter planned',()=>{for(const d of ['',null,'2026-02-30','2026-10-1','미도착'])assert.equal(D.planned(row({manifestOfficeDates:[d]})),false)});
test('both V column display is read-only',()=>{const r=row({progressOfficeDates:['2026-10-16'],manifestOfficeDates:['2026-10-12']}),before=JSON.stringify(r);D.officeDates(r);D.plannedStats([r]);assert.equal(JSON.stringify(r),before)});
test('import retains four independent phone columns for order export',()=>{const headers=['판매처','주문번호','상품명','옵션명','주문수량','수령자이름','수령자휴대폰','수령자전화','주문자전화','주문자휴대폰'];const data=[headers,['에이블리','001','상품','블랙',1,'가상 수령자','010-0000-0011','02-000-1111','02-000-2222','010-0000-0022']];const parsed=I.parseRows(data,0,I.guessMapping(headers));assert.equal(parsed.errors.length,0);assert.deepEqual(parsed.rows[0].exportContacts,{recipientMobile:'010-0000-0011',recipientPhone:'02-000-1111',buyerPhone:'02-000-2222',buyerMobile:'010-0000-0022',sellerLabel:'에이블리'});assert.equal(parsed.rows[0].phone,'01000000022')});
test('legacy import without contact columns marks export metadata unavailable',()=>{const headers=['판매처','주문번호','상품명'];const parsed=I.parseRows([headers,['에이블리','001','상품']],0,I.guessMapping(headers));assert.equal(parsed.rows[0].exportContacts,null)});
test('aggregated orders do not invent conflicting recipient phone',()=>{const headers=['판매처','주문번호','상품명','수령자전화','주문자휴대폰'];const parsed=I.parseRows([headers,['에이블리','001','상품','02-000-1111','01000000022'],['에이블리','001','상품','02-000-3333','01000000022']],0,I.guessMapping(headers));assert.equal(parsed.rows[0].qty,2);assert.equal(parsed.rows[0].exportContacts.recipientPhone,'');assert.equal(parsed.rows[0].exportContacts.buyerMobile,'01000000022')});
test('whole workbook imports only selected shop channels before validating rows',()=>{
 I.setShopName('메이아워');const h=['판매처','주문번호','상품명','수량'];
 const a=I.parseRows([h,['메이아워 에이블리','1','상품',1],['앤로랑 에이블리','','',-1],['누아브 에이블리','','',-1],['메이아워 자사몰','','',-1]],0,I.guessMapping(h),{scope:[I.SELLERS[0]],strictShop:true});
 assert.equal(a.rows.length,1);assert.equal(a.errors.length,0);assert.equal(a.rows[0].sourceSeller,'메이아워 에이블리');assert.equal(Object.keys(a.excluded).length,3);
});
test('empty remembered scope imports no rows rather than all rows',()=>{
 I.setShopName('메이아워');const h=['판매처','주문번호','상품명'];
 assert.equal(I.parseRows([h,['메이아워 에이블리','1','상품']],0,I.guessMapping(h),{scope:[],strictShop:true}).rows.length,0);
});
test('strict raw seller rejects legacy NUAVU alias for another shop and accepts own name',()=>{
 I.setShopName('메이아워');assert.equal(I.seller('누아브 에이블리',true),null);assert.equal(I.seller('앤로랑 에이블리',true),null);assert.equal(I.seller('메이아워에이블리',true),I.SELLERS[0]);
 I.setShopName('NUAVU');assert.equal(I.seller('누아브 에이블리',true),I.SELLERS[0]);
 I.setShopName('');assert.equal(I.seller('누아브 에이블리',true),null);
});
test('Excel seller choices use actual labels including reverse shop and only present channels',()=>{
 I.setShopName('멜릿');const h=['A','B','C','D','E','F','G','H','판매처','주문번호','상품명'];
 const matrix=[h,['','','','','','','','','에이블리 멜릿','M1','니트'],['','','','','','','','','앤로랑 에이블리','A1','니트']];
 assert.deepEqual(I.discoverSellers(matrix,0,I.guessMapping(h)),['에이블리 멜릿']);
 const p=I.parseRows(matrix,0,I.guessMapping(h),{scopeLabels:true,scope:['에이블리 멜릿'],strictShop:true});assert.equal(p.rows.length,1);assert.equal(p.rows[0].seller,I.SELLERS[0]);
});
test('Amood and discovered additional channels parse with the source name',()=>{
 I.setShopName('메이아워');const h=['판매처','주문번호','상품명','수량'];const m=[h,['메이아워 에이블리','1','니트',1],['메이아워 아무드','2','셔츠',1],['메이아워 새채널','3','가디건',1],['뉴메이아워 에이블리','4','상품',1]];
 assert.deepEqual(I.discoverSellers(m,0,I.guessMapping(h)),['메이아워 에이블리','메이아워 아무드','메이아워 새채널']);
 const p=I.parseRows(m,0,I.guessMapping(h),{scopeLabels:true,scope:['메이아워 아무드'],strictShop:true});assert.equal(p.rows.length,1);assert.equal(p.rows[0].seller,'누아브 아무드');assert.equal(p.rows[0].sourceSeller,'메이아워 아무드');
});
test('Remembered absent labels stay hidden and return with prior choice',()=>{
 I.setShopName('메이아워');const settings={shopName:'메이아워',importSellerChoices:{'메이아워':{'메이아워에이블리':true,'메이아워아무드':false}}};
 assert.deepEqual(I.rememberedSellers(['메이아워 에이블리'],settings),['메이아워 에이블리']);
 assert.deepEqual(I.rememberedSellers(['메이아워 에이블리','메이아워 아무드'],settings),['메이아워 에이블리']);
});
test('Source scopes distinguish aliases but preserve legacy row identities',()=>{
 I.setShopName('메이아워');assert.equal(I.inSourceScope({seller:I.SELLERS[0],sourceSeller:'에이블리 메이아워'},['메이아워 에이블리']),false);
 assert.equal(I.inSourceScope({seller:I.SELLERS[0]},['에이블리 메이아워']),true);
});
test('Duplicate seller labels collapse whitespace and empty data discovers no boxes',()=>{
 I.setShopName('멜릿');const h=['판매처'];assert.deepEqual(I.discoverSellers([h,['에이블리 멜릿'],['에이블리  멜릿'],['합계']],0,I.guessMapping(h)),['에이블리 멜릿']);assert.deepEqual(I.discoverSellers([h],0,I.guessMapping(h)),[]);
});
