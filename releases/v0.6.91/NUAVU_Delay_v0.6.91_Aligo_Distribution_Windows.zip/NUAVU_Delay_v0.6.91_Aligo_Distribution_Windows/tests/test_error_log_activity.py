"""2026-10-22 19:02~19:03 (공통) ⚙ 설정 › 오류 로그 · 진행상황 바 · 자사몰 회수접수 오탐 알림."""
import unittest,tempfile,threading,time
from datetime import datetime,timezone,timedelta
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1]

try:from test_v056 import Base
except ImportError:from helpers import Base

class ErrorLog(Base):
    def test_error_alert_goes_to_log_with_traceback(self):
        try:raise ValueError('지그재그 버튼 없음')
        except ValueError:self.engine.add_job_alert('품절 주문취소 확인 필요','139775599329591174: 지그재그 취소 실패','error')
        self.engine.add_job_alert('회수접수 완료','정상','info')
        log=self.engine.error_log({})['entries']
        self.assertEqual(len(log),1);e=log[0]
        self.assertEqual(e['title'],'품절 주문취소 확인 필요');self.assertIn('지그재그 취소 실패',e['message'])
        self.assertIn('ValueError: 지그재그 버튼 없음',e['detail']);self.assertIn('test_error_log_activity.py',e['detail'])
        from domain import APP_VERSION;self.assertEqual(e['version'],APP_VERSION)
        self.assertEqual(self.engine.error_log({'action':'clear'})['entries'],[])
    def test_no_traceback_outside_except(self):
        self.engine.add_job_alert('막힘','x','error');self.assertEqual(self.engine.error_log({})['entries'][0]['detail'],'')
    def test_log_is_bounded(self):
        for i in range(305):self.engine.record_error('t',str(i))
        self.assertEqual(len(self.engine.error_log({})['entries']),300)

class PickupAlert(unittest.TestCase):
    def test_cafe24_and_completed_results_are_not_blocked(self):
        src=(ROOT/'pickup_controller.py').read_text(encoding='utf-8')
        self.assertIn("fine={'에이블리 접수 완료','자사몰 · 이지어드민 회수접수만','에이블리 교환 건 · 접수 단계 없음'}",src)
        self.assertNotIn("f'에이블리 반품요청 접수 확인 필요",src)

class ActivityStatus(unittest.TestCase):
    def test_running_and_upcoming(self):
        from desktop import DesktopAPI
        from domain import Store
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup);store=Store(tmp.name);self.addCleanup(store.close)
        later=(datetime.now(timezone.utc)+timedelta(hours=2)).isoformat()
        with store.edit() as s:
            s['notices']=[{'status':'SCHEDULED','scheduledAt':later,'noticeType':'soldout_card','isTest':False},{'status':'SCHEDULED','scheduledAt':later,'noticeType':'soldout_bank','isTest':False},{'status':'DELIVERED','scheduledAt':later,'noticeType':'delay'}]
            s['soldoutCancelSchedule']=[{'at':(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat(),'targets':[{},{}]}]
            s['returnSettings']={'mode':'daily','time':'23:59'}
        ev=threading.Event();th=threading.Thread(target=ev.wait,daemon=True);th.start();self.addCleanup(ev.set)
        fake=SimpleNamespace(_authorized=lambda t:None,_order_auto=None,_ably_sync=SimpleNamespace(thread=th,job={'message':'에이블리 로그인 완료를 확인합니다.'}),
                             _returns=None,_pickup=None,_zigzag=None,_soldout_display=None,_engine=SimpleNamespace(store=store,order_exporter=None))
        r=DesktopAPI.activity_status(fake,'t')
        self.assertEqual(r['running'],[{'name':'에이블리·아무드 동기화','message':'에이블리 로그인 완료를 확인합니다.'}])
        names=[u['name'] for u in r['upcoming']]
        self.assertEqual(names[0],'예약 주문취소 2건');self.assertIn('예약 품절 문자 2건',names);self.assertIn('(Auto)반품 조회',names)
        self.assertEqual(sorted(r['upcoming'],key=lambda u:u['at']),r['upcoming'])
    def test_unauthorized(self):
        from desktop import DesktopAPI
        def deny(t):raise PermissionError('앱 인증이 만료되었습니다.')
        self.assertEqual(DesktopAPI.activity_status(SimpleNamespace(_authorized=deny),'t'),{'error':'앱 인증이 만료되었습니다.'})
