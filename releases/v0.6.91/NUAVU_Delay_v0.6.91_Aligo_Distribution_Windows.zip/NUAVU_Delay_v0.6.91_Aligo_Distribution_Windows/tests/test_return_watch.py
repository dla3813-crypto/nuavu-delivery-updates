"""File watcher for 에이블리 반품진행상황.xlsx: runs on changed content only, once per interval, remembered across restarts."""
import os,sys,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
from datetime import datetime
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from domain import Store,Engine,KST
import return_check
from return_check import ReturnController
try:
    from test_v068 import xlsx
except ImportError:
    from test_supply_regression import xlsx

def make_engine(tmp):
    store=Store(tmp)
    try:
        from test_app import FakeProvider;engine=Engine(store,FakeProvider())
    except ImportError:
        from helpers import MemoryVault,FakeSMS,FakeAT;engine=Engine(store,FakeSMS(),MemoryVault(),aligo_provider=FakeAT(),aligo_vault=MemoryVault())
    with engine.store.edit() as s:s['settings']['shopName']='누아브'
    return store,engine

def sheet(n):return xlsx([('반품',[['반품접수번호','주문번호']]+[[str(i),'O'+str(i)] for i in range(n)])])

class WatchTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.store,self.engine=make_engine(self.tmp.name)
        self.folder=Path(self.tmp.name)/'f';self.folder.mkdir();self.file=self.folder/'에이블리 반품진행상황.xlsx';self.file.write_bytes(sheet(1))
        self.runs=[];self.mono=[0.0]
        p=patch.object(return_check.time,'monotonic',lambda:self.mono[0]);p.start();self.addCleanup(p.stop)
        self.c=self.controller()
    def controller(self):
        def runner(account,c):self.runs.append(account.get('kind'));return {'rows':[],'total':0,'complete':True,'exchangeRows':[],'digest':return_check.file_digest(str(self.folder))}
        c=ReturnController(self.engine,runner=runner,local=True,clock=lambda:datetime(2026,10,19,8,0,tzinfo=KST))
        c.save({'mode':'manual','time':'09:00','watchEnabled':True,'folder':str(self.folder)});return c
    def ticks(self,n,c=None):
        c=c or self.c
        for _ in range(n):
            self.mono[0]+=10;c.tick()
            for _ in range(200):
                if not c.running():break
                time.sleep(.02)
    def test_first_read_then_quiet(self):
        self.ticks(6);self.assertEqual(self.runs,['return'])
        self.ticks(30);self.assertEqual(self.runs,['return'])
        self.assertTrue(self.store.read()['returnSettings']['watchDigest'])
    def test_restamped_same_content_does_not_rerun(self):
        self.ticks(6);self.assertEqual(len(self.runs),1)
        os.utime(self.file,(time.time()+100,time.time()+100))  # iCloud/Excel touch: new mtime, same bytes
        self.ticks(10);self.assertEqual(len(self.runs),1)
        self.file.write_bytes(sheet(1))  # rewritten with identical content (new inode/mtime)
        self.ticks(10);self.assertEqual(len(self.runs),1)
    def test_changed_content_runs_once_per_interval(self):
        self.ticks(6);self.assertEqual(len(self.runs),1)
        self.file.write_bytes(sheet(2));self.ticks(6);self.assertEqual(len(self.runs),1,'inside the minimum interval: waits')
        self.assertIn('분 간격',self.c.status()['watchNote'])
        self.mono[0]+=return_check.WATCH_MIN_INTERVAL;self.ticks(2);self.assertEqual(len(self.runs),2)
        self.assertEqual(self.c.status()['watchNote'],'')
        self.ticks(20);self.assertEqual(len(self.runs),2)
    def test_restart_with_unchanged_file_does_not_rerun(self):
        self.ticks(6);self.assertEqual(len(self.runs),1)
        other=self.controller();self.ticks(10,other);self.assertEqual(len(self.runs),1)
        self.file.write_bytes(sheet(3));self.mono[0]+=return_check.WATCH_MIN_INTERVAL;self.ticks(6,other);self.assertEqual(len(self.runs),2)
    def test_saving_settings_does_not_rerun_unless_folder_changes(self):
        self.ticks(6);self.assertEqual(len(self.runs),1)
        self.c.save({'mode':'daily','time':'09:00','watchEnabled':True,'folder':str(self.folder)});self.ticks(10);self.assertEqual(len(self.runs),1)
        self.assertTrue(self.store.read()['returnSettings']['watchDigest'])
        other=Path(self.tmp.name)/'g';other.mkdir();(other/'에이블리 반품진행상황.xlsx').write_bytes(sheet(5))
        self.c.save({'mode':'daily','time':'09:00','watchEnabled':True,'folder':str(other)});self.mono[0]+=return_check.WATCH_MIN_INTERVAL;self.ticks(6);self.assertEqual(len(self.runs),2)
    def test_manual_run_claims_content_for_the_watcher(self):
        self.c.save({'mode':'manual','time':'09:00','watchEnabled':False,'folder':str(self.folder)})
        self.c.start(kind='return')
        for _ in range(200):
            if not self.c.running():break
            time.sleep(.02)
        self.assertEqual(self.runs,['return'])
        self.c.save({'mode':'manual','time':'09:00','watchEnabled':True,'folder':str(self.folder)});self.ticks(10);self.assertEqual(len(self.runs),1)

if __name__=='__main__':unittest.main()
