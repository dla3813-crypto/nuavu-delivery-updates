"""2026-10-19: EzAdmin C/S 회수요청 history skips EX00; registered pickups continue to the Ably 반품요청 접수 step."""
import copy,tempfile,threading,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from pickup_browser import cs_pickup_entries,cs_flag_pickup,cs_history_note
from ably_return_accept import match_row,accept_targets,waiting_outcome
from pickup_controller import PickupController
from domain import Store
from test_aftersales_new import NOW,row,snapshot,MemoryVault

CS_ROWS=[['2026-10-08 12:32:54','danimstudio','회수요청 일반','','미처리'],['[731807] [회수요청] S3 소프트 실크 반팔 니트 [화이트] S37644'],
         ['2026-10-07 09:00:00','danimstudio','배송정보변경 일반','','완료'],['[731807] 주소 변경']]

class CsHelperTests(unittest.TestCase):
    def test_entries_only_pickup_requests_with_content(self):
        e=cs_pickup_entries(CS_ROWS)
        self.assertEqual(len(e),1);self.assertEqual(e[0]['at'],'2026-10-08 12:32:54');self.assertEqual(e[0]['worker'],'danimstudio');self.assertEqual(e[0]['state'],'미처리')
        self.assertIn('S3 소프트 실크',e[0]['content']);self.assertEqual(cs_pickup_entries([]),[]);self.assertEqual(cs_pickup_entries([['2026-10-07','x','배송정보변경 일반','','완료']]),[])
    def test_list_flag(self):
        self.assertTrue(cs_flag_pickup('0,xx,tb,rm'));self.assertTrue(cs_flag_pickup('7,xx,tb'));self.assertFalse(cs_flag_pickup('0'));self.assertFalse(cs_flag_pickup(''));self.assertFalse(cs_flag_pickup('0,xxtb'))
    def test_note_mentions_history(self):
        note=cs_history_note({'entries':cs_pickup_entries(CS_ROWS)})
        self.assertIn('회수요청 일반 2026-10-08 12:32:54',note);self.assertIn('danimstudio, 미처리',note);self.assertIn('접수하지 않았습니다',note)

class AblyHelperTests(unittest.TestCase):
    def test_match_row_requires_selectable_invoice(self):
        rows=[{'index':0,'selectable':True,'invoice':'6082035030105','status':'반품요청 지연 - 접수필요','requestNo':'1'},
              {'index':1,'selectable':False,'invoice':'6082035030106','status':'','requestNo':''},
              {'index':2,'selectable':True,'invoice':'6082035030106','status':'반품요청','requestNo':'2'}]
        self.assertEqual(match_row(rows,'6082035030105')['index'],0);self.assertEqual(match_row(rows,'6082035030106')['index'],2);self.assertIsNone(match_row(rows,'1'))
    def test_waiting_card_counts_as_done(self):
        self.assertEqual(waiting_outcome({'status':'검수대기','requestNo':'66338855'})['ablyResult'],'에이블리 접수 완료')
        self.assertIsNone(waiting_outcome(None));self.assertIsNone(waiting_outcome({'status':'반품요청 지연 - 접수필요','requestNo':'1'}))
    def test_targets_registered_only_and_unique(self):
        results=[{'invoice':'1','result':'접수 완료'},{'invoice':'2','result':'이미 접수됨'},{'invoice':'3','result':'조회 실패'},{'invoice':'1','result':'접수 완료'},{'invoice':'4','result':'접수 전 확인','inspectOnly':True}]
        self.assertEqual([t['invoice'] for t in accept_targets(results)],['1','2'])

class ControllerAblyTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(Path(self.tmp.name)/'db')
        with self.store.edit() as s:s['settings'].update(shopName='테스트상점',shopRevision=1);s['returnCheck']=snapshot([row()])
        self.engine=SimpleNamespace(store=self.store,stop=threading.Event());self.cs=[]
        self.report=patch('pickup_report.save_report',return_value=str(Path(self.tmp.name)/'result.xlsx'));self.report.start();self.addCleanup(self.report.stop)
    def tearDown(self):
        for c in self.cs:c.shutdown();c.thread.join(2) if c.thread else None
        self.store.close();self.tmp.cleanup()
    def ctrl(self,runner,ably):
        c=PickupController(self.engine,runner=runner,vault=MemoryVault(),clock=lambda:NOW);c.ably_runner=ably;self.cs.append(c);return c
    def test_registered_pickups_go_to_ably_and_results_persist(self):
        def run(c,rows,shop,inspect):
            c.before_submit('610000000001');c.record({'invoice':'610000000001','result':'접수 완료'})
            c.record({'invoice':'610000000002','result':'이미 접수됨','note':'이지어드민 C/S 이력 회수요청 일반 2026-10-08','csHistory':True})
            c.record({'invoice':'610000000003','result':'조회 실패'})
        calls=[]
        def ably(c,targets,today):
            calls.append([t['invoice'] for t in targets])
            return {'610000000001':{'ablyResult':'에이블리 접수 완료','ablyNote':'검수대기 카드에서 확인 · 반품요청번호 66338855','ablyRequestNo':'66338855'},
                    '610000000002':{'ablyResult':'접수필요 목록에 없음','ablyNote':'목록에서 원송장을 찾지 못했습니다.'}}
        c=self.ctrl(run,ably);c.start_pickups([row(),row('610000000002'),row('610000000003')]);c.thread.join(3)
        self.assertEqual(calls,[['610000000001','610000000002']])
        got={r['invoice']:r for r in c.status()['rows']}
        self.assertEqual(got['610000000001']['ablyResult'],'에이블리 접수 완료');self.assertEqual(got['610000000001']['ablyRequestNo'],'66338855')
        self.assertEqual(got['610000000002']['ablyResult'],'접수필요 목록에 없음');self.assertNotIn('ablyResult',got['610000000003'])
        hist={h['invoice']:h for h in self.store.read()['pickupHistory']}
        self.assertEqual(hist['610000000001']['ablyResult'],'에이블리 접수 완료');self.assertTrue(hist['610000000001']['ablyAt'])
        self.assertEqual(c.status()['phase'],'done');self.assertIn('에이블리 반품요청 접수 1/2건',c.status()['message'])
    def test_inspection_skips_ably(self):
        calls=[]
        c=self.ctrl(lambda c,rows,*a:c.record({'invoice':rows[0]['invoice'],'result':'접수 전 확인'},True),lambda *a:calls.append(1) or {})
        c.start_pickups([row()],inspect_only=True);c.thread.join(2);self.assertEqual(calls,[]);self.assertEqual(c.status()['phase'],'done')
    def test_ably_failure_does_not_fail_pickup_job(self):
        def boom(*a):raise RuntimeError('chrome')
        c=self.ctrl(lambda c,rows,*a:c.record({'invoice':rows[0]['invoice'],'result':'접수 완료'}),boom)
        c.start_pickups([row()]);c.thread.join(2)
        self.assertEqual(c.status()['phase'],'done');self.assertEqual(c.status()['rows'][0]['ablyResult'],'에이블리 접수 실패');self.assertIn('에이블리',c.status()['rows'][0]['ablyNote'])
    def test_no_registered_pickup_means_no_ably_call(self):
        calls=[]
        c=self.ctrl(lambda c,rows,*a:c.record({'invoice':rows[0]['invoice'],'result':'고객정보 불일치'}),lambda *a:calls.append(1) or {})
        c.start_pickups([row()]);c.thread.join(2);self.assertEqual(calls,[])

if __name__=='__main__':unittest.main()
