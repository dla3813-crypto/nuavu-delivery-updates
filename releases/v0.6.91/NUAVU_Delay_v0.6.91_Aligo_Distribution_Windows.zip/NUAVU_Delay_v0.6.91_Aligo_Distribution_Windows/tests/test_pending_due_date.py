"""2026-10-19 (공통): a queued/scheduled delay message pre-applies its 출고 예정일 to the row; failure/cancel restores the old date."""
from helpers import Base,Clock,FIRST
try:
    from helpers import CHANGE
except ImportError:
    CHANGE=FIRST

class PendingDueDateTests(Base):
    def test_scheduled_message_applies_date_now(self):
        self.clock(20);n=self.queue(sendMode='MORNING',dueDate='2026-10-22')
        self.assertEqual(n['status'],'SCHEDULED')
        r=self.row();self.assertEqual(r['dueDate'],'2026-10-22');self.assertTrue(r['dueDatePending']);self.assertEqual(r['dueDateSource'],'pending_message')
        self.assertEqual(r['bucket'],'scheduled');self.assertEqual(r['color'],'green');self.assertEqual(r['noticeCount'],0)
    def test_cancel_restores_previous_date(self):
        self.clock(10);self.send(dueDate='2026-10-20');self.engine.poll(force=True);self.assertEqual(self.row()['dueDate'],'2026-10-20')
        self.clock(20);n=self.queue(sendMode='MORNING',dueDate='2026-10-24',template=CHANGE,templateKey='change')
        self.assertEqual(self.row()['dueDate'],'2026-10-24')
        self.engine.queue_control({'action':'cancel_one','id':n['id']})
        r=self.row();self.assertEqual(r['dueDate'],'2026-10-20');self.assertFalse(r['dueDatePending'])
    def test_failed_send_restores_previous_date(self):
        self.clock(10);self.send(dueDate='2026-10-20');self.engine.poll(force=True);self.assertEqual(self.last()['status'],'DELIVERED')
        self.clock(11);self.queue(dueDate='2026-10-24',template=CHANGE,templateKey='change');self.assertEqual(self.row()['dueDate'],'2026-10-24')
        self.fake.result='발송실패';self.assertTrue(self.engine.send_one());self.engine.poll(force=True)
        self.assertEqual(self.last()['status'],'FAILED');r=self.row();self.assertEqual(r['dueDate'],'2026-10-20');self.assertFalse(r['dueDatePending']);self.assertEqual(r['bucket'],'failed')
