"""Current user policy: V-only arrival evidence, automatic identities, domestic dispatch.
Synthetic OOXML / temporary DB / fake providers only. No real messages.
"""
import copy,unittest
from pathlib import Path
from datetime import datetime
from domain import KST,Engine,Store
from helpers import Base,Clock
from test_supply_regression import source_row,xlsx,order
from supply_workflow import (read_supplier,allocation_view,init_supply,candidates,catalogue,
    order_signature,progress_day,SupplyError)

class StrictDatesTests(Base):
    def setUp(self):
        super().setUp()
        self.folder=Path(self.tmp.name)/'공급';self.folder.mkdir()
        with self.store.edit() as s:s['rows']=[]
        self.engine.supply_link(str(self.folder))
    def orders(self,rows):self.engine.import_rows({'rows':rows,'mode':'merge'})
    def progress(self,rows):
        (self.folder/'진행상황.xlsx').write_bytes(xlsx([('10월16일',rows)]));return self.engine.supply_refresh()
    def manifest(self,rows):
        (self.folder/'솔리아 10월 13일 출고장 (완료).xlsx').write_bytes(xlsx([('출고장',rows)]));return self.engine.supply_refresh()
    def rows(self):return self.engine.public_state()['rows']
    def info(self):return self.rows()[0]['supplyInfo']
    def one(self,product='가디건',option='[원컬러-FREE]',qty=1):self.orders([order(1,product=product,option=option,qty=qty)])
    def test_V_empty_L_date_no_schedule(self):
        self.one();self.progress([source_row(purchase='2026-10-13')]);self.assertEqual(self.rows()[0]['dispatchEnd'],'');self.assertEqual(self.info()['basisDate'] if 'basisDate' in self.info() else '', '')
    def test_L_still_audit_only(self):
        self.one();self.progress([source_row(purchase='2026-10-13')]);r=self.store.read()['supply']['progress'][0];self.assertEqual(r['purchaseDate'],'2026-10-13');self.assertEqual(r['basisDate'],'')
    def test_V_spaces(self):
        self.one();self.progress([source_row(office='  ',purchase='2026-10-13')]);self.assertEqual(self.rows()[0]['dispatchEnd'],'')
    def test_V_invalid_text_no_L_fallback(self):
        self.one();self.progress([source_row(office='미도착',purchase='2026-10-13')]);self.assertEqual(self.rows()[0]['dispatchEnd'],'')
    def test_V_excel_error_no_date(self):
        self.one();self.progress([source_row(office='#VALUE!',purchase='2026-10-13')]);self.assertEqual(self.rows()[0]['dispatchEnd'],'')
    def test_V_valid_numeric(self):
        self.one();self.progress([source_row(office=46311)]);self.assertEqual(self.rows()[0]['dispatchEnd'],'2026-10-22')
    def test_V_same_day_saturday(self):
        self.one();self.progress([source_row(office='10월 17일')]);self.assertEqual(self.info()['parts'][0]['path']['chinaDate'],'2026-10-17')
    def test_domestic_dates_not_customer_receipt(self):
        self.one();self.progress([source_row(office='2026-10-16')]);r=self.rows()[0];self.assertEqual((r['dispatchStart'],r['dispatchEnd']),('2026-10-21','2026-10-22'));self.assertEqual(r['receiptEnd'],'2026-10-23')
    def test_manifest_domestic_monday(self):
        self.one();self.manifest([source_row()]);self.assertEqual(self.rows()[0]['dispatchEnd'],'2026-10-19')
    def test_manifest_evidence_valid_even_progress_blank(self):
        self.one();self.progress([source_row(purchase='2026-10-14')]);self.manifest([source_row()]);r=self.rows()[0];self.assertTrue(r['stockSecured']);self.assertEqual(r['dispatchEnd'],'2026-10-19')
    def test_blank_V_matched_not_manual_needed(self):
        self.one();self.progress([source_row(purchase='2026-10-13')]);a=self.info();self.assertTrue(a['matched']);self.assertFalse(a['matchNeeded']);self.assertEqual(a['reasonCode'],'OFFICE_UNARRIVED')
    def test_insufficient_stock_not_manual_needed(self):
        self.one(qty=2);self.progress([source_row(office='2026-10-16')]);a=self.info();self.assertFalse(a['matchNeeded']);self.assertEqual(a['plannedQty'],1);self.assertEqual(a['dispatchEnd'],'');self.assertEqual(a['reasonCode'],'SHORTAGE_OR_DATE')
    def test_blank_extra_stock_cannot_fill_order(self):
        self.one(qty=2);self.progress([source_row(office='2026-10-16'),source_row(qty=100,purchase='2026-10-13')]);a=self.info();self.assertEqual(a['plannedQty'],1);self.assertEqual(a['dispatchEnd'],'')
    def test_color_specific_no_date_from_other_color(self):
        self.one(option='[블랙-M]');self.progress([source_row(color='블랙',size='M',purchase='2026-10-13'),source_row(color='그린',size='M',office='2026-10-15')]);self.assertEqual(self.rows()[0]['dispatchEnd'],'');self.assertFalse(self.info()['matchNeeded'])
    def test_size_specific_no_date_from_other_size(self):
        self.one(option='[그린-5XL(55)]');self.progress([source_row(color='그린',size='5XL',purchase='2026-10-13'),source_row(color='그린',size='3XL',office='2026-10-15')]);self.assertEqual(self.rows()[0]['dispatchEnd'],'')
    def test_uncolored_free_uses_observed_variant_only(self):
        self.one();self.progress([source_row(color='블랙',size='3XL',office='2026-10-15'),source_row(color='화이트',size='5XL',purchase='2026-10-13')]);self.assertEqual(self.info()['plannedQty'],1);self.assertEqual(self.info()['parts'][0]['color'],'블랙')
    def test_dated_qty_FIFO(self):
        self.orders([order(1),order(2)]);self.progress([source_row(office='2026-10-16'),source_row(qty=20,purchase='2026-10-13')]);rr=self.rows();self.assertEqual(sum(bool(r['dispatchEnd']) for r in rr),1);self.assertEqual(next(r for r in rr if r['orderId']=='TEST-001')['dispatchEnd'],'2026-10-22')
    def test_V_arrives_later_changes_on_manual_refresh(self):
        self.one();self.progress([source_row(purchase='2026-10-13')]);(self.folder/'진행상황.xlsx').write_bytes(xlsx([('main',[source_row(office='2026-10-17')])]));self.assertEqual(self.rows()[0]['dispatchEnd'],'');self.engine.supply_refresh();self.assertEqual(self.rows()[0]['dispatchEnd'],'2026-10-22')
    def test_V_removed_clears_prior_calculation(self):
        self.one();self.progress([source_row(office='2026-10-15')]);self.progress([source_row(purchase='2026-10-13')]);self.assertEqual(self.rows()[0]['dispatchEnd'],'')
    def test_legacy_cached_estimate_never_used_in_projection(self):
        self.one();self.progress([source_row(purchase='2026-10-13')]);s=self.store.read();r=s['supply']['progress'][0];r.update(basisDate='2026-10-16',basisType='estimate');a,_=allocation_view(s);self.assertEqual(next(iter(a.values()))['dispatchEnd'],'')
    def test_upgrade_clears_legacy_basis_and_keeps_notes(self):
        self.one();self.progress([source_row(purchase='2026-10-13')]);key=self.rows()[0]['key'];self.engine.external_manual({'keys':[key],'dueDate':'2026-10-21'});ledger=copy.deepcopy(self.store.read()['notices'])
        with self.store.edit() as s:
            v=s['supply'];v.pop('datePolicy',None);v['progress'][0].update(basisDate='2026-10-16',basisType='estimate')
        self.engine.setup_supply();s=self.store.read();self.assertEqual(s['supply']['progress'][0]['basisDate'],'');self.assertEqual(s['notices'],ledger);self.assertEqual(self.rows()[0]['dueDate'],'2026-10-21')
    def test_upgrade_policy_idempotent(self):
        self.one();self.engine.setup_supply();n=len(self.store.read()['audits']);self.engine.setup_supply();self.assertEqual(len(self.store.read()['audits']),n)
    def test_progress_never_confirms_manifest_bucket(self):
        self.one();self.progress([source_row(office='2026-10-15')]);r=self.rows()[0];self.engine.external_manual({'keys':[r['key']],'dueDate':'2026-10-23'});self.assertEqual(self.rows()[0]['bucket'],'within')
    def test_manifest_confirmed_only_due_compatible(self):
        self.one();self.manifest([source_row()]);r=self.rows()[0];self.engine.external_manual({'keys':[r['key']],'dueDate':'2026-10-21'});self.assertEqual(self.rows()[0]['bucket'],'within_confirmed')
    def test_no_provider_calls(self):
        self.one();self.progress([source_row(office='2026-10-15')]);self.manifest([source_row()]);self.engine.setup_supply();self.rows();self.assertFalse(self.fake.sent);self.assertFalse(self.fake.report_calls)
    def test_exact_product_outranks_generic_hood(self):
        self.one('민트 도트 스타 후드 집업');self.progress([source_row(product='민트 도트 스타 후드 집업',office='2026-10-16'),source_row(product='후드',brand='NS',office='2026-10-15')]);self.assertFalse(self.info()['matchNeeded']);self.assertEqual([p['product'] for p in self.info()['parts']],['민트 도트 스타 후드 집업'])
    def test_exact_blank_V_never_falls_back_generic_dated(self):
        self.one('민트 도트 스타 후드 집업');self.progress([source_row(product='민트 도트 스타 후드 집업',purchase='2026-10-13'),source_row(product='후드',brand='NS',office='2026-10-15')]);self.assertFalse(self.info()['matchNeeded']);self.assertEqual(self.rows()[0]['dispatchEnd'],'')
    def test_exact_wrong_size_never_falls_back_generic(self):
        self.one('민트 후드 집업','[화이트-M]');self.progress([source_row(product='민트 후드 집업',color='화이트',size='L',office='2026-10-15'),source_row(product='후드',color='화이트',size='M',office='2026-10-15')]);self.assertTrue(self.info()['matchNeeded']);self.assertEqual(self.rows()[0]['dispatchEnd'],'')
    def test_substring_single_product_auto_matches(self):
        self.one('(CC-1)[2color]롱 골지 니트 가디건');self.progress([source_row(product='골지 니트 가디건',office='2026-10-15')]);self.assertFalse(self.info()['matchNeeded']);self.assertTrue(self.rows()[0]['dispatchEnd'])
    def test_unrelated_names_dont_fuzzy_guess(self):
        self.one('긴팔 셔츠');self.progress([source_row(product='반팔 셔츠',office='2026-10-15')]);self.assertTrue(self.info()['matchNeeded']);self.assertEqual(self.rows()[0]['dispatchEnd'],'')
    def test_multiple_partial_products_manual_needed(self):
        self.one('니트 가디건');self.progress([source_row(product='니트',office='2026-10-15'),source_row(product='가디건',office='2026-10-15')]);self.assertTrue(self.info()['ambiguous']);self.assertTrue(self.info()['matchNeeded'])
    def test_manual_same_SKU_other_orders(self):
        self.orders([order(1),order(2)]);self.progress([source_row(product='대행사 약칭',office='2026-10-16',qty=2)]);r=self.rows()[0];variant=self.engine.public_state()['supply']['variants'][0]['variant'];self.engine.supply_match({'key':r['key'],'variants':[variant]});self.assertTrue(all(x['dispatchEnd']=='2026-10-22' for x in self.rows()));self.assertTrue(all(not x['supplyInfo']['matchNeeded'] for x in self.rows()))
    def test_manual_map_no_V_cannot_create_date(self):
        self.one();self.progress([source_row(product='대행사 약칭',purchase='2026-10-13')]);r=self.rows()[0];variant=self.engine.public_state()['supply']['variants'][0]['variant'];self.engine.supply_match({'key':r['key'],'variants':[variant]});self.assertFalse(self.info()['matchNeeded']);self.assertEqual(self.rows()[0]['dispatchEnd'],'')
    def test_manual_no_V_then_arrived_after_refresh(self):
        self.one();self.progress([source_row(product='대행사 약칭',purchase='2026-10-13')]);r=self.rows()[0];vid=self.engine.public_state()['supply']['variants'][0]['variant'];self.engine.supply_match({'key':r['key'],'variants':[vid]});self.progress([source_row(product='대행사 약칭',office='2026-10-15')]);self.assertEqual(self.rows()[0]['dispatchEnd'],'2026-10-22')
    def test_manual_rule_remains_after_restart(self):
        self.one();self.progress([source_row(product='대행사 약칭',office='2026-10-16')]);r=self.rows()[0];vid=self.engine.public_state()['supply']['variants'][0]['variant'];self.engine.supply_match({'key':r['key'],'variants':[vid]});before=self.store.read()['supply']['mappings'];self.restart();self.assertEqual(self.store.read()['supply']['mappings'],before);self.assertEqual(self.rows()[0]['dispatchEnd'],'2026-10-22')
    def test_same_exact_product_N_NS_not_ambiguous(self):
        self.one(qty=2);self.progress([source_row(brand='N',office='2026-10-15'),source_row(brand='NS',office='2026-10-15')]);self.assertFalse(self.info()['matchNeeded']);self.assertEqual(self.info()['plannedQty'],2)
    def test_non_selected_brand_excluded(self):
        self.one();self.progress([source_row(brand='OD',office='2026-10-15')]);self.assertEqual(self.rows()[0]['dispatchEnd'],'')
    def test_reloading_same_progress_no_double_qty(self):
        self.orders([order(1),order(2)]);self.progress([source_row(office='2026-10-15')]);self.engine.supply_refresh();self.assertEqual(sum(bool(r['dispatchEnd']) for r in self.rows()),1)
    def test_matched_source_fields_show_V_and_J(self):
        self.one();self.progress([source_row(purchase='2026-10-13',qty=30)]);src=self.info()['sources'][0];self.assertEqual(src['qty'],30);self.assertEqual(src['officeDate'],'');self.assertEqual(src['purchaseDate'],'2026-10-13')
    def test_load_counts_use_only_office_evidence(self):
        self.one();self.progress([source_row(purchase='2026-10-13'),source_row(office='2026-10-15')]);c=self.engine.public_state()['supply']['loadedCounts'];self.assertEqual(c['progressWithDate'],1);self.assertEqual(c['progressWithoutOffice'],1)
    def test_retired_manifest_remains_retired_on_restart(self):
        self.one();self.manifest([source_row()]);self.engine.supply_reset({'confirmed':True});self.restart();self.engine.supply_refresh();self.assertTrue(all(b['closed'] for b in self.store.read()['supply']['manifests'].values()));self.assertEqual(self.rows()[0]['dispatchEnd'],'2026-10-19')
    def test_failure_to_read_keeps_previous_normal_snapshot(self):
        self.one();self.progress([source_row(office='2026-10-16')]);(self.folder/'진행상황.xlsx').write_bytes(b'bad');
        with self.assertRaises(SupplyError):self.engine.supply_refresh()
        self.assertEqual(self.rows()[0]['dispatchEnd'],'2026-10-22')

    def test_v069_restart_does_not_require_new_login(self):
        self.one()
        with self.store.edit() as state:state['appVersion']='0.6.9'
        self.restart();self.assertTrue(self.engine.creds);self.assertFalse(self.fake.sent)
    def test_v069_restart_keeps_future_reservation(self):
        self.one();key=self.rows()[0]['key'];self.queue(keys=[key],sendMode='MORNING');previous=self.last()
        with self.store.edit() as state:state['appVersion']='0.6.9'
        self.restart();n=self.last();self.assertEqual(n['id'],previous['id']);self.assertEqual(n['scheduledAt'],previous['scheduledAt']);self.assertNotEqual(n['status'],'CANCELLED');self.assertFalse(self.fake.sent)
    def test_sealed_quantity_not_reissued_to_next_order(self):
        self.orders([order(1),order(2)]);self.manifest([source_row()]);self.engine.supply_reset({'confirmed':True})
        with self.store.edit() as s:s['rows'][0]['active']=False
        r=next(r for r in self.rows() if r['orderId']=='TEST-002');self.assertEqual(r['dispatchEnd'],'');self.assertFalse(r['stockSecured'])

if __name__=='__main__':unittest.main()
