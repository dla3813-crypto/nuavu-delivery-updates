"""지그재그 배송연기 안내 + 변경 발송 예정일 동기화: pure rules, matching, controller with a fake browser run."""
import sys,unittest
from pathlib import Path
from unittest.mock import MagicMock
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
try:
    from test_v056 import Base
except ImportError:
    from helpers import Base
try:
    from test_v068 import order
except ImportError:
    from test_supply_regression import order
from zigzag_browser import choose_change_date,iso_day,business_days_after
from zigzag_sync import ZigzagSyncController,ZigzagSyncError,ZIGZAG,match_rows,plan_pushes,apply_snapshot

def zz(item='185478058381080807',oid='139777491508015680',ship='2026.10.21 23:59:59 (3 영업일)',changed='-',qty=1):
    return {'itemId':item,'orderId':oid,'status':'배송준비중','shipBy':ship,'changedShipBy':changed,'product':'민트 후드 집업','option':'색상: 원컬러 사이즈: FREE','qty':qty,'recipient':'김나영','sku':'','orderedAt':'2026.10.18 13:21:26',
            'shipByDate':iso_day(ship),'changedDate':iso_day(changed) if changed!='-' else '','currentDate':(iso_day(changed) if changed!='-' else '') or iso_day(ship)}

class RuleTests(unittest.TestCase):
    def test_iso_day(self):
        self.assertEqual(iso_day('2026.10.21 23:59:59 (3 영업일)'),'2026-10-21');self.assertEqual(iso_day('-'),'');self.assertEqual(iso_day(''),'')
    def test_business_days(self):
        from datetime import date
        self.assertEqual([d.isoformat() for d in business_days_after(date(2026,10,21),7)],['2026-10-22','2026-10-23','2026-10-26','2026-10-27','2026-10-28','2026-10-29','2026-10-30'])
    def test_same_or_earlier_date_sends_nothing(self):
        self.assertEqual(choose_change_date('2026-10-21','2026-10-21')[0],'');self.assertEqual(choose_change_date('2026-10-20','2026-10-21')[0],'')
        self.assertIn('이후가 아니어서',choose_change_date('2026-10-21','2026-10-21')[1])
    def test_later_weekday_is_sent_as_is(self):
        self.assertEqual(choose_change_date('2026-10-23','2026-10-21'),('2026-10-23',''))
    def test_weekend_moves_to_next_weekday_and_range_limit(self):
        d,why=choose_change_date('2026-10-24','2026-10-21');self.assertEqual(d,'2026-10-26');self.assertIn('주말',why)
        self.assertEqual(choose_change_date('2026-11-02','2026-10-21')[0],'');self.assertIn('7영업일',choose_change_date('2026-11-02','2026-10-21')[1])
    def test_bad_input(self):self.assertEqual(choose_change_date('x','2026-10-21')[0],'')

class MatchTests(Base):
    def setUp(self):
        super().setUp()
        with self.store.edit() as s:s['rows']=[]
        self.engine.import_rows({'rows':[order(1)|{'orderId':'139777491508015680','orderItemId':'185478058381080807','seller':ZIGZAG},
                                         order(2)|{'orderId':'139777000000000002','seller':ZIGZAG},
                                         order(3)|{'orderId':'139777000000000003','seller':ZIGZAG},order(4)|{'orderId':'139777000000000003','seller':ZIGZAG,'product':'다른 상품'},
                                         order(5)|{'orderId':'12345','orderItemId':'801','seller':'누아브 에이블리'}]})
        self.rows={(r['orderId'],r['product']):r for r in self.store.read()['rows']}
    def test_item_id_then_single_order_fallback(self):
        pairs=match_rows(self.store.read(),[zz(),zz(item='2',oid='139777000000000002'),zz(item='3',oid='139777000000000003'),zz(item='9',oid='139777000000000009')])
        self.assertEqual(pairs[0][1]['orderId'],'139777491508015680');self.assertEqual(pairs[1][1]['orderId'],'139777000000000002')
        self.assertIsNone(pairs[2][1]);self.assertIn('여러 개',pairs[2][2]);self.assertIsNone(pairs[3][1]);self.assertIn('없는',pairs[3][2])
    def test_plan_only_later_dates_and_once(self):
        key=self.rows[('139777491508015680',order(1)['product'])]['key']
        self.engine.external_manual({'keys':[key],'dueDate':'2026-10-21'})
        targets,skipped=plan_pushes(self.store.read(),[zz()],[key],'2026-10-19')
        self.assertEqual(targets,[]);self.assertIn('이후가 아니어서',skipped[0]['reason'])
        self.engine.external_manual({'keys':[key],'dueDate':'2026-10-23'})
        targets,skipped=plan_pushes(self.store.read(),[zz()],[key],'2026-10-19')
        self.assertEqual([(t['itemId'],t['sendDate']) for t in targets],[('185478058381080807','2026-10-23')])
        targets,skipped=plan_pushes(self.store.read(),[zz(changed='2026.10.22 23:59:59')],[key],'2026-10-19')
        self.assertEqual(targets,[]);self.assertIn('1회만',skipped[0]['reason']);self.assertTrue(skipped[0]['quiet']);self.assertFalse(skipped[0]['reconcileSent'])
        self.engine.external_manual({'keys':[key],'dueDate':'2026-10-21'})
        self.assertTrue(plan_pushes(self.store.read(),[zz()],[key],'2026-10-19')[1][0]['quiet'])  # not later: rule, not an error
        self.engine.external_manual({'keys':[key],'dueDate':'2026-11-05'})
        self.assertFalse(plan_pushes(self.store.read(),[zz()],[key],'2026-10-19')[1][0]['quiet'])  # beyond 7 business days: needs attention
        self.assertEqual(plan_pushes(self.store.read(),[zz()],['other'],'2026-10-19'),([],[]))
    def test_sync_records_changed_dates_only(self):
        r=apply_snapshot(self.engine,{'rows':[zz(changed='2026.10.27 23:59:59'),zz(item='2',oid='139777000000000002')],'pages':1})
        self.assertEqual((r['changed'],r['items'],r['noChange'],r['unmatched']),(1,1,1,0))
        n=[n for n in self.store.read()['notices'] if n.get('source')=='zigzag_sync'];self.assertEqual(len(n),1);self.assertEqual(n[0]['dueDate'],'2026-10-27');self.assertEqual(n[0]['seller'],ZIGZAG)
        r=apply_snapshot(self.engine,{'rows':[zz(changed='2026.10.27 23:59:59')],'pages':1});self.assertEqual((r['items'],r['unchanged']),(0,1))
        row=self.engine.public_state()['rows'];me=[x for x in row if x['orderId']=='139777491508015680'][0];self.assertEqual(me['dueDate'],'2026-10-27')

class ControllerTests(Base):
    def setUp(self):
        super().setUp()
        with self.store.edit() as s:s['rows']=[]
        self.engine.import_rows({'rows':[order(1)|{'orderId':'139777491508015680','orderItemId':'185478058381080807','seller':ZIGZAG}]})
        self.key=self.store.read()['rows'][0]['key']
        self.vault=MagicMock(available=True);self.vault.load.return_value=dict(version=1,username='fake',password='FAKE-SECRET',shop='nuavu')
        self.calls=[]
        def runner(account,stop,progress,planner=None,push_only=False):
            self.calls.append((push_only,account['shop']))
            rows=[zz()];pushes=[]
            if planner:
                targets,skipped=planner(rows);pushes=list(skipped)+[dict(t,status='sent',reason='',platformNotice=t['sendDate']) for t in targets]
            return {'rows':rows,'total':1,'pages':1,'pushes':pushes,'pushOnly':push_only,'complete':True}
        self.c=ZigzagSyncController(self.engine,runner=runner,vault=self.vault)
    def test_sync_then_push_only(self):
        self.c.start();self.c.thread.join(4);st=self.c.status();self.assertEqual(st['phase'],'done',st);self.assertIn('지그재그 배송준비중 1건',st['message'])
        self.engine.external_manual({'keys':[self.key],'dueDate':'2026-10-23'})
        self.c.start_push_only([self.key]);self.c.thread.join(4);st=self.c.status()
        self.assertEqual(st['phase'],'done',st);self.assertTrue(st['pushOnly']);self.assertEqual(self.calls,[(False,'nuavu'),(True,'nuavu')])
        log=self.store.read()['zigzagPushLog'];self.assertEqual([(p['itemId'],p['status'],p['sendDate']) for p in log],[('185478058381080807','sent','2026-10-23')])
        self.assertIn('변경 발송 예정일은 가져오지 않았습니다',st['message']);self.assertEqual(len([n for n in self.store.read()['notices'] if n.get('source')=='zigzag_sync']),0)
        self.assertNotIn('FAKE-SECRET',str(st))
    def test_failed_then_seen_on_zigzag_is_reconciled_quietly(self):
        from zigzag_sync import record_pushes
        from domain import now
        self.engine.external_manual({'keys':[self.key],'dueDate':'2026-10-23'})
        nid=[n for n in self.store.read()['notices'] if self.key in n.get('itemKeys',[])][-1]['id']
        with self.store.edit() as s:record_pushes(s,[{'itemId':'185478058381080807','orderId':'139777491508015680','key':self.key,'dueDate':'2026-10-23','noticeId':nid,'sendDate':'2026-10-23','status':'failed','reason':'strict mode violation'}],now())
        targets,skipped=plan_pushes(self.store.read(),[zz(changed='2026.10.23 23:59:59')],[self.key],'2026-10-19')
        self.assertEqual(targets,[]);self.assertTrue(skipped[0]['reconcileSent'])
        with self.store.edit() as s:counts=record_pushes(s,skipped,now())
        self.assertEqual((counts['pushRule'],counts['pushSkipped']),(1,0))
        n=[n for n in self.store.read()['notices'] if n['id']==nid][0];self.assertTrue(any('전송 확인' in e['note'] for e in n['events']))
    def test_push_only_equal_date_sends_nothing(self):
        self.engine.external_manual({'keys':[self.key],'dueDate':'2026-10-21'})
        self.c.start_push_only([self.key]);self.c.thread.join(4);st=self.c.status()
        self.assertEqual(st['phase'],'done');self.assertIn('대상이 없습니다',st['message']);self.assertIn('규칙상 제외',st['message'])
        alerts=self.store.read().get('alerts',[]);self.assertFalse(any(a['level']=='error' for a in alerts))
    def test_push_all_uses_rows_with_app_notice(self):
        with self.assertRaises(ZigzagSyncError):self.c.start_push_all()
        self.engine.external_manual({'keys':[self.key],'dueDate':'2026-10-23'})
        self.c.start_push_all();self.c.thread.join(4);self.assertEqual(self.c.status()['phase'],'done');self.assertEqual(self.calls,[(True,'nuavu')])
    def test_requires_keys(self):
        with self.assertRaises(ZigzagSyncError):self.c.start_push_only([])

if __name__=='__main__':unittest.main()
