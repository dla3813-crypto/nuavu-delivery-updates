import sys,socket
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
@pytest.fixture(autouse=True)
def prohibit_live_network(monkeypatch):
    def forbidden(*args,**kwargs):raise AssertionError('Tests prohibit all live network connections')
    monkeypatch.setattr(socket,'create_connection',forbidden)
