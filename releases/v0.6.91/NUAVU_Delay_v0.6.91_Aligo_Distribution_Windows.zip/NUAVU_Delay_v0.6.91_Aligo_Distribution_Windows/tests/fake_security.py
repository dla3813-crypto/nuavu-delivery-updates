import copy
from credentials import VaultError
class MemoryVault:
    available=True
    name='fake keychain'
    def __init__(self):self.data=None;self.loads=0;self.saves=0;self.fail_load=False;self.fail_save=False;self.fail_delete=False
    def load(self):
        self.loads+=1
        if self.fail_load:raise VaultError('접근 거부 (모의)')
        return copy.deepcopy(self.data)
    def save(self,payload):
        if self.fail_save:raise VaultError('저장 거부 (모의)')
        self.saves+=1;self.data=copy.deepcopy(payload)
    def delete(self):
        if self.fail_delete:raise VaultError('삭제 거부 (모의)')
        self.data=None

class FakeSecurity:
    # Same constants/call signatures as PyObjC Security; all storage is an in-memory dict.
    errSecItemNotFound=-25300;errSecDuplicateItem=-25299
    def __init__(self):self.item=None;self.operations=[];self.force=None
    def __getattr__(self,name):
        if name.startswith('kSec'):return name
        raise AttributeError(name)
    def SecItemCopyMatching(self,q,out):
        self.operations.append(('read',copy.deepcopy(q)))
        return (self.force,None) if self.force else ((0,self.item['kSecValueData']) if self.item else (-25300,None))
    def SecItemUpdate(self,q,fields):
        self.operations.append(('update',copy.deepcopy(q)))
        if self.force:return self.force
        if self.item is None:return -25300
        self.item.update(fields);return 0
    def SecItemAdd(self,q,out):
        self.operations.append(('add',{k:v for k,v in q.items() if k!='kSecValueData'}))
        if self.force:return (self.force,None)
        if self.item:return (-25299,None)
        self.item=dict(q);return (0,None)
    def SecItemDelete(self,q):
        self.operations.append(('delete',dict(q)))
        if self.force:return self.force
        if self.item is None:return -25300
        self.item=None;return 0
