"""지그재그(카카오스타일 파트너센터) 반품/교환 — 2026-10-20 요청 (공통).

반품체크·지금 조회 / 교환·지금 조회 때 저장된 지그재그 계정(로그인 아이디가 이메일일 때만)으로 파트너센터에 들어가
반품요청·반품수거중, 교환요청·교환수거중 목록을 읽어 에이블리 반품 행과 같은 모양으로 바꾼다. 엑셀 다운로드 대신
목록 표를 직접 읽는다(열 구성이 같고, 개인정보 파일을 다운로드 폴더에 남기지 않는다). 그 뒤 택배사 조회는 에이블리 반품과
같은 코드(ReturnFlow.lookup)를 쓴다.

실측 DOM (2026-10-20, shop nuavu):
- 목록 주소: /shop/<shop>/order_item/list/return?status_option=<status>&page=N&date_range_option=date_requested&from=946652400000&to=<ms>
  (from=2000-01-01 = 조회기간 전체, 조회 버튼 없이 바로 열린다). status_option: 반품요청 return_requested · 반품수거중 return_collecting ·
  반품수거완료 return_collected / 교환: exchange_requested · exchange_collecting · exchange_collected. 탭을 클릭하면 기간이 1주일로
  돌아가므로 항상 주소로 연다.
- 표: table thead th 머리글(상품주문번호·주문번호·반품요청일·주문상태·반품사유·반품수거방법·원송장 정보("우체국 6082…")·반품송장번호·
  수령인명·수령인 연락처·구매자명·상품명·옵션정보("색상: 차콜 사이즈: FREE")·수량·반품비용 지불방법(차감=고객 변심, -=판매자 귀책)·
  클레임 번호). 제목 "반품수거중 목록 (6건)". 페이지 버튼 aria-label "N 페이지"/"다음 페이지", 기본 50개씩.
- 교환 표는 한 교환이 교환전/교환후 두 행(교환구분)으로 나오고 둘 다 체크박스가 있다(아무거나 눌러도 됨). 원송장은 상품주문번호
  버튼 → .pds-modal-wrapper 상세의 배송정보 th 송장번호/배송완료일에 있다. 닫기 버튼 "닫기".
- 처리 버튼(체크 전엔 disabled): 반품접수·수거완료 / 교환접수·교환 수거완료. 수거완료를 누르면 .pds-modal-wrapper
  "선택하신 1건의 상품주문을 수거완료 처리 하시겠습니까?" + 취소/확인. 확인 뒤 다음 카드(반품수거완료 등)에서 같은 상품주문번호를 확인한다.
"""
from __future__ import annotations
import hashlib,json,re,time
from datetime import datetime,timezone
from zigzag_browser import Reader,ZigzagError,ZigzagCancelled,PARTNERS
from return_data import invoice as clean_invoice,iso,ReturnError

ZIGZAG='지그재그'
LIST_URL=PARTNERS+'/shop/{shop}/order_item/list/{kind}?status_option={status}&page={page}&date_range_option=date_requested&from=946652400000&to={to}'
RETURN_STATUS={'반품요청':'return_requested','반품수거중':'return_collecting','반품수거완료':'return_collected'}
EXCHANGE_STATUS={'교환요청':'exchange_requested','교환수거중':'exchange_collecting','교환수거완료':'exchange_collected'}
RETURN_COLUMNS={'itemId':'상품주문번호','orderId':'주문번호','requestedAt':'반품요청일','status':'주문상태','reason':'반품사유','orig':'원송장 정보',
                'returnNo':'반품송장번호','customer':'구매자명','recipient':'수령인명','recipientPhone':'수령인 연락처','product':'상품명','option':'옵션정보',
                'qty':'수량','payMethod':'반품비용 지불방법','requestId':'클레임 번호'}
EXCHANGE_COLUMNS={'itemId':'상품주문번호','orderId':'주문번호','part':'교환구분','status':'주문상태','reason':'교환사유','payMethod':'교환비용 지불방법',
                  'product':'상품명','option':'옵션정보','qty':'수량','customer':'구매자명','recipient':'수령인명','recipientPhone':'수령인 연락처','requestedAt':'교환요청일'}
ACTIONS={('return','반품요청'):('반품접수','반품수거중'),('return','반품수거중'):('수거완료','반품수거완료'),
         ('exchange','교환요청'):('교환접수','교환수거중'),('exchange','교환수거중'):('교환 수거완료','교환수거완료')}
STATUS_OF={'return':RETURN_STATUS,'exchange':EXCHANGE_STATUS}
MAX_PAGES=200
SETTLE_MS=1500   # 카드 숫자·목록이 뒤늦게 채워지므로 화면이 뜬 뒤 1.5초 더 기다렸다가 읽는다 (2026-10-20 04:22 요청)

READ_JS='''(cols)=>{
 const norm=s=>(s||'').replace(/\\s+/g,' ').trim();
 const heads=[...document.querySelectorAll('table thead th')].map(th=>norm(th.innerText));
 const leaf=[...document.querySelectorAll('h2,h3,h4,p,span,div,strong')].filter(e=>e.children.length===0).map(e=>norm(e.innerText));
 const title=leaf.find(t=>/목록\\s*\\(\\d[\\d,]*건\\)/.test(t))||'';
 const tab=[...document.querySelectorAll('[role=tab]')].find(e=>e.getAttribute('aria-selected')==='true');
 const pages=[...document.querySelectorAll('button[aria-label$="페이지"]')].map(b=>b.getAttribute('aria-label'));
 const base={title,tab:tab?norm(tab.innerText.split('\\n')[0]):'',pages,modal:document.querySelectorAll('.pds-modal-wrapper').length,bodyRows:document.querySelectorAll('table tbody tr').length};
 const idx={};for(const [k,h] of Object.entries(cols)){const i=heads.indexOf(h);if(i<0)return {...base,missing:h,heads,rows:[]};idx[k]=i;}
 const rows=[...document.querySelectorAll('table tbody tr')].map(tr=>{const o={};for(const [k,i] of Object.entries(idx))o[k]=norm(tr.children[i]?.innerText);o.checkbox=!!tr.querySelector('input[type=checkbox]');return o;});
 return {...base,rows};
}'''

def is_email_login(username):return bool(re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',str(username or '').strip()))

def parse_option(text):
    t=str(text or '').strip()
    m=re.search(r'색상\s*:\s*(.*?)\s*(?:-\s*)?사이즈\s*:\s*(.*)$',t)
    if m:return (m.group(1).strip(' -')+' / '+m.group(2).strip(' -')).strip(' /')
    return re.sub(r'^-\s*','',t)

def parse_day(text):
    m=re.search(r'(\d{4})[.\-/](\d{1,2})[.\-/](\d{1,2})',str(text or ''))
    return f'{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}' if m else ''

def parse_qty(text):
    m=re.search(r'\d+',str(text or ''));return int(m.group(0)) if m else 1

def reason_text(reason,pay_method):
    """지그재그 반품비용 지불방법: 차감 = 고객(단순변심), - = 판매자 귀책 (2026-10-20 설명)."""
    who='판매자' if str(pay_method or '').strip() in ('','-') else '고객'
    return f'{who}({str(reason or "").strip() or "사유 없음"})'

def parse_orig(text):
    """'우체국 6082036144359' → (carrier name, invoice)."""
    t=str(text or '').strip()
    m=re.search(r'(\d[\d\-\s]{9,})\s*$',t)
    number=clean_invoice(m.group(1)) if m else ''
    carrier=t[:m.start()].strip() if m else t
    return carrier,number

def row_key(kind,item_id,request_id):
    return ('zigzag-exchange:' if kind=='exchange' else 'zigzag:')+hashlib.sha256(json.dumps([item_id,request_id],ensure_ascii=False).encode()).hexdigest()

def return_entry(raw,status_label):
    carrier,number=parse_orig(raw.get('orig'))
    r={'seller':ZIGZAG,'kind':'return','zigzagStatus':status_label,'itemId':raw.get('itemId',''),'orderId':raw.get('orderId',''),'product':raw.get('product',''),
       'option':parse_option(raw.get('option')),'qty':parse_qty(raw.get('qty')),'requestedAt':parse_day(raw.get('requestedAt')),'reason':reason_text(raw.get('reason'),raw.get('payMethod')),
       'payMethod':str(raw.get('payMethod') or '').strip(),'fee':0,'customer':raw.get('customer',''),'recipient':raw.get('recipient',''),'recipientPhone':raw.get('recipientPhone',''),
       'invoice':number,'origCarrierName':carrier,'returnNo':clean_invoice(raw.get('returnNo')) if str(raw.get('returnNo') or '').strip() not in ('','-') else '',
       'requestId':str(raw.get('requestId') or '').strip() or raw.get('itemId','')}
    if not r['itemId'] or not r['orderId'] or not r['product'] or not r['requestedAt']:raise ReturnError('지그재그 반품 표의 상품주문번호·주문번호·상품명·반품요청일을 확인하지 못했습니다.')
    r['key']=row_key('return',r['itemId'],r['requestId']);return r

def exchange_entries(raws,status_label):
    """교환전 row carries the claim; the following 교환후 row only supplies the requested option."""
    out=[];i=0
    while i<len(raws):
        raw=raws[i];i+=1
        if raw.get('part')!='교환전':continue
        after=raws[i] if i<len(raws) and raws[i].get('part')=='교환후' else {}
        if after:i+=1
        r={'seller':ZIGZAG,'kind':'exchange','zigzagStatus':status_label,'exchangeStatus':status_label,'itemId':raw.get('itemId',''),'orderId':raw.get('orderId',''),
           'product':raw.get('product',''),'option':parse_option(raw.get('option')),'exchangeOption':parse_option(after.get('option')) if after else '',
           'qty':parse_qty(raw.get('qty')),'requestedAt':parse_day(raw.get('requestedAt')),'reason':reason_text(raw.get('reason'),raw.get('payMethod')),
           'payMethod':str(raw.get('payMethod') or '').strip(),'fee':0,'customer':raw.get('customer',''),'recipient':raw.get('recipient',''),'recipientPhone':raw.get('recipientPhone',''),
           'invoice':'','returnNo':'','requestId':raw.get('itemId',''),'exchangeAfterItemId':after.get('itemId','')}
        if not r['itemId'] or not r['orderId'] or not r['product']:raise ReturnError('지그재그 교환 표의 상품주문번호·주문번호·상품명을 확인하지 못했습니다.')
        r['key']=row_key('exchange',r['itemId'],r['requestId']);out.append(r)
    return out

def list_total(title):
    m=re.search(r'목록\s*\((\d[\d,]*)건\)',title or '')
    return int(m.group(1).replace(',','')) if m else None

def zigzag_enabled(store_directory,vault=None):
    """(account or None, note). Only a saved account whose login id is an e-mail is used (2026-10-20 rule)."""
    try:
        from zigzag_credentials import ZigzagAccounts
        info=ZigzagAccounts(store_directory,vault).info()
    except Exception as exc:return None,'지그재그 계정 확인 실패 · '+str(exc)
    if not info.get('hasPassword'):return None,'지그재그 계정 없음 · 지그재그 반품은 조회하지 않습니다.'
    if not is_email_login(info.get('username')):return None,'지그재그 로그인 아이디가 이메일이 아니어서 지그재그 반품은 조회하지 않습니다.'
    return info,''

class ZigzagClaims(Reader):
    """Partner-center list reader + 처리 버튼 actions. `controller` must offer check(), update(phase,message), stop (Event)."""
    def __init__(self,controller,context,shop):
        self.c=controller;self.shop=shop
        super().__init__(context.new_page(),controller.stop,lambda m:controller.update('running',m),context)
    def login_account(self,account):
        try:
            from aftersales_data import shop as _shop;shop_name=_shop(self.c.engine.store.read())['shopName']
        except Exception:shop_name=''
        self.login({**account,'shop':self.shop,'shopName':account.get('shopName') or shop_name})
        # 2026-10-20: enter through the dashboard (https://partners.kakaostyle.com/shop/<shop>/stats) like a person would, then open the lists by address.
        self.step='지그재그 대시보드';self.progress('지그재그 대시보드를 엽니다.')
        try:self.live_page().goto(PARTNERS+f'/shop/{self.shop}/stats',wait_until='domcontentloaded',timeout=45000)
        except Exception:pass
        self.wait(lambda:self.entered(self.shop,account.get('shopName') or shop_name),'지그재그 대시보드가 열리지 않았습니다. 로그인 상태를 확인하세요.',40)
        self.dashboard_counts={}
        try:
            text=self.live_page().locator('body').inner_text(timeout=5000)
            for label in ('반품요청','교환요청'):
                m=re.search(re.escape(label)+r'\s*(\d[\d,]*)\s*건',text)
                if m:self.dashboard_counts[label]=int(m.group(1).replace(',',''))
        except Exception:pass
    # ---- lists
    def open_list(self,kind,status_label,page=1):
        status=STATUS_OF[kind][status_label];to=int(time.time()*1000)+86400000
        self.step=f'지그재그 {status_label} 목록 {page}페이지';self.check()
        self.live_page().goto(LIST_URL.format(shop=self.shop,kind=kind,status=status,page=page,to=to),wait_until='domcontentloaded',timeout=45000)
        cols=RETURN_COLUMNS if kind=='return' else EXCHANGE_COLUMNS
        def ready():
            try:data=self.live_page().evaluate(READ_JS,cols)
            except Exception:return None
            if data['tab']!=status_label or list_total(data['title']) is None:return None
            # 0건: the empty list renders no header row at all (04:18 보고) — a normal, empty result, not an error.
            if data.get('missing') and list_total(data['title'])==0 and not data.get('bodyRows'):return data
            if data.get('missing') and not data.get('bodyRows'):return None   # still loading
            return data
        data=self.wait(ready,f'지그재그 {status_label} 목록이 열리지 않았습니다.',40)
        # 2026-10-20 04:22: the card counts/list fill a moment after the page shows — settle, then read again and require the same result.
        self.live_page().wait_for_timeout(SETTLE_MS)
        again=ready()
        if again is None or again.get('title')!=data.get('title') or len(again.get('rows',[]))!=len(data.get('rows',[])):
            self.live_page().wait_for_timeout(SETTLE_MS);again=self.wait(ready,f'지그재그 {status_label} 목록이 안정되지 않았습니다.',20)
        data=again
        if data.get('missing') and list_total(data['title'])!=0:
            raise ZigzagError(f'지그재그 {status_label} 표에 "{data["missing"]}" 열이 없습니다. 열: 목록보기 설정에서 기본 열을 켜세요.')
        return data
    def read_all(self,kind,status_label):
        entries=[];total=None;seen=set()
        for page in range(1,MAX_PAGES+1):
            data=self.open_list(kind,status_label,page);n=list_total(data['title'])
            if total is None:total=n
            elif n!=total:raise ZigzagError(f'지그재그 {status_label} 건수가 조회 중 바뀌었습니다 ({total}→{n}).')
            rows=data['rows']
            if not rows:
                if page==1 and total==0:break
                raise ZigzagError(f'지그재그 {status_label} {page}페이지가 비어 있습니다.')
            entries.extend(rows)
            pages=[p for p in data['pages'] if re.fullmatch(r'\d+ 페이지',p or '')]
            if not pages or page>=max(int(p.split()[0]) for p in pages):break
        if kind=='return':
            parsed=[return_entry(r,status_label) for r in entries]
        else:parsed=exchange_entries(entries,status_label)
        for r in parsed:
            if r['key'] in seen:raise ZigzagError(f'지그재그 {status_label} 목록에 같은 상품주문번호가 두 번 있습니다.')
            seen.add(r['key'])
        if total is not None and len(parsed)!=total:
            raise ZigzagError(f'지그재그 {status_label} 목록 {total}건과 읽은 행 {len(parsed)}건이 다릅니다.')
        return parsed,total or 0
    def exchange_invoice(self,kind,status_label,item_id):
        """Open the 상품주문번호 detail modal of that 교환전 row and read 배송정보 › 송장번호 / 배송완료일."""
        page=self.live_page();self.step=f'지그재그 교환 상세 ({item_id})'
        heads=page.locator('table thead th').all_inner_texts();col=[re.sub(r'\s+',' ',h).strip() for h in heads].index('상품주문번호')
        rows=page.locator('table tbody tr').filter(has=page.locator(f'td:nth-child({col+1})',has_text=re.compile(r'^\s*'+re.escape(item_id)+r'\s*$')))
        if rows.count()<1:raise ZigzagError('교환 상품 행을 찾지 못했습니다.')
        rows.first.locator(f'td:nth-child({col+1}) button').first.click(timeout=5000)
        modal=page.locator('.pds-modal-wrapper').last
        self.wait(lambda:modal.count()==1 and '송장번호' in modal.inner_text(),'교환 상세가 열리지 않았습니다.',15)
        def cell(name):
            th=modal.locator('th',has_text=re.compile(r'^\s*'+re.escape(name)+r'\s*$'))
            if th.count()<1:return ''
            return re.sub(r'\s+',' ',th.first.locator('xpath=following-sibling::td[1]').inner_text()).strip()
        out={'invoice':clean_invoice(cell('송장번호')),'carrierName':cell('택배사'),'delivered':parse_day(cell('배송완료일')),'claimState':cell('클레임상태')}
        close=modal.locator('button',has_text=re.compile(r'^\s*닫기\s*$'))
        if close.count()<1:raise ZigzagError('교환 상세 닫기 버튼을 찾지 못했습니다.')
        close.last.click(timeout=5000);self.wait(lambda:page.locator('.pds-modal-wrapper').count()==0,'교환 상세가 닫히지 않았습니다.',10)
        return out
    def collect(self,want_returns=True,want_exchanges=True):
        rows=[];totals={}
        if want_returns:
            for label in ('반품요청','반품수거중'):
                self.progress(f'지그재그 {label} 목록을 읽습니다.');parsed,total=self.read_all('return',label);totals[label]=total;rows.extend(parsed)
        if want_exchanges:
            for label in ('교환요청','교환수거중'):
                self.progress(f'지그재그 {label} 목록을 읽습니다.');parsed,total=self.read_all('exchange',label);totals[label]=total
                for n,r in enumerate(parsed,1):
                    self.progress(f'지그재그 {label} {n}/{len(parsed)} · 상품주문번호 {r["itemId"]} 상세에서 원송장 확인')
                    page_no=1
                    # the detail is opened from the list page that holds the row: reopen page 1 and walk pages until found
                    while True:
                        data=self.open_list('exchange',label,page_no)
                        if any(x.get('itemId')==r['itemId'] for x in data['rows']):break
                        pages=[int(p.split()[0]) for p in data['pages'] if re.fullmatch(r'\d+ 페이지',p or '')]
                        if not pages or page_no>=max(pages):raise ZigzagError('교환 상세를 열 행을 찾지 못했습니다.')
                        page_no+=1
                    try:detail=self.exchange_invoice('exchange',label,r['itemId'])
                    except ZigzagCancelled:raise
                    except Exception as exc:detail={'invoice':'','note':str(exc)[:120]}
                    r['invoice']=detail.get('invoice','');r['origCarrierName']=detail.get('carrierName','');r['origDeliveredHint']=detail.get('delivered','')
                rows.extend(parsed)
        return rows,totals
    # ---- actions
    def act(self,kind,status_label,item_id):
        """Check the row (first checkbox of that 상품주문번호), press the status button, confirm the modal, then verify in the next card."""
        button_label,next_label=ACTIONS[(kind,status_label)]
        page_no=1;found=False
        while not found:
            data=self.open_list(kind,status_label,page_no)
            if any(x.get('itemId')==item_id for x in data['rows']):found=True;break
            pages=[int(p.split()[0]) for p in data['pages'] if re.fullmatch(r'\d+ 페이지',p or '')]
            if not pages or page_no>=max(pages):break
            page_no+=1
        page=self.live_page()
        if not found:
            # Maybe already processed: look in the next card.
            if self.exists(kind,next_label,item_id):return {'result':f'지그재그 {button_label} 완료','note':f'이미 {next_label} 카드에 있습니다.','already':True}
            return {'result':f'지그재그 {button_label} 실패','note':f'{status_label} 목록에서 상품주문번호 {item_id}를 찾지 못했습니다.'}
        heads=[re.sub(r'\s+',' ',h).strip() for h in page.locator('table thead th').all_inner_texts()];col=heads.index('상품주문번호')
        rows=page.locator('table tbody tr').filter(has=page.locator(f'td:nth-child({col+1})',has_text=re.compile(r'^\s*'+re.escape(item_id)+r'\s*$')))
        if rows.count()<1:raise ZigzagError('처리할 행을 찾지 못했습니다.')
        self.step=f'지그재그 {button_label} · {item_id} 선택'
        box=rows.first.locator('input[type=checkbox]').first
        box.click(timeout=5000);self.check()
        self.wait(lambda:box.is_checked(),'행 선택이 되지 않았습니다.',5)
        checked=page.locator('table tbody input[type=checkbox]:checked').count()
        if checked!=1:raise ZigzagError(f'선택된 행이 {checked}개입니다. 한 건만 처리합니다.')
        button=page.locator('button',has_text=re.compile(r'^\s*'+re.escape(button_label)+r'\s*$'))
        if button.count()!=1:raise ZigzagError(f'{button_label} 버튼을 하나로 찾지 못했습니다.')
        self.wait(lambda:button.first.is_enabled(),f'{button_label} 버튼이 활성화되지 않았습니다.',5)
        self.step=f'지그재그 {button_label} 버튼';button.first.click(timeout=5000)
        modal=page.locator('.pds-modal-wrapper').last
        self.wait(lambda:modal.count()==1 and modal.is_visible(),f'{button_label} 확인 창이 열리지 않았습니다.',10)
        text=re.sub(r'\s+',' ',modal.inner_text())
        confirm=modal.locator('button',has_text=re.compile(r'^\s*확인\s*$'));cancel=modal.locator('button',has_text=re.compile(r'^\s*취소\s*$'))
        if not re.search(r'선택하신\s*1\s*건',text) or '하시겠습니까' not in text or confirm.count()!=1 or modal.locator('input,select,textarea').count():
            if cancel.count():cancel.first.click(timeout=5000)
            return {'result':f'지그재그 {button_label} 보류','note':'확인 창 내용이 예상과 달라 누르지 않았습니다: '+text[:120]}
        self.step=f'지그재그 {button_label} 확인';self.clicked=True;confirm.first.click(timeout=5000)
        try:self.wait(lambda:page.locator('.pds-modal-wrapper').count()==0,'확인 창이 닫히지 않았습니다.',15)
        except ZigzagError as exc:
            left=re.sub(r'\s+',' ',page.locator('.pds-modal-wrapper').last.inner_text())[:160] if page.locator('.pds-modal-wrapper').count() else ''
            return {'result':f'지그재그 {button_label} 확인 필요','note':str(exc)+(' · '+left if left else '')}
        page.wait_for_timeout(SETTLE_MS)
        if self.exists(kind,next_label,item_id):return {'result':f'지그재그 {button_label} 완료','note':f'{next_label} 카드에서 확인'}
        return {'result':f'지그재그 {button_label} 확인 필요','note':f'확인은 눌렀지만 {next_label} 카드에서 상품주문번호 {item_id}를 찾지 못했습니다. 파트너센터에서 직접 확인하세요. 다시 누르지 않았습니다.'}
    def exists(self,kind,status_label,item_id):
        page_no=1
        while True:
            data=self.open_list(kind,status_label,page_no)
            if any(x.get('itemId')==item_id for x in data['rows']):return True
            pages=[int(p.split()[0]) for p in data['pages'] if re.fullmatch(r'\d+ 페이지',p or '')]
            if not pages or page_no>=max(pages):return False
            page_no+=1

def _launch(controller,account):
    from playwright.sync_api import sync_playwright
    from return_session import launch_chrome,new_context
    return sync_playwright,launch_chrome,new_context

def collect_zigzag(controller,account,today,want_returns=True,want_exchanges=True,auto_complete=True):
    """Own Chrome: login → lists → (교환 상세 원송장) → 택배사 조회 → 수거완료 처리(사무실 도착분) → rows.
    Returns {'rows','exchangeRows','totals','actions','note'}; raises ZigzagError on a hard failure."""
    from playwright.sync_api import sync_playwright
    from return_session import launch_chrome,new_context
    from return_browser import ReturnFlow
    from return_data import clean_tracking
    with sync_playwright() as pw:
        browser=launch_chrome(pw);context=new_context(browser,accept_downloads=False)
        try:
            flow=ZigzagClaims(controller,context,account.get('shop') or 'nuavu')
            flow.login_account(account)
            rows,totals=flow.collect(want_returns,want_exchanges)
            invoices=list(dict.fromkeys(r['invoice'] for r in rows if r['invoice']))
            if invoices:
                controller.update('running',f'지그재그 반품 {len(rows)}건 · 택배사 조회 {len(invoices)}건')
                tracker=ReturnFlow(controller,context,'지그재그');tracker.page=context.new_page()
                raw=tracker.lookup(invoices)
                try:tracker.page.close()
                except Exception:pass
            else:raw={}
            for r in rows:
                observed=r.get('returnNo','');tr=clean_tracking(raw.get(r['invoice']),r['invoice'],today);r.update(tr)
                if observed and not r['returnNo']:r['returnNo']=observed
                if r.get('kind')=='exchange' and not r.get('origDelivered') and r.get('origDeliveredHint'):r['origDelivered']=r['origDeliveredHint']
            actions=[]
            if auto_complete:
                # 사무실 도착(반품 배달완료) 건: 반품수거중 → 수거완료, 교환수거중 → 교환 수거완료 (2026-10-20 요청).
                for r in rows:
                    if r.get('issue') or r.get('returnStatus')!='DELIVERED':continue
                    label=r.get('zigzagStatus')
                    if (r['kind'],label) not in (('return','반품수거중'),('exchange','교환수거중')):continue
                    controller.check();controller.update('running',f'지그재그 {label} · 상품주문번호 {r["itemId"]} 수거완료 처리')
                    try:res=flow.act(r['kind'],label,r['itemId'])
                    except ZigzagCancelled:raise
                    except Exception as exc:res={'result':'지그재그 수거완료 실패','note':(flow.step+' · ' if flow.step else '')+(str(exc) or type(exc).__name__)[:160]}
                    r['zigzagAction']=res['result'];r['zigzagActionNote']=res.get('note','');r['zigzagActionAt']=datetime.now(timezone.utc).isoformat(timespec='seconds')
                    if res['result'].endswith('완료'):r['zigzagStatus']=ACTIONS[(r['kind'],label)][1]
                    actions.append({'itemId':r['itemId'],'kind':r['kind'],**res})
            return {'rows':[r for r in rows if r['kind']=='return'],'exchangeRows':[r for r in rows if r['kind']=='exchange'],'totals':totals,'actions':actions}
        finally:
            context.close();browser.close()

def accept_zigzag(controller,targets,today):
    """After 이지어드민 회수접수: 반품요청 → 반품접수, 교환요청 → 교환접수, each verified in the 수거중 card.
    targets: [{'invoice','itemId','kind','zigzagStatus'}]. Returns {invoice: {'ablyResult','ablyNote'}} (same display fields as Ably)."""
    from zigzag_credentials import ZigzagAccounts
    from credentials import VaultError
    from playwright.sync_api import sync_playwright
    from return_session import launch_chrome,new_context
    out={}
    if not targets:return out
    info,note=zigzag_enabled(controller.engine.store.directory)
    if not info:return {t['invoice']:{'ablyResult':'지그재그 접수 건너뜀','ablyNote':note} for t in targets}
    try:account=ZigzagAccounts(controller.engine.store.directory).for_login()
    except VaultError as exc:return {t['invoice']:{'ablyResult':'지그재그 접수 실패','ablyNote':str(exc)} for t in targets}
    with sync_playwright() as pw:
        browser=launch_chrome(pw);context=new_context(browser,accept_downloads=False)
        try:
            flow=ZigzagClaims(controller,context,account.get('shop') or 'nuavu')
            try:flow.login_account(account)
            except ZigzagCancelled:raise
            except Exception as exc:
                return {t['invoice']:{'ablyResult':'지그재그 접수 실패','ablyNote':'지그재그 로그인 실패 · '+(str(exc) or type(exc).__name__)[:160]} for t in targets}
            for n,t in enumerate(targets,1):
                controller.check();controller.update('running',f'원송장 {t["invoice"]} · 지그재그 접수 {n}/{len(targets)}')
                kind=t.get('kind') or 'return';label=t.get('zigzagStatus') or ('교환요청' if kind=='exchange' else '반품요청')
                if (kind,label) not in (('return','반품요청'),('exchange','교환요청')):
                    out[t['invoice']]={'ablyResult':'지그재그 접수 건너뜀','ablyNote':f'{label} 상태는 접수 대상이 아닙니다.'};continue
                try:res=flow.act(kind,label,t['itemId'])
                except ZigzagCancelled:raise
                except Exception as exc:res={'result':'지그재그 접수 실패','note':(flow.step+' · ' if flow.step else '')+(str(exc) or type(exc).__name__)[:160]}
                out[t['invoice']]={'ablyResult':res['result'],'ablyNote':res.get('note','')}
        finally:
            try:account.clear()
            except Exception:pass
            context.close();browser.close()
    return out
