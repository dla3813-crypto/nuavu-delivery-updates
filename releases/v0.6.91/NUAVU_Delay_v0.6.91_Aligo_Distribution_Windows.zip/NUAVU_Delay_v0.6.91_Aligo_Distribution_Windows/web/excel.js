/* Small read-only importer: CSV, HTML .xls, BIFF8 .xls, and ordinary .xlsx.
   No formulas are evaluated; no macros or external relationships are executed.
   This is a purpose-built prototype reader, not a general Excel implementation. */
(function(root){
'use strict';
const utf8=new TextDecoder('utf-8'),utf16=new TextDecoder('utf-16le');
function view(a){return new DataView(a.buffer,a.byteOffset,a.byteLength);}
function u16(a,p){if(p+2>a.length)throw Error('파일이 잘렸습니다.');return view(a).getUint16(p,true);}
function u32(a,p){if(p+4>a.length)throw Error('파일이 잘렸습니다.');return view(a).getUint32(p,true);}
function concatenate(parts){const a=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let i=0;for(const p of parts){a.set(p,i);i+=p.length;}return a;}
function csv(text){
 const rows=[];let r=[],v='',quote=false;const delim=(text.split(/\r?\n/,1)[0].split('\t').length>text.split(/\r?\n/,1)[0].split(',').length)?'\t':',';
 for(let i=0;i<text.length;i++){const c=text[i];
  if(quote){if(c==='"'&&text[i+1]==='"'){v+='"';i++;}else if(c==='"')quote=false;else v+=c;}
  else if(c==='"'&&v==='')quote=true;
  else if(c===delim){r.push(v);v='';}
  else if(c==='\n'||c==='\r'){if(c==='\r'&&text[i+1]==='\n')i++;r.push(v);rows.push(r);r=[];v='';}
  else v+=c;
 }
 if(quote)throw Error('CSV 따옴표가 닫히지 않았습니다.');if(v||r.length){r.push(v);rows.push(r);}return rows;
}
function decodeText(a){try{return new TextDecoder('utf-8',{fatal:true}).decode(a).replace(/^\uFEFF/,'');}catch{return new TextDecoder('euc-kr').decode(a).replace(/^\uFEFF/,'');}}
function excelDate(n,date1904=false){const d=new Date(Date.UTC(date1904?1904:1899,date1904?0:11,date1904?1:30)+Math.round(n*86400000));return d.toISOString().slice(0,19).replace('T',' ');}
function isDateFormat(id,custom=''){return (id>=14&&id<=22)||(id>=27&&id<=36)||(id>=45&&id<=47)||(id>=50&&id<=58)||(/[ymdhs]/i.test(custom.replace(/"[^\"]*"/g,'').replace(/\\./g,'').replace(/\[[^\]]*\]/g,''))&&!/general/i.test(custom));}
function safePut(rows,r,c,value){if(r>100000||c>512)throw Error('표의 범위가 너무 큽니다. 주문 데이터만 내보내 주세요.');if(!rows[r])rows[r]=[];rows[r][c]=value;}
function compound(a){
 const sectorSize=2**u16(a,30),miniSize=2**u16(a,32);if(![512,4096].includes(sectorSize))throw Error('지원하지 않는 XLS 섹터 형식입니다.');
 const sectors=Math.floor(a.length/sectorSize)-1;
 const sector=id=>{if(id>=sectors)throw Error('XLS 파일의 섹터 참조가 잘못되었습니다.');return a.subarray((id+1)*sectorSize,(id+2)*sectorSize);};
 const fatIds=[];for(let i=0;i<109;i++){const id=u32(a,76+i*4);if(id<0xfffffffa)fatIds.push(id);}
 let did=u32(a,68);const seenD=new Set();
 for(let k=0;k<u32(a,72)&&did<0xfffffffa;k++){if(seenD.has(did))throw Error('XLS FAT 순환 참조');seenD.add(did);const s=sector(did);for(let j=0;j<sectorSize-4;j+=4){const id=u32(s,j);if(id<0xfffffffa)fatIds.push(id);}did=u32(s,sectorSize-4);}
 const fat=[];for(const id of fatIds.slice(0,u32(a,44))){const s=sector(id);for(let j=0;j<s.length;j+=4)fat.push(u32(s,j));}
 function chain(start,table,get,limit=100000){let id=start;const out=[],seen=new Set();while(id<0xfffffffa){if(seen.has(id)||seen.size>limit||id>=table.length)throw Error('XLS 체인 손상');seen.add(id);out.push(get(id));id=table[id];}return concatenate(out);}
 const directory=chain(u32(a,48),fat,sector),entries=[];
 for(let i=0;i+128<=directory.length;i+=128){const n=u16(directory,i+64);if(n<2||n>64)continue;entries.push({name:utf16.decode(directory.subarray(i,i+n-2)),type:directory[i+66],start:u32(directory,i+116),size:u32(directory,i+120)});}
 const rootEntry=entries.find(e=>e.type===5),book=entries.find(e=>/^(Workbook|Book)$/i.test(e.name));
 if(!book)throw Error('Workbook 스트림이 없습니다. 암호화 파일은 .xlsx로 다시 저장해 주세요.');
 if(book.size>=u32(a,56))return chain(book.start,fat,sector).subarray(0,book.size);
 if(!rootEntry)throw Error('XLS 루트 스트림이 없습니다.');
 const mini=chain(rootEntry.start,fat,sector).subarray(0,rootEntry.size),mfBytes=chain(u32(a,60),fat,sector),mf=[];
 for(let i=0;i+4<=mfBytes.length;i+=4)mf.push(u32(mfBytes,i));
 return chain(book.start,mf,id=>mini.subarray(id*miniSize,(id+1)*miniSize)).subarray(0,book.size);
}
function sharedStrings(segments){
 let si=0,off=0;const boundary=()=>{while(si<segments.length&&off===segments[si].length){si++;off=0;}if(si>=segments.length)throw Error('XLS 공유 문자열이 잘렸습니다.');};
 const byte=()=>{boundary();return segments[si][off++];};const short=()=>byte()|(byte()<<8);const long=()=>{const x=short(),y=short();return (x+y*65536)>>>0;};
 long();const count=long();if(count>1000000)throw Error('공유 문자열이 너무 많습니다.');const result=[];
 for(let j=0;j<count;j++){
  let left=short(),flags=byte(),wide=!!(flags&1),runs=(flags&8)?short():0,ext=(flags&4)?long():0,s='';
  while(left>0){
   // At a CONTINUE boundary within character data, its first byte changes encoding.
   if(si>=segments.length)throw Error('XLS 문자열 손상');
   if(off===segments[si].length){si++;off=0;if(si>=segments.length)throw Error('XLS 문자열 손상');wide=!!(segments[si][off++]&1);}
   const available=Math.floor((segments[si].length-off)/(wide?2:1));const take=Math.min(left,available);
   if(!take)throw Error('지원하지 않는 XLS 문자열 경계입니다. .xlsx로 저장해 주세요.');
   if(wide){s+=utf16.decode(segments[si].subarray(off,off+take*2));off+=take*2;}
   else {for(let z=0;z<take;z++)s+=String.fromCharCode(segments[si][off++]);}
   left-=take;
  }
  for(let k=0;k<runs*4+ext;k++)byte();result.push(s);
 }return result;
}
function unicodeString(a,pos){const len=u16(a,pos),flags=a[pos+2];let p=pos+3;const runs=(flags&8)?u16(a,p):0;if(flags&8)p+=2;if(flags&4)p+=4;return flags&1?utf16.decode(a.subarray(p,p+len*2)):Array.from(a.subarray(p,p+len),c=>String.fromCharCode(c)).join('');}
function biff(a){
 const b=compound(a),records=[];for(let p=0;p+4<=b.length;){const id=u16(b,p),len=u16(b,p+2);if(p+4+len>b.length)break;records.push({id,pos:p,data:b.subarray(p+4,p+4+len)});p+=4+len;}
 if(records.some(r=>r.id===0x2f))throw Error('암호화된 엑셀은 읽을 수 없습니다. 암호를 제거해 다시 저장해 주세요.');
 const sheets=[],formats={},xfs=[];let sst=[],date1904=false;
 for(let i=0;i<records.length;i++){const {id,data:d}=records[i];
  if(id===0x85){const len=d[6],wide=d[7]&1;sheets.push({offset:u32(d,0),name:wide?utf16.decode(d.subarray(8,8+len*2)):Array.from(d.subarray(8,8+len),x=>String.fromCharCode(x)).join(''),type:d[5]});}
  if(id===0xfc){const segments=[d];while(records[i+1]?.id===0x3c)segments.push(records[++i].data);sst=sharedStrings(segments);}
  if(id===0xe0)xfs.push(u16(d,2));if(id===0x41e)formats[u16(d,0)]=unicodeString(d,2);if(id===0x22)date1904=!!u16(d,0);
 }
 if(!sheets.length)throw Error('XLS 시트를 찾지 못했습니다.');
 function number(n,xf){return isDateFormat(xfs[xf],formats[xfs[xf]]||'')?excelDate(n,date1904):n;}
 function rk(n){let v;if(n&2)v=n>>2;else{const a=new Uint8Array(8);view(a).setUint32(4,n&0xfffffffc,true);v=view(a).getFloat64(0,true);}return n&1?v/100:v;}
 return sheets.filter(s=>s.type===0).map(sheet=>{
  const rows=[];let begun=false;
  for(const rec of records){if(rec.pos<sheet.offset)continue;const {id,data:d}=rec;if(id===0x809){if(begun)break;begun=true;continue;}if(id===0x0a&&begun)break;
   if([0xfd,0x203,0x27e,0x204,0x6,0x205].includes(id)&&d.length>=6){const r=u16(d,0),c=u16(d,2),xf=u16(d,4);let val='';
    if(id===0xfd)val=sst[u32(d,6)]??'';
    else if(id===0x203)val=number(view(d).getFloat64(6,true),xf);
    else if(id===0x27e)val=number(rk(u32(d,6)),xf);
    else if(id===0x204)val=unicodeString(d,6);
    else if(id===0x205)val=d[7]?'[엑셀 오류]':d[6]===1?'TRUE':'FALSE';
    else if(id===0x6){val=(d[12]===255&&d[13]===255)?'':number(view(d).getFloat64(6,true),xf);}
    safePut(rows,r,c,val);
   }
   if(id===0xbd){const r=u16(d,0),start=u16(d,2),end=u16(d,d.length-2);for(let c=start;c<=end;c++){const p=4+6*(c-start);safePut(rows,r,c,number(rk(u32(d,p+2)),u16(d,p)));}}
  }return {name:sheet.name,rows:Array.from({length:rows.length},(_,i)=>rows[i]||[])};
 });
}
async function unzip(a){
 let e=-1;for(let i=a.length-22;i>=Math.max(0,a.length-65557);i--){if(u32(a,i)===0x06054b50){e=i;break;}}if(e<0)throw Error('ZIP 형식의 .xlsx 파일이 아닙니다.');
 const count=u16(a,e+10);let p=u32(a,e+16),total=0;const zip=new Map();
 for(let i=0;i<count;i++){
  if(u32(a,p)!==0x02014b50)throw Error('XLSX 중앙 디렉터리 손상');
  const flag=u16(a,p+8),method=u16(a,p+10),compressed=u32(a,p+20),size=u32(a,p+24),nl=u16(a,p+28),el=u16(a,p+30),cl=u16(a,p+32),at=u32(a,p+42);
  if(flag&1)throw Error('암호화 ZIP은 지원하지 않습니다.');total+=size;if(total>80*1024*1024)throw Error('압축 해제 크기가 80MB를 넘습니다. 주문만 따로 내보내 주세요.');
  const name=utf8.decode(a.subarray(p+46,p+46+nl)),start=at+30+u16(a,at+26)+u16(a,at+28);
  zip.set(name,{method,bytes:a.subarray(start,start+compressed),size});p+=46+nl+el+cl;
 }
 async function get(name){const entry=zip.get(name);if(!entry)return null;let out;
  if(entry.method===0)out=entry.bytes;
  else if(entry.method===8){if(typeof DecompressionStream==='undefined')throw Error('이 브라우저는 압축 해제를 지원하지 않습니다. 최신 Safari/Chrome 또는 CSV를 사용해 주세요.');try{const stream=new Blob([entry.bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));out=new Uint8Array(await new Response(stream).arrayBuffer());}catch{throw Error('XLSX 압축 해제 실패. 최신 브라우저를 사용하거나 CSV로 저장해 주세요.');}}
  else throw Error('지원하지 않는 ZIP 압축 방식입니다.');
  if(out.length!==entry.size)throw Error('XLSX 압축 데이터 길이가 맞지 않습니다.');return utf8.decode(out);
 }return {get,zip};
}
function xml(text){const d=new DOMParser().parseFromString(text,'application/xml');if(d.querySelector('parsererror'))throw Error('엑셀 XML을 읽을 수 없습니다.');return d;}
function all(node,name){return Array.from(node.getElementsByTagNameNS('*',name));}
function normalizePath(s){const out=[];for(const p of s.split('/')){if(p==='..')out.pop();else if(p&&p!=='.')out.push(p);}return out.join('/');}
async function xlsx(a){
 const z=await unzip(a),wbText=await z.get('xl/workbook.xml');if(!wbText)throw Error('워크북이 없는 XLSX입니다.');
 const wb=xml(wbText),rels=xml(await z.get('xl/_rels/workbook.xml.rels'));
 const link={};for(const r of all(rels,'Relationship'))if(r.getAttribute('TargetMode')!=='External')link[r.getAttribute('Id')]=r.getAttribute('Target');
 const sstText=await z.get('xl/sharedStrings.xml'),sst=sstText?all(xml(sstText),'si').map(si=>all(si,'t').map(t=>t.textContent).join('')):[];
 const stylesText=await z.get('xl/styles.xml'),formats={},xfs=[];
 if(stylesText){const styles=xml(stylesText);for(const f of all(styles,'numFmt'))formats[f.getAttribute('numFmtId')]=f.getAttribute('formatCode');const xf=all(styles,'cellXfs')[0];if(xf)for(const x of all(xf,'xf'))xfs.push(Number(x.getAttribute('numFmtId')));}
 const date1904=['1','true'].includes(all(wb,'workbookPr')[0]?.getAttribute('date1904'));const output=[];
 for(const sh of all(wb,'sheet')){
  const id=sh.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id')||sh.getAttribute('r:id');const target=link[id];if(!target)continue;
  const text=await z.get(target.startsWith('/')?target.slice(1):normalizePath('xl/'+target));if(!text)continue;const doc=xml(text),rows=[];
  for(const c of all(doc,'c')){
   const ref=c.getAttribute('r')||'',m=ref.match(/^([A-Z]+)([0-9]+)$/);if(!m)continue;let col=0;for(const ch of m[1])col=col*26+ch.charCodeAt(0)-64;
   const type=c.getAttribute('t'),v=all(c,'v')[0]?.textContent||'',style=Number(c.getAttribute('s')||0);let value=v;
   if(type==='s')value=sst[Number(v)]||'';else if(type==='inlineStr')value=all(c,'t').map(t=>t.textContent).join('');
   else if(type==='e')value='[엑셀 오류]';else if(type==='b')value=v==='1'?'TRUE':'FALSE';
   else if((!type||type==='n')&&v!==''){const n=Number(v);value=isDateFormat(xfs[style],formats[xfs[style]]||'')?excelDate(n,date1904):n;}
   safePut(rows,Number(m[2])-1,col-1,value);
  }output.push({name:sh.getAttribute('name')||'주문',rows:Array.from({length:rows.length},(_,i)=>rows[i]||[])});
 }return output;
}
async function read(input,name='orders'){
 const a=input instanceof Uint8Array?input:new Uint8Array(input);if(a.length>20*1024*1024)throw Error('파일은 20MB 이하로 나누어 불러와 주세요.');
 if(a[0]===0xd0&&a[1]===0xcf)return biff(a);
 if(a[0]===0x50&&a[1]===0x4b)return xlsx(a);
 const text=decodeText(a);
 if(/<table[\s>]/i.test(text)){const doc=new DOMParser().parseFromString(text,'text/html');return Array.from(doc.querySelectorAll('table')).map((t,i)=>({name:'표 '+(i+1),rows:Array.from(t.rows,r=>Array.from(r.cells,c=>c.textContent.trim()))}));}
 if(/<Workbook/i.test(text))throw Error('XML 스프레드시트 형식은 .xlsx 또는 CSV로 저장해 주세요.');
 return [{name:name.replace(/\.[^.]+$/,''),rows:csv(text)}];
}
const api={read,csv,biff,xlsx,excelDate};root.NuavuExcel=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
