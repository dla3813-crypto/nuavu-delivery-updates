'use strict';
// 2026-10-23 요청: 업데이트가 있으면 앱을 켤 때마다 "다운로드하시겠습니까?" 창 + 상단 바에 "업데이트 있음" 표시, 버튼 하나로 설치.
(()=>{
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const bar=document.createElement('section');bar.id='updateBar';bar.className='update-bar';bar.hidden=true;
 bar.innerHTML='<span class="update-dot"></span><b id="updateBarText">업데이트 있음</b><span id="updateBarSub" class="update-sub"></span><button id="updateBarBtn" class="update-btn">지금 업데이트</button>';
 const main=document.querySelector('main');if(main)main.prepend(bar);
 const dlg=document.createElement('dialog');dlg.id='updateDialog';dlg.className='update-dialog';
 dlg.innerHTML='<h2>🔵 새 버전이 있습니다</h2><p id="updateDlgVer"></p><ul id="updateDlgNotes"></ul><p class="sub">주문·발송 이력과 계정은 그대로 유지됩니다. 업데이트하면 앱이 잠시 꺼졌다가 새 버전으로 다시 열립니다 (1~3분).</p><p id="updateDlgMsg" class="update-msg"></p><div class="update-actions"><button id="updateDlgLater">나중에</button><button id="updateDlgGo" class="update-btn">다운로드하고 업데이트</button></div>';
 document.body.appendChild(dlg);
 let shownFor='';let last=null;
 const api=()=>window.pywebview?.api;
 function render(s){
  last=s;const busy=s.phase==='downloading'||s.phase==='installing';
  bar.hidden=!(s.available||busy||s.phase==='error'&&s.latest);
  bar.classList.toggle('is-error',s.phase==='error');
  document.getElementById('updateBarText').textContent=busy?(s.phase==='downloading'?`업데이트 받는 중 ${s.progress||0}%`:'업데이트 설치 준비 중'):s.phase==='error'?'업데이트 실패':`업데이트 있음 · v${s.latest}`;
  document.getElementById('updateBarSub').textContent=busy?(s.message||''):s.phase==='error'?(s.error||''):`지금 v${s.current}`;
  const b=document.getElementById('updateBarBtn');b.hidden=busy;b.textContent=s.phase==='error'?'다시 시도':'지금 업데이트';
  document.getElementById('updateDlgVer').innerHTML=`지금 버전 <b>v${esc(s.current)}</b> → 새 버전 <b>v${esc(s.latest)}</b>${s.publishedAt?' · '+esc(String(s.publishedAt).slice(0,10)):''}<br>업데이트를 다운로드하시겠습니까?`;
  document.getElementById('updateDlgNotes').innerHTML=(s.notes||[]).slice(0,12).map(n=>'<li>'+esc(n)+'</li>').join('');
  document.getElementById('updateDlgMsg').textContent=busy?(s.message||'')+(s.phase==='downloading'?` (${s.progress||0}%)`:''):(s.phase==='error'?s.error||'':'');
  document.getElementById('updateDlgGo').disabled=busy;
  // 앱을 켤 때마다(이 화면을 처음 연 뒤) 새 버전마다 한 번 묻는다.
  if(s.available&&!busy&&shownFor!==s.latest){shownFor=s.latest;try{if(!dlg.open)dlg.showModal();}catch(_){}}
 }
 async function install(btn){
  const a=api();if(!a?.update_install||typeof token==='undefined')return;
  if(btn)btn.disabled=true;
  try{const r=await a.update_install(token);if(r.error)throw Error(r.error);render(r);}
  catch(e){document.getElementById('updateDlgMsg').textContent=e.message;if(typeof toast==='function')toast(e.message,true);}
  finally{if(btn)btn.disabled=false;}
 }
 document.getElementById('updateBarBtn').onclick=e=>{if(last&&last.available&&!dlg.open)dlg.showModal();else install(e.currentTarget);};
 document.getElementById('updateDlgGo').onclick=e=>install(e.currentTarget);
 document.getElementById('updateDlgLater').onclick=()=>dlg.close();
 async function tick(){
  const a=api();
  if(typeof token==='undefined'||!a?.update_status){setTimeout(tick,3000);return;}
  try{const s=await a.update_status(token);if(!s.error)render(s);}catch(_){}
  setTimeout(tick,last&&(last.phase==='downloading'||last.phase==='installing')?1000:(!last||!last.checkedAt)?3000:60000);   // 시작 직후 확인 결과가 나올 때까지는 3초 간격
 }
 setTimeout(tick,1500);
})();
