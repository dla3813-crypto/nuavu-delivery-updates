'use strict';
// 2026-10-20 11:38 요청 (공통): 수동매칭 › 수동매칭 필요 — 출고장·진행상황에는 있는데 연결된 주문이 없는 거래처 상품·옵션.
// 주문(현재 미출고)을 골라 연결하면 state.supply.unmatchedVariants 에서 빠져 목록에서 사라진다. 연결은 기존 /api/supply-match
// (주문 행 서명 → 거래처 상품 목록)에 해당 거래처 상품을 덧붙이는 방식이라 기존 수동매칭 규칙을 지우지 않는다.
(()=>{
 const el=id=>document.getElementById(id);
 const host=el('sectionGroupPanel')||el('manualMatchPanel')||document.querySelector('main');
 if(!host)return;
 host.insertAdjacentHTML('afterend',`<section id="manualNeededPanel" class="panel dispatch-panel manual-needed-panel" hidden>
 <p class="eyebrow">SUPPLY MATCH</p><h2>수동매칭 필요 <small id="manualNeededCount" class="sub"></small></h2>
 <p class="sub">출고장·진행상황에 있는 거래처 상품·옵션 중 현재 미출고 주문 어느 것에도 연결되지 않은 것입니다. 오른쪽에서 아직 연결되지 않은 주문 상품·옵션을 검색해 고르고 연결을 누르세요(같은 상품명·옵션의 주문은 한 줄로 묶여 모두 연결됩니다). 연결되면 사라집니다.</p>
 <div class="filterrow"><input id="manualNeededSearch" placeholder="거래처 상품명 · 컬러 · 브랜드 검색"><select id="manualNeededOrigin"><option value="">전체 출처</option><option value="manifest">출고장</option><option value="progress">진행상황</option></select></div>
 <div class="tablewrap"><table class="manual-needed-table"><thead><tr><th>브랜드</th><th>거래처 상품명</th><th>컬러 / 사이즈</th><th>출처 · 수량</th><th>V 도착일</th><th>연결할 주문 상품·옵션 (현재 미출고 · 미연결)</th><th></th></tr></thead><tbody id="manualNeededRows"></tbody></table></div>
 <p id="manualNeededStatus" class="sub" role="status"></p></section>`);
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const choice={};   // variant → chosen order key
 function orders(){
  // 11:55 요청: 현재 미출고 주문 중 아직 연결되지 않은 것만, 같은 상품명·옵션은 하나로(수동매칭 규칙은 상품명·옵션 단위라 주문 수와 무관).
  const seen=new Map();
  for(const r of ((typeof state!=="undefined"?state:null)?.rows||[])){
   if(!r.active||r.soldoutNotified)continue;
   const a=r.supplyInfo||{};if(a.matched&&!a.matchNeeded)continue;
   const k=(r.product||'')+'\u0001'+(r.option||'');const cur=seen.get(k);
   if(cur)cur.orders+=1;else seen.set(k,{key:r.key,product:r.product,option:r.option,seller:r.seller,orders:1});
  }
  return [...seen.values()];
 }
 function candidates(v,q){
  const base=orders();q=(q||'').trim().toLowerCase();
  const words=q?q.split(/\s+/):[];
  const scored=base.map(r=>{const text=(r.product+' '+r.option).toLowerCase();const hit=words.length?words.every(w=>text.includes(w)):true;
   // 검색어가 없으면 거래처 상품명의 핵심 단어가 들어간 주문을 위로
   const core=String(v.product||'').replace(/^(?:\([^)]*\)|\[[^\]]*\]|\s)+/,'').split(/\s+/).filter(w=>w.length>=2);
   const score=core.filter(w=>text.includes(w.toLowerCase())).length+(String(r.option||'').includes(v.color||'')?0.5:0);
   return {r,hit,score};}).filter(x=>x.hit);
  scored.sort((a,b)=>b.score-a.score||a.r.product.localeCompare(b.r.product,'ko'));
  return scored.slice(0,60).map(x=>x.r);
 }
 function optionLabel(r){return `${r.product} / ${r.option||'-'} · 주문 ${r.orders}건`;}
 function render(){
  const panel=el('manualNeededPanel');if(!panel)return;
  const on=el('statusFilter')?.value==='manual_needed';panel.hidden=!on;if(!on)return;
  const all=(typeof state!=="undefined"?state:null)?.supply?.unmatchedVariants||[];const q=el('manualNeededSearch').value.trim().toLowerCase();const origin=el('manualNeededOrigin').value;
  const list=all.filter(v=>(!origin||(v.origins||[]).includes(origin))&&(!q||[v.brand,v.product,v.color,v.size].join(' ').toLowerCase().includes(q)));
  el('manualNeededCount').textContent=`${list.length}개 / 전체 ${all.length}개`;
  el('manualNeededRows').innerHTML=list.length?list.map(v=>{
   const sel=choice[v.variant]||'';const opts=candidates(v,el('mn-q-'+v.variant)?.value||'');
   return `<tr data-variant="${esc(v.variant)}"><td>${esc(v.brand)}</td><td class="productcol"><span class="productname">${esc(v.product)}</span></td><td>${esc(v.color)} / ${esc(v.size)}</td><td>${(v.origins||[]).map(o=>o==='manifest'?'출고장':'진행상황').join(' · ')}<span class="secondary">${esc(v.qty??0)}개</span></td><td>${(v.officeDates||[]).join(', ')||'—'}</td><td><input class="mn-q" id="mn-q-${esc(v.variant)}" data-variant="${esc(v.variant)}" placeholder="주문 상품명·옵션 검색" value="${esc(el('mn-q-'+v.variant)?.value||'')}"><select class="mn-sel" data-variant="${esc(v.variant)}"><option value="">주문 선택 (${opts.length}건)</option>${opts.map(r=>`<option value="${esc(r.key)}" ${sel===r.key?'selected':''}>${esc(optionLabel(r))}</option>`).join('')}</select></td><td><button class="tiny primary mn-link" data-variant="${esc(v.variant)}" ${sel?'':'disabled'}>연결</button></td></tr>`;
  }).join(''):`<tr><td colspan="7" class="empty">${all.length?'검색 조건에 맞는 거래처 상품이 없습니다.':'연결되지 않은 거래처 상품·옵션이 없습니다.'}</td></tr>`;
 }
 document.addEventListener('input',e=>{if(e.target.classList?.contains('mn-q')){const v=e.target.dataset.variant;const sel=document.querySelector(`.mn-sel[data-variant="${CSS.escape(v)}"]`);const variant=((typeof state!=="undefined"?state:null)?.supply?.unmatchedVariants||[]).find(x=>x.variant===v);if(!sel||!variant)return;const opts=candidates(variant,e.target.value);const cur=choice[v]||'';sel.innerHTML=`<option value="">주문 선택 (${opts.length}건)</option>`+opts.map(r=>`<option value="${esc(r.key)}" ${cur===r.key?'selected':''}>${esc(optionLabel(r))}</option>`).join('');}
  if(e.target.id==='manualNeededSearch')render();});
 document.addEventListener('change',e=>{if(e.target.classList?.contains('mn-sel')){const v=e.target.dataset.variant;choice[v]=e.target.value;const b=document.querySelector(`.mn-link[data-variant="${CSS.escape(v)}"]`);if(b)b.disabled=!e.target.value;}
  if(e.target.id==='manualNeededOrigin')render();});
 document.addEventListener('click',async e=>{
  const b=e.target.closest?.('.mn-link');if(!b)return;
  const v=b.dataset.variant,key=choice[v];if(!key)return;
  const row=((typeof state!=="undefined"?state:null)?.rows||[]).find(r=>r.key===key);if(!row)return;
  const existing=(row.supplyInfo?.manualVariants||[]).filter(x=>x!==v);
  b.disabled=true;el('manualNeededStatus').textContent='연결 중…';
  try{const r=await api('supply-match',{key,variants:[...existing,v]});el('manualNeededStatus').textContent=r.message||'연결했습니다.';delete choice[v];await refresh();}
  catch(err){el('manualNeededStatus').textContent=err.message;b.disabled=false;}
 });
 el('statusFilter')?.addEventListener('change',render);
 window.addEventListener('nuavu-state',render);
 const origRender=window.render;
 if(typeof origRender==='function'){window.render=function(){const out=origRender.apply(this,arguments);try{render();}catch(e){}return out;};}
 window.renderManualNeeded=render;
})();
