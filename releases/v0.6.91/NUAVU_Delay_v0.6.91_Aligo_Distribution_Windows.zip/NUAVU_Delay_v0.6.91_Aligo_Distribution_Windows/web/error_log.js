'use strict';
// 2026-10-22 19:02 요청: ⚙ 설정 › 오류 로그 — 앱이 막히거나 실패한 내용을 상세히 모아 두고, 그대로 복사해 Claude에게 붙여넣어 수정하게 한다.
(()=>{
 const hub=document.querySelector('#settingsHubDialog .hub-grid');
 if(hub)hub.insertAdjacentHTML('beforeend','<section class="hub-section hub-errors"><h3>오류 로그</h3><p class="sub">막힘·실패 알림과 처리되지 않은 오류를 시각·버전·상세 위치와 함께 남깁니다. 복사해서 Claude에게 붙여넣으면 고칠 수 있습니다. 주문번호·송장번호가 들어갈 수 있습니다.</p><div class="hub-buttons"><button id="errorLogBtn">오류 로그 보기</button></div></section>');
 document.body.insertAdjacentHTML('beforeend',`<dialog id="errorLogDialog" class="wide"><div class="dialoghead"><div><p class="eyebrow">ERROR LOG</p><h2>오류 로그</h2></div><button id="errorLogClose">닫기</button></div>
  <div class="settings-actions"><button id="errorLogCopyAll" class="primary">전체 복사 (Claude에게 붙여넣기용)</button><button id="errorLogRefresh">새로고침</button><button id="errorLogClear" class="danger-quiet">로그 비우기</button></div>
  <p id="errorLogStatus" class="sub" role="status"></p><div id="errorLogList"></div></dialog>`);
 const $=id=>document.getElementById(id);
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let entries=[],version='';
 const local=iso=>{const d=new Date(iso);return isNaN(d)?String(iso||''):d.toLocaleString('ko-KR',{hour12:false});};
 const asText=e=>`[${local(e.at)}] v${e.version||version} · ${e.title}\n${e.message||''}${e.detail?'\n--- 상세 ---\n'+e.detail:''}${e.thread?'\n(작업: '+e.thread+')':''}`;
 async function call(p){const r=await api('error-log',p||{});return r;}
 async function load(){
  try{const r=await call({});entries=r.entries||[];version=r.version||'';
   $('errorLogStatus').textContent=entries.length?`${entries.length}건 · 최신순 · 앱 v${version}`:'기록된 오류가 없습니다.';
   $('errorLogList').innerHTML=entries.map((e,i)=>`<article class="historycard"><div class="historytop"><b>${esc(e.title)}</b><span class="sub">${esc(local(e.at))} · v${esc(e.version||'')}</span></div><pre>${esc(e.message||'')}</pre>${e.detail?`<details><summary>상세(코드 위치)</summary><pre>${esc(e.detail)}</pre></details>`:''}<div class="alert-actions"><button class="tiny" data-error-copy="${i}">이 오류 복사</button></div></article>`).join('');
   const b=$('errorLogBtn');if(b)b.textContent=entries.length?`오류 로그 보기 (${entries.length})`:'오류 로그 보기';
  }catch(err){$('errorLogStatus').textContent=err.message;}
 }
 async function copy(text){try{await navigator.clipboard.writeText(text);toast('복사했습니다. Claude에게 그대로 붙여넣으세요.');}catch(_){const t=document.createElement('textarea');t.value=text;document.body.append(t);t.select();document.execCommand('copy');t.remove();toast('복사했습니다.');}}
 $('errorLogBtn')?.addEventListener('click',()=>{$('errorLogDialog').showModal();load();});
 $('errorLogClose').onclick=()=>$('errorLogDialog').close();
 $('errorLogRefresh').onclick=load;
 $('errorLogCopyAll').onclick=()=>{if(!entries.length)return toast('복사할 오류가 없습니다.');copy(`누아브 배송안내 앱 오류 로그 (v${version}, ${entries.length}건)\n\n`+entries.map(asText).join('\n\n'));};
 $('errorLogList').addEventListener('click',e=>{const b=e.target.closest('[data-error-copy]');if(b)copy(asText(entries[Number(b.dataset.errorCopy)]));});
 $('errorLogClear').onclick=async()=>{if(!confirm('오류 로그를 모두 지울까요?'))return;await call({action:'clear'});load();};
 setTimeout(()=>{if(typeof api==='function')call({}).then(r=>{const b=$('errorLogBtn');if(b&&r.entries?.length)b.textContent=`오류 로그 보기 (${r.entries.length})`;}).catch(()=>{});},2500);
})();

// 2026-10-22 19:45 요청: 1분 결과 미확인/실패 알림톡 → 같은 안내를 알리고 문자로 오전 9시 예약 / 즉시 전송.
function fallbackButtons(n){
 if(!n||n.kind!=='AT'||n.isTest||n.fallbackId||n.aligoProviderSmsMid||!['UNKNOWN','PENDING','FAILED'].includes(n.status))return '';
 const id=String(n.id).replace(/[&<>"']/g,'');
 return `<div class="alert-actions fallback-actions"><button class="tiny fallback-sms" data-id="${id}" data-mode="MORNING">알리고 문자 · 오전 9시 예약전송</button><button class="tiny fallback-sms" data-id="${id}" data-mode="IMMEDIATE">알리고 문자 · 즉시전송</button></div>`;
}
window.fallbackButtons=fallbackButtons;
document.addEventListener('click',e=>{
 const b=e.target.closest('.fallback-sms');if(!b)return;
 const n=(state?.notices||[]).find(x=>x.id===b.dataset.id);const morning=b.dataset.mode==='MORNING';
 if(!confirm(`${n?n.seller+' '+n.orderId+' · ':''}알림톡과 같은 안내를 알리고 문자로 ${morning?'다음 오전 9시에 예약':'지금 바로'} 1회 보냅니다.\n알림톡이 실제로 도착했다면 고객이 두 번 받을 수 있습니다. 진행할까요?`))return;
 action(async()=>{const r=await api('aligo-fallback',{id:b.dataset.id,mode:b.dataset.mode});toast(r.message);},b);
});
