'use strict';
// 2026-10-21 20:33 요청: 화요일 중국 출고가 밀린 주 — 수요일 18시까지 그 화요일 출고장이 없으면 물어본다.
// 출고 안 됨 → 다음 중국 출고일: 금요일(다음주 화~수 출고) / 토요일(다음주 수~목 출고, 지금과 같음).
(()=>{
 document.body.insertAdjacentHTML('beforeend',`<dialog id="shipDelayDialog" class="ably-dialog">
 <div class="dialoghead"><h2 id="shipDelayTitle">화요일 출고장이 아직 없습니다</h2><button id="shipDelayLater">나중에</button></div>
 <div id="shipDelayStep1"><p id="shipDelayAsk"></p>
  <div class="settings-actions"><button id="shipDelayNo" class="pink-button">출고 안 됨</button><button id="shipDelayYes">출고됐음 (출고장만 늦음)</button></div></div>
 <div id="shipDelayStep2" hidden><p>다음 중국 출고일은 언제인가요?</p>
  <div class="settings-actions"><button id="shipDelayFri" class="pink-button"></button><button id="shipDelaySat" class="pink-button"></button><button id="shipDelayBack">뒤로</button></div>
  <p class="sub">고른 날로 그 화요일 출고분의 예상 출고일을 다시 계산합니다. 이미 고객에게 안내한 날짜는 바꾸지 않습니다(필요하면 재안내).</p></div>
 <p id="shipDelayStatus" class="sub" role="status"></p></dialog>`);
 const $=id=>document.getElementById(id);
 const md=iso=>{const [y,m,d]=iso.split('-');return `${+m}/${+d}`;};
 let current=null,snoozed={};
 function step(n){$('shipDelayStep1').hidden=n!==1;$('shipDelayStep2').hidden=n!==2;$('shipDelayStatus').textContent='';}
 function check(){
  const q=(typeof state!=='undefined'&&state)?state.shipDelayQuestion:null;
  if(!q){if($('shipDelayDialog').open&&current)$('shipDelayDialog').close();current=null;return;}
  if(snoozed[q.tuesday]&&Date.now()<snoozed[q.tuesday])return;
  if($('shipDelayDialog').open)return;
  current=q;
  $('shipDelayTitle').textContent=`${md(q.tuesday)}(화) 출고장이 아직 없습니다`;
  $('shipDelayAsk').textContent=`${md(q.tuesday)}(화) 중국 출고가 진행되지 않았나요? 수요일 오후 6시까지 그 날짜 출고장이 들어오지 않았습니다.`;
  $('shipDelayFri').textContent=`금요일 ${md(q.friday)} 출고 → 다음주 화~수 출고`;
  $('shipDelaySat').textContent=`토요일 ${md(q.saturday)} 출고 → 다음주 수~목 출고`;
  step(1);$('shipDelayDialog').showModal();
 }
 async function answer(payload){
  try{const r=await api('ship-delay',{tuesday:current.tuesday,...payload});$('shipDelayDialog').close();current=null;toast(r.message);if(typeof refresh==='function')await refresh();}
  catch(e){$('shipDelayStatus').textContent=e.message;}
 }
 $('shipDelayNo').onclick=()=>step(2);$('shipDelayBack').onclick=()=>step(1);
 $('shipDelayYes').onclick=()=>answer({answer:'shipped'});
 $('shipDelayFri').onclick=()=>answer({answer:'delayed',departure:'fri'});
 $('shipDelaySat').onclick=()=>answer({answer:'delayed',departure:'sat'});
 $('shipDelayLater').onclick=()=>{if(current)snoozed[current.tuesday]=Date.now()+60*60*1000;$('shipDelayDialog').close();};   // 1시간 뒤 다시 묻기
 setInterval(check,5000);setTimeout(check,1500);
})();
