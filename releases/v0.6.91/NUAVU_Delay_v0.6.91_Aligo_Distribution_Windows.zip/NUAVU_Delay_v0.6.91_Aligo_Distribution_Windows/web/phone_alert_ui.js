'use strict';
// 2026-10-23 요청: ⚙ 설정 › 자동화 — 아이폰 알림 (아이메시지). 문제(빨간) 알림만 보냄 · 기본 꺼짐.
(()=>{
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const row=document.createElement('div');row.className='hub-switch phone-alert-row';row.id='phoneAlertRow';
 row.innerHTML='<label class="phone-alert-toggle"><input type="checkbox" id="phoneAlertOn"><span><b>아이폰 알림 (아이메시지)</b><small>프로그램에 문제가 생겨 빨간 알림(막힘·확인 필요·실패·오류)이 뜰 때만 아이폰으로 보냅니다. 정상 완료 알림은 보내지 않습니다 · 같은 알림은 1번 · 1시간 최대 20통.</small></span></label>'+
  '<div class="phone-alert-line"><label>받는 곳 <input id="phoneAlertTo" placeholder="010 번호 또는 Apple ID 이메일" autocomplete="off"></label><a href="#" id="phoneAlertTest">시험 보내기</a></div>'+
  '<p id="phoneAlertState" class="sub phone-alert-state"></p>';
 function mount(){
  if(document.getElementById('phoneAlertRow'))return true;
  const list=document.getElementById('hubAutoList');if(!list)return false;
  const anchor=list.querySelector('input[data-hub-auto="autoZigzagPush"]')?.closest('label');
  if(anchor)anchor.before(row);else list.append(row);wire();return true;
 }
 let st=null,busy=false;
 const $$=id=>document.getElementById(id);
 function paint(s,msg,isErr){
  st=s||st;if(!st)return;
  const off=!st.supported;row.classList.toggle('is-disabled',off);row.dataset.enabled=String(!!st.enabled&&!off);
  $$('phoneAlertOn').checked=!!st.enabled;$$('phoneAlertOn').disabled=off||busy;$$('phoneAlertTo').disabled=off||busy;
  if(document.activeElement!==$$('phoneAlertTo'))$$('phoneAlertTo').value=st.to||'';
  $$('phoneAlertTest').classList.toggle('disabled',off||busy);
  const last=st.last||{};const when=last.at&&typeof dateTime==='function'?dateTime(last.at):(last.at||'');
  let line=off?st.unsupportedReason:(msg||'');
  if(!off&&!msg&&last.at)line=(last.ok?'마지막 보내기 성공':'마지막 보내기 실패')+` · ${when}${last.kind==='test'?' (시험)':''}${last.ok?'':' · '+(last.error||'')}`;
  if(!off)line+=(line?' · ':'')+`이번 1시간 ${st.sentLastHour||0}/${st.maxPerHour||20}통`;
  const el=$$('phoneAlertState');el.textContent=line;el.classList.toggle('error',!!isErr||(!msg&&last.at&&!last.ok));
 }
 async function call(body){
  const r=await api('phone-alert',body);if(r.error){paint(r,r.error,true);throw Error(r.error);}return r;
 }
 async function load(){if(!mount())return;try{paint(await api('phone-alert',{action:'status'}));}catch(e){}}
 async function save(){
  if(busy)return;busy=true;paint();
  try{const r=await call({action:'save',enabled:$$('phoneAlertOn').checked,to:$$('phoneAlertTo').value});paint(r,r.message);if(typeof toast==='function')toast(r.message);}
  catch(e){$$('phoneAlertOn').checked=!!(st&&st.enabled);if(typeof toast==='function')toast(e.message,true);}
  finally{busy=false;paint();}
 }
 function wire(){
  $$('phoneAlertOn').addEventListener('change',save);
  $$('phoneAlertTo').addEventListener('change',()=>{if(st&&st.enabled||$$('phoneAlertTo').value.trim())save();});
  $$('phoneAlertTo').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();e.target.blur();}});
  $$('phoneAlertTest').addEventListener('click',async e=>{
   e.preventDefault();if(busy||(st&&!st.supported))return;busy=true;paint(null,'시험 아이메시지를 보내는 중…');
   try{const r=await call({action:'test',to:$$('phoneAlertTo').value});paint(r,r.message);if(typeof toast==='function')toast(r.message);}
   catch(err){if(typeof toast==='function')toast(err.message,true);}
   finally{busy=false;paint(null,null);}
  });
 }
 document.addEventListener('click',e=>{if(e.target.closest('#settingsHubBtn'))setTimeout(load,50);});
 setTimeout(load,1500);
})();
