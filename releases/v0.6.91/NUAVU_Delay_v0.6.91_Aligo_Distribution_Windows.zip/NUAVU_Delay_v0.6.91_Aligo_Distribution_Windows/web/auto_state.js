'use strict';
(()=>{
 function style(el,on){if(!el)return;el.classList.add('auto-state');if(el.dataset.enabled!==String(on))el.dataset.enabled=String(on);}
 function render(){
  for(const id of ['supplyAutoBtn','inventoryAutoBtn']){const e=document.getElementById(id);if(!e)continue;const on=e.getAttribute('aria-pressed')==='true';style(e,on);const name=id==='supplyAutoBtn'?'자동 반영':'자동갱신';const label=name+' · '+(on?'켜짐':'꺼짐');if(e.textContent!==label)e.textContent=label;e.title=on?'누르면 자동 실행을 끕니다.':'누르면 자동 실행을 켭니다.';}
  for(const id of ['orderExportEnabled','orderImportScheduleEnabled','returnWatchEnabled','pickupEnabled']){const e=document.getElementById(id);if(!e)continue;const label=e.closest('label');style(label,e.checked);let badge=label.querySelector('.auto-state-word');if(!badge){badge=document.createElement('b');badge.className='auto-state-word';label.append(badge);}const text=e.checked?'켜짐':'꺼짐';if(badge.textContent!==text)badge.textContent=text;}
  const mode=document.getElementById('returnMode');if(mode){style(mode,mode.value==='daily');for(const o of mode.options){const t=o.value==='daily'?'자동 조회 · 켜짐 (매일)':'자동 조회 · 꺼짐 (수동)';if(o.textContent!==t)o.textContent=t;}}
 }
 document.addEventListener('change',render);window.addEventListener('nuavu-state',render);window.addEventListener('nuavu-auto-state',render);
 for(const id of ['supplyAutoBtn','inventoryAutoBtn']){const e=document.getElementById(id);if(e)new MutationObserver(render).observe(e,{attributes:true,attributeFilter:['aria-pressed'],childList:true});}
 setInterval(render,1000);render();
})();
