'use strict';
// Separate from the existing sender and EzAdmin import controls.
document.body.insertAdjacentHTML('beforeend',`
<dialog id="ablySyncDialog" class="ably-dialog">
 <div class="dialoghead"><div><p class="eyebrow">ABLY</p><h2>에이블리 출고 예정일 동기화</h2></div><button data-ably-close="ablySyncDialog">닫기</button></div>
 <p>발송 관리에서 <b>100개씩 모든 페이지</b>를 확인합니다. 배송지연 메시지 발송란이 <b>‘발송’인 상품만</b> 상세를 열어 예상출고일과 안내 발송일을 가져옵니다. 공란·미발송은 건너뜁니다.</p>
 <p class="sub">한 번 확인한 상품주문번호는 기억해 다음 상세 조회에서 제외합니다. 날짜를 못 읽었거나 수량·주문 정보가 달라진 건은 다시 확인합니다.</p>
 <div class="notice"><b>안내한 출고 예정일 우선순위</b><br>고객 안내 문자 → 에이블리 동기화 → 메시지 없는 안내<br><small>문자·알림톡은 접수 또는 발송 완료 이력이 기준입니다. 날짜 범위는 마지막 날을 적용합니다.</small></div>
 <label class="ably-push-option"><input type="checkbox" id="ablyPushEnabled" checked> <b>앱에서 안내한 건을 에이블리에도 배송지연 메시지 발송 처리</b></label>
 <p class="sub">앱에 배송지연 안내(문자·알림톡 발송 또는 메시지 없는 안내)가 있는데 에이블리 발송란이 <b>미발송</b>인 상품만, 에이블리 발송 관리의 <b>배송지연메시지 발송 처리</b>를 앱의 출고 예정일로 실행합니다. 내일·모레·3일 이내·1주 이내·2주 이내에 맞으면 그 버튼을, 그 외는 달력에서 날짜를 고릅니다. 에이블리는 1회만 발송되므로 이미 발송된 건은 건드리지 않습니다. 지난 날짜·30일 초과는 보류합니다.</p>
 <div class="settings-actions"><button id="ablySyncStart" class="pink-button">전체 페이지 동기화</button><button id="ablySyncCancel" disabled>동기화 중단</button><button id="ablySyncSettings">로그인 설정</button></div>
 <p id="ablySyncStatus" class="sub" role="status"></p><p id="ablySyncStamp" class="sub"></p>
 <div id="ablySyncIssues" class="notice small" hidden></div>
 <p class="sub">에이블리 화면의 날짜를 읽어 앱에 기록합니다. 위 옵션을 끄면 실제 메시지 발송이나 에이블리 주문 변경은 하지 않습니다.</p>
 <button id="ablyLegacyImport" class="tiny">기존 엑셀로 안내 이력 반영</button>
 <hr>
 <h3>아무드(일본) 배송지연 메시지</h3>
 <p class="sub">발송 관리 › <b>일본(amood)</b> 탭에서 <b>주문번호로만</b> 찾아 선택 → 배송지연메시지 발송 처리 → 예상 출고일(에이블리와 같은 버튼·달력) → <b>지연 사유</b>(고정 문구에 상품·출고 예정일 채움) → 발송. 앱에서 안내(문자·알림톡·메시지 없는 안내)한 아무드 주문만, 1차 미발송 건만 처리합니다. 메시지 없는 안내 뒤에는 자동으로 실행됩니다.</p>
 <div class="settings-actions"><input id="amoodPreviewOrder" placeholder="아무드 주문번호" inputmode="numeric" style="width:9em"><input id="amoodPreviewDue" type="date"><button id="amoodPreview">미리보기 (발송 안 함)</button><button id="amoodPush" class="pink-button">앱 안내건 아무드 발송 처리</button></div>
 <p class="sub">미리보기는 선택·예상 출고일·지연 사유 입력·발송 버튼 활성까지 확인하고 <b>닫습니다</b>. 결과 단계는 아래 목록에 표시됩니다.</p>
</dialog>
<dialog id="ablySettingsDialog" class="ably-dialog">
 <div class="dialoghead"><h2>⚙ 에이블리 설정</h2><button data-ably-close="ablySettingsDialog">닫기</button></div>
 <p>앱의 쇼핑몰 설정과 같은 마켓의 에이블리 계정을 입력하세요.</p>
 <label>아이디<input id="ablyUsername" autocomplete="off"></label>
 <label>비밀번호<input id="ablyPassword" type="password" autocomplete="new-password" placeholder="비밀번호"></label>
 <p class="sub">macOS 키체인의 별도 항목에 저장합니다. 저장된 비밀번호는 화면에 다시 표시하지 않습니다.</p>
 <button id="ablySave" class="primary">로그인 정보 저장</button><p id="ablySettingsStatus" class="sub" role="status"></p>
 <hr>
 <label class="ably-push-option"><input type="checkbox" id="headlessChrome"> <b>Chrome 헤드리스 (창 없이 실행 · 모든 자동화 공통)</b></label>
 <p class="sub">에이블리 동기화·주문 불러오기·반품/교환 조회·회수접수·이지어드민 C/S 확인에 쓰는 전용 Chrome 창을 최소화(Dock)한 채로 실행합니다. 로그인 확인·추가 인증·‘계속’ 대기처럼 직접 봐야 할 때만 창을 올립니다. 바꾸면 즉시 저장되고 다음 실행부터 적용됩니다.</p>
 <p id="headlessChromeStatus" class="sub" role="status"></p>
</dialog>`);
let ablyTimer=null,ablyPolling=false;
async function ablyCall(action,username='',password=''){
 const bridge=window.pywebview?.api;
 if(!state?.desktopMode||!bridge?.ably_sync_action)throw Error('에이블리 동기화는 v0.6.36 배포판 맥 앱에서 사용할 수 있습니다.');
 const result=await bridge.ably_sync_action(token,action,username,password);if(result.error)throw Error(result.error);return result;
}
function ablyStatus(s){
 $('ablySyncStatus').textContent=s.message||'';$('ablySyncStatus').classList.toggle('error',s.phase==='error');
 $('ablySyncStart').disabled=!!s.running;$('ablySyncCancel').disabled=!s.running;$('ablyPushEnabled').disabled=!!s.running;
 $('ablySyncStamp').textContent=s.lastSync?'마지막 동기화 '+dateTime(s.lastSync):'아직 동기화하지 않았습니다.';
 const issues=s.result?.issues||[];$('ablySyncIssues').hidden=!issues.length;
 $('ablySyncIssues').textContent=issues.map(x=>(x.label||('상품주문번호 '+x.itemId))+' · '+x.reason).join('\n');
 for(const id of ['amoodPreview','amoodPush'])if($(id))$(id).disabled=!!s.running;
}
async function pollAbly(){
 if(window.factoryResetStarted)return;
 if(ablyPolling)return;ablyPolling=true;clearTimeout(ablyTimer);
 try{const s=await ablyCall('status');if(window.factoryResetStarted)return;ablyStatus(s);if(s.running)ablyTimer=setTimeout(pollAbly,1000);else if(s.phase==='done')await refresh();}
 catch(e){$('ablySyncStatus').textContent=e.message;$('ablySyncStatus').classList.add('error');}
 finally{ablyPolling=false;}
}
async function openAblySettings(){
 $('ablyPassword').value='';$('ablyUsername').value='';$('ablySave').disabled=true;
 $('ablySettingsDialog').showModal();$('ablySettingsStatus').textContent='키체인 저장 상태를 확인합니다.';
 try{const s=await ablyCall('settings');$('ablyUsername').value=s.username||'';$('ablyPassword').placeholder=s.hasPassword?'저장됨 · 변경할 때만 입력':'비밀번호';$('ablySave').disabled=!s.available;$('ablySettingsStatus').textContent=s.hasPassword?'저장된 계정이 있습니다.':'계정을 입력하고 저장하세요.';}
 catch(e){$('ablySettingsStatus').textContent=e.message;$('ablySave').disabled=!window.pywebview?.api?.ably_sync_action;}
}
$('historySeedBtn').onclick=async()=>{$('ablySyncDialog').showModal();await pollAbly();};
$('ablySettingsBtn').onclick=openAblySettings;$('ablySyncSettings').onclick=openAblySettings;
try{if(localStorage.getItem('ablyPushEnabled')==='0')$('ablyPushEnabled').checked=false;}catch(e){}
$('ablyPushEnabled').onchange=()=>{try{localStorage.setItem('ablyPushEnabled',$('ablyPushEnabled').checked?'1':'0');}catch(e){}};
$('ablySyncStart').onclick=async()=>{
 $('ablySyncStart').disabled=true;
 try{ablyStatus(await ablyCall($('ablyPushEnabled').checked?'start_push':'start'));await pollAbly();}
 catch(e){$('ablySyncStatus').textContent=e.message;$('ablySyncStatus').classList.add('error');$('ablySyncStart').disabled=false;}
};
$('ablySyncCancel').onclick=async()=>{
 $('ablySyncCancel').disabled=true;
 try{ablyStatus(await ablyCall('cancel'));await pollAbly();}
 catch(e){$('ablySyncStatus').textContent=e.message;}
};
$('ablySave').onclick=()=>action(async()=>{
 const password=$('ablyPassword').value;$('ablyPassword').value='';
 try{const s=await ablyCall('save',$('ablyUsername').value,password);$('ablyPassword').placeholder='저장됨 · 변경할 때만 입력';$('ablySettingsStatus').textContent=s.message;}
 catch(e){$('ablySettingsStatus').textContent=e.message;throw e;}
 finally{$('ablyPassword').value='';}
},$('ablySave'));
$('ablySettingsDialog').addEventListener('close',()=>{$('ablyPassword').value='';});
$('headlessChrome').onchange=async()=>{try{const r=await api('browser-window',{headlessChrome:$('headlessChrome').checked});$('headlessChromeStatus').textContent=r.message;toast(r.message);}catch(e){$('headlessChromeStatus').textContent=e.message;$('headlessChrome').checked=!!state?.settings?.headlessChrome;}};
const syncHeadlessChrome=()=>{try{$('headlessChrome').checked=!!state?.settings?.headlessChrome;}catch(e){}};
$('ablySettingsBtn').addEventListener('click',syncHeadlessChrome);$('ablySyncSettings').addEventListener('click',syncHeadlessChrome);
document.querySelectorAll('[data-ably-close]').forEach(b=>b.onclick=()=>$(b.dataset.ablyClose).close());
$('ablyLegacyImport').onclick=()=>{$('ablySyncDialog').close();invalidateExternal();$('externalDialog').showModal();};
try{const d=new Date(Date.now()+864e5+9*36e5);$('amoodPreviewDue').value=d.toISOString().slice(0,10);}catch(e){}
$('amoodPreview').onclick=async()=>{
 const order=($('amoodPreviewOrder').value||'').trim();
 if(!/^\d+$/.test(order)){$('ablySyncStatus').textContent='아무드 주문번호(숫자)를 입력하세요.';return;}
 try{ablyStatus(await ablyCall('amood_preview',order,$('amoodPreviewDue').value||''));await pollAbly();}
 catch(e){$('ablySyncStatus').textContent=e.message;$('ablySyncStatus').classList.add('error');}
};
$('amoodPush').onclick=async()=>{
 if(!confirm('앱에서 안내한 아무드 주문(1차 미발송)에 배송지연 메시지를 실제로 발송합니다. 계속할까요?'))return;
 try{ablyStatus(await ablyCall('amood_push'));await pollAbly();}
 catch(e){$('ablySyncStatus').textContent=e.message;$('ablySyncStatus').classList.add('error');}
};
