'use strict';
(()=>{
 const el=id=>document.getElementById(id);let job={},polling=false;
 document.body.insertAdjacentHTML('beforeend',`<dialog id="pickupDialog" class="ably-dialog"><div class="dialoghead"><h2>회수접수 · 기존 상태와 이력</h2><button id="pickupClose">닫기</button></div><p class="sub">원운송장번호를 한 줄에 하나씩 입력하세요. 고객명·연락처는 탭으로 구분할 수 있습니다. 엑셀은 첫 열 원송장번호, 둘째 열 고객명, 셋째 열 연락처입니다.</p><textarea id="pickupInput" rows="5" aria-label="회수 원운송장 목록" placeholder="원운송장번호&#9;고객명&#9;연락처"></textarea><div class="settings-actions"><button id="pickupFile">엑셀 목록 불러오기</button><button id="pickupInspect">기존 상태 확인</button><button id="pickupStart" class="return-primary">회수 접수</button><button id="pickupCancel" hidden>중단 · 창 닫기</button></div><p class="sub">기존 상태 확인 후 회수 접수를 직접 선택하세요. 준비중·요청 또는 반품수정/삭제가 표시되는 기존 접수는 중복 신청하지 않습니다. 재접수가 가능한 상태일 때 다음 차수로 남깁니다. 반품삭제는 실행하지 않습니다.</p><p id="pickupStatus" role="status"></p><p id="pickupReport" class="sub"></p><div id="pickupHistory"></div><div id="pickupResults"></div></dialog><dialog id="pickupConfirmDialog"><h2>이지어드민 확인</h2><p id="pickupConfirmText"></p><button id="pickupConfirmNo">취소</button><button id="pickupConfirmYes">확인</button></dialog>`);
 window.pickupCall=async(action,payload=null)=>{
  const bridge=window.pywebview?.api;if(!bridge?.pickup_action)throw Error('새 버전 Mac 앱에서 사용할 수 있습니다.');
  const r=await bridge.pickup_action(token,action,payload,job.id||'');if(r.error)throw Error(r.error);return r;
 };
 function rows(){
  const parsed=el('pickupInput').value.split(/\r?\n/).filter(x=>x.trim()).map(x=>{const [invoice,customer='',phone='']=x.trim().split(/\t|,/);return {invoice:invoice.trim(),customer:customer.trim(),phone:phone.trim()};});
  if(!parsed.length)throw Error('원운송장번호를 입력하세요.');return parsed;
 }
 function render(s){
  job=s;el('pickupStatus').textContent=s.message||'';el('pickupStatus').classList.toggle('error',['error','error_open'].includes(s.phase));
  for(const id of ['pickupStart','pickupInspect','pickupFile','pickupInput'])el(id).disabled=!!s.running;
  el('pickupCancel').hidden=!s.running;
  if(el('pickupContinue'))el('pickupContinue').hidden=!(s.running&&s.phase==='error_open'&&s.browserCanContinue);
  el('pickupReport').textContent=s.reportPath?'결과 엑셀: '+s.reportPath:'';
  const list=s.rows||[];const bad=list.filter(r=>!['접수 완료','이미 접수됨','접수 전 확인'].includes(r.result));
  el('pickupResults').innerHTML=(bad.length?`<p class="dangertext"><b>확인 필요 ${bad.length}건</b></p>`:'')+list.map(r=>`<article class="pickup-result"><b>${esc(r.invoice)} · ${esc(r.customer||'')}</b><p>${esc(r.carrier||'')} / ${esc(r.receiver||'')} / ${esc(r.result)} / ${esc(r.acceptedAt||'—')}</p><small>${r.attempt?esc(r.attempt+'차 회수접수')+' · ':''}${esc(r.note||'')}</small>${r.ablyResult?`<small class="${/완료|접수 단계 없음|건너뜀/.test(r.ablyResult)?'secondary':'dangertext'}">${/^지그재그|^에이블리/.test(r.ablyResult)?'':'에이블리: '}${esc(r.ablyResult)}${r.ablyNote?' · '+esc(r.ablyNote):''}</small>`:''}</article>`).join('');
  let numbers=[];try{numbers=rows().map(r=>r.invoice.replace(/[\s-]/g,''));}catch(_){}
  const history=(s.history||[]).filter(h=>numbers.includes(h.invoice));
  el('pickupHistory').innerHTML='<h3>기존 회수 이력</h3>'+(history.length?history.slice().reverse().map(h=>`<p>${esc(h.invoice)} · ${h.attempt?esc(h.attempt+'차 회수접수'):'상태 확인'} · ${esc(h.result)} · ${esc(dateTime(h.at))}<small class="secondary">${esc(h.note||'')}${h.ablyResult?' · 에이블리: '+esc(h.ablyResult):''}</small></p>`).join(''):'<p class="sub">저장된 회수접수 이력이 없습니다. EX00 기존 접수도 다시 확인합니다.</p>');
  const q=s.loginQuestion;if(q){el('pickupConfirmText').textContent=q.text||q.message||'';if(!el('pickupConfirmDialog').open)el('pickupConfirmDialog').showModal();}else if(el('pickupConfirmDialog').open)el('pickupConfirmDialog').close();
 }
 window.openPickupMany=async(rows)=>{
  // 2026-10-20: several return/exchange rows checked in the 반품/교환 table → one 회수접수 run.
  el('pickupInput').value=rows.map(row=>[row.invoice,row.recipient||'',row.recipientPhone||''].join('\t')).join('\n');
  if(!el('pickupDialog').open)el('pickupDialog').showModal();
  try{render(await window.pickupCall('status'));}catch(e){el('pickupStatus').textContent=e.message;}
 };
 window.openPickup=async(row)=>{
  if(row)el('pickupInput').value=[row.invoice,row.recipient||'',row.recipientPhone||''].join('\t');
  if(!el('pickupDialog').open)el('pickupDialog').showModal();
  try{render(await window.pickupCall('status'));}catch(e){el('pickupStatus').textContent=e.message;}
 };
 el('pickupClose').onclick=()=>el('pickupDialog').close();
 el('pickupFile').onclick=async()=>{try{
  const file=await window.pywebview.api.pick_orders(token);if(!file)return;if(file.error)throw Error(file.error);
  const bytes=Uint8Array.from(atob(file.data),c=>c.charCodeAt(0));const sheets=await NuavuExcel.read(bytes.buffer,file.name);
  if(sheets.length!==1)throw Error('시트 한 개의 목록을 선택하세요.');let values=sheets[0].rows.filter(r=>r.some(v=>String(v??'').trim()));
  if(values.length&&/원.?운?송장|송장번호/.test(String(values[0][0])))values=values.slice(1);
  if(values.length>1000)throw Error('한 번에 1,000건까지 입력하세요.');el('pickupInput').value=values.map(r=>r.slice(0,3).map(v=>String(v??'')).join('\t')).join('\n');el('pickupStatus').textContent=values.length+'건을 읽었습니다. 기존 상태를 확인하세요.';
 }catch(e){el('pickupStatus').textContent=e.message;}};
 el('pickupCancel').insertAdjacentHTML('afterend','<button id="pickupContinue" class="primary" hidden>로그인 완료 · 계속</button>');
 for(const [id,action] of [['pickupStart','start'],['pickupInspect','inspect'],['pickupCancel','cancel'],['pickupContinue','continue']])el(id).onclick=async()=>{try{render(await window.pickupCall(action,['cancel','continue'].includes(action)?null:rows()));}catch(e){el('pickupStatus').textContent=e.message;}};
 for(const [id,accepted] of [['pickupConfirmYes',true],['pickupConfirmNo',false]])el(id).onclick=async()=>{try{await window.pickupCall('answer',{id:job.loginQuestion?.id,accepted});render(await window.pickupCall('status')); }catch(e){el('pickupConfirmText').textContent=e.message;}};
 async function poll(){if(polling||window.factoryResetStarted||!state?.desktopMode||!window.pywebview?.api?.pickup_action)return;polling=true;try{const s=await window.pickupCall('status');render(s);if((s.running||['error','error_open'].includes(s.phase))&&!el('pickupDialog').open){el('pickupStatusBanner').hidden=false;el('pickupStatusBanner').textContent='회수접수 · '+(s.message||'상태 확인');}else el('pickupStatusBanner').hidden=true;}catch(_){}finally{polling=false;}}
 document.querySelector('.cards').insertAdjacentHTML('afterend','<button id="pickupStatusBanner" class="pickup-status-banner" hidden></button>');el('pickupStatusBanner').onclick=()=>window.openPickup();
 // 09:05 CPU 최적화: 2초 폴링은 작업 중·창 열림일 때만, 평소엔 15초.
 let pollTick=0;setInterval(()=>{pollTick++;const hot=job?.running||el('pickupDialog').open;if(hot||pollTick%8===0)poll();},2000);
})();
