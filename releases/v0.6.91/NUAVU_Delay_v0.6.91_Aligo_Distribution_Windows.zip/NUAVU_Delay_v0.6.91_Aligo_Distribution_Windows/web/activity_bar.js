'use strict';
// 2026-10-22 19:03 요청: 진행상황 바 — 지금 돌고 있는 작업 + 다음 예정 작업 (Nuavu Auto와 같은 모양).
(()=>{
 const bar=document.createElement('section');bar.id='activityBar';bar.className='activity-bar';bar.hidden=true;
 bar.innerHTML='<div class="activity-now"><span class="activity-dot"></span><span id="activityState" class="activity-state">대기 중</span><span id="activityJobs" class="activity-jobs"></span></div><div class="activity-next"><span class="activity-clock">🕒 예정</span><span id="activityUpcoming" class="activity-upcoming"></span></div>';
 document.querySelector('main')?.prepend(bar);   // 19:07 요청: 대시보드 최상단
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const when=iso=>{const d=new Date(iso);if(isNaN(d))return '';const p=n=>String(n).padStart(2,'0');return `${d.getMonth()+1}/${d.getDate()} ${p(d.getHours())}:${p(d.getMinutes())}`;};
 async function tick(){
  const api=window.pywebview?.api;
  if(typeof token==='undefined'||!api?.activity_status){setTimeout(tick,3000);return;}
  try{
   const s=await api.activity_status(token);if(s.error)throw Error(s.error);
   bar.hidden=false;const busy=(s.running||[]).length>0;bar.classList.toggle('is-busy',busy);
   document.getElementById('activityState').textContent=busy?'진행 중':'대기 중';
   document.getElementById('activityJobs').innerHTML=busy?s.running.map(r=>`<b>${esc(r.name)}</b>${r.message?' <span class="activity-msg">— '+esc(r.message)+'</span>':''}`).join('<span class="activity-sep">·</span>'):'<span class="activity-msg">진행 중인 작업이 없습니다.</span>';
   const up=s.upcoming||[];
   document.getElementById('activityUpcoming').innerHTML=up.length?up.map(u=>`<span class="activity-item">${esc(u.name)} <b>${esc(when(u.at))}</b></span>`).join('<span class="activity-sep">·</span>'):'<span class="activity-msg">예정된 자동 작업이 없습니다.</span>';
  }catch(e){bar.hidden=true;}
  setTimeout(tick,(bar.classList.contains('is-busy'))?2000:5000);
 }
 setTimeout(tick,1200);
})();
