'use strict';
/* 자사몰(카페24) 로그인 + 품절 옵션 처리 상태 (2026-10-20). 품절 안내 문자(카드/무통장)를 요청·예약하면 자사몰·에이블리 품절 옵션 OFF가 자동으로 돈다. */
document.body.insertAdjacentHTML('beforeend',`
<dialog id="cafe24SettingsDialog" class="ably-dialog">
 <div class="dialoghead"><h2>⚙ 자사몰(카페24) 설정 · 품절 옵션 처리</h2><button data-cafe24-close="cafe24SettingsDialog">닫기</button></div>
 <p>카페24 쇼핑몰 관리자(eclogin.cafe24.com) 로그인 계정입니다. 저장하면 <b>품절 안내 문자(카드/무통장)를 요청·예약하는 즉시</b> 자사몰에서 해당 상품 옵션을 진열안함(원컬러면 상품 전체 진열안함)으로 바꾸고, 에이블리에서도 같은 옵션을 진열 OFF(원컬러면 미진열)합니다. 자사몰 계정이 없으면 에이블리만 처리합니다. 같은 배치에서 <b>해당 주문의 취소 접수</b>(자사몰 품절 취소 · 에이블리 주문취소 접수 처리)까지 이어서 진행합니다.</p>
 <label>아이디<input id="cafe24Username" autocomplete="off"></label>
 <label>비밀번호<input id="cafe24Password" type="password" autocomplete="new-password" placeholder="비밀번호"></label>
 <p class="sub">macOS 키체인의 별도 항목에 저장합니다. 저장된 비밀번호는 화면에 다시 표시하지 않습니다.</p>
 <div class="settings-actions"><button id="cafe24Save" class="primary">로그인 정보 저장</button><button id="cafe24Forget" class="danger-quiet">저장 계정 삭제</button><button id="cafe24Kick">대기 중인 품절 처리 지금 실행</button><button id="cafe24Cancel">처리 중단</button></div>
 <p id="cafe24SettingsStatus" class="sub" role="status"></p>
 <h3>테스트 (검증용 · 정상 동작 확인 뒤 제거)</h3>
 <p class="sub">실제 사이트에서 실제로 처리합니다. 자사몰은 <b>주문번호_품목번호</b>(예: 20261018-0000029_1456), 에이블리는 <b>상품주문번호</b>를 넣으세요. 결과·실패 사유는 아래 이력에 그대로 남습니다.</p>
 <div class="testbox"><select id="cafe24TestPlatform"><option value="ably">에이블리 주문취소</option><option value="cafe24">자사몰 주문취소</option><option value="zigzag">지그재그 주문취소(판매자 직접 취소)</option></select><input id="cafe24TestId" placeholder="에이블리 상품주문번호 / 자사몰 주문번호_품목번호 / 지그재그 주문번호" style="width:260px"><button id="cafe24TestCancel">취소 테스트 실행</button></div>
 <div class="testbox" style="margin-top:6px"><input id="cafe24TestProduct" placeholder="상품명 (엑셀 그대로)" style="width:300px"><input id="cafe24TestOption" placeholder="옵션 예: 그레이/FREE" style="width:160px"><button id="cafe24TestDisplay">품절 옵션 처리 테스트</button></div>
 <h3>품절 옵션 처리 이력</h3><p id="cafe24JobStatus" class="sub" role="status"></p>
 <div id="cafe24Log" class="notice small"></div>
 <h3>품절 주문취소 접수 이력</h3><p class="sub">품절 안내 문자와 함께 자사몰(계정이 있을 때)·에이블리에서 해당 주문을 취소 접수합니다. 자사몰 무통장·가상계좌는 구분 품절, 환불은행 농협중앙회 / 계좌번호 123 / 예금주 123으로, 신용카드는 환불방식 그대로 접수한 뒤 주문상세에서 전체·부분취소합니다. 에이블리는 발송 관리 › 주문취소 접수 처리(판매자 귀책 · 상품 품절, 구매고객 안내 확인)입니다. 지그재그(계정이 있을 때)는 배송준비중(조회기간 전체)에서 한 주문만 선택 › 판매자 직접 취소 › 사유 품절 + 상세사유 › 취소 처리하기이며, 품절 사유라 지그재그 옵션도 품절로 바뀝니다.</p>
 <h3>예약된 주문취소</h3><p class="sub">예약 품절 문자는 전송 10분 전에, '오전 9시 예약취소'는 08:50에 취소 접수합니다. 앱이 켜져 있어야 실행됩니다. 예약 문자를 취소하면 그 주문의 예약 주문취소도 하지 않습니다.</p>
 <div id="cafe24CancelSchedule" class="notice small"></div>
 <div id="cafe24CancelLog" class="notice small"></div>
</dialog>`);
let cafe24Timer=null;
async function cafe24Call(action,username='',password='',payload=null){
 const bridge=window.pywebview?.api;
 if(!state?.desktopMode||!bridge?.soldout_display_action)throw Error('자사몰 설정과 품절 옵션 처리는 설치한 맥 앱에서 사용할 수 있습니다.');
 const result=await bridge.soldout_display_action(token,action,username,password,payload);if(result.error)throw Error(result.error);return result;
}
window.cafe24Call=cafe24Call;
function cafe24Paint(s){
 $('cafe24JobStatus').textContent=(s.message||'')+(s.queued?` · 대기 ${s.queued}건`:'');$('cafe24JobStatus').classList.toggle('error',s.phase==='error');
 $('cafe24Cancel').disabled=!s.running;$('cafe24Kick').disabled=!!s.running||!s.queued;
 const log=s.log||[];
 $('cafe24Log').innerHTML=log.length?log.slice(0,60).map(r=>`<p><b>${esc(r.product)} / ${esc(r.option)}</b> <span class="secondary">${dateTime(r.at)}</span><br><span class="${/실패|검색불가/.test(r.cafe24||'')?'dangertext':'secondary'}">${esc(r.cafe24||'')}${r.cafe24Detail?' · '+esc(r.cafe24Detail):''}</span><br><span class="${/실패|검색불가/.test(r.ably||'')?'dangertext':'secondary'}">${esc(r.ably||'')}${r.ablyDetail?' · '+esc(r.ablyDetail):''}</span></p>`).join(''):'아직 처리한 품절 옵션이 없습니다.';
 const sc=s.cancelSchedule||[];
 $('cafe24CancelSchedule').innerHTML=sc.length?sc.map(e=>`<p><b>${dateTime(e.at)} 실행</b> · ${e.source==='notice'?'예약 품절 문자('+dateTime(e.sendAt)+') 10분 전':'오전 9시 예약취소 버튼'} · ${e.count}건<br><span class="secondary">${esc((e.orders||[]).join(', '))}</span> <button class="tiny" data-unschedule="${esc(e.id)}">예약 해제</button></p>`).join(''):'예약된 주문취소가 없습니다.';
 const cl=s.cancelLog||[];
 $('cafe24CancelLog').innerHTML=cl.length?cl.slice(0,60).map(r=>`<p><b>${r.test?'[테스트] ':''}${esc({cafe24:'자사몰',zigzag:'지그재그'}[r.platform]||'에이블리')} ${esc(r.orderId||'')}${r.sno?' · 상품주문번호 '+esc(r.sno):''}${r.omNo?' · 품목 '+esc(r.omNo):''}</b> <span class="secondary">${dateTime(r.at)}</span><br><span class="secondary">${esc(r.product||'')} / ${esc(r.option||'')}</span><br><span class="${/실패/.test(r.result||'')?'dangertext':'secondary'}">${esc(r.result||'')}${r.detail?' · '+esc(r.detail):''}</span></p>`).join(''):'아직 접수한 주문취소가 없습니다.';
}
async function pollCafe24(){
 clearTimeout(cafe24Timer);
 try{const s=await cafe24Call('status');cafe24Paint(s);if(s.running&&$('cafe24SettingsDialog').open)cafe24Timer=setTimeout(pollCafe24,1500);}
 catch(e){$('cafe24JobStatus').textContent=e.message;}
}
async function openCafe24Settings(){
 $('cafe24Password').value='';$('cafe24Username').value='';$('cafe24Save').disabled=true;
 $('cafe24SettingsDialog').showModal();$('cafe24SettingsStatus').textContent='키체인 저장 상태를 확인합니다.';
 try{const s=await cafe24Call('settings');$('cafe24Username').value=s.username||'';$('cafe24Password').placeholder=s.hasPassword?'저장됨 · 변경할 때만 입력':'비밀번호';$('cafe24Save').disabled=!s.available;$('cafe24SettingsStatus').textContent=s.hasPassword?'자사몰 계정 저장됨 · '+s.username:'자사몰 계정이 없습니다. 비워 두면 에이블리만 처리합니다.';}
 catch(e){$('cafe24SettingsStatus').textContent=e.message;$('cafe24Save').disabled=!window.pywebview?.api?.soldout_display_action;}
 await pollCafe24();
}
window.openCafe24Settings=openCafe24Settings;
$('cafe24SettingsBtn').onclick=openCafe24Settings;
document.querySelector('[data-cafe24-close]').onclick=()=>$('cafe24SettingsDialog').close();
$('cafe24Save').onclick=()=>action(async()=>{
 const password=$('cafe24Password').value;$('cafe24Password').value='';
 try{const s=await cafe24Call('save',$('cafe24Username').value,password);$('cafe24Password').placeholder='저장됨 · 변경할 때만 입력';$('cafe24SettingsStatus').textContent=s.message;}
 catch(e){$('cafe24SettingsStatus').textContent=e.message;throw e;}
 finally{$('cafe24Password').value='';}
},$('cafe24Save'));
$('cafe24Forget').onclick=()=>action(async()=>{const s=await cafe24Call('forget');$('cafe24Username').value='';$('cafe24Password').placeholder='비밀번호';$('cafe24SettingsStatus').textContent=s.message;},$('cafe24Forget'));
// 2026-10-22 요청: 품절칸 '취소만 진행' — 품절(안내 완료/확인 필요) 목록에서 체크한 자사몰·에이블리 주문만 취소 접수. 미진열·문자 재전송 없음.
function cancelOnlyRows(){return state?.rows?state.rows.filter(r=>selected.has(r.key)&&/자사몰|에이블리|지그재그/.test(r.seller||'')):[];}
function renderCancelOnly(){
 const b=$('cancelOnlyBtn');if(!b)return;
 const scope=['charcoal','soldout_check'].includes($('statusFilter').value)||cancelOnlyRows().some(r=>r.soldoutNotified);
 b.hidden=!scope||!state?.desktopMode;b.disabled=!cancelOnlyRows().length;
 const m=$('cancelMorningBtn');if(m){m.hidden=b.hidden;m.disabled=b.disabled;}
}
window.renderCancelOnly=renderCancelOnly;
async function cancelSelected(when){
 const rows=cancelOnlyRows();if(!rows.length)throw Error('취소할 자사몰·에이블리·지그재그 주문을 체크하세요.');
 const ids=[...new Set(rows.map(r=>r.seller.replace('누아브 ','')+' '+r.orderId))];
 if(when==='morning'){
  if(!confirm(`선택한 ${ids.length}개 주문을 오전 9시 예약 문자 전송 10분 전(08:50)에 자사몰·에이블리·지그재그에서 취소 접수하도록 예약합니다.\n미진열·문자/알림톡은 다시 하지 않습니다. 앱이 켜져 있어야 실행됩니다.\n\n${ids.slice(0,15).join('\n')}${ids.length>15?'\n…':''}\n\n예약할까요?`))return;
  const s=await cafe24Call('cancel_only','','',{keys:rows.map(r=>r.key),when:'morning'});
  toast(`주문취소 ${s.scheduled}건 예약 · ${dateTime(s.at)} 실행${s.skipped?` · 이미 취소된 ${s.skipped}건 제외`:''} · ⚙ 자사몰 설정에서 예약 해제 가능`);return;
 }
 if(!confirm(`선택한 ${ids.length}개 주문을 자사몰·에이블리·지그재그에서 실제로 취소 접수합니다(지그재그는 판매자 직접 취소 · 사유 품절 · 환불).\n미진열·문자/알림톡은 다시 하지 않습니다. 이미 취소 완료로 기록된 건은 건너뜁니다.\n\n${ids.slice(0,15).join('\n')}${ids.length>15?'\n…':''}\n\n진행할까요?`))return;
 const s=await cafe24Call('cancel_only','','',{keys:rows.map(r=>r.key)});
 toast(`취소만 진행 ${s.started}건 시작${s.skipped?` · 이미 취소된 ${s.skipped}건 건너뜀`:''} · 결과는 알림과 ⚙ 자사몰 설정 › 주문취소 이력에 남습니다.`);
}
$('cancelOnlyBtn').onclick=()=>action(()=>cancelSelected('now'),$('cancelOnlyBtn'));
$('cancelMorningBtn').onclick=()=>action(()=>cancelSelected('morning'),$('cancelMorningBtn'));
$('cafe24CancelSchedule').addEventListener('click',e=>{const b=e.target.closest('[data-unschedule]');if(!b)return;if(!confirm('이 예약 주문취소를 해제할까요?'))return;b.disabled=true;cafe24Call('unschedule','','',{id:b.dataset.unschedule}).then(cafe24Paint).catch(err=>{$('cafe24SettingsStatus').textContent=err.message;b.disabled=false;});});
// 2026-10-22 02:15: 자사몰 '품절안내 (자사몰/무통장)'(환불 계좌 요청)을 보낸 주문은 주문 엑셀에서 빠져도 남는다 → 환불완료를 누르면 사라진다.
function refundButton(r){if(!r.refundHold)return r.sendHold&&r.sendHoldMissing?'<span class="secondary">주문엑셀에서 빠짐 · 품절 문자 발송 대기(앱이 취소함)</span>':'';return `<button class="tiny pink-button" data-refund-done="${esc(r.key)}" title="자사몰 무통장 환불을 마쳤으면 누르세요. 이 주문 상품을 목록에서 뺍니다(이력 유지).">환불완료</button>${r.refundHoldMissing?'<span class="secondary">주문엑셀에서 빠짐 · 환불 대기</span>':'<span class="secondary">환불 대기</span>'}`;}
window.refundButton=refundButton;
$('rows').addEventListener('click',e=>{const b=e.target.closest('[data-refund-done]');if(!b)return;const r=state.rows.find(x=>x.key===b.dataset.refundDone);if(!r)return;
 const keys=state.rows.filter(x=>x.refundHold&&x.seller===r.seller&&x.orderId===r.orderId).map(x=>x.key);
 if(!confirm(`자사몰 주문 ${r.orderId} 환불을 마쳤나요?\n이 주문의 환불 대기 상품 ${keys.length}개를 목록에서 뺍니다. (안내 이력은 남습니다)`))return;
 action(async()=>{const x=await api('refund-done',{keys});toast(x.message);},b);});
$('cafe24Kick').onclick=()=>action(async()=>{cafe24Paint(await cafe24Call('kick'));await pollCafe24();},$('cafe24Kick'));
$('cafe24Cancel').onclick=()=>action(async()=>{cafe24Paint(await cafe24Call('cancel'));},$('cafe24Cancel'));
$('cafe24TestCancel').onclick=async()=>{const platform=$('cafe24TestPlatform').value,id=$('cafe24TestId').value.trim();if(!id)return;if(!confirm((platform==='ably'?'에이블리 상품주문번호 ':platform==='zigzag'?'지그재그 주문번호 ':'자사몰 주문 ')+id+' 을(를) 실제로 취소 접수합니다. 진행할까요?'))return;$('cafe24TestCancel').disabled=true;try{cafe24Paint(await cafe24Call('test_cancel','','',{platform,id}));pollCafe24();}catch(e){$('cafe24SettingsStatus').textContent=e.message;}finally{$('cafe24TestCancel').disabled=false;}};
$('cafe24TestDisplay').onclick=async()=>{const product=$('cafe24TestProduct').value.trim(),option=$('cafe24TestOption').value.trim();if(!product)return;$('cafe24TestDisplay').disabled=true;try{cafe24Paint(await cafe24Call('test_display','','',{product,option}));pollCafe24();}catch(e){$('cafe24SettingsStatus').textContent=e.message;}finally{$('cafe24TestDisplay').disabled=false;}};
$('cafe24SettingsDialog').addEventListener('close',()=>{$('cafe24Password').value='';clearTimeout(cafe24Timer);});
