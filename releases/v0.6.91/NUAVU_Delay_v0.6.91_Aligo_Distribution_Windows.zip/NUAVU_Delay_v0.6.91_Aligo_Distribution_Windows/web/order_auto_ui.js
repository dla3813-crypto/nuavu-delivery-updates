'use strict';
let ezadminQuestion=null;
let lastOrderErrorId=null,orderRecoveryJob=null;
let orderAutoTimer=null,orderAutoPolling=false,orderAutoApplying=false,orderAutoCancelled=false;
let ezadminFormBusy=false,ezadminFormAvailable=false,ezadminOperationRunning=false,ezadminSettingsLoading=false,orderStateEpoch=0;
function ezadminFormControls(){
 const disabled=ezadminFormBusy||ezadminOperationRunning||!ezadminFormAvailable;
 for(const id of ['checkEzadminLogin','saveEzadminLogin','ezadminDomain','ezadminUsername','ezadminPassword'])$(id).disabled=disabled;
}
function orderBridge(){const b=window.pywebview?.api;if(!state?.desktopMode||!b?.order_auto_status)throw Error('자동 불러오기는 v0.6.36 배포판 맥 앱에서 사용할 수 있습니다.');return b;}
function showOrderSettings(s){$('orderDownloadFolder').textContent=s.folder||'아직 연결하지 않았습니다.';$('orderAutoGroup').value=s.group||state?.settings?.shopName||'';$('orderAutoLast').textContent=s.lastDownload?`최근 다운로드 ${dateTime(s.lastDownload)} · ${s.lastFile}`:'';}
function orderProgress(text,error=false){$('orderAutoProgress').textContent=text;$('orderAutoProgress').classList.toggle('error',error);}
function orderControls(running){ezadminOperationRunning=!!running;ezadminFormControls();$('cancelEzadminLogin').hidden=!running;for(const id of ['autoOrderImport','manualOrderImport','saveOrderAutoGroup','pickOrderDownloadFolder','orderAutoGroup'])$(id).disabled=running||ezadminFormBusy;$('cancelOrderAuto').hidden=!running;}
function stopOrderPolling(){clearTimeout(orderAutoTimer);orderAutoTimer=null;}
async function pollOrderAuto(){
 if(window.factoryResetStarted||ezadminFormBusy||ezadminSettingsLoading)return;
 if(orderAutoPolling)return;stopOrderPolling();orderAutoPolling=true;const epoch=orderStateEpoch;
 try{
  const r=await orderBridge().order_auto_status(token);if(window.factoryResetStarted||ezadminFormBusy||ezadminSettingsLoading||epoch!==orderStateEpoch)return;if(r.error)throw Error(r.error);
  const failed=['error','error_open'].includes(r.phase);
  showOrderSettings(r.settings);orderControls(r.running||r.phase==='ready');orderProgress(r.message,failed);
  $('cancelEzadminLogin').textContent=r.phase==='error_open'?'Chrome 창 닫기':'로그인 확인 중단';
  $('cancelOrderAuto').textContent=r.phase==='error_open'?'Chrome 창 닫기':'자동 불러오기 중단';
  if($('ezadminSettingsDialog').open)ezadminLoginStatus(r.message,failed);
  renderEzadminQuestion(r.loginQuestion);
  renderOrderFailure(r);
  if(r.phase==='ready'&&!orderAutoApplying&&!orderAutoCancelled){
   orderAutoApplying=true;
   try{const f=await orderBridge().order_auto_result(token,r.id);if(window.factoryResetStarted)return;if(f.error)throw Error(f.error);if(orderAutoCancelled)return;await applyAutoOrderFile(f);}
   finally{orderAutoApplying=false;orderControls(false);}
  }else if(r.running){orderAutoTimer=setTimeout(pollOrderAuto,1000);}
 }catch(e){if(epoch!==orderStateEpoch||window.factoryResetStarted)return;orderProgress(e.message,true);orderControls(false);toast(e.message,true);}
 finally{orderAutoPolling=false;if(epoch!==orderStateEpoch&&!window.factoryResetStarted&&!ezadminFormBusy&&!ezadminSettingsLoading)orderAutoTimer=setTimeout(pollOrderAuto,0);}
}
function renderOrderFailure(r){
 const recovery=!!r.running&&!!r.browserRecovery,captcha=recovery&&!!r.captchaWait;
 orderRecoveryJob=recovery?r.id:null;
 $('orderBrowserRecovery').hidden=!recovery||!(r.browserCanContinue||captcha);
 const waiting=r.phase!=='error_open'||!!r.loginQuestion;
 for(const id of ['orderLoginServer','reopenOrderBrowser','continueOrderBrowser'])$(id).disabled=waiting;
 $('continueOrderBrowser').hidden=!r.browserCanContinue||captcha;
 $('captchaDoneOrderBrowser').hidden=!captcha;$('captchaDoneOrderBrowser').disabled=waiting;
 $('reopenOrderBrowser').hidden=captcha;$('orderLoginServer').closest('label').hidden=captcha;
 document.querySelector('#orderErrorDialog h2').textContent=captcha?'이지어드민 캡차 인증 부탁드립니다':'이지어드민 작업이 중단되었습니다';
 $('closeOrderErrorBrowser').hidden=!recovery;
 if(!['error','error_open','browser_recovery'].includes(r.phase)){
  if(!r.loginQuestion&&$('orderErrorDialog').open)$('orderErrorDialog').close();
  return;
 }
 $('orderErrorText').textContent=r.message;
 $('orderErrorHint').textContent=captcha?'Chrome 창에서 캡차 입력 → 다운로드 신청(안내 확인 · 확인했습니다 입력 · 접수)까지 직접 하신 뒤 "다운로드 완료"를 누르세요. 다운로드관리자(BL30)에서 이번 확장주문검색을 받아 반영합니다.':recovery?(r.browserCanContinue?'같은 Chrome 환경을 유지하고 있습니다. 페이지를 다시 열거나 직접 로그인한 뒤 이어가기를 누르세요.':'엑셀 신청 후 중단되어 현재 Chrome 화면을 유지합니다. 로그인 이동·자동 재신청은 하지 않습니다. 열린 다운로드관리자에서 해당 신청시간의 결과를 확인하세요.'):'이 안내는 설정과 주문 불러오기 창에도 남아 있습니다.';
 const id=r.id||r.message;if(lastOrderErrorId===id||r.loginQuestion)return;lastOrderErrorId=id;
 $('orderRecoveryError').textContent='';
 if(!$('orderErrorDialog').open)$('orderErrorDialog').showModal();
}
async function orderBrowserAction(action){
 const id=orderRecoveryJob;if(!id)return;
 for(const key of ['orderLoginServer','reopenOrderBrowser','continueOrderBrowser','captchaDoneOrderBrowser'])$(key).disabled=true;
 $('orderRecoveryError').textContent='';
 try{const r=await orderBridge().order_browser_action(token,id,action,$('orderLoginServer').value);if(r.error)throw Error(r.error);renderOrderFailure(r);await pollOrderAuto();}
 catch(e){$('orderRecoveryError').textContent=e.message;await pollOrderAuto();}
}
$('reopenOrderBrowser').onclick=()=>orderBrowserAction('open');
$('continueOrderBrowser').onclick=()=>orderBrowserAction('continue');
$('captchaDoneOrderBrowser').onclick=()=>orderBrowserAction('downloaded');
$('closeOrderErrorBrowser').onclick=()=>action(async()=>{
 const r=await orderBridge().order_auto_cancel(token);if(r.error)throw Error(r.error);
 $('orderErrorDialog').close();await pollOrderAuto();
},$('closeOrderErrorBrowser'));
function renderEzadminQuestion(q){
 ezadminQuestion=q||null;
 if(!q){if($('ezadminConfirmDialog').open)$('ezadminConfirmDialog').close();return;}
 $('ezadminConfirmText').textContent=q.text;$('ezadminConfirmError').textContent='';
 if(!$('ezadminConfirmDialog').open)$('ezadminConfirmDialog').showModal();
}
async function answerEzadminQuestion(accepted){
 const q=ezadminQuestion;if(!q)return;
 for(const id of ['ezadminConfirmYes','ezadminConfirmNo'])$(id).disabled=true;
 try{const r=await orderBridge().ezadmin_login_answer(token,q.jobId,q.id,accepted);if(r.error)throw Error(r.error);$('ezadminConfirmDialog').close();ezadminQuestion=null;await pollOrderAuto();}
 catch(e){$('ezadminConfirmError').textContent=e.message;}
 finally{for(const id of ['ezadminConfirmYes','ezadminConfirmNo'])$(id).disabled=false;}
}
$('ezadminConfirmYes').onclick=()=>answerEzadminQuestion(true);
$('ezadminConfirmNo').onclick=()=>answerEzadminQuestion(false);
$('ezadminConfirmDialog').addEventListener('cancel',e=>{e.preventDefault();answerEzadminQuestion(false);});
$('checkEzadminLogin').onclick=()=>saveEzadminForm(true);
$('cancelEzadminLogin').onclick=()=>$('cancelOrderAuto').click();
async function applyAutoOrderFile(f){
 // Use the same header detector, order identity parser and import API as manual.
 const file=new File([Uint8Array.from(atob(f.data),c=>c.charCodeAt(0))],f.name);
 const book=await NuavuExcel.read(await file.arrayBuffer(),file.name);
 if(book.length!==1)throw Error('자동 반영을 멈췄습니다. 시트가 여러 개이거나 없습니다. 저장된 파일을 수동으로 확인하세요.');
 const rows=book[0].rows,header=C.findHeader(rows),map=C.guessMapping(rows[header]||[]);
 const required=['seller','orderId','orderItemId','product','option','qty','orderDate'];
 if(required.some(k=>map[k]==null||map[k]<0))throw Error('배송지연 전체품목의 열 구성이 다릅니다. 저장된 파일을 수동으로 확인하세요.');
 const current=await api('state');
 if(current.settings.shopName!==f.shopName||current.settings.shopRevision!==f.shopRevision)throw Error('자동 불러오기 도중 쇼핑몰 설정이 바뀌었습니다. 새 설정으로 다시 불러오세요.');
 if(importScopeSaving||importScopePersisted<importScopeVersion)throw Error('판매처 체크 저장 후 다시 불러오세요.');
 C.setShopName(current.settings.shopName);
 const available=C.discoverSellers(rows,header,map),scope=C.rememberedSellers(available,current.settings);
 if(!scope.length)throw Error('선택된 판매처가 없습니다. 수동 불러오기에서 판매처 체크를 확인하세요.');
 const result=C.parseRows(rows,header,map,{scope,scopeLabels:true,strictShop:true});
 if(result.errors.length||!result.rows.length)throw Error('주문이 0건이거나 읽기 오류가 있어 자동 반영하지 않았습니다. 저장된 파일을 수동으로 확인하세요.');
 if(orderAutoCancelled)return;
 orderProgress('새 주문 파일을 반영 중입니다.');$('cancelOrderAuto').hidden=true;
 busy++;
 try{
  const r=await api('import',{rows:result.rows,excluded:result.excluded,mode:'snapshot',scope,available,scopeLabels:true,scopeFilter:true,shopRevision:f.shopRevision,replaceConfirmed:true,emptyConfirmed:false,parseErrors:[],fileName:f.name});
  selected.clear();await refresh();
  const message=`자동 불러오기 완료 · 신규 ${r.added} / 갱신 ${r.updated} / 목록 제외 ${r.inactive} / 예약·미요청 취소 ${r.cancelled||0}통`;
  orderProgress(message);toast(message);
 }finally{busy--;}
}
$('importBtn').onclick=()=>action(async()=>{
 lastOrderErrorId=null;
 $('orderImportChoice').showModal();
 if(!state?.desktopMode){orderProgress('자동 불러오기는 맥 앱에서 사용할 수 있습니다. 수동 엑셀 선택은 가능합니다.');$('autoOrderImport').disabled=true;return;}
 await pollOrderAuto();
},$('importBtn'));
$('manualOrderImport').onclick=()=>action(async()=>{
 $('orderImportChoice').close();
 if(!state?.desktopMode){$('fileInput').click();return;}
 if(!window.pywebview?.api)throw Error('앱 창 준비 중입니다. 잠시 후 다시 눌러주세요.');
 const f=await window.pywebview.api.pick_orders(token);if(!f)return;if(f.error)throw Error(f.error);
 await loadOrderFile(new File([Uint8Array.from(atob(f.data),c=>c.charCodeAt(0))],f.name));
},$('manualOrderImport'));
$('fileInput').onchange=()=>action(()=>loadOrderFile($('fileInput').files[0]),$('manualOrderImport'));
$('pickOrderDownloadFolder').onclick=()=>action(async()=>{const s=await orderBridge().pick_order_download_folder(token);if(s?.error)throw Error(s.error);if(s)showOrderSettings(s);},$('pickOrderDownloadFolder'));
$('saveOrderAutoGroup').onclick=()=>action(async()=>{const s=await orderBridge().order_auto_settings(token,$('orderAutoGroup').value);if(s.error)throw Error(s.error);showOrderSettings(s);toast('판매처 그룹 이름을 저장했습니다.');},$('saveOrderAutoGroup'));
$('autoOrderImport').onclick=()=>action(async()=>{
 if(orderAutoApplying)throw Error('주문을 반영 중입니다.');
 const b=orderBridge();const s=await b.order_auto_settings(token,$('orderAutoGroup').value);if(s.error)throw Error(s.error);
 orderAutoCancelled=false;stopOrderPolling();const r=await b.order_auto_start(token);if(r.error)throw Error(r.error);orderControls(true);await pollOrderAuto();
});
$('cancelOrderAuto').onclick=()=>action(async()=>{orderAutoCancelled=true;stopOrderPolling();const r=await orderBridge().order_auto_cancel(token);if(r.error)throw Error(r.error);orderProgress(r.message);orderControls(r.running);if(r.running)orderAutoTimer=setTimeout(pollOrderAuto,1000);},$('cancelOrderAuto'));
function ezadminLoginStatus(text,error=false){$('ezadminLoginStatus').textContent=text;$('ezadminLoginStatus').classList.toggle('error',error);}
$('ezadminSettingsBtn').onclick=()=>action(async()=>{
 orderStateEpoch++;stopOrderPolling();ezadminSettingsLoading=true;
 ezadminFormAvailable=false;ezadminFormControls();$('ezadminPreviousError').hidden=true;
 $('ezadminPassword').value='';$('ezadminDomain').value='';$('ezadminUsername').value='';$('saveEzadminLogin').disabled=true;
 $('ezadminSettingsDialog').showModal();ezadminLoginStatus('키체인 저장 상태를 확인합니다.');
 try{const b=orderBridge();if(!b.ezadmin_login_settings)throw Error('v0.6.36 배포판 설치기로 업데이트하세요.');
 const job=await b.order_auto_status(token);if(job.error)throw Error(job.error);
 if(job.running){orderControls(true);ezadminSettingsLoading=false;await pollOrderAuto();return;}
 orderControls(false);
 const s=await b.ezadmin_login_settings(token);if(s.error)throw Error(s.error);
 $('ezadminDomain').value=s.domain||'';$('ezadminUsername').value=s.username||'';
 $('ezadminPassword').placeholder=s.hasPassword?'저장됨 · 변경할 때만 입력':'비밀번호';ezadminFormAvailable=!!s.available;
 const failed=['error','error_open'].includes(job.phase);
 ezadminLoginStatus(s.hasPassword?'키체인에 저장된 계정이 있습니다.':'도메인·아이디·비밀번호를 입력하고 저장하세요.');
 $('ezadminPreviousError').hidden=!failed;$('ezadminPreviousError').textContent=failed?'이전 작업 안내: '+job.message:'';
 // Opening settings must never reopen a finished job's blocking error modal.
 if(failed){lastOrderErrorId=job.id||job.message;if($('orderErrorDialog').open)$('orderErrorDialog').close();}
 orderControls(false);
 }catch(e){ezadminFormAvailable=!!window.pywebview?.api?.ezadmin_login_save;ezadminFormControls();ezadminLoginStatus(e.message,true);throw e;}
 finally{ezadminSettingsLoading=false;}
},$('ezadminSettingsBtn'));
$('ezadminSettingsDialog').addEventListener('close',()=>{$('ezadminPassword').value='';});
$('saveEzadminLogin').onclick=()=>saveEzadminForm(false);
function saveEzadminForm(checkLogin){
 if(ezadminFormBusy||ezadminOperationRunning||!ezadminFormAvailable)return;
 ezadminFormBusy=true;orderStateEpoch++;stopOrderPolling();orderControls(false);
 return action(async()=>{
 try{const b=orderBridge();const password=$('ezadminPassword').value;$('ezadminPassword').value='';
 ezadminLoginStatus('로그인 정보를 저장하고 확인합니다.');
 const s=await b.ezadmin_login_save(token,$('ezadminDomain').value,$('ezadminUsername').value,password);if(s.error)throw Error(s.error);
 if(s.hasPassword!==true)throw Error('저장된 계정을 확인하지 못했습니다. 다시 저장하세요.');
 $('ezadminDomain').value=s.domain;$('ezadminUsername').value=s.username;$('ezadminPassword').placeholder='저장됨 · 변경할 때만 입력';
 $('ezadminPreviousError').hidden=true;$('ezadminPreviousError').textContent='';
 lastOrderErrorId=null;if($('orderErrorDialog').open)$('orderErrorDialog').close();
 ezadminLoginStatus(s.message);toast(s.message);
 if(checkLogin){
  orderAutoCancelled=false;const job=await b.ezadmin_login_check(token);if(job.error)throw Error(job.error);
  orderControls(job.running||job.phase==='ready');
 }
 }catch(e){ezadminLoginStatus(e.message,true);throw e;}
 finally{$('ezadminPassword').value='';ezadminFormBusy=false;orderControls(ezadminOperationRunning);}
 if(checkLogin)await pollOrderAuto();
 });
}
