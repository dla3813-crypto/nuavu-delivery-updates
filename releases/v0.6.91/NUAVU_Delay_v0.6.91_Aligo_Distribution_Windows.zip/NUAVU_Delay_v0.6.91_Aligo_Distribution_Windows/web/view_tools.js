'use strict';
/* Whole-page scale (⌘ + 스크롤 / ⌘ + − 0), same as the main edition. Saved as settings.tableZoom.
   Content scale belongs to this app only. CSS classes keep the restrictive CSP.
   Ordinary wheel scrolling and Cmd+C/V/F remain untouched. No external calls. */
(function(root){
 const steps=Array.from({length:21},(_,i)=>60+i*5);
 let percent=100,metaDown=false,lastWheel=-Infinity,lastTouch=0;
 let dirty=false,saving=false,timer=null;
 const clamp=n=>Math.max(60,Math.min(160,Math.round(n/5)*5));
 function paint(value){
   percent=clamp(value);
   for(const n of steps)document.documentElement.classList.toggle('nuavu-zoom-'+n,n===percent);
   $('zoomValue').textContent=percent+'%';
   $('zoomOutBtn').disabled=percent<=60;$('zoomInBtn').disabled=percent>=160;
 }
 function persistSoon(delay=450){clearTimeout(timer);timer=setTimeout(save,delay);}
 async function save(){
   if(saving||!dirty)return;
   saving=true;const wanted=percent;
   try{
     if(window.factoryResetStarted)return;
     await api('view-settings',{tableZoom:wanted});
     if(state){state.settings=state.settings||{};state.settings.tableZoom=wanted;}
     dirty=percent!==wanted;
   }catch(e){dirty=false;toast('화면 배율은 적용했지만 저장하지 못했습니다: '+e.message,true);}
   finally{saving=false;if(dirty)persistSoon(50);}
 }
 function set(value){
   const target=clamp(value);if(!Number.isFinite(target)||target===percent)return;
   paint(target);dirty=true;lastTouch=Date.now();persistSoon();
 }
 root.NuavuZoom={
   sync(value){if(!dirty&&!saving&&Date.now()-lastTouch>1500)paint(Number.isFinite(value)?value:100);},
   set,get:()=>percent
 };
 $('zoomInBtn').onclick=()=>set(percent+5);
 $('zoomOutBtn').onclick=()=>set(percent-5);
 $('zoomResetBtn').onclick=()=>set(100);
 document.addEventListener('keydown',e=>{
   if(e.key==='Meta')metaDown=true;
   if(!(e.metaKey||e.ctrlKey)||e.altKey)return;
   if(['+','=','-','0'].includes(e.key)){
     e.preventDefault();e.stopPropagation();
     set(e.key==='0'?100:percent+(e.key==='-'?-5:5));
   }
 },true);
 document.addEventListener('keyup',e=>{if(e.key==='Meta'||!e.metaKey)metaDown=false;},true);
 root.addEventListener('blur',()=>{metaDown=false;if(dirty)persistSoon(0);});
 document.addEventListener('wheel',e=>{
   if(!(e.metaKey||metaDown)||!e.deltaY)return;
   e.preventDefault();e.stopPropagation();
   const tick=performance.now();if(tick-lastWheel<70)return;
   lastWheel=tick;set(percent+(e.deltaY<0?5:-5));
 },{passive:false,capture:true});
 paint(100);
 if(state)root.NuavuZoom.sync(state.settings?.tableZoom);
})(window);
