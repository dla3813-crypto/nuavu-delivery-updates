'use strict';
document.body.insertAdjacentHTML('beforeend',`
<dialog id="factoryResetDialog" class="factory-reset-dialog">
 <div class="dialoghead"><h2 id="factoryResetTitle">배포판 전체 초기화</h2><button id="factoryResetCancel">취소</button></div>
 <p id="factoryResetCounts" class="notice" role="status">삭제할 데이터를 확인합니다.</p>
 <div id="factoryResetDetails"><p>다음 항목을 모두 삭제합니다.</p>
 <ul><li>전체 주문과 지연·품절·발송 이력, 예약·발송 대기</li><li>출고장·진행상황 자료, 수동 매칭, 동기화 기록, 반품 조회 결과·자동 실행 설정</li><li>쇼핑몰 이름, 판매처 선택, 문구·폴더·화면 설정</li><li>저장된 문자·알림톡·이지어드민·에이블리 계정</li><li>앱 내부 백업과 이 Mac의 배포판 자동 백업</li></ul>
 <p class="sub">원본 엑셀·직접 내보낸 파일과 다른 Mac의 백업은 그대로 둡니다.</p>
 <p class="warning">삭제한 이력은 되돌릴 수 없고, 같은 주문을 다시 불러오면 이전 발송 여부를 알 수 없습니다. 이미 발송사에 접수된 메시지는 취소되지 않습니다.</p>
 </div>
 <label id="factoryResetInput"><span>계속하려면 <b>전체 초기화</b>를 입력하세요.</span><input id="factoryResetPhrase" autocomplete="off" spellcheck="false" placeholder="전체 초기화"></label>
 <p id="factoryResetStatus" class="sub" role="status"></p>
 <div class="dialogfoot"><span id="factoryResetFootnote">완료 후 앱을 종료하고 다시 실행합니다.</span><button id="factoryResetRun" class="factory-reset-danger" disabled>모두 삭제하고 초기화</button><button id="factoryResetClose" class="primary" hidden>초기화 완료 · 앱 종료</button></div>
</dialog>`);
let factoryResetReady=false,factoryResetBusy=false,factoryResetDone=false;
function resetBridge(){
 const b=window.pywebview?.api;
 if(!state?.desktopMode||!b?.factory_reset)throw Error('전체 초기화는 배포판 Mac 앱에서 사용할 수 있습니다.');
 return b;
}
function resetButton(){ $('factoryResetRun').disabled=!factoryResetReady||factoryResetBusy||factoryResetDone||$('factoryResetPhrase').value!=='전체 초기화'; }
$('factoryResetOpen').onclick=async()=>{
 factoryResetReady=false;factoryResetDone=false;$('factoryResetPhrase').value='';$('factoryResetStatus').textContent='';resetButton();
 $('shopDialog').close();$('factoryResetDialog').showModal();
 try{const r=await resetBridge().factory_reset_preview(token);if(r.error)throw Error(r.error);
  $('factoryResetCounts').textContent=`주문상품 ${r.orders}개 · 안내/발송 이력 ${r.notices}개 · 예약/대기 ${r.queued}개 · 반품 ${r.returns||0}개`;
  factoryResetReady=true;resetButton();$('factoryResetPhrase').focus();
 }catch(e){$('factoryResetStatus').textContent=e.message;}
};
$('factoryResetPhrase').oninput=resetButton;
$('factoryResetCancel').onclick=()=>{if(!window.factoryResetStarted)$('factoryResetDialog').close();};
$('factoryResetDialog').addEventListener('cancel',e=>{if(window.factoryResetStarted)e.preventDefault();});
$('factoryResetRun').onclick=async()=>{
 if(!factoryResetReady||factoryResetBusy||factoryResetDone||$('factoryResetPhrase').value!=='전체 초기화')return;
 factoryResetBusy=true;window.factoryResetStarted=true;resetButton();$('factoryResetCancel').disabled=true;$('factoryResetPhrase').disabled=true;
 if(typeof stopOrderPolling==='function')stopOrderPolling();if(typeof ablyTimer!=='undefined')clearTimeout(ablyTimer);
 clearTimeout(toast.timer);if(typeof tableZoomTimer!=='undefined')clearTimeout(tableZoomTimer);if(typeof zigzagTimer!=='undefined')clearTimeout(zigzagTimer);if(typeof orderAutoCancelled!=='undefined')orderAutoCancelled=true;
 $('factoryResetStatus').textContent='작업을 중단하고 전체 데이터를 초기화하고 있습니다. 잠시 기다려주세요.';
 try{const r=await resetBridge().factory_reset(token,$('factoryResetPhrase').value);if(r.error)throw Error(r.error);
  if(r.reset!==true)throw Error('초기화 완료를 확인하지 못했습니다. 다시 시도하세요.');
  factoryResetDone=true;sessionStorage.removeItem('nuavuToken');selected.clear();
  // Keep nodes valid for already-running UI callbacks, but make the old
  // application inaccessible until the native window and process close.
  document.body.classList.add('factory-reset-complete');
  for(const el of [...document.body.children])if(el.id!=='factoryResetDialog'&&el.tagName!=='SCRIPT'){
   if(el.tagName==='DIALOG'&&el.open)el.close();
   el.inert=true;
  }
  $('factoryResetCounts').textContent='주문상품 0개 · 안내/발송 이력 0개 · 예약/대기 0개';
  $('factoryResetTitle').textContent='전체 초기화 완료';$('factoryResetDetails').hidden=true;$('factoryResetInput').hidden=true;$('factoryResetCancel').hidden=true;
  $('factoryResetFootnote').textContent='다시 실행하면 처음 설치한 상태로 시작합니다.';
  $('factoryResetStatus').textContent=r.message;$('factoryResetRun').hidden=true;$('factoryResetClose').hidden=false;
 }catch(e){$('factoryResetStatus').textContent=e.message;$('factoryResetRun').textContent='초기화 다시 시도';}
 finally{factoryResetBusy=false;resetButton();}
};
$('factoryResetClose').onclick=async()=>{
 try{const r=await resetBridge().factory_reset_close(token);if(r?.error)throw Error(r.error);}
 catch(e){$('factoryResetStatus').textContent=e.message;}
};
