'use strict';
/* Unified settings hub: 메시지 · 로그인 · 자동화. The section buttons keep their original ids,
   so each feature's own dialog and handler stay the single place where that setting is edited. */
(()=>{
 const MAIN=false;
 const dialog=$('settingsHubDialog'),badge=$('settingsHubBadge');
 const ezState=$('hubEzadminState'),ablyState=$('hubAblyState'),zzState=$('hubZigzagState'),cafeState=$('hubCafe24State'),status=$('hubAutoStatus');
 const NEED='로그인을 설정해 주세요';
 let returnsSettings=null,pickupEnabled=null,loginMissing=false,busyAuto=false;
 const box=key=>document.querySelector('[data-hub-auto="'+key+'"]');
 function loginLine(el,info,label){
  el.classList.remove('ok','missing','unknown');
  if(!info){el.textContent=label+' 계정은 설치한 맥 앱에서 확인할 수 있습니다.';el.classList.add('unknown');return false;}
  if(info.error){el.textContent=info.error;el.classList.add('unknown');return false;}
  const ok=!!(info.username&&info.hasPassword);
  el.textContent=ok?'로그인 설정됨 · '+info.username+(info.domain?' · '+info.domain:''):NEED;
  el.classList.add(ok?'ok':'missing');return !ok;
 }
 async function ezadminInfo(){
  try{const b=window.pywebview?.api;if(!state?.desktopMode||!b?.ezadmin_login_settings)return null;const s=await b.ezadmin_login_settings(token);return s||null;}
  catch(e){return {error:e.message};}
 }
 async function ablyInfo(){
  if(!state?.desktopMode||!window.pywebview?.api?.ably_sync_action)return null;
  try{return await ablyCall('settings');}
  catch(e){return {error:e.message};}
 }
 async function zigzagInfo(){
  if(!state?.desktopMode||!window.pywebview?.api?.zigzag_action)return null;
  try{return await zigzagCall('settings');}
  catch(e){return {error:e.message};}
 }
 async function cafe24Info(){
  if(!state?.desktopMode||!window.pywebview?.api?.soldout_display_action)return null;
  try{return await window.cafe24Call('settings');}
  catch(e){return {error:e.message};}
 }
 function cafe24Line(info){
  cafeState.classList.remove('ok','missing','unknown');
  if(!info){cafeState.textContent='자사몰 계정은 설치한 맥 앱에서 확인할 수 있습니다.';cafeState.classList.add('unknown');return;}
  if(info.error){cafeState.textContent=info.error;cafeState.classList.add('unknown');return;}
  const ok=!!(info.username&&info.hasPassword);
  cafeState.textContent=ok?'로그인 설정됨 · '+info.username+' · 품절 안내 시 자사몰+에이블리 품절 처리':'설정 안 함 · 품절 안내 시 에이블리만 처리 (자사몰 없으면 그대로 두세요)';
  cafeState.classList.add(ok?'ok':'unknown');
 }
 async function checkLogins(){
  const [ez,ab,zz,cf]=await Promise.all([ezadminInfo(),ablyInfo(),zigzagInfo(),cafe24Info()]);
  cafe24Line(cf);
  const missEz=loginLine(ezState,ez,'이지어드민'),missAb=loginLine(ablyState,ab,'에이블리'),missZz=loginLine(zzState,zz,'지그재그');
  loginMissing=missEz||missAb||missZz;
  badge.hidden=!loginMissing;$('settingsHubBtn').classList.toggle('needs-login',loginMissing);
  dialog.querySelector('.hub-login').classList.toggle('needs-login',loginMissing);
 }
 function paintAuto(){
  const set=(key,on)=>{const e=box(key);if(e){e.checked=!!on;e.closest('label').dataset.enabled=String(!!on);}};
  set('supply',state?.supply?.autoEnabled);
  if(MAIN){set('inventory',state?.inventory?.autoEnabled);set('orderSchedule',state?.orderImportSchedule?.enabled);set('orderExport',state?.orderExport?.enabled);}
  set('returnWatch',returnsSettings?.watchEnabled);set('returnDaily',returnsSettings?.mode==='daily');
  set('pickup',pickupEnabled);set('headlessChrome',state?.settings?.headlessChrome);set('autoAblyPush',state?.settings?.autoAblyPush!==false);set('autoZigzagPush',state?.settings?.autoZigzagPush!==false);
 }
 async function loadReturns(){
  returnsSettings=null;pickupEnabled=null;
  try{if(window.returnsCall){const s=await window.returnsCall('status');returnsSettings=s.settings||null;}}catch(e){}
  try{if(window.pickupCall){pickupEnabled=!!(await window.pickupCall('status')).settings?.enabled;}}catch(e){}
  for(const key of ['returnWatch','returnDaily']){const e=box(key);if(e)e.disabled=!returnsSettings;}
  const p=box('pickup');if(p)p.disabled=pickupEnabled===null;
  paintAuto();
 }
 async function toggle(key,on){
  if(key==='supply'){populateSupplyForm();if(on)await api('supply-settings',supplySettingsInput());return (await api('supply-auto',{enabled:on})).message;}
  if(key==='inventory'){const r=await api('inventory-settings',{autoEnabled:on,offsetMinutes:Number(state?.inventory?.offsetMinutes??40)});if(on){try{const x=await api('inventory-refresh',{});return x.message;}catch(e){return r.message+' · '+e.message;}}return r.message;}
  if(key==='orderSchedule'){const r=await orderBridge().order_schedule_settings(token,on);if(r.error)throw Error(r.error);return r.enabled?'평일 매시간 55분 자동 불러오기를 켰습니다.':'정시 자동 불러오기를 껐습니다.';}
  if(key==='orderExport'){const r=await api('order-export-settings',{enabled:on,filename:state?.orderExport?.filename||'현재 미출고 상품.xlsx'});return r.message||(on?'미출고 엑셀 자동 저장을 켰습니다.':'미출고 엑셀 자동 저장을 껐습니다.');}
  if(key==='returnWatch'||key==='returnDaily'){
   if(!returnsSettings)throw Error('반품 설정은 새 버전 Mac 앱에서 사용할 수 있습니다.');
   const next={mode:key==='returnDaily'?(on?'daily':'manual'):returnsSettings.mode,time:returnsSettings.time,watchEnabled:key==='returnWatch'?on:!!returnsSettings.watchEnabled,folder:returnsSettings.folder||''};
   const r=await window.returnsCall('save',next);returnsSettings={...returnsSettings,...next};return r.message||'반품 설정을 저장했습니다.';
  }
  if(key==='pickup'){const r=await window.pickupCall('save',{enabled:on});pickupEnabled=on;return r.message||(on?'자동 회수접수를 켰습니다.':'자동 회수접수를 껐습니다.');}
  if(key==='autoAblyPush'){const r=await api('auto-ably-push',{autoAblyPush:on});return r.message;}
  if(key==='autoZigzagPush'){const r=await api('auto-zigzag-push',{autoZigzagPush:on});return r.message;}
  if(key==='headlessChrome'){const r=await api('browser-window',{headlessChrome:on});try{$('headlessChrome').checked=on;}catch(e){}return r.message;}
  throw Error('알 수 없는 설정입니다.');
 }
 $('hubAutoList').addEventListener('change',async e=>{
  const input=e.target.closest('input[data-hub-auto]');if(!input||busyAuto)return;
  const key=input.dataset.hubAuto,on=input.checked;busyAuto=true;input.disabled=true;status.classList.remove('error');status.textContent='저장 중…';
  try{const message=await toggle(key,on);await refresh();status.textContent=message||'저장했습니다.';toast(status.textContent);}
  catch(err){status.textContent=err.message;status.classList.add('error');toast(err.message,true);}
  finally{busyAuto=false;input.disabled=false;paintAuto();window.dispatchEvent(new CustomEvent('nuavu-auto-state'));}
 });
 async function open(){
  status.textContent='';status.classList.remove('error');
  ezState.textContent='확인 중';ablyState.textContent='확인 중';zzState.textContent='확인 중';
  dialog.showModal();paintAuto();
  await Promise.all([checkLogins(),loadReturns()]);
 }
 $('settingsHubBtn').onclick=open;
 window.openSettingsHub=open;
 $('hubSupplyOpen').onclick=()=>$('supplyBtn').click();
 if(MAIN){
  $('hubInventoryOpen').onclick=()=>$('inventoryBtn').click();
  $('hubOrderExportOpen').onclick=()=>$('orderExportSettingsBtn').click();
  $('hubOrderImportOpen').onclick=()=>$('importBtn').click();
 }
 window.addEventListener('nuavu-state',()=>{if(dialog.open)paintAuto();});
 window.addEventListener('nuavu-auto-state',()=>{if(dialog.open&&!busyAuto)paintAuto();});
 // Login check once the app is connected, so the header shows the red badge without opening the hub.
 let checked=false;
 const first=()=>{if(checked||!state)return;checked=true;checkLogins().catch(()=>{});};
 window.addEventListener('nuavu-state',first);setTimeout(first,1500);
 for(const id of ['saveEzadminLogin','ablySave','zigzagSave','cafe24Save','cafe24Forget']){const e=$(id);if(e)e.addEventListener('click',()=>setTimeout(()=>checkLogins().catch(()=>{}),1200));}
})();
