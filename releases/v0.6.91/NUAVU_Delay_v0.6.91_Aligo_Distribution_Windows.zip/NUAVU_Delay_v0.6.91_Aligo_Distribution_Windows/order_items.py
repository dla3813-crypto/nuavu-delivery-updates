"""Ably line identifiers: metadata only, never replacement notice/order keys.

Keep product/order grouping stable across upgrades. When identical SKUs aggregate,
all of their line IDs and quantities must be covered by an external acknowledgement.
"""
from __future__ import annotations
import math,re,unicodedata
ABLY='누아브 에이블리'
AMOOD='누아브 아무드'   # 확장주문검색 주문상세번호 = 아무드 상품주문번호 (2026-10-21)

class ItemIdError(ValueError):pass

def item_id(value):
    if value is None or value=='':return ''
    if isinstance(value,bool):raise ItemIdError('주문 상세번호는 텍스트로 입력하세요.')
    if isinstance(value,(int,float)):
        if not math.isfinite(value) or int(value)!=value or abs(value)>=10**15:
            raise ItemIdError('주문 상세번호 정밀도를 확인하세요. 지수표기가 아닌 텍스트로 내보내세요.')
        value=str(int(value))
    if not isinstance(value,str):raise ItemIdError('주문 상세번호 형식을 확인하세요.')
    s=unicodedata.normalize('NFKC',value).strip()
    if re.fullmatch(r'[+-]?\d+(?:\.\d+)?[eE][+-]?\d+',s):
        raise ItemIdError('주문 상세번호 지수표기는 지원하지 않습니다. 텍스트로 다시 내보내세요.')
    if len(s)>150 or re.search(r'[\s\x00-\x1f]',s):raise ItemIdError('주문 상세번호에 공백 또는 제어문자가 있습니다.')
    if s.startswith(('#EXCEL_ERROR','#UNCACHED_FORMULA')):raise ItemIdError('주문 상세번호 셀에 오류가 있습니다.')
    return s

def items_of(row):
    """Read persisted/new metadata without changing the row or its key."""
    if row.get('seller') not in (ABLY,AMOOD):return []
    source=row.get('orderItems')
    if source is None:
        value=item_id(row.get('orderItemId'))
        source=[{'id':value,'qty':row['qty']}] if value else []
    if not isinstance(source,list) or len(source)>1000:raise ItemIdError('상품주문번호 목록을 확인하세요.')
    out=[];seen=set()
    for part in source:
        if not isinstance(part,dict):raise ItemIdError('상품주문번호 목록 형식 오류')
        value=item_id(part.get('id'));q=part.get('qty')
        if not value or isinstance(q,bool) or not isinstance(q,int) or q<=0:raise ItemIdError('상품주문번호별 수량을 확인하세요.')
        if value in seen:raise ItemIdError('한 주문상품에 상품주문번호가 중복되어 있습니다.')
        seen.add(value);out.append({'id':value,'qty':q})
    if sum(p['qty'] for p in out)>row['qty']:raise ItemIdError('상품주문번호별 수량이 주문 수량을 넘습니다.')
    return out

def set_items(row,parts):
    row['orderItems']=parts
    row['orderItemId']=parts[0]['id'] if len(parts)==1 else ''

def combine_items(target,other):
    a=target.get('orderItems',[]);b=other.get('orderItems',[])
    if {p['id'] for p in a}&{p['id'] for p in b}:
        raise ItemIdError('같은 상품주문번호가 엑셀에 반복됩니다. 중복 행을 확인하세요.')
    set_items(target,a+b)
    target['orderItemIdMapped']=target.get('orderItemIdMapped',False) or other.get('orderItemIdMapped',False)
