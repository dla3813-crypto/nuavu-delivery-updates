"""Separate Alimtalk Keychain item for this distribution."""
import sys
from credentials import MacKeychain, UnavailableVault
SERVICE='kr.nuavu.deliverynotice.distribution.alimtalk'
class AligoKeychain(MacKeychain):
    def _query(self):
        q=super()._query();q[self._api().kSecAttrService]=SERVICE;return q

def default_aligo_vault(directory):
    from windows_credentials import platform_vault
    return platform_vault(directory,SERVICE,'배송안내 배포판 알리고 알림톡 계정',AligoKeychain)
