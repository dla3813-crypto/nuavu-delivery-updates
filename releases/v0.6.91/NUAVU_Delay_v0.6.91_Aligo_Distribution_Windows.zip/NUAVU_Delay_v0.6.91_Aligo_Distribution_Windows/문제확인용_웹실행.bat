@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\web.ps1"
