"""Consistent, completed SQLite snapshots for Desktop/iCloud — NOT live DB sync.

Only the local Library database is writable. Cloud copies are immutable artifacts;
no restore, ownership transfer, remote sender or cross-device locking is claimed.
"""
from __future__ import annotations
import hashlib
import json
import os
import re
import secrets
import shutil
import sqlite3
import tempfile
import threading
from datetime import datetime, timezone, timedelta
from pathlib import Path

KST=timezone(timedelta(hours=9))
README='''배송안내 배포판 · 바탕화면 백업

이 폴더는 완성된 백업 사본을 보관합니다. 실행 중인 원본 데이터베이스가 아닙니다.
원본: ~/Library/Application Support/NUAVU Delay Distribution/nuavu.sqlite3

iCloud의 데스크탑 동기화가 켜져 있으면 이 폴더도 동기화 대상입니다.
앱의 “백업 저장 완료”는 이 맥의 파일 생성 완료이며 iCloud 업로드 완료 보장이 아닙니다.
장치별 폴더를 나눠 다른 맥의 백업과 서로 덮어쓰지 않습니다.

여러 맥에서 이 백업을 원본으로 열거나 과거 DB로 덮어쓰지 마세요.
발송 기록이 사라지면 같은 문자가 다시 발송될 수 있습니다.
노트북에서는 메인 맥 화면을 원격으로 이용하는 방식을 권장합니다.
자동 복원·실시간 두 맥 동기화·발송 담당 맥 이전 기능은 없습니다.

백업에는 고객 개인정보(전화번호/주문/문자 내용)가 들어 있습니다.
API Key·SenderKey는 키체인에만 저장되므로 이 파일에는 들어 있지 않습니다.
이 폴더를 공개 공유하지 마세요. 디스크 파일 자체를 추가 암호화하지는 않습니다.
'''

def atomic_bytes(path: Path, data: bytes):
    fd,temp=tempfile.mkstemp(prefix='.nuavu-',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as out:out.write(data);out.flush();os.fsync(out.fileno())
        os.chmod(temp,0o600);os.replace(temp,path)
    finally:Path(temp).unlink(missing_ok=True)

class DesktopBackup:
    def __init__(self,store,root=None):
        self.store=store
        self.root=Path(root) if root is not None else Path.home()/'Desktop'/'배송안내_배포판_백업'
        self.lock=threading.RLock();self.last_revision=None
        self.info={'enabled':True,'path':str(self.root),'lastSavedAt':None,'revision':None,'error':'','cloudVerified':False}
        self.device=None;self.folder=None

    def status(self):
        # Status is an atomically replaced dictionary; no lock order with Store.lock.
        return dict(self.info)

    def _prepare(self):
        key=self.store.directory/'desktop-backup-device.txt'
        if self.device is None:
            if key.exists():device=key.read_text(encoding='ascii').strip()
            else:
                device=secrets.token_hex(8)
                with key.open('x',encoding='ascii') as out:out.write(device+'\n')
                os.chmod(key,0o600)
            if not re.fullmatch(r'[0-9a-f]{16}',device):raise ValueError('잘못된 장치 식별자')
            self.device=device
        # Reject accidental archival into the active database's parent.
        if self.root.resolve()==self.store.directory.resolve():raise ValueError('원본과 백업 위치가 같습니다')
        self.root.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.folder=self.root/('이맥백업-'+self.device)
        self.folder.mkdir(exist_ok=True,mode=0o700)
        guide=self.folder/'백업_주의사항.txt'
        if not guide.exists():atomic_bytes(guide,README.encode('utf-8'))

    def run(self,force=False,reason='periodic'):
        with self.lock:
            try:
                self._prepare()
                current=self.store.read()
                stamp=datetime.now(timezone.utc);day=stamp.astimezone(KST).date().isoformat()
                daily=self.folder/('일별-'+day+'.sqlite3')
                if not force and current['revision']==self.last_revision and daily.exists():return self.status()
                fd,tmp=tempfile.mkstemp(prefix='archive-',suffix='.sqlite3',dir=self.store.directory)
                os.close(fd);tmp=Path(tmp)
                try:
                    target=sqlite3.connect(tmp)
                    try:
                        with self.store.lock:self.store.db.backup(target)
                        target.execute('PRAGMA journal_mode=DELETE')
                        if target.execute('PRAGMA quick_check').fetchone()[0]!='ok':raise ValueError('백업 검증 실패')
                        body=target.execute('SELECT body FROM app_state WHERE id=1').fetchone()[0]
                        snap=json.loads(body);revision=snap['revision']
                    finally:target.close()
                    # Copy only the completed and closed snapshot. Never copy an active WAL DB.
                    data=tmp.read_bytes()
                    name='백업-'+stamp.strftime('%Y%m%dT%H%M%S%fZ')+'-r'+str(revision)+'.sqlite3'
                    atomic_bytes(self.folder/name,data)
                    if not daily.exists():atomic_bytes(daily,data)
                    metadata={'format':'NUAVU_completed_backup_v1','createdAt':stamp.isoformat(),
                              'appVersion':snap.get('appVersion'),'revision':revision,'file':name,
                              'sha256':hashlib.sha256(data).hexdigest(),'device':self.device,
                              'activeProducts':sum(bool(r['active']) for r in snap['rows']),
                              'notices':len(snap['notices']),'reason':reason,'iCloudUploadVerified':False,
                              'warning':'백업만으로 다른 맥의 발송을 활성화하지 마세요. 동시 실행/자동 복원은 지원하지 않습니다.'}
                    atomic_bytes(self.folder/'최근백업정보.json',json.dumps(metadata,ensure_ascii=False,indent=2).encode('utf-8'))
                    # Prune only known files produced in this instance's own backup folder.
                    for path in sorted(p for p in self.folder.glob('백업-*.sqlite3') if re.fullmatch(r'백업-\d{8}T\d{12}Z-r\d+\.sqlite3',p.name))[:-60]:path.unlink()
                    for path in sorted(p for p in self.folder.glob('일별-*.sqlite3') if re.fullmatch(r'일별-\d{4}-\d{2}-\d{2}\.sqlite3',p.name))[:-14]:path.unlink()
                    self.last_revision=revision
                    self.info={'enabled':True,'path':str(self.root),'folder':str(self.folder),
                               'lastSavedAt':stamp.isoformat(),'revision':revision,'error':'','cloudVerified':False}
                finally:
                    tmp.unlink(missing_ok=True)
                    Path(str(tmp)+'-wal').unlink(missing_ok=True);Path(str(tmp)+'-shm').unlink(missing_ok=True)
            except (OSError,sqlite3.Error,ValueError,TypeError,KeyError) as exc:
                # Archival failure must not turn an already-accepted message into UNKNOWN.
                code=getattr(exc,'errno',None)
                self.info={**self.info,'error':'바탕화면 백업 저장 실패'+(f' (오류 {code})' if code is not None else '')+'. 원본 주문 DB는 유지됩니다. 폴더 접근 권한/남은 저장 공간을 확인하세요.'}
            return self.status()
