"""The user's China-office shipping rules, not an actual carrier guarantee."""
from datetime import date,timedelta
# 2026 KASI almanac + KASA 2026 updates (Labour/Constitution Day).
# Official sources and coverage limits are documented in docs/SUPPLY_RULES.md.
HOLIDAYS_2026=set('01-01 02-16 02-17 02-18 03-01 03-02 05-01 05-05 05-24 05-25 06-03 06-06 07-17 08-15 08-17 09-24 09-25 09-26 10-03 10-05 10-09 12-25'.split())

def is_holiday(d,extra):return (d.year==2026 and d.strftime('%m-%d') in HOLIDAYS_2026) or d.isoformat() in extra

def business(d,extra):
    for _ in range(370):
        if d.weekday()<5 and not is_holiday(d,extra):return d
        d+=timedelta(days=1)
    raise ValueError('휴무일 설정이 너무 길어 날짜를 계산하지 못했습니다.')

def china_departure(basis):
    # Tue/Sat office arrivals join that SAME day's shipment, per user.
    wd=basis.weekday();target=1 if wd in (0,1,6) else 5
    return basis+timedelta(days=(target-wd)%7)

def moved_departure(ship,delays):
    """2026-10-21: a Tuesday China shipment that did not go → the departure the owner chose (Fri/Sat of that week)."""
    d=(delays or {}).get(ship.isoformat()) if ship.weekday()==1 else None
    if isinstance(d,dict) and d.get('status')=='delayed' and d.get('departure'):
        try:return date.fromisoformat(d['departure'])
        except ValueError:return None
    return None

def route(basis,extra=(),departure=None,delays=None):
    ship=departure or china_departure(basis);moved_from=None
    if departure is None and delays:
        new=moved_departure(ship,delays)
        if new:moved_from,ship=ship,new
    if ship.weekday()==1:lo=hi=ship+timedelta(days=6);late=ship+timedelta(days=7)
    elif ship.weekday()==4 and moved_from:
        # 2026-10-21 20:33: 밀린 화요일분을 금요일에 중국 출고 → 실 출고 예상 다음주 화~수.
        lo=ship+timedelta(days=4);hi=ship+timedelta(days=5);late=ship+timedelta(days=6)
    elif ship.weekday() in (4,5):
        # An actual Friday manifest belongs to the same second weekly wave.
        sat=ship+timedelta(days=5-ship.weekday())
        lo=sat+timedelta(days=4);hi=sat+timedelta(days=5);late=sat+timedelta(days=6)
    else:return None
    lo,hi,late=[business(d,extra) for d in (lo,hi,late)]
    recv0,recv1=lo+timedelta(days=1),hi+timedelta(days=1)
    years={d.year for d in (basis,ship,lo,hi,late,recv0,recv1)}
    return {'basisDate':basis.isoformat(),'chinaDate':ship.isoformat(),
        'koreaStart':lo.isoformat(),'koreaEnd':hi.isoformat(),'koreaLatest':late.isoformat(),
        'receiptStart':recv0.isoformat(),'receiptEnd':recv1.isoformat(),
        'receiptLatest':(late+timedelta(days=1)).isoformat(),
        'calendarKnown':years<={2026},**({'delayedFrom':moved_from.isoformat()} if moved_from else {})}
