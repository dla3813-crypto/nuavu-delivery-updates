﻿$ErrorActionPreference='Continue'
try{[Console]::OutputEncoding=[System.Text.Encoding]::UTF8}catch{}
$Root=Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)   # 이 스크립트는 windows\ 안에 있다 → 앱 폴더는 한 단계 위 (10:09 보고)
Set-Location $Root
$Data=Join-Path $env:LOCALAPPDATA 'NUAVU Delay Distribution'
$py=Get-ChildItem -Path $Data -Directory -Filter 'desktop-runtime-win*' -ErrorAction SilentlyContinue | Sort-Object Name | ForEach-Object { Join-Path $_.FullName 'Scripts\python.exe' } | Where-Object { Test-Path $_ } | Select-Object -Last 1
if(-not $py){ Write-Host '먼저 처음한번_앱설치.bat 을 실행하세요.'; Read-Host | Out-Null; exit 1 }
Write-Host ('앱 창을 콘솔과 함께 실행합니다 (오류가 여기에 표시됩니다). Python: '+$py)
Write-Host ('로그: '+(Join-Path $Data 'logs\desktop.log'))
& $py -I (Join-Path $Root 'desktop.py')
Write-Host ('종료 코드: '+$LASTEXITCODE)
Read-Host '엔터를 누르면 이 창을 닫습니다' | Out-Null
