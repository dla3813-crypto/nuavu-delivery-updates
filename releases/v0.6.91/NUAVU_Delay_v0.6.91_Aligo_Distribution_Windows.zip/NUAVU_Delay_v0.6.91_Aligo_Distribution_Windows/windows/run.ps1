﻿$ErrorActionPreference='Continue'
try{[Console]::OutputEncoding=[System.Text.Encoding]::UTF8}catch{}
$Root=Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)   # 이 스크립트는 windows\ 안에 있다 → 앱 폴더는 한 단계 위 (10:09 보고)
$Data=Join-Path $env:LOCALAPPDATA 'NUAVU Delay Distribution'
$pyw=Get-ChildItem -Path $Data -Directory -Filter 'desktop-runtime-win*' -ErrorAction SilentlyContinue | Sort-Object Name | ForEach-Object { Join-Path $_.FullName 'Scripts\pythonw.exe' } | Where-Object { Test-Path $_ } | Select-Object -Last 1
if(-not $pyw){ & (Join-Path $Root 'windows\install.ps1'); exit }
Start-Process -FilePath $pyw -ArgumentList ('"'+(Join-Path $Root 'desktop.py')+'"') -WorkingDirectory $Root
