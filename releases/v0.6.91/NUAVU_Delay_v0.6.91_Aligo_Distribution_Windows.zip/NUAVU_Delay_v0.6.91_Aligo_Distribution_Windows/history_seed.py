"""External notice utilities. No bundled customer data."""
EXTERNAL_STATUS='IMPORTED'

SYNC_SOURCES={'ably_sync','zigzag_sync'}  # platform reads (no app-side send); same priority rules
def is_external(n):
    return n.get('source') in ({'external_excel'}|SYNC_SOURCES) and n.get('status')==EXTERNAL_STATUS

def effective_notice_key(n):
    """Date-only priority: explicit user date edits compete with real notices by time.

    Historical imports and background Ably sync retain their lower priority.
    Sending chronology, provider results and duplicate protections are unchanged.
    """
    rank=3 if n.get('manualDueDateUpdate') else (2 if n.get('source') in SYNC_SOURCES else (1 if is_external(n) else 3))
    return (rank,notice_sort_key(n))

def notice_sort_key(n):
    # Import time is NOT a send time. Preserve all real app outcomes as newer.
    # Ably reads cannot replace a real outcome/failed-send status. Their date
    # priority is selected separately by effective_notice_key.
    return (0 if is_external(n) and (not n.get('manualAcknowledgement') or n.get('source') in SYNC_SOURCES) else 1,
            n.get('sourceSnapshot','') if is_external(n) and not n.get('manualAcknowledgement') else n.get('logicalCreatedAt') or n.get('createdAt',''))
