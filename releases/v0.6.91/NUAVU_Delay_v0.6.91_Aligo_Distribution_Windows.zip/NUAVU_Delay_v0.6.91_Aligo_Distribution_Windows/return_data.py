"""Return lookup data only. Never changes shipping orders, notices or refunds."""
from __future__ import annotations
import hashlib,json,re
from datetime import date
from workbook_reader import read_xlsx,as_date,text

class ReturnError(ValueError):pass
class ReturnCancelled(ReturnError):pass

HEADERS={'requestedAt':'반품 요청일','customer':'주문자명','reason':'반품 사유',
         'invoice':'송장번호','fee':'반품 배송비','orderId':'주문번호','product':'상품명'}
PRIORITY={'late':0,'urgent':1,'arrived':2,'transit':3,'fee':4,'registered':5,'uncollected':6,'unknown':7,'not_defect_done':8}
LABELS={'late':'늦은 반품신청','urgent':'환불승인 시급','arrived':'승인처리 대상',
        'transit':'반품 배송중','fee':'반품배송비 -3,000원','registered':'회수 접수 완료','uncollected':'회수 전 / 미접수','unknown':'조회 확인 필요','not_defect_done':'반품 불량 아님 안내 완료'}

def invoice(value):
    s=re.sub(r'[\s-]','',text(value));s=re.sub(r'\.0$','',s)
    return s if re.fullmatch(r'\d{10,14}',s) else ''

def carrier_of(value):
    if value.startswith('6'):return 'EPOST'
    if value.startswith(('51','52')):return 'CJ'
    return 'UNKNOWN'

def iso(value):
    if not isinstance(value,str) or not value:return ''
    try:return date.fromisoformat(value[:10].replace('.','-')).isoformat()
    except ValueError:return ''

def read_returns(raw,total,today):
    """Require named headers. Positional guesses must not misidentify a customer."""
    sheets=read_xlsx(raw);candidates=[]
    norm=lambda v:re.sub(r'\s+','',text(v))
    for sheet in sheets:
        rows=sheet['rows']
        if not rows:continue
        heads=[norm(v) for v in rows[0]]
        if all(heads.count(norm(v))==1 for v in HEADERS.values()):candidates.append((sheet,heads))
    if len(candidates)!=1:raise ReturnError('반품 엑셀의 요청일·주문번호·상품·사유·송장·배송비 열을 하나로 확인하지 못했습니다.')
    sheet,heads=candidates[0];cols={k:heads.index(norm(v)) for k,v in HEADERS.items()}
    optional={}
    for key,aliases in [('itemId',['상품주문번호']),('option',['옵션명','옵션 정보','옵션']),('qty',['수량','주문 수량']),('recipient',['수취인명']),('recipientPhone',['수취인 연락처'])]:
        found=[heads.index(norm(label)) for label in aliases if heads.count(norm(label))==1]
        if len(found)==1:optional[key]=found[0]
    request_cols=[i for i,h in enumerate(heads) if h==norm('반품 접수번호')]
    if len(request_cols)>1:raise ReturnError('반품 접수번호 열이 중복되어 건수를 확인하지 못했습니다.')
    if request_cols:optional['requestId']=request_cols[0]
    entries=[];seen=set()
    for values in sheet['rows'][1:]:
        if not any(v is not None and text(v) for v in values[:max(cols.values())+1]):continue
        value=lambda i:values[i] if i<len(values) else None
        r={k:text(value(i)) for k,i in cols.items()};r.update({k:text(value(i)) for k,i in optional.items()})
        req=as_date(value(cols['requestedAt']),today.year,sheet.get('epoch1904',False))
        if not req or req>today or not r['orderId'] or not r['product']:
            raise ReturnError('반품 요청일·주문번호·상품명이 빠지거나 잘못된 행이 있어 기존 결과를 유지합니다.')
        r['requestedAt']=req.isoformat();r['invoice']=invoice(r['invoice'])
        fee=re.sub(r'[,\s원]','',r['fee']).replace('−','-')
        if not re.fullmatch(r'-?\d+(?:\.0+)?',fee):raise ReturnError('반품 배송비 숫자를 확인하지 못했습니다.')
        r['fee']=int(float(fee))
        if any(len(str(v))>2000 for v in r.values()):raise ReturnError('반품 엑셀에 지나치게 긴 값이 있습니다.')
        identity=[r.get(k,'') for k in ('orderId','itemId','product','option','requestedAt','invoice','qty')]
        if 'requestId' in r:identity.append(r['requestId'])
        r['key']=hashlib.sha256(json.dumps(identity,ensure_ascii=False).encode()).hexdigest()
        if r['key'] in seen:raise ReturnError('반품 엑셀에 중복 상품 행이 있습니다. 일부만 반영하지 않습니다.')
        seen.add(r['key']);entries.append(r)
    verify_return_count(entries,total)
    return entries

def verify_return_count(entries,total):
    """The screen counts return requests; the workbook contains product rows.

    The header and blank rows have already been removed by read_returns. Never
    subtract another row or discard a product to make the two totals agree.
    Old workbooks without request IDs retain the strict one-row-per-request check.
    """
    if type(total)is not int or not 0<=total<=20000:raise ReturnError('반품요청+검수대기 합계 건수를 확인하지 못했습니다.')
    if len(entries)>20000:raise ReturnError('반품 엑셀 상품 수가 처리 범위를 초과했습니다.')
    if any('requestId' in r for r in entries):
        requests={}
        for r in entries:
            request_id=r.get('requestId')
            if not isinstance(request_id,str) or not request_id.strip() or len(request_id)>2000:
                raise ReturnError('반품 접수번호가 빠진 상품이 있어 건수를 대조하지 못했습니다. 기존 결과를 유지합니다.')
            identity=(r['orderId'],r['requestedAt'])
            if request_id in requests and requests[request_id]!=identity:
                raise ReturnError('같은 반품 접수번호의 주문번호·요청일이 달라 기존 결과를 유지합니다.')
            requests[request_id]=identity
        if len(requests)!=total:
            raise ReturnError(f'반품요청+검수대기 합계 {total}건과 엑셀 반품 접수 {len(requests)}건(제목 제외 상품 {len(entries)}개)이 달라 기존 결과를 유지합니다.')
    elif len(entries)!=total:
        raise ReturnError(f'반품요청+검수대기 합계 {total}건과 엑셀 상품 {len(entries)}개(제목 행 제외)가 다릅니다. 반품 접수번호 열이 없어 기존 결과를 유지합니다.')

def clean_tracking(raw,number,today):
    r=raw if isinstance(raw,dict) else {}
    carrier=r.get('carrier',carrier_of(number))
    result={'carrier':carrier if carrier in ('CJ','EPOST') else 'UNKNOWN',
            'origDelivered':iso(r.get('orig_delivered')),'returnNo':invoice(r.get('return_no')),
            'returnStatus':r.get('return_status'),'returnDelivered':iso(r.get('return_delivered')),'issue':''}
    if not number:result['issue']='원송장번호 없음 또는 형식 확인 필요'
    elif result['carrier']=='UNKNOWN':result['issue']='지원 택배사 확인 필요'
    elif r.get('error') or not r:result['issue']='택배사 조회 실패 · 다시 확인 필요'
    elif result['returnStatus'] not in ('NONE','DELIVERED','IN_TRANSIT','REGISTERED'):result['issue']='택배사 상태 확인 필요'
    elif r.get('return_no') and not result['returnNo']:result['issue']='반품송장번호 확인 필요'
    elif result['returnStatus'] in ('DELIVERED','IN_TRANSIT') and not result['returnNo']:result['issue']='반품송장 근거 없음'
    elif result['returnStatus']=='DELIVERED' and not result['returnDelivered']:result['issue']='반품 배달완료일 확인 필요'
    elif any(v>today.isoformat() for v in (result['origDelivered'],result['returnDelivered']) if v):result['issue']='택배사 날짜 확인 필요'
    elif r.get('orig_delivered') and not result['origDelivered']:result['issue']='원송장 배달완료일 확인 필요'
    if result['issue']:result['returnStatus']='UNKNOWN';result['returnDelivered']=''
    return result

def make_snapshot(entries,raw,total,today):
    verify_return_count(entries,total)
    rows=[]
    for e in entries:
        tr=clean_tracking(raw.get(e['invoice']),e['invoice'],today)
        rows.append({**e,**tr})
    supported=[r for r in rows if r['invoice'] and r['carrier']!='UNKNOWN']
    if supported and all(r['issue'] for r in supported):raise ReturnError('택배사 조회에 모두 실패했습니다. 마지막 정상 조회 결과를 유지합니다.')
    return {'complete':True,'total':len(rows),'requestTotal':total,'rows':rows}

def classify(row,today):
    r=dict(row);delivery=r.get('returnStatus');issue=r.get('issue','')
    arrived=not issue and delivery=='DELIVERED';transit=not issue and delivery=='IN_TRANSIT';registered=not issue and delivery=='REGISTERED'
    original=iso(r.get('origDelivered'));requested=iso(r.get('requestedAt'));returned=iso(r.get('returnDelivered'))
    late=bool(not issue and original and requested and (date.fromisoformat(requested)-date.fromisoformat(original)).days>7)
    days=(today-date.fromisoformat(returned)).days if returned else None
    urgent=bool(arrived and days is not None and days>7)
    fee=r.get('fee')==-3000
    cat='late' if late else 'urgent' if urgent else 'arrived' if arrived else 'transit' if transit else 'unknown' if issue else 'fee' if fee else 'registered' if registered else 'uncollected'
    r.update(category=cat,label=LABELS[cat],late=late,urgent=urgent,feeFlag=fee,registered=registered,
             sellerReason=str(r.get('reason','')).startswith('판매자'),blueFee=cat=='transit' and fee,transitFee=transit and fee,
             daysAfterReturn=days,logistics='unknown' if issue else 'arrived' if arrived else 'transit' if transit else 'undelivered')
    return r

def public_returns(state,today):
    saved=state.get('returnCheck',{});cfg=state.get('settings',{})
    same=all(saved.get(k)==cfg.get(k,0 if k=='shopRevision' else '') for k in ('shopName','shopRevision'))
    rows=[classify(r,today) for r in saved.get('rows',[])] if same else []
    rows.sort(key=lambda r:PRIORITY[r['category']])
    counts={k:sum(r['logistics']==k for r in rows) for k in ('arrived','transit','undelivered','unknown')}
    counts['total']=len(rows)
    return {'rows':rows,'counts':counts,'lastChecked':saved.get('lastChecked','') if same else '',
            'range':'지난 일년 · 반품 진행 관리','scopeChanged':bool(saved and not same)}
