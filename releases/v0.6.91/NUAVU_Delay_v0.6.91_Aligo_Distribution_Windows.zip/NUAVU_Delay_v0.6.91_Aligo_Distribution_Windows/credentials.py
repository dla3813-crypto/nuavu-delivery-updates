"""macOS Keychain storage for the local message-service account.

Only this application's one profile-specific generic-password item is touched.
Secrets never go into sqlite, logs, browser state, shell arguments or exports.
Uses the Security framework already installed with pywebview on macOS.
"""
from __future__ import annotations
import hashlib
import json
import sys
from pathlib import Path

SERVICE = 'kr.nuavu.deliverynotice.distribution.aligo-sms'

class VaultError(Exception):
    """Safe, credential-free error suitable for display in the local app."""

class MacKeychain:
    available = True
    name = 'macOS 키체인'   # Windows: windows_credentials.WindowsDpapiVault

    def __init__(self, directory, security=None):
        self.profile = 'profile-' + hashlib.sha256(
            str(Path(directory).expanduser().resolve()).encode('utf-8')
        ).hexdigest()[:32]
        self._security = security

    def _api(self):
        if self._security is None:
            try:
                import Security
                self._security = Security
            except ImportError as exc:
                raise VaultError('키체인 구성요소가 없습니다. 새 버전의 처음한번_앱설치.command를 실행하세요.') from exc
        return self._security

    def _query(self):
        s = self._api()
        # Deliberately use the local login/file-based keychain, not iCloud sync
        # or the data-protection keychain that requires a signed entitlement.
        return {s.kSecClass: s.kSecClassGenericPassword,
                s.kSecAttrService: SERVICE, s.kSecAttrAccount: self.profile}

    @staticmethod
    def _check(status):
        if status == 0:
            return
        code = int(status)
        if code in (-128, -25293, -25308):
            raise VaultError(f'맥 키체인 접근이 취소·거부되었거나 잠겨 있습니다 ({code}). 키체인 접근을 허용한 뒤 저장된 계정 다시 불러오기를 누르세요.')
        raise VaultError(f'맥 키체인 작업에 실패했습니다 (코드 {code}). 계정은 평문 파일로 대신 저장하지 않습니다.')

    def load(self):
        s = self._api()
        query = self._query()
        query.update({s.kSecReturnData: True, s.kSecMatchLimit: s.kSecMatchLimitOne})
        try:
            status, data = s.SecItemCopyMatching(query, None)
        except Exception as exc:
            raise VaultError('맥 키체인에서 계정을 읽지 못했습니다. 접근 권한을 확인하세요.') from exc
        if status == s.errSecItemNotFound:
            return None
        self._check(status)
        try:
            raw = bytes(data)
            if len(raw) > 16384:
                raise ValueError('size')
            payload = json.loads(raw.decode('utf-8'))
            if not isinstance(payload, dict) or payload.get('version') != 1:
                raise ValueError('version')
            return payload
        except (ValueError, TypeError, UnicodeError) as exc:
            raise VaultError('저장된 계정 형식을 읽지 못했습니다. 문자 설정에서 계정을 다시 저장하세요.') from exc

    def save(self, payload):
        s = self._api()
        raw = json.dumps(payload, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        if len(raw) > 16384:
            raise VaultError('저장할 계정 정보가 너무 큽니다.')
        query = self._query()
        # Update in place instead of deleting a working password before adding.
        try:
            status = s.SecItemUpdate(query, {s.kSecValueData: raw})
            if status == s.errSecItemNotFound:
                add = dict(query)
                add.update({s.kSecValueData: raw, s.kSecAttrLabel: '배송안내 배포판 알리고 문자 API 계정'})
                status, _ = s.SecItemAdd(add, None)
                if status == s.errSecDuplicateItem:
                    status = s.SecItemUpdate(query, {s.kSecValueData: raw})
        except Exception as exc:
            raise VaultError('맥 키체인에 계정을 저장하지 못했습니다. 접근 권한을 확인하세요.') from exc
        self._check(status)

    def delete(self):
        s = self._api()
        try:
            status = s.SecItemDelete(self._query())
        except Exception as exc:
            raise VaultError('저장된 계정을 제거하지 못했습니다. 맥 키체인 접근 권한을 확인하세요.') from exc
        if status != s.errSecItemNotFound:
            self._check(status)

class UnavailableVault:
    """Non-macOS development/browser mode; never a plaintext persistence fallback."""
    available = False
    name = '현재 실행 메모리'
    def load(self): return None
    def save(self, payload):
        raise VaultError('계정 자동 저장은 macOS 키체인이 있는 맥에서만 사용할 수 있습니다.')
    def delete(self): return None

def default_vault(directory):
    from windows_credentials import platform_vault
    return platform_vault(directory,SERVICE,'배송안내 배포판 알리고 문자 API 계정',MacKeychain)
