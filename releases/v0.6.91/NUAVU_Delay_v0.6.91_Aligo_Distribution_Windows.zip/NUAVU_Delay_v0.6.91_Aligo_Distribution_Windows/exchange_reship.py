"""Exchange re-shipment check in EzAdmin E900 (C/S). Read-only: search and detail-read only.

After the Ably exchange list is collected, each order number is looked up in
E900 with 최근세달 + 주문번호부분. An order whose 주문번호 is "C"+<original> is the
exchange re-shipment created by EzAdmin; its invoice and state are recorded on
the exchange row (reship*). Nothing in EzAdmin is changed.
"""
import re
from urllib.parse import urlsplit
from order_browser import Flow
from order_auto import OrderAutoError,Cancelled
from pickup_browser import PickupFlow,INDEX,E804

STATUS={'0':'발주','1':'접수','7':'송장','8':'배송'}
TRANS={'30':'집하','50':'이동중','60':'배송출발','70':'배송완료'}
ALL_DATA_JS='''()=>(window.all_data||[]).map(r=>({pack:String(r.pack||''),orderId:String(r.order_id||''),collectDate:String(r.collect_date||''),status:String(r.status||''),transStatus:String(r.trans_status||''),shop:String(r.shop_name||'')}))'''
DETAIL_JS='''()=>Object.fromEntries(['di_order_id','di_seq','di_trans_corp','di_trans_no','di_trans_date','di_trans_date_pos','di_order_id_seq','di_collect_date','di_shop_name'].map(k=>[k,(document.getElementById(k)?.innerText||'').trim()]))'''

def reship_of(order_id,rows):
    """C-prefixed EzAdmin orders that belong to this original order number."""
    want=('C'+order_id).upper()
    return [r for r in rows if r['orderId'].upper()==want]

def reship_state(status,trans_status,trans_no,pos_date):
    """접수 / 송장 / 배송 by EzAdmin's own status code, cross-checked with the detail dates."""
    label=STATUS.get(str(status),'')
    if not label:label='배송' if pos_date else '송장' if trans_no else '접수'
    detail=TRANS.get(str(trans_status),'')
    return label,detail

class ReshipFlow(PickupFlow):
    def open_e900(self):return super().open_e900('27')  # 주문번호부분: catches C+주문번호 too
    def search(self,page,order_id):
        self.c.check();self.known_page(page)
        if page.locator('#search_type').input_value()!='27':page.locator('#search_type').select_option('27')
        kw=page.locator('#keyword');kw.fill('');kw.fill(order_id)
        if kw.input_value()!=order_id:raise OrderAutoError('검색어 입력을 확인하지 못했습니다.')
        token=page.evaluate('()=>{window.__nuavu_q=(window.__nuavu_q||0)+1;window.__nuavu_rows=null;return window.__nuavu_q;}')
        page.locator('#search').click(timeout=10000)
        # all_data is replaced on every query; wait until it carries this order (or stays empty after the spinner).
        def loaded():
            rows=page.evaluate(ALL_DATA_JS)
            if any(r['orderId'].upper().endswith(order_id.upper()) for r in rows):return rows
            return False
        try:rows=self.until(loaded,25,'')
        except OrderAutoError:
            self.pause(1.5);rows=page.evaluate(ALL_DATA_JS)
        return [r for r in rows if r['orderId'].upper().endswith(order_id.upper())]
    def detail(self,page,c_order):
        row=page.locator('#grid_order tr.jqgrow').filter(has=page.locator('td[aria-describedby="grid_order_order_id"]').filter(has_text=re.compile(r'^\s*'+re.escape(c_order)+r'\s*$')))
        if row.count()!=1:
            row=page.locator('#grid_order tr.jqgrow').filter(has_text=re.compile(r'(^|\s)'+re.escape(c_order)+r'(\s|$)'))
            if row.count()!=1:raise OrderAutoError(f'{c_order} 행을 하나로 찾지 못했습니다.')
        row.locator('td').nth(4).click(timeout=10000)
        d=self.until(lambda:(v if (v:=page.evaluate(DETAIL_JS)).get('di_order_id','').strip().upper()==c_order.upper() else False),20,f'{c_order} 상세가 열리지 않았습니다.')
        return d
    def lookup(self,account,order_ids):
        self.configure_pages();self.account=account;self.relogged=False;self.confirming=False
        self.ensure_login(account,initial=True)
        page=self.open_e900();out={}
        for n,order_id in enumerate(order_ids,1):
            self.step=f'C/S 조회 ({order_id})';self.c.update('exchange',f'이지어드민 C/S · 교환 재발송 확인 {n}/{len(order_ids)} · 주문번호 {order_id}')
            rows=self.search(page,order_id);found=[]
            for r in reship_of(order_id,rows):
                d=self.detail(page,r['orderId'])
                trans_no=re.sub(r'\(.*?\)','',d.get('di_trans_no','')).strip()
                label,detail=reship_state(r['status'],r['transStatus'],trans_no,d.get('di_trans_date_pos',''))
                found.append({'orderId':r['orderId'],'pack':r['pack'] or d.get('di_seq',''),'collectDate':r['collectDate'],'status':label,'deliveryStatus':detail,
                              'carrier':d.get('di_trans_corp',''),'invoice':trans_no,'invoiceAt':d.get('di_trans_date','')[:19],'posAt':d.get('di_trans_date_pos','')[:19],
                              'itemId':d.get('di_order_id_seq','')})
            out[order_id]=found
        return out

def annotate(rows,found,error=''):
    """Attach reship info to exchange rows (in place). Rows keep their own fields."""
    for r in rows:
        hits=found.get(r.get('orderId',''),[]) if found else []
        mine=[h for h in hits if not h.get('itemId') or not r.get('itemId') or h['itemId']==r['itemId']] or hits
        best=sorted(mine,key=lambda h:(h.get('collectDate',''),h.get('invoiceAt','')))[-1] if mine else None
        r['reship']=mine;r['reshipChecked']=not error;r['reshipError']=error
        r['reshipDone']=bool(best and best.get('invoice'))
        r['reshipOrderId']=best['orderId'] if best else '';r['reshipInvoice']=best['invoice'] if best else ''
        r['reshipStatus']=best['status'] if best else '';r['reshipDelivery']=best['deliveryStatus'] if best else ''
        r['reshipCarrier']=best['carrier'] if best else ''
    return rows

def check_reships(controller,rows):
    """Run the E900 lookup in its own Chrome; never raises past a clear message."""
    order_ids=list(dict.fromkeys(r['orderId'] for r in rows if r.get('orderId')))
    if not order_ids:return annotate(rows,{})
    getter=getattr(controller,'ezadmin_account',None)
    if not getter:return annotate(rows,{},'이지어드민 계정 연결이 없어 재발송을 확인하지 못했습니다.')
    try:account=getter()
    except Exception as exc:return annotate(rows,{},'이지어드민 계정: '+str(exc))
    from playwright.sync_api import sync_playwright
    try:
        try:
            with sync_playwright() as pw:
                import browser_window as _bw;browser=pw.chromium.launch(**_bw.launch_kwargs())
                context=browser.new_context(viewport={'width':1280,'height':800},device_scale_factor=1,accept_downloads=False)
                import browser_window;browser_window.attach(context)
                flow=ReshipFlow(controller,context)
                try:found=flow.lookup(account,order_ids)
                except Exception as exc:
                    if isinstance(exc,Cancelled) or type(exc).__name__=='ReturnCancelled':raise
                    msg=flow.failure_message(exc,account)+('' if isinstance(exc,OrderAutoError) else f' ({type(exc).__name__}: {(str(exc).splitlines()[0] if str(exc) else "")[:160]})')
                    try:flow.clear_password()
                    except Exception:pass
                    return annotate(rows,{},msg)
                finally:context.close();browser.close()
        except Exception as exc:
            if isinstance(exc,Cancelled) or type(exc).__name__=='ReturnCancelled':raise
            return annotate(rows,{},f'이지어드민 Chrome 실행 실패 ({type(exc).__name__}: {(str(exc).splitlines()[0] if str(exc) else "")[:160]})')
    finally:account.clear()
    return annotate(rows,found)
