"""Windows counterpart of the macOS Keychain items: one DPAPI-encrypted file per service (2026-10-20 08:42 요청).

CryptProtectData (user scope) ties the blob to the Windows login of the person who saved it — another user or another
PC cannot read it, and nothing is written in plain text. Same contract as MacKeychain: load() → dict|None, save(dict),
delete(). The crypt32 calls are behind `api` so tests can inject a fake.
"""
from __future__ import annotations
import ctypes,hashlib,json,os,sys
from pathlib import Path
from credentials import VaultError

ENTROPY=b'kr.nuavu.deliverynotice.distribution'

class _Blob(ctypes.Structure):
    _fields_=[('cbData',ctypes.c_uint32),('pbData',ctypes.POINTER(ctypes.c_char))]

class Crypt32:
    """Thin wrapper: protect(bytes,description)->bytes, unprotect(bytes)->bytes."""
    def __init__(self):
        self.crypt32=ctypes.WinDLL('crypt32',use_last_error=True);self.kernel32=ctypes.WinDLL('kernel32',use_last_error=True)   # type: ignore[attr-defined]
    def _call(self,fn,raw,description=None):
        inp=_Blob(len(raw),ctypes.cast(ctypes.create_string_buffer(raw,len(raw)),ctypes.POINTER(ctypes.c_char)))
        ent=_Blob(len(ENTROPY),ctypes.cast(ctypes.create_string_buffer(ENTROPY,len(ENTROPY)),ctypes.POINTER(ctypes.c_char)))
        out=_Blob()
        if fn=='protect':ok=self.crypt32.CryptProtectData(ctypes.byref(inp),description,ctypes.byref(ent),None,None,0,ctypes.byref(out))
        else:ok=self.crypt32.CryptUnprotectData(ctypes.byref(inp),None,ctypes.byref(ent),None,None,0,ctypes.byref(out))
        if not ok:raise OSError(ctypes.get_last_error())
        try:return ctypes.string_at(out.pbData,out.cbData)
        finally:self.kernel32.LocalFree(out.pbData)
    def protect(self,raw,description):return self._call('protect',raw,ctypes.c_wchar_p(description))
    def unprotect(self,raw):return self._call('unprotect',raw)

class WindowsDpapiVault:
    available=True
    name='Windows 사용자 보호 저장소(DPAPI)'
    def __init__(self,directory,service,label='배송안내 배포판 계정',api=None):
        self.directory=Path(directory).expanduser();self.service=service;self.label=label;self._api=api
        self.profile='profile-'+hashlib.sha256(str(self.directory.resolve()).encode('utf-8')).hexdigest()[:32]
        self.path=self.directory/'vault'/(hashlib.sha256((service+'|'+self.profile).encode('utf-8')).hexdigest()[:40]+'.dpapi')
    def api(self):
        if self._api is None:
            if sys.platform!='win32':raise VaultError('Windows 보호 저장소는 Windows에서만 사용할 수 있습니다.')
            self._api=Crypt32()
        return self._api
    def load(self):
        if not self.path.is_file():return None
        try:raw=self.api().unprotect(self.path.read_bytes())
        except Exception as exc:raise VaultError('Windows 보호 저장소에서 계정을 읽지 못했습니다. 다른 사용자 계정으로 저장했거나 파일이 손상됐을 수 있습니다. 설정에서 계정을 다시 저장하세요.') from exc
        try:
            if len(raw)>16384:raise ValueError('size')
            payload=json.loads(raw.decode('utf-8'))
            if not isinstance(payload,dict) or payload.get('version')!=1:raise ValueError('version')
            return payload
        except (ValueError,TypeError,UnicodeError) as exc:raise VaultError('저장된 계정 형식을 읽지 못했습니다. 설정에서 계정을 다시 저장하세요.') from exc
    def save(self,payload):
        raw=json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode('utf-8')
        if len(raw)>16384:raise VaultError('저장할 계정 정보가 너무 큽니다.')
        try:
            blob=self.api().protect(raw,self.label)
            self.path.parent.mkdir(parents=True,exist_ok=True)
            tmp=self.path.with_suffix('.tmp');tmp.write_bytes(blob);os.replace(tmp,self.path)
        except VaultError:raise
        except Exception as exc:raise VaultError('Windows 보호 저장소에 계정을 저장하지 못했습니다. 평문으로 대신 저장하지 않습니다.') from exc
    def delete(self):
        try:self.path.unlink(missing_ok=True)
        except Exception as exc:raise VaultError('저장된 계정을 제거하지 못했습니다.') from exc

def platform_vault(directory,service,label,mac_vault,api=None):
    """macOS → the given Keychain item; Windows → DPAPI file; elsewhere → UnavailableVault."""
    from credentials import UnavailableVault
    if sys.platform=='darwin':return mac_vault(directory)
    if sys.platform=='win32' or api is not None:return WindowsDpapiVault(directory,service,label,api=api)
    return UnavailableVault()
