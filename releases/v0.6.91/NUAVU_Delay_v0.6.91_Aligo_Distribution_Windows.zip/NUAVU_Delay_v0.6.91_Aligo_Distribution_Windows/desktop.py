#!/usr/bin/env python3
"""Native macOS window hosting the existing loopback UI. No browser fallback.

pywebview (Cocoa/WKWebView) is installed once into a user-local venv.
The HTTP sender and durable queue remain in the same process as the window.
"""
from __future__ import annotations
from aftersales_lock import operation_lock,serialized
import argparse
import base64
from platform_support import data_dir,ProcessLock,alert,open_path,reveal_path,IS_WINDOWS,IS_MAC
import json
import os
import secrets
import signal
import subprocess
import sys
import tempfile
import threading
from pathlib import Path
from urllib.parse import urlsplit, unquote
from app import LocalServer
from domain import Engine, Store
from desktop_backup import DesktopBackup
from factory_reset import FactoryReset,ResetError,serialized,operation_lock,complete_pending_reset

MAX_IMPORT=20*1024*1024
ORDER_FILE_TYPES=('Order files (*.xls;*.xlsx;*.csv;*.tsv)',)

def selected_path(selected):
    """Accept native paths and local file URLs, never HTTP/remote URLs."""
    value=selected[0] if isinstance(selected,(list,tuple)) else selected
    raw=os.fspath(value)
    if isinstance(raw,bytes):raw=os.fsdecode(raw)
    if raw.startswith('file:'):
        url=urlsplit(raw)
        if url.netloc not in ('','localhost') or url.query or url.fragment:
            raise ValueError('로컬 파일을 선택하세요.')
        raw=unquote(url.path)
    if not raw or '\x00' in raw or not Path(raw).is_absolute():
        raise ValueError('선택한 파일의 로컬 경로를 읽을 수 없습니다.')
    return Path(raw)


def show_error(message: str) -> None:
    print(message, file=sys.stderr)
    alert('배송안내 배포판',message)

def _readonly(method):
    """2026-10-22: 읽기 전용 폴링(진행상황 바)용 — 작업 잠금은 잡지 않고, 전체 초기화 중에는 막는다. 원래 서명 유지."""
    import functools,inspect
    @functools.wraps(method)
    def wrapped(self,*args,**kwargs):
        if getattr(getattr(self,'_engine',None),'reset_in_progress',False):return {'error':'전체 초기화 중입니다.'}
        return method(self,*args,**kwargs)
    wrapped.__signature__=inspect.signature(method)
    return wrapped

class DesktopAPI:
    """Only user-selected imports/exports are exposed; never expose send or paths."""
    def __init__(self, engine, token: str, origin: str, view):
        self._engine=engine;self._token=token;self._origin=origin;self._view=view;self._window=None
        self._dialog_lock=threading.Lock()
        self._saved_exports={}
        operation_lock(engine);self._factory_reset=FactoryReset(engine)
        self._returns=None;self._pickup=None;self._order_auto=None;self._ably_sync=None;self._zigzag=None;self._returns=None;self._order_auto_lock=threading.Lock()

    def _authorized(self, token):
        if not isinstance(token,str) or not secrets.compare_digest(token,self._token):
            raise PermissionError('앱 인증이 만료되었습니다. 앱을 다시 실행하세요.')
        if self._window is None:raise PermissionError('앱 창 준비 중입니다.')
        u=urlsplit(self._window.get_current_url() or '')
        if f'{u.scheme}://{u.netloc}'!=self._origin or u.path not in ('','/','/index.html'):
            raise PermissionError('배송안내 배포판 앱 화면에서만 실행할 수 있습니다.')

    @serialized
    def factory_reset_preview(self,token):
        try:
            self._authorized(token)
            s=self._engine.store.read()
            return {'orders':len(s['rows']),'notices':len(s['notices']),
                    'returns':len(s.get('returnCheck',{}).get('rows',[])),
                    'queued':sum(n.get('status') in {'QUEUED','SCHEDULED','PAUSED'} for n in s['notices'])}
        except Exception:return {'error':'초기화 대상 정보를 확인하지 못했습니다. 앱 화면에서 다시 시도하세요.'}

    @serialized
    def factory_reset(self,token,confirmation):
        try:
            self._authorized(token)
            result=self._factory_reset.run(confirmation,(self._order_auto,self._ably_sync,self._zigzag,self._returns,self._pickup))
            self._saved_exports.clear()
            return result
        except (ResetError,PermissionError) as exc:return {'error':str(exc)}
        except Exception as exc:
            import traceback;traceback.print_exc()   # desktop.log (10:23 보고: 원인을 보이게)
            return {'error':'초기화를 완료하지 못했습니다. 기존 앱 작업은 정지되어 있습니다. 폴더 권한을 확인하고 초기화를 다시 눌러주세요. ('+type(exc).__name__+': '+str(exc)[:200]+')'}

    @serialized
    def factory_reset_close(self,token):
        try:
            self._authorized(token)
            if not self._factory_reset.complete:return {'error':'전체 초기화를 먼저 완료하세요.'}
            self._window.confirm_close=False
            self._window.destroy()
            return {'closed':True}
        except Exception:return {'error':'앱 창의 종료 버튼으로 종료한 뒤 다시 실행하세요.'}

    @serialized
    def pick_orders(self, token):
        try:
            self._authorized(token)
            with self._dialog_lock:
                selected=self._window.create_file_dialog(self._view.FileDialog.OPEN,
                    allow_multiple=False,file_types=ORDER_FILE_TYPES)
                if not selected:return None
                self._authorized(token)
                path=selected_path(selected)
                if path.suffix.lower() not in {'.xls','.xlsx','.csv','.tsv'}:
                    return {'error':'xls, xlsx, csv, tsv 주문 파일을 선택하세요.'}
                # Limit bytes after reading too, in case the selected file changed.
                with path.open('rb') as f:data=f.read(MAX_IMPORT+1)
                if len(data)>MAX_IMPORT:return {'error':'주문 파일은 20MB 이하로 선택하세요.'}
                return {'name':path.name,'data':base64.b64encode(data).decode('ascii')}
        except FileNotFoundError:return {'error':'선택한 파일을 찾지 못했습니다. 클라우드 파일이면 맥에 다운로드한 뒤 다시 선택하세요.','code':'FILE_NOT_FOUND'}
        except PermissionError as exc:
            return {'error':('선택한 파일을 읽을 권한이 없습니다. 해당 폴더 접근 허용 여부를 확인하세요.' if exc.errno else str(exc)),'code':'ACCESS_DENIED'}
        except ValueError:return {'error':'파일 선택창 또는 경로 형식을 읽지 못했습니다. v0.6.12 설치기로 앱을 다시 설치하세요.','code':'FILE_DIALOG_FORMAT'}
        except OSError as exc:return {'error':f'파일 읽기 중 오류가 발생했습니다 (코드 {exc.errno}). 파일을 맥의 다운로드 폴더에 저장한 뒤 다시 선택하세요.','code':'FILE_IO'}

    @serialized
    def pick_supply_folder(self, token):
        try:
            self._authorized(token)
            with self._dialog_lock:
                selected=self._window.create_file_dialog(self._view.FileDialog.FOLDER, allow_multiple=False)
                if not selected:return None
                self._authorized(token)
                return self._engine.supply_link(str(selected_path(selected)))
        except Exception as exc:
            from supply_workflow import SupplyError
            if isinstance(exc,(SupplyError,PermissionError,ValueError)):return {'error':str(exc)}
            return {'error':'폴더를 연결하지 못했습니다. 선택 폴더 권한과 위치를 확인하세요.'}

    def _orders_controller(self):
        with self._order_auto_lock:
            if self._order_auto is None:
                from order_auto import OrderAutoController
                self._order_auto=OrderAutoController(self._engine.store,notify_confirmation=lambda:self._window.show())
                self._order_auto.alert=lambda title,message,level='error':self._engine.add_job_alert(title,message,level)
            self._order_auto.lock=operation_lock(self._engine)
            self._order_auto.external_busy=lambda:self._after_busy('orders')
            return self._order_auto

    def _auto_ably_push(self,keys):
        """After a message-less delay acknowledgement: platform delay notices for those rows
        (Ably push only, 아무드 japan-tab delay message by 주문번호, Zigzag 배송연기 안내); no date import.
        One browser job at a time: later jobs are queued in order (에이블리 → 아무드 → 지그재그)."""
        from order_items import ABLY
        from zigzag_sync import ZIGZAG
        from amood_push import AMOOD
        settings=self._engine.store.read().get('settings',{})
        rows={r['key']:r for r in self._engine.store.read().get('rows',[])}
        ably=[k for k in keys if (rows.get(k) or {}).get('seller')==ABLY]
        amood=[k for k in keys if (rows.get(k) or {}).get('seller')==AMOOD]
        zigzag=[k for k in keys if (rows.get(k) or {}).get('seller')==ZIGZAG]
        on=settings.get('autoAblyPush',True)
        jobs=[]
        if ably and on:jobs.append(('에이블리',f'에이블리 배송지연 메시지 발송 처리 ({len(ably)}개 상품)',lambda:self._ably_controller().start_push_only(ably),'ably'))
        if amood and on:jobs.append(('아무드',f'아무드 배송지연 메시지 발송 처리 ({len(amood)}개 상품 · 주문번호 매칭)',lambda:self._ably_controller().start_amood_push(amood),'ably'))
        if zigzag and settings.get('autoZigzagPush',True):jobs.append(('지그재그',f'지그재그 배송연기 안내 ({len(zigzag)}개 상품)',lambda:self._zigzag_controller().start_push_only(zigzag),'zigzag'))
        notes=[];errors=[]
        if jobs:
            # 2026-10-21: 다른 웹 작업(에이블리 동기화 등)이 돌고 있으면 오류로 돌려보내지 않고 대기열에 넣어 끝난 뒤 자동 시작.
            if self._after_busy(''):
                self._queue_chain([(n,f) for n,_,f,_ in jobs])
                notes.extend(l+' · 진행 중인 작업이 끝나면 자동 시작 (대기열)' for _,l,_,_ in jobs)
            else:
                name,label,fn,kind=jobs[0]
                try:fn();notes.append(label+' 시작')
                except Exception:
                    self._queue_chain([(name,fn)]);notes.append(label+' · 진행 중인 작업이 끝나면 자동 시작 (대기열)')
                if jobs[1:]:
                    self._queue_chain([(n,f) for n,_,f,_ in jobs[1:]])
                    notes.extend(l+' · 앞 작업이 끝난 뒤 시작' for _,l,_,_ in jobs[1:])
        if errors:raise RuntimeError(' / '.join(errors)+(' · '+' / '.join(notes) if notes else ''))
        return ' / '.join(notes)+(' · 예상출고일은 가져오지 않음' if notes else '')
    def _queue_chain(self,steps):
        """Run browser jobs one after another, each when no other web job is running.
        A start refused because another job slipped in first is retried (waits again), not reported."""
        import threading,time
        lock=getattr(self,'_chain_lock',None)
        if lock is None:lock=self._chain_lock=threading.Lock()
        def waiter():
            with lock:   # chains queued later run after this one, in order
                for name,fn in steps:
                    last=None
                    for attempt in range(6):
                        time.sleep(2)
                        for _ in range(7200):
                            if not self._after_busy(''):break
                            time.sleep(1)
                        try:fn();last=None;break
                        except Exception as exc:last=exc
                    if last is not None:self._engine.add_job_alert(f'{name} 자동 처리 시작 실패',str(last) or type(last).__name__,'error')
                    else:
                        # let the started job claim its thread before the next step checks busy
                        for _ in range(20):
                            if self._after_busy(''):break
                            time.sleep(.25)
        threading.Thread(target=waiter,daemon=True).start()
    def _queue_after_ably(self,fn):
        self._queue_chain([('지그재그',fn)])
    def _zigzag_controller(self):
        with self._order_auto_lock:
            if self._zigzag is None:
                from zigzag_sync import ZigzagSyncController
                self._zigzag=ZigzagSyncController(self._engine)
            return self._zigzag

    @serialized
    def zigzag_action(self,token,action,username='',password='',shop=''):
        try:
            self._authorized(token)
            if action in ('save','start','start_push') and self._after_busy('zigzag'):return {'error':'다른 웹 작업이 끝난 뒤 실행하세요.'}
            c=self._zigzag_controller()
            if action=='settings':return c.settings()
            if action=='save':return c.save(username,password,shop or 'nuavu')
            if action=='start':return c.start()
            if action=='start_push':return c.start_push_all()
            if action=='status':return c.status()
            if action=='cancel':return c.cancel()
            return {'error':'지원하지 않는 지그재그 작업입니다.'}
        except Exception as exc:
            from credentials import VaultError
            from zigzag_browser import ZigzagError
            return {'error':str(exc) if isinstance(exc,(VaultError,ZigzagError)) else '지그재그 요청을 처리하지 못했습니다. 앱과 저장 계정을 확인하세요.'}

    def _ably_controller(self):
        with self._order_auto_lock:
            if self._ably_sync is None:
                from ably_sync import AblySyncController
                self._ably_sync=AblySyncController(self._engine)
            return self._ably_sync

    def _after_busy(self,exclude=''):
        controllers=(('orders',self._order_auto),('ably',self._ably_sync),('zigzag',getattr(self,'_zigzag',None)),('returns',self._returns),('pickup',self._pickup),('display',getattr(self,'_soldout_display',None)))
        return any(name!=exclude and c and getattr(c,'thread',None) and c.thread.is_alive() for name,c in controllers)

    def _return_controller(self):
        with self._order_auto_lock:
            if self._returns is None:
                from return_check import ReturnController
                self._returns=ReturnController(self._engine,busy=lambda:self._after_busy('returns'),local=False)
                self._returns.lock=operation_lock(self._engine)
                self._returns.ezadmin_account=lambda:self._orders_controller().login_account()
            return self._returns

    def _soldout_display_controller(self):
        with self._order_auto_lock:
            if getattr(self,'_soldout_display',None) is None:
                from soldout_display import SoldoutDisplayController
                self._soldout_display=SoldoutDisplayController(self._engine,busy=lambda:self._after_busy('display'))
            return self._soldout_display
    # ---- 2026-10-23 버튼 하나 업데이트 (app_update.py) ----
    def _updater(self):
        if getattr(self,'_update',None) is None:
            from app_update import Updater
            from domain import APP_VERSION
            def busy():
                if self._after_busy():return '웹 자동화 작업'
                try:
                    if any(n.get('status')=='SENDING' for n in self._engine.store.read().get('notices',[])):return '문자 전송'
                except Exception:pass
                return ''
            def quit_app():
                w=self._window
                if w is None:return
                try:w.confirm_close=False
                except Exception:pass
                try:w.destroy()
                except Exception:pass
                def last_resort():
                    import time;time.sleep(30);os._exit(0)
                threading.Thread(target=last_resort,daemon=True).start()
            self._update=Updater(self._engine,APP_VERSION,busy=busy,quit_app=quit_app)
        return self._update
    @_readonly
    def update_status(self,token):
        try:self._authorized(token);return self._updater().status()
        except Exception as exc:return {'error':str(exc) if isinstance(exc,PermissionError) else '업데이트 상태를 읽지 못했습니다.'}
    @_readonly
    def update_check(self,token):
        try:self._authorized(token);return self._updater().check()
        except Exception as exc:return {'error':str(exc) if isinstance(exc,PermissionError) else '업데이트를 확인하지 못했습니다.'}
    @_readonly
    def update_install(self,token):
        try:self._authorized(token);return self._updater().install()
        except Exception as exc:
            from app_update import UpdateError
            return {'error':str(exc) if isinstance(exc,(PermissionError,UpdateError)) else '업데이트를 시작하지 못했습니다.'}
    @_readonly
    def activity_status(self,token):   # 읽기 전용 · 작업 잠금 없이 (폴링)
        """2026-10-22 진행상황 바: 지금 돌고 있는 작업 + 다음 예정 자동 작업."""
        try:
            self._authorized(token)
            from datetime import datetime,timezone,timedelta
            KST=timezone(timedelta(hours=9));now=datetime.now(KST);running=[];upcoming=[]
            for label,c in (('주문 불러오기',self._order_auto),('에이블리·아무드 동기화',self._ably_sync),('지그재그',getattr(self,'_zigzag',None)),('반품·교환 조회',self._returns),('회수접수',self._pickup),('품절 처리·주문취소',getattr(self,'_soldout_display',None))):
                try:
                    if c and getattr(c,'thread',None) and c.thread.is_alive():running.append({'name':label,'message':str((getattr(c,'job',None) or {}).get('message',''))[:200]})
                except Exception:pass
            e=self._engine;s=e.store.read()
            try:
                if getattr(getattr(e,'order_exporter',None),'busy',False):running.append({'name':'미출고 엑셀 저장','message':''})
            except Exception:pass
            def add(name,at):
                try:
                    d=datetime.fromisoformat(str(at).replace('Z','+00:00'))
                    if d.tzinfo is None:d=d.replace(tzinfo=KST)
                    if d>=now-timedelta(minutes=1):upcoming.append({'name':name,'at':d.isoformat()})
                except Exception:pass
            try:
                from order_import_schedule import public as _imp
                v=_imp(s)
                if v.get('enabled') and v.get('nextAt'):add('(Auto)주문 불러오기',v['nextAt'])
            except Exception:pass
            try:
                v=e.order_exporter.public(s)
                if v.get('enabled') and v.get('nextAt'):add('(Auto)미출고 엑셀 저장',v['nextAt'])
            except Exception:pass
            try:
                rs=s.get('returnSettings',{})
                if rs.get('mode')=='daily' and rs.get('time'):
                    h,m=map(int,rs['time'].split(':'));at=now.replace(hour=h,minute=m,second=0,microsecond=0)
                    if at<=now or s.get('returnScheduledDay')==now.date().isoformat():at+=timedelta(days=1)
                    add('(Auto)반품 조회',at.isoformat())
            except Exception:pass
            groups={}
            for n in s.get('notices',[]):
                if n.get('status')=='SCHEDULED' and n.get('scheduledAt') and not n.get('isTest'):
                    k=(n['scheduledAt'],'품절' if str(n.get('noticeType','')).startswith('soldout') else '배송지연');groups[k]=groups.get(k,0)+1
            for (at,kind),cnt in groups.items():add(f'예약 {kind} 문자 {cnt}건',at)
            for c in s.get('soldoutCancelSchedule',[]):add(f'예약 주문취소 {len(c.get("targets") or [])}건',c.get('at',''))
            upcoming.sort(key=lambda u:u['at'])
            return {'running':running,'upcoming':upcoming[:12],'now':now.isoformat()}
        except PermissionError as exc:return {'error':str(exc)}
        except Exception:return {'error':'진행상황을 읽지 못했습니다.'}

    @serialized
    def pick_china_cancel_folder(self,token):
        try:
            self._authorized(token)
            with self._dialog_lock:
                selected=self._window.create_file_dialog(self._view.FileDialog.FOLDER, allow_multiple=False)
                if not selected:return None
                self._authorized(token)
                return self._engine.china_cancel_folder(str(selected_path(selected)))
        except Exception as exc:
            from domain import ValidationError
            if isinstance(exc,(ValidationError,PermissionError,ValueError)):return {'error':str(exc)}
            return {'error':'취소건 폴더에 접근할 수 없습니다. 선택한 위치의 권한을 확인하세요.'}

    @serialized
    def soldout_display_action(self,token,action,username='',password='',payload=None):
        """자사몰(카페24) 계정 + 품절 옵션 처리 상태 (2026-10-20)."""
        try:
            self._authorized(token)
            from cafe24_credentials import Cafe24Accounts
            acc=Cafe24Accounts(self._engine.store.directory)
            if action=='settings':return acc.info()
            if action=='save':return acc.save(username,password)
            if action=='forget':return acc.forget()
            c=self._soldout_display_controller()
            if action=='status':return c.status()
            if action=='cancel':return c.cancel()
            if action=='kick':c.kick();return c.status()
            if action=='cancel_only':return c.cancel_only(payload)
            if action=='unschedule':return c.unschedule(payload)   # 2026-10-22 품절칸 '취소만 진행'
            if action=='test_cancel':return c.test_cancel(payload)   # 07:07 테스트 버튼
            if action=='test_display':return c.test_display(payload)
            return {'error':'지원하지 않는 품절 처리 작업입니다.'}
        except Exception as exc:
            from credentials import VaultError
            from soldout_display import DisplayError
            return {'error':str(exc) if isinstance(exc,(VaultError,DisplayError)) else '자사몰 설정 요청을 처리하지 못했습니다. 앱과 저장 계정을 확인하세요.'}
    def _pickup_controller(self):
        with self._order_auto_lock:
            if self._pickup is None:
                from pickup_controller import PickupController
                self._pickup=PickupController(self._engine,busy=lambda:self._after_busy('pickup'))
                self._pickup.lock=operation_lock(self._engine)
                self._pickup.notify_confirmation=lambda:self._window.show()
            return self._pickup

    @serialized
    def return_action(self,token,action,settings=None,job_id=''):
        try:
            self._authorized(token);c=self._return_controller()
            if action=='status':return c.status()
            if action=='save':return c.save(settings)
            if action=='start':return c.start(kind='return')
            if action=='all':return c.start(kind='all')   # 2026-10-20: 전체 · 지금 조회 (반품 + 교환 한 번에)
            if action=='exchange':return c.start(kind='exchange')
            if action.startswith('test:'):return c.start(kind='test',seller=action[5:])   # 2026-10-21 반품설정 › 판매처별 테스트
            if action.startswith('seller:'):return c.start(kind='seller',seller=action[7:])   # 2026-10-21 20:06 판매처별 실제 반품조회
            if action=='cancel':return c.cancel()
            if action=='continue':return c.continue_login(job_id)
            return {'error':'지원하지 않는 반품 작업입니다.'}
        except Exception as exc:
            from credentials import VaultError
            from return_data import ReturnError
            return {'error':str(exc) if isinstance(exc,(VaultError,ReturnError,PermissionError)) else '반품·교환 작업을 처리하지 못했습니다. 이전 결과를 유지합니다.'}

    @serialized
    def pickup_action(self,token,action,payload=None,job_id=''):
        try:
            self._authorized(token);c=self._pickup_controller()
            if action=='status':return c.status()
            if action=='save':return c.save(payload)
            if action=='start':return c.start_pickups(payload)
            if action=='inspect':return c.start_pickups(payload,inspect_only=True)
            if action=='cancel':return c.cancel()
            if action=='continue':return c.request_browser_action(job_id,'continue')  # 에이블리 로그인 수동 완료 후 계속
            if action=='answer':
                if not isinstance(payload,dict):raise ValueError()
                return c.answer_login_confirmation(job_id,payload.get('id'),payload.get('accepted'))
            return {'error':'지원하지 않는 회수 작업입니다.'}
        except Exception as exc:
            from order_auto import OrderAutoError
            from return_data import ReturnError
            from credentials import VaultError
            return {'error':str(exc) if isinstance(exc,(OrderAutoError,ReturnError,VaultError,PermissionError)) else '회수 요청을 처리하지 못했습니다. 결과를 확인하세요.'}

    @serialized
    def pick_return_folder(self,token):
        try:
            self._authorized(token)
            with self._dialog_lock:
                selected=self._window.create_file_dialog(self._view.FileDialog.FOLDER,allow_multiple=False)
                if not selected:return None
                self._authorized(token);c=self._return_controller();cfg=c.config();cfg['folder']=str(selected_path(selected));return c.save(cfg)
        except Exception:return {'error':'반품 폴더를 연결하지 못했습니다.'}

    @serialized
    def ably_sync_action(self,token,action,username='',password=''):
        try:
            self._authorized(token)
            if action in ('save','start','start_push') and self._after_busy('ably'):return {'error':'다른 웹 작업이 끝난 뒤 실행하세요.'}
            c=self._ably_controller()
            if action in ('save','start','start_push') and self._returns and self._returns.running():return {'error':'반품 조회가 끝난 뒤 에이블리 계정 변경·동기화를 실행하세요.'}
            if action=='settings':return c.settings()
            if action=='save':return c.save(username,password)
            if action=='start':return c.start()
            if action=='start_push':return c.start(push=True)  # read + app-planned Ably delay-message sends
            if action=='status':return c.status()
            if action=='cancel':return c.cancel()
            if action in ('amood_push','amood_preview'):
                if self._after_busy('ably') or (self._returns and self._returns.running()):return {'error':'다른 웹 작업이 끝난 뒤 실행하세요.'}
                if action=='amood_push':return c.start_amood_push(None)
                return c.start_amood_preview(username,password)   # 주문번호, 예상 출고일 (계정 값 아님)
            return {'error':'지원하지 않는 에이블리 작업입니다.'}
        except Exception as exc:
            from credentials import VaultError
            from ably_sync import AblySyncError
            return {'error':str(exc) if isinstance(exc,(VaultError,AblySyncError)) else '에이블리 동기화 요청을 처리하지 못했습니다. 앱과 저장 계정을 확인하세요.'}

    @serialized
    def ezadmin_login_settings(self, token):
        try:
            self._authorized(token)
            return self._orders_controller().login_settings()
        except (PermissionError,):return {'error':'누아브 앱에서 이지어드민 설정을 여세요.'}
        except Exception as exc:
            from credentials import VaultError
            from order_auto import OrderAutoError
            return {'error':str(exc) if isinstance(exc,(VaultError,OrderAutoError)) else '이지어드민 키체인을 읽지 못했습니다.'}

    @serialized
    def ezadmin_login_save(self, token, domain, username, password):
        try:
            self._authorized(token)
            if self._pickup and self._pickup.running():return {'error':'회수접수 종료 후 실행하세요.'}
            return self._orders_controller().save_login_settings(domain,username,password)
        except (PermissionError,):return {'error':'누아브 앱에서 이지어드민 설정을 저장하세요.'}
        except Exception as exc:
            from credentials import VaultError
            from order_auto import OrderAutoError
            return {'error':str(exc) if isinstance(exc,(VaultError,OrderAutoError)) else '이지어드민 계정을 저장하지 못했습니다.'}

    @serialized
    def order_auto_status(self, token):
        try:
            self._authorized(token)
            return self._orders_controller().status()
        except Exception as exc:return {'error':str(exc)}

    @serialized
    def order_auto_settings(self, token, group):
        try:
            self._authorized(token)
            return self._orders_controller().configure(group=group)
        except Exception as exc:return {'error':str(exc)}

    @serialized
    def pick_order_download_folder(self, token):
        try:
            self._authorized(token)
            with self._dialog_lock:
                selected=self._window.create_file_dialog(self._view.FileDialog.FOLDER,allow_multiple=False)
                if not selected:return None
                self._authorized(token)
                return self._orders_controller().configure(folder=str(selected_path(selected)))
        except Exception:return {'error':'다운로드 폴더를 연결하지 못했습니다. 실행 중이라면 중단 후 다시 선택하세요.'}

    @serialized
    def order_auto_start(self, token):
        try:
            self._authorized(token)
            if self._pickup and self._pickup.running():return {'error':'회수접수 종료 후 실행하세요.'}
            return self._orders_controller().start()
        except Exception as exc:return {'error':str(exc)}

    @serialized
    def ezadmin_login_check(self, token):
        try:
            self._authorized(token)
            if self._pickup and self._pickup.running():return {'error':'회수접수 종료 후 실행하세요.'}
            return self._orders_controller().start(login_only=True)
        except Exception:return {'error':'로그인 확인을 시작하지 못했습니다. 현재 불러오기가 끝난 뒤 다시 시도하세요.'}

    @serialized
    def ezadmin_login_answer(self, token, job_id, question_id, accepted):
        try:
            self._authorized(token)
            return self._orders_controller().answer_login_confirmation(job_id,question_id,accepted)
        except Exception:return {'error':'만료되었거나 처리할 수 없는 로그인 확인 요청입니다.'}

    @serialized
    def order_browser_action(self, token, job_id, action, login_server='login2'):
        try:
            self._authorized(token)
            return self._orders_controller().request_browser_action(job_id,action,login_server)
        except Exception as exc:
            from order_auto import OrderAutoError
            return {'error':str(exc) if isinstance(exc,OrderAutoError) else '현재 로그인 창에서 요청을 처리할 수 없습니다.'}

    @serialized
    def order_auto_result(self, token, job_id):
        try:
            self._authorized(token)
            return self._orders_controller().take_result(job_id)
        except Exception as exc:return {'error':str(exc)}

    @serialized
    def order_auto_cancel(self, token):
        try:
            self._authorized(token)
            return self._orders_controller().cancel()
        except Exception as exc:return {'error':str(exc)}

    @serialized
    def save_export(self, token, kind, payload=None):
        try:
            self._authorized(token)
            if kind not in {'export','backup','orders'}:return {'error':'지원되지 않는 내보내기입니다.'}
            with self._dialog_lock:
                order_result=None
                if kind=='orders':
                    from order_export import export_orders
                    if not isinstance(payload,dict):return {'error':'다운로드할 주문을 확인하세요.'}
                    order_result=export_orders(self._engine,payload)
                suffix='.xlsx' if order_result else '.csv' if kind=='export' else '.json'
                name=order_result['name'] if order_result else '배송안내_발송이력.csv' if kind=='export' else '배송안내_개인정보포함_백업.json'
                selected=self._window.create_file_dialog(self._view.FileDialog.SAVE,
                    save_filename=name,file_types=(f'{suffix[1:].upper()} (*{suffix})',))
                if not selected:return {'saved':False}
                self._authorized(token)
                path=selected_path(selected)
                if path.suffix.lower()!=suffix:return {'error':f'파일 이름은 {suffix} 확장자로 저장하세요.'}
                if path.resolve()==self._engine.store.path.resolve():return {'error':'실행 중인 데이터 파일을 덮어쓸 수 없습니다.'}
                data=order_result['data'] if order_result else self._engine.export_csv() if kind=='export' else json.dumps(
                    {'format':'NUAVU_Delay_readonly_backup_v2','state':self._engine.store.read()},ensure_ascii=False,indent=2).encode('utf-8')
                fd,tmp=tempfile.mkstemp(prefix='.nuavu-export-',dir=path.parent)
                try:
                    with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
                    os.chmod(tmp,0o600);os.replace(tmp,path)
                finally:Path(tmp).unlink(missing_ok=True)
                if order_result:
                    reveal_id=secrets.token_urlsafe(24)
                    self._saved_exports[reveal_id]=path.absolute()
                    while len(self._saved_exports)>20:self._saved_exports.pop(next(iter(self._saved_exports)))
                    return {'saved':True,'name':path.name,'count':order_result['count'],
                            'missingContacts':order_result['missingContacts'],'revealId':reveal_id}
                return {'saved':True}
        except PermissionError as exc:return {'error':str(exc)}
        except ValueError as exc:
            from domain import ValidationError
            return {'error':str(exc)} if isinstance(exc,ValidationError) else {'error':'저장 파일 선택창 또는 경로 형식을 확인할 수 없습니다.','code':'FILE_DIALOG_FORMAT'}
        except OSError as exc:return {'error':f'파일을 저장하지 못했습니다 (코드 {exc.errno}). 저장 위치의 권한을 확인하세요.','code':'FILE_IO'}

    @serialized
    def reveal_export(self, token, reveal_id):
        return self._open_saved_export(token,reveal_id,reveal=True)

    @serialized
    def open_export(self, token, reveal_id):
        return self._open_saved_export(token,reveal_id,reveal=False)

    def _open_saved_export(self, token, reveal_id, *, reveal):
        """Open/reveal only a saved export; never accept a path from the UI."""
        try:
            self._authorized(token)
            if not isinstance(reveal_id,str) or reveal_id not in self._saved_exports:
                return {'error':'이 앱에서 저장한 파일을 다시 선택하세요.'}
            path=self._saved_exports[reveal_id]
            if not path.is_file():return {'error':'저장한 파일을 찾지 못했습니다. 파일이 이동되거나 삭제됐는지 확인하세요.'}
            if not (IS_MAC or IS_WINDOWS):return {'error':'저장한 파일 열기는 설치한 앱에서 사용할 수 있습니다.'}
            (reveal_path if reveal else open_path)(path)
            return {'opened':True}
        except PermissionError as exc:return {'error':str(exc)}
        except (OSError,subprocess.SubprocessError):return {'error':'Finder에서 파일을 표시하지 못했습니다. 잠시 후 다시 눌러주세요.' if reveal else '파일을 열지 못했습니다. 엑셀 파일의 기본 연결 앱을 확인하세요.'}


def set_app_icon():
    """Use the bundled icon in the Dock even when a Python launcher hosts Cocoa."""
    if sys.platform!='darwin':return
    root=Path(__file__).resolve().parent
    icon=root/'CS-Pink.icns'
    if not icon.is_file():icon=root/'assets/CS-Pink.icns'
    if not icon.is_file():return
    try:
        from AppKit import NSApplication, NSImage
        image=NSImage.alloc().initWithContentsOfFile_(str(icon))
        if image is not None:NSApplication.sharedApplication().setApplicationIconImage_(image)
    except Exception:
        # An optional cosmetic asset must not prevent orders or the app from loading.
        print('앱 아이콘을 표시하지 못했습니다. 기본 아이콘으로 실행합니다.',file=sys.stderr)


def _windows_log(directory):
    """pythonw.exe has no console: route prints/tracebacks to <data>/logs/desktop.log (same name the macOS launcher uses)."""
    if not IS_WINDOWS:return
    try:
        logdir=Path(directory)/'logs';logdir.mkdir(parents=True,exist_ok=True)
        logfile=open(logdir/'desktop.log','a',encoding='utf-8',buffering=1)
        from datetime import datetime
        logfile.write(f'\n==== {datetime.now().isoformat(timespec="seconds")} desktop.py 시작 (python {sys.version.split()[0]}, {sys.executable}) ====\n')
        if sys.stdout is None:sys.stdout=logfile
        if sys.stderr is None:sys.stderr=logfile
    except Exception:pass

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--data-dir');args=parser.parse_args()
    if not (IS_MAC or IS_WINDOWS):raise SystemExit('독립 앱 창은 macOS/Windows용입니다. 개발 테스트에는 app.py --no-browser를 사용하세요.')
    directory=Path(args.data_dir or data_dir()).expanduser()
    directory.mkdir(parents=True,exist_ok=True,mode=0o700)
    _windows_log(directory)   # 10:00 보고: 창이 안 뜨는 원인을 로그에 남기려면 webview import 전부터 기록해야 한다
    try:import webview
    except Exception as exc:
        import traceback;traceback.print_exc()
        show_error(('처음한번_앱설치.bat' if IS_WINDOWS else '처음한번_앱설치.command')+'를 먼저 실행하여 앱 구성요소를 설치하세요. ('+type(exc).__name__+': '+str(exc)[:200]+')');return 1
    os.umask(0o077)
    lock=ProcessLock(directory)
    if not lock.acquire():
        show_error('배송안내 배포판이 이미 실행 중입니다. 기존 앱 창을 사용하세요. 이전 웹 버전이 실행 중이면 해당 터미널에서 Control + C로 먼저 종료하세요.');return 1
    store=None;engine=None;server=None;thread=None;bridge=None;runtime=directory/'runtime.json'
    try:
        complete_pending_reset(directory)
        store=Store(directory);archive=DesktopBackup(store);engine=Engine(store,archive=archive);engine.backup_desktop(force=True,reason='startup');server=LocalServer(engine);server.desktop=True
        bridge=DesktopAPI(engine,server.token,server.origin,webview)
        runtime.write_text(json.dumps({'url':server.url,'pid':os.getpid(),'mode':'desktop'}));os.chmod(runtime,0o600)
        webview.settings['ALLOW_FILE_URLS']=False
        webview.settings['ALLOW_DOWNLOADS']=False # Explicit, scoped native save dialogs instead.
        webview.settings['IGNORE_SSL_ERRORS']=False
        window=webview.create_window('배송안내 배포판 · 배송지연 / 품절 안내',url=server.url,js_api=bridge,
            width=1440,height=960,min_size=(960,680),text_select=True,zoomable=True,confirm_close=True,
            localization={'global.quit':'종료','global.cancel':'계속 사용',
                          'global.quitConfirmation':'앱을 종료하면 예약 발송과 결과 조회·자동 반품체크가 멈춥니다. 계속 실행하려면 최소화하세요. 종료할까요?'})
        bridge._window=window
        thread=threading.Thread(target=server.serve_forever,kwargs={'poll_interval':0.3},daemon=True);thread.start()
        engine.start_worker()
        engine.manual_notice_hook=bridge._auto_ably_push
        bridge._return_controller().start_scheduler()
        bridge._pickup_controller().start_scheduler()
        engine.soldout_display_hook=lambda items:bridge._soldout_display_controller().enqueue(items,'notice')
        try:   # 2026-10-22: 진행상황(AI) › 취소건 폴더 감시
            from china_cancel import ChinaCancelWatcher
            engine.china_cancel_watcher=ChinaCancelWatcher(engine);engine.china_cancel_watcher.start()
        except Exception:pass
        # 2026-10-22: 처리되지 않은 백그라운드 오류도 ⚙ 설정 › 오류 로그에 남긴다.
        _prev_hook=threading.excepthook
        def _thread_hook(args,_prev=_prev_hook):
            try:
                import traceback as _tb
                engine.record_error('처리되지 않은 오류 · '+(args.thread.name if args.thread else ''),f'{args.exc_type.__name__}: {args.exc_value}',''.join(_tb.format_exception(args.exc_type,args.exc_value,args.exc_traceback)))
            except Exception:pass
            _prev(args)
        threading.excepthook=_thread_hook
        bridge._soldout_display_controller().start_scheduler()
        try:bridge._updater().start()   # 2026-10-23: 시작 3초 뒤 + 3시간마다 새 버전 확인 (latest.json, 서명 확인)
        except Exception:pass
        def terminate(*_):window.destroy()
        signal.signal(signal.SIGTERM,terminate);signal.signal(signal.SIGINT,terminate)
        # Cocoa selects the macOS WKWebView renderer automatically. No browser is launched.
        set_app_icon()
        webview.start(private_mode=True,debug=False)
        return 0
    except ResetError as exc:
        show_error(str(exc));return 1
    except Exception:
        # Do not print HTTP payloads or credentials to logs.
        import traceback
        traceback.print_exc()
        show_error('앱 창 실행 중 오류가 발생했습니다. '+(str(data_dir()/'logs'/'desktop.log') if IS_WINDOWS else '~/Library/Logs/NUAVU Delay Distribution/desktop.log')+'를 확인하세요. 기존 주문·이력은 삭제하지 마세요.')
        return 1
    finally:
        if server and thread and thread.is_alive():server.shutdown();thread.join(timeout=5)
        if engine:engine.stop_worker()
        if bridge and not getattr(engine,'reset_store_closed',False):
            for controller in (bridge._ably_sync,bridge._order_auto,bridge._returns,bridge._pickup):
                if controller:
                    if hasattr(controller,'shutdown'):controller.shutdown()
                    controller.cancel()
                    if getattr(controller,'scheduler_thread',None):controller.scheduler_thread.join(timeout=5)
                    if controller.thread:controller.thread.join(timeout=5)
        if server:server.server_close()
        browser_busy=bool(bridge and any(c and c.thread and c.thread.is_alive() for c in (bridge._ably_sync,bridge._order_auto,bridge._returns,bridge._pickup)))
        if store and not browser_busy and not getattr(engine,'reset_store_closed',False) and (not engine or (not engine.supply_watcher.running() and (not engine.thread or not engine.thread.is_alive()))):store.close()
        runtime.unlink(missing_ok=True)
        lock.release()

def _guarded_main():
    try:return main()
    except SystemExit:raise
    except Exception as exc:
        import traceback;traceback.print_exc()
        try:show_error('앱 창을 열지 못했습니다: '+type(exc).__name__+': '+str(exc)[:300])
        except Exception:pass
        return 1

if __name__=='__main__':raise SystemExit(_guarded_main())
