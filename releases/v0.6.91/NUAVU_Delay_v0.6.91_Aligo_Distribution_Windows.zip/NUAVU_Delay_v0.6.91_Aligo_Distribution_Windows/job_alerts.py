"""'작업완료!' notifications. Standalone so background modules can import it without touching domain."""
def job_alert(engine,title,message,level='info'):
    """Post a job notification if the engine supports it (test doubles may not). Never raises."""
    fn=getattr(engine,'add_job_alert',None)
    if not fn:return
    try:fn(title,message,level)
    except Exception:pass
