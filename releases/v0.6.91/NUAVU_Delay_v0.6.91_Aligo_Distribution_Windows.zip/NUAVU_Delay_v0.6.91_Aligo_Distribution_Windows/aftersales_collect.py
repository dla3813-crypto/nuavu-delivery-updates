from return_browser import collect as collect_remote
from exchange_browser import collect_local,collect_exchange

def collect(account,controller):
    kind=account.get('kind','return')
    if kind=='exchange':result=collect_exchange(account,controller)
    else:
        result=(collect_local if account.get('local') else collect_remote)(account,controller)
        if kind=='all':result['exchangeRows']=collect_exchange(account,controller)['rows']
    for r in result.get('rows',[])+result.get('exchangeRows',[]):r.setdefault('seller','에이블리')
    return merge_cafe24(merge_zigzag(result,account,controller),account,controller)

def merge_zigzag(result,account,controller):
    """2026-10-20 (공통): with a saved 지그재그 account whose login id is an e-mail, 반품체크 also reads the partner center
    반품요청·반품수거중 (+ 교환요청·교환수거중) and appends those rows (seller 지그재그). A 지그재그 failure never discards the Ably result."""
    from zigzag_returns import zigzag_enabled,collect_zigzag,ZigzagCancelled
    kind=account.get('kind','return')
    info,note=zigzag_enabled(controller.engine.store.directory)
    result['zigzag']={'enabled':bool(info),'note':note,'totals':{},'actions':[],'error':''}
    if not info:return result
    try:
        from zigzag_credentials import ZigzagAccounts
        zz=ZigzagAccounts(controller.engine.store.directory).for_login()
    except Exception as exc:
        result['zigzag']['error']=str(exc);return result
    try:
        controller.update('running','지그재그 파트너센터에서 반품/교환 목록을 읽습니다.')
        got=collect_zigzag(controller,zz,controller.clock().date(),want_returns=kind!='exchange',want_exchanges=True)
    except ZigzagCancelled:raise
    except Exception as exc:
        result['zigzag']['error']=(str(exc) or type(exc).__name__)[:200];return result
    finally:
        try:zz.clear()
        except Exception:pass
    result['zigzag'].update(totals=got['totals'],actions=got['actions'])
    if kind!='exchange':
        result['rows']=list(result.get('rows',[]))+got['rows'];result['total']=len(result['rows'])
    if kind=='exchange':result['rows']=list(result.get('rows',[]))+got['exchangeRows'];result['total']=len(result['rows'])
    elif kind=='all':result['exchangeRows']=list(result.get('exchangeRows',[]))+got['exchangeRows']
    else:result['zigzagExchangeRows']=got['exchangeRows']
    return result

def merge_cafe24(result,account,controller):
    """2026-10-21 (공통): with a saved 자사몰(카페24) account, 반품체크 also reads 반품 관리(1개월) and 교환 관리(1개월)
    and appends the 진행 중 rows (seller 자사몰), exchanges placed like the 지그재그 ones. A 자사몰 failure never
    discards the other results."""
    from cafe24_returns import cafe24_enabled,collect_cafe24
    kind=account.get('kind','return')
    result['cafe24']={'enabled':False,'note':'','totals':{},'error':''}
    info,note=cafe24_enabled(controller.engine.store.directory)
    result['cafe24'].update(enabled=bool(info),note=note)
    if not info:return result
    try:
        from cafe24_credentials import Cafe24Accounts
        acct=Cafe24Accounts(controller.engine.store.directory).for_login()
        if not acct:return result
    except Exception as exc:
        result['cafe24']['error']=str(exc);return result
    try:
        controller.update('running','자사몰(카페24) 반품·교환 관리에서 목록을 읽습니다.')
        got=collect_cafe24(controller,acct,controller.clock().date(),want_returns=kind!='exchange',want_exchanges=True)
    except Exception as exc:
        if type(exc).__name__ in ('ReturnCancelled','Cancelled'):raise
        result['cafe24']['error']=(str(exc) or type(exc).__name__)[:200];return result
    finally:
        try:acct.clear()
        except Exception:pass
    result['cafe24'].update(totals=got['totals'],notes=got.get('notes',[]))
    ex=got.get('exchangeRows',[])
    if kind=='exchange':
        result['rows']=list(result.get('rows',[]))+ex;result['total']=len(result['rows'])
    else:
        result['rows']=list(result.get('rows',[]))+got['rows'];result['total']=len(result['rows'])
        if kind=='all':result['exchangeRows']=list(result.get('exchangeRows',[]))+ex
        else:result['cafe24ExchangeRows']=ex
    return result

def collect_test(account,controller,seller):
    """반품설정 › 판매처별 테스트: read that seller only. Nothing is saved, no 수거완료·회수접수 actions."""
    today=controller.clock().date()
    if seller=='에이블리':
        result=(collect_local if account.get('local') else collect_remote)(account,controller)
        rows=result.get('rows',[])
        for r in rows:r.setdefault('seller','에이블리')
        return {'rows':rows,'note':''}
    if seller=='지그재그':
        from zigzag_returns import zigzag_enabled,collect_zigzag
        info,note=zigzag_enabled(controller.engine.store.directory)
        if not info:return {'rows':[],'note':note}
        from zigzag_credentials import ZigzagAccounts
        zz=ZigzagAccounts(controller.engine.store.directory).for_login()
        try:got=collect_zigzag(controller,zz,today,want_returns=True,want_exchanges=True,auto_complete=False)
        finally:
            try:zz.clear()
            except Exception:pass
        return {'rows':got['rows']+got['exchangeRows'],'note':' / '.join(f'{k} {v}건' for k,v in got['totals'].items())}
    if seller=='자사몰':
        from cafe24_returns import cafe24_enabled,collect_cafe24
        info,note=cafe24_enabled(controller.engine.store.directory)
        if not info:return {'rows':[],'note':note}
        from cafe24_credentials import Cafe24Accounts
        acct=Cafe24Accounts(controller.engine.store.directory).for_login()
        try:got=collect_cafe24(controller,acct,today)
        finally:
            try:acct.clear()
            except Exception:pass
        return {'rows':got['rows']+got.get('exchangeRows',[]),'note':f"반품 1개월 {got.get('scanned',0)}건 중 진행 중 {len(got['rows'])}건 · 교환 1개월 {got.get('scannedExchange',0)}건 중 진행 중 {len(got.get('exchangeRows',[]))}건"+(' · '+' / '.join(got['notes']) if got.get('notes') else '')}
    raise ValueError('테스트할 판매처를 확인하세요.')

def collect_seller(account,controller):
    """2026-10-21 20:06: 판매처별 실제 반품조회 — that seller only, with the same side effects as 반품체크
    (지그재그 수거완료 처리 포함). The caller replaces only that seller's rows."""
    from return_data import ReturnError
    seller=account.get('onlySeller')
    if seller=='에이블리':
        result=(collect_local if account.get('local') else collect_remote)(account,controller)
        for r in result.get('rows',[]):r.setdefault('seller','에이블리')
        return result
    base={'rows':[],'total':0,'complete':True}
    if seller=='지그재그':
        res=merge_zigzag(base,{**account,'kind':'return'},controller);info=res.get('zigzag') or {}
    elif seller=='자사몰':
        res=merge_cafe24(base,{**account,'kind':'return'},controller);info=res.get('cafe24') or {}
    else:raise ReturnError('조회할 판매처를 확인하세요.')
    if not info.get('enabled'):raise ReturnError(info.get('note') or f'{seller} 계정이 없어 조회하지 않았습니다.')
    if info.get('error'):raise ReturnError(f'{seller} 반품 조회 실패 · '+info['error'])
    return res
