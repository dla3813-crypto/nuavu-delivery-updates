"""Separate return/exchange and pickup metadata; never changes order/sender state."""
from __future__ import annotations
import hashlib,json,re,unicodedata,io,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
from datetime import date
from return_data import ReturnError,invoice,read_returns,verify_return_count,classify,carrier_of
from workbook_reader import read_xlsx,text

def shop(state):
    cfg=state.get('settings',{})
    return {'shopName':cfg.get('shopName') or '누아브','shopRevision':cfg.get('shopRevision',0)}
def folder_default():
    p=Path.home()/'Desktop'
    for name in ('클로드','반품엑셀'):
        matches=[q for q in p.iterdir() if unicodedata.normalize('NFC',q.name)==name] if p.is_dir() else []
        p=matches[0] if len(matches)==1 else p/name
    return p
def local_source(folder):
    p=Path(folder)
    matches=[q for q in p.iterdir() if unicodedata.normalize('NFC',q.name)=='에이블리 반품진행상황.xlsx' and q.is_file() and not q.is_symlink()] if p.is_dir() else []
    if len(matches)!=1:raise ReturnError('연결 폴더에서 에이블리 반품진행상황.xlsx 한 파일을 찾지 못했습니다.')
    return matches[0]
def local_signature(folder):
    p=local_source(folder);s=p.stat()
    return (str(p),s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)
def read_local(raw,today):
    # Legend columns live beside the table. Count only records under named order columns.
    sheets=read_xlsx(raw);totals=[]
    for s in sheets:
        if not s['rows']:continue
        heads=[re.sub(r'\s+','',text(x)) for x in s['rows'][0]]
        if '반품접수번호' not in heads:continue
        ci=heads.index('반품접수번호');oi=heads.index('주문번호') if '주문번호' in heads else -1
        records=[r for r in s['rows'][1:] if any(text(v) for v in r[:30])]
        ids={text(r[ci]) for r in records if len(r)>ci}
        if oi<0 or any(len(r)<=oi or not text(r[oi]) for r in records):raise ReturnError('반품 파일에 주문번호 없는 상품 행이 있습니다.')
        totals.append(len(ids))
    if len(totals)!=1:raise ReturnError('반품 엑셀의 접수번호 열을 확인하지 못했습니다.')
    return read_returns(raw,totals[0],today),totals[0]
def public_aftersales(state,today):
    cfg=shop(state);saved=state.get('returnCheck',{});exchange=state.get('exchangeCheck',{})
    same=lambda data:all(data.get(k)==v for k,v in cfg.items())
    rows=[classify(r,today) for r in saved.get('rows',[])] if same(saved) else []
    erows=[{**classify(r,today),'kind':'exchange'} for r in exchange.get('rows',[])] if same(exchange) else []
    history=state.get('pickupHistory',[])
    from return_messages import return_notice_state
    for r in rows+erows:
        r.setdefault('seller','에이블리')
        # 반품 안내 문자 (23:33 요청): a return with a live/delivered 불량 아님 안내 moves to its own card.
        st=return_notice_state(state.get('notices',[]),r.get('invoice'))
        r['notDefectNotice']=st['notDefect'];r['overdueNotice']=st['overdue'];r['manualNotice']=st.get('manual','')
        if st['notDefect'] and r.get('kind')!='exchange':
            r['category']='not_defect_done';r['label']='반품 불량 아님 안내 완료'
        r['pickupHistory']=[{k:h.get(k,'') for k in ('result','at','acceptedAt','attempt','receiver','carrier','note')} for h in history if h.get('invoice')==r.get('invoice') and h.get('shopName')==cfg['shopName'] and h.get('shopRevision',0)==cfg['shopRevision']]
    counts={k:sum(r['logistics']==k for r in rows) for k in ('arrived','transit','undelivered','unknown')}
    counts.update(total=len(rows),exchange=len(erows))
    # 2026-10-20: the 에이블리 card counts 반품 접수(요청) 건; the workbook/app rows are products (one request can hold several).
    from collections import Counter
    per_request=Counter(r.get('requestId') or (r.get('orderId'),r.get('requestedAt')) for r in rows)
    counts['requests']=len(per_request);counts['multiProductRequests']=sum(1 for n in per_request.values() if n>1)
    return {'rows':rows,'exchangeRows':erows,'counts':counts,'lastChecked':saved.get('lastChecked','') if same(saved) else '',
            'exchangeChecked':exchange.get('lastChecked','') if same(exchange) else '', 'source':saved.get('source',''), 'scopeChanged':bool(saved and not same(saved)),
            'zigzag':saved.get('zigzag',{}) if same(saved) else {},'cafe24':saved.get('cafe24',{}) if same(saved) else {}}
def parse_pickup_input(values):
    if not isinstance(values,list) or not 0<len(values)<=1000:raise ReturnError('원운송장번호를 1~1,000건 입력하세요.')
    out={}
    for value in values:
        if not isinstance(value,dict):raise ReturnError('회수 입력 형식이 잘못되었습니다.')
        number=invoice(value.get('invoice'))
        if not number:raise ReturnError('원운송장번호는 10~14자리 숫자로 입력하세요.')
        row={'invoice':number,'customer':str(value.get('customer','')).strip(),'phone':re.sub(r'[^0-9]','',str(value.get('phone',''))),'rowKey':str(value.get('rowKey','')),'preflightIssue':str(value.get('preflightIssue',''))[:200]}
        if len(row['customer'])>100 or len(row['phone'])>14:raise ReturnError('고객명·연락처 입력을 확인하세요.')
        if number in out and any(out[number][k] and row[k] and out[number][k]!=row[k] for k in ('customer','phone')):raise ReturnError('같은 원송장에 서로 다른 고객정보가 있습니다.')
        if number not in out:out[number]=row
        else:
            for k in ('customer','phone'):out[number][k]=out[number][k] or row[k]
    return list(out.values())
PICKUP_SELLERS=('에이블리','자사몰','지그재그')

def pickup_sellers(state):
    """2026-10-20: 자동 회수접수 is chosen per 판매처. Old bool-only settings mean every seller; a missing key means on."""
    cfg=state.get('pickupSettings',{}) or {}
    saved=cfg.get('sellers') if isinstance(cfg.get('sellers'),dict) else {}
    return {s:bool(saved.get(s,True)) for s in PICKUP_SELLERS}

def auto_candidates(state,today,sellers=None):
    view=public_aftersales(state,today);cfg=shop(state);seen=set();out=[]
    sellers=pickup_sellers(state) if sellers is None else sellers
    candidates=view['rows']+view['exchangeRows']
    identities={}
    for r in candidates:
        fields=identities.setdefault(r.get('invoice'),{'recipient':set(),'recipientPhone':set()})
        for k in fields:
            if r.get(k):fields[k].add(re.sub(r'\D','',r[k]) if k=='recipientPhone' else re.sub(r'\s+','',r[k]))
    conflicts={n for n,fields in identities.items() if any(len(values)>1 for values in fields.values())}
    for r in view['rows']+view['exchangeRows']:
        number=invoice(r.get('invoice'))
        if not number or number in seen or r.get('category') not in ('uncollected','unknown'):continue
        if not sellers.get(r.get('seller') or '에이블리',False):continue  # 판매처별 자동 회수접수 선택
        # One automatic attempt for a tracking number across restarts and file refreshes.
        if any(h.get('invoice')==number and h.get('shopName')==cfg['shopName'] and h.get('shopRevision',0)==cfg['shopRevision'] and not h.get('inspectOnly') for h in state.get('pickupHistory',[])):continue
        seen.add(number);out.append({'invoice':number,'customer':r.get('recipient',''),'phone':r.get('recipientPhone',''),'rowKey':r['key'],'preflightIssue':'같은 원송장에 서로 다른 수령인 정보가 있습니다.' if number in conflicts else ''})
    return out

def platform_of(state,today,invoice_number):
    """{'seller','kind','itemId','zigzagStatus'} of the return/exchange row holding that 원송장 (for the step after 이지어드민 회수접수)."""
    view=public_aftersales(state,today)
    for r in view['rows']+view['exchangeRows']:
        if invoice(r.get('invoice'))==invoice_number:
            return {'seller':r.get('seller','에이블리'),'kind':r.get('kind','return'),'itemId':r.get('itemId',''),'zigzagStatus':r.get('zigzagStatus','')}
    return {'seller':'에이블리','kind':'return','itemId':'','zigzagStatus':''}
