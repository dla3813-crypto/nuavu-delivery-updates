"""EX00 sequential pickup. Existing Flow owns authentication; no sender/refund API."""
import re,time
from urllib.parse import urlsplit
from order_browser import Flow
from order_auto import OrderAutoError,Cancelled
from return_data import invoice

INDEX='https://ga79.ezadmin.co.kr/index.htm'
EX00='https://ga79.ezadmin.co.kr/popup35.htm?template=EX00'
E804='https://ga79.ezadmin.co.kr/template40.htm?template=E804'  # C/S 관리 home; its left menu 일반관리 > C/S carries the popup URL with the session token
class SessionStopped(OrderAutoError):pass

# E900 (C/S) measured 2026-10-19: #search_type 8=송장번호 · #keyword · #search · window.all_data replaced per query
# (order_cs e.g. "0,xx,tb,rm" carries "tb" when a 회수요청 exists) · grid #grid_order tr.jqgrow (5th td opens the detail)
# · detail #di_seq/#di_trans_no · C/S 이력 table.cs_list: title row [일시, 작업자, "회수요청 일반", pin, 미처리|완료] + content row.
CS_ROWS_JS='''()=>Array.isArray(window.all_data)?[window.all_data.map(r=>({pack:String(r.pack||''),orderId:String(r.order_id||''),orderCs:String(r.order_cs||'')}))]:null'''
CS_DETAIL_JS='''()=>Object.fromEntries(['di_seq','di_trans_no','di_order_id'].map(k=>[k,(document.getElementById(k)?.innerText||'').trim()]))'''
CS_LIST_JS=r'''()=>[...document.querySelectorAll('table.cs_list tr')].map(tr=>[...tr.children].map(td=>(td.innerText||'').replace(/\s+/g,' ').trim()))'''
def cs_flag_pickup(order_cs):
    """EzAdmin list flag: order_cs tokens contain "tb" (takeback) when the order has a 회수요청 C/S."""
    return 'tb' in {t.strip() for t in str(order_cs or '').split(',')}
def cs_pickup_entries(rows):
    """회수요청 entries from the C/S 이력 table rows (title row followed by one content row)."""
    out=[]
    for i,cells in enumerate(rows):
        if len(cells)>=3 and '회수요청' in cells[2]:
            content=rows[i+1][0] if i+1<len(rows) and len(rows[i+1])==1 else ''
            out.append({'at':cells[0],'worker':cells[1],'type':cells[2],'state':cells[-1] if len(cells)>=4 else '','content':content[:200]})
    return out
def cs_history_note(history):
    e=history['entries'][0]
    return (f"이지어드민 C/S 이력 {e['type']} {e['at']}"+(f" ({e['worker']}"+(f", {e['state']}" if e['state'] else '')+')' if e['worker'] else '')
            +(' · '+e['content'] if e['content'] else '')+' · 회수 접수가 이미 있어 접수하지 않았습니다.')

NAMES={'CJ':'대한통운','EPOST':'우체국택배'}
def pickup_carrier(number):return 'EPOST' if number.startswith('6') else 'CJ' if number.startswith('5') else 'UNKNOWN'
def compact(v):return re.sub(r'\s+','',str(v or ''))
def recipient_option(options,shop,carrier):
    exact=[x for x in options if compact(x['text'])==compact(shop)]
    tagged=[x for x in options if compact(x['text']) in {compact(shop)+'('+c+')' for c in (('우체국','우체국택배') if carrier=='EPOST' else ('대한통운','CJ대한통운'))}]
    choices=tagged or exact
    if len(choices)!=1:raise OrderAutoError('수신자 변경 실패')
    return choices[0]
def existing(s):return s['modify'] or s['delete'] or any(any(w in r.get('status','') for w in ('준비중','요청','접수')) for r in s['registrations'])
def verified_result(s,number,carrier,receiver,before):
    rows=[r for r in s['registrations'] if r not in before]
    if any(('우체국' not in r['carrier'] if carrier=='EPOST' else '대한통운' not in r['carrier']) for r in rows):return '택배사 잘못 접수'
    valid=[r for r in rows if any(w in r['status'] for w in ('준비중','요청')) and compact(r['receiver'])==compact(receiver) and re.search(r'\d{4}-\d{2}-\d{2}',r['at'])]
    if len(valid)==1 and invoice(s['original'])==number and s['date'] and s['modify'] and s['delete']:
        return '접수 완료'
    return '접수 실패'

class PickupFlow(Flow):
    def authenticated(self,page):
        if not super().authenticated(page):return False
        try:return 'danimstudio' in page.locator('body').inner_text().lower()
        except Exception:return False
    def ensure_login(self,account,initial=False):
        p=self.page if self.page and not self.page.is_closed() else self.context.new_page()
        self.navigate(p,INDEX);self.pause(.6)
        if self.authenticated(p):return
        if not initial:
            if self.relogged:raise OrderAutoError('재로그인 뒤 세션이 다시 끊겨 전체 회수접수를 중단했습니다.')
            self.relogged=True
        self.authenticate(p,account) # Existing keyboard typing, value checks, dialogs, one submission.
        if not self.authenticated(self.page):raise OrderAutoError('이지어드민 업체명 확인에 실패했습니다.')
    def snapshot(self,page):
        self.known_page(page)
        if urlsplit(page.url).path!='/popup35.htm' or 'template=EX00' not in page.url:raise OrderAutoError('회수 요청 화면이 아닙니다.')
        values={k:page.locator('#'+k).input_value().strip() for k in ('sender_name','sender_tel1','sender_tel2','sender_mobile1','sender_mobile2','sender_address','receiver_name','receiver_address','keyword2')}
        values.update(modify=page.locator('#takeback_modify').is_visible(),delete=page.locator('#takeback_del').is_visible(),submit=page.locator('#takeback_submit').is_visible(),
            original=page.locator('#takeback_org_trans_no').inner_text(),date=page.locator('#takeback_reg_date').inner_text(),
            kind=page.locator('input[name="takeback_ret_type"]:checked').get_attribute('value') if page.locator('input[name="takeback_ret_type"]:checked').count()==1 else '',
            settlement=page.locator('input[name="takeback_trans_who"]:checked').get_attribute('value') if page.locator('input[name="takeback_trans_who"]:checked').count()==1 else '')
        values['registrations']=page.locator('#grid2 tr.jqgrow').evaluate_all('rows=>rows.map(r=>{const t=n=>r.querySelector(`[aria-describedby="grid2_${n}"]`)?.innerText.trim()||"";return {status:t("str_reg_trans_corp"),carrier:t("trans_name"),receiver:t("recv_name"),at:t("reg_date")};})')
        values['orders']=page.locator('#grid1 tr.jqgrow').count()
        return values
    def open_e900(self,search_type='27'):
        """Menu route, as a person does it: C/S 관리(E804) → left bar 일반관리 > C/S (popup25 E900 with the session's _si). 최근세달."""
        page=self.context.new_page();self.page=page
        self.step='C/S 관리 메뉴 열기';self.navigate(page,E804);self.pause(.8)
        if urlsplit(page.url).hostname!='ga79.ezadmin.co.kr' or page.locator('#login-pwd:visible').count():
            self.ensure_login(self.account);page.close();page=self.context.new_page();self.page=page;self.navigate(page,E804);self.pause(.8)
        self.known_page(page)
        link=page.locator('a[onclick*="template=E900"]')
        self.until(lambda:link.count()>=1,20,'C/S 관리 화면에서 일반관리 > C/S 메뉴를 찾지 못했습니다.')
        m=re.search(r'popup25\.htm\?template=E900&_si=([A-Za-z0-9]+)',link.first.get_attribute('onclick') or '')
        self.step='일반관리 > C/S 열기'
        if m:
            cs=self.context.new_page();self.page=cs;self.navigate(cs,f'https://ga79.ezadmin.co.kr/popup25.htm?template=E900&_si={m[1]}')
        else:
            # No token in the menu markup: click the menu and take the popup it opens.
            with self.context.expect_page(timeout=20000) as popup:
                link.first.click(timeout=10000)
            cs=popup.value;self.page=cs
            try:cs.wait_for_load_state('domcontentloaded',timeout=20000)
            except Exception:pass
        self.pause(.8);self.known_page(cs)
        self.until(lambda:cs.locator('#search_type').count()==1 and cs.locator('#date_period_sel').count()==1 and cs.locator('#keyword').count()==1,25,'이지어드민 C/S(E900) 검색 화면을 열지 못했습니다.')
        self.step='C/S 조회 조건 설정'
        cs.locator('#date_period_sel').select_option('9')  # 최근세달
        self.pause(.5)
        start=cs.locator('#start_date').input_value().strip();end=cs.locator('#end_date').input_value().strip()
        if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',start) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',end) or start>=end:raise OrderAutoError('C/S 조회 기간(최근세달)이 설정되지 않았습니다.')
        cs.locator('#search_type').select_option(search_type)
        try:page.close()
        except Exception:pass
        return cs
    def cs_pickup_history(self,cs,invoice):
        """E900: search the original tracking number (송장번호) and read each order's C/S 이력 for 회수요청 entries."""
        self.c.check();self.known_page(cs)
        if cs.locator('#search_type').input_value()!='8':cs.locator('#search_type').select_option('8')
        kw=cs.locator('#keyword');kw.fill('');kw.fill(invoice)
        if kw.input_value()!=invoice:raise OrderAutoError('송장번호 입력을 확인하지 못했습니다.')
        cs.evaluate('()=>{window.all_data=null;}')
        cs.locator('#search').click(timeout=10000)
        rows=self.until(lambda:cs.evaluate(CS_ROWS_JS),25,'C/S 조회 결과를 받지 못했습니다.')[0]
        self.pause(.4)
        entries=[];flagged=False;trs=cs.locator('#grid_order tr.jqgrow')
        for i in range(min(trs.count(),len(rows))):
            self.c.check();flagged=flagged or cs_flag_pickup(rows[i]['orderCs'])
            trs.nth(i).locator('td').nth(4).click(timeout=10000)
            pack=rows[i]['pack']
            self.until(lambda:(v if (v:=cs.evaluate(CS_DETAIL_JS)).get('di_seq','').strip()==pack and invoice in v.get('di_trans_no','') else False),20,f'관리번호 {pack} 상세가 열리지 않았습니다.')
            self.pause(.4);entries+=cs_pickup_entries(cs.evaluate(CS_LIST_JS))
        return {'entries':entries,'flagged':flagged,'orders':len(rows)}
    def one(self,row,shop,inspect_only=False):
        page=self.context.new_page();self.page=page
        result={**row,'carrier':NAMES.get(pickup_carrier(row['invoice']),'미확인'),'receiver':'','result':'조회 실패','acceptedAt':'','note':''}
        try:
            if row.get('preflightIssue'):result.update(result='고객정보 불일치',note=row['preflightIssue']);return result
            self.navigate(page,EX00);self.pause(.5)
            if urlsplit(page.url).hostname!='ga79.ezadmin.co.kr' or page.locator('#login-pwd:visible').count():
                self.context.remove_listener('dialog',self.pickup_notice)
                try:self.ensure_login(self.account)
                except Exception as exc:raise SessionStopped('재로그인에 실패하여 전체 회수접수를 중단했습니다.') from exc
                finally:self.context.on('dialog',self.pickup_notice)
                page.close();page=self.context.new_page();self.navigate(page,EX00)
            self.known_page(page)
            search=page.locator('#keyword2');search.fill(row['invoice']);search.press('Enter')
            self.until(lambda:page.locator('#sender_name').input_value().strip() and page.locator('#grid1 tr.jqgrow').count(),20,'조회 실패')
            self.pause(.5);s=self.snapshot(page)
            mobile=s['sender_mobile1']+s['sender_mobile2'];tel=s['sender_tel1']+s['sender_tel2']
            result['customer']=s['sender_name'];result['items']=int(s['orders'] or 0)   # 2026-10-23: 원송장 하나에 묶인 상품 줄 수 (EX00 주문 목록)
            if not (s['orders'] and s['sender_name'] and (mobile or tel) and s['sender_address'] and invoice(s['keyword2'])==row['invoice']):return result
            if (row.get('customer') and compact(row['customer'])!=compact(s['sender_name'])) or (row.get('phone') and re.sub(r'\D','',row['phone']) not in (re.sub(r'\D','',mobile),re.sub(r'\D','',tel))):
                result['result']='고객정보 불일치';return result
            if existing(s):
                result.update(result='이미 접수됨',note='기존 '+(' / '.join(r['status']+' '+r['carrier']+' '+r['at'] for r in s['registrations']) or '수정·삭제 표시')+' · 중복 접수하지 않았습니다.')
                return result
            carrier=pickup_carrier(row['invoice'])
            if carrier=='UNKNOWN':result['result']='택배사 판정 불가';return result
            options=page.locator('#receiver_list option').evaluate_all('es=>es.map(e=>({value:e.value,text:e.textContent.trim()}))')
            try:target=recipient_option(options,shop,carrier)
            except OrderAutoError:result['result']='수신자 변경 실패';return result
            page.locator('#receiver_list').select_option(value=target['value']);self.pause(.5)
            s=self.snapshot(page);result['receiver']=s['receiver_name']
            selected=page.locator('#receiver_list option:checked').inner_text().strip()
            # Exact configured recipient plus nonempty populated address. Do not require a
            # change when this same correct recipient was already selected by the site.
            expected=re.sub(r'\((?:우체국택배|우체국|CJ대한통운|대한통운)\)$','',compact(target['text']))
            if selected!=target['text'] or compact(s['receiver_name']) not in (compact(target['text']),expected) or not s['receiver_address']:
                result['result']='수신자 변경 실패';return result
            if s['kind']!='04' or s['settlement']!='04':result.update(result='접수 실패',note='접수구분 회수 / 정산구분 착지신용 기본값이 아닙니다.');return result
            if inspect_only:result.update(result='접수 전 확인',note='고객·수신자·기본값 확인 완료. 접수 버튼을 누르면 다시 대조 후 신청합니다.',eligible=True);return result
            self.c.check();s2=self.snapshot(page)
            if s2!=s:result.update(result='접수 실패',note='접수 직전 화면이 바뀌었습니다.');return result
            button=page.locator('#takeback_submit')
            if not s2['submit'] or button.inner_text().strip()!='반품접수':return result
            self.c.before_submit(row['invoice']) # Durable unknown-outcome claim BEFORE the click.
            self.confirming=True
            try:button.click(timeout=10000);self.pause(3)
            finally:self.confirming=False
            after=self.snapshot(page);result['result']=verified_result(after,row['invoice'],carrier,s['receiver_name'],s['registrations'])
            new_rows=[r for r in after['registrations'] if r not in s['registrations']]
            result['acceptedAt']=new_rows[0]['at'] if len(new_rows)==1 else after['date'].strip()
            if result['result']=='접수 실패':result['note']='접수 결과 미확인 · 사이트에서 확인하세요. 자동 재클릭하지 않았습니다.'
            return result
        except (Cancelled,SessionStopped):raise
        except Exception:
            if self.c.pending:result['result']='접수 실패'
            result['note']='접수 결과 미확인 · 사이트에서 확인하세요.' if self.c.pending else '화면 또는 조회 정보를 확인하지 못했습니다. 접수하지 않았습니다.'
            return result
        finally:
            try:page.close()
            except Exception:pass
    def run(self,account,rows,shop,inspect_only):
        self.configure_pages();self.account=account;self.relogged=False;self.confirming=False
        self.ensure_login(account,initial=True)
        def notice(d):
            # Only the known pickup request confirmation is auto-accepted. Unknown
            # prompts/security questions stop the batch; never approve deletion.
            message=d.message
            if d.type=='confirm' and self.confirming and re.fullmatch(r'\s*(?:반품|회수)\s*(?:접수|요청)(?:를|을)?\s*(?:하시겠습니까|하시겠습니까\?|하겠습니까\?)\s*\??\s*',message):d.accept()
            elif d.type=='alert':d.dismiss()
            elif d.type=='confirm' and self.confirming and not re.search('삭제|취소|철회|환불',message):
                from order_browser import safe_login_notice
                accepted=False
                try:accepted=self.c.ask_login_confirmation('회수접수 확인: '+safe_login_notice(message,self.account))
                finally:
                    if accepted:d.accept()
                    else:d.dismiss();self.dialog_blocked=True
            else:
                d.dismiss();self.dialog_blocked=True
        self.pickup_notice=notice;self.dialog_blocked=False;self.context.on('dialog',notice)
        cs=None;cs_error=''
        if any(not r.get('preflightIssue') for r in rows):
            # Requested 2026-10-19: an order whose E900 C/S 이력 already holds a 회수요청 counts as picked up → skip EX00 for it.
            try:self.c.update('running','이지어드민 C/S에서 회수 이력을 확인합니다.');cs=self.open_e900('8')
            except (Cancelled,SessionStopped):raise
            except Exception as exc:cs_error=str(exc) if isinstance(exc,OrderAutoError) else 'C/S 화면을 열지 못했습니다.'
        try:
            for row in rows:
                self.c.check();self.c.update('running','원송장 '+row['invoice']+' · 회수 정보 확인 중')
                note='';history=None
                if cs is not None and not row.get('preflightIssue'):
                    self.c.update('running','원송장 '+row['invoice']+' · 이지어드민 C/S 회수 이력 확인 중')
                    try:history=self.cs_pickup_history(cs,row['invoice'])
                    except (Cancelled,SessionStopped):raise
                    except Exception as exc:note='C/S 이력 확인 실패 · '+(str(exc) if isinstance(exc,OrderAutoError) else '화면을 읽지 못했습니다.')
                elif cs_error and not row.get('preflightIssue'):note='C/S 이력 미확인 · '+cs_error
                if history and history['entries']:
                    result={**row,'carrier':NAMES.get(pickup_carrier(row['invoice']),'미확인'),'receiver':'','result':'이미 접수됨','acceptedAt':history['entries'][0]['at'],'note':cs_history_note(history),'csHistory':True}
                    self.c.record(result,inspect_only);continue
                result=self.one(row,shop,inspect_only)
                if note:result['note']=(note+(' · '+result['note'] if result.get('note') else ''))
                self.c.record(result,inspect_only)
                if result['result']=='택배사 잘못 접수':raise OrderAutoError('택배사가 다르게 접수되었습니다. 결과를 확인하세요. 삭제하거나 계속 접수하지 않았습니다.')
                if self.dialog_blocked:raise OrderAutoError('추가 확인이 필요하여 회수접수를 중단했습니다.')
        finally:
            self.context.remove_listener('dialog',notice)
            if cs is not None:
                try:cs.close()
                except Exception:pass

def run_pickups(controller,rows,shop,inspect_only=False):
    from playwright.sync_api import sync_playwright
    account=controller.login_account()
    try:
        with sync_playwright() as pw:
            import browser_window as _bw;browser=pw.chromium.launch(**_bw.launch_kwargs())
            context=browser.new_context(viewport={'width':1280,'height':800},device_scale_factor=1,accept_downloads=False)
            import browser_window;browser_window.attach(context)
            flow=PickupFlow(controller,context)
            try:flow.run(account,rows,shop,inspect_only)
            except Exception as exc:
                msg=flow.failure_message(exc,account);flow.clear_password()
                # No automatic retry. Existing confirmation handling remains responsive.
                try:flow.keep_failure_open(msg,can_continue=False)
                except Exception:pass
                raise OrderAutoError(msg) from None
            finally:context.close();browser.close()
    finally:account.clear()
