"""Local Chinese color labels for manual review, never stock identities or auto matching."""
import re
from workbook_reader import text

# 卡其 follows this shop's explicit convention: beige, not Korean khaki/green.
# Exact whole-label lookup prevents guessing from a substring of an unknown shade.
CHINESE_COLORS={
    '卡其':'베이지','卡其色':'베이지','浅卡其':'라이트베이지','浅卡其色':'라이트베이지',
    '淺卡其':'라이트베이지','淺卡其色':'라이트베이지','深卡其':'다크베이지','深卡其色':'다크베이지',
    '米色':'베이지','米白':'아이보리','米白色':'아이보리','奶白':'아이보리','奶白色':'아이보리',
    '奶油色':'크림','杏色':'살구',
    '黑':'블랙','黑色':'블랙','白':'화이트','白色':'화이트',
    '灰':'그레이','灰色':'그레이','深灰':'다크그레이','深灰色':'다크그레이',
    '浅灰':'라이트그레이','浅灰色':'라이트그레이','淺灰':'라이트그레이','淺灰色':'라이트그레이',
    '棕色':'브라운','咖啡':'브라운','咖啡色':'브라운','咖色':'브라운',
    '深咖':'다크브라운','深咖色':'다크브라운','深棕':'다크브라운','深棕色':'다크브라운',
    '浅咖':'라이트브라운','浅咖色':'라이트브라운','浅棕':'라이트브라운','浅棕色':'라이트브라운',
    '蓝色':'블루','藍色':'블루','藏青':'네이비','藏青色':'네이비',
    '深蓝':'다크블루','深蓝色':'다크블루','深藍色':'다크블루',
    '浅蓝':'라이트블루','浅蓝色':'라이트블루','淺藍色':'라이트블루',
    '天蓝':'스카이블루','天蓝色':'스카이블루','天藍色':'스카이블루',
    '绿色':'그린','綠色':'그린','军绿':'카키','军绿色':'카키','軍綠色':'카키',
    '墨绿':'다크그린','墨绿色':'다크그린','墨綠色':'다크그린',
    '深绿':'다크그린','深绿色':'다크그린','深綠色':'다크그린',
    '浅绿':'라이트그린','浅绿色':'라이트그린','淺綠色':'라이트그린',
    '粉色':'핑크','粉红色':'핑크','粉紅色':'핑크','浅粉':'라이트핑크','浅粉色':'라이트핑크',
    '红色':'레드','紅色':'레드','酒红':'버건디','酒红色':'버건디','酒紅色':'버건디',
    '黄色':'옐로우','黃色':'옐로우','紫色':'퍼플','橙色':'오렌지',
}
CHINESE_RE=re.compile(r'[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]')

def color_label(value):
    raw=text(value);has_chinese=bool(CHINESE_RE.search(raw))
    result={'label':raw,'hasChinese':has_chinese,'translated':False,'needsReview':False}
    if not has_chinese:return result
    korean=''.join(re.findall(r'[가-힣]+',raw))
    if korean:
        # Existing Korean annotations take precedence, as in 深灰色 다크그레이17.
        return result|{'label':korean}
    compact=re.sub(r'[\W\d_]','',raw)
    compact=re.sub(r'^(?:颜色|顏色|色号|色號)','',compact)
    translated=CHINESE_COLORS.get(compact)
    return result|{'label':translated or '번역 확인 필요','translated':bool(translated),'needsReview':not bool(translated)}
