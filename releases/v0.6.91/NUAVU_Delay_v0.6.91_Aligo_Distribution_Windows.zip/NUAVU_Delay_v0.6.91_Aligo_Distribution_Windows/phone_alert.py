"""아이폰 알림 (아이메시지) — 2026-10-23 요청.

문제(빨간·확인 필요) 알림이 새로 저장될 때만 사장님 아이폰으로 아이메시지를 보낸다. 정상 완료(초록) 알림은 보내지 않는다.
- 연결 지점: 앱 알림을 저장하는 코드(Engine.add_alert · Engine.add_job_alert)가 저장 직후 offer(알림) 하나만 부른다.
- 보내는 내용: "[누아브 배송안내] {제목}\\n{내용 앞 300자}"
- 같은 알림은 한 번만: 발송 알림은 앱의 중복 키(noticeId+code) 그대로, 작업 알림(막힘)은 앱에 중복 키가 없어서
  제목+내용이 같으면 6시간 안에는 다시 보내지 않는다.
- 한 시간에 최대 20통 (넘치면 버림). 보내기는 백그라운드 스레드. 실패해도 앱은 계속 돌고, 오류 로그와 설정 줄에만 이유를 남긴다.
- Mac: '메시지' 앱(osascript). Windows: 아이메시지 불가 → 설정 줄 회색.
- 설정: 앱 상태 폴더의 phone_alert.json = {"enabled":bool,"to":"..."} · 보낸 기록: phone_alert_state.json
"""
from __future__ import annotations
import hashlib,json,os,queue,re,subprocess,sys,threading,time
from datetime import datetime,timezone
from pathlib import Path

PREFIX='[누아브 배송안내]'
TEST_TEXT=PREFIX+' 아이폰 알림 시험입니다. 앞으로 문제(빨간 알림)가 생기면 이렇게 보냅니다.'
MAX_PER_HOUR=20
JOB_REPEAT_SECONDS=6*3600
KEEP_KEYS_SECONDS=7*86400
SKIP_CODES={'RESULT_UNCONFIRMED_15S'}   # 15초 1차 미확인은 곧 다시 확인하는 중간 상태라 보내지 않는다 (1분 미확인은 보냄)
CODE_TITLES={'RESULT_UNCONFIRMED_1M':'1분 결과 미확인','RESULT_UNCONFIRMED_25H':'결과 미확인','DELIVERY_FAILED':'전송 실패 확정'}
SCRIPT='''on run argv
  set target to item 1 of argv
  set msg to item 2 of argv
  tell application "Messages"
    set svc to 1st account whose service type = iMessage
    try
      send msg to participant target of svc
    on error
      send msg to buddy target of svc
    end try
  end tell
  return "ok"
end run'''
AUTOMATION_HELP='맥 설정 › 개인정보 보호 및 보안 › 자동화에서 허용해 주세요'

class PhoneAlertError(ValueError):pass

def supported(platform=None):return (platform or sys.platform)=='darwin'

def normalize_to(raw):
    """010-1234-5678 → +821012345678 · Apple ID 이메일은 그대로(소문자). 9자리 미만 거부."""
    s=str(raw or '').strip()
    if not s:return ''
    if '@' in s:
        if not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',s):raise PhoneAlertError('받는 곳 이메일 형식을 확인하세요.')
        return s.lower()
    digits=re.sub(r'\D','',s)
    if len(digits)<9:raise PhoneAlertError('받는 곳은 010 번호 또는 Apple ID 이메일을 입력하세요 (9자리 미만).')
    if s.startswith('+'):return '+'+digits
    if digits.startswith('82'):return '+'+digits
    if digits.startswith('0'):return '+82'+digits[1:]
    return digits

def is_problem(a):
    if not isinstance(a,dict):return False
    if a.get('job'):return a.get('level')=='error'
    return a.get('level') in ('error','warning') and a.get('code') not in SKIP_CODES

def alert_key(a):
    if a.get('job'):return 'J:'+hashlib.sha1((str(a.get('title',''))+'|'+str(a.get('message',''))).encode('utf-8')).hexdigest()
    return 'N:'+str(a.get('noticeId',''))+':'+str(a.get('code',''))

def text_of(a):
    title=a.get('title') or CODE_TITLES.get(a.get('code')) or ('전송 실패' if a.get('level')=='error' else '확인 필요')
    return f'{PREFIX} {title}\n{str(a.get("message",""))[:300]}'

def mac_send(to,text,timeout=40):
    try:r=subprocess.run(['/usr/bin/osascript','-e',SCRIPT,to,text],capture_output=True,text=True,timeout=timeout)
    except subprocess.TimeoutExpired:raise PhoneAlertError('메시지 앱이 응답하지 않습니다 (40초).')
    except FileNotFoundError:raise PhoneAlertError('이 컴퓨터에서 메시지 앱을 실행할 수 없습니다.')
    out=(r.stdout or '')+(r.stderr or '')
    if r.returncode!=0 or 'ok' not in (r.stdout or ''):
        if '-1743' in out or 'Not authorized' in out:raise PhoneAlertError('메시지 앱 제어 권한이 없습니다. '+AUTOMATION_HELP)
        line=(r.stderr or r.stdout or '').strip().splitlines()
        raise PhoneAlertError('아이메시지 보내기 실패'+(' · '+line[-1][:160] if line else '')+' (맥 메시지 앱에 Apple ID 로그인 확인)')

class PhoneAlerts:
    def __init__(self,directory,exists=None,on_error=None,sender=None,platform=None,clock=time.time,delay=1.5):
        self.dir=Path(directory);self.exists=exists;self.on_error=on_error;self.sender=sender or mac_send
        self.platform=platform or sys.platform;self.clock=clock;self.delay=delay
        self.lock=threading.RLock();self.q=queue.Queue();self.thread=None
    # ---- files
    def _read(self,name,default):
        try:
            v=json.loads((self.dir/name).read_text(encoding='utf-8'))
            return v if isinstance(v,dict) else default
        except Exception:return default
    def _write(self,name,data):
        p=self.dir/name;tmp=p.with_suffix('.tmp')
        tmp.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
        try:os.chmod(tmp,0o600)
        except Exception:pass
        os.replace(tmp,p)
    def config(self):
        c=self._read('phone_alert.json',{});return {'enabled':bool(c.get('enabled')),'to':str(c.get('to') or '')}
    def status(self):
        c=self.config();st=self._read('phone_alert_state.json',{});now=self.clock()
        return {**c,'supported':supported(self.platform),'unsupportedReason':'' if supported(self.platform) else '아이메시지는 Mac 버전에서만 됩니다',
                'last':st.get('last') or {},'sentLastHour':len([t for t in st.get('window',[]) if now-t<3600]),'maxPerHour':MAX_PER_HOUR}
    def save(self,enabled,to):
        to=normalize_to(to)
        if enabled and not to:raise PhoneAlertError('받는 곳(010 번호 또는 Apple ID 이메일)을 먼저 입력하세요.')
        if enabled and not supported(self.platform):raise PhoneAlertError('아이메시지는 Mac 버전에서만 됩니다.')
        with self.lock:self._write('phone_alert.json',{'enabled':bool(enabled),'to':to})
        return self.status()
    # ---- sending
    def _record(self,ok,error='',kind='alert'):
        with self.lock:
            st=self._read('phone_alert_state.json',{})
            st['last']={'at':datetime.now(timezone.utc).isoformat(timespec='seconds'),'ok':bool(ok),'error':str(error)[:300],'kind':kind}
            self._write('phone_alert_state.json',st)
        if not ok and self.on_error:
            try:self.on_error('아이폰 알림 보내기 실패',str(error)[:500],'')
            except Exception:pass
    def send_test(self,to=None):
        """'시험 보내기' — 바로 1통 (중복·시간당 제한과 상관없이). 화면을 멈추지 않도록 호출한 쪽 스레드에서 짧게 끝난다."""
        target=normalize_to(to) if to else self.config()['to']
        if not target:raise PhoneAlertError('받는 곳(010 번호 또는 Apple ID 이메일)을 먼저 입력하세요.')
        if not supported(self.platform):raise PhoneAlertError('아이메시지는 Mac 버전에서만 됩니다.')
        try:self.sender(target,TEST_TEXT)
        except Exception as exc:
            self._record(False,str(exc),'test');raise PhoneAlertError(str(exc) if isinstance(exc,PhoneAlertError) else f'시험 보내기 실패 · {type(exc).__name__}') from exc
        self._record(True,'','test');return self.status()
    def offer(self,alert):
        """Called right after an app alert is stored. Never raises, never blocks."""
        try:
            if not is_problem(alert):return
            c=self.config()
            if not c['enabled'] or not c['to'] or not supported(self.platform):return
            self.q.put(dict(alert))
            with self.lock:
                if not (self.thread and self.thread.is_alive()):
                    self.thread=threading.Thread(target=self._worker,daemon=True,name='phone-alert');self.thread.start()
        except Exception:pass
    def _worker(self):
        while True:
            try:a=self.q.get(timeout=60)
            except queue.Empty:return
            try:self.process(a)
            except Exception:pass
    def process(self,a):
        if not is_problem(a):return
        if self.delay:time.sleep(self.delay)   # the alert's store transaction finishes first
        if self.exists and a.get('id') and not self.exists(a['id']):return   # rolled back → never sent
        c=self.config()
        if not c['enabled'] or not c['to']:return
        now=self.clock();key=alert_key(a)
        with self.lock:
            st=self._read('phone_alert_state.json',{})
            sent={k:v for k,v in (st.get('sent') or {}).items() if now-v<KEEP_KEYS_SECONDS}
            window=[t for t in (st.get('window') or []) if now-t<3600]
            if key in sent and (not a.get('job') or now-sent[key]<JOB_REPEAT_SECONDS):return
            if len(window)>=MAX_PER_HOUR:
                st.update(sent=sent,window=window,dropped=int(st.get('dropped',0))+1);self._write('phone_alert_state.json',st);return
            sent[key]=now;window.append(now);st.update(sent=sent,window=window);self._write('phone_alert_state.json',st)
        try:self.sender(c['to'],text_of(a));self._record(True)
        except Exception as exc:self._record(False,str(exc) if isinstance(exc,PhoneAlertError) else f'{type(exc).__name__}: {exc}')

_active=None
def install(notifier):
    global _active;_active=notifier;return notifier
def active():return _active
def offer(alert):
    n=_active
    if n is not None:n.offer(alert)

def for_engine(engine):
    """The process-wide notifier bound to this engine's state folder (created on first use)."""
    n=_active
    if n is None or n.dir!=Path(engine.store.directory):
        def exists(aid):
            try:return any(a.get('id')==aid for a in engine.store.read().get('alerts',[]))
            except Exception:return True
        n=install(PhoneAlerts(engine.store.directory,exists=exists,on_error=getattr(engine,'record_error',None)))
    return n

def settings_action(engine,p):
    """POST /api/phone-alert: {action:'status'|'save'|'test', enabled, to}."""
    n=for_engine(engine);act=(p or {}).get('action','status')
    try:
        if act=='status':return n.status()
        if act=='save':
            r=n.save(bool(p.get('enabled')),p.get('to',''))
            return {**r,'message':('아이폰 알림을 켰습니다 · 받는 곳 '+r['to']) if r['enabled'] else '아이폰 알림을 껐습니다.'}
        if act=='test':
            r=n.send_test(p.get('to') or None)
            return {**r,'message':'시험 아이메시지를 보냈습니다. 아이폰에서 확인하세요.'}
    except PhoneAlertError as exc:return {**n.status(),'error':str(exc)}
    return {**n.status(),'error':'알 수 없는 요청입니다.'}
