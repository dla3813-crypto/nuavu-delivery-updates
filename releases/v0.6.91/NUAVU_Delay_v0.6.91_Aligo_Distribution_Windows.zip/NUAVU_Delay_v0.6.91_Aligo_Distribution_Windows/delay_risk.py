"""Read-only early delay classification from promised dates and FIFO supply.

No allocation, notice, mapping or persisted order is changed here.
"""
from datetime import date, datetime, timedelta, timezone
from supply_calendar import route

KST = timezone(timedelta(hours=9))
CUTOFF_HOUR = 16  # 확정 검토일 당일 오후 4시까지 감시, 그 뒤에도 부족하면 갱신 자료 없이 확정
def clock():
    """KST wall clock, read through domain so tests that patch domain.datetime steer it."""
    import domain
    return domain.datetime.now(KST)
def past_cutoff(today,confirm_day):
    """True once the watch deadline has passed: any day after the confirm day, or the confirm day from 16:00 KST."""
    if today>confirm_day:return True
    if today<confirm_day:return False
    try:return clock().hour>=CUTOFF_HOUR
    except Exception:return False


def parse_day(value):
    if not isinstance(value, str) or len(value) != 10:
        return None
    try:
        result = date.fromisoformat(value)
        return result if result.isoformat() == value else None
    except ValueError:
        return None


def read_day(value):
    try:
        clock = datetime.fromisoformat(value)
        if clock.tzinfo is None:
            clock = clock.replace(tzinfo=KST)
        return clock.astimezone(KST).date()
    except (ValueError, TypeError):
        return None


def risk_window(due, holidays=()):
    """Latest Tue/Sat wave that could reach domestic dispatch by the promise.

    Use the FIRST domestic date: the user's Wed promise intentionally includes
    the Sat wave whose existing dispatch interval is Wed–Thu.
    Sat: Thu watch / Mon confirm. Tue: Mon watch / Wed confirm.
    """
    due = parse_day(due)
    if due is None:
        return None
    for offset in range(371):
        try:
            ship = due - timedelta(days=offset)
        except OverflowError:
            return None
        if ship.weekday() not in (1, 5):
            continue
        path = route(ship, holidays, departure=ship)
        if path and path['koreaStart'] <= due.isoformat():
            saturday = ship.weekday() == 5
            return dict(chinaDate=ship.isoformat(),
                        watchDate=(ship-timedelta(days=2 if saturday else 1)).isoformat(),
                        confirmDate=(ship+timedelta(days=2 if saturday else 1)).isoformat(),
                        dispatchStart=path['koreaStart'], dispatchEnd=path['koreaEnd'])
    return None


def supply_ready(supply):
    if not read_day(supply.get('lastReadAt')):
        return False
    scan = supply.get('lastScan', {})
    if 'files' in scan:
        return any(f.get('selectedRows', 0) > 0 for f in scan['files'])
    # Compatibility with older saved supply data, before scan metadata existed.
    brands = supply.get('brands', [])
    rows = list(supply.get('progress', []))
    rows += [r for b in supply.get('manifests', {}).values() for r in b['rows']]
    return any(r['brand'] in brands for r in rows)


def assess_risk(row, info, as_of, supply, window):
    """Use only quantities already assigned to this order by allocation_view."""
    result = dict(stage='',reason='',dueDate=row.get('dueDate',''),
                  watchDate='',confirmDate='',chinaDate='',
                  requiredQty=row.get('qty',0),coveredQty=0,shortQty=0,
                  manifestQty=0,progressQty=0,lateQty=0,futureQty=0,
                  needsRefresh=False,needsCalendar=False,
                  matchNeeded=bool(info.get('matchNeeded')),
                  lastReadAt=supply.get('lastReadAt',''))
    today = parse_day(as_of)
    due = parse_day(row.get('dueDate'))
    if (not row.get('active') or row.get('soldoutNotified') or row.get('review')
            or not today or not due or due < today or not window):
        return result
    result.update(window)
    if not supply_ready(supply):
        result['reason'] = '선택 브랜드의 공급 자료를 수동갱신하세요.'
        result['needsRefresh'] = True
        return result
    remaining = max(0, int(row.get('qty', 0)))
    for part in info.get('parts', []):
        amount = min(remaining, max(0, int(part.get('allocated', 0))))
        path = part.get('path', {})
        first = parse_day(path.get('koreaStart'))
        observed = parse_day(path.get('chinaDate') if part.get('kind') == 'manifest'
                             else path.get('basisDate'))
        if part.get('kind') not in ('manifest', 'progress') or not first or not observed:
            continue
        if first > due:
            result['lateQty'] += amount
        elif observed > today:
            result['futureQty'] += amount
        else:
            result['manifestQty' if part['kind']=='manifest' else 'progressQty'] += amount
            result['coveredQty'] += amount
            remaining -= amount
    result['shortQty'] = max(0, row['qty']-result['coveredQty'])
    if not result['shortQty'] or as_of < window['watchDate']:
        return result
    known = set(supply.get('confirmedCalendarYears', [2026]))
    years = {int(d[:4]) for d in (row['dueDate'],window['chinaDate'],
                                  window['dispatchStart'],window['dispatchEnd'])}
    result['needsCalendar'] = not years.issubset(known)
    checked = read_day(supply.get('lastReadAt'))
    confirmation = parse_day(window['confirmDate'])
    result['needsRefresh'] = today >= confirmation and not (checked and confirmation <= checked <= today)
    deadline = past_cutoff(today, confirmation)
    result['deadlinePassed'] = bool(deadline)
    result['cutoff'] = window['confirmDate'] + ' 16:00'
    result['stage'] = ('confirmed' if today >= confirmation and (not result['needsRefresh'] or deadline)
                       and not result['needsCalendar'] else 'watch')
    reason = f"주문 {row['qty']}개 중 기한 내 도착 근거 {result['coveredQty']}개 · {result['shortQty']}개 부족"
    if result['lateQty']:
        reason += f" · 기한 이후 예상 물량 {result['lateQty']}개"
    if result['futureQty']:
        reason += f" · 도착일 전 물량 {result['futureQty']}개"
    if result['matchNeeded']:
        reason += ' · 상품 연결 확인 필요'
    if result['needsRefresh'] and not deadline:
        reason += ' · 확정 기준일 이후 자료 갱신 필요 (당일 오후 4시 마감)'
    elif result['needsRefresh'] and deadline:
        reason += ' · 오후 4시 마감 경과 · 갱신 자료 없이 확정'
    if result['stage'] == 'watch' and today == confirmation:
        reason += ' · 감시 (당일 오후 4시 마감)'
    if result['needsCalendar']:
        reason += ' · 해당 연도 휴일 확인 필요'
    result['reason'] = reason
    return result


def decorate_risks(state, supply):
    """Re-evaluate the clock outside cached allocations, including midnight."""
    windows = {}
    summary = dict(watch=0,confirmed=0,watchShortQty=0,confirmedShortQty=0,
                   dataReady=supply_ready(supply),lastReadAt=supply.get('lastReadAt',''))
    for row in state['rows']:
        due = row.get('dueDate','')
        if due not in windows:
            windows[due] = risk_window(due, supply.get('holidays', []))
        risk = assess_risk(row,row.get('supplyInfo',{}),state['today'],supply,windows[due])
        row['delayRisk'] = risk
        stage = risk['stage']
        if stage:
            summary[stage] += 1
            summary[stage+'ShortQty'] += risk['shortQty']
    state['delayRiskSummary'] = summary
    return state
