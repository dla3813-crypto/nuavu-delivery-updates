"""품절 안내 문자 → 주문 취소 접수 (2026-10-20 06:05 설명서, 공통). soldout_display 와 같은 배치에서, 옵션 OFF 다음에 돈다.

자사몰(카페24, 키체인 계정 있을 때만):
 · 주문상세 /admin/php/s_new/order_detail.php?order_id=<주문번호>&menu_no=72 에서 결제수단(무통장입금·가상계좌·신용카드…)을 읽고
 · 취소 처리 /admin/php/s_new/order_cancel_list.php?order_id=<주문번호>&menu_no=72 에서 해당 품목(om_no = 앱 상세주문번호의 '_' 뒤 번호) 체크 → 취소접수(#eCancelAccept)
 · 2단계: 구분 select[name=cs_type]=품절(H). 무통장·가상계좌는 현금 환불 — 환불은행 농협중앙회, 계좌번호 123, 예금주 123 (설명서 값) → 확인(#eSubmit) → do_order_cancel_result.php(alert)
   신용카드는 환불방식 그대로 두고 확인 → 주문상세로 돌아와 전체 취소면 `신용카드 전체취소`(#eCardCancel), 일부면 `신용카드 부분취소`(#eCardPartCancelNoItemNotification).
 · 실측 2026-10-20 06:10: 무통장 건 20261018-0000029 이 절차로 취소(취소 1건·환불 1건·취소번호 C2026…). 신용카드 건은 실행 전 중단 → 카드 단계는 설명서 기준(미실측).
에이블리:
 · 발송 관리 https://my.a-bly.com/sales/order/send?entry_point=dashboard&ably_global_tab=default&keyword_type=sno&keyword=<상품주문번호> (상세조건 상품주문번호 검색과 같은 주소)
 · 1~10초 안에 그 상품주문번호 행이 정확히 1건 떠야 함(없으면 오류) → 행 체크 → `주문취소 접수 처리` → .el-dialog '주문취소 접수 처리':
   해당 행 체크, 판매자 귀책 사유 `상품 품절` 라디오, 구매 고객 안내 여부 `확인` 체크 → `선택 항목 주문취소 접수 처리` → 목록에서 사라지면(총 0건) 완료.
 · 실측 2026-10-20 06:20: 663715463 이 절차로 접수 완료.
"""
from __future__ import annotations
import re,time
from datetime import datetime,timezone
from urllib.parse import quote
from soldout_display import DisplayError,DisplayCancelled,Cafe24Flow

ABLY_ORDERS='https://my.a-bly.com/sales/order/send?entry_point=dashboard&ably_global_tab=default'
CAFE_BANK='농협중앙회';CAFE_ACC='123';CAFE_DEPOSITOR='123'

def split_cafe_item(order_item_id,order_id=''):
    """'20261018-0000029_1456' → ('20261018-0000029','1456'); falls back to the plain order id."""
    for value in (order_item_id,order_id):
        m=re.fullmatch(r'\s*(\d{8}-\d{7})(?:[-_](\d{1,2}))?_(\d+)\s*',str(value or ''))
        if m:return m.group(1),m.group(3)
    m=re.fullmatch(r'\s*(\d{8}-\d{7})(?:-\d{2})?\s*',str(order_item_id or order_id or ''))
    return (m.group(1) if m else str(order_id or '').strip()),''

def cancel_targets(items):
    """Rows of a 품절 안내 → cancel targets. 에이블리 needs the 상품주문번호; 자사몰 needs the order id (+ om_no)."""
    out=[];seen=set()
    for it in items:
        n0=len(out)
        _cancel_target(it,out,seen)
        for t in out[n0:]:
            for k in ('rowKey','sendAt'):
                if it.get(k):t[k]=it[k]
    return out

def _cancel_target(it,out,seen):
    if True:
        seller=str(it.get('seller',''));oid=str(it.get('orderId','')).strip();iid=str(it.get('orderItemId') or it.get('itemId') or '').strip()
        if '에이블리' in seller or 'ably' in seller.lower():
            if not re.fullmatch(r'\d{6,}',iid):return
            key=('ably',iid)
            if key in seen:return
            seen.add(key);out.append({'platform':'ably','sno':iid,'orderId':oid,'product':it.get('product',''),'option':it.get('option','')})
        elif '지그재그' in seller or 'zigzag' in seller.lower():
            # 2026-10-22: 지그재그는 주문번호(필수) + 상품주문번호(있으면 그 행만). 한 주문씩 '판매자 직접 취소'.
            if not re.fullmatch(r'\d{8,}',oid):return
            zid=iid if re.fullmatch(r'\d{8,}',iid) and iid!=oid else ''
            key=('zigzag',oid,zid)
            if key in seen:return
            seen.add(key);out.append({'platform':'zigzag','orderId':oid,'itemId':zid,'product':it.get('product',''),'option':it.get('option','')})
        elif '자사몰' in seller or 'cafe' in seller.lower():
            order_id,om=split_cafe_item(iid,oid)
            if not order_id:return
            key=('cafe24',order_id,om)
            if key in seen:return
            seen.add(key);out.append({'platform':'cafe24','orderId':order_id,'omNo':om,'product':it.get('product',''),'option':it.get('option','')})
# ---------------------------------------------------------------- 카페24
CAFE_DETAIL_JS='''()=>{const t=document.body.innerText;const th=[...document.querySelectorAll('th')].find(e=>e.innerText.trim()==='결제수단');const pay=(th&&th.nextElementSibling?th.nextElementSibling.innerText:(t.match(/결제수단\\t?\\s*([^\\t\\n]{0,40})/)||['',''])[1]).trim();
 const items=[...document.querySelectorAll('tr')].filter(tr=>/\\d{8}-\\d{7}-\\d{2}/.test(tr.innerText)&&tr.querySelector('input[name^="om_no"]')).map(tr=>({om:(tr.querySelector('input[name^="om_no"]')||{}).value||'',text:tr.innerText.replace(/\\s+/g,' ').slice(0,160),cancelled:/\\(C\\d{8}-\\d{7}\\)/.test(tr.innerText)}));
 const tabs=[...document.querySelectorAll('a,button')].map(e=>(e.innerText||'').replace(/\\s+/g,' ').trim()).filter(x=>/^(주문내역|취소|환불)\\(\\d+건\\)$/.test(x));
 return {pay,items,tabs,card:{full:!!document.querySelector('#eCardCancel'),part:!!document.querySelector('#eCardPartCancelNoItemNotification')}}}'''
CAFE_CANCEL_TAB_JS='''(itemNo)=>{const tab=[...document.querySelectorAll('a,button')].find(e=>/^취소\\(\\d+건\\)$/.test((e.innerText||'').replace(/\\s+/g,' ').trim()));if(!tab)return {tab:'',rows:[]};tab.click();
 return new Promise(res=>setTimeout(()=>{const rows=[...document.querySelectorAll('table')].filter(t=>t.offsetParent!==null&&/취소처리|취소번호/.test(t.innerText)).flatMap(t=>[...t.querySelectorAll('tbody tr')]).map(r=>r.innerText.replace(/\\s+/g,' ').trim()).filter(x=>x.includes(itemNo));res({tab:tab.innerText.replace(/\\s+/g,' ').trim(),rows:rows.map(x=>x.slice(0,300))});},1500));}'''
CAFE_LAYER_JS='''()=>{const layers=[...document.querySelectorAll('.mLayer, div[id*="Layer"], div[class*="layer"]')].filter(e=>e.offsetParent!==null);if(!layers.length)return null;const l=layers[0];return {id:l.id,text:l.innerText.replace(/\\s+/g,' ').slice(0,200),buttons:[...l.querySelectorAll('a,button')].map(b=>({id:b.id,text:(b.innerText||'').replace(/\\s+/g,' ').trim()})).filter(b=>b.text)}}'''
CAFE_CANCEL_ROWS_JS='''()=>[...document.querySelectorAll('input[name^="om_no["]')].map(i=>({om:i.value,text:(i.closest('tr')||{innerText:''}).innerText.replace(/\\s+/g,' ').slice(0,140)}))'''

def card_done(row):
    """취소 탭 행의 환불내역 괄호: '(신용카드 취소 전)' → 미완료, '(신용카드 취소완료)' → 완료 (07:47 실측)."""
    return bool(re.search(r'취소\s*완료',row or '')) and not re.search(r'취소\s*전\b|취소 전\)',row or '')

class Cafe24CancelFlow(Cafe24Flow):
    def confirm_ok(self,message):
        # 07:32 보고: 취소접수 확인(#eSubmit)·신용카드 전체/부분취소는 confirm() 창을 띄우는데 기본 처리가 '취소'라 접수가 안 됐다.
        # 취소 단계에서는 확인을 누른다 (삭제 confirm 은 제외).
        if self.step.startswith(('자사몰 취소접수','자사몰 신용카드')) and '삭제' not in message:return True
        return super().confirm_ok(message)
    def detail(self,order_id):
        self.step='자사몰 주문상세 '+order_id
        self.page.goto(f'https://{self.host}/admin/php/s_new/order_detail.php?order_id={quote(order_id)}&menu_no=72',wait_until='domcontentloaded',timeout=45000)
        self.wait(lambda:'주문상세' in self.page.title() or self.page.locator('#eOrderCancel').count()>=1,30,'자사몰 주문상세가 열리지 않았습니다.')
        self.page.wait_for_timeout(1000)
        return self.page.evaluate(CAFE_DETAIL_JS)
    def pay_kind(self,pay):
        p=pay or ''
        if '무통장' in p or '가상계좌' in p:return 'bank'
        if '신용카드' in p or '카드' in p:return 'card'
        return 'other'
    def choose_bank(self):
        sel=self.page.locator('select[name="bank_code"]')
        if sel.count()>1:   # same-name hidden form copies (07:24 cs_type 2개와 같은 구조): prefer the one whose chosen widget is visible
            vis=self.page.locator('select[name="bank_code"]:visible');sel=vis.first if vis.count() else sel.first
        if sel.count()<1:raise DisplayError('환불은행 선택칸을 찾지 못했습니다.')
        box=sel.locator('xpath=following-sibling::div[contains(@class,"chzn-container")][1]')
        if box.count()==1:
            box.locator('a.chzn-single').first.click(timeout=5000);self.page.wait_for_timeout(400)
            item=box.locator('li',has_text=re.compile(r'^\s*'+re.escape(CAFE_BANK)+r'\s*$'))
            if item.count()<1:raise DisplayError('환불은행 목록에서 '+CAFE_BANK+'을(를) 찾지 못했습니다.')
            item.first.click(timeout=5000);self.page.wait_for_timeout(300)
        else:
            sel.select_option(label=CAFE_BANK)
        if CAFE_BANK not in (sel.evaluate('s=>s.options[s.selectedIndex]?.text||""') or ''):raise DisplayError('환불은행이 선택되지 않았습니다.')
    def cancel_tab_row(self,item_no):
        """Open the 취소(N건) tab of the open 주문상세 and return (tab label, row text for item_no or '')."""
        d=self.page.evaluate(CAFE_CANCEL_TAB_JS,item_no) or {'tab':'','rows':[]}
        return d.get('tab',''),(d.get('rows') or [''])[0]
    def card_cancel(self,order_id,item_no,all_cancelled,label):
        """신용카드 전체취소 (#eCardCancel, 주문 전체가 취소일 때) / 부분취소 (#eCardPartCancel). 07:38 요청.
        Accepts the confirm() (confirm_ok) or presses the layer's 결제취소 button, then re-reads the 취소 탭 row until it no longer says 환불전/취소 전."""
        btn='#eCardCancel' if all_cancelled else '#eCardPartCancel';name='신용카드 '+('전체' if all_cancelled else '부분')+'취소'
        loc=self.page.locator(btn+':visible')
        if loc.count()<1:return {'result':'자사몰 카드취소 확인 필요','detail':label+' · '+name+' 버튼이 주문상세에 없습니다. 자사몰에서 직접 누르세요.'}
        self.step='자사몰 '+name;self.check();n_dialogs=len(self.dialogs);before_url=self.page.url
        loc.first.click(timeout=10000);self.page.wait_for_timeout(1500)
        layer=None
        try:layer=self.page.evaluate(CAFE_LAYER_JS)
        except Exception:pass
        if layer and layer.get('buttons'):
            pick=next((b for b in layer['buttons'] if b.get('id')=='eLayerCardCancel'),None) or next((b for b in layer['buttons'] if re.search(r'결제\s*취소|카드\s*취소|취소\s*처리|^확인$',b['text']) and '닫기' not in b['text']),None)
            if not pick:return {'result':'자사몰 카드취소 확인 필요','detail':label+' · '+name+' 창에서 누를 버튼을 찾지 못했습니다: '+layer.get('text','')[:120]}
            self.check();(self.page.locator('#'+pick['id']) if pick.get('id') else self.page.locator('a,button',has_text=re.compile(r'^\s*'+re.escape(pick['text'])+r'\s*$'))).first.click(timeout=10000)
        self.wait(lambda:self.page.url!=before_url or len(self.dialogs)>n_dialogs,30,name+' 뒤 반응이 없습니다 (확인 창·화면 이동 없음).')
        try:self.page.wait_for_load_state('domcontentloaded',timeout=20000)
        except Exception:pass
        self.page.wait_for_timeout(2500)
        self.detail(order_id);tab,row=self.cancel_tab_row(item_no)
        # 07:47 실측: 완료 뒤 행은 `취소처리중 [환불전] … 신용카드 환불 (신용카드 취소완료)` — 환불전은 카페24 환불 처리 상태라 그대로 남고,
        # 카드 취소 여부는 괄호 안 `신용카드 취소 전` → `신용카드 취소완료` 로 바뀐다. alert '"신용카드취소"가 완료되었습니다.' 도 완료 근거.
        dialogs=self.dialogs[n_dialogs:]
        done=bool(row and card_done(row)) or any('완료되었습니다' in d and '신용카드' in d for d in dialogs)
        pending=not done
        return {'result':'자사몰 카드취소 확인 필요' if pending else '자사몰 취소 완료','detail':label+' · '+name+(' 완료 · '+(row[-80:] if row else '; '.join(dialogs)[:80]) if not pending else ' 결과 미확인 — 취소 탭: '+(row[-120:] or '행 없음')+' / 확인 창: '+'; '.join(dialogs)[:100])}
    def cancel(self,order_id,om_no,product):
        info=self.detail(order_id);kind=self.pay_kind(info['pay'])
        if not info['items']:return {'result':'자사몰 취소 확인 필요','detail':'주문상세에서 품목을 찾지 못했습니다 ('+info['pay']+')'}
        targets=[i for i in info['items'] if (om_no and i['om']==om_no) or (not om_no and product and re.sub(r'\s+','',product) in re.sub(r'\s+','',i['text']))]
        if not targets:return {'result':'자사몰 취소 확인 필요','detail':'품목 번호/상품명이 주문상세와 맞지 않습니다: '+', '.join(i['om'] for i in info['items'])}
        om=targets[0]['om'];m=re.search(r'\d{8}-\d{7}-\d{2}',targets[0]['text']);item_no=m.group(0) if m else order_id
        already=all(i['cancelled'] for i in targets)
        if not already:
            self.step='자사몰 취소 처리 화면';self.page.goto(f'https://{self.host}/admin/php/s_new/order_cancel_list.php?order_id={quote(order_id)}&menu_no=72',wait_until='domcontentloaded',timeout=45000)
            self.wait(lambda:self.page.locator('#eCancelAccept').count()>=1,30,'자사몰 취소 처리 화면이 열리지 않았습니다.')
            rows=self.page.evaluate(CAFE_CANCEL_ROWS_JS)
            if not any(r['om']==om for r in rows):return {'result':'자사몰 취소 확인 필요','detail':'취소 처리 화면에 해당 품목이 없습니다(이미 취소/배송 중일 수 있음).'}
            box=self.page.locator(f'input[name^="om_no["][value="{om}"]')
            if not box.is_checked():box.check(timeout=5000)
            self.step='자사몰 취소접수';self.page.locator('#eCancelAccept').first.click(timeout=10000)
            self.wait(lambda:self.page.locator('select[name="cs_type"]').count()>=1,30,'취소접수 입력 화면이 열리지 않았습니다.')
            self.page.wait_for_timeout(800)
            cs=self.page.locator('select[name="cs_type"]:visible')
            cs=cs.first if cs.count() else self.page.locator('select[name="cs_type"]').first
            cs.select_option('H')
            if (cs.evaluate('s=>s.value') or '')!='H':raise DisplayError('취소 구분을 품절로 바꾸지 못했습니다.')
            refund_inputs=self.page.locator('input[name="bank_acc_no"]')
            if kind=='bank' or (kind=='other' and refund_inputs.count() and refund_inputs.first.is_visible()):
                self.choose_bank()
                for name,value in (('bank_acc_no',CAFE_ACC),('depositor',CAFE_DEPOSITOR)):
                    loc=self.page.locator(f'input[name="{name}"]:visible');loc=loc.first if loc.count() else self.page.locator(f'input[name="{name}"]').first
                    loc.fill(value)
            self.step='자사몰 취소접수 확인';self.check();before_url=self.page.url;n_dialogs=len(self.dialogs)
            sub=self.page.locator('#eSubmit:visible');(sub.first if sub.count() else self.page.locator('#eSubmit').first).click(timeout=10000)
            self.wait(lambda:'do_order_cancel_result' in self.page.url or self.page.url!=before_url,40,'취소접수 결과 화면으로 넘어가지 않았습니다. 확인 창: '+'; '.join(self.dialogs[n_dialogs:])[:120])
            try:self.page.wait_for_load_state('domcontentloaded',timeout=20000)
            except Exception:pass
            self.page.wait_for_timeout(2000)
            after=self.detail(order_id)
            if not any(i['om']==om and i['cancelled'] for i in after['items']):
                return {'result':'자사몰 취소 확인 필요','detail':'취소접수 뒤 주문상세에 취소 내역이 보이지 않습니다. 자사몰에서 확인하세요.'}
            label='취소접수 완료 · '+info['pay']
        else:after=info;label='이미 취소접수된 주문 · '+info['pay']
        # 07:39 요청: 취소(N건) 탭에 이 품목이 실제로 들어갔는지 확인 (같은 주문이 여러 번 취소될 수 있음).
        self.step='자사몰 취소 탭 확인';tab,row=self.cancel_tab_row(item_no)
        if not tab or tab.startswith('취소(0'):return {'result':'자사몰 취소 확인 필요','detail':label+' · 주문상세에 취소 탭이 없거나 0건입니다.'}
        if not row:return {'result':'자사몰 취소 확인 필요','detail':label+' · '+tab+' 탭에 품목 '+item_no+' 행이 없습니다.'}
        label+=' · '+tab+' 확인'
        if kind!='card':
            return {'result':'자사몰 취소 완료','detail':label+(' · 현금 환불(농협중앙회/123/123 입력)' if kind=='bank' and not already else '')}
        if card_done(row):return {'result':'자사몰 이미 취소됨','detail':label+' · 신용카드 취소까지 끝난 주문: '+row[-80:]}
        all_cancelled=all(i['cancelled'] for i in after['items'])
        return self.card_cancel(order_id,item_no,all_cancelled,label)

# ---------------------------------------------------------------- 에이블리
class AblyCancelFlow:
    def __init__(self,reader):self.r=reader;self.page=reader.page;self.step=''
    def open(self,sno):
        self.step='에이블리 발송 관리 검색 '+sno
        self.page.goto(ABLY_ORDERS+'&keyword_type=sno&keyword='+quote(sno),wait_until='domcontentloaded',timeout=45000)
        def rows():
            try:return self.page.locator('table.el-table__body tbody tr').filter(has_text=re.compile(re.escape(sno))).count()
            except Exception:return 0
        self.r.wait(lambda:rows()>=1,f'에이블리 발송 관리에서 상품주문번호 {sno}를 10초 안에 찾지 못했습니다. 이미 취소·발송된 주문일 수 있습니다.',10)
        self.page.wait_for_timeout(800)
        total=self.page.locator('table.el-table__body tbody tr').count()
        if total!=1 or rows()!=1:raise DisplayError(f'상품주문번호 {sno} 검색 결과가 {total}건이라 처리하지 않았습니다.')
    def dialog(self):
        return self.page.locator('.el-dialog').filter(has=self.page.locator('.el-dialog__title',has_text=re.compile(r'^\s*주문취소 접수 처리\s*$'))).filter(visible=True)
    def cancel(self,sno):
        self.open(sno)
        self.r.set_checked(sno,True)
        self.step='주문취소 접수 처리 버튼';self.r.check()
        self.page.locator('button',has_text=re.compile(r'^\s*주문취소 접수 처리\s*$')).first.click(timeout=10000)
        d=self.dialog();self.r.wait(lambda:d.count()>=1,'주문취소 접수 처리 창이 열리지 않았습니다.',15);d=d.first
        # 07:24 테스트: 창은 먼저 뜨고 표 행(상품주문번호·주문번호·상품명·옵션…)은 잠시 뒤 채워진다 → 행을 최대 15초 기다린다.
        self.step='주문취소 접수 처리 창 · 행 대기'
        row=d.locator('table.el-table__body tbody tr, tbody tr').filter(has_text=re.compile(re.escape(sno)))
        def row_ready():
            try:return row.count()>=1
            except Exception:return False
        self.r.wait(row_ready,'취소 창에 해당 상품주문번호 행이 15초 안에 나타나지 않았습니다.',15)
        cb=row.first.locator('.el-checkbox').first
        if not row.first.locator('input[type=checkbox]').first.is_checked():cb.click(timeout=5000);self.page.wait_for_timeout(300)
        d.locator('.el-radio',has_text=re.compile(r'^\s*상품 품절\s*$')).first.click(timeout=5000);self.page.wait_for_timeout(300)
        conf=d.locator('.el-checkbox',has_text=re.compile(r'^\s*확인'))
        if conf.count()<1:raise DisplayError('구매 고객 안내 여부 확인 체크박스를 찾지 못했습니다.')
        if not conf.first.locator('input[type=checkbox]').is_checked():conf.first.click(timeout=5000);self.page.wait_for_timeout(300)
        ok=row.first.locator('input[type=checkbox]').first.is_checked() and d.locator('.el-radio.is-checked, .el-radio__input.is-checked').filter(has_text=re.compile('상품 품절')).count()>=0
        if not row.first.locator('input[type=checkbox]').first.is_checked():raise DisplayError('취소 창에서 행이 선택되지 않았습니다.')
        self.step='선택 항목 주문취소 접수 처리';self.r.check()
        d.locator('button',has_text=re.compile(r'^\s*선택 항목 주문취소 접수 처리\s*$')).first.click(timeout=10000)
        self.r.wait(lambda:self.dialog().count()==0,'취소 창이 닫히지 않았습니다. 에이블리 안내 문구를 확인하세요.',20)
        self.page.wait_for_timeout(1500)
        # verify: searching the same 상품주문번호 again must show nothing in 발송 관리
        self.page.goto(ABLY_ORDERS+'&keyword_type=sno&keyword='+quote(sno),wait_until='domcontentloaded',timeout=45000);self.page.wait_for_timeout(3000)
        left=self.page.locator('table.el-table__body tbody tr').filter(has_text=re.compile(re.escape(sno))).count()
        if left:return {'result':'에이블리 취소 확인 필요','detail':'접수 버튼은 눌렀지만 발송 관리에 아직 남아 있습니다. 취소 진행 관리에서 확인하세요.'}
        return {'result':'에이블리 취소 완료','detail':'상품 품절 · 발송 관리에서 빠짐 (취소 진행 관리에서 확인 가능)'}

# ---------------------------------------------------------------- 지그재그 (2026-10-22 01:58~02:05 사장님 설명 + 실측)
# 로그인 → 대시보드 → 배송준비중 목록(조회기간 전체: date_from=2000-01-01, 주소로 열면 조회 버튼 불필요 · 실측 14건=탭 '전체 14건')
# → 취소할 주문 **한 건만** 체크 → '판매자 직접 취소'(체크 전 disabled) → .pds-modal-wrapper '판매자 직접 취소':
#    '취소 상품 선택 (주문번호: N)' 상품 표(체크박스) · 취소 사유 선택 [role=combobox] → 옵션 li[role=option] '품절'
#    ('품절이면 등록된 상품 옵션의 판매 상태가 품절로 변경됩니다' 안내) · 취소 상세사유 textarea(500자, 구매자에게 전달) · 환불금액 표
#    → '취소 처리하기'. 그 뒤 확인 창 유무는 미실측(추측: 있을 수 있음) → '취소'·'처리'가 들어간 확인 창이면 확인, 알림이면 닫기.
# 검증: 배송준비중 목록에서 그 상품주문번호가 빠졌는지. 남아 있으면 '확인 필요'로 두고 다시 누르지 않는다.
ZZ_PRE_URL='https://partners.kakaostyle.com/shop/{shop}/order_item/list/pre_shipment?status_option=awaiting_shipment&date_from=946652400000'
ZZ_COLS={'itemId':'상품주문번호','orderId':'주문번호','status':'주문상태'}
ZZ_REASON='품절'
ZZ_MESSAGE=('안녕하세요, 누아브입니다.\n\n'
 '주문해 주신 상품이 준비 과정에서 품절되어 부득이하게 주문을 취소하게 되었습니다.\n'
 '상품을 기다려 주신 고객님께 기대에 부응하지 못해 진심으로 죄송합니다.\n\n'
 '결제하신 금액은 결제하신 수단으로 전액 환불되며,\n'
 '카드사·결제수단에 따라 실제 반영까지 며칠 걸릴 수 있습니다.\n\n'
 '앞으로 재고를 더 꼼꼼히 관리해 같은 불편을 드리지 않도록 하겠습니다.\n'
 '다시 한번 불편을 드려 죄송합니다.')
ZZ_MODAL_JS='''(m)=>{const norm=s=>(s||'').replace(/\\s+/g,' ').trim();
 const items=[...m.querySelectorAll('tbody tr')].filter(r=>r.querySelector('input[type=checkbox]')).map(r=>({id:norm((r.cells[1]||{}).innerText),checked:!!r.querySelector('input[type=checkbox]').checked}));
 const t=[...m.querySelectorAll('table')].find(t=>/총 환불금액/.test(t.innerText));let refund={};
 if(t){const h=[...t.querySelectorAll('thead th, thead td')].map(e=>norm(e.innerText));const c=[...(t.querySelector('tbody tr')||{cells:[]}).cells].map(e=>norm(e.innerText));h.forEach((k,i)=>{if(c[i]!==undefined)refund[k]=c[i];});}
 const sub=[...m.querySelectorAll('*')].filter(e=>e.children.length===0&&/취소 상품 선택/.test(e.innerText||'')).map(e=>norm(e.innerText))[0]||'';
 return {items,refund,sub,reason:norm((m.querySelector('[role=combobox]')||{}).innerText)};}'''
ZZ_PERIOD_JS="()=>[...document.querySelectorAll('input')].map(i=>i.value).filter(v=>/^\\d{4}\\.\\d{2}\\.\\d{2}$/.test(v))"

def _zz_flow_class():
    from zigzag_returns import ZigzagClaims,READ_JS,list_total
    from zigzag_browser import ZigzagError
    class ZigzagCancelFlow(ZigzagClaims):
        def open_pre(self):
            self.step='지그재그 배송준비중 목록';self.check()
            page=self.live_page();page.goto(ZZ_PRE_URL.format(shop=self.shop),wait_until='domcontentloaded',timeout=45000)
            def ready():
                try:data=page.evaluate(READ_JS,ZZ_COLS);period=page.evaluate(ZZ_PERIOD_JS)
                except Exception:return None
                if data['tab']!='배송준비중' or list_total(data['title']) is None:return None
                if not period or period[0]!='2000.01.01':return None    # 조회기간 전체가 아니면 아직 로딩 중
                if data.get('missing') and list_total(data['title'])==0 and not data.get('bodyRows'):return data
                if data.get('missing'):return None
                return data
            data=self.wait(ready,'지그재그 배송준비중 목록(조회기간 전체)이 열리지 않았습니다.',40)
            page.wait_for_timeout(1500)
            again=self.wait(ready,'지그재그 배송준비중 목록이 안정되지 않았습니다.',20)
            if again.get('title')!=data.get('title'):page.wait_for_timeout(1500);again=self.wait(ready,'지그재그 배송준비중 목록이 안정되지 않았습니다.',20)
            return again
        def goto_page_no(self,n):
            page=self.live_page();btn=page.locator(f'button[aria-label="{n} 페이지"]')
            if btn.count()<1:return None
            btn.first.click(timeout=5000);page.wait_for_timeout(1500)
            return self.wait(lambda:page.evaluate(READ_JS,ZZ_COLS) if not page.evaluate(READ_JS,ZZ_COLS).get('missing') else None,'다음 페이지가 열리지 않았습니다.',20)
        def find_rows(self,order_id,item_id=''):
            data=self.open_pre();page_no=1
            while True:
                hits=[r for r in data['rows'] if r.get('orderId')==order_id and (not item_id or r.get('itemId')==item_id)]
                if hits:return hits
                pages=[int(p.split()[0]) for p in data['pages'] if p and p.split()[0].isdigit() and p.endswith(' 페이지')]
                if not pages or page_no>=max(pages):return []
                page_no+=1;data=self.goto_page_no(page_no)
                if not data:return []
        def close_modal(self,modal):
            # 닫기: 제목 옆 X(글자 없는 버튼, 02:06 실측) — 없으면 '취소'(닫기 버튼). '취소 처리하기'는 절대 아님.
            try:
                if modal.evaluate("m=>{const x=[...m.querySelectorAll('button')].find(b=>!(b.innerText||'').trim());if(x){x.click();return true}return false}"):return
                btn=modal.locator('button').filter(has_text=re.compile(r'^\s*취소\s*$'))
                if btn.count():btn.first.click(timeout=3000)
            except Exception:pass
        def cancel(self,order_id,item_id='',message=ZZ_MESSAGE):
            page=self.live_page()
            rows=self.find_rows(order_id,item_id)
            if not rows:
                return {'result':'지그재그 취소 확인 필요','detail':f'배송준비중 목록(조회기간 전체)에 주문번호 {order_id}'+(f' · 상품주문번호 {item_id}' if item_id else '')+'가 없습니다. 이미 취소·발송됐거나 다른 상태일 수 있어 누르지 않았습니다.'}
            if len(rows)!=1:
                return {'result':'지그재그 취소 확인 필요','detail':f'주문번호 {order_id}의 상품이 {len(rows)}개입니다('+', '.join(r['itemId'] for r in rows)+'). 어느 상품을 취소할지 상품주문번호가 없어 누르지 않았습니다.'}
            target=rows[0]['itemId']
            self.step=f'지그재그 주문 {order_id} 한 건만 선택'
            self.clear_checks();self.set_checked(target,True)
            checked=page.locator('table tbody input[type=checkbox]:checked').count()
            if checked!=1:
                self.clear_checks();raise ZigzagError(f'선택된 행이 {checked}개입니다. 한 주문만 선택해야 해서 중단했습니다.')
            btn=page.locator('button').filter(has_text=re.compile(r'^\s*판매자 직접 취소\s*$'))
            if btn.count()!=1:raise ZigzagError('판매자 직접 취소 버튼을 하나로 찾지 못했습니다.')
            self.wait(lambda:btn.first.is_enabled(),'판매자 직접 취소 버튼이 활성화되지 않았습니다.',8)
            self.step='판매자 직접 취소 창';btn.first.click(timeout=5000)
            modal=page.locator('.pds-modal-wrapper').filter(has_text='판매자 직접 취소')
            self.wait(lambda:modal.count()>=1 and modal.first.is_visible(),'판매자 직접 취소 창이 열리지 않았습니다.',15);modal=modal.first
            info=self.wait(lambda:(lambda d:d if d['items'] else None)(modal.evaluate(ZZ_MODAL_JS)),'판매자 직접 취소 창의 상품 표가 채워지지 않았습니다.',15)
            if f'주문번호: {order_id}' not in info['sub']:
                self.close_modal(modal);return {'result':'지그재그 취소 보류','detail':'창의 주문번호가 다릅니다: '+info['sub'][:80]}
            on=[i['id'] for i in info['items'] if i['checked']]
            if on!=[target]:
                self.close_modal(modal)
                return {'result':'지그재그 취소 보류','detail':f'창에서 체크된 상품({", ".join(on) or "없음"})이 취소할 상품주문번호 {target}과 달라 누르지 않았습니다. (추가상품·1+N 묶음일 수 있음)'}
            self.step='취소 사유 품절 선택'
            modal.locator('[role=combobox]').first.click(timeout=5000)
            opt=page.locator('[role=option]').filter(has_text=re.compile(r'^\s*'+ZZ_REASON+r'\s*$'))
            self.wait(lambda:opt.count()>=1 and opt.first.is_visible(),'취소 사유 목록이 열리지 않았습니다.',8)
            opt.first.click(timeout=5000)
            self.wait(lambda:modal.evaluate(ZZ_MODAL_JS)['reason']==ZZ_REASON,'취소 사유가 품절로 선택되지 않았습니다.',8)
            self.step='취소 상세사유 입력'
            box=modal.locator('textarea')
            if box.count()!=1:self.close_modal(modal);raise ZigzagError('취소 상세사유 입력칸을 하나로 찾지 못했습니다.')
            box.first.fill(message[:500],timeout=5000)
            self.wait(lambda:box.first.input_value()==message[:500],'취소 상세사유가 입력되지 않았습니다.',8)
            info=self.wait(lambda:(lambda d:d if d['refund'].get('총 환불금액') else None)(modal.evaluate(ZZ_MODAL_JS)),'환불금액이 표시되지 않았습니다.',10)
            refund=info['refund'].get('총 환불금액','')
            submit=modal.locator('button').filter(has_text=re.compile(r'^\s*취소\s*처리하기\s*$'))
            if submit.count()!=1:self.close_modal(modal);raise ZigzagError('취소 처리하기 버튼을 하나로 찾지 못했습니다.')
            self.wait(lambda:submit.first.is_enabled(),'취소 처리하기 버튼이 활성화되지 않았습니다.',8)
            seen=[]
            def on_dialog(d):
                seen.append(d.message[:120])
                try:
                    if '취소' in d.message and d.type=='confirm':d.accept()
                    elif d.type=='confirm':d.dismiss()
                    else:d.accept()
                except Exception:pass
            page.on('dialog',on_dialog)
            try:
                self.step='취소 처리하기';self.clicked=True;submit.first.click(timeout=5000)
                form_gone=lambda:page.locator('.pds-modal-wrapper').filter(has_text='판매자 직접 취소').count()==0
                until=time.monotonic()+20;handled=0
                while time.monotonic()<until:
                    self.check()
                    others=page.locator('.pds-modal-wrapper').filter(has_not_text='판매자 직접 취소')
                    if others.count() and handled<3:
                        o=others.last;text=re.sub(r'\s+',' ',o.inner_text())[:160];seen.append(text)
                        ok=o.locator('button').filter(has_text=re.compile(r'^\s*(확인|닫기)\s*$'))
                        if ok.count() and (('하시겠습니까' not in text) or ('취소' in text or '처리' in text)):ok.last.click(timeout=3000);handled+=1;page.wait_for_timeout(600);continue
                        if '하시겠습니까' in text:
                            cancel=o.locator('button').filter(has_text=re.compile(r'^\s*취소\s*$'))
                            if cancel.count():cancel.first.click(timeout=3000)
                            return {'result':'지그재그 취소 확인 필요','detail':'예상하지 못한 확인 창이라 누르지 않았습니다: '+text}
                    if form_gone() and not others.count():break
                    page.wait_for_timeout(300)
                else:
                    left=page.locator('.pds-modal-wrapper')
                    return {'result':'지그재그 취소 확인 필요','detail':'취소 처리하기 뒤 창이 닫히지 않았습니다: '+(re.sub(r'\s+',' ',left.last.inner_text())[-160:] if left.count() else '')+(' / '+'; '.join(seen)[:120] if seen else '')}
            finally:
                try:page.remove_listener('dialog',on_dialog)
                except Exception:pass
            page.wait_for_timeout(1500)
            left=self.find_rows(order_id,target)
            note=f'품절 · 총 환불금액 {refund}'+(' · 확인 창: '+'; '.join(seen)[:120] if seen else '')
            if left:return {'result':'지그재그 취소 확인 필요','detail':note+' · 취소 처리하기는 눌렀지만 배송준비중 목록에 아직 남아 있습니다. 파트너센터 취소 메뉴에서 확인하세요. 다시 누르지 않았습니다.'}
            return {'result':'지그재그 취소 완료','detail':note+' · 배송준비중 목록에서 빠짐 (상품주문번호 '+target+')','itemId':target}
    return ZigzagCancelFlow

# ---------------------------------------------------------------- runner
def run_cancellations(controller,targets,cafe_account,ably_account):
    from playwright.sync_api import sync_playwright
    from return_session import launch_chrome,new_context
    results=[]
    cafe=[t for t in targets if t['platform']=='cafe24'];ably=[t for t in targets if t['platform']=='ably'];zz=[t for t in targets if t['platform']=='zigzag']
    with sync_playwright() as pw:
        if cafe:
            if not cafe_account:
                results.extend({**t,'result':'자사몰 계정 없음','detail':'⚙ 설정 › 로그인에 자사몰(카페24) 계정이 없어 취소를 건너뜀'} for t in cafe)
            else:
                browser=launch_chrome(pw);context=new_context(browser,accept_downloads=False)
                try:
                    flow=Cafe24CancelFlow(controller,context)
                    try:flow.login(cafe_account);ok=True
                    except DisplayCancelled:raise
                    except Exception as exc:
                        ok=False;results.extend({**t,'result':'자사몰 취소 실패','detail':'로그인 · '+(str(exc) or type(exc).__name__)[:160]} for t in cafe)
                    if ok:
                        for n,t in enumerate(cafe,1):
                            controller.check();controller.update('running',f'자사몰 주문취소 {n}/{len(cafe)} · {t["orderId"]}')
                            try:results.append({**t,**flow.cancel(t['orderId'],t.get('omNo',''),t.get('product',''))})
                            except DisplayCancelled:raise
                            except Exception as exc:results.append({**t,'result':'자사몰 취소 실패','detail':(flow.step+' · ' if flow.step else '')+(str(exc) or type(exc).__name__)[:160]})
                finally:context.close();browser.close()
        if ably:
            if not ably_account:
                results.extend({**t,'result':'에이블리 취소 실패','detail':'에이블리 계정 없음'} for t in ably)
            else:
                import browser_window as _bw
                from ably_browser import Reader
                browser=pw.chromium.launch(**_bw.launch_kwargs());context=browser.new_context(viewport={'width':1360,'height':900},device_scale_factor=1,accept_downloads=False);_bw.attach(context)
                try:
                    page=context.new_page();reader=Reader(page,controller.stop,lambda m:controller.update('running',m))
                    try:reader.login(dict(ably_account));ok=True
                    except Exception as exc:
                        if type(exc).__name__ in ('AblyCancelled','DisplayCancelled'):raise
                        ok=False;results.extend({**t,'result':'에이블리 취소 실패','detail':'로그인 · '+(str(exc) or type(exc).__name__)[:160]} for t in ably)
                    if ok:
                        flow=AblyCancelFlow(reader)
                        for n,t in enumerate(ably,1):
                            controller.check();controller.update('running',f'에이블리 주문취소 {n}/{len(ably)} · 상품주문번호 {t["sno"]}')
                            try:results.append({**t,**flow.cancel(t['sno'])})
                            except Exception as exc:
                                if type(exc).__name__ in ('AblyCancelled','DisplayCancelled'):raise
                                results.append({**t,'result':'에이블리 취소 실패','detail':(flow.step+' · ' if flow.step else '')+(str(exc) or type(exc).__name__)[:160]})
                finally:context.close();browser.close()
        if zz:results.extend(_run_zigzag(controller,pw,zz))
    for r in results:r['at']=datetime.now(timezone.utc).isoformat(timespec='seconds')
    return results

def _run_zigzag(controller,pw,targets):
    """지그재그 판매자 직접 취소, 한 주문씩. 계정은 배송안내 앱의 지그재그 설정(키체인, 이메일 아이디)만 쓴다."""
    from zigzag_returns import zigzag_enabled
    from zigzag_credentials import ZigzagAccounts
    from return_session import launch_chrome,new_context
    fail=lambda d:[{**t,'result':'지그재그 취소 실패','detail':d} for t in targets]
    info,note=zigzag_enabled(controller.engine.store.directory)
    if not info:return fail(note)
    try:account=ZigzagAccounts(controller.engine.store.directory).for_login()
    except Exception as exc:return fail(str(exc)[:200])
    out=[]
    browser=launch_chrome(pw);context=new_context(browser,accept_downloads=False)
    try:
        flow=_zz_flow_class()(controller,context,account.get('shop') or 'nuavu')
        try:flow.login_account(account)
        except Exception as exc:
            if type(exc).__name__ in ('ZigzagCancelled','DisplayCancelled'):raise
            return fail('로그인 · '+(str(exc) or type(exc).__name__)[:160])
        for n,t in enumerate(targets,1):
            controller.check();controller.update('running',f'지그재그 주문취소 {n}/{len(targets)} · 주문번호 {t["orderId"]}')
            try:out.append({**t,**flow.cancel(t['orderId'],t.get('itemId',''))})
            except Exception as exc:
                if type(exc).__name__ in ('ZigzagCancelled','DisplayCancelled'):raise
                out.append({**t,'result':'지그재그 취소 실패','detail':(flow.step+' · ' if flow.step else '')+(str(exc) or type(exc).__name__)[:160]})
                if flow.clicked:   # 취소 처리하기를 누른 뒤 오류면 남은 건은 손대지 않는다(환불은 되돌릴 수 없음).
                    out.extend({**x,'result':'지그재그 취소 보류','detail':'앞 주문 처리 중 오류로 멈췄습니다. 파트너센터에서 확인 후 다시 실행하세요.'} for x in targets[n:]);break
            flow.clicked=False
    finally:
        try:account.clear()
        except Exception:pass
        context.close();browser.close()
    return out
