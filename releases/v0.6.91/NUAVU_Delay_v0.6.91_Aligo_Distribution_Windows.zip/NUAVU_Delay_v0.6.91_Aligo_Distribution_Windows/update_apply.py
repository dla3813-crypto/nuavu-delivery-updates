#!/usr/bin/env python3
"""배송안내 배포판 업데이트 적용기 — 새 버전 ZIP 안에 들어 있고, 앱이 서명을 확인한 뒤 앱 밖에서 실행한다.

순서: 앱이 완전히 꺼질 때까지 기다림 → 앱 구성요소(pip) 확인 → 앱 교체 → 새 버전 실행.
- macOS: install_desktop.py 로 ~/Applications/배송안내 배포판.app 을 다시 만든다 (기존 앱은 .before-날짜.app 으로 보관).
- Windows: 앱 폴더(바로가기·배송안내_실행.bat 이 가리키는 곳)를 데이터 폴더에 백업한 뒤 새 파일로 덮어쓴다.
  실패하면 백업을 되돌린다.
주문·발송 이력·계정이 있는 데이터 폴더와 키체인은 건드리지 않는다. 실패하면 알림을 띄우고 기존 앱을 다시 연다.
"""
from __future__ import annotations
import argparse,os,shutil,subprocess,sys,time
from datetime import datetime
from pathlib import Path

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))   # python -I does not add the script folder

MAC_PIP=['--only-binary=pyobjc-core,pyobjc-framework-Cocoa,pyobjc-framework-Quartz,pyobjc-framework-WebKit,pyobjc-framework-Security,pyobjc-framework-UniformTypeIdentifiers',
         'pywebview==6.2.1','playwright==1.64.0','certifi']
WIN_PIP=['pywebview==6.2.1','playwright==1.64.0','certifi','tzdata']
SKIP_WIN=('__pycache__',)

def log(msg):print(f'[{datetime.now().strftime("%H:%M:%S")}] {msg}',flush=True)

def wait_for_exit(data,pid,seconds=600):
    """The app holds <data>/running.lock while it runs; wait until we can take it (then release it)."""
    from platform_support import ProcessLock
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        lock=ProcessLock(data)
        if lock.acquire():lock.release();return True
        time.sleep(0.5)
    return False

def alert(message):
    try:
        from platform_support import alert as _alert
        _alert('배송안내 배포판 업데이트',message)
    except Exception:pass

def pip_install(py,args):
    r=subprocess.run([py,'-I','-m','pip','install','--disable-pip-version-check',*args],capture_output=True,text=True)
    log((r.stdout or '')[-1500:]+(r.stderr or '')[-1500:])
    if r.returncode!=0:raise RuntimeError('앱 구성요소 설치/확인 실패 (인터넷 연결 확인)')

def apply_mac(a):
    py=sys.executable;bundle=Path(a.bundle)
    pip_install(py,MAC_PIP)
    import install_desktop
    install_desktop.build_bundle(bundle,Path(py))
    log('앱 교체 완료: '+str(bundle))
    subprocess.run(['/usr/bin/open',str(bundle)],check=False)

def _copy_tree(src,dst):
    for p in src.rglob('*'):
        rel=p.relative_to(src)
        if any(part in SKIP_WIN for part in rel.parts):continue
        t=dst/rel
        if p.is_dir():t.mkdir(parents=True,exist_ok=True)
        else:t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,t)

def apply_windows(a):
    py=sys.executable;root=Path(a.app_root)
    pip_install(py,WIN_PIP)
    if root.resolve()==HERE:raise RuntimeError('업데이트 파일과 앱 폴더가 같습니다.')
    backup=Path(a.data)/'updates'/('backup-v'+a.from_version)
    shutil.rmtree(backup,ignore_errors=True);log('기존 앱 폴더 백업: '+str(backup));_copy_tree(root,backup)
    try:
        _copy_tree(HERE,root)
    except Exception:
        log('덮어쓰기 실패 → 백업 되돌림');_copy_tree(backup,root);raise
    log('앱 교체 완료: '+str(root))
    pyw=Path(py).with_name('pythonw.exe');pyw=pyw if pyw.exists() else Path(py)
    subprocess.Popen([str(pyw),str(root/'desktop.py')],cwd=str(root),creationflags=0x00000008|0x00000200)

def reopen_old(a):
    try:
        if sys.platform=='darwin' and a.bundle and Path(a.bundle).exists():subprocess.run(['/usr/bin/open',a.bundle],check=False)
        elif sys.platform=='win32' and a.app_root:
            py=Path(sys.executable);pyw=py.with_name('pythonw.exe');pyw=pyw if pyw.exists() else py
            subprocess.Popen([str(pyw),str(Path(a.app_root)/'desktop.py')],cwd=a.app_root,creationflags=0x00000008|0x00000200)
    except Exception:pass

def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--pid',type=int,required=True);p.add_argument('--data',required=True);p.add_argument('--version',required=True)
    p.add_argument('--from-version',default='');p.add_argument('--bundle',default='');p.add_argument('--app-root',default='')
    a=p.parse_args(argv)
    log(f'업데이트 적용 시작 {a.from_version} → {a.version} (앱 종료 대기)')
    if not wait_for_exit(a.data,a.pid):
        alert('앱이 종료되지 않아 업데이트를 적용하지 못했습니다. 앱을 종료한 뒤 다시 업데이트를 눌러 주세요.');return 1
    try:
        if sys.platform=='darwin':apply_mac(a)
        elif sys.platform=='win32':apply_windows(a)
        else:raise RuntimeError('지원하지 않는 운영체제')
        log('업데이트 완료');return 0
    except Exception as exc:
        log(f'업데이트 실패: {type(exc).__name__}: {exc}')
        alert(f'업데이트를 마치지 못해 기존 버전으로 다시 엽니다. 주문·이력은 그대로입니다.\n({str(exc)[:200]})')
        reopen_old(a);return 1

if __name__=='__main__':sys.exit(main())
