"""지그재그 '메시지 없는 배송지연(배송연기 안내)' 날짜 규칙.

근거
- 2026-10-23 사장님 설명: 주문일로부터 3영업일 안에 배송지연 안내를 보내야 함 (10/19→10/22, 10/20→10/23, 10/21→10/26),
  공휴일도 지그재그가 같이 계산함, 고객 안내 문자 작성은 날짜 제한 없음.
- 2026-10-23 파트너센터 실측 (nuavu, 읽기만 · 전송 안 함):
  · 목록 '발송 예정일' = 결제일 + 3영업일 ("2026.10.27 23:59:59 (3 영업일)", 10/22 결제).
  · 발송 예정일이 지난 주문(10/19 결제 · 10/22 예정)을 선택하면 '배송연기 안내' 버튼이 비활성 → 앱이 10초 기다리다 막힘.
  · 10/22 결제(예정 10/27) 주문의 달력: 10/28 ~ 11/5 평일만 선택 가능 = 발송 예정일 다음 영업일 ~ 발송 예정일 + 7영업일.
    창 안내 문구: "배송연기 안내는 최초 발송 예정일로부터 최대 7일까지", "최초 발송 예정일 이내 1회만 가능".
  · 사장님 예시 '10/23 주문 → 11/3', '10/27 주문 → 11/5'는 이 실측(발송 예정일 + 7영업일 → 11/6, 11/10)과 다릅니다.
    앱은 실측한 파트너센터 달력을 따릅니다.
- 공휴일: supply_calendar.HOLIDAYS_2026 (2026년 공휴일표). 그 밖의 해는 주말만 빼고, calendarKnown=False로 표시합니다.
"""
from __future__ import annotations
import re
from datetime import date,timedelta
from supply_calendar import is_holiday

ZIGZAG='누아브 지그재그'
SEND_BUSINESS_DAYS=3     # 결제일 → 최초 발송 예정일 (배송연기 안내 마감일)
MAX_BUSINESS_DAYS=7      # 최초 발송 예정일 → 변경 발송 예정일 최대
KNOWN_YEARS={2026}

def parse_day(text):
    m=re.search(r'(\d{4})[.\-/](\d{1,2})[.\-/](\d{1,2})',str(text or ''))
    if not m:return None
    try:return date(int(m[1]),int(m[2]),int(m[3]))
    except ValueError:return None

def is_business(d):return d.weekday()<5 and not is_holiday(d,())

def business_after(start,count):
    """Business days strictly after `start`, `count` of them (weekends and 2026 public holidays skipped)."""
    out=[];d=start
    for _ in range(400):
        if len(out)>=count:break
        d+=timedelta(days=1)
        if is_business(d):out.append(d)
    return out

def ship_by(order_day):
    """지그재그 최초 발송 예정일 = 결제(주문)일 + 3영업일."""
    return business_after(order_day,SEND_BUSINESS_DAYS)[-1]

def holidays_between(a,b):
    out=[];d=a
    while d<=b:
        if d.weekday()<5 and is_holiday(d,()):out.append(d.isoformat())
        d+=timedelta(days=1)
    return out

def window(order_text,today):
    """Dates for one Zigzag order. `today` is an ISO string. None when the order date is unreadable."""
    od=parse_day(order_text)
    if not od:return None
    sb=ship_by(od);days=business_after(sb,MAX_BUSINESS_DAYS)
    years={od.year,sb.year,days[-1].year}
    return {'orderDate':od.isoformat(),'shipBy':sb.isoformat(),'deadline':sb.isoformat(),
            'min':days[0].isoformat(),'max':days[-1].isoformat(),'allowed':[d.isoformat() for d in days],
            'holidays':holidays_between(od,days[-1]),'open':str(today)<=sb.isoformat(),'calendarKnown':years<=KNOWN_YEARS}

def zigzag_done_once(s,key):
    """Zigzag allows one 배송연기 안내 per order: already changed there (sync) or sent by the app."""
    if any(n.get('source')=='zigzag_sync' and key in n.get('itemKeys',[]) for n in s.get('notices',[])):return True
    return any(p.get('key')==key and p.get('status')=='sent' for p in s.get('zigzagPushLog',[]))

def row_window(s,row,today):
    """Window + eligibility for a Zigzag app row (None for other sellers)."""
    if row.get('seller')!=ZIGZAG:return None
    w=window(row.get('orderDate'),today)
    if not w:return {'open':False,'reason':'주문일을 읽지 못해 지그재그 날짜 범위를 계산하지 못했습니다.'}
    if zigzag_done_once(s,row['key']):w.update(open=False,reason='지그재그에 이미 배송연기 안내 1회 완료 (주문당 1회만 가능)')
    elif not w['open']:w['reason']=f"지그재그 발송 예정일({w['shipBy']})이 지나 배송연기 안내 불가 · 고객 안내 문자 작성으로 안내하세요"
    else:w['reason']=''
    return w

def combined(s,rows,today):
    """For the 메시지 없는 안내 dialog: the date range every still-open Zigzag row accepts."""
    ws=[(r,row_window(s,r,today)) for r in rows if r.get('seller')==ZIGZAG]
    live=[w for _,w in ws if w and w.get('open')]
    closed=[{'key':r['key'],'orderId':r.get('orderId',''),'reason':(w or {}).get('reason','')} for r,w in ws if not (w and w.get('open'))]
    if not live:return {'zigzag':len(ws),'open':0,'closed':closed,'allowed':[],'min':'','max':'','holidays':[]}
    allowed=set(live[0]['allowed'])
    for w in live[1:]:allowed&=set(w['allowed'])
    allowed=sorted(allowed);hol=sorted({h for w in live for h in w['holidays']})
    return {'zigzag':len(ws),'open':len(live),'closed':closed,'allowed':allowed,'min':allowed[0] if allowed else '','max':allowed[-1] if allowed else '',
            'holidays':hol,'deadline':min(w['deadline'] for w in live),'calendarKnown':all(w['calendarKnown'] for w in live)}

def check_due(s,rows,due,today):
    """Server-side guard for the 메시지 없는 안내 dialog. Returns '' or a Korean error."""
    c=combined(s,rows,today)
    if not c['open']:return ''
    if not c['allowed']:return '선택한 지그재그 주문들의 배송연기 가능 날짜가 겹치지 않습니다. 주문일이 비슷한 것끼리 나눠서 처리하세요.'
    if due not in c['allowed']:
        return f"지그재그 배송연기 안내는 {c['min']} ~ {c['max']} 중 평일(공휴일 제외)만 고를 수 있습니다. 선택한 날짜: {due}"
    return ''
