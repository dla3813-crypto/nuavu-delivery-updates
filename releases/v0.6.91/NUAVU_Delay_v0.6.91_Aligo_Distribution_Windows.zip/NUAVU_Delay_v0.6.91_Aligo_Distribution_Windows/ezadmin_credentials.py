"""EzAdmin-only macOS Keychain item. No plaintext fallback or secret UI return."""
from __future__ import annotations
import hashlib
import json
import re
import sys
from credentials import MacKeychain, UnavailableVault, VaultError

SERVICE='kr.nuavu.deliverynotice.distribution.ezadmin'

class EzadminKeychain(MacKeychain):
    def _query(self):
        q=super()._query();q[self._api().kSecAttrService]=SERVICE;return q

    def save(self, payload):
        s=self._api()
        raw=json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode('utf-8')
        if len(raw)>16384:raise VaultError('이지어드민 계정 정보가 너무 큽니다.')
        query=self._query()
        try:
            status=s.SecItemUpdate(query,{s.kSecValueData:raw})
            if status==s.errSecItemNotFound:
                add={**query,s.kSecValueData:raw,s.kSecAttrLabel:'배송안내 배포판 이지어드민 로그인'}
                status,_=s.SecItemAdd(add,None)
                if status==s.errSecDuplicateItem:status=s.SecItemUpdate(query,{s.kSecValueData:raw})
            self._check(status)
        except Exception:
            raise VaultError('이지어드민 계정을 키체인에 저장하지 못했습니다. 키체인 접근을 허용한 뒤 다시 저장하세요. 평문으로 대신 저장하지 않습니다.') from None

    def load(self):
        try:return super().load()
        except Exception:
            raise VaultError('이지어드민 계정을 키체인에서 읽지 못했습니다. 키체인 접근을 허용하고 이지어드민 설정을 다시 여세요.') from None

def default_ezadmin_vault(directory):
    from windows_credentials import platform_vault
    return platform_vault(directory,SERVICE,'배송안내 배포판 이지어드민 로그인',EzadminKeychain)

def identity(domain,username):
    if not isinstance(domain,str) or not isinstance(username,str):raise VaultError('도메인과 아이디를 입력하세요.')
    domain=domain.strip();username=username.strip()
    if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_-]{0,99}',domain):
        raise VaultError('도메인은 주소가 아닌 이지어드민 로그인용 도메인 이름으로 입력하세요.')
    if not username or len(username)>200 or any(ord(c)<32 for c in username):raise VaultError('이지어드민 아이디를 확인하세요.')
    return domain,username

def account_payload(domain,username,password):
    domain,username=identity(domain,username)
    if not isinstance(password,str) or not password or len(password)>4096 or '\x00' in password:
        raise VaultError('이지어드민 비밀번호를 입력하세요.')
    return {'version':1,'domain':domain,'username':username,'password':password}

def account_profile(account):
    # Account changes must not reuse another account's authenticated session.
    return hashlib.sha256(json.dumps([account['domain'],account['username']],ensure_ascii=False).encode()).hexdigest()[:32]

class EzadminAccounts:
    def __init__(self,directory,vault=None):self.vault=vault if vault is not None else default_ezadmin_vault(directory)
    def load(self):
        try: saved=self.vault.load()
        except Exception:raise VaultError('이지어드민 키체인을 읽지 못했습니다. 키체인 접근을 허용한 뒤 설정을 다시 여세요.') from None
        if saved is None:return None
        try:
            if saved.get('version')!=1:raise ValueError()
            return account_payload(saved.get('domain'),saved.get('username'),saved.get('password'))
        except Exception:raise VaultError('저장된 이지어드민 계정을 확인할 수 없습니다. 설정에서 다시 저장하세요.') from None
    def info(self):
        saved=self.load()
        return {'domain':saved['domain'] if saved else '', 'username':saved['username'] if saved else '',
                'hasPassword':bool(saved),'storage':'macOS 키체인','available':bool(self.vault.available)}
    def save(self,domain,username,password):
        domain,username=identity(domain,username)
        if password=='':
            old=self.load()
            if not old or (old['domain'],old['username'])!=(domain,username):
                raise VaultError('새 계정에는 비밀번호를 입력하세요. 다른 계정의 저장 비밀번호는 사용하지 않습니다.')
            password=old['password']
        payload=account_payload(domain,username,password)
        try:self.vault.save(payload)
        except Exception:raise VaultError('이지어드민 계정을 키체인에 저장하지 못했습니다. 키체인 접근을 확인하세요. 평문 파일에는 저장하지 않습니다.') from None
        try:verified=self.load()
        except Exception:raise VaultError('이지어드민 계정을 저장한 뒤 다시 읽지 못했습니다. 키체인 접근을 허용하고 다시 저장하세요.') from None
        if verified!=payload:
            raise VaultError('저장한 이지어드민 계정을 다시 확인하지 못했습니다. 로그인은 시작하지 않았습니다. 다시 저장하세요.')
        return {'domain':domain,'username':username,'hasPassword':True,'storage':'macOS 키체인','available':True,'message':'이지어드민 로그인 정보를 저장하고 키체인에서 다시 확인했습니다.'}
    def for_login(self):
        account=self.load()
        if not account:raise VaultError('⚙ 설정 › 로그인의 이지어드민 설정에서 도메인·아이디·비밀번호를 먼저 저장하세요.')
        return account
