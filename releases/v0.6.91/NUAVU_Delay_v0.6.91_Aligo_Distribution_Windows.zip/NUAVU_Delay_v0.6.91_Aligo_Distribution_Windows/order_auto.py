"""Button-triggered order export. No sender, scheduler or order writes. Login secrets remain in a separate Keychain item.

A run owns one export receipt; an old file in Downloads is never a fallback.
Only the existing front-end parser/import API can apply a successful receipt.
"""
from __future__ import annotations
import base64
from datetime import datetime, timedelta
from email.utils import parsedate_to_datetime
import hashlib
import os
from pathlib import Path
import re
import secrets
import tempfile
import threading
import time
from urllib.parse import unquote, urlsplit

# 10:04 보고(Windows): zoneinfo 는 Windows에 시간대 DB가 없어 import 시점에 실패한다 → 한국은 서머타임이 없으니 고정 +9 로 대체.
try:
    from zoneinfo import ZoneInfo;KST=ZoneInfo('Asia/Seoul')
except Exception:
    from datetime import timezone as _tz,timedelta as _td;KST=_tz(_td(hours=9),'KST')
MAX_BYTES = 20 * 1024 * 1024
FILE_RE = re.compile(r'확장주문검색_(\d{14})_(\d+)\.(xls|xlsx)$')
GROUP = ''
LOGIN_SERVERS = {'login1':'https://login1.ezadmin.co.kr/login.htm',
                 'login2':'https://login2.ezadmin.co.kr/login.htm'}

class OrderAutoError(Exception): pass
class Cancelled(OrderAutoError): pass

def checked_name(name, started):
    m = FILE_RE.fullmatch(name)
    if not m: raise OrderAutoError('확장주문검색 파일명이 아닙니다. 주문을 반영하지 않았습니다.')
    try: stamp = datetime.strptime(m[1], '%Y%m%d%H%M%S').replace(tzinfo=KST)
    except ValueError: raise OrderAutoError('파일 생성시각을 확인할 수 없습니다.')
    if not started - timedelta(seconds=5) <= stamp <= datetime.now(KST) + timedelta(seconds=30):
        raise OrderAutoError('이번 요청보다 오래되었거나 생성시각이 잘못된 파일입니다.')
    return name

def checked_link(url, name):
    u = urlsplit(url)
    if u.scheme != 'https' or not re.fullmatch(r'ga\d+\.ezadmin\.co\.kr', u.hostname or '') or u.port not in (None,443) or u.username or u.password:
        raise OrderAutoError('이지어드민의 안전한 다운로드 주소가 아닙니다.')
    if not u.path.startswith('/data/') or unquote(u.path.rsplit('/',1)[-1]) != name or u.query or u.fragment:
        raise OrderAutoError('요청한 주문 파일과 다운로드 주소가 다릅니다.')
    return url

def new_job(rows, baseline, started):
    candidates = []
    for row in rows:
        if row.get('id') in baseline or row.get('template') != '확장주문검색2': continue
        try: at = datetime.strptime(row['at'], '%Y-%m-%d %H:%M:%S').replace(tzinfo=KST)
        except (ValueError, KeyError): continue
        if at >= started - timedelta(seconds=3): candidates.append(row)
    if len(candidates) > 1:
        raise OrderAutoError('동시에 요청된 주문 엑셀이 여러 개라 구분할 수 없습니다. 다운로드관리자에서 파일을 확인 후 수동으로 불러오세요.')
    return candidates[0] if candidates else None

def server_request_window(started, accepted, date_header, sent, received, elapsed, age='0'):
    """Convert local click/receipt times using the authenticated page response.

    HTTP Date has one-second precision and is generated between request and
    response. Preserve that measured uncertainty, never guess from job rows.
    Multiple rows inside the resulting interval remain an explicit error.
    """
    try:
        server=parsedate_to_datetime(date_header)
        if server.tzinfo is None or server.utcoffset()!=timedelta(0):raise ValueError()
        server=server.astimezone(KST)
        duration=(received-sent).total_seconds()
        if not 0<=duration<=5 or abs(duration-elapsed)>.5 or str(age or '0').strip()!='0':raise ValueError()
        low=server-received;high=server+timedelta(seconds=1)-sent
        if low.total_seconds() < -10 or high.total_seconds() > 10:raise ValueError()
        if accepted<started or sent<accepted:raise ValueError()
    except (TypeError,ValueError,OverflowError,AttributeError):
        raise OrderAutoError('이지어드민 서버 시각을 정확히 확인하지 못했습니다. 열린 다운로드관리자에서 이번 완료 파일을 수동으로 확인하세요.') from None
    return started+low,accepted+high

def requested_job(rows, started, accepted):
    """First manager visit is after acknowledgement, so no pre-submit baseline.

    The manager displays whole seconds. Accept only one ID in the submission
    start to accepted-notice interval; never extend it into older history.
    Multiple requests in that interval require manual selection.
    """
    lower=started.replace(microsecond=0)
    upper=accepted.replace(microsecond=0)
    if upper<lower:raise OrderAutoError('다운로드 접수 시각을 대조하지 못했습니다. 수동으로 파일을 확인하세요.')
    candidates=[]
    for row in rows:
        if row.get('template')!='확장주문검색2':continue
        try:at=datetime.strptime(row['at'],'%Y-%m-%d %H:%M:%S').replace(tzinfo=KST)
        except (ValueError,KeyError,TypeError):
            raise OrderAutoError('다운로드 작업의 요청시각을 확인하지 못했습니다. 수동으로 파일을 확인하세요.')
        if lower<=at<=upper:
            if not row.get('id'):raise OrderAutoError('다운로드 작업 번호를 확인하지 못했습니다.')
            candidates.append(row)
    if len(candidates)>1:
        raise OrderAutoError('접수한 시간에 주문 엑셀이 여러 개 요청되어 구분할 수 없습니다. 다운로드관리자에서 파일을 확인 후 수동으로 불러오세요.')
    return candidates[0] if candidates else None

def checked_request_name(name, started):
    checked_name(name,started)
    stamp=datetime.strptime(FILE_RE.fullmatch(name)[1],'%Y%m%d%H%M%S').replace(tzinfo=KST)
    if stamp<started.replace(microsecond=0):
        raise OrderAutoError('이번 확인 요청보다 오래된 파일입니다. 이전 파일은 반영하지 않았습니다.')
    return name

def persist_download(download, folder, name):
    if not FILE_RE.fullmatch(name): raise OrderAutoError('확장주문검색 파일 이름을 확인하세요.')
    folder = Path(folder)
    if not folder.is_dir(): raise OrderAutoError('연결한 다운로드 폴더를 찾을 수 없습니다.')
    target = folder / name
    if target.exists() or target.is_symlink():
        raise OrderAutoError('같은 이름의 파일이 이미 있습니다. 기존 파일은 덮어쓰지 않았습니다.')
    fd, tmp = tempfile.mkstemp(prefix='.nuavu-orders-', suffix='.part', dir=folder)
    os.close(fd)
    try:
        download.save_as(tmp)
        if download.failure(): raise OrderAutoError('엑셀 다운로드가 완료되지 않았습니다.')
        with open(tmp,'rb') as f: data=f.read(MAX_BYTES+1)
        if not data or len(data)>MAX_BYTES: raise OrderAutoError('주문 파일이 비어 있거나 20MB를 초과했습니다.')
        os.chmod(tmp,0o600)
        # Hard link provides no-overwrite atomic publication on the selected filesystem.
        os.link(tmp,target)
        return data
    except FileExistsError: raise OrderAutoError('같은 이름의 파일이 생겨 자동 반영을 중단했습니다.')
    finally: Path(tmp).unlink(missing_ok=True)

class OrderAutoController:
    def __init__(self, store, runner=None, login_vault=None, notify_confirmation=None):
        self.store=store;self.runner=runner;self.lock=threading.RLock()
        self.notify_confirmation=notify_confirmation
        self.alert=None   # (title,message,level) → app 알림; set by the desktop app
        self.captcha=False   # 캡차 인증 대기 (사람이 캡차·다운로드 신청 후 '다운로드 완료')
        from ezadmin_credentials import EzadminAccounts
        self.accounts=EzadminAccounts(store.directory,login_vault)
        self.stop=threading.Event();self.thread=None;self.receipt=None
        self.login_question=None;self.login_answer=None;self.question_event=threading.Event()
        self.browser_recovery=False;self.browser_can_continue=False;self.browser_command=None
        self.job={'phase':'idle','message':'자동 불러오기를 누르면 이지어드민에서 새 주문 파일을 가져옵니다.'}

    def settings(self):
        state=self.store.read();s=state.get('orderAutoImport',{})
        return {'folder':s.get('folder',''),'group':s.get('group',state['settings'].get('shopName',GROUP)),'lastDownload':s.get('lastDownload',''),'lastFile':s.get('lastFile','')}

    def configure(self, folder=None, group=None):
        with self.lock:
            if self.thread and self.thread.is_alive(): raise OrderAutoError('불러오기 중에는 설정을 바꿀 수 없습니다.')
            if folder is not None:
                p=Path(folder)
                if not p.is_absolute() or not p.is_dir(): raise OrderAutoError('다운로드할 로컬 폴더를 선택하세요.')
                folder=str(p.resolve())
            if group is not None:
                group=str(group).strip()
                if not group or len(group)>80 or any(ord(c)<32 for c in group): raise OrderAutoError('이지어드민에 표시된 판매처 그룹 이름을 입력하세요.')
            with self.store.edit() as s:
                cfg=s.setdefault('orderAutoImport',{})
                if folder is not None: cfg['folder']=folder
                if group is not None: cfg['group']=group
            return self.settings()

    def login_settings(self):
        with self.lock:
            if self.thread and self.thread.is_alive(): raise OrderAutoError('자동 불러오기가 끝나거나 중단된 뒤 이지어드민 설정을 여세요.')
            return self.accounts.info()

    def save_login_settings(self, domain, username, password):
        with self.lock:
            if self.thread and self.thread.is_alive(): raise OrderAutoError('자동 불러오기 중에는 로그인 계정을 바꿀 수 없습니다.')
            result=self.accounts.save(domain,username,password)
            # Account correction supersedes a finished login error, but must
            # never restart a job or discard a downloaded receipt.
            if self.receipt is None and self.job.get('phase') in {'idle','error','error_open','cancelled','login_ready'}:
                self.end_browser_recovery()
                self.login_question=None;self.login_answer=None
                self.job={'phase':'idle','message':'로그인 정보를 저장했습니다. 로그인 확인 또는 자동 불러오기를 눌러 시작하세요.'}
            return result

    def login_account(self):
        from credentials import VaultError
        try:return self.accounts.for_login()
        except VaultError as exc:raise OrderAutoError(str(exc)) from None

    def status(self):
        with self.lock: return {**self.job,'running':bool(self.thread and self.thread.is_alive()),'settings':self.settings(),
                               'loginQuestion':dict(self.login_question) if self.login_question else None,
                               'browserRecovery':self.browser_recovery,'browserCanContinue':self.browser_can_continue,'captchaWait':self.captcha}

    def ask_login_confirmation(self, text):
        # text has already been redacted by the browser driver. Memory only.
        import browser_window;browser_window.attention()
        with self.lock:
            self.check();self.question_event.clear();self.login_answer=None
            self.login_question={'id':secrets.token_urlsafe(18),'jobId':self.job['id'],'text':text}
            self.update('login_confirm','이지어드민 확인 요청이 있습니다. 누아브 앱에서 내용을 확인하세요.')
        try:
            if self.notify_confirmation:
                try:self.notify_confirmation()
                except Exception:pass
            deadline=time.monotonic()+180
            while time.monotonic()<deadline:
                self.check()
                if self.question_event.wait(.1):
                    self.check()
                    return self.login_answer is True
            raise OrderAutoError('로그인 확인 요청에 응답이 없어 중단했습니다. 기존 주문은 유지됩니다.')
        finally:
            with self.lock:self.login_question=None;self.login_answer=None

    def answer_login_confirmation(self, job_id, question_id, accepted):
        with self.lock:
            q=self.login_question
            if not q or q['jobId']!=job_id or q['id']!=question_id or type(accepted) is not bool or self.question_event.is_set() or self.stop.is_set():
                raise OrderAutoError('만료되었거나 이미 처리한 로그인 확인 요청입니다.')
            self.login_answer=accepted;self.question_event.set()
            return {'accepted':True}

    def update(self, phase, message):
        with self.lock: self.job.update(phase=phase,message=message)

    def browser_failed(self, message, browser_open, can_continue=False):
        import browser_window;browser_window.attention()
        with self.lock:
            self.receipt=None
            self.browser_recovery=bool(browser_open and not self.stop.is_set())
            self.browser_can_continue=bool(self.browser_recovery and can_continue)
            self.update('error_open' if browser_open else 'error',message)
        if self.notify_confirmation:
            try:self.notify_confirmation()
            except Exception:pass

    def request_browser_action(self, job_id, action, login_server='login2'):
        # UI requests are consumed only on the existing browser's worker thread.
        with self.lock:
            if (job_id!=self.job.get('id') or not self.thread or not self.thread.is_alive()
                    or self.stop.is_set() or not self.browser_recovery or self.job.get('phase')!='error_open'
                    or self.login_question or self.browser_command):
                raise OrderAutoError('현재 Chrome 창에서 처리할 수 없는 요청입니다. 화면 상태를 다시 확인하세요.')
            if self.captcha!=(action=='downloaded'):
                raise OrderAutoError('캡차 인증 대기 중에는 다운로드 완료만 누를 수 있습니다.' if self.captcha else '캡차 인증 대기 중인 작업이 아닙니다.')
            if action=='downloaded':
                self.browser_command=('downloaded','')
                self.update('browser_recovery','다운로드 완료 확인 · 다운로드관리자에서 이번 파일을 찾습니다.')
                return self.status()
            if action not in ('open','continue') or login_server not in LOGIN_SERVERS:
                raise OrderAutoError('로그인 페이지 선택을 확인하세요.')
            if not self.browser_can_continue:
                raise OrderAutoError('이미 엑셀 신청을 시작한 작업입니다. 로그인 화면으로 이동하거나 다시 신청하지 않습니다. 열린 Chrome에서 결과를 확인하세요.')
            self.browser_command=(action,LOGIN_SERVERS[login_server])
            self.update('browser_recovery','같은 Chrome 창에서 요청을 처리 중입니다.')
            return self.status()

    def captcha_wait(self, message):
        import browser_window;browser_window.attention()
        with self.lock:
            self.receipt=None;self.browser_recovery=True;self.browser_can_continue=False;self.captcha=True
            self.update('error_open',message)
        if self.notify_confirmation:
            try:self.notify_confirmation()
            except Exception:pass

    def take_browser_action(self):
        with self.lock:
            self.check()
            command=self.browser_command;self.browser_command=None
            return command

    def end_browser_recovery(self):
        import browser_window;browser_window.calm()
        with self.lock:
            self.browser_recovery=False;self.browser_can_continue=False;self.browser_command=None;self.captcha=False

    def check(self):
        if self.stop.is_set(): raise Cancelled('자동 불러오기를 중단했습니다. 기존 주문은 유지됩니다.')

    def start(self, login_only=False):
        with self.lock:
            if getattr(self,'external_busy',lambda:False)():raise OrderAutoError('반품·교환 또는 회수접수 작업 종료 후 실행하세요.')
            if self.thread and self.thread.is_alive(): raise OrderAutoError('자동 불러오기가 이미 진행 중입니다.')
            cfg=self.settings()
            if not login_only and (not cfg['folder'] or not Path(cfg['folder']).is_dir()): raise OrderAutoError('다운로드 폴더를 먼저 연결하세요.')
            shop=self.store.read()['settings']
            if not login_only and (not shop.get('shopName') or not cfg['group']):raise OrderAutoError('쇼핑몰 이름과 이지어드민 판매처 그룹을 먼저 설정하세요.')
            cfg.update(shopName=shop.get('shopName',''),shopRevision=shop.get('shopRevision',0))
            cfg['loginOnly']=bool(login_only)
            self.end_browser_recovery()
            self.stop.clear();self.receipt=None
            self.login_question=None;self.question_event.clear()
            self.job={'id':secrets.token_urlsafe(18),'phase':'starting','message':'자동 불러오기 창을 여는 중입니다.'}
            self.thread=threading.Thread(target=self._run,args=(cfg,),daemon=True)
            self.thread.start()
            return self.status()

    def _run(self, cfg):
        try:
            runner=self.runner
            if runner is None:
                from order_browser import run_export
                runner=run_export
            result=runner(self,cfg)
            self.check()
            if cfg.get('loginOnly'):
                self.update('login_ready','로그인 확인 완료 · 주문 다운로드와 반영은 하지 않았습니다.')
                return
            name,data=result
            with self.lock:
                self.check()
                self.receipt={'shopName':cfg['shopName'],'shopRevision':cfg['shopRevision'],'id':self.job['id'],'name':name,'data':base64.b64encode(data).decode('ascii'),'sha256':hashlib.sha256(data).hexdigest()}
                with self.store.edit() as s:
                    s.setdefault('orderAutoImport',{}).update(lastDownload=datetime.now(KST).isoformat(timespec='seconds'),lastFile=name)
                self.update('ready','새 주문 엑셀 다운로드 완료 · 주문 내용을 확인 중입니다.')
        except Cancelled as exc: self.update('cancelled',str(exc))
        except OrderAutoError as exc: self.update('error',str(exc))
        except Exception:
            # Browser exception payloads may include customer contents or account URLs.
            self.update('error','자동 불러오기를 완료하지 못했습니다. Chrome 창·로그인·인터넷 연결을 확인하고 다시 시도하세요. 기존 주문은 유지됩니다.')
        finally:
            self.end_browser_recovery()
            if self.job.get('phase')=='error' and self.notify_confirmation:
                try:self.notify_confirmation()
                except Exception:pass

    def take_result(self, job_id):
        with self.lock:
            if not self.receipt or job_id != self.job.get('id'): raise OrderAutoError('반영할 새 다운로드가 없습니다. 자동 불러오기를 다시 시작하세요.')
            result=self.receipt;self.receipt=None
            self.update('handed_off','주문 파일을 앱에 전달했습니다. 중복 전달하지 않습니다.')
            return result

    def cancel(self):
        with self.lock:
            self.stop.set();self.receipt=None;self.question_event.set();self.login_question=None
            self.end_browser_recovery()
            if self.job.get('phase')=='error_open':self.update('error',self.job['message'])
            elif self.job.get('phase')!='error':self.update('cancelled','자동 불러오기를 중단했습니다. 기존 주문은 유지됩니다.')
        return self.status()
