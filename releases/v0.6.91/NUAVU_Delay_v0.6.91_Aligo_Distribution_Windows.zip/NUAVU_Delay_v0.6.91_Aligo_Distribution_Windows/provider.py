"""Aligo SMS/LMS REST adapter. No legacy transport and no automatic send retries.

Request fields follow the supplied official Python examples: key, userid,
sender, receiver, msg, msg_type, title. A send response is acceptance only.
Final outcomes are read by msg_id -> /sms_list/ -> receiver/sender/type.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import http.client
import json
import re
import ssl
from urllib.parse import urlencode

HOST = 'apis.aligo.in'
MAX_RESPONSE = 2 * 1024 * 1024
PATHS = frozenset({'/send/', '/remain/', '/sms_list/'})

class ProviderError(Exception):
    """Explicit API rejection or validation before a send."""
    def __init__(self, message: str, code: int | None = None):
        super().__init__(message)
        self.code = code

class UncertainError(Exception):
    """Delivery/acceptance is unknown. Never automatically resend."""

@dataclass(frozen=True)
class Credential:
    user: str
    apikey: str = field(repr=False)

def safe_text(value, cred: Credential | None = None) -> str:
    text = str(value or '')
    if cred:
        for secret in (cred.apikey, cred.user):
            if secret:
                text = text.replace(secret, '[숨김]')
    text = re.sub(r'01[016789][\d-]{7,12}', '[연락처 숨김]', text)
    return text[:600]

def integer(value) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str) and re.fullmatch(r'-?\d+', value.strip()):
        return int(value.strip())
    return None

def report_status(value, kind=None) -> str:
    """Only documented/per-recipient text states, never API result_code or 1000.

    Unknown/new provider wording stays pending and is exposed for manual review.
    """
    if not isinstance(value, str):
        return 'PENDING'
    state = re.sub(r'\s+', '', value)
    if state in {'발송완료', '전송완료', '수신완료', '전송성공', '발송성공', '수신성공', '성공'}:
        return 'DELIVERED'
    if state in {'발송실패', '전송실패', '수신실패', '실패'}:
        return 'FAILED'
    return 'PENDING'

class AligoSMS:
    def __init__(self, transport=None):
        self.transport = transport or self._post

    @staticmethod
    def _post(path: str, fields: dict) -> dict:
        if path not in PATHS:
            raise ProviderError('지원되지 않는 알리고 문자 API입니다.')
        # Lazy import prevents a circular import with the existing Alimtalk adapter.
        from aligo_http import verified_context
        body = urlencode(fields, encoding='utf-8').encode('ascii')
        conn = None
        try:
            conn = http.client.HTTPSConnection(HOST, timeout=20, context=verified_context())
            conn.request('POST', path, body, {
                'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8',
                'Content-Length': str(len(body)), 'Accept': 'application/json',
            })
            response = conn.getresponse()
            raw = response.read(MAX_RESPONSE + 1)
            if response.status != 200 or len(raw) > MAX_RESPONSE:
                raise UncertainError('알리고 응답을 확인하지 못했습니다. 자동 재발송하지 않습니다.')
            result = json.loads(raw.decode('utf-8-sig'))
            if not isinstance(result, dict):
                raise ValueError('JSON object required')
            return result
        except (OSError, http.client.HTTPException, ssl.SSLError, ValueError, UnicodeError) as exc:
            raise UncertainError('알리고 문자 연결/응답 오류입니다. API 허용 IP·네트워크·인증서를 확인하세요. '
                                 '접수 여부가 불명확하므로 자동 재발송하지 않습니다.') from exc
        finally:
            if conn:
                conn.close()

    def _call(self, path: str, cred: Credential, fields=None) -> dict:
        if not cred.user or not cred.apikey:
            raise ProviderError('알리고 로그인 ID와 API Key를 먼저 저장하세요.')
        data = self.transport(path, {'key': cred.apikey, 'userid': cred.user, **(fields or {})})
        if not isinstance(data, dict):
            raise UncertainError('알리고 JSON 응답 형식이 다릅니다. 자동 재발송하지 않습니다.')
        code = integer(data.get('result_code'))
        if code == 1:
            return data
        if code is not None and code <= 0:
            raise ProviderError(f'알리고 {code}: '+safe_text(data.get('message') or 'API 요청 거절', cred), code)
        raise UncertainError('알리고 API 접수 결과가 불명확합니다. 자동 재발송하지 않습니다.')

    def send(self, kind: str, cred: Credential, sender: str, receiver: str,
             content: str, title: str, scheme='https') -> dict:
        if scheme != 'https' or kind not in {'SMS', 'LMS'}:
            raise ProviderError('알리고 문자는 HTTPS와 SMS/LMS만 지원합니다.')
        if not re.fullmatch(r'01[016789]\d{7,8}', receiver):
            raise ProviderError('수신번호 하나를 정확히 입력하세요.')
        if not re.fullmatch(r'0\d{8,10}|1[568]\d{6}', sender):
            raise ProviderError('알리고에 등록된 발신번호를 입력하세요.')
        try:
            content_bytes=len(content.encode('cp949'));title_bytes=len(title.encode('cp949'))
        except (AttributeError,UnicodeEncodeError) as exc:
            raise ProviderError('문자에 지원되지 않는 문자/이모지가 있습니다.') from exc
        if not content_bytes or content_bytes>(90 if kind=='SMS' else 2000) or not 1<=title_bytes<=40:
            raise ProviderError('알리고 문자 본문/제목의 바이트 제한을 확인하세요.')
        data = self._call('/send/', cred, {
            'sender': sender, 'receiver': receiver, 'msg': content,
            'msg_type': kind, 'title': title, 'testmode_yn': 'N',
        })
        # Never interpret success_cnt or result_code as terminal delivery success.
        mid = integer(data.get('msg_id'))
        if not mid or mid <= 0 or integer(data.get('success_cnt')) != 1 or integer(data.get('error_cnt')) != 0:
            raise UncertainError('알리고 단일 수신자 접수 건수 또는 메시지 ID를 확인하지 못했습니다. '
                                 '알리고 전송내역을 확인하세요. 자동 재발송하지 않습니다.')
        if data.get('msg_type') and data['msg_type'] != kind:
            raise UncertainError('알리고에서 요청과 다른 문자 유형을 응답했습니다. 전송내역을 확인하세요.')
        return {'mid': str(mid)}

    def remaining(self, kind: str, cred: Credential, scheme='https') -> str:
        if scheme != 'https' or kind not in {'SMS', 'LMS'}:
            raise ProviderError('지원되지 않는 문자 종류/연결 방식입니다.')
        result = self._call('/remain/', cred)
        count = integer(result.get(kind+'_CNT'))
        if count is None or count < 0:
            raise ProviderError('알리고 발송 가능 건수를 확인할 수 없습니다.')
        return str(count)

    def detail(self, cred: Credential, mid: str) -> list[dict]:
        if not re.fullmatch(r'[1-9]\d*', str(mid)):
            raise ProviderError('알리고 문자 메시지 ID가 없습니다. 전송내역에서 수동 확인하세요.')
        rows = []
        # Usually one row (one recipient per send). Bounded pagination avoids
        # silent truncation or infinite loops if a provider response changes.
        for page in range(1, 11):
            data = self._call('/sms_list/', cred, {'mid': str(mid), 'page': page, 'page_size': 500})
            batch = data.get('list')
            if not isinstance(batch, list) or any(not isinstance(x, dict) for x in batch):
                raise UncertainError('알리고 상세 전송결과 목록 형식이 다릅니다.')
            rows.extend(batch)
            nxt = str(data.get('next_yn', '')).upper()
            if nxt == 'N' or (not nxt and len(batch) < 500):
                return rows
            if nxt != 'Y' or not batch:
                raise UncertainError('알리고 상세 전송결과 페이지를 확인하지 못했습니다.')
        raise UncertainError('알리고 상세 조회 상한에 도달했습니다. 홈페이지에서 결과를 확인하세요.')
