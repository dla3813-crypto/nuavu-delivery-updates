"""Verified HTTPS + bounded JSON, with operation-specific, secret-free diagnostics.

No retries, redirects, alternate hosts, TLS-verification bypass, or HTTP fallback.
The official examples use Requests, whose CA bundle is not automatically used by
stdlib HTTPSConnection. Load certifi roots explicitly in the app's own runtime.
"""
from __future__ import annotations
import http.client
import json
import re
import socket
import ssl
import sys
from urllib.parse import urlencode
from provider import ProviderError, UncertainError

HOST = 'kakaoapi.aligo.in'
MAX_RESPONSE = 2 * 1024 * 1024
OPERATION_LABELS = {
    '/akv10/template/list/': '승인 템플릿 조회',
    '/akv10/alimtalk/send/': '알림톡 발송',
    '/akv10/history/detail/': '전송 결과 조회',
}

class AligoConnectionError(UncertainError):
    """A diagnostic code is NOT a provider delivery-failure code."""
    def __init__(self, code: str, path: str, detail: str, *, attempted: bool = False):
        self.diagnostic_code = code
        self.operation = OPERATION_LABELS.get(path, '알리고 연결')
        self.request_attempted = attempted
        if path == '/akv10/alimtalk/send/':
            suffix = ('접수 여부가 불명확하므로 같은 메시지를 다시 보내지 말고 이력을 확인하세요.'
                      if attempted else '발송 HTTP 요청 전 단계에서 중단했습니다. 자동으로 다시 요청하지 않습니다.')
        else:
            suffix = '이 작업은 조회 전용이며 발송 API를 호출하지 않습니다.'
        super().__init__(f'[{code}] {self.operation}: {detail} {suffix}')


def verified_context() -> ssl.SSLContext:
    """Keep system/default trust AND add the runtime's maintained Mozilla CA roots."""
    ctx = ssl.create_default_context()
    # Do not emit TLS session keys through an inherited debug environment variable.
    if getattr(ctx, 'keylog_filename', None):
        ctx.keylog_filename = None
    try:
        import certifi
    except ImportError:
        # Standard Python trust still works when correctly installed. The Mac
        # installer requires certifi; this branch supports existing CLI installs.
        pass
    else:
        ctx.load_verify_locations(cafile=certifi.where())
    return ctx


def tls_environment() -> dict:
    """No user path, endpoint response, credential, or order data in this summary."""
    try:
        import certifi
        bundle = getattr(certifi, '__version__', '설치됨')
    except ImportError:
        bundle = '미설치 (Python 기본 인증서 사용)'
    try:
        count = verified_context().cert_store_stats().get('x509_ca', 0)
    except Exception:
        count = '확인 불가'
    return {'python': '.'.join(map(str, sys.version_info[:3])),
            'tls': ssl.OPENSSL_VERSION, 'certifi': bundle, 'trustedCaCount': count}


def post_json(path: str, fields: dict, allowed_paths) -> dict:
    if path not in allowed_paths or path not in OPERATION_LABELS:
        raise ProviderError('지원되지 않는 알리고 작업입니다.')
    conn = None
    attempted = False
    stage = '연결 준비'
    try:
        body = urlencode(fields).encode('utf-8')
        context = verified_context()
        conn = http.client.HTTPSConnection(HOST, timeout=15, context=context)
        stage = '서버 연결'
        # Explicitly complete DNS/TCP/TLS BEFORE entering the send stage. A TLS
        # or DNS error here cannot mean a password/approval rejection by Aligo.
        conn.connect()
        stage = '요청 전송'
        attempted = True
        conn.request('POST', path, body, {
            'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8',
            'Accept': 'application/json',
            'Accept-Encoding': 'identity',
            'User-Agent': 'NUAVU-DeliveryNotice/0.6.2',
        })
        stage = '응답 수신'
        response = conn.getresponse()
        raw = response.read(MAX_RESPONSE + 1)
        if len(raw) > MAX_RESPONSE:
            raise AligoConnectionError('ALIGO_RESPONSE_TOO_LARGE', path,
                '허용된 응답 크기를 넘었습니다. 응답 원문은 저장하지 않았습니다.', attempted=attempted)
        if response.status != 200:
            hints = {
                401: '서버가 인증 단계에서 연결을 거절했습니다.',
                403: '접근이 거절되었습니다. API 키 오류로 단정할 수 없습니다. 접속망 또는 서버 접근 제한을 확인하세요.',
                429: '요청 제한 응답입니다. 잠시 기다린 뒤 조회로 확인하세요.',
            }
            detail = hints.get(response.status, '정상 응답이 아닙니다. 서버 응답 상태를 확인하세요.')
            if 300 <= response.status < 400:
                detail = '다른 주소로 이동하라는 응답입니다. 키 보호를 위해 자동 이동하지 않았습니다.'
            raise AligoConnectionError(f'ALIGO_HTTP_{response.status}', path,
                f'HTTP {response.status}. {detail}', attempted=attempted)
        content_encoding = (response.getheader('Content-Encoding', '') or '').strip().lower()
        if content_encoding not in ('', 'identity'):
            raise AligoConnectionError('ALIGO_CONTENT_ENCODING', path,
                '예상하지 않은 압축 응답입니다. 키와 응답 원문은 노출하지 않습니다.', attempted=attempted)
        content_type = (response.getheader('Content-Type', '') or '')
        charset_match = re.search(r'charset\s*=\s*["\']?([a-zA-Z0-9_-]+)', content_type, re.I)
        charset = charset_match.group(1).lower() if charset_match else 'utf-8'
        encoding = {'utf8': 'utf-8-sig', 'utf-8': 'utf-8-sig',
                    'euc-kr': 'euc-kr', 'cp949': 'cp949'}.get(charset, 'utf-8-sig')
        stage = '응답 문자 해석'
        text = raw.decode(encoding)  # Strict: never silently change an approved body.
        stage = 'JSON 해석'
        try:
            result = json.loads(text)
        except json.JSONDecodeError as exc:
            kind = 'HTML/웹페이지' if text.lstrip().startswith('<') else ('빈 응답' if not text.strip() else 'JSON 형식 오류')
            raise AligoConnectionError('ALIGO_JSON', path,
                f'HTTP 200이지만 {kind}입니다. JSON 위치 {exc.lineno}:{exc.colno}. 응답 본문은 표시하지 않습니다.',
                attempted=attempted) from None
        if not isinstance(result, dict):
            raise AligoConnectionError('ALIGO_RESPONSE_SHAPE', path,
                '응답 최상위 자료형이 JSON 객체가 아닙니다.', attempted=attempted)
        return result
    except (AligoConnectionError, ProviderError):
        raise
    except ssl.SSLCertVerificationError as exc:
        code = getattr(exc, 'verify_code', None)
        cert_hint = {
            9: '인증서 유효 시작일을 확인하세요. 맥의 날짜/시각도 확인하세요.',
            10: '인증서가 만료되었거나 맥의 날짜/시각이 맞지 않을 수 있습니다.',
            18: '신뢰되지 않는 자체 서명 인증서입니다.',
            19: '인증서 체인에 신뢰되지 않는 인증서가 있습니다.',
            20: '인증서 발급자 체인을 확인하지 못했습니다.',
            21: '인증서 체인을 검증하지 못했습니다.',
            62: '서버 이름과 인증서가 일치하지 않습니다.',
        }.get(code, 'Python 인증서 저장소 또는 서버 인증서 체인을 확인하세요.')
        raise AligoConnectionError('ALIGO_TLS_CERT', path,
            f'HTTPS 인증서 검증 실패 (검증 코드 {code if isinstance(code, int) else "확인 불가"}). {cert_hint} 인증서 검증은 끄지 않았습니다.',
            attempted=attempted) from None
    except ssl.SSLError:
        raise AligoConnectionError('ALIGO_TLS', path,
            'HTTPS 보안 연결이 성립하지 않았습니다. 인증서/보안 연결 오류이며 API 키 오류와 별개입니다.',
            attempted=attempted) from None
    except socket.gaierror:
        raise AligoConnectionError('ALIGO_DNS', path,
            '알리고 서버 주소를 찾지 못했습니다. 인터넷·DNS·VPN 연결을 확인하세요.', attempted=attempted) from None
    except (TimeoutError, socket.timeout):
        raise AligoConnectionError('ALIGO_TIMEOUT', path,
            f'{stage} 단계에서 제한시간을 초과했습니다.', attempted=attempted) from None
    except (ConnectionError, http.client.HTTPException):
        raise AligoConnectionError('ALIGO_CONNECTION', path,
            f'{stage} 단계에서 연결이 끊기거나 올바른 HTTP 응답을 받지 못했습니다.', attempted=attempted) from None
    except UnicodeError:
        raise AligoConnectionError('ALIGO_TEXT_ENCODING', path,
            f'{stage} 단계의 문자 인코딩을 해석하지 못했습니다. 내용을 임의로 바꾸지 않았습니다.', attempted=attempted) from None
    except OSError:
        raise AligoConnectionError('ALIGO_NETWORK_SETUP', path,
            f'{stage} 단계의 네트워크/인증서 파일 접근에 실패했습니다.', attempted=attempted) from None
    except Exception:
        # Do not interpolate exception text: it can contain posted credentials.
        raise AligoConnectionError('ALIGO_LOCAL_ERROR', path,
            f'{stage} 단계에서 연결 처리 오류가 발생했습니다.', attempted=attempted) from None
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
