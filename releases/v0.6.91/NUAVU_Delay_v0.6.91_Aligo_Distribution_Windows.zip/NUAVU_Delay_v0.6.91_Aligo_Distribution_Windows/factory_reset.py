"""Explicit factory reset for this distribution only.

No external originals, manual exports, other devices, runtimes or other app
profiles are deleted. A durable marker prevents workers from starting after an
interrupted reset. Real sends already accepted by a provider cannot be recalled.
"""
from __future__ import annotations
from functools import wraps
import inspect,json,os,re,sqlite3,sys,threading
from pathlib import Path
from urllib.parse import quote
from desktop_backup import atomic_bytes

MARKER='factory-reset-pending.json'
PHRASE='전체 초기화'
EDITION='aligo-distribution'
BLOCKED='전체 초기화 중입니다. 초기화를 완료한 뒤 앱을 종료하고 다시 실행하세요.'
class ResetError(ValueError):pass

def operation_lock(engine):
    if not hasattr(engine,'ui_operation_lock'):engine.ui_operation_lock=threading.RLock()
    return engine.ui_operation_lock

def serialized(method):
    """Serialize native UI operations with HTTP requests and reset."""
    @wraps(method)
    def wrapped(self,*args,**kwargs):
        with operation_lock(self._engine):
            if getattr(self._engine,'reset_in_progress',False) and method.__name__ not in {'factory_reset','factory_reset_close'}:
                return {'error':BLOCKED}
            return method(self,*args,**kwargs)
    # pywebview builds its JS methods with inspect.getfullargspec, which does
    # not follow functools.wraps on its own.
    wrapped.__signature__=inspect.signature(method)
    return wrapped

def vaults_for(directory):
    from credentials import default_vault,UnavailableVault
    from aligo_credentials import default_aligo_vault
    from ezadmin_credentials import default_ezadmin_vault
    from ably_credentials import AblyKeychain
    from zigzag_credentials import ZigzagKeychain
    from cafe24_credentials import Cafe24Keychain,SERVICE as cafe24_service
    from ably_credentials import SERVICE as ably_service
    from zigzag_credentials import SERVICE as zigzag_service
    from windows_credentials import platform_vault
    return [default_vault(directory),default_aligo_vault(directory),default_ezadmin_vault(directory),
            platform_vault(directory,ably_service,'배송안내 배포판 에이블리 로그인',AblyKeychain),
            platform_vault(directory,zigzag_service,'배송안내 배포판 지그재그 로그인',ZigzagKeychain),
            platform_vault(directory,cafe24_service,'배송안내 배포판 자사몰(카페24) 로그인',Cafe24Keychain)]

def sync_directory(directory):
    from platform_support import sync_directory as _sync;_sync(directory)   # Windows: no directory fsync

def regular(path):
    if path.is_symlink() or (path.exists() and not path.is_file()):
        raise ResetError('앱 저장 파일의 형식이 달라 초기화를 중단했습니다. 기존 파일을 임의로 바꾸지 말고 확인하세요.')

def directory_safe(path):
    if path.is_symlink() or (path.exists() and not path.is_dir()):
        raise ResetError('앱 백업 폴더의 연결 형식이 달라 초기화를 중단했습니다.')

def read_marker(directory):
    p=directory/MARKER;regular(p)
    if not p.exists():return None
    try:
        if p.stat().st_size>1024:raise ValueError()
        v=json.loads(p.read_text())
        if set(v)!={'format','edition','device'} or v['format']!=1 or v['edition']!=EDITION or not re.fullmatch(r'(?:[a-f0-9]{16})?',v['device']):raise ValueError()
        return v
    except (ValueError,TypeError,KeyError):raise ResetError('전체 초기화 기록을 확인하지 못했습니다. 앱 작업을 시작하지 않았습니다.') from None

def assert_edition(directory):
    p=directory/'nuavu.sqlite3';regular(p)
    if not p.exists():return
    try:
        db=sqlite3.connect('file:'+quote(str(p.resolve()),safe='/')+'?mode=ro',uri=True)
        try:s=json.loads(db.execute('SELECT body FROM app_state WHERE id=1').fetchone()[0])
        finally:db.close()
        if s.get('edition')!=EDITION:raise ResetError('이 데이터는 배송안내 배포판의 데이터가 아니므로 초기화하지 않습니다.')
    except (sqlite3.Error,ValueError,TypeError) as exc:
        if isinstance(exc,ResetError):raise
        raise ResetError('배포판 데이터 확인에 실패해 초기화를 중단했습니다.') from None

def paths_to_remove(directory,backup_root,device):
    """Fixed local names and exact generated backup names, never UI paths."""
    directory_safe(directory);directory_safe(directory/'backups');directory_safe(backup_root)
    paths=[directory/name for name in ('nuavu.sqlite3','nuavu.sqlite3-wal','nuavu.sqlite3-shm','nuavu.sqlite3-journal','runtime.json')]
    local=directory/'backups'
    if local.exists():
        for p in local.iterdir():
            if re.fullmatch(r'(?:\d{4}-\d{2}-\d{2}|before-v\d+(?:\.\d+)+-\d{8}T\d{12}Z)\.sqlite3',p.name):paths.append(p)
    for p in directory.iterdir():
        if re.fullmatch(r'archive-[a-z0-9_]{8}\.sqlite3(?:-wal|-shm)?',p.name):paths.append(p)
    folders=[local]
    if device:
        folder=backup_root/('이맥백업-'+device);directory_safe(folder);folders.append(folder)
        if folder.exists():
            for p in folder.iterdir():
                if p.name in {'최근백업정보.json','백업_주의사항.txt'} or re.fullmatch(r'(?:백업-\d{8}T\d{12}Z-r\d+|일별-\d{4}-\d{2}-\d{2})\.sqlite3',p.name) or re.fullmatch(r'\.nuavu-[a-z0-9_]{8}\.tmp',p.name):paths.append(p)
    paths.append(directory/'desktop-backup-device.txt')
    for p in paths:regular(p)
    return paths,folders

def complete_pending_reset(directory,*,vaults=None,backup_root=None):
    """Run before Store/Engine/backup startup, or after all workers/DB are closed."""
    directory=Path(directory);directory_safe(directory)
    marker=read_marker(directory)
    if marker is None:return False
    assert_edition(directory)
    root=Path(backup_root) if backup_root is not None else Path.home()/'Desktop/배송안내_배포판_백업'
    paths,folders=paths_to_remove(directory,root,marker['device'])
    # Remove only the four profile-specific distribution accounts, not the
    # user's Keychain itself. Any refusal keeps the marker and blocks startup.
    try:
        for vault in vaults if vaults is not None else vaults_for(directory):vault.delete()
    except Exception:raise ResetError('저장 계정을 지우지 못해 초기화가 아직 완료되지 않았습니다. 키체인 접근을 허용하고 다시 초기화하거나 앱을 다시 실행하세요.') from None
    try:
        for p in paths:p.unlink(missing_ok=True)
        for folder in folders:
            if folder.exists() and not any(folder.iterdir()):folder.rmdir()
        sync_directory(directory)
        (directory/MARKER).unlink();sync_directory(directory)
    except OSError:raise ResetError('일부 앱 데이터 또는 자동 백업을 지우지 못했습니다. 초기화는 아직 완료되지 않았습니다. 폴더 권한을 확인하고 다시 초기화하거나 앱을 다시 실행하세요.') from None
    return True

class FactoryReset:
    def __init__(self,engine,*,vaults=None,backup_root=None,join_timeout=5):
        self.engine=engine;self.directory=engine.store.directory
        self.vaults=vaults;self.backup_root=backup_root;self.join_timeout=join_timeout;self.complete=False
    def run(self,confirmation,controllers=()):
        if confirmation!=PHRASE:raise ResetError('확인란에 전체 초기화를 정확히 입력하세요.')
        if self.complete:return {'reset':True,'message':'전체 초기화가 완료되었습니다. 앱을 종료한 뒤 다시 실행하세요.'}
        engine=self.engine
        with operation_lock(engine):
            engine.reset_in_progress=True;engine.stop.set()
            # Both browser controllers expose status() via cancel; after a
            # closed Store, do not call them again on a deletion retry.
            if not getattr(engine,'reset_store_closed',False):
                for controller in controllers:
                    if controller:
                        # 10:26 보고: an idle 지그재그 controller's cancel() raises '진행 중인 작업이 없습니다' — a no-op for the reset, never a failure.
                        try:
                            if hasattr(controller,'shutdown'):controller.shutdown()
                        except Exception:pass
                        try:controller.cancel()
                        except Exception:pass
            threads=[engine.thread,getattr(getattr(engine,'supply_watcher',None),'thread',None)]+[c.thread for c in controllers if c]+[c.scheduler_thread for c in controllers if c and getattr(c,'scheduler_thread',None)]
            for thread in threads:
                if thread and thread.is_alive():thread.join(timeout=self.join_timeout)
            if any(t and t.is_alive() for t in threads):
                raise ResetError('진행 중인 발송·조회 작업이 아직 끝나지 않았습니다. 데이터는 삭제하지 않았습니다. 잠시 뒤 초기화를 다시 누르세요.')
            if not engine.network_lock.acquire(timeout=self.join_timeout):
                raise ResetError('진행 중인 작업이 끝난 뒤 초기화를 다시 누르세요. 데이터는 삭제하지 않았습니다.')
            try:
                marker=read_marker(self.directory)
                root=Path(self.backup_root) if self.backup_root is not None else Path.home()/'Desktop/배송안내_배포판_백업'
                if marker is None:
                    assert_edition(self.directory)
                    key=self.directory/'desktop-backup-device.txt';regular(key)
                    device=key.read_text().strip() if key.exists() else ''
                    if not re.fullmatch(r'(?:[a-f0-9]{16})?',device):raise ResetError('자동 백업 식별자를 확인하지 못했습니다.')
                    paths_to_remove(self.directory,root,device)
                    atomic_bytes(self.directory/MARKER,json.dumps({'format':1,'edition':EDITION,'device':device}).encode())
                    sync_directory(self.directory)
                # No shutdown backup may reintroduce data after deletion.
                engine.archive=None;engine.creds.clear();engine.aligo_cred=None;engine.plans.clear()
                if not getattr(engine,'reset_store_closed',False):
                    engine.store.close();engine.reset_store_closed=True
                complete_pending_reset(self.directory,vaults=self.vaults,backup_root=root)
                self.complete=True
                return {'reset':True,'message':'전체 초기화가 완료되었습니다. 앱을 종료한 뒤 다시 실행하세요.'}
            finally:engine.network_lock.release()
