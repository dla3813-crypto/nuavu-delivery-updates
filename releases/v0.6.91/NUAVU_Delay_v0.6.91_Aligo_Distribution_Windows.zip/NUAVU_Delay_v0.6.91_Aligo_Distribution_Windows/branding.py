"""Shop identity and read-only table preferences for the shareable edition."""
from __future__ import annotations
import re
import unicodedata

SHOP_TOKEN = '{쇼핑몰명}'
LINK_TOKEN = '{자사몰링크}'
NUAVU_URL = 'http://nuavu.kr'
LEGACY_URL = re.compile(r'(?:https?://)?(?:www\.)?nuavu\.kr(?:/[^\s\]\)<>]*)?', re.I)


def clean_name(value) -> str:
    from domain import ValidationError
    if not isinstance(value, str):
        raise ValidationError('쇼핑몰 이름을 입력하세요.')
    value = unicodedata.normalize('NFC', value).strip()
    if not 1 <= len(value) <= 30 or any(unicodedata.category(c).startswith('C') for c in value):
        raise ValidationError('쇼핑몰 이름은 줄바꿈 없이 1~30자로 입력하세요.')
    if re.search(r'[{}<>\[\]\\/]', value) or '://' in value:
        raise ValidationError('쇼핑몰 이름에는 치환 기호나 링크를 넣을 수 없습니다.')
    try:
        value.encode('cp949')
    except UnicodeEncodeError as exc:
        raise ValidationError('문자로 보낼 수 있는 쇼핑몰 이름을 사용하세요. 이모지는 제외해주세요.') from exc
    return value


def is_nuavu(name) -> bool:
    return re.sub(r'\s+', '', str(name)).casefold() in {'누아브', 'nuavu'}


def canonical_template(text: str, old_name='') -> str:
    """Convert the sender identity in a draft, never alter an order or sent ledger."""
    text = str(text)
    # Replace own-site links before replacing Roman brand text.
    text = re.sub(r'\[https?://(?:www\.)?nuavu\.kr/?\]\(https?://(?:www\.)?nuavu\.kr/?\)', LINK_TOKEN, text, flags=re.I)
    text = LEGACY_URL.sub(LINK_TOKEN, text)
    text = text.replace('누아브', SHOP_TOKEN)
    text = re.sub(r'\bnuavu\b', SHOP_TOKEN, text, flags=re.I)
    if old_name and not is_nuavu(old_name):
        # Only sender-identifying positions, not arbitrary words in a custom draft.
        text = text.replace(old_name+'입니다', SHOP_TOKEN+'입니다')
        if text.startswith(old_name+' '):
            text = SHOP_TOKEN+text[len(old_name):]
    return text


def render_template(text: str, name: str) -> str:
    text = canonical_template(text)
    text = text.replace(SHOP_TOKEN, name or SHOP_TOKEN)
    text = text.replace(LINK_TOKEN, NUAVU_URL if is_nuavu(name) else '')
    return text.rstrip()


def safe_outgoing(text: str, name: str) -> None:
    from domain import ValidationError
    if not is_nuavu(name) and (re.search(r'누아브|\bnuavu\b', text, re.I) or LEGACY_URL.search(text)):
        raise ValidationError('다른 쇼핑몰의 안내에 누아브 이름/주소가 남아 있어 발송을 막았습니다. 문구·상품명·링크를 확인하세요.')
    if SHOP_TOKEN in text or LINK_TOKEN in text:
        raise ValidationError('쇼핑몰 이름 설정 후 문구를 다시 확인하세요.')


def normalize_seller(value, name=''):
    """Platform keys remain stable; accept only the configured shop's aliases."""
    canonical=['누아브 에이블리','누아브 자사몰','누아브 지그재그']
    compact=lambda x:re.sub(r'\s+','',unicodedata.normalize('NFC',str(x or '')).strip())
    source_value=value;source_name=name
    value=compact(value);name=compact(name)
    for key in canonical:
        channel=key.split(' ',1)[1]
        if value in {compact(key),channel} or (name and value==name+channel):return key
    return import_seller(source_value,source_name)


def seller_label(value):
    return ' '.join(unicodedata.normalize('NFC', str(value or '')).split())


def seller_identity(value):
    return re.sub(r'\s+', '', seller_label(value))


def import_seller(value, name=''):
    """Recognize the shop at either end; preserve legacy keys for known channels."""
    label=seller_label(value);shop=seller_label(name)
    k=seller_identity(label);n=seller_identity(shop)
    if not n or not label or len(label)>150 or any(unicodedata.category(c).startswith('C') for c in label):return None
    names=[n]+(['누아브'] if is_nuavu(n) else [])
    for channel in ('에이블리','자사몰','지그재그','아무드'):
        if k==channel or any(k in {x+channel,channel+x} for x in names):return '누아브 '+channel
    # Other channels are allowed only with a separate, exact shop-name prefix/suffix.
    for i,c in enumerate(label):
        if c!=' ':continue
        left,right=label[:i],label[i+1:]
        channel=right if seller_identity(left) in names else left if seller_identity(right) in names else ''
        if channel:return '누아브 '+seller_identity(channel)
    return None


def seller_choices(value, name):
    from domain import ValidationError
    if not isinstance(value,list) or len(value)>200:raise ValidationError('엑셀 판매처 목록을 확인하세요.')
    if any(not isinstance(x,str) or not import_seller(x,name) for x in value):
        raise ValidationError('설정한 쇼핑몰과 일치하는 엑셀 판매처만 선택하세요.')
    labels=[seller_label(x) for x in value]
    if len({seller_identity(x) for x in labels})!=len(labels):raise ValidationError('판매처 목록이 중복되었습니다.')
    return labels


def selected_seller_labels(settings, available):
    prefs=settings.get('importSellerChoices',{}).get(seller_identity(settings.get('shopName','')), {})
    legacy=settings.get('importScope',['누아브 에이블리','누아브 아무드','누아브 자사몰','누아브 지그재그'])
    return [x for x in available if prefs.get(seller_identity(x),
        import_seller(x,settings.get('shopName','')) in legacy if import_seller(x,settings.get('shopName','')) in ('누아브 에이블리','누아브 아무드','누아브 자사몰','누아브 지그재그') else True)]


def row_in_seller_scope(row, labels, name):
    source=row.get('sourceSeller') or (row.get('exportContacts') or {}).get('sellerLabel')
    if source:return seller_identity(source) in {seller_identity(x) for x in labels}
    # Older saved rows have only the stable platform key. Do not rewrite their IDs.
    return row.get('seller') in {import_seller(x,name) for x in labels}


def import_scope(value):
    from domain import ValidationError,SELLERS
    if not isinstance(value,list) or len(value)>4 or any(not isinstance(x,str) or x not in SELLERS for x in value) or len(set(value))!=len(value):
        raise ValidationError('불러올 판매처 선택을 확인하세요.')
    return [x for x in SELLERS if x in value]


def message_title(name: str, soldout=False) -> str:
    suffix = ' 품절 안내' if soldout else ' 배송지연 안내'
    prefix = name or '쇼핑몰'
    while len((prefix+suffix).encode('cp949')) > 40 and prefix:
        prefix = prefix[:-1]
    return prefix+suffix


class ShopWorkflow:
    def ensure_shop_state(self, s):
        cfg=s['settings']
        cfg.setdefault('shopName', '')
        cfg.setdefault('shopRevision', 0)
        cfg.setdefault('tableZoom', 100)
        cfg.setdefault('importScope', ['누아브 에이블리','누아브 자사몰','누아브 지그재그'])
        cfg.setdefault('smsProvider', 'ALIGO')
        cfg.setdefault('importSellerChoices', {})

    def message_templates(self):
        from domain import FIRST, CHANGE, SOLDOUT_CARD, SOLDOUT_BANK
        name=self.store.read()['settings'].get('shopName', '')
        return {key:render_template(body, name) for key,body in (
            ('first',FIRST), ('change',CHANGE), ('soldout_card',SOLDOUT_CARD), ('soldout_bank',SOLDOUT_BANK), ('manual',''))}

    def configure_shop(self, p):
        from domain import now
        name=clean_name(p.get('shopName'))
        paused=0
        with self.network_lock, self.store.edit() as s:
            cfg=s['settings'];old=cfg.get('shopName','')
            if old != name:
                cfg['template']=canonical_template(cfg.get('template',''), old)
                cfg['smsTemplates']={k:canonical_template(v,old) for k,v in cfg.get('smsTemplates',{}).items()}
                cfg['shopName']=name;cfg['shopRevision']=cfg.get('shopRevision',0)+1
                self.plans.clear()
                for n in s['notices']:
                    if n['status'] in {'QUEUED','SCHEDULED','PAUSED'}:
                        self.transition(n,'PAUSED','쇼핑몰 이름이 변경되었습니다. 기존 예약은 취소 후 새 이름으로 다시 작성하세요.')
                        n['pauseReason']='shop_changed';paused+=1
                s['queuePaused']=any(n['status']=='PAUSED' for n in s['notices'])
                s['audits'].append({'at':now(),'event':'쇼핑몰 이름 설정 (발송 없음)','oldName':old,'shopName':name})
        return {'shopName':name,'paused':paused,'message':'쇼핑몰 이름을 저장했습니다. 새 문자부터 적용합니다.'+
                (f' 기존 미요청/예약 {paused}건은 취소 후 새로 작성하세요.' if paused else '')}

    def configure_view(self,p):
        from domain import ValidationError
        zoom=p.get('tableZoom')
        if isinstance(zoom,bool) or not isinstance(zoom,int) or not 60<=zoom<=160 or zoom%5:
            raise ValidationError('화면 배율은 60~160%, 5% 단위로 설정하세요.')
        with self.store.edit() as s:
            s['settings']['tableZoom']=zoom
        return {'tableZoom':zoom,'message':'화면 배율을 저장했습니다.'}

    def configure_import_scope(self,p):
        from domain import ValidationError
        if p.get('scopeLabels') is True:
            with self.store.edit() as s:
                cfg=s['settings'];name=cfg.get('shopName','')
                if p.get('shopRevision')!=cfg.get('shopRevision',0):raise ValidationError('쇼핑몰 설정이 바뀌었습니다. 엑셀을 다시 여세요.')
                available=seller_choices(p.get('available'),name);scope=seller_choices(p.get('scope'),name)
                if not set(scope)<=set(available):raise ValidationError('현재 엑셀에 있는 판매처만 선택하세요.')
                prefs=cfg.setdefault('importSellerChoices',{}).setdefault(seller_identity(name),{})
                for label in available:prefs[seller_identity(label)]=label in scope
                choices=cfg['importSellerChoices']
            return {'scope':scope,'choices':choices,'message':'엑셀 판매처별 체크 상태를 저장했습니다.'}
        scope=import_scope(p.get('scope'))
        with self.store.edit() as s:
            s['settings']['importScope']=scope
        return {'scope':scope,'message':'판매처 선택을 저장했습니다. 직접 바꾸기 전까지 유지합니다.'}
