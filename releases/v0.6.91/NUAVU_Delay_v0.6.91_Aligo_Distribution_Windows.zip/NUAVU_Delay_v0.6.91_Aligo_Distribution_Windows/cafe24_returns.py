"""자사몰(카페24) 반품 목록 → 반품/교환 화면 + 자동 회수접수 대상 (2026-10-21 19:25 요청).

Owner's route:
- 카페24 로그인 → 대시보드가 뜬 뒤 반드시 order_returns.php(반품 관리)로 이동, 기간 1개월 (20:04 정정: 3개월 → 1개월).
- 목록의 운송장정보 = 원운송장 → 이지어드민 회수접수 (기존 회수접수 흐름, 판매처 '자사몰').
- 반품사유는 order_return_handling.php?order_id=<주문번호>&menu_no=78&sSelectOrdItemCode=<품목별 주문번호>
  &sIsOpenFromCsList=T 의 '신청정보 · 접수내용 : <사유> | <상세>'.
Read-only: never presses 반품접수·처리·수거완료 on cafe24.
"""
from __future__ import annotations
import hashlib,json,re
from urllib.parse import urlsplit,quote
from return_data import ReturnError,invoice as clean_invoice

SELLER='자사몰'
HOST='nuavu.cafe24.com'
FORCE_HOST=False   # 배포판: 로그인한 쇼핑몰의 카페24 주소
LIST_PATH='/admin/php/shop1/s_new/order_returns.php'
EXCHANGE_PATH='/admin/php/shop1/s/order_change.php'   # 자사몰 교환 (2026-10-21 20:15, 반품과 같은 화면 · 운송장 열 없음)
DETAIL_PATH='/admin/php/shop1/s_new/order_detail.php'
HANDLING_PATH='/admin/php/shop1/s_new/order_return_handling.php'
ACTIVE=('반품신청','반품접수','반품처리중','처리중')
ACTIVE_EXCHANGE=('교환신청','교환접수','교환처리중','처리중')
CLOSED=('완료','철회','거부','보류','취소')
SELLER_FAULT=('불량','오배송','파손','누락','다른 상품','다른상품','상품정보','배송지연','하자','오염')

ROWS_JS=r"""(reqHead)=>{
  const t=document.querySelector('#searchResultList');if(!t)return null;
  const heads=[...t.querySelectorAll('thead th')].map(th=>(th.innerText||'').replace(/\s+/g,''));
  const col=n=>heads.findIndex(h=>h.startsWith(n));
  const ix={req:col(reqHead||'반품신청일'),code:col('품목별주문번호'),buyer:col('주문자'),prod:col('상품명/옵션'),qty:col('수량'),inv:col('운송장정보'),st:col('주문상태')};
  if(['req','code','buyer','prod','qty','st'].some(k=>ix[k]<0))return {error:'열 이름: '+heads.join(',')};
  const rows=[...t.querySelectorAll('tbody tr')].filter(r=>r.cells.length>=heads.length-1&&r.cells[ix.code]);
  const txt=e=>(e?e.innerText:'').replace(/\s+/g,' ').trim();
  const out=rows.map(r=>{
    const c=r.cells,code=c[ix.code].querySelector('a[data-orderid]');
    const prod=c[ix.prod];const name=[...prod.querySelectorAll('p a')].find(a=>!a.classList.contains('eLayerClick'));
    return {requested:txt(c[ix.req]),itemId:code?txt(code):txt(c[ix.code]).split(' ').pop(),orderId:code?code.getAttribute('data-orderid'):'',
      customer:txt(c[ix.buyer].querySelector('.buyerName'))||txt(c[ix.buyer]).split(' ')[0],
      product:name?txt(name):txt(prod),options:[...prod.querySelectorAll('ul.etc li')].map(txt),qty:txt(c[ix.qty]),
      invoiceText:ix.inv>=0?txt(c[ix.inv]):'',status:txt(c[ix.st])};
  }).filter(x=>x.itemId);
  const empty=/검색된\s*(주문|내역)이\s*없|데이터가\s*없/.test(t.innerText||'');
  const pages=[...document.querySelectorAll('.mPaginate a, .mPaginate strong')].map(a=>(a.innerText||'').trim()).filter(x=>/^\d+$/.test(x));
  const current=(document.querySelector('.mPaginate strong')||{}).innerText||'1';
  return {rows:out,empty,pages,current:String(current).trim()};
}"""

REASON_JS=r"""(code)=>{
  const items=[...document.querySelectorAll('li')].filter(li=>/접수내용\s*:/.test(li.textContent||''));
  if(!items.length)return null;
  // the reason row follows the product row of this 품목 (checked by sSelectOrdItemCode); one item → that one
  let pick=items[0];
  if(items.length>1){
    const box=[...document.querySelectorAll('input[type=checkbox]')].find(i=>i.checked&&i.closest('tr'));
    let tr=box?box.closest('tr').nextElementSibling:null;
    while(tr&&!/접수내용/.test(tr.textContent||'')&&!tr.querySelector('input[type=checkbox]'))tr=tr.nextElementSibling;
    if(tr&&/접수내용/.test(tr.textContent||''))pick=[...tr.querySelectorAll('li')].find(li=>/접수내용/.test(li.textContent||''))||pick;
  }
  const strong=pick.querySelector('strong');
  const all=(pick.textContent||'').replace(/\s+/g,' ').replace(/^.*?접수내용\s*:\s*/,'').trim();
  const kind=strong?(strong.textContent||'').trim():all.split('|')[0].trim();
  const detail=all.includes('|')?all.slice(all.indexOf('|')+1).trim():'';
  return {kind,detail};
}"""

EXCHANGE_INVOICE_JS=r"""(code)=>{
  const tables=[...document.querySelectorAll('table')].filter(t=>/교환번호/.test([...t.querySelectorAll('th')].map(th=>th.innerText).join('')));
  for(const t of tables){
    const heads=[...t.querySelectorAll('thead th, tr:first-child th')].map(th=>(th.innerText||'').replace(/\s+/g,''));
    const ii=heads.findIndex(h=>h.startsWith('운송장번호'));
    for(const r of t.querySelectorAll('tbody tr')){
      if(!(r.innerText||'').includes(code))continue;
      const cells=[...r.cells];const off=cells.length-heads.length;   // a leading checkbox column may have no header
      const cell=ii>=0?cells[ii+(off>0?off:0)]||cells[ii]:null;
      const v=cell?(cell.innerText||'').replace(/\s+/g,' ').trim():'';
      const m=v.match(/\d[\d\-]{8,}/);return {invoice:m?m[0].replace(/-/g,''):'',status:(cells.find(c=>/교환/.test(c.innerText||''))||{}).innerText||''};
    }
  }
  return null;
}"""

def parse_option(values):
    parts={};rest=[]
    for v in values or []:
        m=re.match(r'\s*(색상|컬러|사이즈)\s*:\s*(.*)$',str(v))
        if m:parts['color' if m.group(1) in ('색상','컬러') else 'size']=m.group(2).strip()
        elif str(v).strip():rest.append(str(v).strip())
    out=' / '.join(x for x in (parts.get('color',''),parts.get('size','')) if x)
    return ' / '.join(x for x in (out,*rest) if x)

def product_name(text):
    """'프릴 하트 … 티셔츠 (P0000DHG)' → name without the product code."""
    return re.sub(r'\s*\(P[0-9A-Z]{6,}\)\s*$','',str(text or '').strip())

def reason_text(kind,detail):
    """'판매자(…)'/'고객(…)' like the 지그재그 rows: the row turns bold red for seller-fault reasons."""
    k=str(kind or '').strip() or '사유 없음';d=str(detail or '').strip()
    who='판매자' if any(w in k for w in SELLER_FAULT) else '고객'
    return f'{who}({k}{" · "+d if d else ""})'

def is_active(status,kind='return'):
    s=str(status or '').replace(' ','')
    return any(a in s for a in (ACTIVE_EXCHANGE if kind=='exchange' else ACTIVE)) and not any(c in s for c in CLOSED)

def row_key(item_id,kind='return'):
    return ('cafe24-exchange:' if kind=='exchange' else 'cafe24:')+hashlib.sha256(json.dumps([item_id],ensure_ascii=False).encode()).hexdigest()

def entry(raw,reason=None,kind='return',invoice_number=None):
    m=re.search(r'(\d{4})-(\d{2})-(\d{2})',raw.get('requested',''))
    number=clean_invoice(invoice_number if invoice_number is not None else (re.search(r'\d[\d\-]{8,}',raw.get('invoiceText','')) or [''])[0].replace('-',''))
    qty=int((re.search(r'\d+',raw.get('qty','')) or ['1'])[0])
    r={'seller':SELLER,'kind':kind,'cafe24Status':str(raw.get('status','')).strip(),'itemId':str(raw.get('itemId','')).strip(),
       'orderId':str(raw.get('orderId','')).strip() or re.sub(r'-\d+$','',str(raw.get('itemId','')).strip()),
       'product':product_name(raw.get('product')),'option':parse_option(raw.get('options')),'qty':qty,
       'requestedAt':f'{m.group(1)}-{m.group(2)}-{m.group(3)}' if m else '','requestedAtFull':str(raw.get('requested','')).strip()[:19],
       'reason':reason_text((reason or {}).get('kind'),(reason or {}).get('detail')) if reason else ('교환(사유는 카페24 교환 화면에서 확인)' if kind=='exchange' else '고객(사유 확인 실패)'),
       'cafe24Reason':(reason or {}).get('kind',''),'cafe24ReasonDetail':(reason or {}).get('detail',''),
       'fee':0,'customer':str(raw.get('customer','')).strip(),'recipient':str(raw.get('customer','')).strip(),'recipientPhone':'',
       'invoice':number,'origCarrierName':'','returnNo':'','requestId':str(raw.get('itemId','')).strip()}
    if not r['itemId'] or not r['orderId'] or not r['product'] or not r['requestedAt']:
        raise ReturnError(f"자사몰 {'교환' if kind=='exchange' else '반품'} 목록의 품목별 주문번호·상품명·신청일을 확인하지 못했습니다.")
    if kind=='exchange':r.update(exchangeStatus=r['cafe24Status'],exchangeOption='')
    r['key']=row_key(r['itemId'],kind);return r

class Cafe24Returns:
    def __init__(self,flow,host=None,kind='return'):
        self.flow=flow;self.page=flow.page;self.host=host or HOST;self.kind=kind
        self.path=EXCHANGE_PATH if kind=='exchange' else LIST_PATH;self.word='교환' if kind=='exchange' else '반품'
    def list_url(self):return f'https://{self.host}{self.path}'
    def handling_url(self,order_id,item_id):
        return f'https://{self.host}{HANDLING_PATH}?order_id={quote(order_id)}&menu_no=78&sSelectOrdItemCode={quote(item_id)}&sIsOpenFromCsList=T'
    def trusted(self,page,path):
        u=urlsplit(page.url);return u.scheme=='https' and u.hostname==self.host and u.path==path
    def read(self):
        return self.page.evaluate(ROWS_JS,'교환신청일' if self.kind=='exchange' else '반품신청일')
    def open_list(self):
        f=self.flow;f.step=f'자사몰 {self.word} 관리 열기';f.progress(f'자사몰 {self.word} 관리({self.path.rsplit("/",1)[-1]})로 이동합니다.')
        self.page.goto(self.list_url(),wait_until='domcontentloaded',timeout=45000)
        f.wait(lambda:self.trusted(self.page,self.path) and self.read() is not None,30,f'자사몰 {self.word} 관리 화면이 열리지 않았습니다.')
        f.step=f'자사몰 {self.word} 기간 1개월 선택'
        btn=self.page.locator('a.btnDate').filter(has_text=re.compile(r'^\s*1개월\s*$'))
        if btn.count()<1:raise ReturnError(f'자사몰 {self.word} 관리에서 1개월 버튼을 찾지 못했습니다.')
        btn.first.click(timeout=10000)
        rows=self.page.locator('select[name="rows"]')
        if rows.count()==1:
            try:rows.select_option('100',timeout=5000)
            except Exception:pass
        f.progress(f'자사몰 {self.word} 1개월 조회')
        try:
            with self.page.expect_navigation(wait_until='domcontentloaded',timeout=45000):
                self.page.locator('#search_button').first.click(timeout=10000)
        except Exception:
            self.page.wait_for_timeout(2500)   # the result reloads the page; give it time if no navigation event came
        sel=self.page.locator('a.btnDate.selected').filter(has_text=re.compile(r'^\s*1개월\s*$'))
        if sel.count()<1:raise ReturnError(f'자사몰 {self.word} 기간이 1개월로 조회되지 않았습니다.')
        f.wait(lambda:self.trusted(self.page,self.path) and (d:=self.read()) is not None and not d.get('error'),30,f'자사몰 {self.word} 조회 결과가 열리지 않았습니다.')
        self.page.wait_for_timeout(800)
    def all_rows(self):
        got=[];seen=set();pages_done=set()
        for _ in range(60):
            d=self.read()
            if not d:raise ReturnError('자사몰 반품 목록을 읽지 못했습니다.')
            if d.get('error'):raise ReturnError('자사몰 반품 목록 형식이 다릅니다 · '+d['error'][:150])
            for r in d['rows']:
                if r['itemId'] not in seen:seen.add(r['itemId']);got.append(r)
            pages_done.add(d.get('current','1'))
            nxt=[p for p in d.get('pages',[]) if p not in pages_done and int(p)>int(d.get('current','1') or 1)]
            if not nxt:
                more=self.page.locator('.mPaginate a.next, .mPaginate a:has-text("다음")')
                if more.count() and more.first.is_visible():
                    before=d.get('current')
                    try:
                        with self.page.expect_navigation(wait_until='domcontentloaded',timeout=45000):more.first.click(timeout=10000)
                    except Exception:self.page.wait_for_timeout(2500)
                    if (self.read() or {}).get('current')==before:break
                    continue
                break
            target=min(nxt,key=int);self.flow.progress(f'자사몰 반품 목록 {target}페이지')
            try:
                with self.page.expect_navigation(wait_until='domcontentloaded',timeout=45000):
                    self.page.locator('.mPaginate a').filter(has_text=re.compile(r'^\s*'+target+r'\s*$')).first.click(timeout=10000)
            except Exception:self.page.wait_for_timeout(2500)
            self.flow.wait(lambda:(self.read() or {}).get('current')==target,30,'자사몰 반품 다음 페이지가 열리지 않았습니다.')
        return got
    def exchange_invoice(self,order_id,item_id):
        page=self.flow.context.new_page()
        try:
            page.goto(f'https://{self.host}{DETAIL_PATH}?order_id={quote(order_id)}',wait_until='domcontentloaded',timeout=45000)
            if not self.trusted(page,DETAIL_PATH):return None
            for _ in range(75):
                v=page.evaluate(EXCHANGE_INVOICE_JS,item_id)
                if v:return v
                page.wait_for_timeout(200)
            return None
        finally:
            try:page.close()
            except Exception:pass
    def reason(self,order_id,item_id):
        page=self.flow.context.new_page()
        try:
            page.goto(self.handling_url(order_id,item_id),wait_until='domcontentloaded',timeout=45000)
            if not self.trusted(page,HANDLING_PATH):return None
            end=20
            for _ in range(end*5):
                v=page.evaluate(REASON_JS,item_id)
                if v:return v
                page.wait_for_timeout(200)
            return None
        finally:
            try:page.close()
            except Exception:pass

def collect_cafe24(controller,account,today,host=None,want_returns=True,want_exchanges=True):
    """Own Chrome: 카페24 로그인 → 반품 관리 1개월 → 진행 중 반품 → 반품사유 → 택배사 조회 → rows."""
    from playwright.sync_api import sync_playwright
    from return_session import launch_chrome,new_context
    from return_browser import ReturnFlow
    from return_data import clean_tracking
    from soldout_display import Cafe24Flow
    with sync_playwright() as pw:
        browser=launch_chrome(pw);context=new_context(browser,accept_downloads=False)
        try:
            flow=Cafe24Flow(controller,context);flow.login(account)
            host_used=host or (HOST if FORCE_HOST or not str(flow.host or '').endswith('.cafe24.com') else flow.host)
            rows=[];notes=[];statuses={}
            for kind in (('return','exchange') if want_exchanges else ('return',)):
                if kind=='return' and not want_returns:continue
                reader=Cafe24Returns(flow,host_used,kind)
                reader.open_list()
                raws=reader.all_rows()
                active=[r for r in raws if is_active(r.get('status'),kind)]
                for r in raws:
                    k=reader.word+' '+(r.get('status','').split(' ')[0] or '?');statuses[k]=statuses.get(k,0)+1
                for n,raw in enumerate(active,1):
                    controller.check();oid=raw.get('orderId') or re.sub(r'-\d+$','',raw['itemId'])
                    if kind=='return':
                        flow.progress(f'자사몰 반품 {n}/{len(active)} · {raw["itemId"]} 반품사유 확인')
                        try:why=reader.reason(oid,raw['itemId'])
                        except Exception as exc:why=None;notes.append(f'{raw["itemId"]} 사유 확인 실패 ({type(exc).__name__})')
                        rows.append(entry(raw,why))
                    else:
                        flow.progress(f'자사몰 교환 {n}/{len(active)} · {raw["itemId"]} 주문상세에서 원송장 확인')
                        try:det=reader.exchange_invoice(oid,raw['itemId'])
                        except Exception as exc:det=None;notes.append(f'{raw["itemId"]} 교환 송장 확인 실패 ({type(exc).__name__})')
                        rows.append(entry(raw,None,'exchange',(det or {}).get('invoice','')))
            invoices=list(dict.fromkeys(r['invoice'] for r in rows if r['invoice']))
            raw_track={}
            if invoices:
                controller.update('running',f'자사몰 반품·교환 {len(rows)}건 · 택배사 조회 {len(invoices)}건')
                tracker=ReturnFlow(controller,context,SELLER);tracker.page=context.new_page()
                raw_track=tracker.lookup(invoices)
                try:tracker.page.close()
                except Exception:pass
            for r in rows:r.update(clean_tracking(raw_track.get(r['invoice']),r['invoice'],today))
            ret=[r for r in rows if r['kind']=='return'];ex=[r for r in rows if r['kind']=='exchange']
            return {'rows':ret,'exchangeRows':ex,'totals':{'반품 진행 중':len(ret),'교환 진행 중':len(ex)},'statuses':statuses,
                    'scanned':sum(v for k,v in statuses.items() if k.startswith('반품')),'scannedExchange':sum(v for k,v in statuses.items() if k.startswith('교환')),'notes':notes}
        finally:
            context.close();browser.close()

def cafe24_enabled(store_directory,vault=None):
    try:
        from cafe24_credentials import Cafe24Accounts
        info=Cafe24Accounts(store_directory,vault).info()
    except Exception as exc:return None,'자사몰 계정 확인 실패 · '+str(exc)
    if not info.get('hasPassword'):return None,'자사몰(카페24) 계정 없음 · 자사몰 반품은 조회하지 않습니다.'
    return info,''
