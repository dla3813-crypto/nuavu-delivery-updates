"""자사몰(카페24 관리자)-only macOS Keychain item. No plaintext fallback or secret UI return. (2026-10-20)"""
from __future__ import annotations
import json
import re
import sys
from credentials import MacKeychain, UnavailableVault, VaultError

SERVICE='kr.nuavu.deliverynotice.cafe24'

class Cafe24Keychain(MacKeychain):
    def _query(self):
        q=super()._query();q[self._api().kSecAttrService]=SERVICE;return q

    def save(self, payload):
        s=self._api()
        raw=json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode('utf-8')
        if len(raw)>16384:raise VaultError('자사몰 계정 정보가 너무 큽니다.')
        query=self._query()
        try:
            status=s.SecItemUpdate(query,{s.kSecValueData:raw})
            if status==s.errSecItemNotFound:
                add={**query,s.kSecValueData:raw,s.kSecAttrLabel:'누아브 자사몰(카페24) 로그인'}
                status,_=s.SecItemAdd(add,None)
                if status==s.errSecDuplicateItem:status=s.SecItemUpdate(query,{s.kSecValueData:raw})
            self._check(status)
        except Exception:
            raise VaultError('자사몰 계정을 키체인에 저장하지 못했습니다. 키체인 접근을 허용한 뒤 다시 저장하세요. 평문으로 대신 저장하지 않습니다.') from None

    def load(self):
        try:return super().load()
        except Exception:
            raise VaultError('자사몰 계정을 키체인에서 읽지 못했습니다. 키체인 접근을 허용하고 자사몰 설정을 다시 여세요.') from None

def payload(username,password):
    if not isinstance(username,str) or not username.strip() or len(username)>200 or any(ord(c)<32 for c in username):raise VaultError('자사몰(카페24) 아이디를 확인하세요.')
    if not isinstance(password,str) or not password or len(password)>4096 or any(ord(c)<32 for c in password):raise VaultError('자사몰(카페24) 비밀번호를 입력하세요.')
    return {'version':1,'username':username.strip(),'password':password}

class Cafe24Accounts:
    def __init__(self,directory,vault=None):self.vault=vault if vault is not None else __import__('windows_credentials').platform_vault(directory,SERVICE,'배송안내 배포판 자사몰(카페24) 로그인',Cafe24Keychain)
    def load(self):
        try:
            saved=self.vault.load()
            if saved is None:return None
            if saved.get('version')!=1:raise ValueError()
            return payload(saved.get('username'),saved.get('password'))
        except Exception:raise VaultError('자사몰 키체인을 읽지 못했습니다. 설정에서 계정을 다시 저장하세요.') from None
    def info(self):
        saved=self.load()
        return {'username':saved['username'] if saved else '','hasPassword':bool(saved),'available':bool(self.vault.available),'storage':'macOS 키체인'}
    def save(self,username,password):
        if password=='':
            old=self.load()
            if not old or old['username']!=str(username).strip():raise VaultError('새 계정의 비밀번호를 입력하세요.')
            password=old['password']
        account=payload(username,password)
        try:self.vault.save(account)
        except Exception:raise VaultError('자사몰 계정을 키체인에 저장하지 못했습니다. 접근 권한을 확인하세요.') from None
        return {**self.info(),'message':'자사몰(카페24) 로그인 정보를 키체인에 저장했습니다.'}
    def forget(self):
        try:self.vault.delete()
        except Exception:pass
        return {**self.info(),'message':'자사몰 계정을 키체인에서 삭제했습니다.'}
    def for_login(self):
        """None when nothing is saved — the 배포판 may have no 자사몰 at all; then only 에이블리 is processed."""
        return self.load()
