import threading
from functools import wraps
import inspect

def operation_lock(engine):
    if not hasattr(engine,'ui_operation_lock'):engine.ui_operation_lock=threading.RLock()
    return engine.ui_operation_lock

def serialized(method):
    @wraps(method)
    def wrapped(self,*args,**kwargs):
        with operation_lock(self._engine):
            if getattr(self._engine,'reset_in_progress',False):return {'error':'전체 초기화 중입니다.'}
            return method(self,*args,**kwargs)
    wrapped.__signature__=inspect.signature(method)
    return wrapped
