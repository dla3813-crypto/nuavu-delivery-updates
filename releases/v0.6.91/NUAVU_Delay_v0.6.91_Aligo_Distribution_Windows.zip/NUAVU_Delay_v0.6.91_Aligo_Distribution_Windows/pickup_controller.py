from __future__ import annotations
from job_alerts import job_alert
import copy,secrets,threading
from datetime import datetime
from order_auto import OrderAutoController,OrderAutoError,Cancelled
from aftersales_data import parse_pickup_input,auto_candidates,folder_default,shop,pickup_sellers,PICKUP_SELLERS
from aftersales_lock import operation_lock

class PickupController(OrderAutoController):
    def __init__(self,engine,runner=None,vault=None,busy=None,clock=None):
        super().__init__(engine.store,login_vault=vault)
        self.engine=engine;self.runner=runner;self.ably_runner=None;self.zigzag_runner=None;self.busy=busy or (lambda:False)
        from order_auto import KST
        self.clock=clock or (lambda:datetime.now(KST))
        self.scheduler_stop=threading.Event();self.scheduler_thread=None;self.current=[];self.pending=None
        self.job={'phase':'idle','message':'회수 대상과 기존 접수 이력을 확인하세요.'}
    def running(self):return bool(self.thread and self.thread.is_alive())
    def config(self):
        s=self.store.read();return {'enabled':bool(s.get('pickupSettings',{}).get('enabled',False)),'sellers':pickup_sellers(s)}
    def status(self):
        with self.lock:
            cfg=shop(self.store.read());hist=[h for h in self.store.read().get('pickupHistory',[]) if all(h.get(k,0 if k=='shopRevision' else '')==v for k,v in cfg.items())]
            return {**super().status(),'settings':self.config(),'rows':copy.deepcopy(self.current),'history':copy.deepcopy(hist[-1000:]),'reportPath':self.store.read().get('pickupReportPath','')}
    def save(self,enabled):
        """bool (legacy toggle, all 판매처) or {'enabled':bool,'sellers':{판매처:bool}} — 2026-10-20 판매처별 자동 회수접수."""
        sellers=None
        if isinstance(enabled,dict):
            raw=enabled.get('sellers');enabled=enabled.get('enabled')
            if isinstance(raw,dict):
                if any(k not in PICKUP_SELLERS or type(v)is not bool for k,v in raw.items()):raise OrderAutoError('판매처 선택 값을 확인하세요.')
                sellers={**pickup_sellers(self.store.read()),**raw}
        if type(enabled)is not bool:raise OrderAutoError('켜짐/꺼짐을 선택하세요.')
        with operation_lock(self.engine),self.lock:
            with self.store.edit() as s:s['pickupSettings']={'enabled':enabled,'sellers':sellers or pickup_sellers(s)}
            if not enabled and self.job.get('automatic'):self.stop.set()
        return self.status()
    def check(self):
        super().check()
        if self.engine.stop.is_set() or self.scheduler_stop.is_set() or getattr(self.engine,'reset_in_progress',False):raise Cancelled('회수접수를 중단했습니다.')
    def start_pickups(self,rows,inspect_only=False,automatic=False):
        with operation_lock(self.engine),self.lock:
            self.check_start()
            rows=parse_pickup_input(rows);cfg=shop(self.store.read())
            if automatic:
                allowed={r['invoice'] for r in auto_candidates(self.store.read(),self.clock().date())}
                rows=[r for r in rows if r['invoice'] in allowed]
                if not rows:raise OrderAutoError('새 자동 회수 대상이 없습니다.')
            if not self.store.read().get('settings',{}).get('shopName'):raise OrderAutoError('쇼핑몰 이름을 먼저 설정하세요.')
            self.stop.clear();self.current=[];self.pending=None;self.job_shop=cfg
            self.job={'id':secrets.token_urlsafe(16),'phase':'running','message':'회수접수 전용 Chrome을 엽니다.','automatic':automatic,'inspectOnly':inspect_only}
            # Claim all automatic candidates once before auth/launch, including failures.
            if automatic:
                with self.store.edit() as s:
                    for row in rows:s.setdefault('pickupHistory',[]).append({**cfg,**row,'id':self.job['id']+':'+row['invoice'],'result':'처리 대기','at':self.clock().isoformat(),'attempt':0,'automatic':True})
            self.thread=threading.Thread(target=self._run_pickups,args=(rows,cfg,inspect_only),daemon=True);self.thread.start()
            return self.status()
    def check_start(self):
        if self.running():raise OrderAutoError('회수접수 작업이 이미 진행 중입니다.')
        if self.busy():raise OrderAutoError('주문 불러오기 또는 반품·교환 조회가 끝난 뒤 실행하세요.')
        if self.engine.stop.is_set() or self.scheduler_stop.is_set() or getattr(self.engine,'reset_in_progress',False):raise OrderAutoError('앱 종료 또는 전체 초기화 중입니다.')
    def before_submit(self,number):
        with self.lock:
            self.check();cfg=shop(self.store.read())
            if cfg!=self.job_shop:raise OrderAutoError('쇼핑몰 설정이 변경되었습니다.')
            history=self.store.read().get('pickupHistory',[])
            attempts=[h.get('attempt',0) for h in history if h.get('invoice')==number and all(h.get(k,0 if k=='shopRevision' else '')==v for k,v in cfg.items())]
            attempt=max(attempts,default=0)+1;entry={**cfg,'id':self.job['id']+':'+number,'invoice':number,'attempt':attempt,'result':'접수 결과 미확인','at':self.clock().isoformat(),'automatic':self.job.get('automatic',False)}
            with self.store.edit() as s:
                s['pickupHistory']=[h for h in s.get('pickupHistory',[]) if h.get('id')!=entry['id']]+[entry]
            self.pending=entry
    def record(self,result,inspect_only=False):
        with self.lock:
            result={k:v for k,v in result.items() if k not in ('phone','rowKey')}
            entry={**self.job_shop,**result,'id':self.job['id']+':'+result['invoice'],'at':self.clock().isoformat(),'inspectOnly':inspect_only,'automatic':self.job.get('automatic',False),'attempt':(self.pending or {}).get('attempt',0)}
            if not inspect_only:
                with self.store.edit() as s:s['pickupHistory']=[h for h in s.get('pickupHistory',[]) if h.get('id')!=entry['id']]+[entry]
            self.current.append(entry);self.pending=None
    def _run_pickups(self,rows,cfg,inspect_only):
        self.job_shop=cfg
        try:
            from pickup_browser import run_pickups
            (self.runner or run_pickups)(self,rows,cfg['shopName'],inspect_only)
            ably=self._accept_in_ably() if not inspect_only else {}
            done=sum(r.get('ablyResult')=='에이블리 접수 완료' for r in self.current)
            self.update('done','회수 상태 확인을 완료했습니다.' if inspect_only else '회수접수 처리를 마쳤습니다.'+(f' 에이블리 반품요청 접수 {done}/{len(ably)}건.' if ably else '')+' 건별 결과를 확인하세요.')
            job_alert(self.engine,'회수 상태 확인 완료' if inspect_only else '회수접수 완료',self.job.get('message',''))
            ok={'접수 완료','이미 접수됨','접수 전 확인'}
            blocked=[r for r in self.current if r.get('result') and r['result'] not in ok]
            if blocked:
                lines=[f"원송장 {r.get('invoice','')} · {r.get('result','')}"+(' · '+r['note'] if r.get('note') else '') for r in blocked[:15]]
                job_alert(self.engine,f"{'회수 확인' if inspect_only else '회수접수'} 막힘 {len(blocked)}건",'\n'.join(lines)+('\n…' if len(blocked)>15 else ''),'error')
            # 2026-10-22 18:02 보고: 자사몰('이지어드민 회수접수만')·에이블리 교환·지그재그 접수 완료까지 '에이블리 반품요청 접수 확인 필요'로 떴다 → 정상 결과는 제외.
            fine={'에이블리 접수 완료','자사몰 · 이지어드민 회수접수만','에이블리 교환 건 · 접수 단계 없음'}
            ably_bad=[r for r in self.current if r.get('ablyResult') and r['ablyResult'] not in fine and not str(r['ablyResult']).endswith('완료')]
            if ably_bad:
                lines=[f"원송장 {r.get('invoice','')} · {r.get('ablyResult','')}"+(' · '+r['ablyNote'] if r.get('ablyNote') else '') for r in ably_bad[:15]]
                plats=sorted({'지그재그' if str(r['ablyResult']).startswith('지그재그') else '에이블리' for r in ably_bad})
                job_alert(self.engine,f"{'·'.join(plats)} 반품요청 접수 확인 필요 {len(ably_bad)}건",'\n'.join(lines)+('\n…' if len(ably_bad)>15 else ''),'error')
            # 2026-10-23 19:21 요청: 상품 여러 개짜리 반품요청은 접수는 진행하고 알림으로 알린다.
            # 회수접수는 상품 수와 상관없이 먼저 진행하고(원송장 기준), 상품이 2개 이상이면 이지어드민 주문 목록 줄 수·에이블리 확인창 숫자 중 큰 값으로 알린다.
            n_items=lambda r:max(int(r.get('items') or 0),int(r.get('ablyMulti') or 0))
            multi=[r for r in self.current if r.get('result')=='접수 완료' and not r.get('inspectOnly') and n_items(r)>1]
            if multi:
                lines=[f"원송장 {r.get('invoice','')} · 회수접수는 진행되었으나, 상품이 {n_items(r)}개입니다"+(' · '+r['ablyResult'] if r.get('ablyResult') else '')+(' · 반품요청번호 '+r['ablyRequestNo'] if r.get('ablyRequestNo') else '') for r in multi[:15]]
                job_alert(self.engine,f"회수접수 진행 · 상품 여러 개 반품요청 {len(multi)}건",'\n'.join(lines)+('\n…' if len(multi)>15 else ''),'error')
        except Exception as exc:
            self.update('cancelled' if self.stop.is_set() else 'error',str(exc) if isinstance(exc,OrderAutoError) else '회수접수 중 문제가 발생했습니다. 결과를 확인하세요.')
            if not self.stop.is_set():job_alert(self.engine,'회수접수 실패',self.job.get('message',''),'error')
        finally:
            if self.pending:
                self.current.append(copy.deepcopy(self.pending));self.pending=None
            if not inspect_only:
                with self.store.edit() as s:
                    for h in s.get('pickupHistory',[]):
                        if h.get('id','').startswith(self.job['id']+':') and h.get('result')=='처리 대기':
                            h['result']='접수 실패';h['note']='처리 전 중단 · 자동 재시도 없음';self.current.append(copy.deepcopy(h))
            known={r['invoice'] for r in self.current}
            for row in rows:
                if row['invoice'] not in known:
                    self.record({'invoice':row['invoice'],'customer':row.get('customer',''),'result':'접수 실패','note':'처리 전 중단 · 접수하지 않음'},inspect_only)
            if self.current:
                try:
                    from pickup_report import save_report
                    path=save_report(self.current,folder_default().parent,self.clock())
                    with self.store.edit() as s:s['pickupReportPath']=path
                except Exception:self.job['message']+=' 결과 엑셀 저장 실패. 앱 이력에서 확인하세요.'
    def _accept_in_ably(self):
        """Requested 2026-10-19: registered pickups continue to 에이블리 반품요청(접수필요) → 반품요청 접수 → 검수대기 check."""
        from ably_return_accept import accept_targets,accept_returns
        from aftersales_data import platform_of
        with self.lock:targets=accept_targets(copy.deepcopy(self.current))
        if not targets:return {}
        # 2026-10-20: exchange rows have no 에이블리 반품요청 step (교환 접수 is done on the 교환 page); 지그재그 rows go to the partner center.
        state=self.store.read();today=self.clock().date();results={}
        for t in targets:t.update(platform_of(state,today,t['invoice']))
        ably=[t for t in targets if t['seller'] not in ('지그재그','자사몰') and t['kind']!='exchange']
        for t in targets:
            # 2026-10-21: 자사몰 = 이지어드민 회수접수까지만 (카페24 반품접수는 자동으로 누르지 않음)
            if t['seller']=='자사몰':results[t['invoice']]={'ablyResult':'자사몰 · 이지어드민 회수접수만','ablyNote':'카페24 반품접수·수거완료는 자동으로 처리하지 않습니다.'}
        zigzag=[t for t in targets if t['seller']=='지그재그']
        for t in targets:
            if t['seller'] not in ('지그재그','자사몰') and t['kind']=='exchange':results[t['invoice']]={'ablyResult':'에이블리 교환 건 · 접수 단계 없음','ablyNote':'이지어드민 회수접수만 진행했습니다. 교환 접수는 에이블리 교환 관리에서 처리하세요.'}
        if ably:
            self.update('running',f'회수접수 {len(ably)}건 · 에이블리 반품요청 접수를 시작합니다.')
            try:results.update((self.ably_runner or accept_returns)(self,ably,today))
            except Cancelled:raise
            except Exception as exc:
                results.update({t['invoice']:{'ablyResult':'에이블리 접수 실패','ablyNote':str(exc) if isinstance(exc,OrderAutoError) else '에이블리 처리 중 문제가 발생했습니다. 에이블리에서 직접 확인하세요.'} for t in ably})
        if zigzag:
            from zigzag_returns import accept_zigzag
            self.update('running',f'회수접수 {len(zigzag)}건 · 지그재그 반품접수/교환접수를 시작합니다.')
            try:results.update((self.zigzag_runner or accept_zigzag)(self,zigzag,today))
            except Cancelled:raise
            except Exception as exc:
                results.update({t['invoice']:{'ablyResult':'지그재그 접수 실패','ablyNote':(str(exc) or type(exc).__name__)[:200]} for t in zigzag})
        stamp=self.clock().isoformat()
        with self.lock:
            with self.store.edit() as s:
                for entry in self.current:
                    r=results.get(entry.get('invoice'))
                    if not r or entry.get('inspectOnly') or entry.get('result') not in {'접수 완료','이미 접수됨'}:continue
                    r={k:v for k,v in r.items() if k in ('ablyResult','ablyNote','ablyRequestNo','ablyMulti')};entry.update(r);entry['ablyAt']=stamp
                    for h in s.get('pickupHistory',[]):
                        if h.get('id')==entry.get('id'):h.update(r);h['ablyAt']=stamp
        return results
    def tick(self):
        with operation_lock(self.engine),self.lock:
            if self.running() or self.busy() or not self.config()['enabled'] or self.engine.stop.is_set() or self.scheduler_stop.is_set() or getattr(self.engine,'reset_in_progress',False):return False
            rows=auto_candidates(self.store.read(),self.clock().date())
            if not rows:return False
            self.start_pickups(rows,automatic=True);return True
    def start_scheduler(self):
        if self.scheduler_thread and self.scheduler_thread.is_alive():return
        def loop():
            while not self.scheduler_stop.wait(10):
                try:self.tick()
                except Exception:self.update('error','자동 회수접수를 시작하지 못했습니다. 설정을 확인하세요.')
        self.scheduler_thread=threading.Thread(target=loop,daemon=True);self.scheduler_thread.start()
    def shutdown(self):self.scheduler_stop.set();self.stop.set();self.question_event.set()
