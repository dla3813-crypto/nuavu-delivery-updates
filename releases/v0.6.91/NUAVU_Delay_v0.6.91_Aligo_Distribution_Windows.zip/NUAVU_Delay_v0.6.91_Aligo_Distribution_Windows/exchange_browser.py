"""Read-only exchange collection. Never clicks exchange approval/withdrawal."""
import re,hashlib,json
from datetime import timedelta
from urllib.parse import urlencode,urlsplit
from return_data import ReturnError,invoice,carrier_of
from return_browser import ReturnFlow
from return_session import launch_chrome,new_context
from order_auto import OrderAutoError

URL='https://my.a-bly.com/sales/order/exchange/progress'
# The exchange list is fetched asynchronously after the status card / 검색 / page
# click; the old table (often empty) stays visible before the spinner appears.
# Wait a fixed settle time and then require the rows to stay unchanged.
SETTLE_SECONDS=2.5
STABLE_SECONDS=1.0
FIELDS={'requestId':'교환요청번호','requestedAt':'교환요청일시','exchangeStatus':'주문상태','itemId':'상품주문번호','orderId':'주문번호','product':'상품명','option':'기존옵션','exchangeOption':'교환요청 옵션','qty':'수량','reason':'교환사유','fee':'교환 배송비 (왕복)','returnNo':'수거 송장번호','customer':'수취인명','recipientPhone':'수취인 연락처'}

def parse_exchange(headers,records,status):
    norm=lambda s:re.sub(r'\s+','',s)
    heads=[norm(h) for h in headers]
    if any(heads.count(norm(h))!=1 for h in FIELDS.values()):raise ReturnError('교환 표의 필수 열을 확인하지 못했습니다.')
    cols={k:heads.index(norm(h)) for k,h in FIELDS.items()};rows=[]
    for cells in records:
        if len(cells)!=len(heads):raise ReturnError('교환 표의 열 수가 변경되었습니다.')
        r={k:cells[i].strip() for k,i in cols.items()}
        if r['exchangeStatus'].split()[0]!=status:raise ReturnError('선택한 교환 상태와 목록이 달라 이전 결과를 유지합니다.')
        if not all(r[k] for k in ('requestId','orderId','itemId','product')):raise ReturnError('교환 주문 식별 정보가 없습니다.')
        r['requestedAt']=r['requestedAt'][:10];r['returnNo']=invoice(r['returnNo']);r['recipient']=r['customer']
        r['fee']=int(re.sub(r'[^\d-]','',r['fee']) or '0');r['invoice']='';r['kind']='exchange'
        r['key']='exchange:'+hashlib.sha256(json.dumps([r['requestId'],r['itemId']],ensure_ascii=False).encode()).hexdigest()
        rows.append(r)
    return rows

def detail_invoice(text,item_id):
    if f'상품주문정보 조회 [{item_id}]' not in text:raise ReturnError('교환 상세 상품주문번호가 다릅니다.')
    part=text.split('배송정보\n',1)
    if len(part)!=2:raise ReturnError('교환 주문의 배송정보가 없습니다.')
    part=part[1].split('배송지정보',1)[0]
    numbers=re.findall(r'(?:^|\n)송장번호\s*\n\s*([\d-]{10,20})(?:\s|$)',part)
    if len(numbers)!=1 or not invoice(numbers[0]):raise ReturnError('원송장을 하나로 확인하지 못했습니다.')
    return invoice(numbers[0])

DASHBOARD='https://my.a-bly.com/dashboard'
STATUS_CODES={'교환요청':'[2]','교환수거중':'[3]'}
CARD_JS='''()=>[...document.querySelectorAll('[class*="FilterCard__Wrapper"]')].map(w=>w.innerText.replace(/\\s+/g,' ').trim())'''

def parse_cards(texts):
    """'교환요청 6 건' style summary cards -> {status:count}."""
    counts={}
    for t in texts or []:
        m=re.fullmatch(r'(교환요청|교환수거중|수거완료|교환상품준비중|교환재배송중|교환완료)\s*([\d,]+)\s*건',t.strip())
        if m:counts[m[1]]=int(m[2].replace(',',''))
    return counts

class ExchangeFlow(ReturnFlow):
    def exchange_frame(self):
        frames=[f for f in self.page.frames if urlsplit(f.url).hostname=='seller-admin.a-bly.com' and urlsplit(f.url).path=='/sales/order/exchange']
        if len(frames)!=1:raise ReturnError('에이블리 교환 화면을 확인하지 못했습니다.')
        return frames[0]
    def selected_exchange_status(self,f):
        control=f.locator('#status:visible')
        if control.count()!=1:return None
        root=control.locator('xpath=ancestor::div[contains(concat(" ",normalize-space(@class)," ")," ant-select ")][1]')
        selected=root.locator('.ant-select-selection-item:visible')
        if selected.count()!=1:return None
        return selected.inner_text().strip()
    def top_query(self):
        from urllib.parse import parse_qs
        return {k:v[0] for k,v in parse_qs(urlsplit(self.page.url).query).items()}
    def card_counts(self,f):
        try:return parse_cards(f.evaluate(CARD_JS))
        except Exception:return {}
    def confirm_period_popup(self,f):
        """Dashboard entry shows '교환 요청기간 검색 … 최근 1년을 조회합니다' → 확인 (= last-year search)."""
        box=f.locator('.ant-modal-wrap:visible .ant-modal-confirm')
        for _ in range(2):
            if not box.count():return False
            title=box.locator('.ant-modal-confirm-title').inner_text().strip() if box.locator('.ant-modal-confirm-title').count() else ''
            if '요청기간' not in title and '최근 1년' not in box.inner_text():raise ReturnError('예상하지 못한 교환 확인 창이 있어 중단했습니다: '+title)
            ok=box.locator('button.ant-btn-primary')
            if ok.count()!=1 or ok.inner_text().strip()!='확인':raise ReturnError('교환 요청기간 확인 버튼을 찾지 못했습니다.')
            self.c.update('exchange','교환 요청기간 확인 창 → 확인 (최근 1년 조회)');ok.click(timeout=5000)
            self.until(lambda:not box.count(),20,'교환 요청기간 확인 창이 닫히지 않았습니다.')
            self.pause(SETTLE_SECONDS)
        return True
    def open_from_dashboard(self):
        """Enter like a person: dashboard → 취소/반품/교환 → 교환요청 count (Korea row)."""
        self.step='대시보드 열기';self.c.update('exchange','대시보드를 엽니다.')
        self.navigate(DASHBOARD);self.pause(1);self.dismiss_popups();self.check_market()
        item=self.page.locator('.panel-list__item').filter(has=self.page.locator('.panel-list__item--title').filter(has_text=re.compile(r'^\s*교환요청\s*$')))
        self.until(lambda:item.count()==1,30,'대시보드의 교환요청 항목을 찾지 못했습니다.')
        rows=item.locator('.panel-list__item--value-row')
        self.until(lambda:rows.count()>=1,20,'대시보드의 교환요청 건수를 찾지 못했습니다.')
        korea=rows.first  # first value row is 한국(ABLY); 일본(amood) follows
        count=korea.locator('.panel-list__item--count')
        if count.count()!=1:raise ReturnError('대시보드의 교환요청 숫자를 하나로 찾지 못했습니다.')
        text=count.inner_text().strip();m=re.fullmatch(r'[\d,]+',text)
        if not m:raise ReturnError('대시보드의 교환요청 숫자를 읽지 못했습니다: '+text)
        dashboard=int(text.replace(',',''))
        self.step='대시보드 교환요청 숫자 클릭';self.c.update('exchange',f'대시보드 교환요청 {dashboard}건 → 숫자를 눌러 교환 관리로 들어갑니다.')
        count.click(timeout=5000)
        self.until(lambda:urlsplit(self.page.url).path=='/sales/order/exchange/progress',30,'교환 관리 화면으로 이동하지 못했습니다.')
        self.pause(SETTLE_SECONDS)
        self.until(lambda:any(urlsplit(f.url).hostname=='seller-admin.a-bly.com' for f in self.page.frames),30,'교환 화면이 열리지 않았습니다.')
        self.step='교환 관리 화면 · 요청기간 확인 창';f=self.exchange_frame()
        self.until(lambda:f.locator('.ant-modal-wrap:visible .ant-modal-confirm').count() or f.locator('.ant-pagination-total-text').count(),40,'교환 목록 또는 확인 창이 나타나지 않았습니다.')
        self.confirm_period_popup(f)
        return dashboard
    def exchange_table(self,f):
        label=f.locator('.ant-pagination-total-text')
        return {'total':label.inner_text().strip() if label.count()==1 else None,
                'rows':f.locator('tbody tr.ant-table-row').evaluate_all('es=>es.map(e=>[...e.querySelectorAll("td")].map(c=>c.innerText))'),
                'loading':bool(f.locator('.ant-spin-spinning:visible').count())}
    def total_of(self,f):
        t=self.exchange_table(f)
        if t['loading'] or t['total'] is None:return None
        m=re.fullmatch(r'총\s*([\d,]+)\s*개',t['total'])
        return int(m[1].replace(',','')) if m else None
    def select_exchange_status(self,f,status):
        """Click the summary card unless already selected; the card itself reloads the list."""
        if status not in STATUS_CODES:raise ReturnError('지원하지 않는 교환 상태입니다.')
        self.until(lambda:self.selected_exchange_status(f) is not None,30,'교환 상태 선택 표시가 준비되지 않았습니다.')
        if self.selected_exchange_status(f)!=status:
            card=f.locator('span.ant-typography[class*="FilterCard"]:visible').filter(has_text=re.compile(r'^\s*'+re.escape(status)+r'\s*$'))
            if card.count()!=1:raise ReturnError('교환 상태 카드를 하나로 찾지 못했습니다.')
            self.c.update('exchange',status+' 카드를 누릅니다.');card.click(timeout=5000)
            self.pause(SETTLE_SECONDS)
        self.until(lambda:self.selected_exchange_status(f)==status,30,'교환 상태 선택을 확인하지 못했습니다.')
    def wait_exchange(self,f,status):
        self.until(lambda:self.selected_exchange_status(f)==status,30,'교환 상태 선택을 확인하지 못했습니다.')
        self.pause(SETTLE_SECONDS)  # give the async fetch time to start before judging the table
        self.until(lambda:not f.locator('.ant-spin-spinning:visible').count() and f.locator('.ant-pagination-total-text').count()==1,40,'교환 목록이 준비되지 않았습니다.')
        def current_rows():
            heads=f.locator('thead th').all_inner_texts()
            if '주문상태' not in heads:return False
            i=heads.index('주문상태')
            t=self.exchange_table(f)
            if t['loading'] or t['total'] is None:return False
            m=re.fullmatch(r'총\s*([\d,]+)\s*개',t['total'])
            if not m:return False
            if int(m[1].replace(',',''))>0 and not t['rows']:return False  # count says rows exist but the table has not filled yet
            return all(len(r)>i and r[i].strip().split()[:1]==[status] for r in t['rows'])
        self.until(current_rows,30,'선택한 교환 상태로 목록이 갱신되지 않았습니다.')
        # Stable: the same total and rows after a further pause, so a late reload cannot slip in.
        def stable():
            before=self.exchange_table(f);self.pause(STABLE_SECONDS);after=self.exchange_table(f)
            return not after['loading'] and before['total']==after['total'] and before['rows']==after['rows'] and current_rows()
        self.until(stable,30,'교환 목록이 계속 바뀌어 확인하지 못했습니다.')
        if self.selected_exchange_status(f)!=status:raise ReturnError('교환 상태 선택을 확인하지 못했습니다.')
    def ready_for(self,f,status):
        """Status selected, top URL carries that status, list stable, and the card count equals the list total."""
        self.step=status+' 목록 확인';self.select_exchange_status(f,status)
        self.wait_exchange(f,status)
        q=self.top_query()
        if q.get('status') not in (STATUS_CODES[status],None):raise ReturnError(f'화면 주소의 교환 상태({q.get("status")})가 {status}와 다릅니다.')
        if q.get('status') is None:
            # The list did not switch by URL: ask for the search explicitly, once.
            self.c.update('exchange','검색 버튼으로 목록을 다시 불러옵니다.')
            f.get_by_role('button',name='검색',exact=True).click(timeout=5000);self.pause(SETTLE_SECONDS);self.confirm_period_popup(f);self.wait_exchange(f,status)
        total=self.total_of(f);cards=self.card_counts(f)
        if total is None:raise ReturnError('교환 전체 건수를 읽지 못했습니다.')
        if status in cards and cards[status]!=total:
            self.pause(SETTLE_SECONDS);total=self.total_of(f);cards=self.card_counts(f)
            if status in cards and cards[status]!=total:raise ReturnError(f'{status} 카드 {cards[status]}건과 목록 {total}건이 달라 이전 결과를 유지합니다.')
        self.c.update('exchange',f'{status} {total}건 (카드 {cards.get(status,"?")}건) 확인 · 주소 상태 {q.get("status","-")}')
        return total
    def collect_exchange(self,today):
        dashboard=self.open_from_dashboard()
        allrows=[];keys=set();summary={}
        for status in ('교환요청','교환수거중'):
            f=self.exchange_frame()
            total=self.ready_for(f,status);summary[status]=total;count=0;pages=set()
            if total>20000:raise ReturnError('교환 처리 범위를 초과했습니다.')
            label=f.locator('.ant-pagination-total-text').inner_text()
            while True:
                self.c.check();self.check_market()
                headers=f.locator('thead th').all_inner_texts()
                records=f.locator('tbody tr.ant-table-row').evaluate_all('es=>es.map(e=>[...e.querySelectorAll("td")].map(c=>c.innerText))')
                rows=parse_exchange(headers,records,status)
                sig=tuple(r['key'] for r in rows)
                if sig in pages and rows:raise ReturnError('교환 페이지가 반복되어 중단했습니다.')
                pages.add(sig)
                for n,r in enumerate(rows,1):
                    if r['key'] in keys:raise ReturnError('교환 목록에 중복 항목이 있어 이전 결과를 유지합니다.')
                    keys.add(r['key'])
                    self.step=f'{status} 상세 조회 ({r["itemId"]})';self.c.update('exchange',f'{status} {count+n}/{total} · 상품주문번호 {r["itemId"]} 상세에서 원송장 확인')
                    tr=f.locator('tbody tr.ant-table-row').filter(has=f.get_by_text(r['itemId'],exact=True))
                    if tr.count()!=1:raise ReturnError('교환 상품 행을 하나로 찾지 못했습니다.')
                    tr.get_by_text(r['itemId'],exact=True).click(timeout=5000)
                    modal=f.locator('[role="dialog"]:visible')
                    self.until(lambda:modal.count()==1 and r['itemId'] in modal.inner_text(),15,'교환 상세가 열리지 않았습니다.')
                    # 2026-10-20: the header shows at once but 배송정보 loads afterwards; reading early gave '번호 없음'.
                    try:self.until(lambda:'배송지정보' in modal.inner_text() and '교환 요청' in modal.inner_text(),15,'교환 상세 내용이 표시되지 않았습니다.')
                    except ReturnError:pass
                    r['invoice']='';r['invoiceNote']=''
                    for attempt in range(6):
                        try:r['invoice']=detail_invoice(modal.inner_text(),r['itemId']);break
                        except ReturnError as exc:
                            r['invoiceNote']=str(exc)
                            if attempt<5:self.pause(1)
                    close=modal.locator('button.mantine-Modal-close')
                    if close.count()!=1:raise ReturnError('교환 상세 닫기 버튼을 확인하지 못했습니다.')
                    close.click();self.until(lambda:not modal.count(),10,'교환 상세가 닫히지 않았습니다.')
                    allrows.append(r)
                count+=len(rows)
                nxt=f.locator('.ant-pagination-next')
                if nxt.count()!=1:raise ReturnError('교환 다음 페이지를 확인하지 못했습니다.')
                if nxt.get_attribute('aria-disabled')=='true':break
                if not rows or count>=total:raise ReturnError('교환 페이지/건수가 일치하지 않습니다.')
                before=f.locator('.ant-pagination-item-active').inner_text()
                nxt.locator('button').click(timeout=5000);self.pause(SETTLE_SECONDS)
                self.until(lambda:f.locator('.ant-pagination-item-active').inner_text()!=before,20,'교환 다음 페이지로 이동하지 못했습니다.')
                self.wait_exchange(f,status)
                if f.locator('.ant-pagination-total-text').inner_text()!=label:raise ReturnError('조회 중 교환 건수가 변경되었습니다.')
            if count!=total:raise ReturnError('교환 전체 건수와 수집 행 수가 다릅니다.')
        self.c.update('exchange',f'교환요청 {summary["교환요청"]}건 · 교환수거중 {summary["교환수거중"]}건 (대시보드 교환요청 {dashboard}건) · 택배사 조회 중')
        raw=self.lookup(list(dict.fromkeys(r['invoice'] for r in allrows if r['invoice'])))
        from return_data import clean_tracking
        for r in allrows:
            observed=r['returnNo'];r.update(clean_tracking(raw.get(r['invoice']),r['invoice'],today))
            if observed and r['returnNo'] and observed!=r['returnNo']:r.update(issue='에이블리 수거송장과 택배사 반품송장이 다릅니다.',returnStatus='UNKNOWN')
            if observed and not r['returnNo']:r['returnNo']=observed
        self.check_market()
        return {'complete':True,'total':len(allrows),'rows':allrows,'dashboardExchangeRequested':dashboard,'statusTotals':summary}

def collect_exchange(account,controller):
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        browser=launch_chrome(pw);context=new_context(browser,accept_downloads=False)
        try:
            flow=ExchangeFlow(controller,context,account['shopName']);flow.login(dict(account))
            try:result=flow.collect_exchange(controller.clock().date())
            except ReturnError:raise
            except Exception as exc:
                if type(exc).__name__=='ReturnCancelled':raise
                detail='' if isinstance(exc,OrderAutoError) else f' ({type(exc).__name__}: {(str(exc).splitlines()[0] if str(exc) else "")[:160]})'
                raise ReturnError('교환 조회 · '+flow.failure_message(exc)+detail) from None
        finally:context.close();browser.close()
    # Second, separate Chrome: EzAdmin C/S lookup for C+주문번호 re-shipments (read-only).
    from exchange_reship import check_reships
    controller.update('exchange',f'교환 {len(result["rows"])}건 · 이지어드민 C/S에서 교환 재발송(C주문번호)을 확인합니다.')
    check_reships(controller,result['rows'])
    errors={r.get('reshipError','') for r in result['rows'] if r.get('reshipError')}
    result['reshipError']=next(iter(errors),'');result['reshipDone']=sum(bool(r.get('reshipDone')) for r in result['rows'])
    return result

def collect_local(account,controller):
    from playwright.sync_api import sync_playwright
    from aftersales_data import local_source,local_signature,read_local
    from return_data import make_snapshot
    folder=account['folder'];before=local_signature(folder);p=local_source(folder)
    if p.stat().st_size>20*1024*1024:raise ReturnError('반품 파일은 20MB 이하만 읽습니다.')
    raw_bytes=p.read_bytes();import hashlib as _h;digest=_h.sha256(raw_bytes).hexdigest()
    entries,total=read_local(raw_bytes,controller.clock().date())
    if before!=local_signature(folder):raise ReturnError('반품 파일 저장 중입니다. 이전 결과를 유지합니다.')
    with sync_playwright() as pw:
        browser=launch_chrome(pw);context=new_context(browser,accept_downloads=False)
        try:
            flow=ReturnFlow(controller,context,account['shopName']);flow.page=context.new_page()
            raw=flow.lookup(list(dict.fromkeys(r['invoice'] for r in entries if r['invoice'])))
            controller.check()
            if before!=local_signature(folder):raise ReturnError('조회 중 반품 파일이 바뀌었습니다. 이전 결과를 유지합니다.')
            return {**make_snapshot(entries,raw,total,controller.clock().date()),'source':p.name,'digest':digest}
        finally:context.close();browser.close()
