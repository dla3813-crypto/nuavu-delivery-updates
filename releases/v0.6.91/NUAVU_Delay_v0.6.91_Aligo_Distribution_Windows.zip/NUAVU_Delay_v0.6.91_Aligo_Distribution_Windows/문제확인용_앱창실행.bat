@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\desktop_console.ps1"
