"""Windows/macOS differences in one place (2026-10-20 08:42 요청: 배포판 윈도우 버전).

- data_dir(): macOS ~/Library/Application Support/<app>, Windows %LOCALAPPDATA%\\<app>, else ~/.local/share/<slug>.
- ProcessLock: fcntl.flock on POSIX, msvcrt.locking on Windows (same "already running" semantics).
- alert(): native warning box (osascript / MessageBoxW) without interpolating text into script source.
- open_path()/reveal_path(): Finder `open` / Explorer `explorer /select,`.
- sync_directory(): directory fsync where the OS allows it (Windows cannot open a directory for fsync — skipped).
No secrets, order data or network here.
"""
from __future__ import annotations
import os,subprocess,sys
from pathlib import Path

APP_FOLDER='NUAVU Delay Distribution'
APP_SLUG='nuavu-delay-distribution'
IS_WINDOWS=sys.platform=='win32'
IS_MAC=sys.platform=='darwin'

def data_dir():
    if IS_MAC:return Path.home()/'Library/Application Support'/APP_FOLDER
    if IS_WINDOWS:
        base=os.environ.get('LOCALAPPDATA') or str(Path.home()/'AppData/Local')
        return Path(base)/APP_FOLDER
    return Path.home()/'.local/share'/APP_SLUG

def platform_name():return 'macOS' if IS_MAC else 'Windows' if IS_WINDOWS else sys.platform

class ProcessLock:
    """Exclusive, non-blocking lock on <directory>/running.lock. acquire() → True when this process now holds it."""
    def __init__(self,directory):self.path=Path(directory)/'running.lock';self.file=None
    def acquire(self):
        self.file=self.path.open('a+')
        try:
            if IS_WINDOWS:
                import msvcrt
                self.file.seek(0);msvcrt.locking(self.file.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(self.file,fcntl.LOCK_EX|fcntl.LOCK_NB)
            return True
        except (BlockingIOError,PermissionError,OSError):
            self.file.close();self.file=None;return False
    def release(self):
        if not self.file:return
        try:
            if IS_WINDOWS:
                import msvcrt
                self.file.seek(0);msvcrt.locking(self.file.fileno(),msvcrt.LK_UNLCK,1)
            else:
                import fcntl
                fcntl.flock(self.file,fcntl.LOCK_UN)
        except Exception:pass
        try:self.file.close()
        except Exception:pass
        self.file=None

def alert(title,message):
    """Warning box; text is passed as data, never built into script/command source."""
    try:
        if IS_MAC:
            script='on run argv\n display alert (item 1 of argv) message (item 2 of argv) as warning\nend run'
            subprocess.run(['/usr/bin/osascript','-e',script,title,message],check=False)
        elif IS_WINDOWS:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None,str(message),str(title),0x30)   # MB_ICONWARNING
    except Exception:pass

def open_path(path):
    path=Path(path)
    if IS_MAC:subprocess.run(['/usr/bin/open',str(path)],check=True,timeout=10,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    elif IS_WINDOWS:os.startfile(str(path))  # type: ignore[attr-defined]
    else:subprocess.run(['xdg-open',str(path)],check=True,timeout=10,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)

def reveal_path(path):
    path=Path(path)
    if IS_MAC:subprocess.run(['/usr/bin/open','-R',str(path)],check=True,timeout=10,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    elif IS_WINDOWS:subprocess.run(['explorer','/select,',str(path)],check=False,timeout=10)
    else:open_path(path.parent)

def sync_directory(directory):
    if IS_WINDOWS:return
    fd=os.open(directory,os.O_RDONLY)
    try:os.fsync(fd)
    finally:os.close(fd)
