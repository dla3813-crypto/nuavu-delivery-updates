"""Manual/daily return reads, one worker, atomic snapshots and persistent daily claim."""
from __future__ import annotations
from job_alerts import job_alert
import copy,hashlib,re,secrets,threading
from datetime import datetime
from return_data import ReturnError,ReturnCancelled,public_returns
from ably_credentials import AblyAccounts
from credentials import VaultError
from aftersales_lock import operation_lock
from aftersales_data import shop,public_aftersales,folder_default,local_signature,local_source
import time

# 10:04 보고(Windows): zoneinfo 는 Windows에 시간대 DB가 없어 import 시점에 실패한다 → 한국은 서머타임이 없으니 고정 +9 로 대체.
try:
    from zoneinfo import ZoneInfo;KST=ZoneInfo('Asia/Seoul')
except Exception:
    from datetime import timezone as _tz,timedelta as _td;KST=_tz(_td(hours=9),'KST')
WATCH_MIN_INTERVAL=600  # seconds between automatic file-change runs; a changed file waits, it is not skipped
WATCH_MAX_BYTES=20*1024*1024

def file_digest(folder):
    """Content hash of 에이블리 반품진행상황.xlsx. The watcher runs on changed CONTENT only, so
    iCloud/Excel re-stamping the same file (new mtime/inode) never starts another read."""
    p=local_source(folder)
    if p.stat().st_size>WATCH_MAX_BYTES:raise ReturnError('반품 파일은 20MB 이하만 읽습니다.')
    return hashlib.sha256(p.read_bytes()).hexdigest()

class ReturnController:
    def __init__(self,engine,runner=None,vault=None,clock=None,busy=None,local=False):
        self.local=local;self.observed=None;self.observed_at=0;self.attempted=None;self.last_auto_at=None;self.watch_note=''
        self.engine=engine;self.runner=runner;self.accounts=AblyAccounts(engine.store.directory,vault)
        self.clock=clock or (lambda:datetime.now(KST));self.busy=busy or (lambda:False)
        self.lock=threading.RLock();self.stop=threading.Event();self.scheduler_stop=threading.Event()
        self.thread=None;self.scheduler_thread=None;self.command=None
        self.job={'phase':'idle','message':'반품체크를 누르면 에이블리 목록과 반품송장을 조회합니다.'}
    def running(self):return bool(self.thread and self.thread.is_alive())
    def config(self):
        s=self.engine.store.read().get('returnSettings',{})
        return {'mode':s.get('mode','manual'),'time':s.get('time','09:00'),'local':self.local,'folder':s.get('folder') or str(folder_default()),'watchEnabled':bool(s.get('watchEnabled',False))}
    def status(self):
        with self.lock:
            data=self.engine.store.read();visible=copy.deepcopy(self.job)
            previous=data.get('returnRun',{})
            if visible.get('phase')=='idle' and previous:
                visible.update(phase=previous.get('phase','idle'),message=previous.get('message',''))
                if visible['phase']=='running':visible.update(phase='error',message='이전 반품 조회가 완료되지 않았습니다. 마지막 정상 결과를 유지합니다. 필요하면 지금 조회를 실행하세요.')
            if self.watch_note and not visible.get('message'):visible['message']=self.watch_note
            return {**visible,'running':self.running(),'settings':self.config(),'watchNote':self.watch_note,
                    'lastAttempt':data.get('returnRun',{}).get('at',''),
                    'lastResult':data.get('returnRun',{}).get('message',''),
                    'data':public_aftersales(data,self.clock().date())}
    def save(self,settings):
        if not isinstance(settings,dict) or settings.get('mode') not in ('manual','daily') or not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d',str(settings.get('time',''))):
            raise ReturnError('수동 또는 매일 실행과 올바른 시간을 선택하세요.')
        with self.lock,self.engine.store.edit() as s:
            previous=s.get('returnSettings',{})
            enabled=settings.get('watchEnabled',previous.get('watchEnabled',False))
            if type(enabled)is not bool:raise ReturnError('자동 파일 확인 설정을 확인하세요.')
            folder=settings.get('folder',previous.get('folder') or str(folder_default()))
            from pathlib import Path
            if not isinstance(folder,str) or not Path(folder).is_absolute():raise ReturnError('반품 폴더를 선택하세요.')
            s['returnSettings']={**previous,**{k:settings[k] for k in ('mode','time')},'watchEnabled':enabled,'folder':folder}
            if folder!=previous.get('folder'):self.attempted=None;s['returnSettings'].pop('watchDigest',None)
        return self.status()
    def start(self,scheduled=False,kind="return",seller=''):
        # Native calls and the scheduler use the same lock as reset/account edits.
        with operation_lock(self.engine),self.lock:
            if self.scheduler_stop.is_set() or self.engine.stop.is_set() or getattr(self.engine,'reset_in_progress',False):raise ReturnError('앱 종료 또는 전체 초기화 중입니다.')
            if self.running():raise ReturnError('이미 반품 조회 중입니다.')
            if self.busy():raise ReturnError('에이블리 동기화가 끝난 뒤 반품체크를 실행하세요.')
            if kind not in ('return','exchange','all','test','seller'):raise ReturnError('조회 종류를 확인하세요.')
            if kind in ('test','seller') and seller not in ('에이블리','자사몰','지그재그'):raise ReturnError('판매처를 확인하세요.')
            cfg=shop(self.engine.store.read())
            if not self.local and not self.engine.store.read().get('settings',{}).get('shopName'):raise ReturnError('쇼핑몰 이름을 먼저 설정하세요.')
            account={} if (self.local and kind=='return') or (kind in ('test','seller') and seller!='에이블리') else self.accounts.for_login()
            account.update(**cfg,local=self.local,folder=self.config()['folder'],kind=kind,testSeller=seller,onlySeller=seller if kind=='seller' else '')
            self.stop.clear();self.command=None
            stamp=self.clock().isoformat();job_id=secrets.token_urlsafe(16)
            self.job={'id':job_id,'phase':'running','message':(f'{seller} 반품 테스트 조회 (저장·처리 없음)' if kind=='test' else f'{seller} 반품만 조회합니다.' if kind=='seller' else '전용 Chrome에서 반품 목록을 확인합니다.'),'scheduled':scheduled,'kind':kind,'testSeller':seller}
            if kind!='test':
                with self.engine.store.edit() as s:s['returnRun']={'at':stamp,'phase':'running','message':'반품 조회 중'}
            self.thread=threading.Thread(target=self._run_test if kind=='test' else self._run,args=(account,),daemon=True);self.thread.start()
            return self.status()
    def check(self):
        if self.stop.is_set() or self.scheduler_stop.is_set():raise ReturnCancelled('반품 조회를 중단했습니다. 이전 결과를 유지합니다.')
    def update(self,phase,message):
        with self.lock:self.job.update(phase=phase,message=message)
    def browser_failed(self,message,browser_open,can_continue=False):
        import browser_window;browser_window.attention()
        with self.lock:self.job.update(phase='login_wait' if can_continue else 'error_open',message=message,browserOpen=browser_open,canContinue=can_continue)
    def take_browser_action(self):
        with self.lock:command=self.command;self.command=None;return command
    def continue_login(self,job_id):
        with self.lock:
            if not self.running() or not self.job.get('canContinue') or self.job.get('id')!=job_id:raise ReturnError('현재 로그인 대기 작업에서만 계속할 수 있습니다.')
            self.command=('continue',None)
        return self.status()
    def end_browser_recovery(self):
        import browser_window;browser_window.calm()
        with self.lock:self.job.update(phase='running',browserOpen=False,canContinue=False);self.command=None
    ezadmin_account=None  # set by the desktop bridge: callable returning the saved EzAdmin login (for the exchange re-ship check)
    def ask_login_confirmation(self,text):
        """EzAdmin login prompt during the exchange re-ship check: 계속 = accept, 중단/timeout = decline."""
        import time,browser_window;browser_window.attention()
        with self.lock:self.check();self.command=None;self.job.update(phase='login_wait',message='이지어드민 확인 요청: '+text+' → 승인하려면 계속, 아니면 중단을 누르세요.',browserOpen=True,canContinue=True)
        try:
            deadline=time.monotonic()+180
            while time.monotonic()<deadline:
                self.check()
                with self.lock:command=self.command;self.command=None
                if command and command[0]=='continue':return True
                time.sleep(.1)
            return False
        finally:self.end_browser_recovery()
    def _run_test(self,account):
        seller=account.get('testSeller','')
        try:
            from aftersales_collect import collect_test
            got=collect_test(account,self,seller)
            rows=got.get('rows',[])
            lines=[f"{r.get('requestedAt','')} · {r.get('itemId') or r.get('orderId','')} · {r.get('customer','')} · {r.get('product','')} {('['+r['option']+']') if r.get('option') else ''} · {r.get('reason','')} · 원송장 {r.get('invoice') or '없음'} · {r.get('issue') or r.get('returnStatus') or ''}" for r in rows[:50]]
            message=f'{seller} 반품 테스트 · {len(rows)}건 읽음'+(' · '+got['note'] if got.get('note') else '')+' · 저장·회수접수·수거완료 없음'
            with self.lock:self.job.update(phase='done',message=message,testRows=lines,browserOpen=False,canContinue=False)
        except Exception as exc:
            from order_auto import OrderAutoError
            msg=str(exc) if isinstance(exc,(ReturnError,VaultError,OrderAutoError)) or type(exc).__name__ in ('DisplayError','ZigzagError') else f'{seller} 반품 테스트 중 문제가 발생했습니다. (오류 종류: {type(exc).__name__})'
            last=self.job.get('message','')
            if last and last not in msg:msg+=' · 마지막 단계: '+last
            with self.lock:self.job.update(phase='cancelled' if self.stop.is_set() else 'error',message=f'{seller} 반품 테스트 실패 · '+msg,testRows=[],browserOpen=False,canContinue=False)
        finally:account.clear()
    def _run(self,account):
        shop={k:account[k] for k in ('shopName','shopRevision')}
        try:
            from aftersales_collect import collect,collect_seller
            snapshot=collect_seller(account,self) if account.get('kind')=='seller' and not self.runner else (self.runner or collect)(account,self)
            with self.lock:
                self.check()
                rows=snapshot.get('rows')
                if snapshot.get('complete') is not True or not isinstance(rows,list) or type(snapshot.get('total'))is not int or not 0<=len(rows)==snapshot['total']<=20000:
                    raise ReturnError('전체 반품 조회가 완료되지 않아 이전 결과를 유지합니다.')
                stamp=self.clock().isoformat();message=f'{"교환" if account.get("kind")=="exchange" else "반품"} {len(rows)}개 상품 조회를 완료했습니다.'
                zz=snapshot.get('zigzag') or {}
                if zz.get('enabled'):
                    totals=zz.get('totals') or {}
                    message+=' · 지그재그 '+(' / '.join(f'{k} {v}건' for k,v in totals.items()) if totals else '0건')
                    done=[a for a in zz.get('actions',[]) if str(a.get('result','')).endswith('완료')];bad=[a for a in zz.get('actions',[]) if not str(a.get('result','')).endswith('완료')]
                    if done:message+=f' · 수거완료 처리 {len(done)}건'
                    if bad:message+=f' · 수거완료 확인 필요 {len(bad)}건'
                    if zz.get('error'):message+=' · 지그재그 조회 실패: '+zz['error']
                elif zz.get('note'):message+=' · '+zz['note']
                cf=snapshot.get('cafe24') or {}
                if cf.get('enabled'):message+=' · 자사몰 '+(cf['error'] and '조회 실패: '+cf['error'] or ' / '.join(f'{k} {v}건' for k,v in (cf.get('totals') or {}).items()) or '0건')
                if account.get('kind')=='exchange':
                    message+=f' · 교환 재발송(C주문번호) 확인 {snapshot.get("reshipDone",0)}건'+(' · 이지어드민 확인 실패: '+snapshot['reshipError'] if snapshot.get('reshipError') else '')
                with self.engine.store.edit() as s:
                    if any((s['settings'].get(k,0 if k=='shopRevision' else '') or ('누아브' if k=='shopName' else 0))!=shop[k] for k in shop):raise ReturnError('조회 중 쇼핑몰 설정이 바뀌어 결과를 반영하지 않았습니다.')
                    target='exchangeCheck' if account.get('kind')=='exchange' else 'returnCheck'
                    only=account.get('onlySeller') if account.get('kind')=='seller' else ''
                    prev=s.get('returnCheck') or {}
                    prev_same=all(prev.get(k)==v for k,v in shop.items())
                    if only:
                        # 판매처별 반품조회: replace only that seller's rows; the other sellers keep their last result.
                        keep=[r for r in (prev.get('rows',[]) if prev_same else []) if (r.get('seller') or '에이블리')!=only]
                        message=f'{only}만 조회 · '+message+(f' · 다른 판매처 {len(keep)}개 상품은 이전 결과 유지' if keep else '')
                        s[target]={**shop,'rows':keep+copy.deepcopy(rows),'lastChecked':stamp,'source':snapshot.get('source','') if only=='에이블리' else prev.get('source','')}
                    else:s[target]={**shop,'rows':copy.deepcopy(rows),'lastChecked':stamp,'source':snapshot.get('source','')}
                    if snapshot.get('digest'):s.setdefault('returnSettings',{})['watchDigest']=snapshot['digest']
                    s[target]['zigzag']=snapshot.get('zigzag',{}) if (not only or only=='지그재그') else (prev.get('zigzag',{}) if prev_same else {})
                    s[target]['cafe24']=snapshot.get('cafe24',{}) if (not only or only=='자사몰') else (prev.get('cafe24',{}) if prev_same else {})
                    if 'zigzagExchangeRows' in snapshot:
                        # 반품체크 only: replace the 지그재그 part of the exchange list, keep the Ably exchange rows as they were.
                        prev=s.get('exchangeCheck') or {}
                        keep=[r for r in prev.get('rows',[]) if r.get('seller')!='지그재그'] if all(prev.get(k)==v for k,v in shop.items()) else []
                        s['exchangeCheck']={**shop,'rows':keep+copy.deepcopy(snapshot['zigzagExchangeRows']),'lastChecked':prev.get('lastChecked','') if keep else stamp,'source':prev.get('source','')}
                    if 'cafe24ExchangeRows' in snapshot:
                        # 2026-10-21: 자사몰 교환 — replace only the 자사몰 part of the exchange list.
                        prev_ex=s.get('exchangeCheck') or {}
                        keep_ex=[r for r in prev_ex.get('rows',[]) if r.get('seller')!='자사몰'] if all(prev_ex.get(k)==v for k,v in shop.items()) else []
                        s['exchangeCheck']={**shop,'rows':keep_ex+copy.deepcopy(snapshot['cafe24ExchangeRows']),'lastChecked':prev_ex.get('lastChecked','') if keep_ex else stamp,'source':prev_ex.get('source','')}
                    if account.get('kind')=='all':
                        exchange=snapshot.get('exchangeRows')
                        if not isinstance(exchange,list):raise ReturnError('교환 조회가 완료되지 않았습니다.')
                        s['exchangeCheck']={**shop,'rows':copy.deepcopy(exchange),'lastChecked':stamp}
                    s['returnRun']={'at':stamp,'phase':'done','message':message}
                    s['audits'].append({'at':stamp,'event':'반품 조회 완료','items':len(rows)})
                self.job.update(phase='done',message=message,browserOpen=False,canContinue=False)
            job_alert(self.engine,('교환 조회 완료' if account.get('kind')=='exchange' else '반품체크 완료')+(' (자동)' if self.job.get('scheduled') else ''),message)
            if account.get('kind')=='exchange' and snapshot.get('reshipError'):job_alert(self.engine,'교환 재발송(C주문번호) 확인 막힘','이지어드민 C/S 확인 실패: '+str(snapshot['reshipError'])+' · 교환 목록은 저장했고 재발송 표시만 빠졌습니다.','error')
        except Exception as exc:
            from order_auto import OrderAutoError
            last=self.job.get('message','')
            if isinstance(exc,(ReturnError,VaultError,OrderAutoError)):msg=str(exc)
            else:msg=f'반품 조회 중 문제가 발생했습니다. 이전 결과를 유지합니다. (오류 종류: {type(exc).__name__})'  # unknown exception text is never shown: it may carry secrets
            if last and last not in msg:msg+=' · 마지막 단계: '+last
            phase='cancelled' if self.stop.is_set() or self.scheduler_stop.is_set() else 'error'
            with self.lock:self.job.update(phase=phase,message=msg,browserOpen=False,canContinue=False)
            if phase=='error':job_alert(self.engine,('교환 조회' if account.get('kind')=='exchange' else '반품체크')+' 실패',msg,'error')
            # Reset waits for this worker before closing/deleting the Store.
            with self.engine.store.edit() as s:s['returnRun']={'at':self.clock().isoformat(),'phase':phase,'message':msg}
        finally:account.clear()
    def cancel(self):
        with self.lock:
            self.stop.set();self.command=None
            if self.running():self.job['message']='반품 조회와 Chrome 창을 닫는 중입니다.'
        return self.status()
    def tick(self):
        guard=operation_lock(self.engine)
        if not guard.acquire(blocking=False):return False
        try:
            with self.lock:
                if self.scheduler_stop.is_set() or self.engine.stop.is_set() or getattr(self.engine,'reset_in_progress',False) or self.running() or self.busy():return False
                now=self.clock();cfg=self.config();day=now.date().isoformat()
                if self.local and cfg['watchEnabled']:
                    try:sig=local_signature(cfg['folder'])
                    except ReturnError:
                        self.job.update(phase='error',message='반품 파일을 찾지 못했습니다. 연결 폴더를 확인하세요.');return False
                    if sig!=self.observed:self.observed=sig;self.observed_at=time.monotonic()
                    elif sig!=self.attempted and time.monotonic()-self.observed_at>=5:
                        # The file stopped changing. Read only when its CONTENT differs from what was last
                        # processed (persisted across restarts), and never more than once per interval.
                        digest=None
                        try:digest=file_digest(cfg['folder'])
                        except ReturnError as exc:self.attempted=sig;self.watch_note=str(exc)
                        if digest is not None:
                            last=self.engine.store.read().get('returnSettings',{}).get('watchDigest','')
                            if digest==last:self.attempted=sig;self.watch_note=''
                            elif self.last_auto_at is not None and time.monotonic()-self.last_auto_at<WATCH_MIN_INTERVAL:
                                wait=int(WATCH_MIN_INTERVAL-(time.monotonic()-self.last_auto_at))
                                self.watch_note=f'반품 파일이 바뀌었습니다. 자동 조회는 {WATCH_MIN_INTERVAL//60}분 간격으로 실행합니다 · {max(wait,1)}초 뒤 확인'
                            else:
                                self.attempted=sig;self.last_auto_at=time.monotonic();self.watch_note=''
                                with self.engine.store.edit() as s:s.setdefault('returnSettings',{})['watchDigest']=digest
                                self.start(scheduled=True,kind='return');return True
                s=self.engine.store.read()
                if cfg['mode']!='daily' or now.strftime('%H:%M')<cfg['time'] or s.get('returnScheduledDay')==day:return False
                # Persist before login or browser startup: an error or app restart
                # cannot repeatedly submit the same scheduled download.
                with self.engine.store.edit() as s:s['returnScheduledDay']=day
                try:self.start(scheduled=True,kind="all")
                except Exception as exc:
                    msg=str(exc) if isinstance(exc,(ReturnError,VaultError)) else '자동 반품 조회를 시작하지 못했습니다. 설정을 확인하세요.'
                    self.job.update(phase='error',message=msg)
                    with self.engine.store.edit() as s:s['returnRun']={'at':now.isoformat(),'phase':'error','message':msg}
                return True
        finally:guard.release()
    def start_scheduler(self):
        if self.scheduler_thread and self.scheduler_thread.is_alive():return
        def loop():
            while not self.scheduler_stop.wait(10):
                try:self.tick()
                except Exception:pass  # No secrets/tracebacks from saved account errors.
        self.scheduler_thread=threading.Thread(target=loop,daemon=True);self.scheduler_thread.start()
    def shutdown(self):
        self.scheduler_stop.set();self.stop.set()
