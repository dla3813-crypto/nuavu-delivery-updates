"""(Auto)반품체크 브라우저 단계 — 에이블리 반품 진행 관리 엑셀(지난 일년) 다운로드 + CJ/우체국 같은 오리진 조회.

실측 DOM(2026-10-18): 반품 접수일 .el-date-editor--daterange input.el-range-input → 달력 .el-picker-panel.el-date-range-picker
의 .el-picker-panel__shortcut '지난 한 주/지난 30일/지난 일년' · 버튼 '검색' '전체 주문 엑셀 다운로드'.
전체 다운로드 건수는 반품상태 카드의 반품요청 + 검수대기 합계다. 페이지네이션 건수는 사용하지 않는다.
"""
import datetime as dt
import re,unicodedata
from pathlib import Path
from urllib.parse import urlsplit
from return_session import AblySession
from return_data import carrier_of
from return_data import ReturnError as OrderAutoError

RETURN_URL='https://my.a-bly.com/sales/order/return/progress'
CJ_URL='https://www.cjlogistics.com/ko/tool/parcel/tracking'
EPOST_HOST='service.epost.go.kr'
EPOST_URL='https://service.epost.go.kr/trace.RetrieveDomRigiTraceList.comm?ems_gubun=E&sid1=%s&POST_CODE=&mgbn=trace&traceselect=1&target_command=&JspURI=&postNum=%s'
CHUNK=1  # check cancellation after each original/return pair
CJ_JS=r'''async (invoices)=>{const out={};const csrf=document.querySelector('input[name="_csrf"]')?.value||'';
const q=async no=>{const r=await fetch('https://www.cjlogistics.com/ko/tool/parcel/tracking-detail',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},signal:AbortSignal.timeout(15000),body:'paramInvcNo='+encodeURIComponent(no)+'&_csrf='+encodeURIComponent(csrf)});if(!r.ok)throw new Error('HTTP '+r.status);return r.json();};
const day=t=>(t||'').slice(0,10);
for(const no of invoices){try{const j=await q(no);const ev=j.parcelDetailResultMap?.resultList||[];const sum=(j.parcelResultMap?.resultList||[])[0]||{};
if(!j.parcelDetailResultMap || !j.parcelResultMap)throw new Error('schema');
let orig='';for(const e of ev)if(e.scanNm==='배송완료')orig=day(e.dTime);
const rec={carrier:'CJ',orig_delivered:orig,return_no:sum.rtnTrspbillnum||'',return_status:'NONE',return_delivered:''};
if(rec.return_no&&!/^\d{10,14}$/.test(rec.return_no))throw new Error('invoice');if(rec.return_no){const j2=await q(rec.return_no);const ev2=j2.parcelDetailResultMap?.resultList||[];if(!j2.parcelDetailResultMap)throw new Error('schema');
const last=ev2[ev2.length-1];
if(!last)rec.return_status='NONE';else if(last.scanNm==='배송완료'){rec.return_status='DELIVERED';rec.return_delivered=day(last.dTime);}else if(ev2.some(e=>/집화|상품인수|간선|배송출발|배달출발/.test(e.scanNm||'')))rec.return_status='IN_TRANSIT';else if(ev2.every(e=>/접수|예약|등록/.test(e.scanNm||'')))rec.return_status='REGISTERED';else throw new Error('unknown status');}
out[no]=rec;}catch(e){out[no]={carrier:'CJ',error:'택배사 조회 응답을 확인하지 못했습니다',return_status:'NONE'};}
await new Promise(r=>setTimeout(r,50));}
return out;}'''
EPOST_JS=r'''async ([invoices,urlTemplate])=>{const out={};
const url=no=>urlTemplate.split('%s').join(no);
const trace=async no=>{const r=await fetch(url(no),{credentials:'include',signal:AbortSignal.timeout(15000)});if(!r.ok)throw new Error('HTTP '+r.status);const html=await r.text();
const doc=new DOMParser().parseFromString(html,'text/html');const nodes=[];if(doc.body){const w=doc.createTreeWalker(doc.body,4);while(w.nextNode())nodes.push(w.currentNode.nodeValue);}const text=nodes.join(' ');
const norm=text.replace(/\s+/g,' ');const rtn=(norm.match(/반품등기번호[:\s]*([0-9]{10,16})/)||[])[1]||'';
// 우체국은 회수(방문접수)만 등록된 반품을 원송장 페이지의 반품등기번호 옆에 "(접수전)"으로 표시한다. 반품등기번호 자체 페이지에는 아직 이력이 없다.
const rtnPending=/반품등기번호[:\s]*[0-9]{10,16}\s*\(\s*접수\s*전\s*\)/.test(norm);const events=[];
for(const tr of doc.querySelectorAll('table tr')){const t=[...tr.querySelectorAll('td')].map(td=>td.textContent.trim());
if(t.length>=4&&/^\d{4}\.\d{2}\.\d{2}$/.test(t[0]))events.push({d:t[0].replace(/\./g,'-'),status:t[3].replace(/\(.*$/s,'').trim().split(/\n/)[0].trim(),raw:t[3].trim()});}
if(!events.length&&!/찾지 못했|입력되지 않았|조회.*없|정보.*없|찾을 수 없|등록.*않/.test(norm))throw new Error('unknown page');
const last=events[events.length-1]||null;const delivered=events.filter(e=>e.status.includes('배달완료')).pop()||null;
// 방문접수(회수) 반품등기번호 페이지는 집하 전까지 운송장출력 → 수거준비 → 미수거(재방문 대기) 같은 '수거 전' 이력만 보인다 (2026-10-19 실측 7091402789162). 전부 수거 전이면 회수 접수 완료.
const PRE=/^(?:운송장\s*출력|수거\s*준비|미수거|수거\s*예정|(?:소포)?접수|접수\s*전)$/;
const registered=events.length>0&&events.every(e=>/접수전|접수\s*전/.test(e.raw)||(!e.status&&/접수/.test(e.raw))||PRE.test(e.status.replace(/\s+/g,'')));
return {rtn,rtnPending,last,deliveredDate:delivered?delivered.d:'',hasEvents:events.length>0,registered,inTransit:events.some(e=>/집하|집화|발송|도착|배달준비/.test(e.status))||(!registered&&events.some(e=>/접수/.test(e.status)))};};
for(const no of invoices){try{const a=await trace(no);const rec={carrier:'EPOST',orig_delivered:a.deliveredDate,return_no:a.rtn,return_status:'NONE',return_delivered:''};
if(rec.return_no&&!/^\d{10,14}$/.test(rec.return_no))throw new Error('invoice');if(rec.return_no){const b=await trace(rec.return_no);if(!b.hasEvents)rec.return_status=a.rtnPending?'REGISTERED':'NONE';else if(b.last&&b.last.status.includes('배달완료')){rec.return_status='DELIVERED';rec.return_delivered=b.deliveredDate;}else if(b.registered)rec.return_status='REGISTERED';else if(b.inTransit)rec.return_status='IN_TRANSIT';else if(a.rtnPending)rec.return_status='REGISTERED';else throw new Error('unknown status');}
out[no]=rec;}catch(e){out[no]={carrier:'EPOST',error:'택배사 조회 응답을 확인하지 못했습니다',return_status:'NONE'};}
await new Promise(r=>setTimeout(r,80));}
return out;}'''

def year_ago_ok(start_text,today):
    try:start=dt.date.fromisoformat(start_text.strip()[:10].replace('.','-'))
    except ValueError:return False
    return 360 <= (today-start).days <= 367

def return_status_counts(cards):
    """Count only the two pending statuses, never completed/refund-request cards."""
    labels={'반품요청(접수필요)':'requested','반품요청':'requested','검수대기':'waiting'}
    counts={}
    if not isinstance(cards,list):raise OrderAutoError('반품요청·검수대기 건수를 읽지 못했습니다.')
    for card in cards:
        if not isinstance(card,dict):raise OrderAutoError('반품 상태 표시를 확인하지 못했습니다.')
        title=card.get('title','').strip();key=labels.get(re.sub(r'\s+','',title))
        if not key:continue
        value=card.get('text','').strip()
        # The observed status card contains a title followed by one count in 건.
        if key in counts or not value.startswith(title):raise OrderAutoError('반품요청·검수대기 건수를 하나로 확인하지 못했습니다.')
        match=re.fullmatch(r'(0|[1-9]\d*|[1-9]\d{0,2}(?:,\d{3})+)\s*건',value[len(title):].strip())
        if not match:raise OrderAutoError('반품요청·검수대기 건수의 숫자를 확인하지 못했습니다.')
        counts[key]=int(match[1].replace(',',''))
    if set(counts)!={'requested','waiting'}:raise OrderAutoError('반품요청과 검수대기 건수를 모두 확인하지 못했습니다.')
    if sum(counts.values())>20000:raise OrderAutoError('반품 목록은 20,000개 상품까지 조회할 수 있습니다.')
    return counts

class ReturnFlow(AblySession):
    def pending_counts(self):
        cards=self.page.locator('.return-status-filter__filter:visible').evaluate_all('''cards=>cards.map(card=>({title:card.querySelector('.return-status-filter__filter--title')?.innerText||'',text:card.innerText}))''')
        return return_status_counts(cards)
    def set_last_year(self,today):
        page=self.page;self.step='반품 접수일 지난 일년 설정'
        field=page.locator('.el-date-editor--daterange input.el-range-input').first
        for attempt in range(3):
            field.click(timeout=5000);self.pause(.4)
            panel=page.locator('.el-picker-panel.el-date-range-picker:visible')
            self.until(lambda:panel.count()>0,10,'반품 접수일 달력이 열리지 않았습니다.')
            shortcut=panel.first.locator('.el-picker-panel__shortcut',has_text=re.compile(r'^\s*지난 일년\s*$'))
            if shortcut.count()!=1:raise OrderAutoError('달력에서 ‘지난 일년’ 버튼을 하나로 찾지 못했습니다.')
            shortcut.first.click(timeout=5000);self.pause(.5)
            if year_ago_ok(field.input_value(),today):
                ends=page.locator('.el-date-editor--daterange input.el-range-input')
                end=ends.nth(1).input_value().strip()[:10].replace('.','-') if ends.count()==2 else ''
                if end==today.isoformat():return
        raise OrderAutoError('반품 접수일 시작일이 1년 전으로 바뀌지 않았습니다. 기본값(한 달)으로는 진행하지 않습니다.')
    def table_idle(self):
        self.pause(.6)
        self.until(lambda:not self.page.locator('.el-loading-mask:visible').count() and self.page.locator('.el-pagination__total').count(),60,'반품 목록 조회가 끝나지 않았습니다.')
        self.pause(.6)
    def download_excel(self,folder,today):
        page=self.page;self.step='반품 진행 관리 열기';self.c.update('ably','반품 진행 관리 목록을 엽니다.')
        self.navigate(RETURN_URL);self.pause(1);self.dismiss_popups();self.check_market()
        self.set_last_year(today)
        self.step='반품 목록 검색'
        button=self.until(lambda:self.button('검색').count()==1 and self.button('검색').first,20,'반품 목록의 검색 버튼을 하나로 찾지 못했습니다.')
        self.c.check();button.click(timeout=10000);self.table_idle()
        counts=self.pending_counts();total=sum(counts.values())
        if total==0:
            self.pause(1);self.check_market()
            if self.pending_counts()!=counts:raise OrderAutoError('반품요청·검수대기 건수가 바뀌었습니다. 다시 조회하세요.')
            return None,0
        self.check_market()
        self.step='전체 주문 엑셀 다운로드';self.c.update('ably',f'반품요청 {counts["requested"]}건 + 검수대기 {counts["waiting"]}건 = 총 {total}건 · 전체 주문 엑셀을 내려받습니다.')
        export=self.button('전체 주문 엑셀 다운로드')
        self.until(lambda:export.count()==1 and export.first.is_enabled(),30,'전체 주문 엑셀 다운로드 버튼이 활성화되지 않았습니다.')
        self.c.check()
        with page.expect_download(timeout=120000) as result:
            export.first.click(timeout=10000)  # 딱 한 번만 누른다
        download=result.value
        name=unicodedata.normalize('NFC',download.suggested_filename)
        if Path(name).name!=name or '/' in name or '\\' in name:raise OrderAutoError('다운로드 파일명이 올바르지 않습니다.')
        if '반품 진행 관리' not in name or not name.lower().endswith('.xlsx'):
            raise OrderAutoError('예상한 반품 진행 관리 엑셀 파일명이 아닙니다.')
        folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
        target=folder/name;n=2
        while target.exists():target=folder/(Path(name).stem+f' ({n}).xlsx');n+=1
        download.save_as(str(target))
        if download.failure():raise OrderAutoError('반품 엑셀 다운로드가 완료되지 않았습니다.')
        self.check_market()
        if self.pending_counts()!=counts:raise OrderAutoError('다운로드 중 반품요청·검수대기 건수가 바뀌어 기존 결과를 유지합니다.')
        if target.stat().st_size>20*1024*1024:raise OrderAutoError('반품 엑셀이 20MB를 초과합니다.')
        return target,total
    # ---- 송장 조회 (같은 오리진 fetch) ----
    def lookup(self,invoices):
        groups={'CJ':[],'EPOST':[],'UNKNOWN':[]}
        for inv in invoices:groups[carrier_of(inv)].append(inv)
        results={}
        for inv in groups['UNKNOWN']:results[inv]={'carrier':'UNKNOWN','return_status':'NONE','error':'택배사 판별 불가'}
        for carrier,fn in [('CJ',self.lookup_cj),('EPOST',self.lookup_epost)]:
            if not groups[carrier]:continue
            try:results.update(fn(groups[carrier]))
            except Exception:
                self.c.check()
                for inv in groups[carrier]:results[inv]={'carrier':carrier,'return_status':'NONE','error':'택배사 연결 또는 화면 확인 실패'}
        missing=[inv for inv in invoices if inv not in results]
        if missing:raise OrderAutoError(f'조회 결과가 누락된 송장 {len(missing)}건이 있어 색칠하지 않았습니다.')
        return results
    def _run_chunks(self,page,invoices,script,label,extra=None):
        out={}
        for i in range(0,len(invoices),CHUNK):
            chunk=invoices[i:i+CHUNK];self.c.check()
            self.c.update('tracking',f'{label} 조회 {min(i+CHUNK,len(invoices))}/{len(invoices)}')
            part=page.evaluate(script,[chunk,extra] if extra is not None else chunk)
            if not isinstance(part,dict) or any(inv not in part for inv in chunk):raise OrderAutoError(f'{label} 조회 응답이 불완전합니다.')
            out.update(part)
        return out
    def lookup_cj(self,invoices):
        main=self.page;page=self.context.new_page();self.page=page;self.step='CJ대한통운 조회'
        try:
            page.goto(CJ_URL,wait_until='domcontentloaded',timeout=45000)
            u=urlsplit(page.url)
            if u.scheme!='https' or u.hostname!='www.cjlogistics.com':raise OrderAutoError('CJ대한통운 조회 페이지가 아닙니다.')
            page.locator('input[name="_csrf"]').first.wait_for(state='attached',timeout=20000)
            return self._run_chunks(page,invoices,CJ_JS,'CJ대한통운')
        finally:
            self.page=main
            try:page.close()
            except Exception:pass
    def lookup_epost(self,invoices):
        main=self.page;page=self.context.new_page();self.page=page;self.step='우체국 조회'
        try:
            page.goto(EPOST_URL%(invoices[0],invoices[0]),wait_until='domcontentloaded',timeout=45000)
            u=urlsplit(page.url)
            if u.scheme!='https' or u.hostname!=EPOST_HOST:raise OrderAutoError('우체국 조회 페이지가 아닙니다.')
            return self._run_chunks(page,invoices,EPOST_JS,'우체국',EPOST_URL)
        finally:
            self.page=main
            try:page.close()
            except Exception:pass


def collect(account,controller):
    """One fresh context; raw customer workbook lives only in a private temp directory."""
    import tempfile
    from playwright.sync_api import sync_playwright
    from return_session import launch_chrome,new_context
    from return_data import read_returns,make_snapshot,ReturnCancelled
    with sync_playwright() as pw:
        browser=launch_chrome(pw)
        context=new_context(browser,accept_downloads=True)
        flow=ReturnFlow(controller,context,account['shopName'])
        try:
            flow.login(dict(account))
            controller.check()
            today=controller.clock().date()
            with tempfile.TemporaryDirectory(prefix='delivery-return-') as tmp:
                source,total=flow.download_excel(tmp,today)
                entries=read_returns(source.read_bytes(),total,today) if source else []
                controller.update('running',f'반품 {total}건 · 상품 {len(entries)}개 확인(제목 행 제외) · 반품송장을 조회합니다.')
                invoices=list(dict.fromkeys(r['invoice'] for r in entries if r['invoice']))
                raw=flow.lookup(invoices)
                controller.check();flow.check_market()
                return {**make_snapshot(entries,raw,total,today),'source':'에이블리 다운로드'}
        except ReturnCancelled:raise
        except Exception as exc:
            message=flow.failure_message(exc)
            controller.browser_failed(message+' Chrome 창을 확인한 뒤 닫기를 누르세요. 기존 조회 결과를 유지합니다.',True,False)
            # Retain the window until the user closes/cancels; never resubmit.
            while any(not p.is_closed() for p in context.pages):
                controller.check()
                page=next((p for p in context.pages if not p.is_closed()),None)
                if page is None:break
                try:page.wait_for_timeout(150)
                except Exception:break
            raise OrderAutoError(message) from None
        finally:
            try:context.close()
            finally:browser.close()
