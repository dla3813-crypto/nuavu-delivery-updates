"""아무드(일본) 배송지연 메시지 발송 처리 (2026-10-21 요청).

Rules from the owner:
- Always open https://my.a-bly.com/sales/order/send?...&ably_global_tab=japan and work through
  that page. Never navigate to the amood frame's own address (seller.amood.jp); the order list
  is read and clicked *inside* the frame of the my.a-bly.com page only.
- 아무드 orders are matched by 주문번호, and (2026-10-21 18:36) also by 주문상세번호 = 아무드 상품주문번호
  when the app has it from 확장주문검색. Never by name or option.
- 예상 출고일 buttons are the same as Ably (내일·모레·3일 이내·1주 이내·2주 이내·날짜로 선택하기).
- 지연 사유 is required: the fixed text below with #{상품명}/#{출고예정일} filled like the app's 알림톡.

Only the 1차 message is automated. A dialog titled 2차 (already sent once) is never used.
"""
from __future__ import annotations
import re,time
from datetime import date
from urllib.parse import urlsplit
from ably_sync import AblySyncError,AblyCancelled,push_option,app_delay_notice

AMOOD='누아브 아무드'
AMOOD_ORDERS='https://my.a-bly.com/sales/order/send?entry_point=dashboard&ably_global_tab=japan'
FRAME_HOST='seller.amood.jp'
FRAME_PATH='/sales/order-send'
PUSH_BUTTON='배송지연메시지 발송 처리'
SEND_RE=re.compile(r'^\s*배송\s*지연\s*메시지\s*발송\s*$')
TITLE_RE=re.compile(r'배송\s*지연\s*메시지\s*발송')
UNSENT=('','-','미발송','발송 필요','발송필요')
REASON_TEMPLATE=('안녕하세요 고객님\n{shop}입니다.\n\n주문하신 상품의 입고가 지연되어 안내드립니다.\n\n'
                 '상품: #{상품명}\n출고 예정일: #{출고예정일}\n\n기다리게 해드려 정말 죄송합니다.\n'
                 '입고되는 대로 꼼꼼히 검수하여 빠르게 출고하겠습니다.\n\n기다려주셔서 감사합니다.')

def order_key(value):
    return re.sub(r'\s+','',str(value or ''))

def korean_date(due):
    d=date.fromisoformat(due);return f'{d.year}년 {d.month}월 {d.day}일'

def product_lines(rows):
    return '\n'.join(f"{r.get('product','')}{' ('+r['option']+')' if r.get('option') else ''} × {r.get('qty',1)}" for r in rows)

def reason_text(shop,rows,due):
    """The owner's fixed 지연 사유 with the app's 알림톡 values (same product/date format)."""
    return REASON_TEMPLATE.replace('{shop}',shop or '').replace('#{상품명}',product_lines(rows)).replace('#{출고예정일}',korean_date(due))

def sent_orders(state):
    return {order_key(p.get('orderId')) for p in state.get('amoodPushLog',[]) if p.get('status') in ('sent','already')}

def plan_amood(state,keys,today,shop=''):
    """Group app-notified 아무드 rows by 주문번호. Pure function.

    keys=None plans every active 아무드 row. A row needs an applied app delay notice (문자/알림톡
    or 메시지 없는 안내) with a due date; the order's latest due date is used.
    """
    wanted=None if keys is None else set(keys)
    done=sent_orders(state);groups={}
    for r in state.get('rows',[]):
        if not r.get('active') or r.get('seller')!=AMOOD:continue
        if wanted is not None and r['key'] not in wanted:continue
        n=app_delay_notice(state,r['key'])
        if not n:continue
        oid=order_key(r.get('orderId'))
        g=groups.setdefault(oid,{'orderId':oid,'keys':[],'rows':[],'noticeIds':[],'dues':[],'ids':[],'missingIds':False})
        g['keys'].append(r['key']);g['rows'].append(r);g['noticeIds'].append(n['id']);g['dues'].append(n['dueDate'])
        ids=[order_key(p.get('id')) for p in (r.get('orderItems') or []) if p.get('id')] or [order_key(x) for x in (r.get('exportOrderItemIds') or []) if x]
        if ids:g['ids'].extend(ids)
        else:g['missingIds']=True
    targets=[];skipped=[]
    for oid,g in groups.items():
        due=max(g['dues']);base={'orderId':oid,'keys':g['keys'],'noticeIds':sorted(set(g['noticeIds'])),'dueDate':due,
                                 'itemIds':[] if g['missingIds'] else sorted(set(g['ids']))}
        if not re.fullmatch(r'\d{1,30}',oid):skipped.append({**base,'status':'skipped','reason':'주문번호 형식을 확인하지 못했습니다.'});continue
        if oid in done:continue   # sent once already: never again from the app
        option,reason=push_option(due,today)
        if not option:skipped.append({**base,'status':'skipped','reason':reason});continue
        targets.append({**base,'option':option,'reason':reason_text(shop,g['rows'],due)})
    targets.sort(key=lambda t:t['orderId']);return targets,skipped

def record_amood(s,results,stamp):
    log=s.setdefault('amoodPushLog',[]);by_id={n['id']:n for n in s['notices']}
    for p in results:
        log.append({k:p.get(k,'') for k in ('orderId','dueDate','option','status','reason','platformNotice')}|{'keys':list(p.get('keys',[])),'at':stamp})
        if p.get('status')=='sent':
            for nid in p.get('noticeIds',[]):
                n=by_id.get(nid)
                if n is None:continue
                n.setdefault('events',[]).append({'at':stamp,'status':n['status'],'note':f"아무드 배송지연 메시지 발송 처리 완료 (앱 자동) · 주문번호 {p['orderId']} · 예상 출고일 {p['dueDate']} ({p['option'] if p['option']!='date' else '날짜 선택'})"})
                n['updatedAt']=stamp
    del log[:-5000]
    counts={'pushed':sum(p['status']=='sent' for p in results),'pushFailed':sum(p['status']=='failed' for p in results),'pushSkipped':sum(p['status'] in ('skipped','already') for p in results)}
    if results:s['audits'].append({'at':stamp,'event':'아무드 배송지연 메시지 발송 처리',**counts})
    return counts

def amood_message(counts):
    return f"아무드 배송지연 메시지 발송 처리 {counts.get('pushed',0)}건 · 실패 {counts.get('pushFailed',0)}건 · 보류 {counts.get('pushSkipped',0)}건"

READ_JS=r'''() => {
  const norm=t=>(t||'').replace(/\s+/g,'');
  const tables=[...document.querySelectorAll('table')];
  let headers=null;
  for(const t of tables){const hs=[...t.querySelectorAll('thead th')].map(e=>norm(e.innerText));if(hs.includes('주문번호')&&hs.includes('상품주문번호')){headers=hs;break;}}
  if(!headers)return {headers:null,tables:tables.length,text:norm(document.body.innerText).slice(0,120)};
  let rows=[];
  for(const t of tables){
    const rs=[...t.querySelectorAll('tbody tr')].filter(r=>r.getAttribute('aria-hidden')!=='true'&&!/measure/.test(r.className)&&r.cells.length===headers.length);
    if(rs.length){rows=rs;break;}
  }
  const loading=[...document.querySelectorAll('.ant-spin-spinning,.el-loading-mask,.ant-table-placeholder .ant-spin')].some(e=>e.getBoundingClientRect().width&&getComputedStyle(e).display!=='none');
  const m=(document.body.innerText||'').match(/총계\s*([\d,]+)\s*건/);
  return {headers,loading,total:m?parseInt(m[1].replace(/,/g,'')):null,
    rows:rows.map(r=>({cells:[...r.cells].map(c=>(c.innerText||'').trim()),checked:!!r.querySelector('input[type="checkbox"]')?.checked}))};
}'''

CAL_JS=r"""(due)=>{
  const [Y,M,D]=due.split('-').map(Number);
  const vis=e=>{const r=e.getBoundingClientRect();const c=getComputedStyle(e);return r.width>0&&r.height>0&&c.visibility!=='hidden'&&c.display!=='none'&&c.opacity!=='0';};
  document.querySelectorAll('[data-nuavu-day],[data-nuavu-next]').forEach(e=>{e.removeAttribute('data-nuavu-day');e.removeAttribute('data-nuavu-next');});
  const MON=['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
  const wk=/(Su|Sun|일)\s*(Mo|Mon|월)\s*(Tu|Tue|화)/;
  const panels=[...document.querySelectorAll('div,table,section')].filter(e=>vis(e)&&wk.test((e.innerText||'').replace(/\n/g,' '))&&/(19|20)\d\d/.test(e.innerText||''));
  if(!panels.length)return {state:'nopanel'};
  panels.sort((a,b)=>a.querySelectorAll('*').length-b.querySelectorAll('*').length);
  const panel=panels[0];const text=(panel.innerText||'');
  const ym=text.match(/(19|20)\d\d/);const year=+ym[0];
  let month=0;const low=text.toLowerCase();
  const kor=text.match(/(\d{1,2})\s*월/);if(kor)month=+kor[1];
  if(!month){for(let i=0;i<12;i++){if(new RegExp('\\b'+MON[i]).test(low)){month=i+1;break;}}}
  if(!month){const n=text.match(/(19|20)\d\d\s*[.\-/]\s*(\d{1,2})/);if(n)month=+n[2];}
  const shown=year+'-'+String(month).padStart(2,'0');
  if(!month)return {state:'nomonth',shown:text.slice(0,40)};
  const diff=(Y-year)*12+(M-month);
  if(diff<0)return {state:'past',shown};
  if(diff>0){
    const btns=[...panel.querySelectorAll('button,span,a,div')].filter(e=>vis(e)&&e.children.length<=2);
    const nxt=btns.find(e=>/(^|[-_ ])next/i.test(e.className||'')&&!/super|year|decade/i.test(e.className||''))||btns.find(e=>/^\s*[›>]\s*$/.test(e.innerText||'')||/next month|다음\s*달/i.test(e.getAttribute('aria-label')||e.getAttribute('title')||''));
    if(!nxt)return {state:'nonext',shown};
    nxt.setAttribute('data-nuavu-next','1');return {state:'next',shown};}
  const cells=[...panel.querySelectorAll('td,button,div,span')].filter(e=>vis(e)&&/^\s*\d{1,2}\s*$/.test(e.innerText||'')&&![...e.children].some(c=>/^\s*\d{1,2}\s*$/.test(c.innerText||'')));
  const i1=cells.findIndex(e=>+e.innerText.trim()===1);
  if(i1<0)return {state:'nocells',shown};
  let i2=cells.findIndex((e,k)=>k>i1&&+e.innerText.trim()===1);if(i2<0)i2=cells.length;
  const target=cells.slice(i1,i2).find(e=>+e.innerText.trim()===D);
  if(!target)return {state:'noday',shown};
  const host=target.closest('td')||target;
  const cls=((host.className||'')+' '+(target.className||'')).toLowerCase();
  if(/disabled/.test(cls)||host.getAttribute('aria-disabled')==='true'||target.getAttribute('aria-disabled')==='true')return {state:'disabled',shown};
  target.setAttribute('data-nuavu-day','1');return {state:'cell',shown};
}"""
PICKED_JS=r"""(due)=>[...document.querySelectorAll('input')].some(i=>i.value&&i.value.replace(/[.\/\s]/g,'-').replace(/-+/g,'-').startsWith(due))"""

def spaced(*words):
    """Button names may be rendered with spaces between Korean letters (antd: '확 인')."""
    return re.compile(r'^\s*(?:'+'|'.join(r'\s*'.join(map(re.escape,w)) for w in words)+r')\s*$',re.I)

CONFIRM_JS=r"""()=>{
  const vis=e=>{const r=e.getBoundingClientRect();const c=getComputedStyle(e);return r.width>0&&r.height>0&&c.visibility!=='hidden'&&c.display!=='none';};
  const compact=t=>(t||'').replace(/\s+/g,'');
  document.querySelectorAll('[data-nuavu-ok]').forEach(e=>e.removeAttribute('data-nuavu-ok'));
  const boxes=[...document.querySelectorAll('div,section,[role="dialog"]')].filter(e=>vis(e)&&/하시겠습니까/.test(e.innerText||'')&&!/배송\s*지연\s*메시지\s*발송\s*\n/.test((e.innerText||'').slice(0,40)));
  if(!boxes.length)return {found:false};
  boxes.sort((a,b)=>a.querySelectorAll('*').length-b.querySelectorAll('*').length);
  // smallest box that still holds clickable controls
  for(const box of boxes){
    const ctrls=[...box.querySelectorAll('button,[role="button"],a,input[type="button"],input[type="submit"]')].filter(vis);
    if(!ctrls.length)continue;
    const names=ctrls.map(c=>compact(c.innerText||c.value||c.getAttribute('aria-label')));
    const OK=['확인','발송','발송하기','예','네','보내기','ok','yes','confirm'];
    let idx=names.findIndex(n=>OK.includes(n.toLowerCase()));
    if(idx<0){const rest=ctrls.map((c,i)=>i).filter(i=>!/^(취소|닫기|아니오|아니요|cancel|close|no|x|×)?$/i.test(names[i]));
      if(rest.length===1&&/primary/i.test(ctrls[rest[0]].className||''))idx=rest[0];}
    if(idx<0)return {found:true,ok:false,names,text:(box.innerText||'').slice(0,120)};
    ctrls[idx].setAttribute('data-nuavu-ok','1');return {found:true,ok:true,name:names[idx],names};
  }
  return {found:true,ok:false,names:[]};
}"""

# 2026-10-21 19:10: the old ancestor walk could reach the order table and pick a row's 송장번호 input.
# Now: only an input on the same line as the '검색어' label, to its right, outside any table, never a
# 송장/택배 field. It may be disabled until the 검색 기준 is chosen.
SEARCH_MARK_JS=r"""()=>{
  document.querySelectorAll('[data-nuavu-search],[data-nuavu-searchtype]').forEach(e=>{e.removeAttribute('data-nuavu-search');e.removeAttribute('data-nuavu-searchtype');});
  const R=e=>e.getBoundingClientRect();
  const shown=e=>{const r=R(e);const c=getComputedStyle(e);return r.width>0&&r.height>0&&c.visibility!=='hidden'&&c.display!=='none';};
  const labels=[...document.querySelectorAll('label,span,div,th,td,p')].filter(e=>shown(e)&&!e.closest('table')&&e.children.length<=2&&(e.innerText||'').replace(/\s+/g,'')==='검색어');
  for(const l of labels){
    const lr=R(l);const cy=lr.top+lr.height/2;
    const same=e=>{const r=R(e);return Math.abs((r.top+r.height/2)-cy)<28&&r.left>=lr.right-4;};
    const inputs=[...document.querySelectorAll('input')].filter(i=>shown(i)&&!i.closest('table,.ant-table,.el-table,.ant-select,.el-select,.ant-picker')
      &&(i.type==='text'||i.type==='search'||!i.type)&&i.getAttribute('role')!=='combobox'&&!/송장|택배|운송장|일|date/i.test((i.placeholder||'')+' '+(i.name||'')+' '+(i.id||''))&&R(i).width>60&&same(i));
    if(!inputs.length)continue;
    inputs.sort((a,b)=>R(a).left-R(b).left);
    const inp=inputs[0];inp.setAttribute('data-nuavu-search','1');
    const sels=[...document.querySelectorAll('.ant-select-selector,.el-select,select')].filter(e=>shown(e)&&!e.closest('table,.ant-table,.el-table')&&same(e)&&R(e).left<R(inp).left);
    sels.sort((a,b)=>R(b).left-R(a).left);
    if(sels[0])sels[0].setAttribute('data-nuavu-searchtype','1');
    return {input:true,select:!!sels[0],disabled:!!inp.disabled||!!inp.readOnly,placeholder:inp.placeholder||''};
  }
  return {input:false,select:false};
}"""
SEARCH_GUARD_JS=r"""(e)=>!e.closest('table,.ant-table,.el-table')&&!/송장|택배|운송장/.test((e.placeholder||'')+' '+(e.name||'')+' '+(e.id||''))"""

class AmoodPusher:
    """Drives the 일본(amood) tab of my.a-bly.com 발송 관리. preview=True never presses send."""
    def __init__(self,page,stop,progress):
        self.page=page;self.stop=stop;self.progress=progress;self.clicked=False;self.steps=[]
    def check(self,ignore_stop=False):
        if self.stop.is_set() and not ignore_stop:raise AblyCancelled('아무드 발송 처리를 중단했습니다.')
        if self.page.is_closed():raise AblySyncError('에이블리 창이 닫혔습니다.')
    def wait(self,predicate,message,seconds=30,ignore_stop=False):
        until=time.monotonic()+seconds
        while time.monotonic()<until:
            self.check(ignore_stop)
            try:value=predicate()
            except AblySyncError:raise
            except Exception:value=False
            if value:return value
            self.page.wait_for_timeout(200)
        raise AblySyncError(message)
    def step(self,text):
        self.steps.append(text);self.progress(text)
    def trusted(self):
        u=urlsplit(self.page.url)
        return u.scheme=='https' and u.hostname=='my.a-bly.com' and u.port in (None,443) and u.path=='/sales/order/send'
    # ---- page / frame ----
    def open(self):
        self.step('에이블리 발송 관리 › 일본(amood) 탭을 엽니다 (지정 링크).')
        self.page.goto(AMOOD_ORDERS,wait_until='domcontentloaded',timeout=30000)
        if not self.trusted():raise AblySyncError('에이블리 발송 관리 주소를 확인하지 못했습니다.')
        tab=self.page.locator('.global-tab li.el-menu-item').filter(has_text='일본(amood)')
        self.wait(lambda:tab.count()==1,'일본(amood) 탭을 찾지 못했습니다.',30)
        if 'is-active' not in (tab.get_attribute('class') or ''):
            self.step('일본(amood) 탭 클릭');tab.click(timeout=10000)
            self.wait(lambda:'is-active' in (tab.get_attribute('class') or ''),'일본(amood) 탭으로 바뀌지 않았습니다.',15)
        self.wait(lambda:self.table(),'아무드 주문 목록이 열리지 않았습니다.',45)
        self.step('아무드 주문 목록 확인')
    def frame(self):
        """The amood order frame inside this my.a-bly.com page (never opened on its own)."""
        if not self.trusted():raise AblySyncError('에이블리 발송 관리 주소가 바뀌었습니다.')
        for f in self.page.frames:
            u=urlsplit(f.url or '')
            if u.scheme=='https' and u.hostname==FRAME_HOST and u.path.startswith(FRAME_PATH):return f
        return None
    def table(self):
        f=self.frame()
        if not f:return None
        d=f.evaluate(READ_JS)
        if not d or not d.get('headers') or d.get('loading'):return None
        need=('상품주문번호','주문번호','배송지연메시지발송여부')
        if any(n not in d['headers'] for n in need):
            raise AblySyncError('아무드 목록의 열 이름이 예상과 다릅니다: '+', '.join(h for h in d['headers'] if h)[:200])
        return d
    def col(self,d,name):return d['headers'].index(name)
    def rows_of(self,d,order_id):
        i=self.col(d,'주문번호');j=self.col(d,'상품주문번호');k=self.col(d,'배송지연메시지발송여부')
        p=self.col(d,'상품명') if '상품명' in d['headers'] else None
        out=[]
        for r in d['rows']:
            c=r['cells']
            if order_key(c[i])!=order_id:continue
            out.append({'itemId':order_key(c[j]),'notice':c[k].strip(),'checked':r['checked'],'product':(c[p].splitlines()[0].strip() if p is not None and c[p] else '')})
        return out
    def search(self,order_id):
        """Narrow the list with the page's 검색어 box (검색 기준 → 주문번호). Any trouble → False (page scan).

        2026-10-21: the box was not fillable ('Locator.fill: Timeout 30000ms') — every step now has a
        short timeout and a failure only switches to scanning the list pages, never stops the order."""
        f=self.frame()
        try:
            marked=f.evaluate(SEARCH_MARK_JS)
        except Exception:marked={'input':False}
        if not marked.get('input'):
            if order_id:self.step('검색어 칸을 찾지 못해 목록 페이지를 넘기며 주문번호를 찾습니다.')
            return False
        try:
            if order_id and marked.get('select'):
                kind=f.locator('[data-nuavu-searchtype="1"]').first
                if not self.choose_search_type(kind):
                    raise AblySyncError('검색 기준을 주문번호로 바꾸지 못했습니다 (다른 기준으로는 입력하지 않음).')
            box=f.locator('[data-nuavu-search="1"]')
            if order_id and marked.get('select') and re.sub(r'\s+','',f.locator('[data-nuavu-searchtype="1"]').first.inner_text(timeout=3000) or '')!='주문번호':
                raise AblySyncError('검색 기준이 주문번호가 아닙니다.')
            if box.count()!=1 or not box.evaluate(SEARCH_GUARD_JS):raise AblySyncError('검색어 칸이 아닌 곳(표·송장번호)이라 입력하지 않았습니다.')
            self.wait(lambda:box.is_enabled() and box.is_editable(),'검색어 칸이 입력 가능 상태가 되지 않았습니다.',4)
            box.fill(order_id,timeout=5000)
            if box.input_value(timeout=3000)!=order_id:raise AblySyncError('검색어 입력값이 다릅니다.')
            btn=f.get_by_role('button',name=spaced('검색'))
            if btn.count()>=1:btn.first.click(timeout=5000)
            else:box.press('Enter',timeout=3000)
        except AblyCancelled:raise
        except Exception as exc:
            try:self.page.keyboard.press('Escape')
            except Exception:pass
            if order_id:self.step(f'검색칸 입력 실패({type(exc).__name__}) → 목록 페이지를 넘기며 주문번호를 찾습니다.')
            return False
        if not order_id:
            try:self.wait(lambda:self.table(),'목록을 다시 읽지 못했습니다.',20)
            except AblySyncError:pass
            return False
        def narrowed():
            d=self.table()
            if not d:return False
            i=self.col(d,'주문번호')
            return d if d['rows'] and all(order_key(r['cells'][i])==order_id for r in d['rows']) else ('empty' if not d['rows'] else False)
        try:return self.wait(narrowed,'검색 결과가 갱신되지 않았습니다.',20)
        except AblySyncError:return False
    def choose_search_type(self,kind):
        """검색 기준 → exactly '주문번호' (not 상품주문번호·송장번호). The dropdown is given time to finish
        opening/scrolling before the click, and the shown value is re-read; up to 3 tries."""
        f=self.frame()
        shown=lambda:re.sub(r'\s+','',kind.inner_text(timeout=3000) or '')
        for attempt in range(3):
            if shown()=='주문번호':return True
            if kind.evaluate('e=>e.tagName')=='SELECT':
                kind.select_option(label='주문번호',timeout=3000);continue
            kind.click(timeout=3000)
            opt=f.locator(':is(.ant-select-item-option,.el-select-dropdown__item):visible').filter(has_text=re.compile(r'^\s*주문번호\s*$'))
            try:self.wait(lambda:opt.count()>=1,'',4)
            except AblySyncError:
                self.page.keyboard.press('Escape');continue
            self.page.wait_for_timeout(600)          # dropdown open animation / list scroll settles
            try:opt.first.scroll_into_view_if_needed(timeout=2000)
            except Exception:pass
            self.page.wait_for_timeout(300)
            if re.sub(r'\s+','',opt.first.inner_text() or '')!='주문번호':
                self.page.keyboard.press('Escape');continue
            opt.first.click(timeout=3000)
            self.page.wait_for_timeout(400)
        ok=shown()=='주문번호'
        if not ok:
            try:self.page.keyboard.press('Escape')
            except Exception:pass
        else:self.step('검색 기준: 주문번호 확인')
        return ok
    def page_signature(self):
        d=self.table()
        return [tuple(r['cells'][1:4]) for r in d['rows']] if d else None
    def goto_page(self,which):
        """which='first'|'next' on the antd/element pager; False when there is no such page."""
        f=self.frame()
        if which=='first':
            item=f.locator(':is(li.ant-pagination-item-1,.el-pager li.number):visible').first
            if not item.count() or 'active' in (item.get_attribute('class') or ''):return False
        else:
            item=f.locator(':is(li.ant-pagination-next,button.btn-next):visible').first
            if not item.count():return False
            if 'disabled' in (item.get_attribute('class') or '') or item.get_attribute('aria-disabled')=='true' or item.get_attribute('disabled') is not None:return False
        before=self.page_signature()
        item.click(timeout=5000)
        try:self.wait(lambda:(sig:=self.page_signature()) is not None and sig!=before,'다음 목록 페이지로 넘어가지 않았습니다.',15)
        except AblySyncError:return False
        return True
    def find_rows(self,order_id):
        """Rows of this 주문번호: search first, otherwise scan every list page from page 1."""
        found=self.search(order_id)
        if found=='empty':
            self.step('검색 결과 없음 → 검색어를 비우고 목록 페이지를 넘기며 다시 찾습니다.');self.search('')
        d=self.wait(lambda:self.table(),'아무드 목록을 읽지 못했습니다.',20)
        rows=self.rows_of(d,order_id)
        if rows or found not in (False,'empty'):return rows
        self.goto_page('first')
        for _ in range(60):
            d=self.wait(lambda:self.table(),'아무드 목록을 읽지 못했습니다.',20)
            rows=self.rows_of(d,order_id)
            if rows:return rows
            if not self.goto_page('next'):return []
        return []
    def clear_checks(self):
        f=self.frame()
        if not f:return
        for _ in range(3):
            d=self.table()
            if not d or not any(r['checked'] for r in d['rows']):return
            i=self.col(d,'주문번호')
            for r in d['rows']:
                if r['checked']:self.toggle(r['cells'][i],r['cells'][self.col(d,'상품주문번호')],False)
    def row_locator(self,d,order_id,item_id):
        f=self.frame();i=self.col(d,'주문번호')+1;j=self.col(d,'상품주문번호')+1
        exact=lambda t:re.compile(r'^\s*'+re.escape(t)+r'\s*$')
        return f.locator('tbody tr').filter(has=f.locator(f'td:nth-child({i})').filter(has_text=exact(order_id))).filter(has=f.locator(f'td:nth-child({j})').filter(has_text=exact(item_id)))
    def is_checked(self,order_id,item_id):
        d=self.table()
        return any(r['itemId']==item_id and r['checked'] for r in self.rows_of(d,order_id)) if d else False
    def toggle(self,order_id,item_id,on):
        order_id=order_key(order_id);item_id=order_key(item_id)
        if self.is_checked(order_id,item_id)==on:return
        d=self.table();row=self.row_locator(d,order_id,item_id)
        if row.count()!=1:raise AblySyncError(f'주문번호 {order_id} 행을 하나로 찾지 못했습니다 ({row.count()}개).')
        box=row.locator('input[type="checkbox"]').first
        if not box.count():raise AblySyncError(f'주문번호 {order_id} 행의 선택 칸을 찾지 못했습니다.')
        wrapper=row.locator('label:has(input[type="checkbox"])').first
        try:(wrapper if wrapper.count() else box).click(timeout=5000)
        except Exception:box.dispatch_event('click')
        try:self.wait(lambda:self.is_checked(order_id,item_id)==on,'선택 칸이 바뀌지 않았습니다.',8)
        except AblySyncError:
            box.dispatch_event('click');self.wait(lambda:self.is_checked(order_id,item_id)==on,f'주문번호 {order_id} 선택 칸을 바꾸지 못했습니다.',8)
    # ---- dialog ----
    def dialog(self):
        f=self.frame()
        loc=f.locator(':is([role="dialog"],.ant-modal-content,.el-dialog,.modal-content):visible').filter(has_text=TITLE_RE)
        return loc.last if loc.count() else None
    def dialog_title(self,dlg):
        text=(dlg.inner_text() or '').strip().splitlines()
        return next((t.strip() for t in text if TITLE_RE.search(t)),'')
    def choose(self,dlg,option,due):
        f=self.frame()
        if option=='date':
            self.step(f'예상 출고일: 날짜로 선택하기 → {due}')
            dlg.get_by_text('날짜로 선택하기',exact=True).first.click(timeout=10000)
            self.pick_date(due)
            return
        self.step(f'예상 출고일 버튼 "{option}" 선택')
        btn=dlg.get_by_role('button',name=option,exact=True)
        if btn.count()!=1:btn=dlg.get_by_text(option,exact=True)
        if btn.count()<1:raise AblySyncError(f'예상 출고일 버튼 "{option}"을(를) 찾지 못했습니다.')
        before=btn.first.get_attribute('class') or ''
        btn.first.click(timeout=10000)
        try:self.wait(lambda:(btn.first.get_attribute('class') or '')!=before or btn.first.get_attribute('aria-pressed')=='true' or btn.first.get_attribute('aria-checked')=='true','',4)
        except AblySyncError:self.step(f'"{option}" 버튼 표시 변화는 확인하지 못했습니다 (발송 버튼 활성으로 확인).')
    def pick_date(self,due):
        """Calendar popup (header 'Oct  2026', ‹ › arrows, grey days of other months): move to the month,
        click the day inside that month. Disabled days (25영업일 초과 등) are never clicked."""
        f=self.frame()
        for _ in range(4):
            r=self.wait(lambda:(v if (v:=f.evaluate(CAL_JS,due)).get('state')!='nopanel' else False),'날짜 달력이 열리지 않았습니다.',8)
            if r['state']=='cell':
                cell=f.locator('[data-nuavu-day="1"]')
                cell.click(timeout=5000)
                self.step(f"달력 {r['shown']} › {due[-2:].lstrip('0')}일 클릭")
                try:self.wait(lambda:f.evaluate(PICKED_JS,due),'',4)
                except AblySyncError:self.step('달력 선택값 표시는 확인하지 못했습니다 (발송 버튼 활성으로 확인).')
                return
            if r['state']=='next':
                self.step(f"달력 {r['shown']} → 다음 달");f.locator('[data-nuavu-next="1"]').click(timeout=5000);self.page.wait_for_timeout(300);continue
            if r['state']=='disabled':raise AblySyncError(f'달력에서 {due}은(는) 선택할 수 없는 날짜입니다 (최대 25영업일 등 제한).')
            raise AblySyncError(f"달력에서 {due}을(를) 찾지 못했습니다 ({r.get('state')} · {r.get('shown','')}).")
        raise AblySyncError(f'달력에서 {due}이(가) 있는 달로 넘어가지 못했습니다.')
    def fill_reason(self,dlg,text):
        area=dlg.locator('textarea')
        if area.count()!=1:raise AblySyncError(f'지연 사유 입력칸을 하나로 찾지 못했습니다 ({area.count()}개).')
        area.fill('');area.fill(text)
        if area.input_value()!=text:raise AblySyncError('지연 사유 입력값이 일치하지 않습니다.')
        self.step('지연 사유 입력 확인')
    def send_button(self,dlg):
        b=dlg.get_by_role('button',name=SEND_RE)
        return b.last if b.count() else None
    def close_dialog(self):
        dlg=self.dialog()
        if not dlg:return
        close=dlg.get_by_role('button',name=spaced('닫기'))
        try:
            if close.count():close.first.click(timeout=5000)
            else:self.page.keyboard.press('Escape')
            self.wait(lambda:self.dialog() is None,'발송 창이 닫히지 않았습니다.',10)
        except AblySyncError:pass
    def dismiss_info(self):
        """A plain notice box left after sending (확인 only); never a send control."""
        f=self.frame()
        try:
            for _ in range(3):
                box=f.locator(':is([role="dialog"],.ant-modal-content,.ant-modal-confirm,.el-message-box,.modal-content):visible').filter(has_not_text=TITLE_RE)
                if not box.count():return
                text=(box.last.inner_text() or '').strip()[:160]
                ok=box.last.get_by_role('button',name=spaced('확인','OK'))
                if not ok.count():return
                self.step('안내 창: '+text.replace('\n',' ')[:80]+' → 확인');ok.last.click(timeout=5000);self.page.wait_for_timeout(500)
        except Exception:pass
    def toast(self):
        f=self.frame()
        try:
            texts=[t.strip() for t in f.locator(':is(.ant-message,.ant-notification,.el-message,[role="alert"]):visible').all_inner_texts() if t.strip()]
            return ' / '.join(texts)[:200]
        except Exception:return ''
    def run_order(self,t,preview=False):
        """One 주문번호 → one dialog. Returns a result dict; never presses send twice."""
        oid=t['orderId'];self.clicked=False
        self.step(f'주문번호 {oid} 찾기 (주문번호 + 주문상세번호 대조)')
        rows=self.find_rows(oid)
        if not rows:return {**t,'status':'skipped','reason':'아무드 목록(모든 페이지)에서 주문번호를 찾지 못했습니다.','platformNotice':''}
        want=set(t.get('itemIds') or [])
        if want:
            have={r['itemId'] for r in rows}
            if not want<=have:
                return {**t,'status':'skipped','reason':f"주문상세번호 불일치 · 앱(확장주문검색) {', '.join(sorted(want))} / 아무드 상품주문번호 {', '.join(sorted(have))}",'platformNotice':''}
            rows=[r for r in rows if r['itemId'] in want]
            self.step(f'주문상세번호 일치 {len(rows)}건 ('+', '.join(sorted(want))+')')
        else:self.step('앱에 주문상세번호가 없어 주문번호로만 매칭합니다 (최신 확장주문검색을 불러오면 같이 대조).')
        unsent=[r for r in rows if r['notice'] in UNSENT]
        if not unsent:return {**t,'status':'already','reason':'이미 배송지연 메시지 발송됨: '+', '.join(sorted({r['notice'] for r in rows})),'platformNotice':', '.join(sorted({r['notice'] for r in rows}))}
        if len(unsent)!=len(rows):return {**t,'status':'skipped','reason':'같은 주문번호 안에 이미 발송된 상품이 섞여 있습니다. 직접 확인하세요.','platformNotice':''}
        self.clear_checks()
        for r in rows:self.toggle(oid,r['itemId'],True)
        d=self.table();checked=[r for r in d['rows'] if r['checked']]
        if len(checked)!=len(rows) or any(order_key(r['cells'][self.col(d,'주문번호')])!=oid or order_key(r['cells'][self.col(d,'상품주문번호')]) not in {x['itemId'] for x in rows} for r in checked):raise AblySyncError('선택한 행이 주문번호·주문상세번호와 다릅니다.')
        self.step(f'주문번호 {oid} · {len(rows)}개 상품 선택 → 배송지연메시지 발송 처리 버튼')
        f=self.frame();push=f.get_by_role('button',name=re.compile(r'배송지연메시지\s*발송\s*처리'))
        if push.count()<1:raise AblySyncError('배송지연메시지 발송 처리 버튼을 찾지 못했습니다.')
        push.first.click(timeout=10000)
        dlg=self.wait(lambda:self.dialog(),'배송 지연 메시지 발송 창이 열리지 않았습니다.',15)
        title=self.dialog_title(dlg);self.step('발송 창: '+title)
        if '2차' in title:
            self.close_dialog();self.clear_checks()
            return {**t,'status':'already','reason':'2차 발송 창이 열렸습니다(1차 발송 이력 있음). 자동 발송하지 않았습니다.','platformNotice':'1차 발송됨'}
        self.choose(dlg,t['option'],t['dueDate'])
        self.fill_reason(dlg,t['reason'])
        send=self.send_button(dlg)
        if not send or not send.is_enabled():raise AblySyncError('배송 지연 메시지 발송 버튼이 활성화되지 않았습니다 (예상 출고일 선택 확인).')
        if preview:
            self.step('미리보기: 발송 버튼 활성 확인까지 완료 → 발송하지 않고 닫습니다.')
            self.close_dialog();self.clear_checks()
            return {**t,'status':'preview','reason':'발송하지 않음 (미리보기)','platformNotice':''}
        if not self.trusted():raise AblySyncError('발송 직전 에이블리 주소를 확인하지 못했습니다.')
        self.step(f'주문번호 {oid} → 배송 지연 메시지 발송 클릭')
        self.clicked=True
        try:send.click(timeout=10000)
        except Exception:send.dispatch_event('click')
        def settled():
            if self.dialog() is None:return 'closed'
            box=f.locator(':is([role="dialog"],.ant-modal-content,.ant-modal-confirm,.el-message-box,.modal-content):visible').filter(has_not_text=TITLE_RE)
            if box.count():return 'confirm'
            return False
        outcome=self.wait(settled,'발송 결과 화면을 확인하지 못했습니다.',40,ignore_stop=True)
        if outcome=='confirm':
            box=f.locator(':is([role="dialog"],.ant-modal-content,.ant-modal-confirm,.el-message-box,.modal-content):visible').filter(has_not_text=TITLE_RE).last
            text=(box.inner_text() or '').strip()[:160]
            ok=box.get_by_role('button',name=spaced('확인','발송','발송하기','예','네','보내기','OK'))
            if ok.count()>=1:target=ok.last;label=(target.inner_text() or '').strip()
            else:
                r=f.evaluate(CONFIRM_JS)
                if not r.get('ok'):raise AblySyncError('확인 창의 확인 버튼을 찾지 못했습니다 (버튼: '+', '.join(r.get('names') or [])+'): '+text)
                target=f.locator('[data-nuavu-ok="1"]');label=r.get('name','')
            self.step('확인 창: '+text.replace('\n',' ')[:60]+f' → {label} 클릭');target.click(timeout=10000)
            self.wait(lambda:self.dialog() is None or not box.is_visible(),'확인 후 창이 닫히지 않았습니다.',30,ignore_stop=True)
            if self.dialog() is not None:self.close_dialog()
        toast=self.toast()
        if toast:self.step('에이블리 안내: '+toast)
        self.dismiss_info()
        picked={r['itemId'] for r in rows}
        def shown():
            d=self.table()
            if not d:return False
            now=[r for r in self.rows_of(d,oid) if r['itemId'] in picked]
            return now if len(now)==len(picked) and all(r['notice'] not in UNSENT for r in now) else False
        try:after=self.wait(shown,'목록 갱신 대기',25,ignore_stop=True)
        except AblySyncError:
            try:self.find_rows(oid);after=self.wait(shown,'목록 갱신 대기',20,ignore_stop=True)
            except AblyCancelled:raise
            except Exception:after=None
        self.clear_checks()
        if not after:return {**t,'status':'failed','reason':'아무드 목록에서 발송 표시를 확인하지 못했습니다. 직접 확인하세요. '+toast,'platformNotice':''}
        return {**t,'status':'sent','reason':'','platformNotice':', '.join(sorted({r['notice'] for r in after}))}
    def verify_sent(self,t):
        """After a send click went wrong: read the list again (all pages). Returns the shown notice or ''."""
        try:
            for _ in range(3):
                try:self.page.keyboard.press('Escape')
                except Exception:pass
                self.dismiss_info()
            self.page.wait_for_timeout(1500)
            rows=self.find_rows(t['orderId'])
            want=set(t.get('itemIds') or [])
            if want:rows=[r for r in rows if r['itemId'] in want]
            if rows and all(r['notice'] not in UNSENT for r in rows):
                self.step(f"주문번호 {t['orderId']} 목록 재확인: 발송 표시 있음")
                return ', '.join(sorted({r['notice'] for r in rows}))
        except AblyCancelled:raise
        except Exception:pass
        return ''
    def run(self,targets,preview=False):
        results=[]
        self.open()
        for t in targets:
            self.check()
            try:results.append(self.run_order(t,preview))
            except AblyCancelled:
                if self.clicked:results.append({**t,'status':'failed','reason':'발송 클릭 후 중단 · 직접 확인하세요.','platformNotice':''})
                raise
            except Exception as exc:
                msg=str(exc) if isinstance(exc,AblySyncError) else f'{type(exc).__name__}: {str(exc).splitlines()[0][:160] if str(exc) else ""}'
                last=self.steps[-1] if self.steps else ''
                if self.clicked:
                    done=self.verify_sent(t)
                    if done:
                        results.append({**t,'status':'sent','reason':'','platformNotice':done,'note':f'발송 후 화면 정리 중 오류({msg})가 있었지만 목록에서 발송 표시 확인'})
                        try:self.close_dialog();self.clear_checks()
                        except Exception:pass
                        continue
                    results.append({**t,'status':'failed','reason':f'{msg} (발송 클릭 후 · 마지막 단계: {last})','platformNotice':''})
                    rest=[x for x in targets if x['orderId'] not in {r['orderId'] for r in results}]
                    results.extend({**x,'status':'skipped','reason':'앞선 발송 확인 실패로 중단','platformNotice':''} for x in rest)
                    return results
                try:self.close_dialog();self.clear_checks()
                except Exception:pass
                results.append({**t,'status':'skipped','reason':f'{msg} (마지막 단계: {last})','platformNotice':''})
        return results

def run(account,stop,progress,targets,preview=False):
    """Login with the Ably account (same market), then work only on the japan tab of 발송 관리."""
    from playwright.sync_api import sync_playwright
    from ably_browser import Reader
    with sync_playwright() as pw:
        import browser_window;browser=pw.chromium.launch(**browser_window.launch_kwargs())
        context=browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1,accept_downloads=False)
        browser_window.attach(context)
        context.on('page',lambda page:page.on('dialog',lambda dialog:dialog.dismiss()))
        page=context.new_page()
        try:
            Reader(page,stop,progress).login(account)
            pusher=AmoodPusher(page,stop,progress)
            results=pusher.run(targets,preview)
            return {'results':results,'steps':pusher.steps[-40:]}
        finally:context.close();browser.close()
