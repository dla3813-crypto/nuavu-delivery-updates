# After-sales verification — 0.6.44

- Python: 960 passed (92 subtests).
- JavaScript: 125 passed.
- Installed temporary bundle UI: 82 checks passed; desktop and compact screenshots inspected. Synthetic customers, fake native bridge; no external sender POST.
- Installed Chrome + synthetic routed HTTPS: 43 assertions covering inspection, success, duplicate, wrong customer, lookup failure, wrong recipient, wrong defaults, wrong carrier, uncertain result, confirm handling, one-click claim, new tabs; exchange two statuses + pagination + detail invoice.
- New pure/controller cases: 15. Default-off, section eligibility, conflicting recipients, scope changes, persisted pre-click claims, restart duplicate prevention, explicit manual attempts, partial failure, atomic snapshots, report text types and non-overwriting save.
- Nuavu scheduled import waits for other web work before claiming the slot; uses same lock as native operations. Added two regression cases.
- Prior release manifest: all original hashes intact. Store and all Engine methods except constructor/public_state retain prior AST. Provider/sender, inventory/FIFO/supply, credentials, order export and external notices preserved. Existing browser login source identical apart from distribution installer version text.
- Read-only actual local file: 89 product rows / 84 return requests; title and legend excluded. No customer file copied into this package.
- Actual-site read-only DOM observation: EX00 search/recipient/defaults/result columns and Ably exchange filters/detail. Never clicked actual return submission, delete, refund or exchange approval.
- UI initial verification caught personal return bar entering order-card handler; narrowed order handlers to data-color cards and rechecked. Static-file allowlist omissions fixed. Test harness row symbol/selector mistakes fixed. Full regression and affected tests re-run.
- No operating installation, real Keychain access, real authentication attempt by new driver, actual pickup submission, customer message, refund, or live automatic settings activation. End-to-end production pickup remains unverified.

See `AFTERSALES_UPDATE.md` for usage and the deliberate no-reclick behavior after an uncertain submission.
