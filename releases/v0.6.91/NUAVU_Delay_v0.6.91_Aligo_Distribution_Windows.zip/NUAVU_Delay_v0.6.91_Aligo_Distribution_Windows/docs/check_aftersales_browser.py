"""Installed Chrome, synthetic HTTPS pages intercepted entirely in memory. No real submissions."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from playwright.sync_api import sync_playwright
from pickup_browser import PickupFlow,EX00,INDEX
from exchange_browser import ExchangeFlow,FIELDS
from order_auto import OrderAutoError
checks=[]
def check(name,ok):assert ok,name;checks.append(name)
class C:
 def __init__(self):self.pending=None;self.results=[];self.claims=[]
 def check(self):pass
 def update(self,*args):pass
 def before_submit(self,n):self.pending={'invoice':n};self.claims.append(n)
 def record(self,r,inspect=False):self.results.append(r);self.pending=None
 def ask_login_confirmation(self,text):return True
class FastPickup(PickupFlow):
 def pause(self,n):super().pause(min(n,.04))
 def until(self,p,t,m):return super().until(p,min(t,.6),m)
class FastExchange(ExchangeFlow):
 def pause(self,n):super().pause(min(n,.06))
 def until(self,p,t,m):return super().until(p,min(t,2),m)
 def lookup(self,numbers):return {n:dict(carrier='EPOST',return_status='NONE') for n in numbers}
def pickup_html(case):
 fields=['sender_name','sender_tel1','sender_tel2','sender_mobile1','sender_mobile2','sender_address','receiver_name','receiver_address','keyword2']
 html='<meta charset="utf-8">'+''.join(f'<input id="{k}">' for k in fields)
 html+='''<select id="receiver_list"><option value="wrong">다른상점</option><option value="right">테스트상점</option></select><input type="radio" name="takeback_ret_type" value="04" checked><input type="radio" name="takeback_trans_who" value="04" checked><table id="grid1"><tbody></tbody></table><table id="grid2"><tbody></tbody></table><table><td id="takeback_org_trans_no"></td><td id="takeback_reg_date"></td></table><span id="takeback_submit">반품접수</span><span id="takeback_modify" hidden>반품수정</span><span id="takeback_del" hidden>반품삭제</span>'''
 html+='<script>const CASE='+json.dumps(case)+';'+'''
 window.clicks=0;
 keyword2.onkeydown=e=>{if(e.key!=='Enter')return;if(CASE==='lookup')return;sender_name.value='가상';sender_mobile1.value='010';sender_mobile2.value='00001234';sender_address.value='가상 주소';grid1.querySelector('tbody').innerHTML='<tr class="jqgrow"><td>가상 주문</td></tr>';if(CASE==='duplicate'){takeback_modify.hidden=false;takeback_del.hidden=false;}if(CASE==='defaults')document.querySelector('[name=takeback_trans_who]').checked=false;};
 receiver_list.onchange=()=>{receiver_name.value=CASE==='receiver'?'다른상점':'테스트상점';receiver_address.value='가상 회사 주소';};
 takeback_submit.onclick=()=>{window.clicks++;window.recordClick();if(CASE==='confirm'&&!confirm('회수 접수를 진행할까요?'))return;if(CASE==='uncertain')return;const carrier=CASE==='carrier'?'대한통운':'우체국택배';grid2.querySelector('tbody').innerHTML='<tr class="jqgrow"><td aria-describedby="grid2_str_reg_trans_corp">준비중</td><td aria-describedby="grid2_trans_name">'+carrier+'</td><td aria-describedby="grid2_recv_name">테스트상점</td><td aria-describedby="grid2_reg_date">2026-10-18 10:00:00</td></tr>';takeback_org_trans_no.textContent=keyword2.value;takeback_reg_date.textContent='2026-10-18';takeback_modify.hidden=false;takeback_del.hidden=false;takeback_submit.hidden=true;};
 </script>'''
 return html
with sync_playwright() as pw:
 browser=pw.chromium.launch(channel='chrome',headless=True,chromium_sandbox=True)
 try:
  for case,expected in [('success','접수 완료'),('duplicate','이미 접수됨'),('lookup','조회 실패'),('customer','고객정보 불일치'),('receiver','수신자 변경 실패'),('defaults','접수 실패'),('carrier','택배사 잘못 접수'),('uncertain','접수 실패'),('confirm','접수 완료'),('inspect','접수 전 확인')]:
   context=browser.new_context();requested=[];pages=[];clicks=[]
   context.expose_function('recordClick',lambda:clicks.append(True))
   context.on('page',lambda page:pages.append(page))
   def route(rt):
    requested.append(rt.request.url)
    if rt.request.url==INDEX:body='<meta charset="utf-8"><a href="logout.php">로그아웃</a><p>danimstudio</p>'
    elif rt.request.url==EX00:body=pickup_html(case)
    else:raise AssertionError('Unexpected network '+rt.request.url)
    rt.fulfill(content_type='text/html',body=body)
   context.route('**/*',route);c=C();flow=FastPickup(c,context)
   # Keep synthetic pages long enough to inspect click counts, then context closes all.
   original_one=flow.one
   def one(*args,**kw):
    context.on('page',lambda p:p.on('close',lambda:None))
    return original_one(*args,**kw)
   row={'invoice':'610000000001','customer':'다름' if case=='customer' else '가상','phone':'01000001234'}
   try:flow.run({},[row],'테스트상점',case=='inspect')
   except OrderAutoError:
    check(case+' stops whole batch',case=='carrier')
   check(case+' result',len(c.results)==1 and c.results[0]['result']==expected)
   check(case+' durable click claim',len(c.claims)==(1 if case in ('success','carrier','uncertain','confirm') else 0))
   check(case+' exactly one click or none',len(clicks)==len(c.claims))
   check(case+' fresh EX00 tab',len(pages)==2 and requested.count(EX00)==1)
   context.close()
  context=browser.new_context();c=C();flow=FastExchange(c,context,'테스트상점');flow.page=context.new_page()
  headers=list(FIELDS.values());keys=list(FIELDS);head=''.join('<th>'+s+'</th>' for s in headers)
  iframe='''<meta charset="utf-8"><span class="ant-typography FilterCard-label" id="request">교환요청</span><span class="ant-typography FilterCard-label" id="collect">교환수거중</span><div class="ant-select ant-select-single"><div class="ant-select-selector"><span class="ant-select-selection-wrap"><span class="ant-select-selection-search"><input id="status" readonly style="opacity:0"></span><span class="ant-select-selection-item" id="selected">교환요청</span></span></div></div><button id="search">검색</button><table><thead><tr>'''+head+'''</tr></thead><tbody></tbody></table><span class="ant-pagination-total-text"></span><span class="ant-pagination-item-active">1</span><span class="ant-pagination-next"><button id="next">다음</button></span><div id="modal"></div><script>const fields='''+json.dumps(keys)+''';let kind='교환요청',page=1;function render(){selected.textContent=kind;document.querySelector('.ant-pagination-total-text').textContent='총 '+(kind==='교환요청'?2:1)+'개';document.querySelector('.ant-pagination-item-active').textContent=page;document.querySelector('.ant-pagination-next').setAttribute('aria-disabled',String(kind!=='교환요청'||page===2));const item=kind==='교환요청'?'100'+page:'2001';const r={requestId:'R'+item,requestedAt:'2026-10-18 10:00:00',exchangeStatus:kind,itemId:item,orderId:'TEST-'+item,product:'가상 상품',option:'블랙',exchangeOption:'화이트',qty:'1',reason:'색상',fee:'0원',returnNo:'-',customer:'가상',recipientPhone:'01000001234'};document.querySelector('tbody').innerHTML='<tr class="ant-table-row">'+fields.map(k=>'<td>'+(k==='itemId'?'<a id="detail">'+r[k]+'</a>':r[k])+'</td>').join('')+'</tr>';detail.onclick=()=>{modal.innerHTML='<div role="dialog">상품주문정보 조회 ['+item+']<div>배송정보</div><div>송장번호</div><div>61000000'+item+'</div><div>배송지정보</div><button class="mantine-Modal-close">닫기</button></div>';modal.querySelector('button').onclick=()=>modal.innerHTML='';};}request.onclick=()=>{kind=kind==='교환요청'?'전체':'교환요청';page=1;render();};collect.onclick=()=>{kind=kind==='교환수거중'?'전체':'교환수거중';page=1;render();};search.onclick=render;next.onclick=()=>{page++;render();};render();</script>'''
  def route(rt):
   if rt.request.url.startswith('https://my.a-bly.com/sales/order/exchange/progress'):
    body='<meta charset="utf-8"><h1 class="profile__market-name">테스트상점</h1><iframe src="https://seller-admin.a-bly.com/sales/order/exchange"></iframe>'
   elif rt.request.url=='https://seller-admin.a-bly.com/sales/order/exchange':body=iframe
   else:raise AssertionError('Unexpected exchange network '+rt.request.url)
   rt.fulfill(content_type='text/html',body=body)
  context.route('**/*',route)
  import datetime
  result=flow.collect_exchange(datetime.date(2026,10,18))
  check('exchange all pages both statuses',result['total']==3 and [r['exchangeStatus'] for r in result['rows']]==['교환요청','교환요청','교환수거중'])
  check('exchange original invoice from matching detail',all(r['invoice'].startswith('61000000') for r in result['rows']))
  context.close()
 finally:browser.close()
print(json.dumps({'checks':len(checks),'result':'PASS'},ensure_ascii=False))
