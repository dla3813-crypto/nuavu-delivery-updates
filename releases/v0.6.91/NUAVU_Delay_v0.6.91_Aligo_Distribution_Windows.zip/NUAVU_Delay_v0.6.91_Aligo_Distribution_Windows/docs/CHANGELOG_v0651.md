# NUAVU_Delay_v0.6.51_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v0650.md

## Windows 배포판 (배포판, 10-20 08:42 요청) — 같은 코드, 같은 기능
- 배포판 코드를 macOS·Windows 공용으로 바꾸고 **`NUAVU_Delay_v0.6.51_Aligo_Distribution_Windows.zip`** 을 따로 만듭니다(Mac ZIP과 기능 동일 · Mac 전용 .command/.icns만 뺌).
- **설치**: python.org Python 3.11~3.15(64비트, "Add python.exe to PATH") + Google Chrome 설치 → `처음한번_앱설치.bat` 더블클릭 → `%LOCALAPPDATA%\NUAVU Delay Distribution\desktop-runtime-win` 가상환경에 pywebview 6.2.1 · playwright 1.64.0 · certifi 설치 → 바탕화면 `배송안내 배포판` 바로가기(pythonw.exe desktop.py, 아이콘 assets/CS-Pink.ico) → 앱 실행. Windows 10은 WebView2 런타임이 없으면 안내(설치 사이트는 열지 않음). `배송안내_실행.bat`, `문제확인용_웹실행.bat`, `먼저읽기_윈도우.txt` 포함. .bat은 ASCII만, 실제 작업은 UTF-8(BOM) PowerShell(windows/*.ps1).
- **계정 저장**: 맥 키체인 대신 **Windows DPAPI(사용자 보호 저장소)** — 알리고·이지어드민·에이블리·지그재그·자사몰 계정을 사용자별 암호화 파일(`…\vault\*.dpapi`)로 저장(같은 Windows 계정에서만 복호화, 평문 저장 없음). 전체 초기화도 같은 저장소를 지웁니다. (windows_credentials.py · `platform_vault`가 OS별로 고름)
- **경로·잠금·창**: 데이터 `%LOCALAPPDATA%\NUAVU Delay Distribution`(백업은 바탕화면\배송안내_배포판_백업, 로그 `…\logs\desktop.log`), 중복 실행 잠금은 msvcrt, 오류 창은 MessageBox, 저장 파일 열기/위치 보기는 탐색기(platform_support.py). 앱 창은 pywebview의 WebView2.
- 검증: Linux에서 가짜 DPAPI로 저장/읽기/삭제·잠금·플랫폼 선택·스크립트 존재/인코딩 테스트 통과(tests/test_windows_support.py), 배포판 전체 1193건 통과. **실제 Windows PC에서는 아직 실행해 보지 못했습니다** — 첫 실행 시 `처음한번_앱설치.bat` 창의 메시지와 `logs\desktop.log`를 보내주시면 맞추겠습니다.
