"""Installed-bundle HTTP UI with synthetic return data and a fake native bridge."""
from pathlib import Path
import copy,importlib.util,json,sys,tempfile,threading,types,datetime as dt
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from install_desktop import build_bundle
from playwright.sync_api import sync_playwright
try:
 from helpers import FakeSMS,FakeAT,MemoryVault
 DIST=True
except ImportError:
 from test_v056 import Base
 DIST=False
from domain import Engine,Store
from test_aftersales_new import row as new_row,TODAY,NOW
from return_data import clean_tracking
from aftersales_data import public_aftersales,shop
if DIST:from test_supply_regression import order
else:from test_v068 import order

def entry():return new_row('510000000001')
def track(**kw):return {'carrier':'CJ','orig_delivered':'2026-10-14','return_no':'520000000001','return_status':'DELIVERED','return_delivered':'2026-10-11'}|kw
checks=[]
def check(label,test):assert test,label;checks.append(label)
with tempfile.TemporaryDirectory() as tmp:
 if DIST:
  e=Engine(Store(Path(tmp)/'data'),FakeSMS(),MemoryVault(),aligo_provider=FakeAT(),aligo_vault=MemoryVault());e.configure_shop({'shopName':'테스트스토어'})
 else:
  base=Base();base.setUp();e=base.engine
 e.import_rows({'rows':[order(1)]})
 scenarios=[('late',{'orig_delivered':'2026-10-01','return_delivered':'2026-10-10'},0,'구매자'),('urgent',{'return_delivered':'2026-10-10'},0,'구매자'),('arrived',{},0,'판매자(상품에 문제가 있어요)'),('transit',{'return_status':'IN_TRANSIT','return_delivered':''},-3000,'구매자'),('fee',{'return_status':'NONE','return_no':'','return_delivered':''},-3000,'구매자'),('uncollected',{'return_status':'NONE','return_no':'','return_delivered':''},0,'구매자'),('unknown',{'error':'test'},0,'구매자')]
 rr=[]
 for i,(key,tr,fee,reason) in enumerate(scenarios):
  row=entry();row.update(key=key,orderId='TEST-R'+str(i),product='가상 반품 상품 '+key,reason=reason,fee=fee,customer='가상고객 '+str(i))
  tr={'return_no':{0:'520000000010',1:'520000000002',2:'620000000001',3:'5200000000001',6:'520000000001'}.get(i,'')}|tr
  rr.append(row|clean_tracking(track(**tr),row['invoice'],TODAY))
 with e.store.edit() as s:s['returnCheck']=dict(rows=rr,**shop(s),lastChecked='2026-10-18T09:00:00+09:00')
 with e.store.edit() as s:s['exchangeCheck']={**shop(s),'rows':[new_row('610000000001')|{'exchangeStatus':'교환요청','exchangeOption':'화이트','kind':'exchange','customer':'가상교환','key':'exchange1'}],'lastChecked':NOW.isoformat()}
 fixture=e.public_state();fixture['returns']=public_aftersales(e.store.read(),TODAY);fixture['desktopMode']=True
 snapshot=dict(id='job',phase='idle',running=False,message='가상 조회 준비',settings={'mode':'manual','time':'09:00','folder':'/tmp/가상 반품엑셀','local':not DIST,'watchEnabled':False},data=fixture['returns'])
 bundle=build_bundle(Path(tmp)/'Return UI.app',Path(sys.executable).resolve());resources=bundle/'Contents/Resources'
 for f in ['return_browser.py','return_session.py','return_check.py','return_data.py','web/returns_ui.js']:check('bundle includes '+f,(resources/f).is_file())
 spec=importlib.util.spec_from_file_location('return_test_app',resources/'app.py');app=importlib.util.module_from_spec(spec);spec.loader.exec_module(app)
 server=app.LocalServer(types.SimpleNamespace(public_state=lambda:copy.deepcopy(fixture),message_templates=lambda:{}));server.desktop=True
 thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();qa=ROOT/'docs/qa/aftersales';qa.mkdir(parents=True,exist_ok=True)
 try:
  with sync_playwright() as pw:
   browser=pw.chromium.launch(channel='chrome',headless=True,chromium_sandbox=True)
   page=browser.new_page(viewport={'width':1500,'height':1050});errors=[];posts=[]
   page.on('pageerror',lambda err:errors.append(str(err)))
   page.on('request',lambda r:posts.append(r.url) if r.method=='POST' else None)
   page.route('**/*',lambda r:r.continue_() if r.request.url.startswith(server.origin+'/') else r.abort())
   page.add_init_script('window.returnFixture='+json.dumps(snapshot,ensure_ascii=False)+''';window.returnCalls=[];window.pickupCalls=[];window.pickupFixture={id:'pickup-job',phase:'idle',running:false,message:'가상 회수 준비',settings:{enabled:false},rows:[],history:[],reportPath:''};window.pywebview={api:{pickup_action:async function(token,action,payload,jobId){pickupCalls.push({action,payload,jobId});if(action==='save')pickupFixture.settings.enabled=payload;if(action==='inspect'||action==='start')pickupFixture.rows=payload.map(r=>({...r,result:action==='inspect'?'접수 전 확인':'접수 완료',carrier:'우체국택배',receiver:'테스트스토어',attempt:action==='start'?1:0}));return JSON.parse(JSON.stringify(pickupFixture));},return_action:async function(token,action,settings,jobId){window.returnCalls.push({action,settings,jobId});if(action==='save')returnFixture.settings=settings;if(action==='start'){returnFixture.phase='tracking';returnFixture.running=true;returnFixture.message='가상 송장 조회 중';}if(action==='cancel'){returnFixture.phase='cancelled';returnFixture.running=false;returnFixture.canContinue=false;}return JSON.parse(JSON.stringify(returnFixture));},ably_sync_action:async()=>({username:'가상계정',hasPassword:true,available:true})}};''')
   page.goto(server.url);page.wait_for_function("()=>document.querySelector('#returnsCount')?.textContent==='8'")
   check('no UI script errors',not errors);check('expected cards',page.locator('.cards .card').count()==(10 if DIST else 12))
   check('three logistic counts',page.locator('#returnsCounts').text_content()=='도착 3건 / 배송중 1건 / 미배송 2건 / 교환 1건')
   check('separate unknown','조회 확인 필요 1건' in page.locator('#returnsWarning').text_content())
   cards=page.locator('.cards').bounding_box();bar=page.locator('#returnsCard').bounding_box();check('full width bar',abs(cards['width']-bar['width'])<3)
   page.locator('.cards').screenshot(path=str(qa/'dashboard.png'))
   page.locator('#returnsCard').click();check('dedicated screen',page.locator('#returnsPanel').is_visible() and not page.locator('#orderWorkspace').is_visible());check('send actions hidden',not page.locator('#composeBtn').is_visible())
   check('seven rows',page.locator('#returnRows tr').count()==7)
   page.locator('[data-return-tab="exchange"]').click();check('exchange separately',page.locator('#returnRows tr').count()==1 and '교환요청' in page.locator('#returnRows').inner_text())
   page.locator('.pickup-row').click();check('row opens own invoice',page.locator('#pickupInput').input_value().startswith('610000000001'))
   page.locator('#pickupInspect').click();page.wait_for_function("()=>document.querySelector('#pickupResults').textContent.includes('접수 전 확인')");check('inspect requested before submit',page.evaluate("pickupCalls.filter(c=>c.action==='start').length")==0)
   page.locator('#pickupStart').click();page.wait_for_function("()=>document.querySelector('#pickupResults').textContent.includes('1차 회수접수')");check('manual submit explicit',page.evaluate("pickupCalls.filter(c=>c.action==='start').length")==1)
   page.locator('#pickupDialog').screenshot(path=str(qa/'pickup.png'));page.locator('#pickupClose').click()
   page.locator('[data-return-tab=""]').click()
   for key,*_ in scenarios:
    page.locator('[data-return-tab="'+key+'"]').click();check('section '+key,page.locator('#returnRows tr').count()==1 and key in page.locator('#returnRows tr').get_attribute('class'))
   page.locator('[data-return-tab=""]').click();page.locator('#returnEmphasis').select_option('fee');check('fee crossfilter includes blue',page.locator('#returnRows tr').count()==2)
   page.locator('#returnEmphasis').select_option('blueFee');check('blue red font',page.locator('#returnRows tr').get_attribute('class')=='return-transit return-blue-fee' and page.locator('#returnRows td').first.evaluate('e=>getComputedStyle(e).color')=='rgb(183, 50, 68)')
   page.locator('#returnEmphasis').select_option('seller');check('seller reason red bold',page.locator('#returnRows .return-reason').evaluate('e=>getComputedStyle(e).color')=='rgb(183, 50, 68)')
   page.locator('#returnEmphasis').select_option('');page.locator('#returnSearch').fill('TEST-R0');check('order search',page.locator('#returnRows tr').count()==1)
   page.locator('#returnSearch').fill('상품 urgent');check('combined search',page.locator('#returnRows tr').count()==1)
   page.locator('#returnSearch').fill('');page.locator('#returnSort').select_option('orderId_asc');check('order sort',page.locator('#returnRows tr').first.locator('td').nth(1).text_content().startswith('TEST-R0'))
   page.locator('#returnTable [data-return-sort="orderId"]').click();check('reverse sort',page.locator('#returnRows tr').first.locator('td').nth(1).text_content().startswith('TEST-R6'))
   def displayed_ids():
    return page.locator('#returnRows tr td:nth-child(2)').evaluate_all("es=>es.map(e=>e.firstChild.textContent)")
   def missing_bottom():
    ids=displayed_ids();known=[v for v in ids if v not in {'TEST-R4','TEST-R5'}];missing=[v for v in ids if v in {'TEST-R4','TEST-R5'}]
    return ids==known+missing
   options=page.locator('#returnSort option').evaluate_all('es=>es.map(e=>e.value)')
   for value in options:
    page.locator('#returnSort').select_option(value)
    check('missing invoices bottom '+value,missing_bottom())
   page.locator('#returnSort').select_option('requestedAt_desc')
   page.locator('[data-return-sort="returnNo"]').click()
   check('invoice numeric ascending',displayed_ids()==['TEST-R6','TEST-R1','TEST-R0','TEST-R2','TEST-R3','TEST-R4','TEST-R5'])
   check('invoice ascending direction visible',page.locator('[data-return-sort="returnNo"]').text_content()=='반품송장 ↑' and page.locator('#returnSort').input_value()=='returnNo_asc')
   check('invoice ascending accessible',page.locator('[data-return-sort="returnNo"]').evaluate("e=>e.closest('th').getAttribute('aria-sort')")=='ascending')
   page.locator('[data-return-sort="returnNo"]').click()
   check('invoice numeric descending',displayed_ids()==['TEST-R3','TEST-R2','TEST-R0','TEST-R1','TEST-R6','TEST-R4','TEST-R5'])
   check('invoice descending direction visible',page.locator('[data-return-sort="returnNo"]').text_content()=='반품송장 ↓' and page.locator('#returnSort').input_value()=='returnNo_desc')
   page.locator('[data-return-sort="deliveryStatus"]').click()
   check('delivery status ascending',displayed_ids()==['TEST-R0','TEST-R1','TEST-R2','TEST-R3','TEST-R6','TEST-R4','TEST-R5'])
   check('independent status header',page.locator('[data-return-sort="deliveryStatus"]').text_content()=='배송 상태 ↑' and page.locator('[data-return-sort="returnNo"]').text_content()=='반품송장 ↕')
   page.locator('[data-return-sort="deliveryStatus"]').click()
   check('delivery status descending',displayed_ids()==['TEST-R6','TEST-R3','TEST-R0','TEST-R1','TEST-R2','TEST-R4','TEST-R5'])
   check('status descending accessible',page.locator('[data-return-sort="deliveryStatus"]').evaluate("e=>e.closest('th').getAttribute('aria-sort')")=='descending')
   check('summary preserved',page.locator('#returnSummary').text_content()=='전체 반품 · 7개 상품 / 7개 주문')
   check('known invoice with tracking error retained',displayed_ids()[0]=='TEST-R6')
   page.locator('#returnEmphasis').select_option('fee')
   for value in ['returnNo_asc','returnNo_desc','deliveryStatus_asc','deliveryStatus_desc']:
    page.locator('#returnSort').select_option(value)
    check('sort filtered rows '+value,displayed_ids()==['TEST-R3','TEST-R4'])
   page.locator('#returnEmphasis').select_option('')
   page.locator('[data-return-tab="uncollected"]').click()
   check('missing only section retained',displayed_ids()==['TEST-R5'])
   page.locator('[data-return-tab=""]').click()
   page.locator('#returnSearch').fill('520000000002')
   check('invoice search after sorting',displayed_ids()==['TEST-R1'])
   page.locator('#returnSearch').fill('')
   check('snapshot unchanged by sorting',page.evaluate('JSON.stringify(returnFixture.data.rows)')==json.dumps(snapshot['data']['rows'],ensure_ascii=False,separators=(',',':')))
   page.locator('#returnsPanel').screenshot(path=str(qa/'return_sort.png'))
   page.locator('#returnBack').click();check('back to orders',page.locator('#orderWorkspace').is_visible());page.locator('#returnsCard').click();page.locator('.card[data-color="white"]').click();check('other card exits returns',not page.locator('#returnsPanel').is_visible())
   page.locator('#returnsSettingsBtn').click();page.wait_for_function("()=>!document.querySelector('#returnSave').disabled")
   check('manual default time disabled',page.locator('#returnMode').input_value()=='manual' and page.locator('#returnTime').is_disabled())
   check('pickup default pink off',page.locator('#pickupEnabled').evaluate("e=>e.closest('label').dataset.enabled")=='false')
   page.locator('#pickupEnabled').check();check('pickup green on',page.locator('#pickupEnabled').evaluate("e=>e.closest('label').dataset.enabled")=='true');check('explicit on label','켜짐' in page.locator('#pickupEnabled').evaluate("e=>e.closest('label').textContent"))
   page.locator('#returnMode').select_option('daily');page.locator('#returnTime').fill('14:30');page.locator('#returnSave').click();page.wait_for_function("()=>document.querySelector('#returnSettingsStatus').textContent.includes('저장했습니다')")
   check('pickup saved explicitly',page.evaluate("pickupCalls.some(c=>c.action==='save'&&c.payload===true)"))
   check('local controls in personal only',page.locator('#returnLocalSettings').is_visible()==(not DIST))
   check('daily persisted bridge',page.evaluate("returnCalls.some(c=>c.action==='save'&&c.settings.mode==='daily'&&c.settings.time==='14:30')"))
   page.locator('#returnSettingsDialog').screenshot(path=str(qa/'settings.png'))
   page.locator('#returnSettingsRun').click();page.wait_for_function("()=>document.querySelector('#returnStatus').textContent.includes('가상 송장')");check('start disabled during run',page.locator('#returnRun').is_disabled());check('cancel shown',page.locator('#returnCancel').is_visible())
   page.locator('#returnCancel').click();page.wait_for_function("()=>!document.querySelector('#returnRun').disabled")
   page.evaluate("returnFixture.running=true;returnFixture.phase='login_wait';returnFixture.canContinue=true")
   page.wait_for_function("()=>!document.querySelector('#returnContinue').hidden");page.locator('#returnContinue').click();check('scoped resume job',page.evaluate("returnCalls.some(c=>c.action==='continue'&&c.jobId==='job')"))
   page.evaluate("returnFixture.running=false;returnFixture.canContinue=false")
   page.set_viewport_size({'width':960,'height':850});page.locator('.cards').screenshot(path=str(qa/'dashboard_compact.png'));check('compact fits',page.locator('#returnsCard').bounding_box()['width']<=960)
   check('no live sender POST',not posts);check('no final UI errors',not errors)
   browser.close()
 finally:server.shutdown();thread.join(3);server.server_close();e.store.close()
print(json.dumps({'passed':len(checks),'checks':checks},ensure_ascii=False,indent=2))
