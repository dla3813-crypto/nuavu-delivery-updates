# NUAVU_Delay_v0.6.89_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v0688.md

## 지그재그 로그인 뒤 /shop/None/stats 로 들어가던 문제 (2026-10-23 19:03 보고, 공통)
- 원인: v0.6.91/0.6.86에서 배송연기 안내 화면 복구용으로 Reader에 `self.shop=None`을 넣었는데, 반품/교환·품절 취소 흐름(ZigzagClaims)은 shop('nuavu')을 먼저 정한 뒤 Reader를 초기화해서 그 값이 None으로 지워졌음.
- 수정: Reader가 이미 정해진 shop을 지우지 않음. 대시보드 주소가 다시 https://partners.kakaostyle.com/shop/nuavu/stats 로 열림.
- 회귀 테스트 추가 (tests/test_zigzag_shop_none.py).
