"""Synthetic XLSX through the delivered JS parser + actual local import API.
No Chrome site login, keychain access, operational data or send workers.
"""
from pathlib import Path
import sys,tempfile,threading,copy,json,base64
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from playwright.sync_api import sync_playwright
from app import LocalServer
from domain import Store,Engine
from helpers import FakeSMS,FakeAT,MemoryVault
from test_supply_regression import xlsx,order
checks=[]
def check(name,yes):
 assert yes,name
 checks.append(name)
with tempfile.TemporaryDirectory() as tmp:
 store=Store(Path(tmp)/'isolated');sms=FakeSMS();engine=Engine(store,sms,MemoryVault(),aligo_provider=FakeAT(),aligo_vault=MemoryVault())
 engine.configure_shop({'shopName':'데모스토어'})
 labels=['데모스토어 에이블리','데모스토어 자사몰','데모스토어 아무드']
 engine.import_rows({'rows':[order(i)|{'orderId':str(900+i),'sourceSeller':label,'seller':label} for i,label in enumerate(labels,1)]})
 engine.configure_import_scope({'scopeLabels':True,'available':labels[:2],'scope':labels[:1],'shopRevision':store.read()['settings']['shopRevision']})
 server=LocalServer(engine);server.desktop=True;t=threading.Thread(target=server.serve_forever,daemon=True);t.start()
 header=['판매처','주문번호','주문 상세번호','상품명','옵션명','주문수량','주문일','주문자휴대폰']
 rows=[['데모스토어 에이블리','1001','8001','새 상품','화이트',1,'2026-10-17','01000000000'],['데모스토어 자사몰','1002','','미선택 상품','블랙',1,'2026-10-17','01000000000'],['다른마켓 에이블리','1003','8003','다른마켓 상품','화이트',1,'2026-10-17','01000000000']]
 def receipt(matrix=None,**kw):
  cfg=store.read()['settings'];return {'name':'확장주문검색_20261018001010_123.xlsx','data':base64.b64encode(xlsx([('주문',[header]+(rows if matrix is None else matrix))])).decode(),'shopName':cfg['shopName'],'shopRevision':cfg['shopRevision'],**kw}
 try:
  with sync_playwright() as pw:
   browser=pw.chromium.launch(channel='chrome',headless=True,chromium_sandbox=True)
   try:
    page=browser.new_page();page.route('**/*',lambda r:r.continue_() if r.request.url.startswith(server.origin+'/') else r.abort());page.goto(server.url);page.wait_for_function('state!==null')
    def apply(r):return page.evaluate('async f=>{try{await applyAutoOrderFile(f);return "ok"}catch(e){return e.message}}',r)
    check('automatic receipt applied',apply(receipt())=='ok')
    current={r['orderId']:r for r in store.read()['rows']}
    check('checked seller imported','1001' in current)
    check('unchecked and foreign new orders excluded','1002' not in current and '1003' not in current)
    check('missing order in selected present seller deactivated',not current['901']['active'])
    check('unchecked seller retained',current['902']['active'])
    check('seller absent from file retained',current['903']['active'])
    before=copy.deepcopy(store.read())
    check('old shop receipt rejected','쇼핑몰 설정이 바뀌' in apply(receipt(shopRevision=0)))
    check('old shop receipt does not mutate',before==store.read())
    check('zero rows refused','선택된 판매처가 없습니다' in apply(receipt([])))
    check('zero rows leave orders',before==store.read())
    bad=copy.deepcopy(rows);bad[0][5]='invalid'
    check('invalid quantity refused','읽기 오류' in apply(receipt(bad)))
    check('parse failure leaves orders',before==store.read())
    engine.configure_import_scope({'scopeLabels':True,'available':labels[:2],'scope':[],'shopRevision':store.read()['settings']['shopRevision']})
    before=copy.deepcopy(store.read())
    check('all unchecked does not select all','선택된 판매처가 없습니다' in apply(receipt()))
    check('all unchecked leaves orders',before==store.read())
    check('automatic import sent no customer messages',not sms.sent)
   finally:browser.close()
 finally:server.shutdown();server.server_close();t.join();store.close()
print(json.dumps({'passed':len(checks),'checks':checks},ensure_ascii=False,indent=2))
