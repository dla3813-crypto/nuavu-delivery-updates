"""Real packaged HTTP/native handlers with memory Keychain and fake login.

Run with a source path and --baseline to reproduce the old settings popup.
No actual account, browser login, download, installed app or customer send.
"""
from pathlib import Path
from types import SimpleNamespace
import json,sys,tempfile,threading
QA_ROOT=Path(__file__).resolve().parents[1]
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 and not sys.argv[1].startswith('--') else QA_ROOT
BASELINE='--baseline' in sys.argv
sys.path.insert(0,str(ROOT))
from install_desktop import build_bundle
from playwright.sync_api import sync_playwright
checks=[]
def check(name,yes):
    assert yes,name
    checks.append(name)
with tempfile.TemporaryDirectory() as tmp:
    tmp=Path(tmp)
    bundle=build_bundle(tmp/'Settings QA.app',Path(sys.executable).resolve())
    resources=(bundle/'Contents/Resources').resolve()
    sys.path[:0]=[str(resources),str(ROOT/'tests')]
    import app,desktop
    from domain import Store,Engine
    from order_auto import OrderAutoController,OrderAutoError
    from fake_security import MemoryVault
    from helpers import FakeSMS,FakeAT
    store=Store(tmp/'data');vault=MemoryVault();sms=FakeSMS();at=FakeAT()
    engine=Engine(store,sms,MemoryVault(),aligo_provider=at,aligo_vault=MemoryVault())
    engine.configure_shop({'shopName':'데모스토어'})
    runs=[]
    def login(c,cfg):
        account=c.login_account()
        runs.append({'loginOnly':cfg.get('loginOnly'),'domain':account['domain'],'username':account['username']})
    controller=OrderAutoController(store,runner=login,login_vault=vault)
    controller.start(login_only=True);controller.thread.join(2)
    check('missing-account error reproduced',controller.status()['phase']=='error' and '먼저 저장' in controller.status()['message'])
    server=app.LocalServer(engine);server.desktop=True
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    native=desktop.DesktopAPI(engine,server.token,server.origin,SimpleNamespace())
    native._window=SimpleNamespace(get_current_url=lambda:server.url);native._order_auto=controller
    allowed={'order_auto_status','ezadmin_login_settings','ezadmin_login_save','ezadmin_login_check'}
    def bridge(_source,name,args):
        assert name in allowed
        return getattr(native,name)(*args)
    try:
        with sync_playwright() as pw:
            browser=pw.chromium.launch(channel='chrome',headless=True,chromium_sandbox=True)
            try:
                page=browser.new_page(viewport={'width':1440,'height':1100},locale='ko-KR')
                page.set_default_timeout(10000);errors=[];external=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                def route(r):
                    if r.request.url.startswith(server.origin+'/'):r.continue_()
                    else:external.append(r.request.url);r.abort()
                page.route('**/*',route)
                page.expose_binding('__native',bridge)
                page.add_init_script("""window.pywebview={api:{}};
                for(const n of ['order_auto_status','ezadmin_login_settings','ezadmin_login_save','ezadmin_login_check'])
                    window.pywebview.api[n]=(...args)=>window.__native(n,args);""")
                page.goto(server.url,wait_until='networkidle');page.wait_for_function('state!==null')
                check('packaged modules actually served',app.ROOT==resources and Path(desktop.__file__).parent==resources)
                page.locator('#ezadminSettingsBtn').click()
                page.wait_for_function("!document.getElementById('saveEzadminLogin').disabled")
                if BASELINE:
                    check('baseline reopening settings blocks with old error',page.locator('#orderErrorDialog').evaluate('e=>e.open'))
                    page.locator('[data-close=orderErrorDialog]').click()
                else:
                    check('opening settings does not reopen old error',not page.locator('#orderErrorDialog').evaluate('e=>e.open'))
                    check('all login fields editable',all(page.locator('#'+n).is_enabled() for n in ('ezadminDomain','ezadminUsername','ezadminPassword')))
                    check('current unsaved state clear','입력하고 저장' in page.locator('#ezadminLoginStatus').inner_text())
                    check('old error separately labelled','이전 작업 안내:' in page.locator('#ezadminPreviousError').inner_text())
                    check('no login attempted on open',not runs and vault.load() is None)
                    qa=QA_ROOT/'docs/qa';qa.mkdir(exist_ok=True)
                    page.locator('#ezadminSettingsDialog').screenshot(path=str(qa/'v0631_settings_after_old_error.png'))
                for ident,value in [('ezadminDomain','demo-shop'),('ezadminUsername','demo-user'),('ezadminPassword','FAKE-ONLY-SECRET')]:
                    page.locator('#'+ident).fill(value)
                page.locator('#saveEzadminLogin').click()
                page.wait_for_function("!document.getElementById('saveEzadminLogin').disabled")
                check('save used real native/account handler',controller.login_settings()['hasPassword'] and vault.load()['username']=='demo-user')
                check('save alone does not login',not runs)
                check('password cleared from field',page.locator('#ezadminPassword').input_value()=='')
                if BASELINE:
                    check('baseline retains missing-account error after saving',controller.status()['phase']=='error')
                    page.locator('[data-close=ezadminSettingsDialog]').click();page.locator('#ezadminSettingsBtn').click()
                    page.wait_for_function("document.getElementById('orderErrorDialog').open")
                    check('baseline saved credentials still reopen stale modal',controller.login_settings()['hasPassword'] and page.locator('#orderErrorDialog').evaluate('e=>e.open'))
                else:
                    check('successful save clears completed error',controller.status()['phase']=='idle')
                    check('old error note removed after save',not page.locator('#ezadminPreviousError').is_visible())
                    page.locator('[data-close=ezadminSettingsDialog]').click();page.locator('#ezadminSettingsBtn').click()
                    page.wait_for_function("!document.getElementById('saveEzadminLogin').disabled")
                    check('reopen shows saved state without modal',not page.locator('#orderErrorDialog').evaluate('e=>e.open') and '저장된 계정' in page.locator('#ezadminLoginStatus').inner_text())
                    # Fill a different account, then click save+check without separate save.
                    page.locator('#ezadminUsername').fill('demo-new-user');page.locator('#ezadminPassword').fill('FAKE-NEW-SECRET')
                    page.locator('#checkEzadminLogin').click()
                    page.wait_for_function("document.getElementById('ezadminLoginStatus').textContent.includes('로그인 확인 완료')")
                    check('save+check uses the newly entered identity',runs==[{'loginOnly':True,'domain':'demo-shop','username':'demo-new-user'}])
                    check('saved password is new value',vault.load()['password']=='FAKE-NEW-SECRET')
                    check('no secret in UI/status',not any(x in page.locator('body').inner_text()+json.dumps(controller.status()) for x in ('FAKE-ONLY-SECRET','FAKE-NEW-SECRET')))
                    check('duplicate-action controls restored',page.locator('#saveEzadminLogin').is_enabled() and page.locator('#checkEzadminLogin').is_enabled())
                    # Blank is allowed only for the same saved identity.
                    page.locator('#ezadminUsername').fill('changed-again')
                    page.locator('#checkEzadminLogin').click()
                    page.wait_for_function("document.getElementById('ezadminLoginStatus').textContent.includes('새 계정에는 비밀번호')")
                    check('new identity without password cannot start login',len(runs)==1 and vault.load()['username']=='demo-new-user')
                    page.locator('#ezadminUsername').fill('demo-new-user');vault.fail_save=True
                    page.locator('#ezadminPassword').fill('FAKE-FAILED')
                    page.locator('#checkEzadminLogin').click()
                    page.wait_for_function("document.getElementById('ezadminLoginStatus').textContent.includes('키체인에 저장하지 못')")
                    check('keychain save refusal stops login',len(runs)==1 and vault.load()['password']=='FAKE-NEW-SECRET')
                    vault.fail_save=False
                    # A delayed old poll must not resurrect the error after save.
                    old=controller.status()|{'id':'old-error','phase':'error','running':False,'message':'먼저 저장하세요.'}
                    page.evaluate("""() => {
                       window.realStatus=pywebview.api.order_auto_status;let once=true;
                       pywebview.api.order_auto_status=(...args)=>{if(once){once=false;return new Promise(resolve=>window.resolveOld=resolve);}return realStatus(...args);};
                       pollOrderAuto();
                    }""")
                    page.wait_for_function("typeof resolveOld==='function'")
                    page.locator('#saveEzadminLogin').click()
                    page.wait_for_function("!ezadminFormBusy")
                    page.evaluate('r=>resolveOld(r)',old);page.wait_for_timeout(150)
                    check('late old poll cannot reopen error',not page.locator('#orderErrorDialog').evaluate('e=>e.open') and controller.status()['phase']=='idle')
                    check('same identity empty password preserved',vault.load()['password']=='FAKE-NEW-SECRET')
                    page.locator('#ezadminSettingsDialog').screenshot(path=str(qa/'v0631_settings_saved.png'))
                    # A real new failure still appears; only stale errors are suppressed.
                    def failed_login(c,cfg):c.login_account();raise OrderAutoError('가상 사이트의 새 로그인 오류')
                    controller.runner=failed_login
                    page.locator('#checkEzadminLogin').click()
                    page.wait_for_function("document.getElementById('orderErrorDialog').open")
                    check('fresh failure remains visible','가상 사이트의 새 로그인 오류' in page.locator('#orderErrorText').inner_text())
                check('no external sites or customer messages',not external and not sms.sent and not at.sent)
                check('no JavaScript errors',not errors)
            finally:browser.close()
    finally:
        controller.cancel()
        if controller.thread:controller.thread.join(2)
        server.shutdown();server.server_close();thread.join();store.close()
print(json.dumps({'baseline':BASELINE,'passed':len(checks),'checks':checks},ensure_ascii=False,indent=2))
