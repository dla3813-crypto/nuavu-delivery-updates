"""Installed Chrome against intercepted synthetic Ably DOM. No live traffic."""
from pathlib import Path
import sys,json,threading
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from playwright.sync_api import sync_playwright
from ably_browser import Reader,LOGIN,ORDERS
from ably_sync import AblySyncError

HEAD='<!doctype html><meta charset="utf-8"><a href="/seller">데모스토어</a><span>로그아웃</span>'
LOGIN_HTML='''<!doctype html><meta charset="utf-8"><input type="text"><input type="password"><button onclick="if(document.querySelector('input').value==='fake'&&document.querySelector('input[type=password]').value==='FAKE-ONLY'){location.href='/dashboard'}">로그인</button>'''
PAGE=HEAD+'''<div class="el-loading-mask" style="display:none">읽는중</div><table class="el-table__header"><tr><th>상품주문번호</th><th>주문번호</th><th>수량</th><th>판매채널</th><th>배송지연 메시지 발송</th></tr></table><table class="el-table__body"><tbody></tbody></table><div class="pagination-container"><span class="total-count"></span><span class="el-pagination__sizes"><input value="30개씩 보기" readonly onclick="document.getElementById('size').hidden=false"></span><div id="size" hidden><button onclick="this.parentElement.hidden=true;document.querySelector('.el-pagination__sizes input').value='100개씩 보기';size=100;draw(1)">100개씩 보기</button></div><button class="btn-prev" disabled></button><ul class="el-pager"></ul><button class="btn-next" disabled></button></div><div id="details"></div><script>
let total=TOTAL,size=30,number=1,reads=0,visited=[],actions=[],caseName=CASE;
function draw(n){number=n;document.querySelector('.el-loading-mask').style.display='block';document.querySelector('.el-pager').innerHTML=Array.from({length:Math.max(1,Math.ceil(total/size))},(_,i)=>`<li class="number ${n===i+1?'active':''}" onclick="draw(${i+1})">${i+1}</li>`).join('');setTimeout(()=>{
 document.querySelector('.total-count').textContent='총 '+total+'건';document.querySelector('.el-table__body tbody').innerHTML=Array.from({length:Math.min(size,Math.max(0,total-(n-1)*size))},(_,i)=>{const id=(n-1)*size+i+1;return `<tr><td><a onclick="detail('${id}')">${id}</a></td><td>${10000+id}</td><td>1</td><td>에이블리</td><td>${caseName==='all-unsent'?'-':id%2?'발송 (2026-10-15)':'-'}</td></tr>`}).join('');document.querySelector('.el-loading-mask').style.display='none';},30)}
function detail(id){reads++;visited.push(id);let title=caseName==='wrong-detail'?'999':id;document.getElementById('details').innerHTML=`<div role="dialog" aria-label="상품주문정보 조회 [${title}]"><div><span class="title">수량</span><span>1</span></div><div><span class="title">주문상태</span><span>상품 준비중</span></div><div><span class="title">예상출고일</span><span>${caseName==='bad-date'?'2026-02-30':id==='3'?'':'2026-10-21~2026-10-22'}</span></div><button aria-label="Close" onclick="document.getElementById('details').innerHTML='';if(caseName==='changed-list'){total++;draw(number)}">Close</button></div>`}
draw(1);
</script>'''
results=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(channel='chrome',headless=True,chromium_sandbox=True)
 try:
  for case,total in [('three-pages',201),('cached-only',1),('changed-cache',5),('empty',0),('all-unsent',4),('changed-list',2),('bad-date',1),('cancel',3),('wrong-market',1)]:
   print('CASE '+case,flush=True);requests=[];context=browser.new_context();stop=threading.Event();messages=[]
   def route(r):
    requests.append(r.request.url)
    if r.request.url==LOGIN:r.fulfill(body=LOGIN_HTML,content_type='text/html')
    elif '/dashboard' in r.request.url:r.fulfill(body=HEAD.replace('데모스토어','다른마켓') if case=='wrong-market' else HEAD,content_type='text/html')
    elif '/sales/order/send' in r.request.url:
     html=PAGE.replace('TOTAL',str(total)).replace('CASE',json.dumps(case))
     if case=='changed-cache':
      html=html.replace('<td>1</td>','<td>${id===1?2:1}</td>').replace('<span>1</span>','<span>${id===\'1\'?2:1}</span>')
      html=html.replace("'발송 (2026-10-15)'","(id===5?'발송 (2026-10-16)':'발송 (2026-10-15)')")
     r.fulfill(body=html,content_type='text/html')
    else:r.abort()
   context.route('**/*',route);page=context.new_page()
   def progress(m):
    messages.append(m)
    if case=='cancel' and '2번째' in m:stop.set()
   reader=Reader(page,stop,progress)
   try:
    reader.login({'username':'fake','password':'FAKE-ONLY','shopName':'데모스토어'})
    cache={str(i):dict(itemId=str(i),orderId=str(10000+i),qty=1,noticeSent=True,noticeDate='2026-10-15',range='' if i==3 else '2026-10-21~2026-10-22',readAt='2026-10-17T12:00:00+09:00') for i in (1,3,5)} if case in ('cached-only','changed-cache') else {}
    result=reader.collect(cache)
    assert case in ('three-pages','cached-only','changed-cache','empty','all-unsent'),case
    assert result['total']==total and len(result['entries'])==({'three-pages':101,'cached-only':1,'changed-cache':3}.get(case,0)) and result['verified']
    if case=='three-pages':
     assert result['pages']==3 and result['entries'][0]['noticeDate']=='2026-10-15' and result['entries'][1]['range']==''
     assert page.evaluate('visited.length')==101 and len(set(page.evaluate('visited')))==101 and all(int(x)%2 for x in page.evaluate('visited'))
    if case=='cached-only':assert page.evaluate('visited')==[] and result['entries'][0]['fromCache']
    if case=='changed-cache':
     assert page.evaluate('visited')==['1','3','5']
     assert result['entries'][0]['qty']==2 and result['entries'][2]['noticeDate']=='2026-10-16'
    assert not page.evaluate('actions')
    results.append({'case':case,'passed':True,'listed':total,'opened':page.evaluate('visited.length')})
    if case=='three-pages':
     cache={e['itemId']:e|{'readAt':'2026-10-17T12:00:00+09:00'} for e in result['entries'] if e['range']}
     page.goto(ORDERS,wait_until='domcontentloaded');repeated=reader.collect(cache)
     assert repeated['verified'] and repeated['pages']==3 and len(repeated['entries'])==101
     assert page.evaluate('visited')==['3'] and sum(e.get('fromCache',False) for e in repeated['entries'])==100
     results.append({'case':'repeat-three-pages','passed':True,'listed':total,'cached':100,'opened':1})
   except AblySyncError as e:
    assert case in ('changed-list','bad-date','cancel','wrong-market'),(case,str(e))
    results.append({'case':case,'passed':True,'rejected':str(e)})
   finally:context.close()
   assert all('/login' in u or '/dashboard' in u or '/sales/order/send' in u for u in requests),requests
 finally:browser.close()
print(json.dumps(results,ensure_ascii=False,indent=2))
