"""Actual Chrome, all external requests intercepted with synthetic fixtures."""
from pathlib import Path
import base64,datetime as dt,json,sys,threading
from urllib.parse import urlsplit,parse_qs
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from return_browser import collect,CJ_JS,EPOST_JS,ReturnFlow,year_ago_ok
from return_data import ReturnError,ReturnCancelled,HEADERS
from test_returns import xlsx,TODAY
from playwright.sync_api import sync_playwright
checks=[]
def check(label,ok):assert ok,label;checks.append(label)
class Control:
 def __init__(self):self.stop=threading.Event();self.messages=[]
 def clock(self):return dt.datetime(2026,10,18,12,0,tzinfo=dt.timezone(dt.timedelta(hours=9)))
 def check(self):
  if self.stop.is_set():raise ReturnCancelled('중단')
 def update(self,phase,msg):self.messages.append((phase,msg))
 def browser_failed(self,message,*args):raise ReturnError(message)
 def take_browser_action(self):return None
 def end_browser_recovery(self):pass
account=dict(username='fixture-user',password='fixture-password',shopName='테스트마켓')
check('year range bounds',year_ago_ok('2025-10-18',TODAY) and not year_ago_ok('2020-10-18',TODAY) and not year_ago_ok('2026-09-18',TODAY))
for case in ['success','zero','mismatch','wrong_market','combined27','waiting_only','hidden_duplicate','missing_status','changed_status','request27_products28','missing_request']:
 requests=[];contexts=[];downloads=[]
 rows=[['2026-10-10','가상 고객1','구매자','510000000001',0,'ORDER1','가상 코트'],['2026-10-10','가상 고객2','판매자(상품에 문제가 있어요)','610000000001',-3000,'ORDER2','가상 니트']]
 if case in ('combined27','mismatch','changed_status','request27_products28','missing_request'):
  rows=[['2026-10-10','가상 고객','구매자','510000000001',0,'ORDER'+str(i),'가상 상품'] for i in range(26 if case=='mismatch' else 27)]
 if case=='waiting_only':rows=[['2026-10-10','가상 고객','구매자','510000000001',0,'ORDER'+str(i),'가상 상품'] for i in range(22)]
 headers=None
 if case in ('request27_products28','missing_request'):
  headers=list(HEADERS.values())+['반품 접수번호','상품주문번호']
  rows=[row+['RETURN'+str(i),'ITEM'+str(i)] for i,row in enumerate(rows)]
  extra=list(rows[0]);extra[6]='같은 반품의 두 번째 상품';extra[-1]='EXTRA_ITEM'
  rows.append(extra)
  if case=='missing_request':rows.pop(-2)
 raw=base64.b64encode(xlsx(rows,headers)).decode();market='다른마켓' if case=='wrong_market' else '테스트마켓'
 profile='<h1 class="profile__market-name">'+market+'</h1>'
 requested,waiting=(0,0) if case=='zero' else (5,22) if case in ('combined27','mismatch','changed_status','request27_products28','missing_request') else (0,22) if case=='waiting_only' else (1,1)
 total=requested+waiting
 def status_card(title,value,id='',hidden=False):return f'<div class="return-status-filter__filter"'+(' style="display:none"' if hidden else '')+f'><div class="return-status-filter__filter--title"><p>{title}</p></div><div id="{id}">{value}건</div></div>'
 statuses=status_card('반품요청 (접수필요)',requested,'requested')+('' if case=='missing_status' else status_card('검수대기',waiting,'waiting'))+status_card('검수완료 후 환불요청',30)+status_card('반품완료',105)
 if case=='hidden_duplicate':statuses+=status_card('반품요청 (접수필요)',999,hidden=True)+status_card('검수대기',999,hidden=True)
 login='''<meta charset="utf-8"><form><input type="text"><input type="password"><button>로그인</button></form><script>document.querySelector('form').onsubmit=e=>{e.preventDefault();if(document.querySelector('input[type=text]').value==='fixture-user'&&document.querySelector('input[type=password]').value==='fixture-password')location.href='/dashboard';};</script>'''
 changed="document.querySelector('#requested').textContent='6건';document.querySelector('#waiting').textContent='21건';" if case=='changed_status' else ''
 html='<meta charset="utf-8">'+profile+statuses+f'''<div class="el-date-editor--daterange"><input class="el-range-input" value="2026-09-18"><input class="el-range-input" value="2026-10-18"></div><div class="el-picker-panel el-date-range-picker" hidden><button class="el-picker-panel__shortcut">지난 일년</button></div><button id="search">검색</button><span class="el-pagination__total">총 {requested}건</span><button id="export"><i></i>전체 주문 엑셀 다운로드</button><script>document.querySelector('.el-range-input').onclick=()=>document.querySelector('.el-picker-panel').hidden=false;document.querySelector('.el-picker-panel__shortcut').onclick=()=>{{document.querySelector('.el-range-input').value='2025-10-18';document.querySelector('.el-picker-panel').hidden=true;}};document.querySelector('#export').onclick=()=>{{const a=document.createElement('a');a.download='반품 진행 관리_20261018.xlsx';a.href='data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,{raw}';a.click();window.exportCount=(window.exportCount||0)+1;{changed}}};</script>'''
 def route(r):
  u=urlsplit(r.request.url);requests.append((r.request.method,u.hostname,u.path));body='';ctype='text/html; charset=utf-8'
  if u.hostname=='my.a-bly.com':
   if u.path=='/login':body=login
   elif u.path=='/dashboard':body='<meta charset="utf-8">'+profile
   elif u.path=='/sales/order/return/progress':body=html
   else:raise AssertionError('unexpected Ably endpoint '+u.path)
  elif u.hostname=='www.cjlogistics.com':
   if u.path.endswith('tracking-detail'):
    no=parse_qs(r.request.post_data)['paramInvcNo'][0];ctype='application/json'
    body=json.dumps({'parcelResultMap':{'resultList':[{'rtnTrspbillnum':'520000000001' if no.startswith('51') else ''}]},'parcelDetailResultMap':{'resultList':[{'scanNm':'배송완료','dTime':'2026-10-04' if no.startswith('51') else '2026-10-11'}]}})
   else:body='<input name="_csrf" value="fixture-csrf">'
  elif u.hostname=='service.epost.go.kr':
   no=parse_qs(u.query)['sid1'][0]
   body='<meta charset="utf-8">'+('반품등기번호: 620000000001' if no.startswith('61') else '')+'<table><tr><td>2026.10.04</td><td>10:00</td><td>우체국</td><td>'+('배달완료' if no.startswith('61') else '발송')+'</td></tr></table>'
  else:raise AssertionError('Unexpected external host')
  r.fulfill(status=200,content_type=ctype,body=body)
 def context(browser,accept_downloads=False):
  c=browser.new_context(accept_downloads=accept_downloads);c.route('**/*',route);c.on('page',lambda p:p.on('download',lambda d:downloads.append(d.suggested_filename)));contexts.append(c);return c
 c=Control()
 with patch('return_session.launch_chrome',lambda pw:pw.chromium.launch(channel='chrome',headless=True,chromium_sandbox=True)),patch('return_session.new_context',context):
  if case in ('success','zero','combined27','waiting_only','hidden_duplicate','request27_products28'):
   snapshot=collect(dict(account),c);check(case+' complete',snapshot['complete'] and snapshot['total']==(28 if case=='request27_products28' else total) and snapshot['requestTotal']==total)
   if case=='success':
    check('CJ delivered with return number',snapshot['rows'][0]['returnStatus']=='DELIVERED' and snapshot['rows'][0]['returnNo']=='520000000001')
    check('EPOST transit with return number',snapshot['rows'][1]['returnStatus']=='IN_TRANSIT' and snapshot['rows'][1]['returnNo']=='620000000001')
   elif case=='zero':check('zero does not query carriers',all(h=='my.a-bly.com' for _,h,_ in requests))
   if case=='request27_products28':
    check('all 28 products retained for 27 requests',len(snapshot['rows'])==28 and len({r['requestId'] for r in snapshot['rows']})==27)
    check('header-excluded product and request counts shown',any('반품 27건 · 상품 28개 확인(제목 행 제외)' in m for _,m in c.messages))
   if case=='combined27':check('user 5 plus 22 breakdown shown',any('반품요청 5건 + 검수대기 22건 = 총 27건' in message for _,message in c.messages))
  else:
   try:collect(dict(account),c);raise AssertionError('must stop')
   except ReturnError as exc:
    check(case+' rejected',True)
    if case=='mismatch':check('mismatch reports actual counts','합계 27건과 엑셀 상품 26개' in str(exc))
    if case=='missing_request':check('27 products with only 26 requests rejected','합계 27건과 엑셀 반품 접수 26건(제목 제외 상품 27개)' in str(exc))
    if case=='changed_status':check('same-total status shift detected','다운로드 중 반품요청·검수대기 건수가 바뀌어' in str(exc))
   check(case+' no carriers',all(h=='my.a-bly.com' for _,h,_ in requests))
 check(case+' one context',len(contexts)==1)
 check(case+' download once or no download',len(downloads)==(0 if case in ('zero','missing_status','wrong_market') else 1))
 check(case+' no refund/update requests',all(method=='GET' or host=='www.cjlogistics.com' and path.endswith('/tracking-detail') for method,host,path in requests))
# Exercise parser edge cases in the real JS engine without any real network.
with sync_playwright() as pw:
 browser=pw.chromium.launch(channel='chrome',headless=True,chromium_sandbox=True);page=browser.new_page();page.set_content('<input name="_csrf" value="test">')
 cases=[('예약접수','NONE'),('집화처리','IN_TRANSIT'),('간선상차','IN_TRANSIT'),('잘못된새상태','ERROR')]
 for status,expected in cases:
  page.evaluate('''status=>{window.fetch=async(url,opts)=>({ok:true,json:async()=>({parcelResultMap:{resultList:[{rtnTrspbillnum:opts.body.includes('510000000001')?'520000000001':''}]},parcelDetailResultMap:{resultList:[{scanNm:opts.body.includes('510000000001')?'배송완료':status,dTime:'2026-10-10'}]}})});}''',status)
  result=page.evaluate(CJ_JS,['510000000001'])['510000000001'];check('CJ status '+status,('ERROR' if result.get('error') else result['return_status'])==expected)
 page.evaluate("()=>{window.fetch=async()=>({ok:true,json:async()=>({error:'login failed'})})}")
 check('CJ invalid schema error',bool(page.evaluate(CJ_JS,['510000000001'])['510000000001'].get('error')))
 page.evaluate("()=>{window.fetch=async()=>({ok:true,text:async()=>'<html>오류 페이지</html>'})}")
 check('EPOST invalid HTML error',bool(page.evaluate(EPOST_JS,[['610000000001'],'https://example.test/%s'])['610000000001'].get('error')))
 page.evaluate("()=>{window.fetch=async()=>({ok:true,text:async()=>'<html>조회 정보가 없습니다.</html>'})}")
 check('EPOST no records is not transport error',not page.evaluate(EPOST_JS,[['610000000001'],'https://example.test/%s'])['610000000001'].get('error'))
 browser.close()
print(json.dumps({'passed':len(checks),'checks':checks},ensure_ascii=False,indent=2))
