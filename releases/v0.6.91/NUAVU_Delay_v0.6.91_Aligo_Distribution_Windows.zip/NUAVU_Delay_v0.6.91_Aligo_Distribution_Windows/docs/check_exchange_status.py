"""Chrome regression for Ably's selected-card toggle. Synthetic DOM; no site/network."""
from pathlib import Path
import sys,json,importlib.util
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from playwright.sync_api import sync_playwright
from exchange_browser import ExchangeFlow
from return_data import ReturnError
checks=[]
def check(name,ok):
 assert ok,name
 checks.append(name)
class C:
 def check(self):pass
 def update(self,*args):pass
class Fast(ExchangeFlow):
 def pause(self,n):super().pause(min(n,.02))
 def until(self,p,t,m):return super().until(p,min(t,.45),m)
HTML='''<meta charset="utf-8">
<span class="ant-typography FilterCard-label" id="request">교환요청</span>
<span class="ant-typography FilterCard-label" id="collect">교환수거중</span>
<div class="ant-select ant-select-single"><div class="ant-select-selector"><span class="ant-select-selection-wrap"><span class="ant-select-selection-search"><input id="status" readonly style="opacity:0"></span><span class="ant-select-selection-item" id="selected">교환요청</span></span></div></div>
<button id="search">검색</button><table><thead><tr><th>주문상태</th></tr></thead><tbody><tr class="ant-table-row"><td>교환요청</td></tr></tbody></table><span class="ant-pagination-total-text">총 1개</span>
<script>window.clicks=0;window.searches=[];window.delay=0;window.ignore=false;
function choose(label){clicks++;if(ignore)return;const next=selected.textContent===label?'전체':label;setTimeout(()=>{selected.textContent=next},delay);}
request.onclick=()=>choose('교환요청');collect.onclick=()=>choose('교환수거중');
search.onclick=()=>{searches.push(selected.textContent);document.querySelector('tbody td').textContent=selected.textContent==='전체'?'교환요청':selected.textContent;};
</script>'''
with sync_playwright() as pw:
 browser=pw.chromium.launch(channel='chrome',headless=True,chromium_sandbox=True)
 try:
  context=browser.new_context();context.route('**/*',lambda r:r.abort())
  page=context.new_page();flow=Fast(C(),context,'가상');flow.page=page
  def fresh():page.set_content(HTML)
  def search():page.get_by_role('button',name='검색',exact=True).click();flow.wait_exchange(page,'교환요청')
  # Reproduce the old unconditional card click using the unmodified prior source.
  if len(sys.argv)>1:
   spec=importlib.util.spec_from_file_location('legacy_exchange',Path(sys.argv[1])/'exchange_browser.py');legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)
   class Old(legacy.ExchangeFlow):
    def pause(self,n):super().pause(min(n,.02))
    def until(self,p,t,m):return super().until(p,min(t,.45),m)
   old=Old(C(),context,'가상');old.page=page;fresh()
   page.locator('#request').click();page.wait_for_timeout(20);page.locator('#search').click()
   try:old.wait_exchange(page,'교환요청')
   except ReturnError as e:check('old source reproduces reported error',str(e)=='교환 상태 선택을 확인하지 못했습니다.')
   else:raise AssertionError('Old source unexpectedly accepted toggled-off status')
  fresh();flow.select_exchange_status(page,'교환요청');search()
  check('initial request kept without clicking',page.evaluate('clicks')==0 and page.evaluate('searches')==['교환요청'])
  page.evaluate('delay=90');flow.select_exchange_status(page,'교환수거중');page.locator('#search').click();flow.wait_exchange(page,'교환수거중')
  check('wait for changed status before search',page.evaluate('clicks')==1 and page.evaluate('searches')[-1]=='교환수거중')
  flow.select_exchange_status(page,'교환수거중')
  check('repeated selection never toggles off',page.evaluate('clicks')==1 and flow.selected_exchange_status(page)=='교환수거중')
  flow.select_exchange_status(page,'교환요청');search()
  check('switch back exactly once',page.evaluate('clicks')==2 and flow.selected_exchange_status(page)=='교환요청')
  fresh();page.evaluate("selected.textContent='전체'");flow.select_exchange_status(page,'교환요청');search()
  check('all to requested',page.evaluate('clicks')==1)
  fresh();page.evaluate("selected.textContent='전체';ignore=true")
  try:flow.select_exchange_status(page,'교환요청')
  except ReturnError as e:check('failed selection stops without retry/search',str(e)=='교환 상태 선택을 확인하지 못했습니다.' and page.evaluate('clicks')==1 and page.evaluate('searches')==[])
  else:raise AssertionError('Failed selection accepted')
  fresh();page.evaluate("selected.textContent='교환요청 완료'")
  check('selection compared by exact label',flow.selected_exchange_status(page)!='교환요청')
  fresh();page.evaluate("selected.insertAdjacentHTML('afterend','<span class=ant-select-selection-item>교환수거중</span>')")
  check('ambiguous visible values rejected',flow.selected_exchange_status(page) is None)
  fresh();page.evaluate("selected.insertAdjacentHTML('afterend','<span class=ant-select-selection-item hidden>전체</span>')")
  check('hidden stale value ignored',flow.selected_exchange_status(page)=='교환요청')
  fresh();page.evaluate("document.querySelector('tbody').innerHTML='';document.querySelector('.ant-pagination-total-text').textContent='총 0개'")
  flow.wait_exchange(page,'교환요청');check('empty selected list allowed',True)
  page.evaluate("selected.textContent='전체'")
  try:flow.wait_exchange(page,'교환요청')
  except ReturnError:check('empty list cannot bypass selection check',True)
  else:raise AssertionError('Incorrect empty-list selection accepted')
  fresh();page.evaluate("document.querySelector('tbody td').textContent='교환수거중'")
  try:flow.wait_exchange(page,'교환요청')
  except ReturnError as e:check('stale other status rows rejected','목록이 갱신되지' in str(e))
  else:raise AssertionError('Stale rows accepted')
  fresh();page.evaluate("document.querySelector('tbody td').textContent=''")
  try:flow.wait_exchange(page,'교환요청')
  except ReturnError as e:check('blank row is pending not IndexError','목록이 갱신되지' in str(e))
  else:raise AssertionError('Blank row accepted')
  context.close()
 finally:browser.close()
print(json.dumps({'checks':len(checks),'result':'PASS','names':checks},ensure_ascii=False))
