# NUAVU_Delay_v0.6.55_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v0654.md

## Windows: 바로가기 더블클릭 무반응 (배포판, 10-20 10:04 보고) — 시간대 DB
- 원인: `order_auto.py`·`return_check.py`가 불러오는 순간 `ZoneInfo('Asia/Seoul')`을 만드는데, **Windows에는 시스템 시간대 DB가 없어** (`tzdata` 패키지 없이는) 여기서 `ZoneInfoNotFoundError`로 죽습니다. 창 없는 pythonw 실행이라 아무 표시 없이 끝났습니다(로그 기록보다 앞선 import 단계).
- 수정: 한국은 서머타임이 없으므로 zoneinfo가 없으면 **고정 +09:00**으로 대체(공통 코드), 설치 스크립트는 `tzdata`도 함께 설치. 이제 같은 경우가 나면 시작 로그·경고창에 남습니다.
