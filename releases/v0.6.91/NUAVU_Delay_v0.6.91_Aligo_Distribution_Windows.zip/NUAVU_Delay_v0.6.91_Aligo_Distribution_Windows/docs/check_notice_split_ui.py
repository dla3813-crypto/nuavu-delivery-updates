"""Actual temporary app HTTP assets, synthetic state only; no sender or live site."""
from pathlib import Path
import copy,importlib.util,json,sys,tempfile,threading,types
ROOT=(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]).resolve();personal='_Distribution' not in ROOT.name
sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from install_desktop import build_bundle
from playwright.sync_api import sync_playwright
checks=[]
def check(name,ok):
 assert ok,name
 checks.append(name)
with tempfile.TemporaryDirectory() as tmp:
 if personal:fixture=json.loads((ROOT/'docs/V0638_ui_fixture.json').read_text())
 else:
  from domain import Store,Engine
  from helpers import FakeSMS,FakeAT,MemoryVault
  from test_supply_regression import order
  e=Engine(Store(Path(tmp)/'test-data'),FakeSMS(),MemoryVault(),aligo_provider=FakeAT(),aligo_vault=MemoryVault())
  e.configure_shop({'shopName':'테스트스토어'});e.import_rows({'rows':[order(1)]});fixture=e.public_state()
 sample=copy.deepcopy(fixture['rows'][0]);fixture['notices']=[];fixture['alerts']=[];fixture['imports']=[];fixture['desktopMode']=False;fixture['rows']=[]
 fixture['supply']['lastReadAt']='2026-10-18T01:00:00+09:00'
 def row(key,**extra):
  r=copy.deepcopy(sample);r.update(dict(key=key,orderId=key,seller='누아브 에이블리',sourceSeller='테스트스토어 에이블리',product='가상 상품 '+key,option='화이트 FREE',qty=1,buyer='가상고객 '+key,phone='01000000000',active=True,review=False,stockSecured=False,progressOfficeDates=[],manifestOfficeDates=[],dispatchStart='',dispatchEnd='',inventoryReady=False,isBundle=False,bundleReady=False,bundleScheduled=False,bundleType='',itemScheduleKnown=False,soldoutNotified=False,soldoutCheck=0,soldoutCheckHidden=False,delayRiskStage='',delayRisk={},bucket='unnotified',color='white',noticeCount=0,delayNoticeCount=0,externalNoticeCount=0,appNoticeCount=0,externalHistory=False,orderDate='2026-10-01',dueDate='',lastNoticeAt='',supplyInfo={'matchNeeded':True,'reason':'가상 연결 필요'},manualMatchRecommended=False,manualMatchRecommendations=[]));r.update(extra);return r
 risk=dict(delayRiskStage='confirmed',delayRisk={'stage':'confirmed','shortQty':1})
 fixture['rows']=[row('a',orderId='ORDER1',bucket='overdue',color='red',dueDate='2026-10-15',qty=10),row('b',orderId='ORDER1'),row('c',orderId='ORDER2',**risk),row('d',orderId='ORDER3'),row('e',orderId='ORDER4',qty=2,noticeCount=1,delayNoticeCount=1,externalNoticeCount=1,bucket='within',dueDate='2026-10-30'),row('f',orderId='C100',inventoryReady=True),row('g',orderId='C101'),row('h',bucket='soldout',soldoutNotified=True,color='charcoal'),row('i',soldoutCheck=1),row('j',isBundle=True,bundleReady=True,bundleType='ready',inventoryReady=True,stockSecured=True),row('k',isBundle=True,bundleScheduled=True,bundleType='unconfirmed',progressOfficeDates=['2026-10-16'],dispatchStart='2026-10-21',dispatchEnd='2026-10-22'),row('l',isBundle=True,bundleType='confirmed',stockSecured=True),row('m',isBundle=True,bundleType='planned',stockSecured=True),row('n',isBundle=True,bundleType='unconfirmed'),row('o',active=False),row('p',inventoryReady=True,stockSecured=True),row('q',soldoutCheckHidden=True,soldoutCheck=1),row('r',manualMatchRecommended=True,manualMatchRecommendations=[{'reason':'화이트와 아이보리'}],supplyInfo={'manualRecommended':True,'manualRecommendations':[{'reason':'화이트와 아이보리'}],'matchNeeded':True}),row('s',supplyInfo={'matchMethod':'manual','reason':'가상 수동 연결'}),row('t',supplyInfo={'matchMethod':'auto','reason':'가상 자동 연결'})]
 bundle=build_bundle(Path(tmp)/'UI check.app',Path(sys.executable).resolve());resources=bundle/'Contents/Resources'
 spec=importlib.util.spec_from_file_location('qa_http_app',resources/'app.py');app=importlib.util.module_from_spec(spec);spec.loader.exec_module(app)
 server=app.LocalServer(types.SimpleNamespace(public_state=lambda:copy.deepcopy(fixture),message_templates=lambda:{}));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 try:
  with sync_playwright() as pw:
   browser=pw.chromium.launch(channel='chrome',headless=True,chromium_sandbox=True)
   page=browser.new_page(viewport={'width':1600,'height':1200});errors=[];posts=[];responses={}
   page.on('pageerror',lambda e:errors.append(str(e)))
   page.on('response',lambda r:responses.update({r.url.removeprefix(server.origin):r.status}))
   page.on('request',lambda r:posts.append(r.url) if r.method=='POST' else None)
   page.route('**/*',lambda r:r.continue_() if r.request.url.startswith(server.origin+'/') else r.abort())
   page.goto(server.origin+'/#'+server.token);page.wait_for_selector('#rows tr');page.wait_for_timeout(200)
   check('initial render without errors',not errors)
   for src in page.locator('script[src]').evaluate_all('es=>es.map(e=>e.getAttribute("src"))'):check('HTTP asset '+src,responses.get('/'+src)==200)
   qa=ROOT/'docs/qa';qa.mkdir(exist_ok=True)
   page.locator('.cards').screenshot(path=str(qa/'dashboard_groups.png'))
   check('action queue starts with notice needed',page.locator('.dashboard-action .card').first.get_attribute('data-color')=='notice_needed')
   check('no standalone undated card',page.locator('.cards [data-color="dispatch_undated"]').count()==0)
   check('no old overdue tile',page.locator('.cards [data-color="red"]').count()==0)
   page.locator('[data-color="notice_needed"]').click()
   keys=lambda:page.locator('#rows .rowcheck').evaluate_all('es=>es.map(e=>e.dataset.key)')
   check('resend only overdue and confirmed',set(keys())=={'a','c'})
   check('parent active',page.locator('[data-color="notice_needed"]').get_attribute('aria-pressed')=='true')
   page.locator('#sectionGroupPanel').screenshot(path=str(qa/'notice_needed.png'))
   page.locator('[data-section="notice_undated_new"]').click();check('same order sibling removed from unknown','b' not in keys() and 'a' not in keys() and 'c' not in keys() and 'd' in keys())
   check('three notice subfilters',page.locator('#sectionGroupChoices [data-section]').count()==3)
   check('new unknown excludes history product','e' not in keys() and 'd' in keys())
   check('unnotified tab keeps original blue',page.locator('[data-section="notice_undated_new"]').evaluate('e=>getComputedStyle(e).backgroundColor')=='rgb(233, 243, 254)')
   page.locator('[data-section="notice_undated_seen"]').click();check('history subset only notified product',keys()==['e'])
   check('notified tab pink',page.locator('[data-section="notice_undated_seen"]').evaluate('e=>getComputedStyle(e).backgroundColor')=='rgb(255, 224, 237)')
   check('history panel pink',page.locator('#sectionGroupPanel').evaluate('e=>getComputedStyle(e).backgroundColor')=='rgb(255, 248, 251)')
   page.locator('#sectionGroupPanel').screenshot(path=str(qa/'notice_history_split.png'))
   page.locator('[data-section="notice_resend"]').click();check('resend tab pink',page.locator('[data-section="notice_resend"]').evaluate('e=>getComputedStyle(e).backgroundColor')=='rgb(255, 224, 237)')
   page.locator('[data-section="notice_undated_new"]').click();check('unnotified panel original color',not page.locator('#sectionGroupPanel').evaluate('e=>e.classList.contains("notice-pink-panel")'))
   page.locator('#rows .rowcheck[data-key="d"]').check();fixture['rows'][3]['delayNoticeCount']=1
   page.evaluate('()=>refresh()');check('refresh moves newly notified item out of new list','d' not in keys());check('hidden selection cleared','d' not in page.evaluate('[...selected]'))
   page.locator('[data-section="notice_undated_seen"]').click();check('newly notified row in history tab',set(keys())=={'d','e'})
   fixture['rows'][3]['delayNoticeCount']=0;page.evaluate('()=>refresh()');page.locator('[data-section="notice_undated_new"]').click()
   page.locator('#search').fill('가상 상품 b');check('search cannot move duplicate sibling',not keys())
   page.locator('#search').fill('');page.locator('#resetBtn').click()
   # Each sortable header toggles the actual select and list, with all option IDs present.
   columns=page.evaluate('sortColumns')
   for id,label,asc,desc in columns:
    page.locator('#'+id).click();check(label+' ascending click',page.locator('#sortOrder').input_value()==asc)
    page.locator('#'+id).click();check(label+' descending click',page.locator('#sortOrder').input_value()==desc)
   page.locator('#sortOrder').select_option('qty_asc');check('quantity numeric',keys().index('e')<keys().index('a'))
   page.locator('#sortOrder').select_option('matching_asc');check('manual connections before automatic',keys().index('s')<keys().index('t'))
   page.locator('#sortOrder').select_option('product_asc');page.locator('#clearBtn').click();boxes=page.locator('#rows .rowcheck');current=keys()
   boxes.nth(0).click();boxes.nth(4).click(modifiers=['Shift']);check('shift forward range checked',page.locator('#rows .rowcheck:checked').count()==5)
   boxes.nth(4).click(modifiers=['Shift']);check('shift clears range',page.locator('#rows .rowcheck:checked').count()==0)
   page.locator('#clearBtn').click();boxes.nth(5).click();boxes.nth(2).click(modifiers=['Shift']);check('shift reverse range checked',page.locator('#rows .rowcheck:checked').count()==4)
   page.locator('#sortOrder').select_option('qty_desc');page.locator('#rows .rowcheck:not(:checked)').first.click(modifiers=['Shift']);check('sort resets range anchor',page.locator('#rows .rowcheck:checked').count()==5)
   page.locator('#clearBtn').click();page.locator('#search').fill('ORDER');page.locator('#rows .rowcheck').first.click();page.locator('#rows .rowcheck').last.click(modifiers=['Shift']);check('filtered range only',set(page.evaluate('[...selected]'))==set(keys()))
   page.locator('#clearBtn').click();page.locator('#search').fill('');page.locator('#activeFilter').select_option('all');page.locator('#sortOrder').select_option('product_asc');page.locator('#rows .rowcheck').first.click();page.locator('#rows .rowcheck').last.click(modifiers=['Shift']);check('disabled row skipped','o' not in page.evaluate('[...selected]'))
   page.locator('#resetBtn').click()
   if personal:
    check('eleven cards in PDF layout',page.locator('.cards .card').count()==11)
    check('three summary cards',page.locator('.dashboard-summary .card').count()==3)
    check('green ready bar shows both singles and bundle',page.locator('.dashboard-ready [data-color="ready_all"]').count()==1)
    page.locator('[data-color="ready_all"]').click();check('ready union includes full bundle and singles',set(keys())=={'f','j','p'})
    for group,children in [('group_exchange',['exchange_ready','exchange_blocked']),('group_soldout',['charcoal','soldout_check']),('group_bundle',['ready_bundle','scheduled_bundle','bundle_confirmed','bundle_planned','bundle_unconfirmed'])]:
     page.locator('[data-color="'+group+'"]').click()
     for child in children:
      page.locator('[data-section="'+child+'"]').click();check('child '+child+' accessible',page.locator('#statusFilter').input_value()==child and len(keys())>0)
    page.locator('[data-section="scheduled_bundle"]').click();page.locator('#sectionGroupPanel').screenshot(path=str(qa/'bundle_sections.png'));check('nested bundle date panel',page.locator('#bundleDispatchPanel').is_visible());page.locator('[data-bundle-range="2026-10-21|2026-10-22"]').click();check('bundle date product filter retained',keys()==['k'])
    page.locator('[data-color="group_soldout"]').click();page.locator('[data-section="soldout_check"]').click();page.locator('[data-oos="hidden"]').click();check('hidden soldout tab retained',keys()==['q'])
    page.locator('#resetBtn').click();page.set_viewport_size({'width':800,'height':1000});page.locator('.cards').screenshot(path=str(qa/'dashboard_compact.png'));check('narrow card grid fits viewport',page.locator('.cards').bounding_box()['width']<=800)
   else:
    check('nine distribution cards',page.locator('.cards .card').count()==9)
    check('two top summary cards',page.locator('.dashboard-summary .card').count()==2)
    check('no distribution ready bar',page.locator('.dashboard-ready').count()==0)
    page.locator('#resetBtn').click()
    check('duplicate order rows have bold bundle prefix',page.locator('tr:has([data-key="a"]) .bundle-label').text_content()=='(합포)' and page.locator('tr:has([data-key="b"]) .bundle-label').text_content()=='(합포)')
    check('single order has no bundle prefix',page.locator('tr:has([data-key="d"]) .bundle-label').count()==0)
   page.set_viewport_size({'width':1500,'height':1100});page.locator('#resetBtn').click()
   check('summary descriptions populated',all(page.locator('#'+id).text_content() for id in ['whiteSummary','noticeSummary','dispatchSummary','exchangeSummary']))
   check('planned dates and waiting visible','10월 21일 ~ 10월 22일 1건' in page.locator('#dispatchSummary').text_content() and '계산 대기 0건' in page.locator('#dispatchSummary').text_content())
   page.locator('#rows .rowcheck[data-key="d"]').check();check('selection count appears',page.locator('#selectionFloating').is_visible() and page.locator('#selectionFloatingCount').text_content()=='1개 선택됨')
   page.locator('#rows .rowcheck[data-key="e"]').check();check('selection count updates',page.locator('#selectionFloatingCount').text_content()=='2개 선택됨')
   page.locator('#noSendBtn').click();check('manual date label updated',page.locator('#noSendDue').locator('..').text_content()=='안내할 출고 예정일')
   page.locator('#noSendDialog').screenshot(path=str(qa/'manual_date_dialog.png'));page.locator('[data-close="noSendDialog"]').click()
   page.locator('#clearBtn').click();check('selection count hides after clear',not page.locator('#selectionFloating').is_visible())
   check('compact distribution dashboard under 570px',page.locator('.cards').bounding_box()['height']<570)
   page.locator('.cards').screenshot(path=str(qa/'pdf_dashboard.png'))
   page.set_viewport_size({'width':780,'height':1000});page.locator('.cards').screenshot(path=str(qa/'pdf_dashboard_narrow.png'))
   check('narrow view has no card overflow',page.locator('.cards .card').evaluate_all('es=>es.every(e=>e.getBoundingClientRect().right<=innerWidth && e.scrollWidth<=e.clientWidth+1)'))
   page.set_viewport_size({'width':1500,'height':1100})
   # Capture the actual form request; no production APIs or send providers.
   manual_payloads=[]
   def manual_request(route):
    payload=route.request.post_data_json;manual_payloads.append(payload)
    for r in fixture['rows']:
     if r['key'] in payload['keys']:r.update(dueDate=payload['dueDate'],noticeCount=r['noticeCount']+1,delayNoticeCount=r['delayNoticeCount']+1,externalNoticeCount=r['externalNoticeCount']+1)
    route.fulfill(status=200,content_type='application/json',body=json.dumps({'message':'가상 안내 처리 완료'}))
   page.route(server.origin+'/api/external-manual',manual_request)
   for step in [1,2]:
    page.locator('#rows .rowcheck[data-key="d"]').check();page.locator('#noSendBtn').click()
    page.locator('#noSendDue').fill('2026-10-30');page.locator('#noSendApply').click();page.wait_for_function('()=>!document.getElementById("noSendDialog").open')
    page.wait_for_function('()=>state.rows.find(r=>r.key==="d").noticeCount==='+str(step))
    check('manual form request mode '+str(step),manual_payloads[-1]['mode']=='set_due_date' and manual_payloads[-1]['keys']==['d'] and len(manual_payloads[-1]['requestId'])>=16)
    check('notice count displayed '+str(step),str(step)+'회 안내완료' in page.locator('tr:has(.rowcheck[data-key="d"])').text_content())
   check('distinct intended actions have distinct IDs',manual_payloads[0]['requestId']!=manual_payloads[1]['requestId'])
   # Read-only list interactions must never change an order, start a browser, or send.
   check('only two manual form requests',posts==[server.origin+'/api/external-manual']*2);check('API requests succeeded',all(status==200 for path,status in responses.items() if path.startswith('/api/')));check('no JavaScript errors',not errors)
   browser.close()
 finally:server.shutdown();server.server_close();thread.join()
print(json.dumps({'edition':ROOT.name,'passed':len(checks),'checks':checks,'live_messages':0},ensure_ascii=False,indent=2))
