# NUAVU_Delay_v0.6.57_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v0656.md

## 전체 초기화 실패 원인 표시 (배포판, 10-20 10:23 보고)
- Windows 첫 실행에서 "초기화를 완료하지 못했습니다 … 폴더 권한을 확인하고" 가 떴는데 원인이 가려져 있었습니다. 이제 오류 종류·내용을 메시지 끝에 붙이고 desktop.log에 전체 추적을 남깁니다.
