"""Build a temporary bundle and load its actual HTTP resources in Chrome.

Uses synthetic UI data and a fake desktop bridge. No operational DB, worker,
Keychain, external login or message sending. With --baseline, demonstrate .38.
"""
from pathlib import Path
import copy,importlib.util,json,sys,tempfile,threading,types

ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
BASELINE='--baseline' in sys.argv
sys.path.insert(0,str(ROOT))
from install_desktop import build_bundle
from playwright.sync_api import sync_playwright

sys.path.insert(0,str(ROOT/'tests'))
from helpers import FakeSMS,FakeAT,MemoryVault
from domain import Store,Engine
from test_supply_regression import order
fixture=None

checks=[]
def check(name,value):
    assert value,name
    checks.append(name)

with tempfile.TemporaryDirectory() as tmp:
    bundle=build_bundle(Path(tmp)/'HTTP test.app',Path(sys.executable).resolve())
    resources=(bundle/'Contents/Resources').resolve()
    spec=importlib.util.spec_from_file_location('bundle_http_app',resources/'app.py')
    app=importlib.util.module_from_spec(spec);spec.loader.exec_module(app)
    store=Store(Path(tmp)/'isolated-data')
    engine=Engine(store,FakeSMS(),MemoryVault(),aligo_provider=FakeAT(),aligo_vault=MemoryVault())
    engine.configure_shop({'shopName':'데모스토어'})
    engine.import_rows({'rows':[order(1)|{'orderItemId':'801'}]})
    server=app.LocalServer(engine);server.desktop=True
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        with sync_playwright() as pw:
            browser=pw.chromium.launch(channel='chrome',headless=True,chromium_sandbox=True)
            try:
                page=browser.new_page(viewport={'width':1440,'height':1100})
                page.route('**/*',lambda r:r.continue_() if r.request.url.startswith(server.origin+'/') else r.abort())
                errors=[];responses={};posts=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.on('response',lambda r:responses.update({r.url.removeprefix(server.origin):r.status}))
                page.on('request',lambda r:posts.append(r.url) if r.method=='POST' else None)
                page.add_init_script("""window.bridgeCalls=[];window.testJob={phase:'idle',running:false,message:'가상 동기화 준비'};
                window.pywebview={api:{ably_sync_action:async(t,a,u,p)=>{
                  bridgeCalls.push(a);
                  if(a==='settings')return {available:true,username:'',hasPassword:false};
                  if(a==='start')testJob={phase:'running',running:true,message:'가상 페이지 확인 중'};
                  if(a==='cancel')testJob={phase:'cancelled',running:false,message:'가상 동기화 중단'};
                  return testJob;
                },
                order_auto_status:async()=>({phase:'idle',running:false,message:'준비됨',settings:{folder:'',group:'데모스토어'}}),
                ezadmin_login_settings:async()=>({available:true,domain:'',username:'',hasPassword:false}),
                pick_orders:async()=>null}};""")
                main=page.goto(server.url,wait_until='networkidle')
                page.wait_for_function('state !== null')
                check('served from packaged app over real HTTP',main.status==200 and app.ROOT==resources)
                check('production CSP retained',"script-src 'self'" in main.headers['content-security-policy'])
                if BASELINE:
                    check('baseline Ably script returns 404',responses.get('/ably_ui.js')==404)
                    for ident in ['ablySettingsBtn','historySeedBtn']:
                        page.locator('#'+ident).click()
                        check('baseline inert button '+ident,page.locator('#ablySettingsDialog, #ablySyncDialog').count()==0)
                    check('baseline no bridge calls',page.evaluate('bridgeCalls.length')==0)
                else:
                    check('Ably script delivered',responses.get('/ably_ui.js')==200)
                    for name in page.locator('script[src]').evaluate_all('els=>els.map(e=>e.getAttribute("src"))'):
                        check('script delivered '+name,responses.get('/'+name)==200)
                    check('no automatic sync or credential access',page.evaluate('bridgeCalls.length')==0)
                    page.locator('#ablySettingsBtn').click()
                    check('settings opens',page.locator('#ablySettingsDialog').evaluate('e=>e.open'))
                    page.wait_for_function('bridgeCalls.includes("settings")')
                    check('settings uses desktop bridge',page.evaluate('bridgeCalls.includes("settings")'))
                    check('password input is masked',page.locator('#ablyPassword').get_attribute('type')=='password')
                    check('password starts empty',page.locator('#ablyPassword').input_value()=='')
                    qa=ROOT/'docs/qa';qa.mkdir(exist_ok=True)
                    page.locator('#ablySettingsDialog').screenshot(path=str(qa/'v0629_http_settings.png'))
                    page.locator('[data-ably-close="ablySettingsDialog"]').click()
                    page.locator('#historySeedBtn').click()
                    check('sync opens',page.locator('#ablySyncDialog').evaluate('e=>e.open'))
                    page.wait_for_function('bridgeCalls.includes("status")')
                    check('sync uses desktop bridge',page.evaluate('bridgeCalls.includes("status")'))
                    check('reuse policy present','한 번 확인한 상품주문번호' in page.locator('#ablySyncDialog').inner_text())
                    page.locator('#ablySyncDialog').screenshot(path=str(qa/'v0629_http_sync.png'))
                    page.locator('#ablySyncStart').click()
                    check('start connected and duplicate start disabled',page.locator('#ablySyncStart').is_disabled())
                    page.locator('#ablySyncCancel').click()
                    check('cancel connected',page.evaluate('bridgeCalls.includes("cancel")'))
                    page.locator('#ablyLegacyImport').click()
                    check('legacy import opens',page.locator('#externalDialog').evaluate('e=>e.open'))
                    page.locator('[data-close=externalDialog]').click()
                    page.locator('#importBtn').click()
                    check('manual/automatic selector opens',page.locator('#orderImportChoice').evaluate('e=>e.open'))
                    check('manual available',page.locator('#manualOrderImport').is_visible())
                    check('automatic available',page.locator('#autoOrderImport').is_visible())
                    check('shop group default',page.locator('#orderAutoGroup').input_value()=='데모스토어')
                    page.locator('#orderImportChoice').screenshot(path=str(qa/'v0629_order_import.png'))
                    page.locator('#manualOrderImport').click()
                    page.locator('#ezadminSettingsBtn').click()
                    check('ezadmin settings opens',page.locator('#ezadminSettingsDialog').evaluate('e=>e.open'))
                    check('ezadmin password masked',page.locator('#ezadminPassword').get_attribute('type')=='password')
                    check('ezadmin password empty',page.locator('#ezadminPassword').input_value()=='')
                    page.locator('#ezadminSettingsDialog').screenshot(path=str(qa/'v0629_ezadmin_settings.png'))
                    page.locator('[data-close=ezadminSettingsDialog]').click()
                    page.screenshot(path=str(qa/'v0629_dashboard.png'),full_page=True)
                    check('no JavaScript errors',not errors)

                check('no HTTP mutations',not posts)
            finally:browser.close()
    finally:server.shutdown();server.server_close();thread.join();store.close()
print(json.dumps({'source':ROOT.name,'baseline':BASELINE,'checks':checks,'passed':len(checks)},ensure_ascii=False,indent=2))
