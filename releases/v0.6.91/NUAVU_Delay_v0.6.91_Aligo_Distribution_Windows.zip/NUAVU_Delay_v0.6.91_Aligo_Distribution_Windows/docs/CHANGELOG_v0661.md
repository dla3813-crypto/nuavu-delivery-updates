# NUAVU_Delay_v0.6.61_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v0660.md
