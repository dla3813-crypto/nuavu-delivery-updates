"""Run the production UI driver against an isolated synthetic EzAdmin site.
All requests are intercepted; no customer service or live website connection.
"""
from pathlib import Path
import sys,tempfile,json,time
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
BASELINE='--baseline' in sys.argv
sys.path.insert(0,str(ROOT))
from playwright.sync_api import sync_playwright
from order_browser import Flow,LOGIN_URL
SEARCH_URL='https://ga79.ezadmin.co.kr/template35.htm?template=DS00'
DOWNLOAD_URL='https://ga79.ezadmin.co.kr/template40.htm?template=BL30'
from order_auto import KST, OrderAutoError, Cancelled
from datetime import datetime
from urllib.parse import quote
stamp=datetime.now(KST);name='확장주문검색_'+stamp.strftime('%Y%m%d%H%M%S')+'_987.xls'
record={'submitted':False,'requests':[],'phases':[]}
def select(id,options,name_attr=''):
 return f'<select id="{id}" name="{name_attr}">'+''.join(f'<option value="{v}">{t}</option>' for v,t in options)+'</select>'
search=''.join([select('date_type',[(0,'발주일')],'date_type'),select('date_period_sel',[(0,'오늘'),(8,'최근한달')]),select('status_sel',[(0,'전체'),(5,'접수+송장')],'status_sel'),select('order_cs_sel',[(0,'전체'),(1,'정상')],'order_cs_sel'),'<input id="is_packed" type="checkbox"><span onclick="javascript:openWinShopDetail()">상세선택</span>',select('str_shop_code',[(0,'전체')]),'<button id="search" onclick="document.querySelector(\'#grid1\').innerHTML=\'<tr class=jqgrow><td>synthetic</td></tr>\'">검색(F2)</button><table id="grid1"></table><div id="gridpager">표시할 행이 없습니다</div><div id="load_grid1" hidden></div>',select('download_type',[(0,'상품단위')]),select('download_field',[(0,'배송지연 전체품목')]),'<input id="include_sum" type="checkbox"><button id="download" onclick="show(1)">다운로드(F6)</button><div id="dialog" role="dialog"></div>', '''<script>
function openWinShopDetail(){window.open('/popup35.htm?template=C120','group')}
function show(n){const d=document.querySelector('#dialog');if(n===1)d.innerHTML='<h2>다운로드 변경 안내</h2><button onclick="show(2)">다운로드 신청</button>';if(n===2)d.innerHTML='<h2>개인정보 파기 안내</h2><button onclick="show(3)">확인</button>';if(n===3)d.innerHTML='<h2>다운로드 안내</h2><input id="swal2-input" oninput="window.ackKeys=(window.ackKeys||0)+1"><button onclick="submitExport()">확인</button>';}
async function submitExport(){if(document.querySelector('#swal2-input').value!=='확인했습니다')throw Error('bad acknowledgement');const fields=['#date_period_sel','#status_sel','#order_cs_sel','#str_shop_code'];if(fields.map(s=>document.querySelector(s).value).join(',')!=='8,5,1,group')throw Error('wrong query');await fetch('/mock-submit',{method:'POST',body:JSON.stringify({value:document.querySelector('#swal2-input').value,keys:window.ackKeys||0})});document.querySelector('#dialog').innerHTML='<p>요청하신 다운로드 작업이 접수되었습니다.</p>';}
</script>'''])
text_search=search
image_dialogs = r'''<style>
#pop_download_info,#pop_personal_information,#pop_download_complete {width:500px;height:330px;position:fixed;left:10px;top:10px;background-size:contain}
#btn_download_info1,.btn_cnf,#btn_download_complete1 {position:absolute;left:30px;top:270px;width:170px;height:45px}
#btn_download_info2,#btn_download_complete2 {position:absolute;left:230px;top:270px;width:170px;height:45px}
</style>
<div id="pop_download_info" style="display:none;background-image:url('https://ga79.ezadmin.co.kr/images/download_info_request.png?v=synthetic')"><div id="btn_download_close"></div><div id="btn_download_info1" onclick="show(2)"></div><div id="btn_download_info2"></div></div>
<div id="pop_personal_information" style="display:none;background-image:url('https://ga79.ezadmin.co.kr/images/personal_infomation_popup.png?v=synthetic')"><div class="btn_cnf" onclick="show(3)"></div></div>
<div id="pop_download_complete" style="display:none;background-image:url('https://ga79.ezadmin.co.kr/images/download_info_complete.png?v=synthetic')"><div id="btn_download_close"></div><div id="btn_download_complete1"></div><div id="btn_download_complete2"></div></div>
<script>
function show(n){
 for(const id of ['pop_download_info','pop_personal_information','pop_download_complete'])document.getElementById(id).style.display='none';
 const d=document.getElementById('dialog'); d.innerHTML='';
 if(n===1){document.getElementById('pop_download_info').style.display='block';}
 if(n===2){document.getElementById('pop_personal_information').style.display='block';}
 if(n===3){d.innerHTML='<h2>다운로드 안내</h2><input id="swal2-input" oninput="window.ackKeys=(window.ackKeys||0)+1"><button onclick="submitExport()">확인</button>';}
}
async function submitExport(){
 if(document.getElementById('swal2-input').value!=='확인했습니다')throw Error('bad acknowledgement');
 const fields=['#date_period_sel','#status_sel','#order_cs_sel','#str_shop_code'];
 if(fields.map(s=>document.querySelector(s).value).join(',')!=='8,5,1,group')throw Error('wrong query');
 await fetch('/mock-submit',{method:'POST',body:JSON.stringify({value:document.getElementById('swal2-input').value,keys:window.ackKeys||0})});
 document.getElementById('dialog').innerHTML='';
 document.getElementById('pop_download_complete').style.display='block';
}
</script>'''
search += image_dialogs
group='''<ul><li><input class="chk_group" type="checkbox" checked>다른 그룹</li><li><input class="chk_group" type="checkbox">데모스토어</li></ul><span onclick="javascript:set_shop_group()">선택 그룹 바로 설정</span><script>function set_shop_group(){if(document.querySelectorAll('input:checked').length!==1||!document.querySelectorAll('input')[1].checked)throw Error('bad group');opener.document.querySelector('#str_shop_code').innerHTML='<option value="group">상세선택</option>';window.close();}</script>'''

AUTH='<a href="/logout.php" aria-label="로그아웃">로그아웃</a>'
FAKE={'domain':'synthetic-shop','username':'synthetic-user','password':'FAKE-ONLY-0623'}
LOGIN='''<form id="loginForm"><input id="login-domain"><input id="login-id"><input id="login-pwd" type="password"><input id="savedomain" type="checkbox" checked><button type="button" onclick="go()">로그인</button></form><script>async function go(){const v={domain:document.querySelector('#login-domain').value,username:document.querySelector('#login-id').value,password:document.querySelector('#login-pwd').value,save:document.querySelector('#savedomain').checked};const r=await(await fetch('/test-auth',{method:'POST',body:JSON.stringify(v)})).json();if(r.fail){alert('아이디 비밀번호 확인');return;}if(r.kind==='technical'){alert('인증 서버 연결 오류');return;}if(r.kind==='security'){alert('reCAPTCHA 오류');return;}if(r.kind==='info-continue')alert('비밀번호 변경 기간 안내');if(r.kind.startsWith('confirm')&&!confirm('이미 접속 중입니다. 다른 접속을 종료하고 로그인하시겠습니까?'))return;location.href='https://ga79.ezadmin.co.kr/index.htm';}</script>'''
class Controller:
 def check(self):
  if record.get('cancelled'):raise Cancelled('cancelled synthetic test')
 def ask_login_confirmation(self,text):
  assert '다른 접속' in text;record['confirmations']+=1;return record['case']=='confirm-yes'
 def update(self,phase,message):
  record['phases'].append(phase);print(record['case'],phase,flush=True)
  if phase=='waiting' and record['case']=='cancel-after-accept':record['cancelled']=True
class FastFailureFlow(Flow):
 def until(self,predicate,timeout,message):return super().until(predicate,min(timeout,3),message)
def route(r):
 global stamp,name
 url=r.request.url;record['requests'].append(url);print('mock route',url,flush=True)
 case=record['case']
 if '/images/' in url:return r.fulfill(body='<svg xmlns="http://www.w3.org/2000/svg" width="500" height="330"><rect width="500" height="330" fill="#eee"/></svg>',content_type='image/svg+xml')
 if '/test-auth' in url:
  payload=json.loads(r.request.post_data);assert payload==dict(FAKE,save=False)
  record['loginAttempts']+=1;record['loginAccepted']=case!='rejected'
  return r.fulfill(body=json.dumps({'fail':case=='rejected','kind':case}),content_type='application/json')
 if url==LOGIN_URL:
  if case=='existing-session':record['loginAccepted']=True;return r.fulfill(body="<script>location.replace('https://ga79.ezadmin.co.kr/index.htm')</script>",content_type='text/html')
  if case=='foreign-login':return r.fulfill(body="<script>location.replace('https://untrusted.invalid/login.htm')</script>",content_type='text/html')
  body=LOGIN
 elif 'untrusted.invalid' in url:body=LOGIN
 elif '/index.htm' in url:body='<p>로그인 진행</p>' if case=='no-proof' else AUTH
 elif '/mock-submit' in url:
  stamp=datetime.now(KST);name='확장주문검색_'+stamp.strftime('%Y%m%d%H%M%S')+'_987.xls'
  payload=json.loads(r.request.post_data);assert payload['value']=='확인했습니다' and payload['keys']>=6
  record['submitted']=True;record['submitted_at']=time.monotonic();return r.fulfill(body='OK')
 elif '/data/' in url:
  return r.fulfill(body='<table><tr><td>synthetic only</td></tr></table>',headers={'Content-Type':'application/vnd.ms-excel','Content-Disposition':"attachment; filename*=UTF-8''"+quote(name)})
 elif 'C120' in url:body=group.replace('window.close();','setTimeout(()=>window.close(),350);') if case=='async-popup-close' else group
 elif 'DS00' in url:
  assert record['loginAccepted'],'Order search before login'
  body='mysqli 데이터베이스에 연결할 수 없습니다.' if case=='mysqli' else ('' if case=='expired-session' else AUTH)+search
  if case=='text-variant':body=AUTH+text_search
  if case=='wrong-image':body=body.replace('/images/download_info_request.png','/images/unrelated.png')
  if case=='missing-privacy':body=body.replace("onclick=\"show(2)\"","onclick=\"show(99)\"")
  if case=='hidden-receipt':body=body.replace("document.getElementById('pop_download_complete').style.display='block';","document.getElementById('pop_download_complete').style.display='none';")
  if case=='stale-receipt':body=body.replace("if(n===1){document.getElementById('pop_download_info').style.display='block';}","if(n===1){document.getElementById('pop_download_info').style.display='block';document.getElementById('pop_download_complete').style.display='block';}")
  if case=='unrelated-confirm':body='<button onclick="fetch(&quot;/wrong-confirm&quot;)">확인</button>'+body
  if case=='delayed-privacy':body=body.replace("onclick=\"show(2)\"","onclick=\"setTimeout(()=>show(2),500)\"")
  if case=='missing-input':body=body.replace('id="swal2-input"','id="absent-input"')
  if case=='tampered-input':body=body.replace('id="swal2-input"','id="swal2-input" onblur="this.value=String()"')
  if case=='missing-receipt':body=body.replace('/images/download_info_complete.png','/images/unknown_receipt.png')
 elif 'BL30' in url:
  assert record['submitted'], 'BL30 opened before typing/confirmation'
  assert time.monotonic()-record['submitted_at']>=4.9, 'BL30 opened before five-second wait'
  assert case not in ['missing-receipt','cancel-after-accept']
  row=''
  if record['submitted']:
   cells={'crdate':stamp.strftime('%Y-%m-%d %H:%M:%S'),'template':'확장주문검색2','file_name':f'<a href="https://ga79.ezadmin.co.kr/data/test/{quote(name)}">{name}</a>','status':'완료','work_percent':'100%'}
   if case=='cross-server':cells['file_name']=cells['file_name'].replace('ga79.ezadmin.co.kr','ga90.ezadmin.co.kr')
   row='<tr class="jqgrow"><td><input class="del_worklist" value="777"></td>'+''.join(f'<td aria-describedby="grid1_{k}">{v}</td>' for k,v in cells.items())+'</tr>'
  if case=='ambiguous-job':row+=row.replace('value="777"','value="778"')
  body=AUTH+'<button id="search">검색</button><table id="grid1">'+row+'</table><div id="gridpager">표시할 행이 없습니다</div><div id="load_grid1" hidden></div>'
 else:return r.abort()
 r.fulfill(body='<!doctype html><meta charset="utf-8">'+body,content_type='text/html; charset=utf-8')
results=[]
with tempfile.TemporaryDirectory() as tmp, sync_playwright() as p:
 browser=p.chromium.launch(channel='chrome',headless=True,chromium_sandbox=True)
 try:
  for case in (['cross-server'] if BASELINE else ['cross-server','success','rejected','foreign-login','no-proof','mysqli','expired-session','existing-session','confirm-yes','confirm-no','technical','security','info-continue','login-only','async-popup-close','missing-input','tampered-input','missing-receipt','cancel-after-accept','ambiguous-job','text-variant','wrong-image','missing-privacy','hidden-receipt','stale-receipt','unrelated-confirm','delayed-privacy']):
   stamp=datetime.now(KST);name='확장주문검색_'+stamp.strftime('%Y%m%d%H%M%S')+'_987.xls'
   folder=Path(tmp)/case;folder.mkdir()
   record={'case':case,'submitted':False,'requests':[],'phases':[],'loginAttempts':0,'loginAccepted':False,'confirmations':0}
   context=browser.new_context(accept_downloads=True);context.route('**/*',route);context.new_page()
   try:
    if case=='login-only':
     assert Flow(Controller(),context).execute({'loginOnly':True},FAKE) is None
     assert SEARCH_URL not in record['requests'] and not record['submitted'] and len(context.pages)==1
    elif not BASELINE and case in ['cross-server','success','existing-session','confirm-yes','info-continue','async-popup-close','text-variant','unrelated-confirm','delayed-privacy']:
     n,data=Flow(Controller(),context).execute({'group':'데모스토어','folder':str(folder)},FAKE)
     assert n==name and b'synthetic only' in data
     assert (folder/name).read_bytes()==data
     assert 'search' in record['phases'] and record['phases'][-2:]==['waiting','downloading']
     assert record['loginAttempts']==(0 if case=='existing-session' else 1)
     assert len(context.pages)==2
    else:
     try:FastFailureFlow(Controller(),context).execute({'group':'데모스토어','folder':str(folder)},FAKE)
     except OrderAutoError as e:
      if BASELINE:assert '로그인한 서버와 다운로드 서버가 다릅니다' in str(e)
      assert FAKE['password'] not in str(e)
      if case=='technical':assert '인증 서버 연결 오류' in str(e) and '불일치' not in str(e)
      if case=='security':assert '보안 확인' in str(e) and '불일치' not in str(e)
     else:raise AssertionError('Failure accepted: '+case)
     assert not list(folder.iterdir())
     assert record['submitted']==(case in ['missing-receipt','cancel-after-accept','ambiguous-job','hidden-receipt','cross-server'])
     if case not in ['ambiguous-job','cross-server']:assert DOWNLOAD_URL not in record['requests']
     if case in ['rejected','foreign-login','no-proof','confirm-no','technical','security']:assert SEARCH_URL not in record['requests']
     assert record['loginAttempts']==(0 if case=='foreign-login' else 1)
     if case=='rejected':assert context.pages[0].locator('#login-pwd').input_value()==''
    if case.startswith('confirm'):assert record['confirmations']==1
    assert record['requests'][0]==LOGIN_URL
    assert not any('/wrong-confirm' in x for x in record['requests'])
    results.append({'case':case,'passed':True,'loginAttempts':record['loginAttempts'],'exportSubmitted':record['submitted'],'managerVisits':record['requests'].count(DOWNLOAD_URL)})
   finally:context.close()
 finally:browser.close()
Path(__file__).with_name(('v0631-cross-server-baseline.json' if BASELINE else 'v0632-ezadmin-flow.json')).write_text(json.dumps({'cases':results,'liveNetwork':False},indent=2))
print(json.dumps({'passed':len(results),'liveNetwork':False}))
