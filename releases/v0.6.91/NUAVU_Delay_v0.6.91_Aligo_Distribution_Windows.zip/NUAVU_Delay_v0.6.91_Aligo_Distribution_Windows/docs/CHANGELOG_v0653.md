# NUAVU_Delay_v0.6.53_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v0652.md

## Windows 설치: "Python을 찾지 못했습니다" (배포판, 10-20 09:56 보고)
- 원인: PowerShell 5.1은 네이티브 명령에 큰따옴표가 든 인수를 제대로 넘기지 못해, `python -c "…"` 검사 코드가 깨져 모든 후보가 실패로 보였습니다(설치는 정상이었음). 또 stderr 출력이 오류로 승격되는 설정이었습니다.
- 수정: 검사 코드를 임시 .py 파일(%TEMP%\nuavu-install\probe.py, check.py)로 실행하고, 후보별 결과(`py -3.13: 사용 → 경로` / `제외 (이유)`)를 화면에 표시합니다. 못 찾으면 `py --list` 출력을 함께 보여줍니다. 오류 승격을 끄고 종료 코드로만 판정합니다.
