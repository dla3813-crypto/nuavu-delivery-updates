# NUAVU_Delay_v0.6.63_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v0662.md

## 출고장·진행상황 반영 규칙 (공통, 10-20 23:56 요청)
- 파일명에 **`(NS 이미지)`** 또는 **`색칠`** 이 든 출고장/진행상황 파일은 작업용 사본으로 보고 **수집하지 않고 폴더 감시(변경 감지)에서도 뺍니다**. 전각 괄호 `（NS 이미지）`도 같게 봅니다. 테스트: tests/test_supply_skip_marks.py.
