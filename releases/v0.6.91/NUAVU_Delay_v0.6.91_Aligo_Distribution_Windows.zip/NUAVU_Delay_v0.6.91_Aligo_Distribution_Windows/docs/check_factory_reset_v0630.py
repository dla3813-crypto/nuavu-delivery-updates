"""Temporary packaged app + actual HTTP/desktop reset, synthetic records only.

The native window is a stand-in, all four Keychains are memory-only, and both
backup/data roots are temporary. No installed app, account or message is used.
"""
from pathlib import Path
import json,sys,tempfile,threading
from types import SimpleNamespace
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from install_desktop import build_bundle
from playwright.sync_api import sync_playwright
checks=[]
def check(name,yes):
    assert yes,name
    checks.append(name)

with tempfile.TemporaryDirectory() as tmp:
    tmp=Path(tmp)
    bundle=build_bundle(tmp/'Reset QA.app',Path(sys.executable).resolve())
    resources=(bundle/'Contents/Resources').resolve()
    sys.path[:0]=[str(resources),str(ROOT/'tests')]
    import app,desktop,factory_reset
    from domain import Store,Engine,FIRST
    from desktop_backup import DesktopBackup
    from helpers import Clock,FakeSMS,FakeAT,sample_rows
    from fake_security import MemoryVault
    check('reset module included in packaged app',Path(factory_reset.__file__).parent==resources)
    check('native module and HTTP resources from package',Path(desktop.__file__).parent==resources and app.ROOT==resources)
    with sync_playwright() as pw,patch('domain.datetime',Clock):
        browser=pw.chromium.launch(channel='chrome',headless=True,chromium_sandbox=True)
        try:
            for fail in (False,True):
                prefix='retry' if fail else 'success'
                data=tmp/prefix/'data';backup_root=tmp/prefix/'Desktop'/'backups'
                vaults=[MemoryVault() for _ in range(4)]
                sms=FakeSMS();at=FakeAT();store=Store(data)
                engine=Engine(store,sms,vaults[0],aligo_provider=at,aligo_vault=vaults[1])
                engine.configure_shop({'shopName':'데모스토어'})
                engine.configure({'user':'DEMO','apikey':'FAKE-ONLY','sender':'0212345678'})
                engine.import_rows({'rows':sample_rows(),'mode':'merge'})
                plan=engine.preview({'keys':[r['key'] for r in store.read()['rows'][:2]],'sendMode':'MORNING','dueDate':'2026-10-21','template':FIRST,'kind':'LMS','title':'테스트','templateKey':'first'})
                engine.commit({'token':plan['token']})
                for v in vaults[1:]:v.save({'fake':'ONLY'})
                archive=DesktopBackup(store,backup_root);engine.archive=archive;archive.run(force=True)
                keeps=[data/'runtime-keep'/'sentinel',tmp/prefix/'original.xlsx',tmp/prefix/'manual-export.xlsx',backup_root/'이맥백업-ffffffffffffffff'/'일별-2026-10-18.sqlite3']
                for f in keeps:f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b'KEEP')
                before=store.read()
                server=app.LocalServer(engine);server.desktop=True
                worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
                window=SimpleNamespace(get_current_url=lambda:server.url,confirm_close=True,destroy=lambda:setattr(window,'closed',True),closed=False)
                bridge=desktop.DesktopAPI(engine,server.token,server.origin,SimpleNamespace())
                bridge._window=window
                bridge._factory_reset=factory_reset.FactoryReset(engine,vaults=vaults,backup_root=backup_root)
                page=browser.new_page(viewport={'width':1440,'height':1100},locale='ko-KR')
                page.set_default_timeout(10000);errors=[];external=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                def route(r):
                    if r.request.url.startswith(server.origin+'/'):r.continue_()
                    else:external.append(r.request.url);r.abort()
                page.route('**/*',route)
                allowed={'factory_reset_preview','factory_reset','factory_reset_close'}
                def native(_source,name,args):
                    assert name in allowed
                    return getattr(bridge,name)(*args)
                page.expose_binding('__resetNative',native)
                page.add_init_script("""window.pywebview={api:{}};
                for(const n of ['factory_reset_preview','factory_reset','factory_reset_close'])
                    window.pywebview.api[n]=(...args)=>window.__resetNative(n,args);""")
                try:
                    response=page.goto(server.url,wait_until='networkidle')
                    page.wait_for_function('state!==null')
                    check(prefix+' production CSP',response.status==200 and "script-src 'self'" in response.headers['content-security-policy'])
                    check(prefix+' existing records visible',page.locator('#totalCount').inner_text()=='3')
                    page.locator('#shopSettingsBtn').click()
                    check(prefix+' settings entry visible',page.locator('#factoryResetOpen').is_visible())
                    page.locator('#factoryResetOpen').click()
                    page.wait_for_function('factoryResetReady')
                    check(prefix+' preview count','주문상품 3개 · 안내/발송 이력 1개 · 예약/대기 1개' in page.locator('#factoryResetCounts').inner_text())
                    check(prefix+' preview does not delete',store.read()==before and all(v.load() for v in vaults))
                    check(prefix+' empty confirmation disabled',page.locator('#factoryResetRun').is_disabled())
                    page.locator('#factoryResetPhrase').fill('전체 초기화 ')
                    check(prefix+' imprecise confirmation disabled',page.locator('#factoryResetRun').is_disabled())
                    page.locator('#factoryResetCancel').click()
                    check(prefix+' cancel leaves records',store.read()==before and not page.locator('#factoryResetDialog').evaluate('e=>e.open'))
                    page.locator('#shopSettingsBtn').click();page.locator('#factoryResetOpen').click()
                    page.wait_for_function('factoryResetReady')
                    page.locator('#factoryResetPhrase').fill('전체 초기화')
                    check(prefix+' exact confirmation enabled',page.locator('#factoryResetRun').is_enabled())
                    qa=ROOT/'docs/qa';qa.mkdir(exist_ok=True)
                    if not fail:page.locator('#factoryResetDialog').screenshot(path=str(qa/'v0630_reset_confirmation.png'))
                    # Simulate a state fetch already in flight at reset start.
                    page.evaluate("""() => {
                      window.beforeResetState=state;window.realApi=api;
                      api=(path,data)=>path==='state'?new Promise(resolve=>window.lateRefresh=resolve):realApi(path,data);
                      toast('기존 알림');refresh();
                    }""")
                    if fail:vaults[2].fail_delete=True
                    page.locator('#factoryResetRun').click()
                    if fail:
                        page.wait_for_function("document.getElementById('factoryResetRun').textContent==='초기화 다시 시도'&&!factoryResetBusy")
                        check('failure does not claim completion',not page.locator('#factoryResetClose').is_visible())
                        check('failure keeps pending marker and DB',(data/factory_reset.MARKER).exists() and store.path.exists())
                        check('failure blocks operations',page.request.get(server.origin+'/api/state',headers={'X-NUAVU-Token':server.token}).status==503)
                        page.keyboard.press('Escape')
                        check('failure cannot dismiss reset',page.locator('#factoryResetDialog').evaluate('e=>e.open'))
                        vaults[2].fail_delete=False
                        page.locator('#factoryResetRun').click()
                    page.wait_for_function('factoryResetDone')
                    page.evaluate("() => {lateRefresh({rows:[]});toast('늦은 알림');}")
                    page.wait_for_timeout(700)
                    check(prefix+' late refresh does not restore application',page.evaluate('state===beforeResetState') and not page.locator('main').is_visible())
                    check(prefix+' only completion is accessible',page.locator('#factoryResetClose').is_visible() and page.locator('main').evaluate('e=>e.inert'))
                    check(prefix+' completion count zero','주문상품 0개 · 안내/발송 이력 0개' in page.locator('#factoryResetCounts').inner_text())
                    check(prefix+' database and own backups deleted',not store.path.exists() and not archive.folder.exists() and not (data/'backups').exists())
                    check(prefix+' all four saved accounts cleared',all(v.load() is None for v in vaults))
                    check(prefix+' pending marker removed last',not (data/factory_reset.MARKER).exists())
                    check(prefix+' originals runtime and other device preserved',all(f.read_bytes()==b'KEEP' for f in keeps))
                    check(prefix+' state API blocked after close',page.request.get(server.origin+'/api/state',headers={'X-NUAVU-Token':server.token}).status==503)
                    check(prefix+' mutations blocked after close',page.request.post(server.origin+'/api/shop',data={'shopName':'새 이름'},headers={'X-NUAVU-Token':server.token,'Origin':server.origin}).status==503)
                    check(prefix+' native imports blocked','error' in bridge.pick_orders(server.token))
                    check(prefix+' no messages or external sites',not sms.sent and not at.sent and not external)
                    if not fail:page.locator('#factoryResetDialog').screenshot(path=str(qa/'v0630_reset_complete.png'))
                    page.locator('#factoryResetClose').click()
                    page.wait_for_timeout(50)
                    check(prefix+' close action reaches native window',window.closed and not window.confirm_close)
                    engine.stop_worker()
                    check(prefix+' shutdown does not recreate backup',not store.path.exists() and not archive.folder.exists())
                    fresh=Store(data)
                    try:
                        s=fresh.read()
                        check(prefix+' next launch starts empty',s['rows']==[] and s['notices']==[] and s['imports']==[] and s['settings']['shopName']=='')
                    finally:fresh.close()
                    check(prefix+' no JavaScript errors',not errors)
                finally:
                    page.close();server.shutdown();server.server_close();worker.join()
                    if not getattr(engine,'reset_store_closed',False):store.close()
        finally:browser.close()
print(json.dumps({'passed':len(checks),'checks':checks},ensure_ascii=False,indent=2))
