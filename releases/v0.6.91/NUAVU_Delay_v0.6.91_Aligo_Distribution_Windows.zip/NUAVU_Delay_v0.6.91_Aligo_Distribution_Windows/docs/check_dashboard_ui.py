"""Actual temporary app HTTP assets, synthetic state only; no sender or live site."""
from pathlib import Path
import copy,importlib.util,json,sys,tempfile,threading,types
ROOT=(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]).resolve();personal='_Distribution' not in ROOT.name
sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from install_desktop import build_bundle
from playwright.sync_api import sync_playwright
checks=[]
def check(name,ok):
 assert ok,name
 checks.append(name)
with tempfile.TemporaryDirectory() as tmp:
 if personal:fixture=json.loads((ROOT/'docs/V0638_ui_fixture.json').read_text())
 else:
  from domain import Store,Engine
  from helpers import FakeSMS,FakeAT,MemoryVault
  from test_supply_regression import order
  e=Engine(Store(Path(tmp)/'test-data'),FakeSMS(),MemoryVault(),aligo_provider=FakeAT(),aligo_vault=MemoryVault())
  e.configure_shop({'shopName':'테스트스토어'});e.import_rows({'rows':[order(1)]});fixture=e.public_state()
 sample=copy.deepcopy(fixture['rows'][0]);fixture['notices']=[];fixture['alerts']=[];fixture['imports']=[];fixture['desktopMode']=False;fixture['rows']=[]
 fixture['supply']['lastReadAt']='2026-10-18T01:00:00+09:00'
 def row(key,**extra):
  r=copy.deepcopy(sample);r.update(dict(key=key,orderId=key,seller='누아브 에이블리',sourceSeller='테스트스토어 에이블리',product='가상 상품 '+key,option='화이트 FREE',qty=1,buyer='가상고객 '+key,phone='01000000000',active=True,review=False,stockSecured=False,progressOfficeDates=[],manifestOfficeDates=[],dispatchStart='',dispatchEnd='',inventoryReady=False,isBundle=False,bundleReady=False,bundleScheduled=False,bundleType='',itemScheduleKnown=False,soldoutNotified=False,soldoutCheck=0,soldoutCheckHidden=False,delayRiskStage='',delayRisk={},bucket='unnotified',color='white',noticeCount=0,externalNoticeCount=0,appNoticeCount=0,externalHistory=False,orderDate='2026-10-01',dueDate='',lastNoticeAt='',supplyInfo={'matchNeeded':True,'reason':'가상 연결 필요'},manualMatchRecommended=False,manualMatchRecommendations=[]));r.update(extra);return r
 risk=dict(delayRiskStage='confirmed',delayRisk={'stage':'confirmed','shortQty':1})
 fixture['rows']=[row('a',orderId='ORDER1',bucket='overdue',color='red',dueDate='2026-10-15',qty=10),row('b',orderId='ORDER1'),row('c',orderId='ORDER2',**risk),row('d',orderId='ORDER3'),row('e',orderId='ORDER4',qty=2),row('f',orderId='C100',inventoryReady=True),row('g',orderId='C101'),row('h',bucket='soldout',soldoutNotified=True,color='charcoal'),row('i',soldoutCheck=1),row('j',isBundle=True,bundleReady=True,bundleType='ready',inventoryReady=True,stockSecured=True),row('k',isBundle=True,bundleScheduled=True,bundleType='unconfirmed',progressOfficeDates=['2026-10-16'],dispatchStart='2026-10-21',dispatchEnd='2026-10-22'),row('l',isBundle=True,bundleType='confirmed',stockSecured=True),row('m',isBundle=True,bundleType='planned',stockSecured=True),row('n',isBundle=True,bundleType='unconfirmed'),row('o',active=False),row('p',inventoryReady=True,stockSecured=True),row('q',soldoutCheckHidden=True,soldoutCheck=1),row('r',manualMatchRecommended=True,manualMatchRecommendations=[{'reason':'화이트와 아이보리'}],supplyInfo={'manualRecommended':True,'manualRecommendations':[{'reason':'화이트와 아이보리'}],'matchNeeded':True}),row('s',supplyInfo={'matchMethod':'manual','reason':'가상 수동 연결'}),row('t',supplyInfo={'matchMethod':'auto','reason':'가상 자동 연결'})]
 bundle=build_bundle(Path(tmp)/'UI check.app',Path(sys.executable).resolve());resources=bundle/'Contents/Resources'
 spec=importlib.util.spec_from_file_location('qa_http_app',resources/'app.py');app=importlib.util.module_from_spec(spec);spec.loader.exec_module(app)
 server=app.LocalServer(types.SimpleNamespace(public_state=lambda:copy.deepcopy(fixture),message_templates=lambda:{}));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 try:
  with sync_playwright() as pw:
   browser=pw.chromium.launch(channel='chrome',headless=True,chromium_sandbox=True)
   page=browser.new_page(viewport={'width':1600,'height':1200});errors=[];posts=[];responses={}
   page.on('pageerror',lambda e:errors.append(str(e)))
   page.on('response',lambda r:responses.update({r.url.removeprefix(server.origin):r.status}))
   page.on('request',lambda r:posts.append(r.url) if r.method=='POST' else None)
   page.route('**/*',lambda r:r.continue_() if r.request.url.startswith(server.origin+'/') else r.abort())
   page.goto(server.origin+'/#'+server.token);page.wait_for_selector('#rows tr');page.wait_for_timeout(200)
   check('initial render without errors',not errors)
   for src in page.locator('script[src]').evaluate_all('es=>es.map(e=>e.getAttribute("src"))'):check('HTTP asset '+src,responses.get('/'+src)==200)
   qa=ROOT/'docs/qa';qa.mkdir(exist_ok=True)
   page.locator('.cards').screenshot(path=str(qa/'dashboard_groups.png'))
   check('overdue replaced at fourth card',page.locator('.cards .card').nth(3).get_attribute('data-color')=='notice_needed')
   check('no old overdue tile',page.locator('.cards [data-color="red"]').count()==0)
   page.locator('[data-color="notice_needed"]').click()
   keys=lambda:page.locator('#rows .rowcheck').evaluate_all('es=>es.map(e=>e.dataset.key)')
   check('resend only overdue and confirmed',set(keys())=={'a','c'})
   check('parent active',page.locator('[data-color="notice_needed"]').get_attribute('aria-pressed')=='true')
   page.locator('#sectionGroupPanel').screenshot(path=str(qa/'notice_needed.png'))
   page.locator('[data-section="notice_undated"]').click();check('same order sibling removed from unknown','b' not in keys() and 'a' not in keys() and 'c' not in keys() and 'd' in keys())
   page.locator('#search').fill('가상 상품 b');check('search cannot move duplicate sibling',not keys())
   page.locator('#search').fill('');page.locator('#resetBtn').click()
   # Each sortable header toggles the actual select and list, with all option IDs present.
   columns=page.evaluate('sortColumns')
   for id,label,asc,desc in columns:
    page.locator('#'+id).click();check(label+' ascending click',page.locator('#sortOrder').input_value()==asc)
    page.locator('#'+id).click();check(label+' descending click',page.locator('#sortOrder').input_value()==desc)
   page.locator('#sortOrder').select_option('qty_asc');check('quantity numeric',keys().index('e')<keys().index('a'))
   page.locator('#sortOrder').select_option('matching_asc');check('manual connections before automatic',keys().index('s')<keys().index('t'))
   page.locator('#sortOrder').select_option('product_asc');page.locator('#clearBtn').click();boxes=page.locator('#rows .rowcheck');current=keys()
   boxes.nth(0).click();boxes.nth(4).click(modifiers=['Shift']);check('shift forward range checked',page.locator('#rows .rowcheck:checked').count()==5)
   boxes.nth(4).click(modifiers=['Shift']);check('shift clears range',page.locator('#rows .rowcheck:checked').count()==0)
   page.locator('#clearBtn').click();boxes.nth(5).click();boxes.nth(2).click(modifiers=['Shift']);check('shift reverse range checked',page.locator('#rows .rowcheck:checked').count()==4)
   page.locator('#sortOrder').select_option('qty_desc');page.locator('#rows .rowcheck:not(:checked)').first.click(modifiers=['Shift']);check('sort resets range anchor',page.locator('#rows .rowcheck:checked').count()==5)
   page.locator('#clearBtn').click();page.locator('#search').fill('ORDER');page.locator('#rows .rowcheck').first.click();page.locator('#rows .rowcheck').last.click(modifiers=['Shift']);check('filtered range only',set(page.evaluate('[...selected]'))==set(keys()))
   page.locator('#clearBtn').click();page.locator('#search').fill('');page.locator('#activeFilter').select_option('all');page.locator('#sortOrder').select_option('product_asc');page.locator('#rows .rowcheck').first.click();page.locator('#rows .rowcheck').last.click(modifiers=['Shift']);check('disabled row skipped','o' not in page.evaluate('[...selected]'))
   page.locator('#resetBtn').click()
   if personal:
    check('ten compact tiles and two wide bars',page.locator('.cards .card').count()==12)
    bounds=page.locator('.cards .card').evaluate_all('es=>es.map(e=>({key:e.dataset.color,x:e.getBoundingClientRect().x,y:e.getBoundingClientRect().y,w:e.getBoundingClientRect().width}))')
    check('first row four columns',len({x['y'] for x in bounds[:4]})==1 and len({x['x'] for x in bounds[:4]})==4)
    check('ready full width above purple',bounds[-2]['key']=='ready' and bounds[-2]['w']==bounds[-1]['w'] and bounds[-2]['y']<bounds[-1]['y'])
    for group,children in [('group_exchange',['exchange_ready','exchange_blocked']),('group_soldout',['charcoal','soldout_check']),('group_bundle',['ready_bundle','scheduled_bundle','bundle_confirmed','bundle_planned','bundle_unconfirmed'])]:
     page.locator('[data-color="'+group+'"]').click()
     for child in children:
      page.locator('[data-section="'+child+'"]').click();check('child '+child+' accessible',page.locator('#statusFilter').input_value()==child and len(keys())>0)
    page.locator('[data-section="scheduled_bundle"]').click();page.locator('#sectionGroupPanel').screenshot(path=str(qa/'bundle_sections.png'));check('nested bundle date panel',page.locator('#bundleDispatchPanel').is_visible());page.locator('[data-bundle-range="2026-10-21|2026-10-22"]').click();check('bundle date product filter retained',keys()==['k'])
    page.locator('[data-color="group_soldout"]').click();page.locator('[data-section="soldout_check"]').click();page.locator('[data-oos="hidden"]').click();check('hidden soldout tab retained',keys()==['q'])
    page.locator('#resetBtn').click();page.set_viewport_size({'width':800,'height':1000});page.locator('.cards').screenshot(path=str(qa/'dashboard_compact.png'));check('narrow card grid fits viewport',page.locator('.cards').bounding_box()['width']<=800)
   # Read-only list interactions must never change an order, start a browser, or send.
   check('no HTTP mutations',not posts);check('API requests succeeded',all(status==200 for path,status in responses.items() if path.startswith('/api/')));check('no JavaScript errors',not errors)
   browser.close()
 finally:server.shutdown();server.server_close();thread.join()
print(json.dumps({'edition':ROOT.name,'passed':len(checks),'checks':checks,'live_messages':0},ensure_ascii=False,indent=2))
