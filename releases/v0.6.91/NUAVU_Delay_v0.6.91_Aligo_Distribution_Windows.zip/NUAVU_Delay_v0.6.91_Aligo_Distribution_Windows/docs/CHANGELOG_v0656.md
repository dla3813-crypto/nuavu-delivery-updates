# NUAVU_Delay_v0.6.56_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v0655.md

## Windows: desktop.py 경로 오류 (배포판, 10-20 10:09 보고) — 진짜 원인
- `can't open file '…\windows\desktop.py'`: PowerShell 스크립트들이 `windows\` 폴더 안에 있는데 자기 폴더를 앱 폴더로 잡아, 바로가기·실행·설치 스크립트 모두 `windows\desktop.py`(없는 파일)를 실행했습니다 → pythonw는 조용히 종료(무반응). 네 스크립트 모두 한 단계 위 폴더를 앱 폴더로 잡도록 고쳤습니다. 기존 바로가기는 잘못된 경로를 가리키므로 `처음한번_앱설치.bat`을 다시 실행해 바로가기를 새로 만듭니다.
