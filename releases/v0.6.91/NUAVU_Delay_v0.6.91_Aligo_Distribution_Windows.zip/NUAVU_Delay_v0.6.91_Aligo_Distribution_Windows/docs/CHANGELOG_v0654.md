# NUAVU_Delay_v0.6.54_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v0653.md

## Windows 앱 창이 안 열릴 때 진단 (배포판, 10-20 10:00 보고)
- desktop.py가 시작하자마자 `%LOCALAPPDATA%\NUAVU Delay Distribution\logs\desktop.log`에 시작 시각·Python 경로를 적고, 앱 창 구성요소(webview) 불러오기 실패를 포함한 모든 예외를 로그와 경고창에 남깁니다(전에는 pythonw 실행이라 조용히 끝날 수 있었음).
- `문제확인용_앱창실행.bat` 추가: 콘솔과 함께 앱 창을 띄워 오류를 바로 보여줍니다.
