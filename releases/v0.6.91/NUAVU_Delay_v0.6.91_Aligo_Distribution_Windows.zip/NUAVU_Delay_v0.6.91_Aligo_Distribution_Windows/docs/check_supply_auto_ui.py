"""Temporary installed bundle, real local HTTP controls, synthetic files/engine only."""
from pathlib import Path
import importlib.util,json,sys,threading,time
from unittest.mock import patch
ROOT=(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]).resolve();personal='Distribution' not in ROOT.name
sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
if personal:
 from test_v056 import Base
 from test_v068 import order,source_row,xlsx
else:
 from helpers import Base
 from test_supply_regression import order,source_row,xlsx
from install_desktop import build_bundle
from playwright.sync_api import sync_playwright
checks=[]
def check(name,condition):assert condition,name;checks.append(name)
b=Base();b.setUp();engine=b.engine
folder=Path(b.tmp.name)/'supply';folder.mkdir();engine.supply_link(str(folder))
with b.store.edit() as s:s['rows']=[];s['notices']=[];s['imports']=[]
engine.import_rows({'rows':[order(1,qty=20)]})
def put(name,rows):
 p=folder/name;p.write_bytes(xlsx([('test',rows)]));return p
put('진행상황.xlsx',[source_row(office='2026-10-16',qty=2),source_row(office='2026-10-17',qty=3),source_row(office='2026-10-18',qty=4)])
original=b.store.read()
bundle=build_bundle(Path(b.tmp.name)/'Auto supply.app',Path(sys.executable).resolve());resources=bundle/'Contents/Resources'
check('watcher packaged',(resources/'supply_watch.py').read_bytes()==(ROOT/'supply_watch.py').read_bytes())
spec=importlib.util.spec_from_file_location('supply_ui_app',resources/'app.py');app=importlib.util.module_from_spec(spec);spec.loader.exec_module(app)
server=app.LocalServer(engine);server.desktop=False
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
qa=ROOT/'docs/qa/supply_auto';qa.mkdir(parents=True,exist_ok=True)
def until(predicate):
 limit=time.monotonic()+8
 while not predicate():
  if time.monotonic()>limit:raise AssertionError('automatic watcher did not settle')
  page.wait_for_timeout(30)
try:
 with patch('supply_watch.POLL_SECONDS',.05),patch('supply_watch.STABLE_SECONDS',.1):
  engine.supply_watcher.start()
  with sync_playwright() as pw:
   browser=pw.chromium.launch(channel='chrome',headless=True,chromium_sandbox=True)
   page=browser.new_page(viewport={'width':1450,'height':1100});errors=[];posts=[]
   page.on('pageerror',lambda e:errors.append(str(e)))
   page.on('request',lambda r:posts.append(r.url.removeprefix(server.origin)) if r.method=='POST' else None)
   page.route('**/*',lambda r:r.continue_() if r.request.url.startswith(server.origin+'/') else r.abort())
   page.goto(server.url);page.wait_for_selector('#rows tr');page.locator('#supplyBtn').click()
   check('initial auto off',page.locator('#supplyAutoBtn').text_content()=='자동 반영 켜기')
   check('manual button retained',page.locator('#refreshSupply').is_visible())
   check('no automatic read before enabling',not b.store.read()['supply']['progress'])
   page.locator('#supplyAutoBtn').click();until(lambda:bool(b.store.read()['supply']['lastReadAt']))
   page.evaluate('refresh()');page.wait_for_function("document.querySelector('#supplyAutoBtn').textContent==='자동 반영 끄기'")
   check('auto mode shown','자동 반영' in page.locator('#supplyReadState').text_content())
   check('pressed state',page.locator('#supplyAutoBtn').get_attribute('aria-pressed')=='true')
   check('first progress applied',engine.public_state()['rows'][0]['supplyInfo']['plannedQty']==9)
   m=put('솔리아 10월 17일 출고장 (완료).xlsx',[source_row(product='다른 상품',qty=1)])
   until(lambda:b.store.read()['supply'].get('progressCutoff')=='2026-10-17')
   page.evaluate('refresh()');page.wait_for_function("document.querySelector('#supplyCutoffInfo').textContent.includes('2행 / 5개')")
   check('global date displayed','2026-10-17 포함 이전' in page.locator('#supplyCutoffInfo').text_content())
   check('active quantity excludes stale rows',engine.public_state()['rows'][0]['supplyInfo']['plannedQty']==4)
   check('included day excluded message','2행 / 5개 제외' in page.locator('#supplyCutoffInfo').text_content())
   check('manual settings intact',page.locator('#supplyYear').input_value()=='2026')
   page.locator('#supplyDialog').screenshot(path=str(qa/'automatic.png'))
   m.unlink();until(lambda:b.store.read()['supply']['watchSignature']==__import__('supply_watch').scan_signature(str(folder.resolve())))
   check('cutoff retained after deletion',engine.public_state()['supply']['progressCutoff']=='2026-10-17')
   p=folder/'진행상황.xlsx';p.write_bytes(b'broken')
   until(lambda:engine.supply_watcher.status()['phase']=='error');page.evaluate('refresh()')
   page.wait_for_function("document.querySelector('#supplyReadState').classList.contains('dangertext')")
   check('previous data retained on read error',engine.public_state()['rows'][0]['supplyInfo']['plannedQty']==4)
   check('error visible',bool(page.locator('#supplyReadState').text_content()))
   page.locator('#supplyDialog').screenshot(path=str(qa/'read_error.png'))
   put('진행상황.xlsx',[source_row(office='2026-10-18',qty=6)])
   until(lambda:engine.public_state()['rows'][0]['supplyInfo']['plannedQty']==6)
   page.evaluate('refresh()');page.wait_for_function("!document.querySelector('#supplyReadState').classList.contains('dangertext')")
   check('file correction auto recovered',not engine.supply_watcher.status()['error'])
   page.locator('#supplyAutoBtn').click();until(lambda:not b.store.read()['supply']['autoEnabled'])
   put('진행상황.xlsx',[source_row(office='2026-10-18',qty=8)]);page.wait_for_timeout(250)
   check('off prevents changes',engine.public_state()['rows'][0]['supplyInfo']['plannedQty']==6)
   page.locator('#refreshSupply').click();until(lambda:engine.public_state()['rows'][0]['supplyInfo']['plannedQty']==8)
   page.evaluate('refresh()');page.wait_for_function("document.querySelector('#supplyReadState').textContent.includes('마지막 수동')")
   check('manual works while off',b.store.read()['supply']['lastReadMode']=='manual')
   check('no side-effect API calls',all(x in {'/api/supply-settings','/api/supply-auto','/api/supply-refresh'} for x in posts))
   check('no scripts errors',not errors)
   after=b.store.read()
   for key in ['rows','notices','imports']:check('preserved '+key,after[key]==original[key])
   page.set_viewport_size({'width':960,'height':850});page.locator('#supplyDialog').screenshot(path=str(qa/'compact.png'))
   check('compact dialog fits',page.locator('#supplyDialog').bounding_box()['width']<=960)
   browser.close()
finally:
 engine.stop.set();engine.supply_watcher.join();server.shutdown();thread.join();server.server_close();b.tearDown();b.doCleanups()
print(json.dumps({'passed':len(checks),'checks':checks},ensure_ascii=False,indent=2))
