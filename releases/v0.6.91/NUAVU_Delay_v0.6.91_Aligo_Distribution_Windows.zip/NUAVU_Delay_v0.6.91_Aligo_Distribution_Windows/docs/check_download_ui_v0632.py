"""Real packaged HTTP/native handlers with memory Keychain and fake login.

Run with a source path and --baseline to reproduce the old settings popup.
No actual account, browser login, download, installed app or customer send.
"""
from pathlib import Path
from types import SimpleNamespace
import json,sys,tempfile,threading
QA_ROOT=Path(__file__).resolve().parents[1]
ROOT=QA_ROOT
BASELINE='--baseline' in sys.argv
sys.path.insert(0,str(ROOT))
from install_desktop import build_bundle
from playwright.sync_api import sync_playwright
checks=[]
def check(name,yes):
    assert yes,name
    checks.append(name)
with tempfile.TemporaryDirectory() as tmp:
    tmp=Path(tmp)
    bundle=build_bundle(tmp/'Settings QA.app',Path(sys.executable).resolve())
    resources=(bundle/'Contents/Resources').resolve()
    sys.path[:0]=[str(resources),str(ROOT/'tests')]
    import app,desktop
    from domain import Store,Engine
    from order_auto import OrderAutoController,OrderAutoError
    from fake_security import MemoryVault
    from helpers import FakeSMS,FakeAT
    store=Store(tmp/'data');vault=MemoryVault();sms=FakeSMS();at=FakeAT()
    engine=Engine(store,sms,MemoryVault(),aligo_provider=at,aligo_vault=MemoryVault())
    engine.configure_shop({'shopName':'데모스토어'})
    runs=[]
    def login(c,cfg):
        account=c.login_account()
        runs.append({'loginOnly':cfg.get('loginOnly'),'domain':account['domain'],'username':account['username']})
    controller=OrderAutoController(store,runner=login,login_vault=vault)
    controller.thread=SimpleNamespace(is_alive=lambda:not controller.stop.is_set())
    controller.job={'id':'download-job','phase':'error_open','message':'완료된 주문 엑셀 확인 단계에서 중단했습니다. 가상 오류 안내'}
    controller.browser_recovery=True;controller.browser_can_continue=False
    server=app.LocalServer(engine);server.desktop=True
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    native=desktop.DesktopAPI(engine,server.token,server.origin,SimpleNamespace())
    native._window=SimpleNamespace(get_current_url=lambda:server.url);native._order_auto=controller
    allowed={'order_auto_status','order_browser_action','order_auto_cancel'};calls=[]
    def bridge(_source,name,args):
        assert name in allowed;calls.append(name)
        return getattr(native,name)(*args)
    try:
        with sync_playwright() as pw:
            browser=pw.chromium.launch(channel='chrome',headless=True,chromium_sandbox=True)
            try:
                page=browser.new_page(viewport={'width':1440,'height':1100},locale='ko-KR')
                errors=[];external=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                def route(r):
                    if r.request.url.startswith(server.origin+'/'):r.continue_()
                    else:external.append(r.request.url);r.abort()
                page.route('**/*',route);page.expose_binding('__native',bridge)
                page.add_init_script("""window.pywebview={api:{}};
                for(const n of ['order_auto_status','order_browser_action','order_auto_cancel'])
                    window.pywebview.api[n]=(...args)=>window.__native(n,args);""")
                page.goto(server.url,wait_until='networkidle');page.wait_for_function('state!==null')
                page.evaluate('pollOrderAuto()')
                check('actual packaged/native failure shown',page.locator('#orderErrorDialog').evaluate('e=>e.open') and app.ROOT==resources)
                check('download error preserved','완료된 주문 엑셀 확인' in page.locator('#orderErrorText').inner_text())
                check('post-request login controls hidden',not page.locator('#orderBrowserRecovery').is_visible())
                check('close browser remains explicit',page.locator('#closeOrderErrorBrowser').is_visible())
                check('no redirect or resend explanation','자동 재신청은 하지 않습니다' in page.locator('#orderErrorHint').inner_text())
                qa=QA_ROOT/'docs/qa';qa.mkdir(exist_ok=True)
                page.locator('#orderErrorDialog').screenshot(path=str(qa/'v0632_download_error.png'))
                check('forged login action rejected','error' in native.order_browser_action(server.token,'download-job','open','login2'))
                check('forged resume rejected','error' in native.order_browser_action(server.token,'download-job','continue','login2'))
                page.locator('[data-close=orderErrorDialog]').click()
                check('dismiss only keeps worker',controller.status()['running'] and controller.status()['browserRecovery'])
                check('dismiss never calls cancel','order_auto_cancel' not in calls)
                page.evaluate('pollOrderAuto()')
                check('same error does not pop up again',not page.locator('#orderErrorDialog').evaluate('e=>e.open'))
                controller.job={'id':'login-job','phase':'error_open','message':'로그인 확인 단계의 가상 오류'}
                controller.browser_can_continue=True
                page.evaluate('pollOrderAuto()')
                check('pre-request login recovery still visible',page.locator('#reopenOrderBrowser').is_visible() and page.locator('#continueOrderBrowser').is_visible())
                page.locator('#reopenOrderBrowser').click()
                check('explicit pre-request navigation accepted',controller.take_browser_action()==('open','https://login2.ezadmin.co.kr/login.htm'))
                controller.job.update(phase='error_open')
                page.evaluate('pollOrderAuto()');page.locator('#closeOrderErrorBrowser').click()
                check('explicit close stops worker',controller.stop.is_set())
                check('no login/export runner started',not runs)
                check('no JS errors',not errors);check('no external network',not external)
            finally:browser.close()
    finally:server.shutdown();server.server_close();thread.join();store.close()
print(json.dumps({'passed':len(checks),'checks':checks},ensure_ascii=False,indent=2))
