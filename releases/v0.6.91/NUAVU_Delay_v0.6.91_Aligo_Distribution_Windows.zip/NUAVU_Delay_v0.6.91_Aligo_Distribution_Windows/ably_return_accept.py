"""에이블리 반품요청(접수필요) → 반품요청 접수, after the EzAdmin pickup (회수접수) is registered.

Requested 2026-10-19: for every pickup that is registered (newly or already), open 반품 진행 관리, select the
반품요청 (접수필요) card, tick the row whose 원송장번호 is the pickup's original tracking number, press
'반품 요청 접수', confirm the blue '반품요청 접수' button in the dialog, then open the 검수대기 card and verify
the same 원송장 is now listed there. One request per click; nothing else on the page is touched.

Measured DOM (my.a-bly.com/sales/order/return/progress, 2026-10-19):
 · status cards .return-status-filter__filter (title .return-status-filter__filter--title: 반품요청 (접수필요) / 검수대기 / …),
   selected card gets --selected; the 검색 button reloads the list for that card.
 · el-table with a fixed-left block: fixed row cells [checkbox, 반품 요청번호, 반품 요청일, 반품 상태, 상품주문번호, 주문번호, 상품명];
   main row cell '원송장번호' (header text lookup; measured index 10). A multi-item request spans extra rows without a checkbox.
 · toolbar button '반품 요청 접수' (is-plain) → dialog .el-dialog__wrapper titled '반품요청 접수' with
   '반품요청 N개를 접수합니다.' and footer buttons [닫기, 반품요청 접수].
 · pagination .el-pagination .btn-next (disabled on the last page), 30 rows per page.
"""
import re
from return_browser import ReturnFlow,RETURN_URL
from return_data import ReturnError as OrderAutoError

ACCEPTED={'접수 완료','이미 접수됨'}  # pickup results that continue to the Ably step
ROWS_JS=r'''()=>{const txt=e=>(e?.innerText||'').replace(/\s+/g,' ').trim();const inv=t=>(String(t||'').match(/\d{10,14}/)||[''])[0];
const heads=[...document.querySelectorAll('.el-table__header-wrapper th')].map(txt);let ci=heads.indexOf('원송장번호');if(ci<0)ci=10;
const fheads=[...document.querySelectorAll('.el-table__fixed .el-table__fixed-header-wrapper th')].map(txt);
const fi=(name,fallback)=>{const i=fheads.indexOf(name);return i<0?fallback:i;};
const iReq=fi('반품 요청번호',1),iStatus=fi('반품 상태',3),iItem=fi('상품주문번호',4),iOrder=fi('주문번호',5);
const fixed=[...document.querySelectorAll('.el-table__fixed .el-table__body tr')];const main=[...document.querySelectorAll('.el-table__body-wrapper .el-table__body tr')];
return main.map((tr,i)=>{const f=fixed[i];return {index:i,selectable:!!f?.querySelector('.el-checkbox'),checked:!!f?.querySelector('.el-checkbox.is-checked'),
 requestNo:txt(f?.children[iReq]),status:txt(f?.children[iStatus]),itemId:txt(f?.children[iItem]),orderId:txt(f?.children[iOrder]),invoice:inv(tr.children[ci]?.innerText)};});}'''

def match_row(rows,invoice):
    """The selectable row whose 원송장번호 equals the pickup's original tracking number (first hit)."""
    for r in rows:
        if r.get('selectable') and r.get('invoice')==invoice:return r
    return None

def request_size(rows,index):
    """Product rows of the request that starts at `index`: the selectable row + the following rows without a checkbox
    (a multi-item request spans extra rows, measured 2026-10-19)."""
    n=1
    for r in rows[index+1:]:
        if r.get('selectable'):break
        n+=1
    return n

def dialog_count(text):
    m=re.search(r'반품요청\s*(\d+)\s*개를\s*접수합니다',text or '')
    return int(m[1]) if m else None

def waiting_outcome(found):
    """Row found in the 검수대기 card (or None) → result dict, shared by the post-click check and the already-waiting case."""
    if found and '검수대기' in found.get('status',''):
        return {'ablyResult':'에이블리 접수 완료','ablyRequestNo':found.get('requestNo','')}
    return None

def accept_targets(results):
    """Pickup results that continue to the Ably step: registered now or already (EX00 or C/S 이력), not inspections."""
    seen=set();out=[]
    for r in results:
        number=r.get('invoice','')
        if r.get('result') in ACCEPTED and number and number not in seen and not r.get('inspectOnly'):
            seen.add(number);out.append(r)
    return out

class ReturnAcceptFlow(ReturnFlow):
    def open_card(self,today,card_title):
        self.step='반품 진행 관리 열기';self.navigate(RETURN_URL);self.pause(1);self.dismiss_popups();self.check_market()
        self.set_last_year(today)
        self.step=card_title+' 카드 선택'
        cards=self.page.locator('.return-status-filter__filter:visible').filter(has_text=re.compile(re.escape(card_title)))
        if cards.count()!=1:raise OrderAutoError(f'반품 상태 카드 {card_title}을(를) 하나로 찾지 못했습니다.')
        cards.first.click(timeout=5000);self.pause(.5)
        self.until(lambda:'--selected' in (cards.first.get_attribute('class') or ''),10,f'{card_title} 카드가 선택되지 않았습니다.')
        button=self.until(lambda:self.button('검색').count()==1 and self.button('검색').first,20,'반품 목록의 검색 버튼을 하나로 찾지 못했습니다.')
        self.c.check();button.click(timeout=10000);self.table_idle()
    def rows(self):return self.page.evaluate(ROWS_JS)
    def find(self,invoice,max_pages=50):
        for _ in range(max_pages):
            self.c.check()
            hit=match_row(self.rows(),invoice)
            if hit:return hit
            nxt=self.page.locator('.el-pagination .btn-next')
            if not nxt.count() or nxt.first.is_disabled():return None
            nxt.first.click(timeout=5000);self.table_idle()
        raise OrderAutoError('반품 목록 페이지가 너무 많아 조회를 중단했습니다.')
    def accept_one(self,invoice,today):
        self.open_card(today,'반품요청')
        row=self.find(invoice)
        if row is None:
            # 2026-10-19 21:22: not in 접수필요 but already in 검수대기 → that is the normal, finished state.
            self.step='검수대기 확인'
            self.open_card(today,'검수대기')
            done=waiting_outcome(self.find(invoice))
            if done:return {**done,'ablyNote':'이미 검수대기 상태 · 반품요청번호 '+done['ablyRequestNo'],'ablyAlready':True}
            return {'ablyResult':'접수필요 목록에 없음','ablyNote':'에이블리 반품요청(접수필요)·검수대기 목록(지난 일년)에서 원송장을 찾지 못했습니다. 반품 철회·완료 등 다른 상태일 수 있습니다.'}
        if '반품요청' not in row['status']:return {'ablyResult':'접수 안 함','ablyNote':'반품 상태가 반품요청이 아닙니다: '+row['status']}
        self.step='반품 행 선택'
        box=self.page.locator('.el-table__fixed .el-table__body tr').nth(row['index']).locator('.el-checkbox__inner')
        if box.count()!=1:raise OrderAutoError('반품 행의 선택 상자를 찾지 못했습니다.')
        box.first.click(timeout=5000);self.pause(.4)
        snapshot=self.rows();checked=[r for r in snapshot if r['checked']]
        if len(checked)!=1 or checked[0]['invoice']!=invoice:raise OrderAutoError('선택한 반품 행이 하나가 아니어서 접수하지 않았습니다.')
        size=request_size(snapshot,checked[0]['index'])
        self.step='반품 요청 접수 버튼'
        self.one_button('반품 요청 접수').click(timeout=5000)
        dialog=self.page.locator('.el-dialog__wrapper:visible').filter(has_text=re.compile(r'반품요청\s*접수'))
        self.until(lambda:dialog.count()==1 and re.search(r'반품요청\s*\d+개를\s*접수합니다',dialog.first.inner_text()),10,'반품요청 접수 확인창이 열리지 않았습니다.')
        text=dialog.first.inner_text()
        count=dialog_count(text)
        # 2026-10-23 19:21: 상품 2~3개짜리 반품요청은 확인창이 'N개'로 뜬다. 고른 반품요청의 상품 줄 수와 같으면 접수하고 알림으로 알린다.
        # 다르면(다른 행이 함께 잡힌 것일 수 있음) 지금처럼 접수하지 않는다.
        if count!=1 and count!=size:raise OrderAutoError(f'확인창의 접수 건수({count}개)가 고른 반품요청의 상품 수({size}개)와 달라서 접수하지 않았습니다.')
        multi=count if count and count>1 else 0
        confirm=self.button('반품요청 접수',dialog.first)
        if confirm.count()!=1:raise OrderAutoError('확인창의 반품요청 접수 버튼을 하나로 찾지 못했습니다.')
        self.step='반품요청 접수 확인';self.c.check()
        confirm.first.click(timeout=5000)  # once; the result is verified from the 검수대기 list, never by re-clicking
        self.pause(1.2)
        try:self.table_idle()
        except OrderAutoError:pass
        self.step='검수대기 확인'
        self.open_card(today,'검수대기')
        found=self.find(invoice);done=waiting_outcome(found)
        extra={'ablyMulti':multi} if multi else {}
        lead=f'상품 {multi}개 반품요청 · ' if multi else ''
        if done:return {**done,**extra,'ablyNote':lead+'검수대기 카드에서 확인 · 반품요청번호 '+done['ablyRequestNo']}
        return {'ablyResult':'에이블리 접수 확인 실패',**extra,'ablyNote':lead+'접수 버튼은 눌렀지만 검수대기 목록에서 원송장을 찾지 못했습니다. 에이블리에서 직접 확인하세요. 자동으로 다시 누르지 않았습니다.'}

def accept_returns(controller,targets,today):
    """Separate Ably Chrome. Returns {invoice: {ablyResult, ablyNote, ...}}; login/setup failures mark every target."""
    from playwright.sync_api import sync_playwright
    from return_session import launch_chrome,new_context
    from ably_credentials import AblyAccounts
    from aftersales_data import shop
    from credentials import VaultError
    out={}
    if not targets:return out
    try:account=AblyAccounts(controller.engine.store.directory).for_login()
    except VaultError as exc:
        return {t['invoice']:{'ablyResult':'에이블리 접수 실패','ablyNote':str(exc)} for t in targets}
    cfg=shop(controller.store.read());account.update(**cfg)
    with sync_playwright() as pw:
        browser=launch_chrome(pw);context=new_context(browser,accept_downloads=False)
        try:
            flow=ReturnAcceptFlow(controller,context,account['shopName'])
            try:flow.login(dict(account))
            except Exception as exc:
                if type(exc).__name__ in ('Cancelled','ReturnCancelled'):raise
                message='에이블리 로그인 실패 · '+flow.failure_message(exc)
                return {t['invoice']:{'ablyResult':'에이블리 접수 실패','ablyNote':message} for t in targets}
            for n,t in enumerate(targets,1):
                controller.check();controller.update('running',f'원송장 {t["invoice"]} · 에이블리 반품요청 접수 {n}/{len(targets)}')
                try:out[t['invoice']]=flow.accept_one(t['invoice'],today)
                except Exception as exc:
                    if type(exc).__name__ in ('Cancelled','ReturnCancelled'):raise
                    out[t['invoice']]={'ablyResult':'에이블리 접수 실패','ablyNote':(flow.step+' 단계 · ' if getattr(flow,'step','') else '')+flow.failure_message(exc)}
        finally:
            try:account.clear()
            except Exception:pass
            context.close();browser.close()
    return out
