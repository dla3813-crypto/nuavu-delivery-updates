"""에이블리 셀러 어드민(my.a-bly.com) 공통 세션 — 전용 headed Chrome, 키체인 계정, 키보드 입력 로그인.

원칙(web_import와 동일): 쿠키·저장 비밀번호를 가져오지 않고, 비밀번호를 로그·상태·JS 문자열에 넣지 않으며,
로그인 실패 시 창을 유지하고 사용자가 Chrome에서 직접 처리한 뒤 ‘로그인 완료 · 계속’을 누른다.
"""
import re
import time
from urllib.parse import urlsplit
from return_data import ReturnError as OrderAutoError, ReturnCancelled as Cancelled
from order_browser import safe_login_notice, login_notice_kind, network_code

HOST='my.a-bly.com'
LOGIN_URL='https://my.a-bly.com/login'
DASHBOARD_URL='https://my.a-bly.com/dashboard'
# Market is per job, never a hard-coded store.

def market_name(text):
    return re.sub(r'\s+','',str(text or ''))

class AblySession:
    def __init__(self,controller,context,market):
        self.market=market
        self.c=controller;self.context=context;self.page=None;self.step='브라우저 준비'
        self.login_error=None;self.connection_error=''
        context.on('page',self._watch)
        for page in context.pages:self._watch(page)
    def _watch(self,page):
        def failed(request):
            try:
                if request.is_navigation_request() and request.frame==page.main_frame:
                    self.connection_error=network_code(request.failure)
            except Exception:pass
        page.on('requestfailed',failed)
    # ---- waiting helpers (Flow와 동일한 취소 확인 방식) ----
    def pause(self,seconds):
        end=time.monotonic()+seconds
        while time.monotonic()<end:
            self.c.check()
            page=self.page if self.page and not self.page.is_closed() else next((p for p in self.context.pages if not p.is_closed()),None)
            if page is None:raise OrderAutoError('에이블리 Chrome 창이 닫혔습니다.')
            try:page.wait_for_timeout(min(100,max(1,(end-time.monotonic())*1000)))
            except Exception:
                if not page.is_closed():raise
    def until(self,predicate,timeout,message):
        end=time.monotonic()+timeout
        while time.monotonic()<end:
            self.c.check()
            result=predicate()
            if result:return result
            self.pause(.25)
        raise OrderAutoError(message)
    # ---- element helpers ----
    def button(self,text,scope=None,visible_only=True):
        """Element UI 버튼은 <i class="el-icon-*"> 아이콘이 접근성 이름에 섞여 get_by_role 정확 일치가 실패한다.
        글자(textContent)만으로 정확히 일치하는 버튼을 찾는다. 보이는 것만 센다."""
        scope=scope or self.page
        selector='button'+(':visible' if visible_only else '')
        pattern=re.compile(r'^\s*'+re.escape(text)+r'\s*$')
        return scope.locator(selector).filter(has_text=pattern)
    def one_button(self,text,scope=None,what='버튼'):
        loc=self.button(text,scope)
        count=loc.count()
        if count!=1:raise OrderAutoError(f"'{text}' {what}을 하나로 찾지 못했습니다({count}개).")
        return loc.first
    # ---- page checks ----
    def trusted(self,page=None):
        page=page or self.page
        u=urlsplit(page.url)
        if u.scheme!='https' or u.hostname!=HOST or u.port not in (None,443) or u.username or u.password:
            raise OrderAutoError('에이블리 셀러 어드민(HTTPS) 화면이 아니어서 중단했습니다. Chrome 창을 확인하세요.')
    def on_login_page(self,page=None):
        page=page or self.page
        try:
            u=urlsplit(page.url)
            return u.hostname==HOST and u.path.startswith('/login') and page.locator('input[type="password"]').first.is_visible()
        except Exception:return False
    def signed_in(self,page=None):
        page=page or self.page
        try:
            page.locator('body').count()
            u=urlsplit(page.url)
            if u.scheme!='https' or u.hostname!=HOST or u.path.startswith('/login'):return False
            name=page.locator('h1.profile__market-name')
            return name.count()>0 and name.first.is_visible()
        except Exception:return False
    def navigate(self,url):
        self.page.bring_to_front()
        import browser_window;browser_window.reminimize(self.page)
        self.page.goto(url,wait_until='domcontentloaded',timeout=45000)
    def dismiss_popups(self,keep=()):
        """광고·안내 el-dialog만 닫는다. keep에 있는 제목(예: 환불 요청 처리)은 건드리지 않는다."""
        for _ in range(6):
            closed=False
            wrappers=self.page.locator('.el-dialog__wrapper')
            for i in range(wrappers.count()):
                w=wrappers.nth(i)
                try:
                    if not w.is_visible():continue
                    title=(w.locator('.el-dialog__title').first.inner_text() if w.locator('.el-dialog__title').count() else '').strip()
                    if any(k in title for k in keep):continue
                    text=w.inner_text()
                    if '철회' in text or '환불 요청 처리' in title:continue
                    button=self.button('닫기',w)
                    if button.count():button.first.click(timeout=3000)
                    elif w.locator('.el-dialog__headerbtn').count():w.locator('.el-dialog__headerbtn').first.click(timeout=3000)
                    else:continue
                    closed=True;self.pause(.3)
                except Exception:continue
            if not closed:return
    def check_market(self):
        self.trusted()
        name=self.page.locator('h1.profile__market-name')
        if not name.count():raise OrderAutoError('마켓명을 찾지 못했습니다. 로그인 상태를 확인하세요.')
        actual=market_name(name.first.inner_text())
        if actual!=market_name(self.market):raise OrderAutoError(f'로그인된 마켓이 {self.market}가 아닙니다({actual}). 다른 마켓에서는 실행하지 않습니다.')
        tab=self.page.locator('[role="menuitem"]:visible').filter(has_text=re.compile(r'한국\(ABLY\)'))
        if tab.count()==1 and 'is-active' not in (tab.first.get_attribute('class') or ''):
            tab.first.click(timeout=5000);self.pause(.5)
    # ---- login (키보드 입력, 값 검증, 비밀번호 비우기) ----
    def login_controls(self):
        pwd=self.page.locator('input[type="password"]:visible')
        if pwd.count()!=1:return None
        form=pwd.first.locator('xpath=ancestor::form[1]')
        scope=form if form.count() else self.page
        ids=scope.locator('input[type="text"]:visible, input[type="email"]:visible, input:not([type]):visible')
        if ids.count()!=1:return None
        button=self.button('로그인',scope)
        if button.count()!=1:button=self.button('로그인')
        if button.count()!=1:
            submit=scope.locator('button[type="submit"]:visible')
            if submit.count()!=1:return None
            button=submit
        return ids.first,pwd.first,button.first
    def type_field(self,field,value):
        self.c.check();self.trusted()
        if not self.on_login_page():raise OrderAutoError('로그인 입력 주소가 바뀌어 중단했습니다.')
        if not isinstance(value,str) or not value or any(ord(c)<32 or ord(c)==127 for c in value):
            raise OrderAutoError('로그인 정보에 빈 값이나 제어문자가 있어 전송하지 않았습니다. 설정에서 다시 저장하세요.')
        limit=field.get_attribute('maxlength')
        if limit and limit.isdecimal() and len(value)>int(limit):
            raise OrderAutoError('저장한 계정이 입력칸 최대 길이를 초과해 전송하지 않았습니다.')
        field.click(timeout=5000);field.fill('')
        for character in value:
            self.c.check();self.trusted();field.press_sequentially(character,delay=20,timeout=15000)
        field.press('Tab')
        if field.input_value()!=value:
            raise OrderAutoError('저장한 계정과 로그인 입력칸의 값이 달라 전송하지 않았습니다. 에이블리 설정에서 계정을 다시 저장하세요.')
    def clear_password(self):
        try:
            pwd=self.page.locator('input[type="password"]:visible')
            if pwd.count():pwd.first.fill('',timeout=1000)
        except Exception:pass
    def login(self,account):
        self.page=self.context.pages[0] if self.context.pages else self.context.new_page()
        self.step='에이블리 로그인 페이지 열기';self.c.update('login','에이블리 로그인 페이지를 엽니다.')
        self.login_error=None
        def notice(dialog):
            text=safe_login_notice(dialog.message,account)
            kind=login_notice_kind(dialog.message)
            if dialog.type=='prompt':self.login_error='로그인에 별도 입력이 필요해 중단했습니다. Chrome 창에서 확인하세요.'
            elif kind=='credentials':self.login_error='에이블리에서 계정 정보 불일치를 안내했습니다. 사이트 안내: '+text
            elif kind=='security':self.login_error='에이블리 보안 확인이 필요합니다. 계정 오류로 판단하지 않았습니다. 사이트 안내: '+text
            else:self.c.update('login','에이블리 안내: '+text)
            try:dialog.dismiss()
            except Exception:pass
        self.context.on('dialog',notice)
        try:
            try:self.navigate(LOGIN_URL)
            except Exception:
                if self.page.is_closed():raise
            self.until(lambda:self.signed_in() or self.on_login_page(),30,'에이블리 로그인 화면을 열지 못했습니다. 인터넷 연결을 확인하세요.')
            if not self.signed_in() and account:
                controls=self.login_controls()
                if controls:
                    user,pwd,button=controls
                    self.step='에이블리 로그인 정보 입력';self.c.update('login','키체인에 저장한 에이블리 계정을 키보드 방식으로 입력합니다.')
                    self.type_field(user,account['username']);self.type_field(pwd,account['password'])
                    if user.input_value()!=account['username'] or pwd.input_value()!=account['password']:
                        raise OrderAutoError('로그인 입력값을 확인하지 못해 전송하지 않았습니다.')
                    self.step='에이블리 로그인 버튼 처리';self.c.check();button.click(timeout=10000)
                    self.c.update('login','에이블리 로그인 완료를 확인합니다.')
                    import time as _t,browser_window
                    started=_t.monotonic()
                    def finished():
                        if self.login_error:raise OrderAutoError(self.login_error)
                        if _t.monotonic()-started>8:
                            if browser_window.need_person():raise OrderAutoError('추가 인증 또는 로그인 확인이 필요합니다. '+browser_window.need_person())
                            browser_window.attention()  # extra authentication likely
                        return self.signed_in()
                    try:self.until(finished,60,'에이블리 로그인 완료를 확인하지 못했습니다.')
                    except OrderAutoError as exc:self.login_error=str(exc)
                else:self.login_error='에이블리 로그인 입력칸을 하나로 확인하지 못해 계정을 입력하지 않았습니다.'
            if not self.signed_in():
                # 원본 프로그램과 같은 복구: 창을 유지하고 사용자가 로그인한 뒤 ‘계속’을 누른다.
                self.clear_password()
                hint=(self.login_error+' ' if self.login_error else '')+'에이블리 Chrome 창에서 로그인한 뒤 ‘로그인 완료 · 계속’을 눌러 주세요.'
                import browser_window
                if browser_window.need_person():raise OrderAutoError((self.login_error+' ' if self.login_error else '')+browser_window.need_person())
                browser_window.attention()
                self.c.browser_failed(hint,True,True)
                while True:
                    self.pause(.3);command=self.c.take_browser_action()
                    if command and command[0]=='continue':
                        if self.signed_in():break
                        self.c.browser_failed('아직 에이블리 로그인을 확인하지 못했습니다. 로그인 후 다시 계속을 눌러 주세요.',True,True)
                self.c.end_browser_recovery()
        finally:
            self.context.remove_listener('dialog',notice);self.clear_password()
        self.step='마켓 확인';self.dismiss_popups();self.check_market()
        return self.page
    def failure_message(self,exc):
        if isinstance(exc,OrderAutoError):reason=str(exc)
        elif type(exc).__name__=='TimeoutError':reason='화면 응답을 기다리다 시간이 초과되었습니다.'
        else:reason='Chrome과의 연결 또는 화면 처리 중 문제가 발생했습니다.'
        code=network_code(str(exc)) or self.connection_error
        return f'{self.step} 단계에서 중단했습니다. {reason}'+(f' · {code}' if code else '')

def launch_chrome(playwright,accept_downloads=False):
    try:
        import browser_window as _bw;browser=playwright.chromium.launch(**_bw.launch_kwargs())
    except Exception:
        raise OrderAutoError('Chrome을 열지 못했습니다. Google Chrome 설치 여부를 확인하세요. 샌드박스를 끄고 재시도하지 않습니다.') from None
    return browser

def new_context(browser,accept_downloads=False):
    context=browser.new_context(viewport={'width':1380,'height':900},device_scale_factor=1,accept_downloads=accept_downloads)
    context.set_default_timeout(15000)
    import browser_window;browser_window.attach(context)
    return context
