"""Aligo AT adapter. HTTPS only, no automatic send retry, no provider SMS failover.

Based on the owner's Python example and official /alimapi.html, checked
2026-10-15. The current REST examples authenticate by apikey/userid directly.
No customer data, API keys or SenderKeys are bundled here.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import hashlib
import http.client
import json
import re
import ssl
from urllib.parse import urlencode
from provider import ProviderError, UncertainError

HOST = 'kakaoapi.aligo.in'
PATHS = {'templates':'/akv10/template/list/', 'send':'/akv10/alimtalk/send/',
         'detail':'/akv10/history/detail/'}

@dataclass(frozen=True)
class AligoCredential:
    user: str
    apikey: str = field(repr=False)
    senderkey: str = field(repr=False)
    @property
    def profile(self):
        return hashlib.sha256((self.user+'\0'+self.senderkey).encode()).hexdigest()

def safe_text(value, cred):
    text=str(value or '')
    for secret in (cred.apikey,cred.senderkey):
        if secret:text=text.replace(secret,'[보호된 값]')
    return text[:500]

class Aligo:
    def __init__(self,transport=None):self.transport=transport or self._post
    @staticmethod
    def _post(path,fields):
        from aligo_http import post_json
        return post_json(path,fields,PATHS.values())
    def request(self,operation,cred,fields=None):
        params={'apikey':cred.apikey,'userid':cred.user}
        if operation in {'send','templates'}:params['senderkey']=cred.senderkey
        params.update(fields or {})
        try:result=self.transport(PATHS[operation],params)
        except (ProviderError,UncertainError):raise
        except Exception as exc:raise UncertainError('알리고 응답을 확인하지 못했습니다. 자동으로 다시 보내지 않습니다.') from exc
        if not isinstance(result,dict) or isinstance(result.get('code'),bool):
            raise UncertainError('알리고 응답 형식을 확인하지 못했습니다.')
        code=result.get('code')
        if not isinstance(code,(int,str)) or not re.fullmatch(r'-?\d+',str(code)):
            raise UncertainError('알리고 결과코드 형식을 확인하지 못했습니다.')
        if int(code)!=0:raise ProviderError('알리고 요청 거절 ('+str(code)+'): '+safe_text(result.get('message'),cred),int(code))
        return result
    def template(self,cred,code):
        result=self.request('templates',cred,{'tpl_code':code})
        rows=result.get('list')
        if not isinstance(rows,list):raise UncertainError('알리고 템플릿 목록 형식이 다릅니다.')
        matched=[r for r in rows if isinstance(r,dict) and str(r.get('templtCode',''))==code]
        if len(matched)!=1:raise ProviderError(code+': 해당 템플릿을 한 건으로 확인하지 못했습니다.')
        row=matched[0]
        if row.get('senderKey') and row['senderKey']!=cred.senderkey:raise ProviderError('템플릿의 채널이 저장한 SenderKey와 다릅니다.')
        # Template lifecycle and inspection are separate fields. R is waiting
        # before the first send, not an inspection failure. An approved R must
        # be usable for its first send; A remains usable thereafter. Never allow
        # stopped / unknown / unapproved states. See docs/TEMPLATE_STATUS_FIX.md.
        status, inspection = row.get('status'), row.get('inspStatus')
        if status not in ('A', 'R') or inspection != 'APR':
            actual = safe_text(
                'status=' + json.dumps(status, ensure_ascii=False) +
                ', inspStatus=' + json.dumps(inspection, ensure_ascii=False), cred)
            raise ProviderError(code + ': 템플릿 사용 조건 불일치 (' + actual +
                                '). 승인(APR)이면서 정상(A) 또는 발송 전 대기(R)여야 합니다.')
        # Keep lifecycle flags out of the content snapshot/hash: the expected
        # R -> A change must not invalidate unchanged queued messages.
        return template_snapshot(row)
    def send(self,cred,notice):
        fields={'tpl_code':notice['aligoCode'],'sender':notice['sender'],'receiver_1':notice['phone'],
                'subject_1':notice['title'],'message_1':notice['content'],'failover':'N','testMode':'N'}
        if notice.get('aligoButtons'):fields['button_1']=json.dumps({'button':notice['aligoButtons']},ensure_ascii=False,separators=(',',':'))
        if notice.get('aligoEmtitle'):fields['emtitle_1']=notice['aligoEmtitle']
        result=self.request('send',cred,fields)
        info=result.get('info')
        if not isinstance(info,dict):raise UncertainError('알림톡 접수 응답에 메시지 ID가 없습니다. 자동 문자 대체를 하지 않습니다.')
        mid=str(info.get('mid',''))
        if not re.fullmatch(r'[1-9]\d*',mid) or str(info.get('scnt'))!='1' or str(info.get('fcnt'))!='0' or info.get('type')!='AT':
            raise UncertainError('알림톡 요청 수 또는 메시지 ID를 확정하지 못했습니다. 자동 재발송하지 않습니다.')
        return mid
    def detail(self,cred,mid):
        if not re.fullmatch(r'[1-9]\d*',str(mid)):raise ProviderError('알리고 메시지 ID가 없어 자동 결과 연결을 할 수 없습니다.')
        result=self.request('detail',cred,{'mid':str(mid),'page':'1','limit':'50'})
        rows=result.get('list')
        if not isinstance(rows,list) or any(not isinstance(r,dict) for r in rows):raise UncertainError('알리고 상세 결과 형식이 다릅니다.')
        # One request is deliberately one recipient, so pagination/many rows is abnormal.
        pages=str(result.get('totalPage','1'));count=str(result.get('totalCount',len(rows)))
        if not pages.isdigit() or int(pages)>1 or not count.isdigit() or int(count)!=len(rows) or len(rows)>1:
            raise UncertainError('한 수신자 요청에 여러 상세 결과가 있어 자동 대체를 보류합니다.')
        return rows

def variables(text):return set(re.findall(r'#\{([^{}]+)\}',text))
def fill(text,values):
    # Substitute only placeholders in the approved template, not inserted product text.
    unknown=variables(text)-set(values)
    if unknown:raise ProviderError('승인 템플릿에 지원하지 않는 변수가 있습니다: '+', '.join(sorted(unknown)))
    return re.sub(r'#\{([^{}]+)\}',lambda m:values[m[1]],text)

def template_snapshot(row):
    body=row.get('templtContent')
    if not isinstance(body,str) or not body or len(body)>4000:raise ProviderError('승인 템플릿 본문을 읽지 못했습니다.')
    if variables(body)!={'상품명','출고예정일'}:raise ProviderError('이 연결은 #{상품명}, #{출고예정일} 두 변수가 있는 지연 안내용입니다.')
    # Fail closed for unimplemented rich/ad/image templates rather than dropping content.
    if row.get('templateType','BA') not in ('','BA'):raise ProviderError('현재 연결은 기본형(BA) 알림톡 템플릿만 지원합니다.')
    if row.get('templateEmType','NONE') not in ('','NONE','TEXT'):raise ProviderError('이미지/아이템형 템플릿은 이번 연결에 포함되지 않았습니다.')
    title=row.get('templtTitle','') or ''
    if not isinstance(title,str) or variables(title)-{'상품명','출고예정일'}:raise ProviderError('강조 제목 변수를 확인하세요.')
    buttons=row.get('buttons') or []
    if not isinstance(buttons,list) or len(buttons)>5:raise ProviderError('템플릿 버튼 정보를 확인하세요.')
    result=[]
    for b in buttons:
        if not isinstance(b,dict) or b.get('linkType') not in {'AC','DS','WL','AL','BK','MD'} or not b.get('name'):
            raise ProviderError('현재 지원하지 않는 템플릿 버튼 형식입니다.')
        mapped={'name':b['name'],'linkType':b['linkType']}
        for src,dst in [('linkTypeName','linkTypeName'),('linkMo','linkM'),('linkPc','linkP'),('linkIos','linkI'),('linkAnd','linkA')]:
            if b.get(src):mapped[dst]=b[src]
        for v in mapped.values():
            if not isinstance(v,str) or variables(v)-{'상품명','출고예정일'}:raise ProviderError('버튼에 지원하지 않는 변수가 있습니다.')
        if b['linkType']=='WL' and not mapped.get('linkM'):raise ProviderError('웹링크 버튼의 모바일 주소가 없습니다.')
        result.append(mapped)
    return {'code':str(row['templtCode']),'name':str(row.get('templtName') or row['templtCode']),
            'body':body,'emtitle':title,'buttons':result,'verified':True}

def delivery_result(row):
    """No guessing from undocumented rslt codes or status=3 (only number format).

    msgid prefixed Q means still sending per official docs. Require a dated final
    result and an explicit, narrowly allowlisted result description. Unknown
    numeric/letter codes remain pending, never trigger SMS fallback.
    """
    msgid=str(row.get('msgid',''));reason=str(row.get('rslt_message','') or '').strip()
    if not msgid or msgid.upper().startswith('Q'):return 'PENDING'
    # Only a genuine dated result is treated as final; all-zero dates are pending.
    from datetime import datetime
    try:
        stamp=str(row.get('rsltdate',''))
        datetime.fromisoformat(stamp.replace('Z','+00:00'))
    except (ValueError,TypeError):return 'PENDING'
    normalized=re.sub(r'[\s.!。]','',reason).casefold()
    successes={'성공','전송성공','발송성공','정상전송','정상발송','정상발송완료','전송성공완료','성공적으로전송되었습니다','정상적으로전송되었습니다','success','delivered'}
    failures={'실패','전송실패','발송실패','메시지가템플릿과일치하지않음','메시지가템플릿과일치하지않습니다',
              '카카오톡미사용자','카카오톡미가입자','카카오톡을사용하지않는사용자','카카오톡미설치사용자',
              '수신거부','수신차단','전송시간초과','전송타임아웃','전송실패(카카오톡미사용자)','failed','deliveryfailed'}
    if normalized in successes:return 'DELIVERED'
    if normalized in failures:return 'FAILED'
    # 2026-10-22 19:44 보고: '최근 카카오톡을 미사용자'(rslt 9)가 목록에 없어 '결과 미확인'으로 남고 문자 대체가 안 나갔다.
    # 날짜가 찍힌 최종 결과 중 카카오톡 미사용·미가입·미설치·수신거부/차단·전송 실패·시간초과 계열은 실패로 본다.
    if re.search(r'(카카오톡|카톡)\S*(미사용|미가입|미설치|사용하지않|사용안)|미사용자|미가입자|수신거부|수신차단|전송실패|발송실패|시간초과|타임아웃',normalized):return 'FAILED'
    return 'PENDING'
