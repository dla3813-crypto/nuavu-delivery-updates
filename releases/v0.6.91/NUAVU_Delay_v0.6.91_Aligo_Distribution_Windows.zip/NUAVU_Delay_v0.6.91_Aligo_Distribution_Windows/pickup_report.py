"""Portable inline-string XLSX report, no formulas or external links."""
import io,zipfile,os,tempfile,xml.etree.ElementTree as E
from pathlib import Path
from datetime import datetime
NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
def report_bytes(rows):
    q=lambda n:'{'+NS+'}'+n
    E.register_namespace('',NS);s=E.Element(q('worksheet'))
    E.SubElement(s,q('dimension'),ref=f'A1:J{len(rows)+2}')
    view=E.SubElement(E.SubElement(s,q('sheetViews')),q('sheetView'),workbookViewId='0')
    E.SubElement(view,q('pane'),ySplit='2',topLeftCell='A3',activePane='bottomLeft',state='frozen')
    cols=E.SubElement(s,q('cols'))
    for i,w in enumerate((22,16,18,18,22,23,12,65,22,60),1):E.SubElement(cols,q('col'),min=str(i),max=str(i),width=str(w),customWidth='1')
    data=E.SubElement(s,q('sheetData'))
    bad=sum(r.get('result') not in ('접수 완료','이미 접수됨','접수 전 확인') for r in rows)
    values=[[f'확인 필요 {bad}건' if bad else '회수접수 결과'],['원운송장번호','고객명','택배사','수신자명','결과','접수시각','회수 차수','안내','플랫폼 접수 (에이블리·지그재그)','플랫폼 안내']]
    values += [[r.get(k,'') for k in ('invoice','customer','carrier','receiver','result','acceptedAt','attempt','note','ablyResult','ablyNote')] for r in rows]
    for i,values_row in enumerate(values,1):
        rr=E.SubElement(data,q('row'),r=str(i))
        for j,v in enumerate(values_row):
            c=E.SubElement(rr,q('c'),r=chr(65+j)+str(i),t='inlineStr',s='1' if i==1 and bad else '0')
            t=E.SubElement(E.SubElement(c,q('is')),q('t'));t.text=''.join(c for c in str(v) if ord(c)>=32 or c in '\n\t')
    E.SubElement(s,q('autoFilter'),ref=f'A2:J{max(2,len(values))}')
    styles=f'<styleSheet xmlns="{NS}"><fonts count="2"><font><sz val="11"/><name val="맑은 고딕"/></font><font><b/><color rgb="FFC62C49"/><sz val="12"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="2"><xf fontId="0" fillId="0" borderId="0" numFmtId="49" xfId="0"/><xf fontId="1" fillId="0" borderId="0" numFmtId="49" xfId="0" applyFont="1"/></cellXfs></styleSheet>'
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>')
        z.writestr('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml',f'<workbook xmlns="{NS}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="회수접수 결과" sheetId="1" r:id="rId1"/></sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>')
        z.writestr('xl/worksheets/sheet1.xml',E.tostring(s,encoding='utf-8',xml_declaration=True));z.writestr('xl/styles.xml',styles)
    return out.getvalue()
def save_report(rows,folder,now):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    base='회수접수_결과_'+now.strftime('%Y%m%d_%H%M');target=folder/(base+'.xlsx');n=2
    while target.exists() or target.is_symlink():target=folder/(base+f'_{n}.xlsx');n+=1
    fd,tmp=tempfile.mkstemp(prefix='.pickup-',dir=folder)
    try:
        with os.fdopen(fd,'wb') as f:f.write(report_bytes(rows));f.flush();os.fsync(f.fileno())
        os.link(tmp,target)
    finally:Path(tmp).unlink(missing_ok=True)
    return str(target)
