"""Zigzag 출고 예정일 동기화 + app-planned 배송연기 안내.

Sync: Zigzag's 변경 발송 예정일 (date only) becomes an app notice (source 'zigzag_sync'), the same way
Ably's 예상출고일 does. Rows without a changed date carry no delay notice and are left alone.
Push: after a message-less delay acknowledgement in the app, Zigzag gets a 배송연기 안내 for those
rows only when the app's 출고 예정일 is later than Zigzag's current 발송 예정일 (변경 발송 예정일 if set).
Matching: Zigzag 상품주문번호 against the app row's orderItemId first, then Zigzag 주문번호 against the app
orderId when that order has exactly one app row and one Zigzag row.
"""
from __future__ import annotations
from job_alerts import job_alert
import copy,hashlib,json,re,secrets,threading
from collections import defaultdict
from zigzag_browser import ZigzagError,ZigzagCancelled,ZigzagPushAborted,choose_change_date

ZIGZAG='누아브 지그재그'

class ZigzagSyncError(ZigzagError):pass

def match_rows(s,items):
    """Pair Zigzag list items with app rows. Returns [(item,row_or_None,reason)]."""
    rows=[r for r in s['rows'] if r.get('active') and r.get('seller')==ZIGZAG]
    by_item={};by_order=defaultdict(list)
    for r in rows:
        ident=str(r.get('orderItemId') or '').strip()
        if ident:by_item.setdefault(ident,[]).append(r)
        for part in (r.get('orderItems') or []):
            pid=str(part.get('id') or '').strip()
            if pid:by_item.setdefault(pid,[]).append(r)
        by_order[str(r.get('orderId') or '').strip()].append(r)
    zz_by_order=defaultdict(list)
    for i in items:zz_by_order[i['orderId']].append(i)
    out=[]
    for i in items:
        cands=by_item.get(i['itemId'],[])
        if len(cands)==1:out.append((i,cands[0],''));continue
        if len(cands)>1:out.append((i,None,'같은 상품주문번호가 여러 주문에 연결됨'));continue
        oc=by_order.get(i['orderId'],[])
        if len(oc)==1 and len(zz_by_order[i['orderId']])==1:out.append((i,oc[0],''));continue
        if not oc:out.append((i,None,'앱 주문 목록에 없는 지그재그 주문 (최신 확장주문검색을 먼저 불러오세요)'));continue
        out.append((i,None,'한 주문에 상품이 여러 개라 상품주문번호로만 연결할 수 있습니다 (주문 상세번호 필요)'))
    return out

def plan_pushes(s,items,keys,today):
    """Targets among `keys` whose app delay notice is later than Zigzag's current 발송 예정일."""
    from ably_sync import app_delay_notice
    wanted=set(keys);targets=[];skipped=[]
    for item,row,reason in match_rows(s,items):
        if not row or row['key'] not in wanted:continue
        n=app_delay_notice(s,row['key'])
        if not n:skipped.append({'itemId':item['itemId'],'orderId':item['orderId'],'key':row['key'],'dueDate':'','noticeId':'','status':'skipped','quiet':True,'reason':'앱 배송지연 안내 이력 없음'});continue
        if item['changedDate']:
            # Rule, not an error. If an earlier run reported this send as failed but Zigzag now shows that date, note the correction.
            earlier=[p for p in s.get('zigzagPushLog',[]) if p.get('itemId')==item['itemId'] and p.get('status')!='sent' and p.get('sendDate')==item['changedDate']]
            confirmed=[p for p in s.get('zigzagPushLog',[]) if p.get('itemId')==item['itemId'] and p.get('status')=='sent']
            skipped.append({'itemId':item['itemId'],'orderId':item['orderId'],'key':row['key'],'dueDate':n['dueDate'],'noticeId':n['id'],'status':'skipped','quiet':True,'sendDate':item['changedDate'],
                            'reconcileSent':bool(earlier and not confirmed),'reason':f'지그재그에 이미 배송연기 안내됨 ({item["changedDate"]}) · 1회만 가능'});continue
        if item.get('shipByDate') and str(today)>item['shipByDate']:
            # 2026-10-23: 지그재그는 최초 발송 예정일(결제일+3영업일)까지만 배송연기 안내 가능 — 지난 주문은 버튼이 꺼져 있다.
            skipped.append({'itemId':item['itemId'],'orderId':item['orderId'],'key':row['key'],'dueDate':n['dueDate'],'noticeId':n['id'],'status':'skipped','quiet':True,'zigzagDate':item['currentDate'],
                            'reason':f"지그재그 발송 예정일({item['shipByDate']})이 지나 배송연기 안내 불가 · 고객 안내 문자 작성으로 안내하세요"});continue
        send_date,why=choose_change_date(n['dueDate'],item['currentDate'])
        base={'itemId':item['itemId'],'orderId':item['orderId'],'key':row['key'],'dueDate':n['dueDate'],'noticeId':n['id'],'zigzagDate':item['currentDate']}
        if not send_date:skipped.append({**base,'status':'skipped','quiet':'이후가 아니어서' in why,'reason':why});continue
        targets.append({**base,'sendDate':send_date,'adjusted':why})
    return targets,skipped

def validate_pushes(pushes):
    if pushes is None:return []
    if not isinstance(pushes,list) or len(pushes)>20000:raise ZigzagSyncError('지그재그 배송연기 안내 결과 형식을 확인하지 못했습니다.')
    clean=[]
    for raw in pushes:
        if not isinstance(raw,dict) or raw.get('status') not in ('sent','failed','skipped'):raise ZigzagSyncError('지그재그 배송연기 안내 결과 형식을 확인하지 못했습니다.')
        p={k:raw.get(k,'') for k in ('itemId','orderId','key','dueDate','noticeId','zigzagDate','sendDate','adjusted','status','reason','platformNotice')}
        p['quiet']=bool(raw.get('quiet'));p['reconcileSent']=bool(raw.get('reconcileSent'))
        if not isinstance(p['itemId'],str) or not re.fullmatch(r'\d{1,30}',p['itemId']):raise ZigzagSyncError('지그재그 결과의 상품주문번호를 확인하지 못했습니다.')
        clean.append(p)
    return clean

def record_pushes(s,pushes,stamp):
    pushes=validate_pushes(pushes)
    if not pushes:return {'pushed':0,'pushFailed':0,'pushSkipped':0}
    by_id={n['id']:n for n in s['notices']};log=s.setdefault('zigzagPushLog',[])
    for p in pushes:
        log.append({**p,'at':stamp})
        n=by_id.get(p['noticeId'])
        if n is not None and p['status']=='sent':
            note=f"지그재그 배송연기 안내 전송 완료 (앱 자동) · 상품주문번호 {p['itemId']} · 변경 발송 예정일 {p['sendDate']}"+(' · '+p['adjusted'] if p['adjusted'] else '')
            n.setdefault('events',[]).append({'at':stamp,'status':n['status'],'note':note});n['updatedAt']=stamp
        elif n is not None and p['reconcileSent']:
            note=f"지그재그 배송연기 안내 전송 확인 · 상품주문번호 {p['itemId']} · 변경 발송 예정일 {p['sendDate']} (이전 실행에서 오류로 표시됐으나 지그재그에 반영됨)"
            n.setdefault('events',[]).append({'at':stamp,'status':n['status'],'note':note});n['updatedAt']=stamp
    del log[:-5000]
    counts={'pushed':sum(p['status']=='sent' for p in pushes),'pushFailed':sum(p['status']=='failed' for p in pushes),'pushSkipped':sum(p['status']=='skipped' and not p['quiet'] for p in pushes),'pushRule':sum(p['status']=='skipped' and p['quiet'] for p in pushes)}
    s['audits'].append({'at':stamp,'event':'지그재그 배송연기 안내',**counts})
    return counts

def push_message(counts):
    if not any(counts.get(k) for k in ('pushed','pushFailed','pushSkipped','pushRule')):return ''
    return f" · 지그재그 배송연기 안내 {counts['pushed']}건"+(f" / 실패 {counts['pushFailed']}건" if counts['pushFailed'] else '')+(f" / 보류 {counts['pushSkipped']}건" if counts['pushSkipped'] else '')+(f" / 규칙상 제외 {counts.get('pushRule',0)}건" if counts.get('pushRule') else '')

def apply_snapshot(engine,snapshot):
    """Record Zigzag's 변경 발송 예정일 as app notices; count the rest."""
    from domain import now
    items=snapshot.get('rows') or [];stamp=now();pushes=validate_pushes(snapshot.get('pushes'))
    counts={'scanned':len(items),'pages':snapshot.get('pages',1),'changed':0,'items':0,'unchanged':0,'unmatched':0,'protected':0,'noChange':0}
    issues=[]
    with engine.network_lock,engine.store.edit() as s:
        counts.update(record_pushes(s,pushes,stamp))
        issues.extend({'itemId':p['itemId'],'reason':('지그재그 안내 실패 · ' if p['status']=='failed' else '지그재그 안내 보류 · ')+(p['reason'] or '')} for p in pushes if p['status']!='sent' and not p['quiet'])
        pairs=match_rows(s,items)
        if any(n['status']=='SENDING' and {r['key'] for _,r,_ in pairs if r}.intersection(n.get('itemKeys',[])) for n in s['notices']):
            raise ZigzagSyncError('같은 주문의 고객 안내가 전송 중입니다. 전송 결과 확인 후 다시 동기화하세요.')
        for item,row,reason in pairs:
            if not item['changedDate']:counts['noChange']+=1;continue
            counts['changed']+=1
            if not row:counts['unmatched']+=1;issues.append({'itemId':item['itemId'],'reason':reason});continue
            key=row['key'];due=item['changedDate']
            facts={'itemId':item['itemId'],'orderId':item['orderId'],'qty':item['qty'],'shipBy':item['shipByDate'],'changed':due}
            signature=hashlib.sha256(json.dumps(facts,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
            old=[n for n in s['notices'] if n.get('source')=='zigzag_sync' and key in n.get('itemKeys',[])]
            if old and old[-1].get('syncSignature')==signature:counts['unchanged']+=1;continue
            protected=any(not n.get('isTest') and n['status'] in ('PENDING','DELIVERED') and n.get('kind') in ('SMS','LMS','AT') and key in n.get('itemKeys',[]) for n in s['notices'])
            counts['protected']+=int(protected)
            note='지그재그 상품준비/배송 관리의 변경 발송 예정일을 읽었습니다. 앱의 실제 발송 성공 이력을 우선합니다.'
            s['notices'].append({'id':'ZIGZAG-'+secrets.token_urlsafe(16),'ref':'','kind':'EXTERNAL','channel':'지그재그 출고 예정일 동기화',
                'title':'지그재그 변경 발송 예정일','content':'사이트 조회 기록 · 앱에서 실제 발송 없음','phone':'','seller':ZIGZAG,'orderId':row['orderId'],
                'dueDate':due,'noticeType':'delay','templateKey':'first','itemKeys':[key],
                'products':[{k:row.get(k,'') for k in ('product','option','qty')}],'isTest':False,'status':'IMPORTED','source':'zigzag_sync',
                'manualAcknowledgement':True,'createdAt':stamp,'updatedAt':stamp,'importedAt':stamp,'logicalCreatedAt':stamp,
                'actualSendDateKnown':False,'sourceMappings':[facts],'sourceReadAt':[stamp],'syncSignature':signature,'note':note,
                'events':[{'at':stamp,'status':'IMPORTED','note':note}]})
            counts['items']+=1
        message=f"지그재그 배송준비중 {counts['scanned']}건 / {counts['pages']}페이지 · 변경 발송 예정일 있음 {counts['changed']}건 · 새 이력 {counts['items']}건 · 동일 {counts['unchanged']}건 · 미연결 {counts['unmatched']}건 · 고객 안내 우선 {counts['protected']}건"+push_message(counts)
        s['zigzagSync']={'lastSync':stamp,**counts,'message':message}
        s['audits'].append({'at':stamp,'event':'지그재그 출고 예정일 동기화',**counts})
    if engine.archive:engine.backup_desktop(force=True,reason='zigzag-sync')
    return {**counts,'message':message,'issues':issues[:200],'lastSync':stamp}

class ZigzagSyncController:
    def __init__(self,engine,runner=None,vault=None):
        from zigzag_credentials import ZigzagAccounts
        self.engine=engine;self.runner=runner;self.accounts=ZigzagAccounts(engine.store.directory,vault)
        self.lock=threading.RLock();self.stop=threading.Event();self.thread=None
        self.job={'phase':'idle','message':'동기화를 누르면 배송준비중 전체 목록의 변경 발송 예정일을 읽습니다.'}
    def status(self):
        with self.lock:return {**copy.deepcopy(self.job),'running':bool(self.thread and self.thread.is_alive()),'lastSync':self.engine.store.read().get('zigzagSync',{}).get('lastSync','')}
    def settings(self):return self.accounts.info()
    def save(self,username,password,shop='nuavu'):
        with self.lock:
            if self.thread and self.thread.is_alive():raise ZigzagSyncError('작업 중에는 계정을 변경할 수 없습니다.')
            return self.accounts.save(username,password,shop)
    def _begin(self,message,**job):
        if self.thread and self.thread.is_alive():raise ZigzagSyncError('지그재그 작업이 이미 진행 중입니다.')
        account=self.accounts.for_login();self.stop.clear()
        try:
            from aftersales_data import shop as _shop;account={**account,'shopName':_shop(self.engine.store.read())['shopName']}   # 입점 스토어 선택용
        except Exception:pass
        self.job={'id':secrets.token_urlsafe(16),'phase':'running','message':message,**job}
        return account
    def start(self):
        with self.lock:
            account=self._begin('전용 Chrome에서 지그재그 파트너센터를 엽니다.',push=False)
            self.thread=threading.Thread(target=self._run,args=(account,None),daemon=True);self.thread.start()
            return self.status()
    def start_push_only(self,keys):
        keys=[k for k in dict.fromkeys(keys or []) if isinstance(k,str)]
        if not keys:raise ZigzagSyncError('지그재그 배송연기 안내할 주문상품이 없습니다.')
        with self.lock:
            account=self._begin('메시지 없는 안내 → 지그재그 배송연기 안내를 시작합니다.',push=True,pushOnly=True,keys=len(keys))
            self.thread=threading.Thread(target=self._run,args=(account,keys),daemon=True);self.thread.start()
            return self.status()
    def start_push_all(self):
        """Dialog button: retry/send 배송연기 안내 for every Zigzag row the app has a delay notice for."""
        from ably_sync import app_delay_notice
        s=self.engine.store.read()
        keys=[r['key'] for r in s['rows'] if r.get('active') and r.get('seller')==ZIGZAG and app_delay_notice(s,r['key'])]
        if not keys:raise ZigzagSyncError('앱에 배송지연 안내 이력이 있는 지그재그 주문이 없습니다.')
        return self.start_push_only(keys)
    def progress(self,message):
        with self.lock:self.job['message']=message
    def planner_for(self,keys):
        def planner(items):
            from domain import today
            targets,skipped=plan_pushes(self.engine.store.read(),items,keys,today())
            with self.lock:self.job['planned']={'targets':len(targets),'skipped':len(skipped)}
            return targets,skipped
        return planner
    def _record_partial(self,pushes):
        if not pushes:return ''
        from domain import now
        with self.engine.network_lock,self.engine.store.edit() as s:counts=record_pushes(s,pushes,now())
        if self.engine.archive:self.engine.backup_desktop(force=True,reason='zigzag-push')
        return push_message(counts)
    def _run(self,account,keys):
        push_only=keys is not None
        try:
            from zigzag_browser import run
            runner=self.runner or run
            snapshot=runner(account,self.stop,self.progress,self.planner_for(keys) if push_only else None,push_only)
            with self.lock:
                if self.stop.is_set() and not any(p.get('status')=='sent' for p in (snapshot.get('pushes') or [])):raise ZigzagCancelled('지그재그 작업을 중단했습니다. 수집한 자료는 반영하지 않았습니다.')
                if push_only:
                    pushes=validate_pushes(snapshot.get('pushes'))
                    from domain import now
                    with self.engine.network_lock,self.engine.store.edit() as s:counts=record_pushes(s,pushes,now())
                    if pushes and self.engine.archive:self.engine.backup_desktop(force=True,reason='zigzag-push')
                    held=[p for p in pushes if p['status']=='skipped']
                    message=(push_message(counts).lstrip(' ·') if counts['pushed'] or counts['pushFailed'] or counts['pushSkipped'] else '지그재그에 배송연기 안내할 대상이 없습니다'+(' (규칙상 제외 '+str(len(held))+'건: '+' / '.join(dict.fromkeys(p['reason'] for p in held if p.get('reason')))[:300]+')' if held else ''))+' · 지그재그 변경 발송 예정일은 가져오지 않았습니다.'
                    result={'counts':counts,'issues':[{'itemId':p['itemId'],'reason':('[규칙] ' if p['quiet'] else '')+p.get('reason','')} for p in pushes if p['status']!='sent'][:200]}
                else:
                    result=apply_snapshot(self.engine,snapshot);message=result['message']
                self.job.update(phase='done',message=message,result=result)
            job_alert(self.engine,'지그재그 배송연기 안내 완료' if push_only else '지그재그 출고 예정일 동기화 완료',message)
            blocked=[p for p in (snapshot.get('pushes') or []) if isinstance(p,dict) and p.get('status') in ('failed','skipped') and not p.get('quiet')]
            if blocked:
                lines=[f"상품주문번호 {p.get('itemId','')} · {'실패' if p.get('status')=='failed' else '보류'} · {p.get('reason','')}" for p in blocked[:15]]
                job_alert(self.engine,f'지그재그 배송연기 안내 막힘 {len(blocked)}건','\n'.join(lines)+('\n…' if len(blocked)>15 else ''),'error')
        except ZigzagPushAborted as exc:
            extra=self._record_partial(exc.pushes)
            with self.lock:self.job.update(phase='error',message=str(exc)+extra)
            job_alert(self.engine,'지그재그 작업 중단 (일부 기록)',str(exc)+extra,'error')
        except Exception as exc:
            detail='' if isinstance(exc,ZigzagError) else f' ({type(exc).__name__}: {self._safe(str(exc),account)})'
            with self.lock:self.job.update(phase='cancelled' if self.stop.is_set() else 'error',message=str(exc) if isinstance(exc,ZigzagError) else '지그재그 화면을 처리하지 못했습니다. 기존 이력을 유지합니다. 다시 실행하세요.'+detail+(' · 마지막 단계: '+self.job.get('message','') if self.job.get('message') else ''))
            if not self.stop.is_set():job_alert(self.engine,'지그재그 배송연기 안내 실패' if push_only else '지그재그 출고 예정일 동기화 실패',self.job.get('message',''),'error')
        finally:account.clear()
    @staticmethod
    def _safe(text,account):
        line=(text or '').splitlines()[0] if text else ''
        for secret in (account.get('password',''),account.get('username','')):
            if secret:line=line.replace(secret,'***')
        return line[:200]
    def cancel(self):
        with self.lock:
            if not (self.thread and self.thread.is_alive()):raise ZigzagSyncError('진행 중인 지그재그 작업이 없습니다.')
            self.stop.set();self.job['message']='중단 요청을 보냈습니다. 현재 단계가 끝나면 멈춥니다.'
            return self.status()
