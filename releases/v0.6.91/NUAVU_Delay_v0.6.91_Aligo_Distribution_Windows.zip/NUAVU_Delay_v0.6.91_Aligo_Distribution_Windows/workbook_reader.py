"""Bounded, read-only OOXML import. No macros, formulas, links or images executed.
Only cached cell values are used; caller validates domain columns. Stdlib only.
"""
from __future__ import annotations
import io, re, zipfile, posixpath, unicodedata
from xml.etree import ElementTree as ET
from datetime import date, datetime, timedelta

MAX_FILE=20*1024*1024
NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
REL='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
class WorkbookError(ValueError):pass

def text(v):
    return unicodedata.normalize('NFKC',str(v if v is not None else '')).replace('_x000D_','').strip()

def xml(raw):
    if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():raise WorkbookError('외부 XML 선언은 읽지 않습니다.')
    return ET.fromstring(raw)

def read_xlsx(raw):
    if len(raw)>MAX_FILE:raise WorkbookError('엑셀은 20MB 이하로 선택하세요.')
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            infos=z.infolist()
            if len(infos)>10000 or sum(i.file_size for i in infos)>160*1024*1024:raise WorkbookError('엑셀 압축 해제 크기가 너무 큽니다.')
            strings=[]
            if 'xl/sharedStrings.xml' in z.namelist():
                strings=[''.join(e.itertext()) if False else ''.join(t.text or '' for t in e.findall('.//s:t',NS)) for e in xml(z.read('xl/sharedStrings.xml')).findall('s:si',NS)]
            wb=xml(z.read('xl/workbook.xml'));prop=wb.find('s:workbookPr',NS)
            epoch1904=prop is not None and prop.get('date1904') in ('1','true')
            rels={r.get('Id'):r.get('Target') for r in xml(z.read('xl/_rels/workbook.xml.rels')) if r.get('TargetMode')!='External'}
            result=[]
            for sheet in wb.findall('s:sheets/s:sheet',NS):
                target=rels.get(sheet.get(REL),'')
                path=posixpath.normpath(target.lstrip('/') if target.startswith('/') else 'xl/'+target)
                if not path.startswith('xl/') or path not in z.namelist():raise WorkbookError('시트 위치가 올바르지 않습니다.')
                tree=xml(z.read(path));cells=[];maxr=0;maxc=0
                for node in tree.findall('s:sheetData/s:row/s:c',NS):
                    ref=node.get('r','');m=re.fullmatch(r'([A-Z]{1,3})([1-9]\d*)',ref)
                    if not m:continue
                    row=int(m[2]);col=0
                    for ch in m[1]:col=col*26+ord(ch)-64
                    if row>20001 or col>100:raise WorkbookError('지원 범위(20,000행·100열)를 넘는 엑셀입니다.')
                    kind=node.get('t');v=node.find('s:v',NS);val=v.text if v is not None else None
                    if kind=='inlineStr':val=''.join(t.text or '' for t in node.findall('s:is//s:t',NS))
                    elif kind=='s':
                        if val is not None:val=strings[int(val)]
                    elif kind=='b':val=val=='1'
                    elif kind=='e':val='#EXCEL_ERROR:'+str(val)
                    elif val is not None and kind not in ('str','d'):
                        try:
                            n=float(val);val=int(n) if n.is_integer() else n
                        except ValueError:pass
                    if val is None and node.find('s:f',NS) is not None:val='#UNCACHED_FORMULA'
                    if val is not None:
                        cells.append((row-1,col-1,val));maxr=max(maxr,row);maxc=max(maxc,col)
                if maxr*maxc>1500000:raise WorkbookError('셀 수가 너무 많은 시트입니다.')
                matrix=[[None]*maxc for _ in range(maxr)]
                for r,c,v in cells:matrix[r][c]=v
                result.append({'name':text(sheet.get('name')),'rows':matrix,'epoch1904':epoch1904})
            return result
    except WorkbookError:raise
    except (ValueError,KeyError,IndexError,ET.ParseError,zipfile.BadZipFile,RuntimeError,OverflowError) as e:
        raise WorkbookError('엑셀을 해석하지 못했습니다. Excel에서 .xlsx로 저장한 원본을 선택하세요.') from e

def cell(row,i):return row[i] if i<len(row) else None

def as_date(value,year,epoch1904=False):
    if isinstance(value,datetime):return value.date()
    if isinstance(value,date):return value
    if isinstance(value,bool):return None
    if isinstance(value,(float,int)):
        if not 1<=value<=100000:return None
        return date(1904,1,1)+timedelta(days=int(value)) if epoch1904 else date(1899,12,30)+timedelta(days=int(value))
    s=text(value)
    if not s:return None
    m=re.fullmatch(r'(\d{4})[-/.년\s]+(\d{1,2})[-/.월\s]+(\d{1,2})(?:일)?(?:\s.*|T.*)?',s)
    if not m:
        m2=re.fullmatch(r'(\d{1,2})[-/.월\s]+(\d{1,2})(?:일)?(?:\s*\([월화수목금토일]\))?',s)
        if m2:m=(str(year),m2[1],m2[2])
    try:return date(int(m[1]),int(m[2]),int(m[3])) if hasattr(m,'group') else date(*map(int,m)) if m else None
    except (ValueError,TypeError):return None

def integer(value):
    if isinstance(value,bool):return None
    try:
        n=float(text(value).replace(',',''))
        return int(n) if n.is_integer() and 0<=n<=1000000 else None
    except (ValueError,OverflowError):return None
