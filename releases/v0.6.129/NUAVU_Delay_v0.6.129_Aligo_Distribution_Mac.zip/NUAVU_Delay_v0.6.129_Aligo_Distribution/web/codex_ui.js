'use strict';
// 2026-10-24 Codex 대화 — 22:05 추가 요청: Codex 데스크톱 구조 (왼쪽 대화 목록 · 가운데 대화 · 하단 고정 입력창 · 필요할 때만 작업 파일).
// 화면 → window.pywebview.api.codex(token, 명령, 값) → 이 컴퓨터 Python (원격 화면도 remote_bridge.js 로 같은 이 컴퓨터 서비스).
// 입력창은 한 번만 만들고 다시 그리지 않는다 → 입력 중인 글·한글 조합·커서 유지.
// 2026-10-25: 오른쪽 아래 버튼(채널톡처럼) → 작게 보기(오른쪽 위에 뜨는 창) / 크게 보기(전체). 03:10 요청: 상단 빠른 질문 바는 그대로 두고, 앱 화면 레이아웃(폭)은 바꾸지 않는다.
// 앱 도구 중 화면 계산이 필요한 것(상태 필터·카드 숫자·주문 검색·자동 불러오기)은 여기서 화면의 같은 함수로 처리한다.
(()=>{
 const $$=id=>document.getElementById(id);
 const remote=typeof REMOTE_VIEW!=='undefined'&&REMOTE_VIEW;
 const SVG={
  send:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V5M5.5 11.5 12 5l6.5 6.5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  stop:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="7" y="7" width="10" height="10" rx="2" fill="currentColor"/></svg>',
  login:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 16 16 8M10 8h6v6" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  plus:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  clock:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M12 7.5V12l3 2" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
  open:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 6.5h15v9h-8l-4 3v-3h-3z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
  chat:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 6.5A2.5 2.5 0 0 1 7.5 4h9A2.5 2.5 0 0 1 19 6.5v7a2.5 2.5 0 0 1-2.5 2.5H11l-4.5 3.5V16h0A2 2 0 0 1 5 14z" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"/><path d="M9 10.2c.8 1 1.8 1.5 3 1.5s2.2-.5 3-1.5" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>',
  close:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.5 6.5l11 11M17.5 6.5l-11 11" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>',
  down:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5.5 12.5 12 19l6.5-6.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>'};
 const ui={drafts:new Map(),pending:null,brief:null,open:false,files:false,side:true,parts:{},answers:new Map(),opened:new Set(),composing:false,deferred:null,lastSession:'',atBottom:true,mode:'mini',seenRev:-1,unread:false,doneCalls:new Set(),watch:null};
 try{ui.side=localStorage.getItem('nuavu.cx.side')!=='closed';ui.mode=localStorage.getItem('nuavu.cx.mode')==='max'?'max':'mini';}catch(_){}
 // ---------- 오른쪽 아래 버튼 (채널톡처럼) ----------
 const bar=document.createElement('button');bar.type='button';bar.id='cxLauncher';bar.className='cx-launcher';bar.setAttribute('aria-label','Codex 대화 열기');bar.title='Codex 대화 (ChatGPT 구독)';
 bar.innerHTML='<span class="cx-launch-open">'+SVG.chat+'</span><span class="cx-launch-close">'+SVG.close+'</span><span class="cx-launch-dot" aria-hidden="true"></span>';
 // ---------- 상단 빠른 질문 바 (이전 그대로 · 업무 화면의 시작점) ----------
 const qbar=document.createElement('div');qbar.id='cx-quick';qbar.className='siri-bar';qbar.setAttribute('aria-label','Codex 빠른 질문');
 qbar.innerHTML='<div class="siri-inner"><span class="siri-orb" aria-hidden="true"></span><div class="siri-entry"><label class="sr-only" for="cx-draft">Codex에게 질문</label><textarea id="cx-draft" rows="1" maxlength="16000" placeholder="무엇을 도와드릴까요? 안내건 분석·안내문 다듬기·엑셀 확인을 적어 주세요."></textarea><span id="cx-quick-hint" class="siri-hint">Codex · ChatGPT 구독 · 실행은 이 컴퓨터에서</span></div><div class="siri-controls"><button type="button" class="siri-open" data-cx-local="open" aria-label="대화창 열기" title="대화창 열기">'+SVG.open+'<span>대화 보기</span></button><button type="button" id="cx-quick-send" class="siri-send" data-cx="cxSend" data-src="quick" aria-label="메시지 보내기" title="Enter로 보내기 · Shift+Enter 줄바꿈">'+SVG.send+'</button></div></div>';
 // ---------- 대화창 (한 번만 만든다) ----------
 const view=document.createElement('div');view.id='cxView';view.className='cx-view';view.hidden=true;view.setAttribute('role','dialog');view.setAttribute('aria-label','Codex 대화');
 view.innerHTML='<div class="cx-app"><div class="cx-side" id="cxSide" role="navigation" aria-label="대화 목록"></div><div class="cx-main" role="main"><div class="cx-head" id="cxHead"></div>'
  +'<div class="cx-messages" id="cxMessages" role="log" aria-label="대화 내용" tabindex="0"><div class="cx-transcript" id="cxTranscript"></div></div>'
  +'<button type="button" class="cx-newmsg" id="cxNewMsg" hidden>'+SVG.down+'<span>새 메시지</span></button>'
  +'<div class="cx-compose-wrap"><div id="cxAlert"></div><div id="cxPicker"></div><div class="cx-composer"><div class="cx-chips" id="cxChips"></div><label class="sr-only" for="cx-compose">메시지</label>'
  +'<textarea id="cx-compose" rows="2" maxlength="16000" placeholder="추가로 질문하거나 수정할 내용을 적어 주세요. (Enter 보내기 · Shift+Enter 줄바꿈)"></textarea>'
  +'<div class="cx-tools"><button type="button" class="cx-icon" data-cx="cxBrowse" data-value="" aria-label="이 컴퓨터 파일 첨부" title="이 컴퓨터 파일 첨부">'+SVG.plus+'</button>'
  +'<button type="button" class="cx-tool" data-cx="cxResults">'+SVG.clock+'<span>최근 자료</span></button><button type="button" class="cx-tool" id="cxModelBtn" data-cx-local="more">모델</button>'
  +'<span class="cx-status" id="cxStatus" role="status"></span><button type="button" class="cx-send" id="cx-compose-send" data-cx="cxSend" data-src="compose" aria-label="메시지 보내기" title="Enter로 보내기 · Shift+Enter 줄바꿈">'+SVG.send+'</button></div></div>'
  +'<div class="cx-hint"><span>Enter로 보내기 · Shift+Enter 줄바꿈 · 이 컴퓨터에서 실행</span><span id="cxUsage"></span></div></div></div>'
  +'<div class="cx-files" id="cxFiles" role="complementary" aria-label="작업 파일"></div><div id="cxBrowser"></div></div>';
 function mount(){const act=$$('activityBar');if(act)act.after(qbar);else document.querySelector('main')?.prepend(qbar);document.body.append(view,bar);}
 mount();
 const bridgeApi=()=>window.pywebview?.api;
 async function call(action,value){
  const a=bridgeApi();if(typeof token==='undefined'||!a?.codex)throw Error('앱 연결을 기다리는 중입니다.');
  const r=await a.codex(token,action,value===undefined?null:value);
  if(r&&r.error)throw Error(r.error);return r||{};
 }
 const say=(m,err)=>{if(typeof toast==='function')toast(m,err);};
 // ---------- 화면 배율: 업무 화면 배율(예: 60%)과 상관없이 대화창은 100% ----------
 function pageZoom(){return parseFloat(getComputedStyle(document.documentElement).zoom)||1;}
 function unzoom(){const z=pageZoom();const v=z&&z!==1?String(1/z):'';view.style.zoom=v;bar.style.zoom=v;}
 function panelWidth(){return Math.max(320,Math.min(420,Math.round(innerWidth*0.34)));}
 // 03:10 요청: 앱 화면 폭은 이전과 같게 (오른쪽 비켜두기 없음). 버튼 자리만 맨 아래 여백으로 두어 마지막 줄까지 버튼 위로 올려 볼 수 있게 한다.
 function reserve(){
  const z=pageZoom();document.documentElement.style.setProperty('--cx-reserve-b',(72/z)+'px');document.body.classList.add('cx-reserve');
  view.style.setProperty('--cx-panel-w',panelWidth()+'px');
 }
 // ---------- 초안 (두 입력칸이 같은 대화의 같은 초안) ----------
 const boxes=()=>[$$('cx-draft'),$$('cx-compose')];
 function setDraft(text,except){ui.drafts.set(ui.brief?.session||'',text);for(const b of boxes())if(b!==except&&b.value!==text)b.value=text;resizeAll();}
 function resize(d,min,max){d.style.height='auto';d.style.height=Math.min(max,Math.max(min,d.scrollHeight))+'px';}
 function resizeAll(){resize($$('cx-draft'),23,96);resize($$('cx-compose'),46,138);}
 function quick(brief){
  if(!brief)return;const prev=ui.brief?.session;ui.brief=brief;
  if(prev&&prev!==brief.session){const t=ui.drafts.get(brief.session)||'';for(const b of boxes())b.value=t;}
  const p=ui.pending,last=brief.lastUser;
  // 보낸 글은 앱이 새 사용자 메시지로 받아들인 것을 확인한 뒤에만 지운다 (실패하면 남김)
  if(p&&p.id===brief.session&&last&&last.id!==p.previous&&last.text===p.text){if((ui.drafts.get(brief.session)||'').trim()===p.text&&!ui.composing)setDraft('');ui.pending=null;}
  for(const e of [bar,qbar]){e.classList.toggle('working',!!brief.busy);e.classList.toggle('problem',!!brief.error);}
  if(!ui.open&&ui.seenRev>=0&&brief.revision!==ui.seenRev&&!brief.busy&&brief.lastUser)ui.unread=true;
  if(ui.open)ui.seenRev=brief.revision;bar.classList.toggle('unread',ui.unread&&!ui.open);
  if(brief.uiCalls&&brief.uiCalls.length)runUiCalls(brief.uiCalls);
  for(const b of [$$('cx-quick-send'),$$('cx-compose-send')]){
   b.dataset.cx=brief.running?'cxStop':brief.ready?'cxSend':'cxLogin';b.innerHTML=brief.running?SVG.stop:brief.ready?SVG.send:SVG.login;
   b.disabled=!!brief.busy&&!brief.running;b.classList.toggle('stop',!!brief.running);
   const t=brief.running?'작업 중지':brief.ready?'메시지 보내기 (Enter)':'ChatGPT 구독 연결 (이 컴퓨터 브라우저에서 로그인)';b.setAttribute('aria-label',t);b.title=t;
  }
  $$('cx-quick-hint').textContent=brief.busy||brief.error?brief.message:brief.ready?'Codex · 이 컴퓨터에서 실행 · Enter로 보내기 · Shift+Enter 줄바꿈 · 대화: '+brief.title:'Codex · ChatGPT 구독 연결이 필요해요';
  bar.title=brief.busy||brief.error?'Codex · '+brief.message:'Codex 대화 (ChatGPT 구독)'+(brief.ready?'':' · 연결 필요');
  resizeAll();
 }
 // ---------- 부분 갱신 ----------
 function nearBottom(){const m=$$('cxMessages');return m.scrollHeight-m.clientHeight-m.scrollTop<80;}
 function setPart(id,key,html){if(ui.parts[key]===html)return false;ui.parts[key]=html;$$(id).innerHTML=html;return true;}
 function paint(r){
  if(r.brief)quick(r.brief);
  const P=r.parts;if(!P)return;
  const typing=document.activeElement&&view.contains(document.activeElement)&&document.activeElement.matches('[data-cx-answer],select');
  if(typing||ui.composing&&document.activeElement?.closest('#cxMessages')){ui.deferred=r;return;}
  const sessionChanged=P.session!==ui.lastSession;ui.lastSession=P.session;
  const stick=sessionChanged||nearBottom();
  // 답변 입력칸·열린 상세 보존
  view.querySelectorAll('[data-cx-answer]').forEach(e=>ui.answers.set(P.session+':'+e.dataset.cxAnswer,e.value));
  const openKeys=new Set([...view.querySelectorAll('details[open]')].map(d=>(d.closest('.cx-file')?.querySelector('b')?.textContent||'')+'|'+(d.querySelector('summary')?.textContent||'')));
  const moreOpen=!!view.querySelector('.cx-more[open]');
  setPart('cxSide','side',P.side);
  const headChanged=setPart('cxHead','head',P.head);
  const changed=setPart('cxTranscript','messages',P.messages);
  setPart('cxAlert','alert',P.alert||'');setPart('cxPicker','picker',P.picker);setPart('cxChips','chips',P.chips);setPart('cxFiles','files',P.files);setPart('cxBrowser','browser',P.browser);
  view.querySelectorAll('details').forEach(d=>{const k=(d.closest('.cx-file')?.querySelector('b')?.textContent||'')+'|'+(d.querySelector('summary')?.textContent||'');if(openKeys.has(k))d.open=true;});
  if(headChanged&&moreOpen)view.querySelector('.cx-more')?.setAttribute('open','');
  view.querySelectorAll('[data-cx-answer]').forEach(e=>e.value=ui.answers.get(P.session+':'+e.dataset.cxAnswer)||'');
  $$('cxModelBtn').textContent=P.composer.model;$$('cxStatus').textContent=P.composer.status||'';$$('cxStatus').classList.toggle('error',!!P.composer.error);$$('cxUsage').textContent=P.composer.usage||'';
  layout();
  const m=$$('cxMessages');
  if(changed){if(stick){m.scrollTop=m.scrollHeight;$$('cxNewMsg').hidden=true;}else $$('cxNewMsg').hidden=false;}
 }
 function layout(){
  const app=view.querySelector('.cx-app');app.classList.toggle('side-hidden',!ui.side);app.classList.toggle('files-open',ui.files);
  view.querySelectorAll('[data-cx-local="files"]').forEach(b=>b.setAttribute('aria-expanded',String(ui.files)));
 }
 async function status(activate){
  try{paint(await call('cxStatus',{activate:!!activate,remote}));}
  catch(e){$$('cxStatus').textContent=e.message;$$('cxStatus').classList.add('error');}
 }
 function applyMode(){
  view.classList.toggle('cx-mini',ui.mode==='mini');view.classList.toggle('cx-max',ui.mode==='max');
  document.body.classList.toggle('cx-open',ui.open&&ui.mode==='max');document.body.classList.toggle('cx-docked',ui.open&&ui.mode==='mini');
  bar.classList.toggle('on',ui.open);bar.setAttribute('aria-label',ui.open?'Codex 대화 닫기':'Codex 대화 열기');bar.hidden=ui.open&&ui.mode==='max';
  reserve();
 }
 function openView(mode){if(mode)ui.mode=mode;ui.open=true;ui.unread=false;unzoom();view.hidden=false;applyMode();ui.parts={};status(true);setTimeout(()=>{const c=$$('cx-compose');c.value=ui.drafts.get(ui.brief?.session||'')||c.value;resizeAll();c.focus();const m=$$('cxMessages');if(m){m.scrollTop=m.scrollHeight;$$('cxNewMsg').hidden=true;}},60);}
 function closeView(){ui.open=false;view.hidden=true;applyMode();}
 function toggleSize(){view.querySelector('.cx-app')?.classList.remove('side-mobile');ui.mode=ui.mode==='max'?'mini':'max';try{localStorage.setItem('nuavu.cx.mode',ui.mode);}catch(_){}applyMode();}
 // ---------- 명령 ----------
 async function act(button){
  const action=button.dataset.cx;let value=button.dataset.value;
  if(action==='cxSend'){
   const box=button.dataset.src==='quick'?$$('cx-draft'):$$('cx-compose');const text=box.value.trim(),brief=ui.brief;
   if(!text){box.focus();return;}
   if(!brief?.session){say('대화 연결을 확인해 주세요.',true);return;}
   // 2026-10-25 실화면: Enter 를 두 번 누르면 두 번째가 '작업 중' 으로 거절되며 입력칸에 글이 남았다 → 보내는 중에는 다시 보내지 않고, 입력칸은 바로 비운다 (실패하면 되돌림)
   if(ui.pending&&ui.pending.id===brief.session&&Date.now()-ui.pending.at<20000)return;
   ui.pending={id:brief.session,text,previous:brief.lastUser?.id||null,at:Date.now()};value={text};setDraft('');
  }else if(action==='cxSettings')value={model:$$('cx-model')?.value,effort:$$('cx-effort')?.value};
  else if(action==='cxAnswer'){const p=button.closest('[data-cx-request]');value={request:p.dataset.cxRequest,answers:Object.fromEntries([...p.querySelectorAll('[data-cx-answer]')].map(e=>[e.dataset.cxAnswer,e.value]))};}
  else if(action==='cxApply'||action==='cxExport'||action==='cxOpenFile'||action==='cxRevealFile'){try{value=JSON.parse(value);}catch(_){say('변경 확인을 다시 눌러 주세요.',true);return;}}
  // 원본을 바꾸는 버튼은 두 번 눌러 확인 (시스템 확인창 대신 — 버튼 글자로 무엇이 일어나는지 보여 줌)
  if(button.classList.contains('cx-arm')&&!button.classList.contains('armed')){
   const label=button.textContent;button.classList.add('armed');button.textContent=action==='cxApply'?'한 번 더 누르면 원본에 반영 (백업 후)':'한 번 더 누르면 반영 전으로 되돌림';
   setTimeout(()=>{if(button.isConnected){button.classList.remove('armed');button.textContent=label;}},4000);return;
  }
  if(action==='cxAttach'||action==='cxReview'){ui.files=true;if(ui.mode==='mini')toggleSize();}
  if(action==='cxSelect'||action==='cxNew'){ui.files=false;const cur=ui.brief?.session;if(cur)ui.drafts.set(cur,$$('cx-compose').value);}
  if((action==='cxBrowse'||action==='cxLogin'||action==='cxResults')&&!ui.open)openView();
  button.disabled=true;
  try{
   const r=await call(action,value);paint(r);
   // 03:40 실화면: 상단 바에서 보낼 때 대화창을 먼저 열면 '연결 확인'이 먼저 시작돼 질문이 거절됐다 → 보낸 다음에 연다
   if(action==='cxSend'&&button.dataset.src==='quick'&&!ui.open)openView();
   if(action==='cxApplySettings'){try{if(typeof refresh==='function')await refresh();}catch(_){}window.dispatchEvent(new CustomEvent('nuavu-auto-state'));}
   if(action==='cxSelect'||action==='cxNew'){const t=ui.drafts.get(r.brief?.session)||'';for(const b of boxes())b.value=t;resizeAll();$$('cx-compose').focus();}
   if(action==='cxOpen')say(remote?'이 컴퓨터 화면에서 수정본을 열었습니다.':'수정본을 열었습니다.');
   if(action==='cxLogin'&&remote)say('로그인 창은 이 컴퓨터 브라우저에 열립니다.');
  }catch(e){say(e.message,true);if(action==='cxSend'){const p=ui.pending;ui.pending=null;if(p&&!$$('cx-compose').value.trim())setDraft(p.text);}}   // 실패하면 입력한 글을 되돌림
  finally{button.disabled=false;tick(true);}
 }
 document.addEventListener('click',e=>{
  if(e.target.closest('#cxLauncher')){ui.open?closeView():openView();return;}
  const b=e.target.closest('[data-cx]');if(b&&(view.contains(b)||qbar.contains(b))){e.preventDefault();act(b);return;}
  const l=e.target.closest('[data-cx-local]');if(!l)return;
  const k=l.dataset.cxLocal;
  if(k==='open'){ui.open?closeView():openView();return;}
  if(k==='close'){closeView();return;}
  if(k==='size'){toggleSize();return;}
  if(k==='side'){if(innerWidth<=650||ui.mode==='mini')view.querySelector('.cx-app').classList.toggle('side-mobile');else{ui.side=!ui.side;try{localStorage.setItem('nuavu.cx.side',ui.side?'open':'closed');}catch(_){}layout();}return;}
  if(k==='files'){ui.files=!ui.files;if(ui.files&&ui.mode==='mini')toggleSize();layout();return;}
  if(k==='more'){const d=view.querySelector('.cx-more');if(d)d.open=!d.open;return;}
  if(k==='proposal'){openProposal(l);return;}
 });
 view.addEventListener('click',e=>{const app=view.querySelector('.cx-app');if(ui.mode==='mini'&&app.classList.contains('side-mobile')&&!e.target.closest('.cx-side,[data-cx-local="side"]'))app.classList.remove('side-mobile');   // 목록 밖을 누르면 닫기
  const t=e.target.closest('.cx-thread-main,[data-cx="cxNew"]');if(t&&(innerWidth<=650||ui.mode==='mini'))view.querySelector('.cx-app').classList.remove('side-mobile');});
 $$('cxNewMsg').addEventListener('click',()=>{const m=$$('cxMessages');m.scrollTop=m.scrollHeight;$$('cxNewMsg').hidden=true;});
 $$('cxMessages').addEventListener('scroll',()=>{if(nearBottom())$$('cxNewMsg').hidden=true;});
 document.addEventListener('input',e=>{if(e.target.id==='cx-compose'||e.target.id==='cx-draft')setDraft(e.target.value,e.target);});
 document.addEventListener('compositionstart',e=>{if(view.contains(e.target)||qbar.contains(e.target))ui.composing=true;});
 document.addEventListener('compositionend',e=>{if(view.contains(e.target)||qbar.contains(e.target)){ui.composing=false;setTimeout(flush,0);}});
 document.addEventListener('focusout',e=>{if(view.contains(e.target))setTimeout(flush,0);});
 function flush(){const r=ui.deferred;if(!r)return;const busyInput=document.activeElement&&view.contains(document.activeElement)&&document.activeElement.matches('[data-cx-answer],select');if(ui.composing||busyInput)return;ui.deferred=null;paint(r);}
 document.addEventListener('keydown',e=>{
  if((e.target.id==='cx-compose'||e.target.id==='cx-draft')&&!e.isComposing&&e.keyCode!==229&&e.key==='Enter'&&!e.shiftKey&&!e.altKey){   // 2026-10-24: Enter = 보내기, Shift+Enter = 줄바꿈 (한글 조합 중 Enter는 보내지 않음)
   e.preventDefault();const b=e.target.id==='cx-draft'?$$('cx-quick-send'):$$('cx-compose-send');if(!b.disabled&&b.dataset.cx==='cxSend')act(b);}
  if(e.key==='Escape'&&ui.open&&!view.querySelector('.cx-picker')&&!view.querySelector('.cx-more[open]'))closeView();
 });
 window.addEventListener('resize',()=>{unzoom();reserve();});
 new MutationObserver(()=>{unzoom();reserve();}).observe(document.documentElement,{attributes:true,attributeFilter:['class']});
 // ---------- Codex 제안 → 앱의 기존 화면 (여기서는 아무것도 보내거나 바꾸지 않음) ----------
 function fire(id,value){const e=$$(id);if(!e)return;if(value!==undefined)e.value=value;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));}
 function watch(kind,proposal,count){ui.watch={kind,proposal:proposal||'',count:count||0,until:Date.now()+30*60*1000};}
 // 2026-10-26 17:02 원격 웹에서 '창이 안 뜸' → 실패 이유를 토스트 + 대화 기록(cxActionResult)으로 남긴다 (맥에서도 보이게)
 function report(p,msg){say(msg,true);try{call('cxActionResult',{kind:'open_failed',message:'카드 열기 실패 · '+msg+' ('+(remote?'원격 화면':'맥 화면')+' · '+innerWidth+'px)',count:0,proposal:p?.proposal||''}).catch(()=>{});}catch(_){}}
 async function openProposal(button){
  let p;try{p=JSON.parse(button.dataset.value);}catch(_){say('제안을 다시 열어 주세요.',true);return;}
  const leave=()=>{if(ui.mode==='max')closeView();};
  if(p.action==='change_dispatch'){   // 출고장 단위 출고 예상일 변경 창 (적용은 사장님이 창에서)
   if(!window.nuavuDispatchOverride){say('출고 예상일 변경 창을 열지 못했습니다. 앱을 다시 열어 주세요.',true);return;}
   leave();watch('change_dispatch',p.proposal,(p.chinaDates||[]).length);
   setTimeout(()=>{window.nuavuDispatchOverride.open({chinaDates:p.chinaDates||[],start:p.start||'',end:p.end||p.start||''});say('출고 예상일 변경 창을 열었습니다. 출고장과 날짜를 확인한 뒤 적용을 직접 눌러 주세요.');},120);return;}
  if(typeof state==='undefined'||!state?.rows||typeof selected==='undefined'){report(p,'앱 목록을 아직 불러오지 못했습니다. 잠시 뒤 다시 눌러 주세요.');return;}
  if((p.phones||[]).length&&!(p.keys||[]).length){   // 2026-10-25: 주문 목록에 없는 번호 → 수동 문자 작성 창 (번호·문구·사유 채움)
   if(!window.nuavuDirectCompose){say('수동 문자 작성 창을 열지 못했습니다. 앱을 다시 열어 주세요.',true);return;}
   leave();selected.clear();if(typeof renderSelection==='function')renderSelection();if(typeof render==='function')render();watch(p.action,p.proposal,p.phones.length);
   setTimeout(()=>{window.nuavuDirectCompose.open({phones:p.phones,message:p.message||'',title:p.title||'',reason:p.manualReason||'',sendMode:p.sendMode||''});say(`직접 입력 번호 ${p.phones.length}개로 수동 문자 작성 창을 열었습니다. 번호·문구를 확인한 뒤 ${p.sendMode==='MORNING'?'[오전 9시에 전송]':'보내기'} 버튼을 직접 눌러 주세요.`);},120);return;}
  const pick=()=>{const live=new Set(state.rows.filter(r=>r.active).map(r=>r.key));return (p.keys||[]).filter(k=>live.has(k));};
  let keys=pick();
  if(!keys.length&&typeof refresh==='function'){try{await refresh();}catch(_){}keys=pick();}   // 화면 목록이 낡았으면 새로 받아 한 번 더
  if(!keys.length){report(p,`제안한 상품 ${(p.keys||[]).length}개가 지금 미출고 목록(${state.rows.filter(r=>r.active).length}행)에 없습니다. 주문을 다시 불러온 뒤 다시 물어봐 주세요.`);return;}
  leave();selected.clear();keys.forEach(k=>selected.add(k));if(typeof renderSelection==='function')renderSelection();if(typeof render==='function')render();
  const skipped=(p.keys||[]).length-keys.length;watch(p.action,p.proposal,keys.length);
  setTimeout(()=>{
   if(p.action==='no_send_notice'){$$('noSendBtn')?.click();setTimeout(()=>{if(p.dueDate)fire('noSendDue',p.dueDate);if($$('noSendType'))$$('noSendType').value=p.template||'first';},80);}
   else{
    $$('composeBtn')?.click();
    setTimeout(()=>{
     const btn={first:'firstTemplateBtn',change:'changeTemplateBtn',manual:'manualTemplateBtn'}[p.template||'first'];if(btn)$$(btn)?.click();
     if(p.template==='manual'&&p.message){fire('template',p.message);if(p.title)fire('messageTitle',p.title);if(p.manualReason)fire('noticeReason',p.manualReason);if((p.phones||[]).length)fire('directPhones',p.phones.join('\n'));}
     if(p.dueDate)fire('dueDate',p.dueDate);
     if(p.sendMode==='MORNING'&&window.nuavuDirectCompose?.suggest)window.nuavuDirectCompose.suggest('MORNING');
    },80);
   }
   say(`${keys.length}개 상품을 선택했습니다${skipped?` (목록에 없는 ${skipped}개 제외)`:''}. 날짜·대상${p.message?'·추천 문구':''}를 확인한 뒤 보내기/처리 버튼을 직접 눌러 주세요.`);
   setTimeout(()=>{   // 창이 정말 열렸는지 확인 — 안 열렸으면 이유를 대화에 남긴다
    const id=p.action==='no_send_notice'?'noSendDialog':'composeDialog',d=$$(id),b=$$(p.action==='no_send_notice'?'noSendBtn':'composeBtn');
    if(d&&d.open)return;
    report(p,`${p.action==='no_send_notice'?'메시지 없는 안내':'문자 작성'} 창이 열리지 않았습니다 (${!d?'창 없음':!b?'버튼 없음':b.disabled?'버튼 비활성 · 선택 '+selected.size+'개':'알 수 없음'}). 앱 목록에서 직접 선택해 주세요.`);
   },700);
  },120);
 }
 // 사장님이 카드로 연 화면에서 실제로 처리한 결과 → 대화에 기록 (앱의 api 호출 결과를 그대로 전달)
 (function wrapApi(){
  const orig=window.api;if(typeof orig!=='function'||orig.__cxWrapped)return;   // app.js 의 전역 api (이 파일 안의 bridge 함수와 다름)
  const kinds={'send':'문자·알림톡 요청','external-manual':'메시지 없는 안내 처리','dispatch-override':'출고 예상일 변경'};
  const wrapped=async function(path,data){
   const r=await orig(path,data);
   try{
    const w=ui.watch;
    if(w&&Date.now()<w.until&&kinds[path]&&!(path==='dispatch-override'&&data?.clear)){
     call('cxActionResult',{kind:kinds[path],message:kinds[path]+' · '+(r?.message||'완료'),count:w.count,proposal:w.proposal}).catch(()=>{});
     if(path!=='dispatch-override')ui.watch=null;
    }
   }catch(_){}
   return r;
  };
  wrapped.__cxWrapped=true;window.api=wrapped;   // app.js 의 api 를 그대로 감싸기 (동작은 같음)
 })();
 // ---------- 앱 도구 중 화면 계산 (화면과 같은 함수) ----------
 const maskName=n=>{n=String(n||'').trim();return n.length<=1?n:n.length===2?n[0]+'○':n[0]+'○'.repeat(n.length-2)+n.slice(-1);};
 function withFilters(f,fn){
  const ids=['search','searchField','statusFilter','activeFilter'],prev=ids.map(i=>$$(i)?.value);
  const prevSeller=typeof seller!=='undefined'?seller:'';
  try{
   if($$('search'))$$('search').value=f.search||'';if($$('searchField'))$$('searchField').value=f.field||'all';
   if($$('statusFilter'))$$('statusFilter').value=f.status||'';if($$('activeFilter'))$$('activeFilter').value=f.scope||'active';
   try{seller=f.seller||'';}catch(_){}
   return fn();
  }finally{ids.forEach((i,n)=>{if($$(i))$$(i).value=prev[n];});try{seller=prevSeller;}catch(_){}}
 }
 function sellerKey(v){v=String(v||'').trim();if(!v)return '';const all=[...new Set((state?.rows||[]).map(r=>r.seller))];return all.find(x=>x===v)||all.find(x=>x.replace('누아브 ','')===v.replace('누아브 ',''))||v;}
 function rowOut(r){
  const a=r.supplyInfo||{};
  return {key:r.key,seller:String(r.seller||'').replace('누아브 ',''),orderId:r.orderId,orderDate:r.orderDate,product:r.product,option:r.option,qty:r.qty,customer:maskName(r.buyer||r.recipient),
   active:!!r.active,noticeState:typeof rowNoticeLabel==='function'?rowNoticeLabel(r):r.color,bucket:r.bucket,dueDate:r.dueDate||'',noticeCount:r.noticeCount||0,lastNoticeAt:r.lastNoticeAt||'',
   dispatchStart:r.dispatchStart||'',dispatchEnd:r.dispatchEnd||'',receiptStart:r.receiptStart||'',receiptEnd:r.receiptEnd||'',stockSecured:!!r.stockSecured,
   allocatedQty:a.allocatedQty??null,manifestQty:a.manifestQty??null,plannedQty:a.plannedQty??null,inventoryQty:a.inventoryQty??null,supplyReason:a.reason||'',
   chinaDates:[...new Set((a.parts||[]).filter(x=>x.kind!=='inventory'&&x.path?.chinaDate).map(x=>x.path.chinaDate))],
   inventoryReady:!!r.inventoryReady,isBundle:!!r.isBundle,bundleType:r.bundleType||'',bundleSize:r.bundleSize||1,bundleReady:!!r.bundleReady,bundleDueToday:!!r.bundleDueToday,
   isExchange:!!r.isExchange,review:!!r.review,pickup:typeof pickupRecordFor==='function'&&pickupRecordFor(r)?'반품/교환 조회 기록 있음':'',
   supplyCode:a.reasonCode||'',shortQty:Math.max(0,(Number(r.qty)||0)-(Number(a.allocatedQty)||0)),incomingQty:r.incomingQty??a.incomingQty??null,
   incoming:incomingParts(r)};
 }
 // 이 주문상품에 배정된 입고 물량(출고장·진행상황)과 한국 입고/출고 예상일
 function incomingParts(r){
  return ((r.supplyInfo||{}).parts||[]).filter(p=>p.kind!=='inventory'&&p.path).map(p=>({kind:p.kind==='manifest'?'출고장':'진행상황',qty:p.allocated||0,chinaDate:p.path.chinaDate||'',
   receiptStart:p.path.receiptStart||'',receiptEnd:p.path.receiptEnd||'',dispatchStart:p.path.koreaStart||'',dispatchEnd:p.path.koreaEnd||''}));
 }
 const isoDay=d=>{const z=new Date(d.getTime()-d.getTimezoneOffset()*60000);return z.toISOString().slice(0,10);};
 function weekRange(today,next){
  const t=new Date((today||isoDay(new Date()))+'T12:00:00');const dow=(t.getDay()+6)%7;  // 월=0
  const mon=new Date(t);mon.setDate(t.getDate()-dow+(next?7:0));const sun=new Date(mon);sun.setDate(mon.getDate()+6);
  return [isoDay(mon),isoDay(sun)];
 }
 const overlaps=(s,e,from,to)=>{s=s||e;e=e||s;return !!s&&s<=to&&e>=from;};
 const itemKey=r=>String(r.product||'')+'|'+String(r.option||'');
 const lite=r=>{const o=rowOut(r);return {key:o.key,seller:o.seller,orderId:o.orderId,orderDate:o.orderDate,customer:o.customer,product:o.product,option:o.option,qty:o.qty,
   allocatedQty:o.allocatedQty,shortQty:o.shortQty,dueDate:o.dueDate,noticeState:o.noticeState,dispatchStart:o.dispatchStart,dispatchEnd:o.dispatchEnd,supplyReason:o.supplyReason,
   inventoryReady:o.inventoryReady,isBundle:o.isBundle,incoming:o.incoming};};
 const UI_TOOLS={
  app_overview(){
   if(typeof state==='undefined'||!state)throw Error('앱 목록을 아직 불러오지 못했습니다.');
   const cards=[...document.querySelectorAll('.card')].map(c=>({label:(c.querySelector('span')?.textContent||'').trim(),count:(c.querySelector('strong')?.textContent||'').trim(),detail:(c.querySelector('small')?.textContent||'').trim().slice(0,160)})).filter(c=>c.label);
   const opts=[...($$('statusFilter')?.options||[])].map(o=>({value:o.value,label:o.textContent.trim()}));
   const statusFilters=opts.map(o=>({...o,count:typeof filtered==='function'?withFilters({status:o.value,scope:'active'},()=>filtered().filter(r=>r.active).length):null}));
   const active=state.rows.filter(r=>r.active);
   return {ok:true,today:state.today,activeItems:active.length,activeOrders:new Set(active.map(r=>r.seller+'|'+r.orderId)).size,
    lastImportAt:state.lastImportAt||state.importedAt||'',importStamp:($$('importStamp')?.textContent||'').trim().slice(0,200),
    supplyReadAt:state.supply?.lastReadAt||'',inventoryAt:state.inventory?.snapshot?.sourceAt||'',returnsCheckedAt:state.returns?.lastChecked||'',
    cards,statusFilters,sellers:[...new Set(active.map(r=>String(r.seller).replace('누아브 ','')))]};
  },
  list_orders(a){
   if(typeof state==='undefined'||!state||typeof filtered!=='function')throw Error('앱 목록을 아직 불러오지 못했습니다.');
   const st=String(a.status||'');if(st&&![...($$('statusFilter')?.options||[])].some(o=>o.value===st))throw Error('모르는 안내 상태 값입니다: '+st+' (app_overview 의 statusFilters 참고)');
   // 대화에 나온 가려진 이름(박*하 · 박○하)으로도 찾기: 첫 글자·끝 글자가 같은 고객
   const masked=/^\s*\S[*○]+\S?\s*$/.test(String(a.search||''));
   let rows=withFilters({search:masked?'':a.search,field:a.search_field,status:st,scope:a.scope,seller:sellerKey(a.seller)},()=>filtered());
   if(masked){const q=String(a.search).trim(),first=q[0],last=/[*○]$/.test(q)?'':q.slice(-1);
    rows=rows.filter(r=>[r.buyer,r.recipient].some(n=>{n=String(n||'').trim();return n.length>=2&&n[0]===first&&(!last||n.slice(-1)===last);}));}
   const limit=Math.max(1,Math.min(500,Number(a.limit)||200));
   return {ok:true,count:rows.length,returned:Math.min(limit,rows.length),filters:{status:st,search:a.search||'',search_field:a.search_field||'all',seller:a.seller||'',scope:a.scope||'active'},rows:rows.slice(0,limit).map(rowOut)};
  },
  shortage_report(a){
   if(typeof state==='undefined'||!state)throw Error('앱 목록을 아직 불러오지 못했습니다.');
   let [from,to]=weekRange(state.today,a.week!=='this');if(a.from)from=String(a.from);if(a.to)to=String(a.to);
   const active=state.rows.filter(r=>r.active&&!r.soldoutNotified);
   // 상품·옵션별로 그 기간에 한국 입고(입고 예상일)되는 물량 — 어느 주문에 배정됐든 모두 모은다
   const coming={};
   for(const r of active)for(const p of incomingParts(r))if(overlaps(p.receiptStart,p.receiptEnd,from,to)){
    const k=itemKey(r);(coming[k]=coming[k]||{qty:0,lots:[]});coming[k].qty+=p.qty;
    if(coming[k].lots.length<8)coming[k].lots.push({kind:p.kind,chinaDate:p.chinaDate,receiptStart:p.receiptStart,receiptEnd:p.receiptEnd,qty:p.qty});
   }
   const short=active.filter(r=>r.supplyInfo&&(Number(r.supplyInfo.allocatedQty)||0)<(Number(r.qty)||0)&&!r.review);
   const groups={};
   for(const r of short){const k=itemKey(r);if(!coming[k])continue;(groups[k]=groups[k]||{product:r.product,option:r.option,incomingQtyInRange:coming[k].qty,incomingLots:coming[k].lots,shortQty:0,orders:[]});
    groups[k].shortQty+=Math.max(0,(Number(r.qty)||0)-(Number(r.supplyInfo.allocatedQty)||0));groups[k].orders.push(lite(r));}
   const items=Object.values(groups).sort((x,y)=>y.shortQty-x.shortQty);
   const others=short.filter(r=>!coming[itemKey(r)]);
   return {ok:true,rule:'기간 안에 한국 입고 예정 물량이 있는 상품·옵션 중, 날짜가 잡힌 배정 수량이 주문 수량보다 적은(수량 부족) 미출고 주문상품. 품절 안내 완료·주문정보 확인 필요 건 제외. 입고 예상일은 앱이 출고장·진행상황으로 계산한 값.',
    from,to,today:state.today,itemCount:items.length,orderCount:items.reduce((n,g)=>n+g.orders.length,0),items:items.slice(0,60),
    otherShortageCount:others.length,otherShortageNote:'기간 안 입고 예정 물량이 없는 수량 부족·일정 미정 주문상품 수 (필요하면 list_orders 로 조회)',
    supplyReadAt:state.supply?.lastReadAt||'',lastImportAt:state.lastImportAt||state.importedAt||''};
  },
  bundle_plan(a){
   if(typeof state==='undefined'||!state)throw Error('앱 목록을 아직 불러오지 못했습니다.');
   const day=String(a.date||state.today||'');if(!/^\d{4}-\d{2}-\d{2}$/.test(day))throw Error('date 는 YYYY-MM-DD 로 주세요.');
   const orders={};
   const flagged=state.rows.some(r=>r.isBundle!==undefined&&r.isBundle!==null);   // 합포 표시가 없는 앱(배포판)은 한 주문에 상품 2개 이상을 합포로 본다
   for(const r of state.rows.filter(r=>r.active&&(!flagged||r.isBundle))){const k=r.seller+'|'+r.orderId;(orders[k]=orders[k]||[]).push(r);}
   if(!flagged)for(const k of Object.keys(orders))if(orders[k].length<2)delete orders[k];
   // 앱의 '출고 가능 · 합포/부분' 규칙과 같음: 현재고 준비 또는 출고 예상 시작일이 그날 이하이면 그날 나갈 수 있는 상품
   const can=r=>!r.review&&!r.soldoutNotified&&(r.inventoryReady||(!!(r.dispatchStart||r.dispatchEnd)&&(r.dispatchStart||r.dispatchEnd)<=day));
   const full=[],partial=[],wait=[];
   for(const rows of Object.values(orders)){
    const items=rows.map(r=>({...lite(r),canShip:can(r)})),n=items.filter(i=>i.canShip).length;
    const o={seller:items[0].seller,orderId:items[0].orderId,customer:items[0].customer,bundleType:rows[0].bundleType||'',size:rows.length,canShipItems:n,items};
    (n===rows.length?full:n?partial:wait).push(o);
   }
   const byDate=(x,y)=>String(x.items[0].orderDate).localeCompare(String(y.items[0].orderDate));
   return {ok:true,date:day,today:state.today,rule:'합포(한 주문 여러 상품) 중 그날 출고 가능한 상품 = 현재고 준비 또는 출고 예상 시작일 ≤ 그날 (주문정보 확인 필요·품절 안내 완료 제외). full=전부 가능(합포 출고), partial=일부만 가능(부분 출고), notReady=아직 없음.',
    fullCount:full.length,partialCount:partial.length,notReadyCount:wait.length,full:full.sort(byDate),partial:partial.sort(byDate).slice(0,60),
    notReady:wait.sort(byDate).slice(0,20).map(o=>({seller:o.seller,orderId:o.orderId,customer:o.customer,size:o.size,next:o.items.map(i=>i.dispatchStart||'미정')})),
    lastImportAt:state.lastImportAt||state.importedAt||'',supplyReadAt:state.supply?.lastReadAt||''};
  },
  import_orders(){
   const b=$$('autoOrderImport');if(!b)throw Error('이 앱에는 주문 자동 불러오기 버튼이 없습니다.');
   if(b.disabled)return {ok:false,error:'주문 불러오기가 이미 진행 중이거나 지금 쓸 수 없습니다. job_status 로 확인하세요.'};
   b.click();return {ok:true,message:'주문 자동 불러오기를 시작했습니다 (화면의 「자동 불러오기 시작」과 같음). 이지어드민 로그인·확인 창이 뜨면 사장님이 확인해야 합니다. 끝났는지는 job_status 로 확인하세요.'};
  }
 };
 async function runUiCalls(calls){
  for(const c of calls){
   if(ui.doneCalls.has(c.id))continue;ui.doneCalls.add(c.id);
   let result;try{const fn=UI_TOOLS[c.tool];if(!fn)throw Error('화면 도구가 아닙니다: '+c.tool);result=await fn(c.args||{});}
   catch(e){result={ok:false,error:String(e?.message||e)};}
   try{await call('cxToolResult',{id:c.id,result});}catch(_){}
  }
 }
 // ---------- 상태 갱신 (가벼운 brief만 자주, 대화창은 열려 있을 때만) ----------
 let timer=null,lastRev=-1;
 async function tick(now){
  clearTimeout(timer);let next=4000;
  try{
   const r=await call('cxBrief');const brief=r.brief;quick(brief);
   next=brief.busy?900:4000;
   if(ui.open&&(brief.revision!==lastRev||brief.busy)){lastRev=brief.revision;await status(false);}
  }catch(_){next=3000;}
  timer=setTimeout(tick,now?350:next);
 }
 setTimeout(()=>{unzoom();applyMode();tick();},600);
})();
