'use strict';
// 2026-10-21 20:33 요청: 화요일 중국 출고가 밀린 주 — 수요일 18시까지 그 화요일 출고장이 없으면 물어본다.
// 출고 안 됨 → 다음 중국 출고일: 금요일(다음주 화~수 출고) / 토요일(다음주 수~목 출고, 지금과 같음).
(()=>{
 document.body.insertAdjacentHTML('beforeend',`<dialog id="shipDelayDialog" class="ably-dialog">
 <div class="dialoghead"><h2 id="shipDelayTitle">화요일 출고장이 아직 없습니다</h2><button id="shipDelayLater">나중에</button></div>
 <div id="shipDelayStep1"><p id="shipDelayAsk"></p>
  <div class="settings-actions"><button id="shipDelayNo" class="pink-button">출고 안 됨</button><button id="shipDelayYes">출고됐음 (출고장만 늦음)</button></div></div>
 <div id="shipDelayStep2" hidden><p>다음 중국 출고일은 언제인가요?</p>
  <div class="settings-actions"><button id="shipDelayFri" class="pink-button"></button><button id="shipDelaySat" class="pink-button"></button><button id="shipDelayBack">뒤로</button></div>
  <p class="sub">고른 날로 그 화요일 출고분의 예상 출고일을 다시 계산합니다. 이미 고객에게 안내한 날짜는 바꾸지 않습니다(필요하면 재안내).</p></div>
 <p id="shipDelayStatus" class="sub" role="status"></p></dialog>`);
 const $=id=>document.getElementById(id);
 const md=iso=>{const [y,m,d]=iso.split('-');return `${+m}/${+d}`;};
 let current=null,snoozed={};
 function step(n){$('shipDelayStep1').hidden=n!==1;$('shipDelayStep2').hidden=n!==2;$('shipDelayStatus').textContent='';}
 function check(){
  const q=(typeof state!=='undefined'&&state)?state.shipDelayQuestion:null;
  if(!q){if($('shipDelayDialog').open&&current)$('shipDelayDialog').close();current=null;return;}
  if(snoozed[q.tuesday]&&Date.now()<snoozed[q.tuesday])return;
  if($('shipDelayDialog').open)return;
  current=q;
  $('shipDelayTitle').textContent=`${md(q.tuesday)}(화) 출고장이 아직 없습니다`;
  $('shipDelayAsk').textContent=`${md(q.tuesday)}(화) 중국 출고가 진행되지 않았나요? 수요일 오후 6시까지 그 날짜 출고장이 들어오지 않았습니다.`;
  $('shipDelayFri').textContent=`금요일 ${md(q.friday)} 출고 → 다음주 화~수 출고`;
  $('shipDelaySat').textContent=`토요일 ${md(q.saturday)} 출고 → 다음주 수~목 출고`;
  step(1);$('shipDelayDialog').showModal();
 }
 async function answer(payload){
  try{const r=await api('ship-delay',{tuesday:current.tuesday,...payload});$('shipDelayDialog').close();current=null;toast(r.message);if(typeof refresh==='function')await refresh();}
  catch(e){$('shipDelayStatus').textContent=e.message;}
 }
 $('shipDelayNo').onclick=()=>step(2);$('shipDelayBack').onclick=()=>step(1);
 $('shipDelayYes').onclick=()=>answer({answer:'shipped'});
 $('shipDelayFri').onclick=()=>answer({answer:'delayed',departure:'fri'});
 $('shipDelaySat').onclick=()=>answer({answer:'delayed',departure:'sat'});
 $('shipDelayLater').onclick=()=>{if(current)snoozed[current.tuesday]=Date.now()+60*60*1000;$('shipDelayDialog').close();};   // 1시간 뒤 다시 묻기
 setInterval(check,5000);setTimeout(check,1500);
})();

// 2026-10-24 요청: 출고 예상일 변경 — 출고장(중국 출고분) 단위로 앱의 실 출고 예상일을 사장님이 직접 지정/해제.
// 고객에게 안내한 출고 예정일·발송 이력은 바꾸지 않고, 메시지도 보내지 않는다. Codex 제안 카드도 이 창을 연다.
(()=>{
 document.body.insertAdjacentHTML('beforeend',`<dialog id="dispatchOverrideDialog" class="ably-dialog dispatch-ovr-dialog">
 <div class="dialoghead"><div><p class="eyebrow">DISPATCH ESTIMATE</p><h2>출고 예상일 변경</h2></div><button id="dispatchOvrClose">닫기</button></div>
 <p class="sub">출고장(중국 출고일) 단위로 앱이 계산한 출고 예상일을 바꿉니다. 고객에게 안내한 출고 예정일과 발송 이력은 그대로이고, 메시지는 보내지 않습니다.</p>
 <div id="dispatchOvrList" class="dispatch-ovr-list"></div>
 <div class="dispatch-ovr-dates"><label>새 출고 예상일 <input type="date" id="dispatchOvrStart"></label><label>~ <input type="date" id="dispatchOvrEnd"></label></div>
 <div class="settings-actions"><button id="dispatchOvrApply" class="primary">선택한 출고장에 적용</button></div>
 <p id="dispatchOvrStatus" class="sub" role="status"></p></dialog>`);
 const $=id=>document.getElementById(id);
 const md=iso=>{if(!iso)return '?';const [,m,d]=iso.split('-');return `${+m}/${+d}`;};
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let picked=new Set();
 function waves(){return (typeof state!=='undefined'&&state&&state.supply&&state.supply.dispatchWaves)||[];}
 function paint(){
  const list=waves();
  if(!list.length){$('dispatchOvrList').innerHTML='<p class="sub">출고장·진행상황으로 출고 예상일이 잡힌 상품이 없습니다. 진행상황 반영을 먼저 해 주세요.</p>';return;}
  $('dispatchOvrList').innerHTML=list.map(w=>{
   const o=w.override,orig=w.original||{};
   const now=`${md(w.koreaStart)}${w.koreaEnd&&w.koreaEnd!==w.koreaStart?'~'+md(w.koreaEnd):''}`;
   const was=o&&orig.koreaStart?` · 원래 ${md(orig.koreaStart)}${orig.koreaEnd&&orig.koreaEnd!==orig.koreaStart?'~'+md(orig.koreaEnd):''}`:'';
   return `<label class="dispatch-ovr-row"><input type="checkbox" data-wave="${esc(w.chinaDate)}"${picked.has(w.chinaDate)?' checked':''}>
    <span><b>중국 출고 ${esc(md(w.chinaDate))}</b> · ${esc((w.kinds||[]).join('·')||'지정만 남음')} · 주문상품 ${w.items||0}개 · 지금 출고 예상 <b>${esc(now)}</b>${o?' <em>직접 지정</em>':''}${esc(was)}</span>
    ${o?`<button type="button" data-clear="${esc(w.chinaDate)}">지정 해제</button>`:''}</label>`;}).join('');
 }
 function open(pre){
  picked=new Set((pre&&pre.chinaDates)||[]);$('dispatchOvrStatus').textContent='';
  $('dispatchOvrStart').value=(pre&&pre.start)||'';$('dispatchOvrEnd').value=(pre&&(pre.end||pre.start))||'';
  paint();if(!$('dispatchOverrideDialog').open)$('dispatchOverrideDialog').showModal();
  if(pre&&pre.chinaDates){const miss=pre.chinaDates.filter(c=>!waves().some(w=>w.chinaDate===c));if(miss.length)$('dispatchOvrStatus').textContent=`지금 목록에 없는 출고장 ${miss.map(md).join(', ')}은 뺐습니다.`;}
 }
 window.nuavuDispatchOverride={open};
 $('dispatchOvrList').addEventListener('change',e=>{const c=e.target.dataset.wave;if(!c)return;e.target.checked?picked.add(c):picked.delete(c);});
 $('dispatchOvrList').addEventListener('click',async e=>{
  const c=e.target.dataset?.clear;if(!c)return;e.preventDefault();
  try{const r=await api('dispatch-override',{chinaDate:c,clear:true});$('dispatchOvrStatus').textContent=r.message;if(typeof refresh==='function')await refresh();paint();}
  catch(err){$('dispatchOvrStatus').textContent=err.message;}
 });
 $('dispatchOvrStart').addEventListener('change',()=>{if(!$('dispatchOvrEnd').value||$('dispatchOvrEnd').value<$('dispatchOvrStart').value)$('dispatchOvrEnd').value=$('dispatchOvrStart').value;});
 $('dispatchOvrApply').onclick=async()=>{
  const start=$('dispatchOvrStart').value,end=$('dispatchOvrEnd').value||start,list=[...picked].filter(c=>waves().some(w=>w.chinaDate===c));
  if(!list.length){$('dispatchOvrStatus').textContent='바꿀 출고장을 골라 주세요.';return;}
  if(!start){$('dispatchOvrStatus').textContent='새 출고 예상일을 골라 주세요.';return;}
  const done=[];
  for(const c of list){
   try{const r=await api('dispatch-override',{chinaDate:c,start,end,source:'app'});done.push(r.message);}
   catch(err){$('dispatchOvrStatus').textContent=`${md(c)} 출고분: ${err.message}`;if(typeof refresh==='function')await refresh();paint();return;}
  }
  if(typeof refresh==='function')await refresh();paint();
  $('dispatchOvrStatus').textContent=done.length===1?done[0]:`출고장 ${done.length}개의 출고 예상일을 바꿨습니다. 고객 메시지는 보내지 않았습니다.`;
  if(typeof toast==='function')toast($('dispatchOvrStatus').textContent);
 };
 $('dispatchOvrClose').onclick=()=>$('dispatchOverrideDialog').close();
 // 상단 버튼 (진행상황 반영 옆)
 const anchor=$('supplyBtn');
 if(anchor&&!$('dispatchOvrBtn')){anchor.insertAdjacentHTML('afterend','<button id="dispatchOvrBtn" class="green-button" title="출고장 단위로 앱의 출고 예상일을 바꿉니다 (고객 메시지 없음)">출고 예상일 변경</button>');$('dispatchOvrBtn').onclick=()=>open(null);}
})();
