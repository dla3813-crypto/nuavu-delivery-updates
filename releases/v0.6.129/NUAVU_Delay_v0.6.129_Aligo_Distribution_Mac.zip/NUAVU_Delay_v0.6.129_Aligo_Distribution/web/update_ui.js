'use strict';
// 2026-10-23 요청: 업데이트가 있으면 앱을 켤 때마다 "다운로드하시겠습니까?" 창 + 상단 바에 "업데이트 있음" 표시, 버튼 하나로 설치.
(()=>{
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const bar=document.createElement('section');bar.id='updateBar';bar.className='update-bar';bar.hidden=true;
 bar.innerHTML='<span class="update-dot"></span><b id="updateBarText">업데이트 있음</b><span id="updateBarSub" class="update-sub"></span><button id="updateBarBtn" class="update-btn">지금 업데이트</button>';
 const main=document.querySelector('main');if(main)main.prepend(bar);
 const dlg=document.createElement('dialog');dlg.id='updateDialog';dlg.className='update-dialog';
 dlg.innerHTML='<h2>🔵 새 버전이 있습니다</h2><p id="updateDlgVer"></p><ul id="updateDlgNotes"></ul><p class="sub">주문·발송 이력과 계정은 그대로 유지됩니다. 업데이트하면 앱이 잠시 꺼졌다가 새 버전으로 다시 열립니다 (1~3분).</p><p id="updateDlgMsg" class="update-msg"></p><div class="update-actions"><button id="updateDlgLater">나중에</button><button id="updateDlgGo" class="update-btn">다운로드하고 업데이트</button></div>';
 document.body.appendChild(dlg);
 // 2026-10-25: 업데이트를 받고 새 버전이 처음 켜지면 이번에 바뀐 점(패치노트)을 보여 준다.
 const done=document.createElement('dialog');done.id='updateDoneDialog';done.className='update-dialog';
 done.innerHTML='<h2>✅ 업데이트 완료</h2><p id="updateDoneVer"></p><p id="updateDoneHead" class="update-head">이번 버전에서 바뀐 점</p><div id="updateDoneNotes" class="update-notes"></div><p class="sub">주문·발송 이력과 계정은 그대로입니다.</p><div class="update-actions"><button id="updateDoneOk" class="update-btn" autofocus>확인</button></div>';
 document.body.appendChild(done);let doneShown=false;
 async function ackDone(){try{if(done.open)done.close();const a=api();if(a?.update_ack&&typeof token!=='undefined')await a.update_ack(token);}catch(_){}}
 let shownFor='';let last=null;
 const api=()=>window.pywebview?.api;
 function render(s){
  last=s;const busy=s.phase==='downloading'||s.phase==='installing';
  bar.hidden=!(s.available||busy||s.phase==='error'&&s.latest);
  bar.classList.toggle('is-error',s.phase==='error');
  document.getElementById('updateBarText').textContent=busy?(s.phase==='downloading'?`업데이트 받는 중 ${s.progress||0}%`:'업데이트 설치 준비 중'):s.phase==='error'?'업데이트 실패':`업데이트 있음 · v${s.latest}`;
  document.getElementById('updateBarSub').textContent=busy?(s.message||''):s.phase==='error'?(s.error||''):`지금 v${s.current}`;
  const b=document.getElementById('updateBarBtn');b.hidden=busy;b.textContent=s.phase==='error'?'다시 시도':'지금 업데이트';
  document.getElementById('updateDlgVer').innerHTML=`지금 버전 <b>v${esc(s.current)}</b> → 새 버전 <b>v${esc(s.latest)}</b>${s.publishedAt?' · '+esc(String(s.publishedAt).slice(0,10)):''}<br>업데이트를 다운로드하시겠습니까?`;
  document.getElementById('updateDlgNotes').innerHTML=(s.notes||[]).slice(0,30).map(n=>'<li>'+esc(n)+'</li>').join('');
  const j=s.justUpdated;
  if(j&&!doneShown){doneShown=true;document.getElementById('updateDoneVer').innerHTML=(j.from?'v'+esc(j.from)+' → ':'')+'<b>v'+esc(j.to)+'</b> 로 업데이트했습니다.';
   const win=/Win/i.test(navigator.platform||navigator.userAgent||'');const fix=t=>win?String(t).replace('[Finder에서 보기](윈도우: [탐색기에서 보기])','[탐색기에서 보기]'):String(t).replace('(윈도우: [탐색기에서 보기])','');
   document.getElementById('updateDoneHead').textContent=j.headline||'이번 버전에서 바뀐 점';
   document.getElementById('updateDoneNotes').innerHTML=(j.sections&&j.sections.length)?j.sections.map(s=>'<section class="update-sec'+(s.image?' has-img':'')+'"><div class="update-sec-text"><h3>'+esc(s.title)+'</h3><ul>'+(s.items||[]).map(i=>'<li>'+esc(fix(i))+'</li>').join('')+'</ul></div>'+(s.image?'<img src="/'+esc(s.image)+'" alt="'+esc(s.title)+' 화면">':'')+'</section>').join('')
    :((j.notes||[]).map(n=>'<li>'+esc(fix(n))+'</li>').join('')?'<ul>'+(j.notes||[]).map(n=>'<li>'+esc(fix(n))+'</li>').join('')+'</ul>':'<p class="sub">자세한 변경 내용은 다음 업데이트부터 표시됩니다.</p>');
   // 가로로 긴 사진은 글 아래에 넓게, 세로로 긴 사진(대화 창)은 글 옆에
   done.querySelectorAll('.update-sec img').forEach(im=>{const f=()=>{if(im.naturalWidth>im.naturalHeight)im.closest('.update-sec').classList.add('wide');};im.complete?f():im.addEventListener('load',f);});
   try{if(!done.open&&!dlg.open)done.showModal();}catch(_){}
   document.getElementById('updateDoneNotes').scrollTop=0;}
  document.getElementById('updateDlgMsg').textContent=busy?(s.message||'')+(s.phase==='downloading'?` (${s.progress||0}%)`:''):(s.phase==='error'?s.error||'':'');
  document.getElementById('updateDlgGo').disabled=busy;
  // 앱을 켤 때마다(이 화면을 처음 연 뒤) 새 버전마다 한 번 묻는다.
  if(s.available&&!busy&&shownFor!==s.latest){shownFor=s.latest;try{if(!dlg.open)dlg.showModal();}catch(_){}}
 }
 async function install(btn){
  const a=api();if(!a?.update_install||typeof token==='undefined')return;
  if(btn)btn.disabled=true;
  try{const r=await a.update_install(token);if(r.error)throw Error(r.error);render(r);}
  catch(e){document.getElementById('updateDlgMsg').textContent=e.message;if(typeof toast==='function')toast(e.message,true);}
  finally{if(btn)btn.disabled=false;}
 }
 document.getElementById('updateBarBtn').onclick=e=>{if(last&&last.available&&!dlg.open)dlg.showModal();else install(e.currentTarget);};
 document.getElementById('updateDlgGo').onclick=e=>install(e.currentTarget);
 document.getElementById('updateDlgLater').onclick=()=>dlg.close();
 document.getElementById('updateDoneOk').onclick=ackDone;done.addEventListener('cancel',()=>ackDone());
 async function tick(){
  const a=api();
  if(typeof token==='undefined'||!a?.update_status){setTimeout(tick,3000);return;}
  try{const s=await a.update_status(token);if(!s.error)render(s);}catch(_){}
  setTimeout(tick,last&&(last.phase==='downloading'||last.phase==='installing')?1000:(!last||!last.checkedAt)?3000:60000);   // 시작 직후 확인 결과가 나올 때까지는 3초 간격
 }
 setTimeout(tick,1500);
})();
