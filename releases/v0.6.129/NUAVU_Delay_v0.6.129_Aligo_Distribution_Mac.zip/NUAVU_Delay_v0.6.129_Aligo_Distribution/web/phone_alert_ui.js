'use strict';
// 2026-10-23 요청: ⚙ 설정 › 자동화 — 아이폰 알림 (아이메시지). 문제(빨간) 알림만 보냄 · 기본 꺼짐.
// 2026-10-23 20:57 보고 수정: 체크하면 '껐습니다'가 뜨고, 번호를 넣고 시험 보내기를 누르면 '받는 곳을 먼저 입력하세요'가 뜨던 문제
//   (화면을 다시 그릴 때 사용자가 바꾼 체크·번호를 저장값으로 덮어씀) → 저장/불러오기 때만 화면 값을 맞추고, 그 밖에는 손대지 않는다.
(()=>{
 const row=document.createElement('div');row.className='hub-switch phone-alert-row';row.id='phoneAlertRow';
 row.innerHTML='<label class="phone-alert-toggle"><input type="checkbox" id="phoneAlertOn"><span><b>아이폰 알림 (아이메시지)</b><small>프로그램에 문제가 생겨 빨간 알림(막힘·확인 필요·실패·오류)이 뜰 때만 아이폰으로 보냅니다. 정상 완료 알림은 보내지 않습니다 · 같은 알림은 1번 · 1시간 최대 20통.</small></span></label>'+
  '<div class="phone-alert-line"><label>받는 곳 <input id="phoneAlertTo" placeholder="010 번호 또는 Apple ID 이메일" autocomplete="off"></label><a href="#" id="phoneAlertTest">시험 보내기</a></div>'+
  '<p id="phoneAlertState" class="sub phone-alert-state"></p>';
 function mount(){
  if(document.getElementById('phoneAlertRow'))return true;
  const list=document.getElementById('hubAutoList');if(!list)return false;
  const anchor=list.querySelector('input[data-hub-auto="autoZigzagPush"]')?.closest('label');
  if(anchor)anchor.before(row);else list.append(row);wire();return true;
 }
 let st=null,busy=false,saving=null,note='',noteErr=false;
 const $$=id=>document.getElementById(id);
 function sync(s){   // 저장값을 화면에 반영 (불러올 때 · 저장 성공 뒤에만)
  st=s;$$('phoneAlertOn').checked=!!s.enabled;$$('phoneAlertTo').value=s.to||'';
 }
 function paint(msg,isErr){
  if(msg!==undefined){note=msg||'';noteErr=!!isErr;}
  if(!st)return;
  const off=!st.supported;row.classList.toggle('is-disabled',off);row.dataset.enabled=String(!!st.enabled&&!off);
  $$('phoneAlertOn').disabled=off;$$('phoneAlertTo').disabled=off;
  $$('phoneAlertTest').classList.toggle('disabled',off);   // 저장 중에도 누를 수 있어야 함 (번호 칸을 벗어나는 순간 저장이 시작돼 클릭이 사라지던 문제)
  const last=st.last||{};const when=last.at&&typeof dateTime==='function'?dateTime(last.at):(last.at||'');
  let line=off?st.unsupportedReason:note;
  if(!off&&!note&&last.at)line=(last.ok?'마지막 보내기 성공':'마지막 보내기 실패')+` · ${when}${last.kind==='test'?' (시험)':''}${last.ok?'':' · '+(last.error||'')}`;
  if(!off)line+=(line?' · ':'')+`이번 1시간 ${st.sentLastHour||0}/${st.maxPerHour||20}통`;
  const el=$$('phoneAlertState');el.textContent=line;el.classList.toggle('error',noteErr||(!note&&!!last.at&&!last.ok));
 }
 async function load(){if(!mount())return;try{const s=await api('phone-alert',{action:'status'});if(!s.error){sync(s);paint('');}}catch(e){}}
 function save(){
  const enabled=$$('phoneAlertOn').checked,to=$$('phoneAlertTo').value;   // 사용자가 지금 고른 값을 먼저 읽는다
  const prev=saving;   // 저장은 차례대로 (번호 칸을 벗어나며 저장 → 곧바로 체크 저장)
  const job=(async()=>{
   if(prev)await prev.catch(()=>{});
   busy=true;paint('저장 중…');
   try{
    const r=await api('phone-alert',{action:'save',enabled,to});
    if(r.error){st={...st,...r};$$('phoneAlertOn').checked=!!r.enabled;paint(r.error,true);if(typeof toast==='function')toast(r.error,true);return;}
    sync(r);paint(r.message);if(typeof toast==='function')toast(r.message);
   }catch(e){$$('phoneAlertOn').checked=!!(st&&st.enabled);paint(e.message,true);}
   finally{busy=false;paint();}
  })();
  saving=job;job.finally(()=>{if(saving===job)saving=null;});return job;
 }
 function wire(){
  $$('phoneAlertOn').addEventListener('change',()=>{save();});
  $$('phoneAlertTo').addEventListener('change',()=>{if((st&&st.to)!==$$('phoneAlertTo').value.trim())save();});
  $$('phoneAlertTo').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();e.target.blur();}});
  $$('phoneAlertTest').addEventListener('click',async e=>{
   e.preventDefault();if(st&&!st.supported)return;
   if(saving)await saving.catch(()=>{});   // 번호 칸을 벗어나며 시작된 저장을 기다린 뒤 보낸다
   if(busy)return;
   const to=$$('phoneAlertTo').value.trim();
   if(!to){paint('받는 곳(010 번호 또는 Apple ID 이메일)을 먼저 입력하세요.',true);return;}
   busy=true;paint('시험 아이메시지를 보내는 중…');
   try{
    const r=await api('phone-alert',{action:'test',to});
    st={...st,...r,enabled:st?st.enabled:false,to:st?st.to:''};   // 시험은 저장값을 바꾸지 않는다
    if(r.error){paint(r.error,true);if(typeof toast==='function')toast(r.error,true);}
    else{paint(r.message);if(typeof toast==='function')toast(r.message);}
   }catch(err){paint(err.message,true);}
   finally{busy=false;paint();}
  });
 }
 document.addEventListener('click',e=>{if(e.target.closest('#settingsHubBtn'))setTimeout(load,50);});
 setTimeout(load,1500);
})();
