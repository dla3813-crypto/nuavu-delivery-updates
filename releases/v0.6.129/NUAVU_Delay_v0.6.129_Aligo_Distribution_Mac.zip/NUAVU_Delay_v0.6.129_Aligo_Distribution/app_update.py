"""배송안내 배포판 버튼 하나 업데이트 (2026-10-23 요청).

- 새 버전 정보: GitHub 공개 저장소 dla3813-crypto/nuavu-delivery-updates 의 main/latest.json.
  사장님이 "배포하자"라고 할 때만 그 파일이 바뀐다. 그 전에는 지인 앱에 아무것도 뜨지 않는다.
- latest.json 은 Ed25519로 서명한다. 앱에는 공개키만 들어 있고, 서명이 맞지 않으면 무시한다.
  서명 안에 각 ZIP의 SHA-256과 크기가 들어 있어, 받은 ZIP이 하나라도 다르면 설치하지 않는다.
- 설치: ZIP을 데이터 폴더(updates/)에 풀고, 새 버전에 들어 있는 update_apply.py 를 앱 밖 프로세스로 실행한 뒤
  앱을 종료한다. update_apply.py 는 앱이 완전히 꺼질 때까지 기다렸다가 구성요소 확인 → 앱 교체 → 다시 실행한다.
  주문·발송 이력·계정(데이터 폴더·키체인)은 건드리지 않는다.
- 더 높은 버전만 설치한다(같거나 낮은 버전은 무시 → 예전 latest.json 재사용 공격도 막힘).
"""
from __future__ import annotations
import hashlib,json,os,re,shutil,ssl,subprocess,sys,threading,time,zipfile
from datetime import datetime,timezone
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import Request,build_opener,HTTPSHandler,HTTPRedirectHandler

REPO='dla3813-crypto/nuavu-delivery-updates'
MANIFEST_URL=f'https://raw.githubusercontent.com/{REPO}/main/latest.json'
PUBLIC_KEY_HEX='4753ad7b280a99e7147ed3d4a5af8c8d99152918c839af04f3d59a7414322349'
APP_ID='nuavu-delivery-distribution'
ALLOWED_HOSTS={'raw.githubusercontent.com','github.com','objects.githubusercontent.com','release-assets.githubusercontent.com','codeload.github.com'}
CHECK_EVERY=3*3600
MAX_MANIFEST=64*1024
MAX_ZIP=200*1024*1024
MAX_UNPACKED=600*1024*1024

class UpdateError(Exception):pass

# ---------------------------------------------------------------- Ed25519 verify (RFC 8032, pure Python, verify only)
_P=2**255-19
_L=2**252+27742317777372353535851937790883648493
_D=-121665*pow(121666,_P-2,_P)%_P
_I=pow(2,(_P-1)//4,_P)
def _xrecover(y):
    xx=(y*y-1)*pow(_D*y*y+1,_P-2,_P)%_P
    x=pow(xx,(_P+3)//8,_P)
    if (x*x-xx)%_P:x=x*_I%_P
    if (x*x-xx)%_P:return None
    return x
_BY=4*pow(5,_P-2,_P)%_P;_BX=_xrecover(_BY)
if _BX&1:_BX=_P-_BX
_B=(_BX,_BY,1,_BX*_BY%_P)
def _add(P,Q):
    X1,Y1,Z1,T1=P;X2,Y2,Z2,T2=Q
    A=(Y1-X1)*(Y2-X2)%_P;B=(Y1+X1)*(Y2+X2)%_P;C=T1*2*_D*T2%_P;D=Z1*2*Z2%_P
    E=B-A;F=D-C;G=D+C;H=B+A
    return (E*F%_P,G*H%_P,F*G%_P,E*H%_P)
def _mul(s,P):
    Q=(0,1,1,0)
    while s>0:
        if s&1:Q=_add(Q,P)
        P=_add(P,P);s>>=1
    return Q
def _eq(P,Q):return (P[0]*Q[2]-Q[0]*P[2])%_P==0 and (P[1]*Q[2]-Q[1]*P[2])%_P==0
def _decode(b):
    if len(b)!=32:return None
    y=int.from_bytes(b,'little')&((1<<255)-1);sign=b[31]>>7
    if y>=_P:return None
    x=_xrecover(y)
    if x is None or (x==0 and sign):return None
    if (x&1)!=sign:x=_P-x
    return (x,y,1,x*y%_P)
def ed25519_verify(public_key:bytes,message:bytes,signature:bytes)->bool:
    if len(public_key)!=32 or len(signature)!=64:return False
    A=_decode(public_key);R=_decode(signature[:32])
    if A is None or R is None:return False
    S=int.from_bytes(signature[32:],'little')
    if S>=_L:return False
    h=int.from_bytes(hashlib.sha512(signature[:32]+public_key+message).digest(),'little')%_L
    return _eq(_mul(S,_B),_add(R,_mul(h,A)))

# ---------------------------------------------------------------- manifest
def canonical(payload):return json.dumps(payload,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')

def version_tuple(v):
    if not isinstance(v,str) or not re.fullmatch(r'\d{1,4}(\.\d{1,4}){1,3}',v):raise UpdateError('버전 형식 오류')
    return tuple(int(x) for x in v.split('.'))

def platform_key():return 'mac' if sys.platform=='darwin' else 'windows' if sys.platform=='win32' else 'other'

def verify_manifest(raw:bytes,public_key_hex=PUBLIC_KEY_HEX):
    """Parsed payload of a signed latest.json, or UpdateError."""
    if len(raw)>MAX_MANIFEST:raise UpdateError('업데이트 정보가 너무 큽니다.')
    try:doc=json.loads(raw.decode('utf-8'))
    except Exception as exc:raise UpdateError('업데이트 정보를 읽지 못했습니다.') from exc
    if not isinstance(doc,dict) or not isinstance(doc.get('payload'),dict) or not isinstance(doc.get('signature'),str):raise UpdateError('업데이트 정보 형식이 다릅니다.')
    try:sig=bytes.fromhex(doc['signature'])
    except ValueError as exc:raise UpdateError('업데이트 서명 형식이 다릅니다.') from exc
    p=doc['payload']
    if not ed25519_verify(bytes.fromhex(public_key_hex),canonical(p),sig):raise UpdateError('업데이트 서명이 맞지 않습니다. 설치하지 않습니다.')
    if p.get('app')!=APP_ID:raise UpdateError('다른 프로그램의 업데이트 정보입니다.')
    version_tuple(p.get('version'))
    files=p.get('files')
    if not isinstance(files,dict):raise UpdateError('업데이트 파일 목록이 없습니다.')
    for k,f in files.items():
        if not isinstance(f,dict):raise UpdateError('업데이트 파일 정보 형식 오류')
        u=urlsplit(str(f.get('url','')))
        if u.scheme!='https' or u.hostname not in ALLOWED_HOSTS:raise UpdateError('허용되지 않은 다운로드 주소입니다.')
        if not re.fullmatch(r'[0-9a-f]{64}',str(f.get('sha256',''))):raise UpdateError('파일 확인값 형식 오류')
        if not isinstance(f.get('size'),int) or not 0<f['size']<=MAX_ZIP:raise UpdateError('파일 크기 정보 오류')
    notes=p.get('notes',[])
    if not isinstance(notes,list) or not all(isinstance(n,str) for n in notes):raise UpdateError('변경 내용 형식 오류')
    return p

# ---------------------------------------------------------------- network
class _SafeRedirect(HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        u=urlsplit(newurl)
        if u.scheme!='https' or u.hostname not in ALLOWED_HOSTS:raise UpdateError('허용되지 않은 주소로 이동하려고 해서 멈췄습니다.')
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def _context():
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:return ssl.create_default_context()

def _opener():return build_opener(HTTPSHandler(context=_context()),_SafeRedirect())

def fetch(url,limit,progress=None,dest=None,timeout=30):
    u=urlsplit(url)
    if u.scheme!='https' or u.hostname not in ALLOWED_HOSTS:raise UpdateError('허용되지 않은 주소입니다.')
    req=Request(url,headers={'User-Agent':'NUAVU-Delivery-Distribution-Updater','Cache-Control':'no-cache'})
    with _opener().open(req,timeout=timeout) as r:
        total=int(r.headers.get('Content-Length') or 0)
        if total and total>limit:raise UpdateError('파일이 너무 큽니다.')
        got=0;chunks=[];out=open(dest,'wb') if dest else None
        try:
            while True:
                b=r.read(256*1024)
                if not b:break
                got+=len(b)
                if got>limit:raise UpdateError('파일이 너무 큽니다.')
                if out:out.write(b)
                else:chunks.append(b)
                if progress:progress(got,total)
        finally:
            if out:out.close()
    return None if dest else b''.join(chunks)

# ---------------------------------------------------------------- unpack
def safe_extract(zip_path,target):
    """Extract a ZIP without absolute paths, '..', or symlinks; returns the folder that holds update_apply.py."""
    target=Path(target);target.mkdir(parents=True,exist_ok=True);root=target.resolve();total=0
    with zipfile.ZipFile(zip_path) as z:
        for info in z.infolist():
            name=info.filename.replace('\\','/')
            if name.startswith('/') or re.match(r'^[A-Za-z]:',name) or any(part=='..' for part in name.split('/')):raise UpdateError('업데이트 파일 안에 허용되지 않은 경로가 있습니다.')
            if (info.external_attr>>16)&0o170000==0o120000:raise UpdateError('업데이트 파일 안에 링크 파일이 있습니다.')
            total+=info.file_size
            if total>MAX_UNPACKED:raise UpdateError('업데이트 파일 압축이 너무 큽니다.')
            dest=(root/name).resolve()
            if dest!=root and root not in dest.parents:raise UpdateError('업데이트 파일 안에 허용되지 않은 경로가 있습니다.')
        z.extractall(root)
    hits=[p.parent for p in root.rglob('update_apply.py') if '__MACOSX' not in p.parts]
    if len(hits)!=1:raise UpdateError('업데이트 파일 구성이 다릅니다 (update_apply.py).')
    return hits[0]

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def current_bundle():
    """macOS: the .app bundle this code runs from (None when run from a plain folder)."""
    for p in Path(__file__).resolve().parents:
        if p.suffix=='.app':return p
    return None

# ---------------------------------------------------------------- patch notes (2026-10-25)
def bundled_patch(version):
    """앱에 함께 들어 있는 이번 버전의 패치노트 (web/patch_notes.json: 제목·항목·사진). 버전이 다르면 빈 내용."""
    try:
        doc=json.loads((Path(__file__).resolve().parent/'web'/'patch_notes.json').read_text(encoding='utf-8'))
        if str(doc.get('version'))!=str(version):return {}
        sections=[]
        for s in doc.get('sections',[])[:10]:
            img=str(s.get('image') or '')
            if img and not re.fullmatch(r'patch/[a-z0-9_]{1,40}\.(png|jpg)',img):img=''
            sections.append({'title':str(s.get('title',''))[:80],'items':[str(i)[:200] for i in s.get('items',[])][:8],'image':img})
        return {'headline':str(doc.get('headline',''))[:80],'sections':sections,'notes':[str(n) for n in doc.get('notes',[]) if str(n).strip()][:40]}
    except Exception:return {}
def bundled_notes(version):return bundled_patch(version).get('notes',[])

# ---------------------------------------------------------------- controller
class Updater:
    def __init__(self,engine,current_version,busy=lambda:'',quit_app=None,manifest_url=MANIFEST_URL,public_key_hex=PUBLIC_KEY_HEX,data=None):
        self.engine=engine;self.current=current_version;self.busy=busy;self.quit_app=quit_app
        self.url=manifest_url;self.pub=public_key_hex
        self.data=Path(data) if data else Path(engine.store.directory)
        self.lock=threading.RLock();self.thread=None;self.stop=threading.Event()
        self.state={'phase':'idle','current':current_version,'latest':'','available':False,'notes':[],'checkedAt':'','error':'','progress':0,'message':''}
        self.payload=None
        self._load_just_updated()
    def _marker(self):return self.data/'updates'/'just_updated.json'
    def _load_just_updated(self):
        """업데이트 뒤 처음 켜졌을 때: '업데이트 완료 · 바뀐 점' 창용 정보 (사장님이 확인을 누르면 지움)."""
        try:
            m=self._marker()
            if not m.is_file():return
            info=json.loads(m.read_text(encoding='utf-8'))
            if str(info.get('to'))!=str(self.current):m.unlink();return   # 다른 버전 표시는 버림
            patch=bundled_patch(self.current)
            self.state['justUpdated']={'from':str(info.get('from',''))[:20],'to':str(self.current),'notes':patch.get('notes',[]),'headline':patch.get('headline',''),'sections':patch.get('sections',[])}
        except Exception:pass
    def acknowledge_update(self):
        with self.lock:self.state.pop('justUpdated',None)
        try:self._marker().unlink()
        except FileNotFoundError:pass
        except Exception:pass
        return self.status()
    def status(self):
        with self.lock:return dict(self.state,notes=list(self.state['notes']))
    def _set(self,**kw):
        with self.lock:self.state.update(kw)
    def check(self):
        """Read latest.json. Network or signature trouble never bothers the user (quiet, logged)."""
        try:
            raw=fetch(self.url+('&' if '?' in self.url else '?')+'t='+str(int(time.time())),MAX_MANIFEST,timeout=15)
            p=verify_manifest(raw,self.pub)
            newer=version_tuple(p['version'])>version_tuple(self.current)
            f=(p['files'] or {}).get(platform_key())
            with self.lock:
                self.payload=p if newer and f else None
                if self.state['phase'] not in ('downloading','installing'):
                    self.state.update(phase='idle',latest=p['version'],available=bool(newer and f),notes=list(p.get('notes',[]))[:30] if newer else [],
                                      publishedAt=str(p.get('publishedAt',''))[:40],checkedAt=datetime.now(timezone.utc).isoformat(timespec='seconds'),error='')
        except Exception as exc:
            self._set(checkedAt=datetime.now(timezone.utc).isoformat(timespec='seconds'),error=str(exc)[:200] if isinstance(exc,UpdateError) else '업데이트 확인 실패 (인터넷 연결 확인)')
        return self.status()
    def start(self):
        def loop():
            time.sleep(3)
            while not self.stop.is_set():
                self.check()
                self.stop.wait(CHECK_EVERY)
        threading.Thread(target=loop,daemon=True,name='update-check').start()
    def install(self):
        with self.lock:
            if self.state['phase'] in ('downloading','installing'):return self.status()
            if not self.payload:raise UpdateError('설치할 새 버전이 없습니다. 잠시 후 다시 확인하세요.')
            why=self.busy()
            if why:raise UpdateError(f'진행 중인 작업({why})이 끝난 뒤 업데이트하세요.')
            self.state.update(phase='downloading',progress=0,message='새 버전을 받는 중입니다.',error='')
            p=self.payload
        self.thread=threading.Thread(target=self._install,args=(p,),daemon=True,name='update-install');self.thread.start()
        return self.status()
    def _install(self,p):
        try:
            f=p['files'][platform_key()];ver=p['version']
            base=self.data/'updates';base.mkdir(parents=True,exist_ok=True)
            for old in base.iterdir():   # keep only the current (running) and the new one
                if old.name.startswith('v') and old.name!='v'+ver and old.name!='v'+self.current:shutil.rmtree(old,ignore_errors=True)
            work=base/('v'+ver);shutil.rmtree(work,ignore_errors=True);work.mkdir(parents=True)
            zpath=work/'package.zip'
            fetch(f['url'],min(MAX_ZIP,f['size']+1),progress=lambda got,total:self._set(progress=int(got*100/max(1,f['size']))),dest=zpath,timeout=60)
            if zpath.stat().st_size!=f['size'] or sha256_file(zpath)!=f['sha256']:raise UpdateError('받은 파일이 서명된 파일과 다릅니다. 설치하지 않습니다.')
            self._set(phase='installing',progress=100,message='압축을 풀고 설치를 준비합니다.')
            root=safe_extract(zpath,work/'package');zpath.unlink()
            self._launch_apply(root,ver)
            self._set(message='앱을 종료하고 새 버전으로 다시 엽니다. 잠시만 기다려 주세요 (1~3분).')
            if self.quit_app:threading.Timer(1.5,self.quit_app).start()
        except Exception as exc:
            self._set(phase='error',error=str(exc)[:300] if isinstance(exc,UpdateError) else f'업데이트 실패 · {type(exc).__name__}: {str(exc)[:200]}',message='')
            try:self.engine.record_error('앱 업데이트',self.state['error'],'')
            except Exception:pass
    def _launch_apply(self,root,ver):
        logs=self.data/'logs';logs.mkdir(parents=True,exist_ok=True)
        args=['--pid',str(os.getpid()),'--data',str(self.data),'--version',ver,'--from-version',self.current]
        if sys.platform=='darwin':
            bundle=current_bundle()
            args+=['--bundle',str(bundle or Path.home()/'Applications/배송안내 배포판.app')]
            py=sys.executable
        elif sys.platform=='win32':
            here=Path(__file__).resolve().parent;args+=['--app-root',str(here)]
            exe=Path(sys.executable);py=str(exe.with_name('python.exe')) if exe.name.lower()=='pythonw.exe' and exe.with_name('python.exe').exists() else str(exe)
        else:raise UpdateError('이 운영체제에서는 자동 업데이트를 지원하지 않습니다.')
        log=open(logs/'update.log','a',encoding='utf-8')
        log.write(f'\n==== {datetime.now().isoformat(timespec="seconds")} 업데이트 {self.current} → {ver} 준비 ====\n');log.flush()
        kw={'cwd':str(root),'stdout':log,'stderr':subprocess.STDOUT,'stdin':subprocess.DEVNULL}
        if sys.platform=='win32':kw['creationflags']=0x00000008|0x00000200|0x08000000   # DETACHED | NEW_GROUP | NO_WINDOW
        else:kw['start_new_session']=True
        subprocess.Popen([py,'-I',str(root/'update_apply.py'),*args],**kw)
