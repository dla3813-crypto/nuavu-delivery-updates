"""배송안내 배포판 · Codex 작업 복사본 (2026-10-24) — Nuavu Auto 1.31.1 codex_chat/files.py 이식.

원본은 반영 전까지 그대로 둔다. 작업 복사본 → 변경 확인 → (사장님 선택) 원본 반영 / 별도 저장 / 되돌리기.
반영·복구 때 원본이 그사이 바뀌었으면 덮어쓰지 않는다. 반영 전 원본은 백업하고, 임시 파일 → 원자적 교체.
엑셀(.xlsx)은 이 앱의 표준 라이브러리 읽기(workbook_reader)로 셀 값을 비교하고, 셀 값 밖의 변경(수식·서식·이미지·시트 구성)은
압축 안 파트 단위로 따로 표시한다 — 셀 값이 같다고 이미지·서식까지 그대로라고 말하지 않는다.
프로그램 소스(.py/.js/.css/.html)는 업무 파일과 구분해 받지 않는다.
"""
from __future__ import annotations
import datetime,difflib,hashlib,json,os,re,shutil,tempfile,uuid,zipfile
from pathlib import Path
from codex_rpc import CodexError

ALLOWED={'.xlsx','.xls','.csv','.tsv','.txt','.md','.json','.docx','.pdf','.png','.jpg','.jpeg','.webp'}
TEXT={'.txt','.md','.json','.csv','.tsv'}
MAX_SIZE=100*1024*1024

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()

def atomic_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='.save-',dir=path.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(value,f,ensure_ascii=False,indent=1)
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def checked_file(path,root=None):
    p=Path(path)
    if p.is_symlink() or not p.is_file():raise CodexError('일반 파일만 선택할 수 있습니다. 바로가기·폴더는 지원하지 않습니다.')
    if root is not None:
        try:p.resolve().relative_to(Path(root).resolve())
        except ValueError:raise CodexError('작업 폴더 밖의 파일은 사용할 수 없습니다.') from None
    if p.suffix.lower() not in ALLOWED:raise CodexError('이 파일 형식은 지원하지 않습니다. (엑셀·CSV·텍스트·문서·이미지 업무 파일만)')
    if p.stat().st_size>MAX_SIZE:raise CodexError('100MB 이하의 파일을 선택해 주세요.')
    return p

# ---------- XLSX (표준 라이브러리) ----------
def _zip_ok(p,kind):
    with zipfile.ZipFile(p) as z:
        infos=z.infolist()
        if len(infos)>20000 or sum(x.file_size for x in infos)>500*1024*1024:raise ValueError('size')
        if z.testzip() is not None:raise ValueError('crc')
        names=set(z.namelist())
        need='xl/workbook.xml' if kind=='.xlsx' else 'word/document.xml'
        if need not in names or '[Content_Types].xml' not in names:raise ValueError('parts')
        from xml.etree import ElementTree as ET
        for n in names:
            if n.endswith('.xml') or n.endswith('.rels'):
                raw=z.read(n)
                if b'<!DOCTYPE' in raw[:4096].upper():raise ValueError('doctype')
                ET.fromstring(raw)   # 모든 XML 파트가 실제로 읽히는지
    return True

def validate_output(path):
    p=checked_file(path);ext=p.suffix.lower()
    if ext in ('.xlsx','.docx'):
        try:
            _zip_ok(p,ext)
            if ext=='.xlsx':
                from workbook_reader import read_xlsx,WorkbookError
                try:read_xlsx(p.read_bytes())
                except WorkbookError as e:
                    # 이 앱의 읽기 범위(20MB·2만 행) 밖인 큰 파일은 압축·XML 구조 검사만으로 통과시킨다.
                    if not re.search('범위|크기|너무',str(e)):raise ValueError('xlsx')
        except Exception:raise CodexError('수정본의 파일 구조가 올바르지 않아 원본을 바꾸지 않았습니다.') from None
    elif ext=='.json':
        try:json.loads(p.read_text(encoding='utf-8-sig'))
        except Exception:raise CodexError('수정본 JSON 형식이 올바르지 않아 원본을 바꾸지 않았습니다.') from None
    return p

def _parts(p):
    with zipfile.ZipFile(p) as z:return {i.filename:(i.CRC,i.file_size) for i in z.infolist()}

def _formula_counts(p):
    out={}
    with zipfile.ZipFile(p) as z:
        for n in z.namelist():
            if n.startswith('xl/worksheets/') and n.endswith('.xml'):out[n]=z.read(n).count(b'<f')
    return out

def xlsx_extra_changes(before,after):
    """셀 값 밖의 변경을 파트 단위로 알려 준다 (이미지·서식·수식·시트 구성)."""
    a=_parts(before) if before else {};b=_parts(after);lines=[]
    media=lambda d:{k for k in d if k.startswith(('xl/media/','xl/drawings/','xl/charts/','xl/embeddings/'))}
    added=sorted(media(b)-media(a));removed=sorted(media(a)-media(b));changed=sorted(k for k in media(a)&media(b) if a[k]!=b[k])
    if added:lines.append('이미지·그림 추가: '+', '.join(x.rsplit('/',1)[-1] for x in added[:8]))
    if removed:lines.append('⚠ 이미지·그림 삭제: '+', '.join(x.rsplit('/',1)[-1] for x in removed[:8]))
    if changed:lines.append('이미지·그림 변경: '+', '.join(x.rsplit('/',1)[-1] for x in changed[:8]))
    if a and a.get('xl/styles.xml')!=b.get('xl/styles.xml'):lines.append('서식(styles) 파트 변경 — 글꼴·색·테두리 등은 수정본을 열어 확인해 주세요.')
    if before:
        fa,fb=_formula_counts(before),_formula_counts(after)
        for k in sorted(set(fa)|set(fb)):
            if fa.get(k,0)!=fb.get(k,0):lines.append(f'수식 개수 변경 ({k.rsplit("/",1)[-1]}): {fa.get(k,0)} → {fb.get(k,0)}')
        other=sorted(k for k in set(a)|set(b) if a.get(k)!=b.get(k) and not k.startswith(('xl/media/','xl/drawings/','xl/charts/','xl/embeddings/','xl/worksheets/','docProps/')) and k not in ('xl/styles.xml','xl/sharedStrings.xml','xl/calcChain.xml'))
        if other:lines.append('기타 구성 변경: '+', '.join(other[:8]))
    return lines

def _xlsx_values(p):
    from workbook_reader import read_xlsx
    return {s['name']:s['rows'] for s in read_xlsx(Path(p).read_bytes())}

def _col(n):
    s=''
    while n:n,r=divmod(n-1,26);s=chr(65+r)+s
    return s

def preview(before,after):
    """읽기 전용 미리보기. 수정본을 다른 도구로 다시 저장하지 않는다."""
    after=Path(after);ext=after.suffix.lower()
    try:
        if ext in TEXT:
            def lines(path):
                with Path(path).open('rb') as stream:return stream.read(256*1024).decode('utf-8-sig',errors='replace').splitlines()
            a=lines(before) if before else [];b=lines(after)
            note='앞부분 미리보기입니다. 전체 내용은 수정본 열기에서 확인해 주세요.\n' if after.stat().st_size>256*1024 or (before and Path(before).stat().st_size>256*1024) else ''
            return note+'\n'.join(difflib.unified_diff(a,b,fromfile='수정 전',tofile='수정 후',lineterm=''))[:16000]
        if ext=='.xlsx':
            out=[];changes=0
            try:
                av=_xlsx_values(before) if before else {};bv=_xlsx_values(after)
                for name,rows in bv.items():
                    old=av.get(name)
                    out.append(f'{name}: {len(rows):,}행'+('' if old is not None or not before else ' (새 시트)'))
                    for r in range(max(len(rows),len(old or []))):
                        ra=(old or [])[r] if r<len(old or []) else [];rb=rows[r] if r<len(rows) else []
                        for c in range(max(len(ra),len(rb))):
                            x=ra[c] if c<len(ra) else None;y=rb[c] if c<len(rb) else None
                            if x in ('',None) and y in ('',None):continue
                            if x!=y:
                                changes+=1
                                if changes<=35:out.append(f'{name}!{_col(c+1)}{r+1}: {str(x)[:100]} → {str(y)[:100]}')
                for name in set(av)-set(bv):out.append('⚠ 삭제된 시트: '+name)
                out.append(f'셀 값 변경 {changes:,}개')
            except Exception:out.append('셀 값 비교를 만들지 못했습니다 (이 앱의 읽기 범위 밖일 수 있음). 수정본을 열어 확인해 주세요.')
            extra=xlsx_extra_changes(before,after)
            out.extend(extra or ['셀 값 밖의 파트(이미지·서식·수식 개수) 변경은 찾지 못했습니다. 그래도 최종 확인은 수정본을 열어 해 주세요.'])
            return '\n'.join(out)[:16000]
    except Exception:return '내용 미리보기를 만들지 못했습니다. 수정본을 열어 확인해 주세요.'
    return '이미지·문서 파일입니다. 수정본 열기로 내용을 확인해 주세요.'


class Workspace:
    def __init__(self,root):
        self.root=Path(root);self.work=self.root/'files';self.meta=self.root/'attachments.json'
        self.work.mkdir(parents=True,exist_ok=True);os.chmod(self.root,0o700)
        try:self.records=json.loads(self.meta.read_text(encoding='utf-8'))
        except (OSError,ValueError):self.records={}

    def save(self):atomic_json(self.meta,self.records)

    def import_file(self,path,*,name=None,read_only=False,artifact=None,source=None,expected_sha=None):
        """원본(또는 앱 보관본) 전체를 바이트 그대로 작업 복사본으로. 복사 후 SHA-256 일치를 확인한다.
        artifact: 앱 자료 목록 항목 (같은 회차·버전은 다시 복사하지 않음). source: '원본에 반영'할 실제 원본 위치."""
        p=checked_file(path)
        before=digest(p)
        if expected_sha and before!=expected_sha:raise CodexError('보관된 자료의 해시가 목록과 다릅니다. 연결하지 않았습니다.')
        src=str(Path(source).resolve()) if source else str(p.resolve())
        for r in self.records.values():
            try:self.safe_work(r['name']);usable=True
            except (OSError,ValueError):usable=False
            if not usable:continue
            if artifact and (r.get('artifact') or {}).get('id')==artifact.get('id'):return r['id']        # 같은 회차·버전: 다시 복사하지 않음
            if not artifact and not r.get('artifact') and r['source']==src and r['baseline']==before:return r['id']
        if len(self.records)>=30:raise CodexError('대화 하나에 최대 30개 파일을 연결할 수 있습니다. 새 대화를 만들어 주세요.')
        key=uuid.uuid4().hex
        name=str(name or p.name)
        if Path(name).name!=name or name.startswith('.') or Path(name).suffix.lower()!=p.suffix.lower():raise CodexError('작업 복사본 파일명이 올바르지 않습니다.')
        target=self.work/name;serial=2
        while target.exists():target=self.work/(Path(name).stem+f' ({serial})'+p.suffix);serial+=1
        original=self.root/'originals'/key/p.name;original.parent.mkdir(parents=True)
        shutil.copy2(p,original)
        if digest(original)!=before or digest(p)!=before:raise CodexError('선택하는 동안 원본이 바뀌었습니다. 다시 선택해 주세요.')
        shutil.copy2(original,target)
        if digest(target)!=before:
            target.unlink(missing_ok=True);raise CodexError('작업 복사본 해시가 원본과 달라 연결하지 않았습니다.')
        self.records[key]={'id':key,'source':src,'name':target.name,'baseline':before,'original':str(original),'history':[],'readOnly':bool(read_only),'linkedAt':datetime.datetime.now().isoformat(timespec='seconds')}
        if artifact:self.records[key]['artifact']=dict(artifact)
        self.save();return key

    def detach(self,key):
        """현재 대화의 연결만 해제. 원본·앱 보관본은 지우지 않고, 작업본은 detached/ 로 옮겨 보존."""
        r=self.records.get(str(key))
        if not r:raise CodexError('연결된 파일을 다시 선택해 주세요.')
        try:
            p=self.safe_work(r['name'])
            keep=self.root/'detached'/datetime.datetime.now().strftime('%Y%m%d_%H%M%S');keep.mkdir(parents=True,exist_ok=True)
            shutil.move(str(p),str(keep/p.name))
        except (OSError,ValueError):pass
        self.records.pop(str(key),None);self.save()

    def safe_work(self,relative):
        rel=Path(str(relative))
        if rel.is_absolute() or '..' in rel.parts or any(x.startswith('.') for x in rel.parts):raise CodexError('작업 파일 경로가 올바르지 않습니다.')
        return checked_file(self.work/rel,self.work)

    def review(self):
        by_name={r['name']:r for r in self.records.values()};out=[]
        for p in sorted(self.work.rglob('*')):
            try:
                rel=str(p.relative_to(self.work));p=self.safe_work(rel)
            except (OSError,ValueError):continue
            r=by_name.get(rel);sha=digest(p);changed=sha!=(r or {}).get('baseline')
            base=None
            if not r:   # Codex가 만든 새 파일: 이름이 이어지는 연결 파일(예: 주문.xlsx → 주문_수정.xlsx)과 비교
                stem=Path(rel).stem
                base=next((x['original'] for x in self.records.values() if Path(x['name']).suffix==Path(rel).suffix and stem.startswith(Path(x['name']).stem)),None)
            out.append({'key':r['id'] if r else 'new:'+rel,'name':rel,'sha':sha,'bytes':p.stat().st_size,
                        'changed':changed,'original':bool(r and not r.get('readOnly')),'canRestore':bool(r and r['history']),
                        'source':(r or {}).get('source',''),'artifact':dict((r or {}).get('artifact') or {}),'readOnly':bool(r and r.get('readOnly')),'linked':bool(r),
                        'compareWith':Path(base).name if base else '',
                        'preview':preview(r['original'] if r else base,p) if changed else ''})
        return out

    def resolve_key(self,key):
        if str(key).startswith('new:'):return self.safe_work(str(key)[4:]),None
        r=self.records.get(str(key))
        if not r:raise CodexError('파일을 다시 선택해 주세요.')
        return self.safe_work(r['name']),r

    def apply(self,key,expected):
        p,r=self.resolve_key(key)
        if not r:raise CodexError('새 파일은 결과 저장을 눌러 주세요.')
        if r.get('readOnly'):raise CodexError('지난 회차 보관본이라 원본에 반영할 수 없습니다. 별도 저장을 사용해 주세요.')
        validate_output(p)
        if digest(p)!=expected:raise CodexError('미리보기 후 수정본이 바뀌었습니다. 변경 확인을 다시 눌러 주세요.')
        src=checked_file(r['source']);before=digest(src)
        if before!=r['baseline']:raise CodexError('다른 작업에서 원본을 변경했습니다. 덮어쓰지 않았습니다. 새 대화에서 최신 파일을 가져와 주세요.')
        stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]
        backup=self.root/'backups'/stamp/src.name;backup.parent.mkdir(parents=True)
        shutil.copy2(src,backup)
        if digest(backup)!=before or digest(src)!=before:raise CodexError('원본이 변경되어 반영하지 않았습니다.')
        baseline=self.root/'originals'/r['id']/('applied_'+stamp+p.suffix);shutil.copy2(p,baseline)
        if digest(baseline)!=expected:raise CodexError('수정본이 바뀌어 원본을 유지했습니다.')
        self._replace(baseline,src,expected,require_hash=before)
        r['history'].append({'backup':str(backup),'before':before,'after':expected,'at':stamp})
        r['baseline']=expected
        r['original']=str(baseline)   # 이후 수정은 마지막 반영본과 비교 (예전 백업은 모두 보관)
        self.save();return src

    @staticmethod
    def _replace(source,target,source_hash,require_hash=None):
        target=Path(target)
        fd,tmp=tempfile.mkstemp(prefix='.nuavu-ai-',suffix=target.suffix,dir=target.parent);os.close(fd)
        try:
            shutil.copy2(source,tmp)
            if digest(tmp)!=source_hash:raise CodexError('복사 중 파일이 바뀌어 원본을 유지했습니다.')
            if require_hash is not None and digest(target)!=require_hash:raise CodexError('원본이 바뀌어 덮어쓰지 않았습니다.')
            try:os.replace(tmp,target)
            except PermissionError:raise CodexError('원본 파일이 다른 프로그램(엑셀 등)에서 열려 있어 바꾸지 못했습니다. 파일을 닫은 뒤 다시 눌러 주세요. 원본은 그대로입니다.') from None
        finally:
            if os.path.exists(tmp):os.unlink(tmp)

    def restore(self,key):
        _,r=self.resolve_key(key)
        if not r or not r['history']:raise CodexError('되돌릴 반영 기록이 없습니다.')
        h=r['history'][-1];src=checked_file(r['source']);backup=checked_file(h['backup'])
        if digest(src)!=h['after']:raise CodexError('반영 후 원본이 다시 바뀌어 자동으로 되돌리지 않았습니다.')
        if digest(backup)!=h['before']:raise CodexError('보관된 원본을 검증하지 못했습니다.')
        self._replace(backup,src,h['before'],require_hash=h['after'])
        r['history'].pop();r['baseline']=h['before'];r['original']=str(backup);self.save();return src

    def export(self,key,expected,destination):
        p,_=self.resolve_key(key);validate_output(p)
        if digest(p)!=expected:raise CodexError('수정본이 바뀌었습니다. 변경 확인 후 다시 저장해 주세요.')
        directory=Path(destination)/datetime.datetime.now().strftime('%Y-%m-%d')/self.root.name[:8]
        directory.mkdir(parents=True,exist_ok=True);target=directory/p.name
        if target.exists():target=directory/(p.stem+'_'+uuid.uuid4().hex[:6]+p.suffix)
        self._replace(p,target,expected);return target
