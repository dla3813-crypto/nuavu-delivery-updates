#!/bin/bash
set -e
cd "$(dirname "$0")"
APP="$HOME/Applications/배송안내 배포판.app"
if [ -d "$APP" ]; then
 /usr/bin/open "$APP"
else
 /bin/bash './처음한번_앱설치.command'
fi
