"""배송안내 배포판 · Codex 대화 (2026-10-24 요청) — 공식 Codex app-server 를 이 앱의 자식 프로세스로 stdio 연결.
TCP 포트 없음 · API 키 없음 · 배송안내 앱 전용 CODEX_HOME. Nuavu Auto 1.31.1 codex_chat/rpc.py 를 이식."""
from concurrent.futures import Future
import json,os,shutil,subprocess,sys,threading
from pathlib import Path


class CodexError(ValueError):pass


IS_WINDOWS=sys.platform=='win32'

def _windows_candidates():
    """2026-10-25 배포판 윈도우: npm 전역 설치(@openai/codex)의 실제 codex.exe, ChatGPT/Codex 앱 폴더.
    codex.cmd(npm 래퍼)는 cmd.exe 를 거치므로 쓰지 않고 그 옆의 실행 파일을 찾는다."""
    out=[]
    appdata=Path(os.environ.get('APPDATA') or Path.home()/'AppData/Roaming')
    local=Path(os.environ.get('LOCALAPPDATA') or Path.home()/'AppData/Local')
    arch='aarch64-pc-windows-msvc' if 'ARM' in (os.environ.get('PROCESSOR_ARCHITECTURE','').upper()) else 'x86_64-pc-windows-msvc'
    pkg='codex-win32-arm64' if arch.startswith('aarch64') else 'codex-win32-x64'
    for npm in (appdata/'npm',local/'pnpm',Path.home()/'.bun/install/global'):
        root=npm/'node_modules/@openai'
        out+=[root/'codex/node_modules/@openai'/pkg/'vendor'/arch/'bin/codex.exe',root/pkg/'vendor'/arch/'bin/codex.exe',root/'codex/vendor'/arch/'bin/codex.exe']
    for base in (local/'Programs/ChatGPT',local/'Programs/Codex',local/'Programs/OpenAI/Codex'):
        out+=[base/'resources/codex-cli/codex.exe',base/'resources/codex.exe',base/'codex.exe']
    return out

def find_codex():
    env=os.environ.get('NUAVU_CODEX_BIN')   # 사장님이 직접 지정한 위치 (선택)
    candidates=[Path(env)] if env else []
    if IS_WINDOWS:
        candidates+=_windows_candidates()
        found=shutil.which('codex.exe')
        if found:candidates.append(Path(found))
    else:
        candidates+=[Path('/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex'),
                     Path('/Applications/Codex.app/Contents/Resources/codex'),
                     Path.home()/'Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex']
        found=shutil.which('codex')
        if found:candidates.append(Path(found))
    for p in candidates:
        try:
            if p.is_file() and (IS_WINDOWS or os.access(p,os.X_OK)) and (not IS_WINDOWS or p.suffix.lower()=='.exe'):return p.resolve()
        except OSError:continue
    if IS_WINDOWS:raise CodexError('이 컴퓨터에서 공식 Codex를 찾지 못했습니다. Node.js 설치 후 명령 프롬프트에서 "npm install -g @openai/codex" 로 Codex CLI를 설치해 주세요.')
    raise CodexError('이 컴퓨터에서 공식 Codex를 찾지 못했습니다. ChatGPT 데스크톱 앱 또는 공식 Codex CLI를 설치해 주세요.')


def child_environment(home):
    # Never inherit API/provider tokens, a remote host, or the caller's Codex environment.
    if IS_WINDOWS:
        keep=('SYSTEMROOT','SYSTEMDRIVE','WINDIR','COMSPEC','PATHEXT','USERPROFILE','USERNAME','USERDOMAIN','HOMEDRIVE','HOMEPATH',
              'APPDATA','LOCALAPPDATA','PROGRAMDATA','PROGRAMFILES','PROGRAMFILES(X86)','PROGRAMW6432','TEMP','TMP','NUMBER_OF_PROCESSORS','PROCESSOR_ARCHITECTURE','OS')
        env={k:os.environ[k] for k in keep if k in os.environ}
        root=os.environ.get('SYSTEMROOT',r'C:\Windows')
        env.update(CODEX_HOME=str(home),PATH=os.pathsep.join([root+r'\System32',root,root+r'\System32\WindowsPowerShell\v1.0']),PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
        return env
    env={k:os.environ[k] for k in ('HOME','USER','LOGNAME','TMPDIR','LANG','LC_ALL','SHELL','__CF_USER_TEXT_ENCODING') if k in os.environ}
    env.update(CODEX_HOME=str(home),PATH='/usr/bin:/bin:/usr/sbin:/sbin:/opt/homebrew/bin:/usr/local/bin',PYTHONDONTWRITEBYTECODE='1')
    return env


def _spawn_options():
    # 윈도우: 검은 콘솔 창 없이 (pythonw 에서 실행), 별도 프로세스 그룹. 맥: 별도 세션.
    if IS_WINDOWS:return {'creationflags':getattr(subprocess,'CREATE_NO_WINDOW',0x08000000)|getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0x200)}
    return {'start_new_session':True}


class Client:
    def __init__(self,home,on_event,on_request,on_exit=lambda:None,binary=None):
        self.home=Path(home);self.on_event=on_event;self.on_request=on_request;self.on_exit=on_exit
        self.binary=binary;self.proc=None;self.lock=threading.RLock();self.pending={};self.serial=0;self.closed=False

    def start(self):
        with self.lock:
            if self.proc and self.proc.poll() is None:return
            self.home.mkdir(parents=True,exist_ok=True)
            try:self.home.chmod(0o700)
            except OSError:pass
            binary=self.binary or find_codex()
            args=[str(binary),'app-server','--listen','stdio://','-c','cli_auth_credentials_store="keyring"',
                  '-c','model_provider="openai"','-c','web_search="disabled"','-c','analytics.enabled=false',
                  '-c','shell_environment_policy.inherit="none"','-c','features.multi_agent=false']
            self.closed=False
            self.proc=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
                text=True,encoding='utf-8',bufsize=1,cwd=str(self.home),env=child_environment(self.home),**_spawn_options())
            self.reader=threading.Thread(target=self._read,args=(self.proc,),daemon=True,name='nuavu-delivery-codex-rpc');self.reader.start()

    def send(self,message):
        with self.lock:
            if not self.proc or self.proc.poll() is not None:raise CodexError('Codex 연결이 종료됐습니다. 다시 연결해 주세요.')
            try:self.proc.stdin.write(json.dumps(message,ensure_ascii=False)+'\n');self.proc.stdin.flush()
            except (OSError,ValueError):raise CodexError('Codex 연결이 끊겼습니다. 같은 작업을 자동 재전송하지 않았습니다.') from None

    def call(self,method,params=None,timeout=35):
        with self.lock:
            self.serial+=1;key=self.serial;f=Future();self.pending[key]=f
        try:
            self.send({'id':key,'method':method,'params':params or {}})
            return f.result(timeout=timeout)
        except TimeoutError:raise CodexError('Codex 응답을 기다리다 멈췄습니다. 실행 결과를 확인한 뒤 다시 연결해 주세요.') from None
        finally:
            with self.lock:self.pending.pop(key,None)

    def reply(self,key,result=None,error=None):
        self.send({'id':key,**({'error':error} if error else {'result':result or {}})})

    def _read(self,proc):
        try:
            for line in proc.stdout:
                try:m=json.loads(line)
                except (ValueError,TypeError):continue
                if 'method' in m:
                    try:
                        if 'id' in m:self.on_request(m)
                        else:self.on_event(m['method'],m.get('params') or {})
                    except Exception:
                        if 'id' in m:
                            try:self.reply(m['id'],error={'code':-32603,'message':'Client could not handle this request'})
                            except Exception:pass
                elif 'id' in m:
                    with self.lock:f=self.pending.get(m['id'])
                    if f and not f.done():
                        if 'error' in m:f.set_exception(CodexError(str((m['error'] or {}).get('message','Codex 요청 실패'))))
                        else:f.set_result(m.get('result') or {})
        finally:
            with self.lock:
                pending=list(self.pending.values())
            for f in pending:
                if not f.done():f.set_exception(CodexError('Codex 연결이 종료됐습니다. 작업을 자동 재전송하지 않았습니다.'))
            if not self.closed:self.on_exit()

    def close(self):
        with self.lock:self.closed=True;proc=self.proc
        if proc and proc.poll() is None:
            try:proc.stdin.close();proc.terminate()
            except OSError:pass
            try:proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                # Only our direct child, never another Codex or the desktop app.
                proc.kill();proc.wait(timeout=2)
        if proc:
            reader=getattr(self,'reader',None)
            if reader and reader is not threading.current_thread():reader.join(timeout=1)
            if proc.stdout:proc.stdout.close()
