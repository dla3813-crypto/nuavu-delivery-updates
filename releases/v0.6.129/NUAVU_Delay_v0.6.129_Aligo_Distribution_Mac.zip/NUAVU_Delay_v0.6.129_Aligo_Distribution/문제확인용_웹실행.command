#!/bin/bash
set -e
cd "$(dirname "$0")"
source './python_locator.sh'
if ! nuavu_find_python; then nuavu_pause; exit 1; fi
PY="$NUAVU_PY"
export PYTHONDONTWRITEBYTECODE=1
# Keep the terminal window open on startup failure, so the user can read the error.
set +e
"$PY" app.py
RESULT=$?
if [ "$RESULT" -ne 0 ]; then
  echo ""
  echo "실행 중 오류가 발생했습니다. 이 화면을 확인해주세요. 고객에게 반복 발송하지 마세요."
  read -r -p "엔터를 누르면 종료합니다. " _
fi
exit "$RESULT"
