"""품절 안내 문자 → 자사몰(카페24)·에이블리 품절 옵션 OFF / 상품 미진열 (2026-10-20 05:05 설명서 + 05:08 요청, 공통).

고객 안내 문자 작성에서 품절 안내(카드/무통장) 템플릿을 요청·예약하는 즉시, 그 문자에 담긴 상품/옵션마다
 · 자사몰(카페24, 키체인에 계정이 있을 때만): 상품명 검색 → 상품코드 → 상품 수정 › 옵션/재고 › 해당 품목 진열상태 진열안함 → 상품수정.
   옵션이 원컬러면 상품 전체 진열상태 진열안함. 이미 진열안함이면 정상.
 · 에이블리: 상품 관리 상품명 검색 → 상품번호 → 수정 화면 옵션 목록 진열 여부 스위치 OFF → 수정. 원컬러면 진열 상태 미진열.
   대표 옵션으로 지정된 옵션은 스위치가 비활성이라 진열 중인 다른 옵션을 대표로 옮긴 뒤 끈다.
검색은 상품명 그대로 → 앞의 로케이션 (SC-2) 제거 → [2color] 같은 머리 태그까지 제거 순으로 시도하고, 그래도 하나로 잡히지 않으면 '검색불가'.

실측 DOM (2026-10-20, 크롬으로 8개 상품 직접 처리):
 카페24 로그인 https://eclogin.cafe24.com/Shop/ : #mall_id(loginId) #userpasswd(loginPasswd) a.btnStrong '로그인' → https://<mall>.cafe24.com/disp/admin/shop1/main/dashboard
 검색 GET /disp/admin/shop1/product/productmanage?eField[]=product_name&eValue[]=<이름>&limit=100 … 행마다 상품코드 P0000XXX 링크 → ProductRegister?product_no=N
 수정 페이지: 상품 진열 input[name="is_display[1]"] T/F · 품목마다 table.eItemRow (hidden mp_option_value[] = '그레이#$%FREE', select.eBatchIsDisplay1Mp T/F) · 저장 a#eProductModify → POST ProductModify → alert '상품이 수정되었습니다.'
 에이블리 목록 https://seller-admin.a-bly.com/goods/list : #keyword_type(ant-select → '상품명') #keyword 검색 → tbody tr.ant-table-row td[1]=상품번호 td[5]=상품명
 수정 https://seller-admin.a-bly.com/goods/<번호> : 진열 상태 .ant-radio-wrapper '진열'/'미진열' · 옵션 목록 .ant-table-tbody-virtual .ant-table-row (옵션1=색상 '블랙（모델착용）' 전각괄호, 옵션2=사이즈, 진열 여부 button[role=switch], 대표 옵션 여부 checkbox) · 맨 아래 button '수정' · 페이지 이탈 시 beforeunload 창.
"""
from __future__ import annotations
from pathlib import Path
import re,threading,time,secrets
from urllib.parse import urlsplit
from datetime import datetime,timezone,timedelta
from urllib.parse import quote,urlsplit
CANCEL_LEAD=timedelta(minutes=10)   # 2026-10-22: 예약 품절 문자 전송 10분 전에 주문취소

class DisplayError(Exception):pass
class DisplayCancelled(DisplayError):pass

LOCATION=re.compile(r'^\s*\([A-Za-z]{1,3}-?\d{1,3}\)\s*')
TAG=re.compile(r'^\s*(?:\[[^\]]*\]|\([^)]*\))\s*')
ONE_COLOR={'원컬러','onecolor','one','단일','단일색상','free','원칼라'}
CAFE_LOGIN='https://eclogin.cafe24.com/Shop/'
# 2026-10-20: the seller-admin pages only work inside the my.a-bly.com wrapper (the iframe carries the login); opening
# seller-admin.a-bly.com directly in the app's Chrome gave '에이블리 실패' for every item. Wrapper URL → iframe host/path.
ABLY_LIST='https://my.a-bly.com/goods/v2/list'            # iframe: seller-admin.a-bly.com/goods/list
ABLY_EDIT='https://my.a-bly.com/goods/v2/edit/{no}'       # iframe: seller-admin.a-bly.com/goods/{no}
ABLY_FRAME_HOST='seller-admin.a-bly.com'

def norm(s):
    """Comparison form: full/half-width parentheses and their content dropped (블랙（모델착용） = 블랙), spaces/case folded."""
    s=re.sub(r'[（(][^）)]*[）)]','',str(s or ''));return re.sub(r'\s+','',s).lower()
def norm_size(s):return norm(s).replace('(','').replace(')','')
def search_names(product):
    """['(SC-2)[2color]사이드 집업 …' , '[2color]사이드 집업 …', '사이드 집업 …'] — tried in order, duplicates dropped."""
    full=str(product or '').strip();out=[]
    for cand in (full,LOCATION.sub('',full).strip(),TAG.sub('',LOCATION.sub('',full)).strip()):
        cand=re.sub(r'\s+',' ',cand)
        if cand and cand not in out:out.append(cand)
    return out
def split_option(option):
    """'그레이-FREE' / '[그레이-FREE]' / '그레이 / FREE' / '블랙-6XL(66)' → ('그레이','FREE')."""
    t=str(option or '').strip().strip('[]').strip()
    if '/' in t:a,b=t.split('/',1)
    elif '-' in t:a,b=t.split('-',1)
    else:a,b=t,''
    return a.strip(),b.strip()
def is_one_color(color):return norm(color) in ONE_COLOR
def items_from_notice(n):
    """Distinct (product, option) pairs of a 품절 안내 notice."""
    out=[];seen=set()
    for p in n.get('products',[]) or []:
        key=(str(p.get('product','')).strip(),str(p.get('option','')).strip())
        if key[0] and key not in seen:seen.add(key);out.append({'product':key[0],'option':key[1],'seller':n.get('seller',''),'orderId':n.get('orderId','')})
    return out

# ---------------------------------------------------------------- 카페24
CAFE_ROWS_JS='''()=>[...document.querySelectorAll('table tbody tr')].filter(tr=>/P0000[A-Z0-9]+/.test(tr.innerText)).map(tr=>{const code=tr.innerText.match(/P0000[A-Z0-9]+/)[0];const a=[...tr.querySelectorAll('a')].find(a=>a.innerText.trim()===code);const pn=((a&&a.getAttribute('href'))||'').match(/product_no=(\\d+)/);const nameCell=[...tr.querySelectorAll('td')].find(td=>td.innerText.includes(code));return {code,productNo:pn?pn[1]:'',text:tr.innerText.replace(/\\s+/g,' ').trim()}})'''
CAFE_STATE_JS='''()=>({display:([...document.querySelectorAll('input[name="is_display[1]"]')].find(i=>i.checked)||{}).value||'',name:(document.querySelector('input[name="product_name[1]"]')||{}).value||'',items:[...document.querySelectorAll('table.eItemRow')].filter(t=>t.offsetParent).map(t=>({value:(t.querySelector('input[name="mp_option_value[]"]')||{}).value||'',code:(t.querySelector('input[name="mp_prd_item_code[]"]')||{}).value||'',display:(t.querySelector('select.eBatchIsDisplay1Mp')||{}).value||''})),saveBtn:!!document.querySelector('#eProductModify')})'''
CAFE_SET_ITEM_JS='''(value)=>{const t=[...document.querySelectorAll('table.eItemRow')].filter(t=>t.offsetParent).find(t=>(t.querySelector('input[name="mp_option_value[]"]')||{}).value===value);if(!t)return 'missing';const sel=t.querySelector('select.eBatchIsDisplay1Mp');if(sel.value==='F')return 'already';sel.value='F';sel.dispatchEvent(new Event('change',{bubbles:true}));return sel.value}'''
CAFE_SET_PRODUCT_JS='''()=>{const f=document.querySelector('input[name="is_display[1]"][value="F"]');if(!f)return 'missing';if(f.checked)return 'already';f.click();return f.checked?'F':'fail'}'''

class Cafe24Flow:
    def __init__(self,controller,context):
        self.c=controller;self.context=context;self.page=context.new_page();self.host='';self.step='';self.dialogs=[];self.saving=False
        def on_dialog(d):
            self.dialogs.append(d.type+':'+(d.message or '')[:80])
            try:
                if d.type=='beforeunload' or d.type=='alert' or (d.type=='confirm' and self.confirm_ok(d.message or '')):d.accept()
                else:d.dismiss()
            except Exception:pass
        self.page.on('dialog',on_dialog)
    def confirm_ok(self,message):
        """Which confirm() dialogs to accept: 상품수정 here; the cancel flow adds 취소접수/카드취소 (07:32 보고: 확인을 누르지 않아 접수가 안 됨)."""
        return getattr(self,'saving',False) or '수정' in message   # 2026-10-26 21:09: 저장 단계에서는 어떤 확인창이든 수락(기록은 남김) — 기각하면 저장이 취소된다
    def snapshot(self,label):
        """실패 원인 조사용 화면 캡처 → 바탕화면 배송지연(AI)/품절처리_실패/ (계정·비밀번호 없음, 상품 수정 화면만)."""
        try:
            d=Path.home()/'Desktop'/'배송지연(AI)'/'품절처리_실패';d.mkdir(parents=True,exist_ok=True)
            p=d/(datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+re.sub(r'[^0-9A-Za-z가-힣_-]+','_',label)[:40]+'.png')
            self.page.screenshot(path=str(p),full_page=True);return p.name
        except Exception:return ''
    def check(self):
        if hasattr(self.c,'check'):self.c.check()
    def progress(self,m):
        try:self.c.update('running',m)
        except Exception:pass
    def wait(self,pred,seconds,message):
        end=time.monotonic()+seconds
        while time.monotonic()<end:
            self.check()
            try:
                v=pred()
                if v:return v
            except Exception:pass
            self.page.wait_for_timeout(200)
        raise DisplayError(message)
    def on_admin(self):
        u=urlsplit(self.page.url);return u.hostname and u.hostname.endswith('.cafe24.com') and u.hostname!='eclogin.cafe24.com' and '/disp/admin' in u.path
    def login(self,account):
        self.step='자사몰 로그인';self.progress('자사몰(카페24) 관리자 로그인 화면을 엽니다.')
        self.page.goto(CAFE_LOGIN,wait_until='domcontentloaded',timeout=45000)
        self.wait(lambda:self.on_admin() or self.page.locator('#mall_id').count()==1,30,'카페24 로그인 화면을 열지 못했습니다.')
        if not self.on_admin():
            user=self.page.locator('#mall_id');pw=self.page.locator('#userpasswd')
            for loc,value in ((user,account['username']),(pw,account['password'])):
                self.check();loc.fill('');loc.press_sequentially(value,delay=20)
                if loc.input_value()!=value:raise DisplayError('카페24 로그인 입력값이 일치하지 않습니다. 저장 계정을 확인하세요.')
            btn=self.page.locator('.btnStrong',has_text=re.compile(r'^\s*로그인\s*$'))   # 2026-10-22 실측: 지금은 button.btnStrong (예전 a)
            if btn.count():btn.first.click(timeout=10000)
            else:pw.press('Enter')
            import browser_window;started=time.monotonic()
            def signed():
                if time.monotonic()-started>8:
                    if browser_window.need_person():raise DisplayError('카페24 추가 인증 또는 로그인 확인이 필요합니다. '+browser_window.need_person())
                    browser_window.attention()
                return self.on_admin()
            self.wait(signed,120,'카페24 로그인을 확인하지 못했습니다. 계정 또는 추가 인증을 확인하세요.')
            browser_window.calm()
        self.page.wait_for_timeout(1500)   # 설명서: 로그인 후 1.5초 뒤 대시보드
        self.host=urlsplit(self.page.url).hostname
        self.progress('자사몰 로그인 확인 · '+self.host)
    def search(self,name):
        url=f'https://{self.host}/disp/admin/shop1/product/productmanage?eField%5B%5D=product_name&eValue%5B%5D={quote(name)}&product_type=all&display=A&selling=A&limit=100&bIsSearchClickAction=T'
        self.step='자사몰 상품 검색 · '+name;self.page.goto(url,wait_until='domcontentloaded',timeout=45000)
        self.wait(lambda:self.page.locator('#eBtnSearch').count()>=1 or self.page.locator('table').count()>0,30,'자사몰 상품 목록이 열리지 않았습니다.')
        self.page.wait_for_timeout(800)
        return self.page.evaluate(CAFE_ROWS_JS)
    def find_product(self,product):
        tried=[]
        for name in search_names(product):
            rows=self.search(name);tried.append(f'{name} ({len(rows)}건)')
            exact=[r for r in rows if norm(name) in norm(r['text'])]
            pick=rows if len(rows)==1 else exact if len(exact)==1 else []
            if len(pick)==1 and pick[0]['productNo']:return pick[0],tried
        return None,tried
    def state(self,product_no):
        self.page.goto(f'https://{self.host}/disp/admin/product/ProductRegister?product_no={product_no}',wait_until='domcontentloaded',timeout=45000)
        self.wait(lambda:self.page.evaluate(CAFE_STATE_JS)['saveBtn'],30,'자사몰 상품 수정 화면이 열리지 않았습니다.')
        self.page.wait_for_timeout(1200)
        return self.page.evaluate(CAFE_STATE_JS)
    def set_off(self,product_no,color,size):
        st=self.state(product_no);one=is_one_color(color)
        if one:
            if st['display']=='F':return {'result':'자사몰 이미 진열안함','detail':'상품 전체'}
            r=self.page.evaluate(CAFE_SET_PRODUCT_JS)
            if r!='F':raise DisplayError('자사몰 상품 진열안함 선택에 실패했습니다 ('+str(r)+').')
            label='상품 전체 진열안함'
        else:
            match=[i for i in st['items'] if i['value'] and norm(i['value'].split('#$%')[0])==norm(color) and norm_size(i['value'].split('#$%')[1] if '#$%' in i['value'] else '')==norm_size(size)]
            if not match:raise DisplayError('자사몰 품목에서 옵션을 찾지 못했습니다: '+', '.join(i['value'].replace('#$%','/') for i in st['items'])[:200])
            if match[0]['display']=='F':return {'result':'자사몰 이미 진열안함','detail':match[0]['value'].replace('#$%','/')}
            r=self.page.evaluate(CAFE_SET_ITEM_JS,match[0]['value'])
            if r!='F':raise DisplayError('자사몰 품목 진열안함 선택에 실패했습니다 ('+str(r)+').')
            label=match[0]['value'].replace('#$%','/')+' 진열안함'
        self.step='자사몰 상품수정 저장';self.check()
        def save_and_verify():
            seen=len(self.dialogs);self.saving=True
            try:
                self.page.locator('#eProductModify').first.click(timeout=10000)
                self.wait(lambda:'ProductModify' in self.page.url or 'ProductBlank' in self.page.url or any('수정되었습니다' in d for d in self.dialogs[seen:]),40,'자사몰 상품수정 결과를 확인하지 못했습니다.')
            finally:self.saving=False
            self.page.wait_for_timeout(1500)
            after=self.state(product_no)
            ok=(after['display']=='F') if one else any(i['value']==match[0]['value'] and i['display']=='F' for i in after['items'])
            return ok,after,self.dialogs[seen:]
        ok,after,dialogs=save_and_verify()
        if not ok:   # 2026-10-26 21:22 실측: 저장은 됐는데 바로 다시 연 화면엔 아직 옛 값(T) → 잠시 뒤 한 번 더 읽는다
            self.progress('자사몰 저장 반영을 다시 확인합니다.');self.page.wait_for_timeout(4000)
            after=self.state(product_no)
            ok=(after['display']=='F') if one else any(i['value']==match[0]['value'] and i['display']=='F' for i in after['items'])
            if ok:label+=' (반영 확인에 잠시 걸림)'
        if not ok:   # 그래도 아니면 품목 선택부터 다시 하고 한 번 더 저장
            self.progress('자사몰 저장이 반영되지 않아 한 번 더 시도합니다.')
            r=self.page.evaluate(CAFE_SET_PRODUCT_JS) if one else self.page.evaluate(CAFE_SET_ITEM_JS,match[0]['value'])
            if r in ('F','already'):ok,after,dialogs2=save_and_verify();dialogs=dialogs+dialogs2
        if not ok:
            shot=self.snapshot('자사몰_미반영_'+str(product_no))
            cur=after['display'] if one else next((i['display'] for i in after['items'] if i['value']==match[0]['value']),'?')
            raise DisplayError('자사몰 저장 후 다시 열었더니 반영되지 않았습니다 (2회 시도). 저장 중 대화창: '+(' | '.join(dialogs)[:160] or '없음')+' · 다시 연 상태: '+('상품 진열 ' if one else '품목 진열 ')+str(cur)+(' · 화면 캡처: '+shot if shot else ''))
        return {'result':'자사몰 처리 완료','detail':label+(' · 저장 중 확인창: '+' | '.join(dialogs)[:120] if dialogs else '')}

# ---------------------------------------------------------------- 에이블리
ABLY_ROWS_JS='''()=>[...document.querySelectorAll('tbody tr.ant-table-row')].map(tr=>{const tds=[...tr.querySelectorAll('td')];return {no:(tds[1]||{}).innerText?.trim()||'',name:((tds[5]||{}).innerText||'').replace(/\\s+/g,' ').trim(),hidden:tr.innerText.includes('미진열')}})'''
ABLY_OPTS_JS='''()=>{const optTable=[...document.querySelectorAll('table')].find(t=>/진열 여부/.test(t.innerText));if(!optTable)return null;optTable.scrollIntoView({block:'center'});const wrap=optTable.closest('.ant-table-wrapper')||optTable.closest('.ant-table');const heads=[...optTable.querySelectorAll('thead th')].map(t=>t.innerText.replace(/\\s+/g,' ').trim());return [...wrap.querySelectorAll('.ant-table-tbody-virtual .ant-table-row')].map((tr,i)=>{const c=[...tr.querySelectorAll('.ant-table-cell')];const sw=(c[heads.indexOf('진열 여부')]||{querySelector:()=>null}).querySelector('button[role=switch]');const rep=(c[heads.indexOf('대표 옵션 여부')]||{querySelector:()=>null}).querySelector('input[type=checkbox]');return {i,color:(c[heads.indexOf('옵션1')]||{}).innerText?.trim()||'',size:(c[heads.indexOf('옵션2')]||{}).innerText?.trim()||'',no:(c[heads.indexOf('옵션 번호')]||{}).innerText?.trim()||'',on:sw?sw.getAttribute('aria-checked')==='true':null,disabled:sw?sw.disabled:true,rep:rep?rep.checked:false}})}'''
ABLY_CLICK_JS='''([i,what])=>{const optTable=[...document.querySelectorAll('table')].find(t=>/진열 여부/.test(t.innerText));const wrap=optTable.closest('.ant-table-wrapper')||optTable.closest('.ant-table');const heads=[...optTable.querySelectorAll('thead th')].map(t=>t.innerText.replace(/\\s+/g,' ').trim());const tr=[...wrap.querySelectorAll('.ant-table-tbody-virtual .ant-table-row')][i];if(!tr)return 'missing';const c=[...tr.querySelectorAll('.ant-table-cell')];if(what==='rep'){const cb=c[heads.indexOf('대표 옵션 여부')].querySelector('input[type=checkbox]');cb.click();return 'clicked';}const sw=c[heads.indexOf('진열 여부')].querySelector('button[role=switch]');if(sw.disabled)return 'disabled';sw.click();return 'clicked'}'''
ABLY_RADIO_JS='''()=>{const groups=[...document.querySelectorAll('.ant-radio-group')].filter(g=>/미\\s*진열/.test(g.innerText)&&/진열/.test(g.innerText));const g=groups[0];if(!g)return 'missing';const off=[...g.querySelectorAll('.ant-radio-wrapper')].find(r=>/^미\\s*진열$/.test(r.innerText.trim()));if(!off)return 'missing';const inp=off.querySelector('input');if(inp.checked)return 'already';inp.click();return inp.checked?'off':'fail'}'''
ABLY_RADIO_STATE_JS='''()=>{const g=[...document.querySelectorAll('.ant-radio-group')].find(g=>/미\\s*진열/.test(g.innerText));if(!g)return '';const on=[...g.querySelectorAll('.ant-radio-wrapper')].find(r=>r.querySelector('input').checked);return on?on.innerText.trim():''}'''
NEUTRALIZE_UNLOAD='''()=>{window.addEventListener('beforeunload',e=>{e.stopImmediatePropagation();},true);window.onbeforeunload=null;}'''

class AblyDisplayFlow:
    """Runs inside an AblySession context (already logged in through return_session). Only navigation + DOM here."""
    def __init__(self,session):self.s=session;self.page=session.context.new_page();self.step='';self.f=None
    def check(self):self.s.c.check()
    def progress(self,m):
        try:self.s.c.update('running',m)
        except Exception:pass
    def wait(self,pred,seconds,message):
        end=time.monotonic()+seconds
        while time.monotonic()<end:
            self.check()
            try:
                v=pred()
                if v:return v
            except Exception:pass
            self.page.wait_for_timeout(200)
        raise DisplayError(message)
    def goto(self,url,path):
        """Open a my.a-bly.com wrapper page and wait for its seller-admin iframe (path) — every DOM step then runs in self.f."""
        for fr in self.page.frames:
            try:fr.evaluate(NEUTRALIZE_UNLOAD)
            except Exception:pass
        self.f=None
        self.page.goto(url,wait_until='domcontentloaded',timeout=45000)
        def frame():
            fs=[fr for fr in self.page.frames if urlsplit(fr.url).hostname==ABLY_FRAME_HOST and urlsplit(fr.url).path.rstrip('/')==path]
            return fs[0] if len(fs)==1 else None
        self.f=self.wait(frame,40,'에이블리 화면(iframe)이 열리지 않았습니다. 로그인 상태를 확인하세요.')
        if urlsplit(self.page.url).path=='/login':raise DisplayError('에이블리 로그인이 풀렸습니다.')
        return self.f
    def search(self,name):
        self.step='에이블리 상품 검색 · '+name;f=self.goto(ABLY_LIST,'/goods/list')
        self.wait(lambda:f.locator('#keyword_type').count()==1,30,'에이블리 상품 관리 목록이 열리지 않았습니다. 로그인 상태를 확인하세요.')
        self.page.wait_for_timeout(800)
        # 06:47 보고: contains(@class,"ant-select") 가 바로 위 .ant-select-selection-search 를 잡아 .ant-select-selector 가 없었음 →
        # 정확히 ant-select 클래스를 가진 조상(.ant-select > .ant-select-selector > .ant-select-selection-search > input#keyword_type).
        sel=f.locator('#keyword_type').locator('xpath=ancestor::div[contains(concat(" ",normalize-space(@class)," ")," ant-select ")][1]')
        try:sel.locator('.ant-select-selector').first.click(timeout=5000)
        except Exception:f.locator('#keyword_type').click(force=True,timeout=5000)   # antd opens the dropdown on the input's mousedown too
        self.page.wait_for_timeout(400)
        opt=f.locator('.ant-select-item-option',has_text=re.compile(r'^\s*상품명\s*$'))
        if opt.count()<1:raise DisplayError('에이블리 검색 조건에서 상품명을 찾지 못했습니다.')
        opt.first.click(timeout=5000);self.page.wait_for_timeout(300)
        kw=f.locator('#keyword');self.wait(lambda:kw.is_enabled(),10,'에이블리 검색어 입력칸이 열리지 않았습니다.')
        kw.fill('');kw.fill(name)
        f.locator('button',has_text=re.compile(r'^\s*검색\s*$')).first.click(timeout=5000)
        self.page.wait_for_timeout(2500)
        self.wait(lambda:re.search(r'총\s*[\d,]+\s*개',f.locator('body').inner_text()),20,'에이블리 검색 결과가 표시되지 않았습니다.')
        return f.evaluate(ABLY_ROWS_JS)
    def find_product(self,product):
        # 2026-10-22: 에이블리 상품명에는 (C-13) 같은 위치 코드가 없다 → 코드 뗀 이름부터 검색. 결과 없음은 다음 이름으로 넘어감.
        tried=[];names=[n for n in search_names(product) if not LOCATION.match(n)] or search_names(product)
        for name in names:
            try:rows=self.search(name)
            except DisplayError as exc:
                tried.append(f'{name} (결과 없음)');continue
            tried.append(f'{name} ({len(rows)}건)')
            exact=[r for r in rows if norm(r['name'])==norm(name)]
            pick=rows if len(rows)==1 else exact if len(exact)==1 else []
            if len(pick)==1 and pick[0]['no']:return pick[0],tried
        return None,tried
    def open_edit(self,no):
        self.step=f'에이블리 상품 {no} 수정 화면';f=self.goto(ABLY_EDIT.format(no=no),f'/goods/{no}')
        self.wait(lambda:f.evaluate(ABLY_OPTS_JS) is not None and f.locator('button',has_text=re.compile(r'^\s*수정\s*$')).count()>=1,40,'에이블리 상품 수정 화면이 열리지 않았습니다.')
        self.page.wait_for_timeout(1500)
    def options(self):
        self.f.evaluate(ABLY_OPTS_JS);self.page.wait_for_timeout(800)
        return self.f.evaluate(ABLY_OPTS_JS) or []
    def save(self):
        self.step='에이블리 수정 저장';self.check()
        self.f.locator('button',has_text=re.compile(r'^\s*수정\s*$')).last.click(timeout=10000)
        self.page.wait_for_timeout(3500)
    def set_off(self,no,color,size):
        self.open_edit(no);one=is_one_color(color)
        if one:
            if self.f.evaluate(ABLY_RADIO_STATE_JS).replace(' ','')=='미진열':return {'result':'에이블리 이미 미진열','detail':'상품 전체'}
            r=self.f.evaluate(ABLY_RADIO_JS)
            if r not in ('off','already'):raise DisplayError('에이블리 미진열 선택에 실패했습니다 ('+str(r)+').')
            self.save();self.open_edit(no)
            if self.f.evaluate(ABLY_RADIO_STATE_JS).replace(' ','')!='미진열':raise DisplayError('에이블리 저장 후 다시 열었더니 미진열이 아닙니다.')
            return {'result':'에이블리 처리 완료','detail':'상품 전체 미진열'}
        opts=self.options()
        match=[o for o in opts if norm(o['color'])==norm(color) and norm_size(o['size'])==norm_size(size)]
        if not match:raise DisplayError('에이블리 옵션 목록에서 옵션을 찾지 못했습니다: '+', '.join(o['color']+'/'+o['size'] for o in opts)[:200])
        target=match[0]
        if target['on'] is False:return {'result':'에이블리 이미 미진열','detail':target['color']+'/'+target['size']}
        moved=''
        if target['rep']:
            other=next((o for o in opts if o['i']!=target['i'] and o['on']),None)
            if not other:raise DisplayError('대표 옵션을 넘길 진열 중인 다른 옵션이 없어 끌 수 없습니다.')
            self.f.evaluate(ABLY_CLICK_JS,[other['i'],'rep']);self.page.wait_for_timeout(800);moved=other['color']+'/'+other['size']
            opts=self.options();target=next(o for o in opts if o['i']==match[0]['i'])
        r=self.f.evaluate(ABLY_CLICK_JS,[target['i'],'switch'])
        if r!='clicked':raise DisplayError('에이블리 진열 여부 스위치를 누르지 못했습니다 ('+str(r)+').')
        self.page.wait_for_timeout(800)
        if next(o for o in self.options() if o['i']==target['i'])['on'] is not False:raise DisplayError('에이블리 스위치가 꺼지지 않았습니다.')
        self.save();self.open_edit(no)
        after=next((o for o in self.options() if norm(o['color'])==norm(color) and norm_size(o['size'])==norm_size(size)),None)
        if not after or after['on'] is not False:raise DisplayError('에이블리 저장 후 다시 열었더니 옵션이 다시 진열 중입니다.')
        return {'result':'에이블리 처리 완료','detail':target['color']+'/'+target['size']+' 진열 OFF'+(' · 대표 옵션 → '+moved if moved else '')}

# ---------------------------------------------------------------- runner
def run_display_off(controller,items,cafe_account,ably_account,shop_name):
    """items: [{'product','option',...}] → list of result dicts (one per item). Each platform runs in its own Chrome."""
    from playwright.sync_api import sync_playwright
    from return_session import launch_chrome,new_context,AblySession
    results=[{**it,'at':datetime.now(timezone.utc).isoformat(timespec='seconds'),'cafe24':'','cafe24Detail':'','ably':'','ablyDetail':''} for it in items]
    for r in results:
        r['color'],r['size']=split_option(r['option']);r['oneColor']=is_one_color(r['color'])
    with sync_playwright() as pw:
        # 자사몰
        if cafe_account:
            browser=launch_chrome(pw);context=new_context(browser,accept_downloads=False)
            try:
                flow=Cafe24Flow(controller,context)
                try:flow.login(cafe_account)
                except DisplayCancelled:raise
                except Exception as exc:
                    for r in results:r['cafe24']='자사몰 실패';r['cafe24Detail']='로그인 · '+(str(exc) or type(exc).__name__)[:320]
                    flow=None
                if flow:
                    for n,r in enumerate(results,1):
                        controller.check();controller.update('running',f'자사몰 {n}/{len(results)} · {r["product"]} / {r["option"]}')
                        try:
                            hit,tried=flow.find_product(r['product'])
                            if not hit:r['cafe24']='자사몰 검색불가';r['cafe24Detail']=' → '.join(tried)[:200];continue
                            out=flow.set_off(hit['productNo'],r['color'],r['size']);r['cafe24']=out['result'];r['cafe24Detail']=f'{hit["code"]} · '+out['detail']
                        except DisplayCancelled:raise
                        except Exception as exc:r['cafe24']='자사몰 실패';r['cafe24Detail']=(flow.step+' · ' if flow.step else '')+(str(exc) or type(exc).__name__)[:320]
            finally:context.close();browser.close()
        else:
            for r in results:r['cafe24']='자사몰 계정 없음';r['cafe24Detail']='⚙ 설정 › 로그인에 자사몰(카페24) 계정이 없어 건너뜀'
        # 에이블리
        browser=launch_chrome(pw);context=new_context(browser,accept_downloads=False)
        try:
            session=AblySession(controller,context,shop_name)
            try:session.login(dict(ably_account) if ably_account else {})
            except DisplayCancelled:raise
            except Exception as exc:
                for r in results:r['ably']='에이블리 실패';r['ablyDetail']='로그인 · '+(str(exc) or type(exc).__name__)[:320]
                return results
            flow=AblyDisplayFlow(session)
            for n,r in enumerate(results,1):
                controller.check();controller.update('running',f'에이블리 {n}/{len(results)} · {r["product"]} / {r["option"]}')
                try:
                    hit,tried=flow.find_product(r['product'])
                    if not hit:r['ably']='에이블리 검색불가';r['ablyDetail']=' → '.join(tried)[:200];continue
                    out=flow.set_off(hit['no'],r['color'],r['size']);r['ably']=out['result'];r['ablyDetail']=f'{hit["no"]} · '+out['detail']
                except DisplayCancelled:raise
                except Exception as exc:r['ably']='에이블리 실패';r['ablyDetail']=(flow.step+' · ' if flow.step else '')+(str(exc) or type(exc).__name__)[:320]
        finally:
            try:
                if ably_account:ably_account.clear()
            except Exception:pass
            context.close();browser.close()
    return results

class SoldoutDisplayController:
    """Queue: 품절 안내 문자 commit → items; a worker processes them when no other web job runs. Results → state['soldoutDisplayLog'] + job alert."""
    def __init__(self,engine,runner=None,busy=None,vault=None,cafe_vault=None):
        self.engine=engine;self.store=engine.store;self.runner=runner;self.cancel_runner=None;self.busy=busy or (lambda:False);self.vault=vault;self.cafe_vault=cafe_vault
        self.lock=threading.RLock();self.stop=threading.Event();self.scheduler_stop=threading.Event();self.thread=None;self.scheduler_thread=None
        self.queue=[];self.job={'phase':'idle','message':'품절 안내 문자를 작성하면 자사몰·에이블리 품절 처리가 자동으로 시작됩니다.'}
        with self.store.edit() as s:
            if not isinstance(s.get('soldoutDisplayLog'),list):s['soldoutDisplayLog']=[]
            if not isinstance(s.get('soldoutDisplayQueue'),list):s['soldoutDisplayQueue']=[]
            if not isinstance(s.get('soldoutCancelLog'),list):s['soldoutCancelLog']=[]
            if not isinstance(s.get('soldoutCancelSchedule'),list):s['soldoutCancelSchedule']=[]
            self.queue=list(s['soldoutDisplayQueue'])
    def running(self):return bool(self.thread and self.thread.is_alive())
    def check(self):
        if self.stop.is_set() or self.scheduler_stop.is_set():raise DisplayCancelled('품절 처리를 중단했습니다.')
    def update(self,phase,message):
        with self.lock:self.job.update(phase=phase,message=message)
    def status(self):
        with self.lock:
            s=self.store.read()
            sched=[{'id':e.get('id'),'at':e.get('at'),'source':e.get('source',''),'sendAt':e.get('sendAt',''),'count':len(e.get('targets') or []),
                    'orders':[f"{ {'cafe24':'자사몰','zigzag':'지그재그'}.get(t.get('platform'),'에이블리')} {t.get('orderId') or t.get('sno','')}" for t in (e.get('targets') or [])][:20]} for e in s.get('soldoutCancelSchedule',[])]
            return {**self.job,'running':self.running(),'queued':len(self.queue),'log':list(reversed(s.get('soldoutDisplayLog',[])[-100:])),'cancelLog':list(reversed(s.get('soldoutCancelLog',[])[-100:])),'cancelSchedule':sched}
    def enqueue(self,items,source=''):
        """items: per-row dicts (product/option + seller/orderId/orderItemIds). Display is deduped by (product, option);
        every order row is kept under 'orders' so the batch can also cancel those orders (2026-10-20 06:05)."""
        stamp=datetime.now(timezone.utc).isoformat(timespec='seconds');items=[i for i in items if str(i.get('product','')).strip()]
        if not items:return 0
        with self.lock:
            by_key={(q['product'],q['option']):q for q in self.queue};new=0
            for i in items:
                key=(str(i.get('product','')).strip(),str(i.get('option','')).strip())
                order={'seller':str(i.get('seller','')),'orderId':str(i.get('orderId','')),'orderItemIds':[str(x) for x in (i.get('orderItemIds') or []) if x]}
                for k in ('key','sendAt'):
                    if i.get(k):order[k]=str(i[k])
                q=by_key.get(key)
                if q is None:
                    q={'product':key[0],'option':key[1],'seller':order['seller'],'orderId':order['orderId'],'orders':[],'source':source,'queuedAt':stamp}
                    by_key[key]=q;self.queue.append(q);new+=1
                q.setdefault('orders',[])
                if order['orderId'] and order not in q['orders']:q['orders'].append(order)
            with self.store.edit() as s:s['soldoutDisplayQueue']=list(self.queue)
        self.kick();return new
    def kick(self):
        with self.lock:
            if self.running() or not self.queue or self.busy() or self.engine.stop.is_set() or getattr(self.engine,'reset_in_progress',False):return False
            batch=list(self.queue);self.queue=[]
            with self.store.edit() as s:s['soldoutDisplayQueue']=[]
            self.stop.clear();self.job={'id':secrets.token_urlsafe(12),'phase':'running','message':f'품절 처리 {len(batch)}건 · Chrome을 엽니다.'}
            self.thread=threading.Thread(target=self._run,args=(batch,),daemon=True);self.thread.start();return True
    def _accounts(self):
        from cafe24_credentials import Cafe24Accounts
        from ably_credentials import AblyAccounts
        from aftersales_data import shop
        cafe=None;note=''
        try:cafe=Cafe24Accounts(self.store.directory,self.cafe_vault).for_login()
        except Exception as exc:note='자사몰 계정 확인 실패 · '+str(exc)
        try:ably=AblyAccounts(self.store.directory,self.vault).for_login()
        except Exception as exc:ably=None;note=(note+' · ' if note else '')+str(exc)
        return cafe,ably,shop(self.store.read())['shopName'],note
    def _run(self,batch):
        try:
            cafe,ably,shop_name,note=self._accounts()
            if ably is None:
                results=[{**it,'cafe24':'','cafe24Detail':'','ably':'에이블리 실패','ablyDetail':note} for it in batch]
            # 2026-10-22: 미진열 단계는 끝날 때 받은 계정을 지운다 → 사본을 넘겨야 바로 뒤 주문취소 단계가 '에이블리 계정 없음'이 되지 않는다.
            else:results=(self.runner or run_display_off)(self,batch,dict(cafe) if cafe else cafe,dict(ably),shop_name)
            for r in results:r.pop('orders',None)
            with self.store.edit() as s:
                log=s.setdefault('soldoutDisplayLog',[]);log.extend(results);del log[:-500]
            bad=[r for r in results if any(str(r.get(k,'')).endswith(('실패','검색불가')) for k in ('cafe24','ably'))]
            def line(r):
                parts=[]
                for k in ('cafe24','ably'):
                    v=str(r.get(k,''));parts.append(v+((' ('+str(r.get(k+'Detail',''))[:140]+')') if v.endswith(('실패','검색불가')) and r.get(k+'Detail') else ''))
                return f'{r["product"]} / {r["option"]}: '+' · '.join(parts)
            summary='; '.join(line(r) for r in results)[:900]
            self.engine.add_job_alert('품절 옵션 처리 '+('확인 필요' if bad else '완료'),summary,'error' if bad else 'info')
            # 주문 취소 접수 (2026-10-20 06:05): same batch, after the option OFF. 자사몰 without a saved account is skipped.
            try:cancels=self._cancel_orders(batch,cafe,ably)
            finally:
                for acct in (cafe,ably):
                    try:
                        if acct:acct.clear()
                    except Exception:pass
            cbad=[r for r in cancels if str(r.get('result','')).endswith('실패')]
            self.update('error' if bad or cbad else 'done',f'품절 처리 {len(results)}건 · 확인 필요 {len(bad)}건' if bad else f'품절 처리 {len(results)}건 완료'+(f' · 주문취소 {len(cancels)}건'+(f' (실패 {len(cbad)}건)' if cbad else '') if cancels else ''))
        except DisplayCancelled as exc:self.update('error',str(exc))
        except Exception as exc:
            self.update('error','품절 처리 중 문제가 발생했습니다: '+(str(exc) or type(exc).__name__)[:200])
            with self.lock:
                self.queue=batch+self.queue
                with self.store.edit() as s:s['soldoutDisplayQueue']=list(self.queue)
            try:self.engine.add_job_alert('품절 옵션 처리 실패',(str(exc) or type(exc).__name__)[:300],'error')
            except Exception:pass
    def _cancel_orders(self,batch,cafe,ably):
        from soldout_cancel import cancel_targets,run_cancellations
        flat=[]
        for it in batch:
            for o in it.get('orders') or []:
                for iid in o.get('orderItemIds') or ['']:
                    flat.append({'seller':o.get('seller',''),'orderId':o.get('orderId',''),'orderItemId':iid,'product':it['product'],'option':it['option'],'rowKey':o.get('key',''),'sendAt':o.get('sendAt','')})
        targets=cancel_targets(flat)
        if not targets:return []
        now=datetime.now(timezone.utc);later={}
        for t in targets:
            at=self.cancel_at(t.get('sendAt'))
            if at and at>now:later.setdefault(t['sendAt'],[]).append(t)
        for send_at,group in later.items():self.schedule_cancel(group,self.cancel_at(send_at),'notice',send_at)
        due=[t for t in targets if not any(t is x for g in later.values() for x in g)]
        return self._run_cancel_targets(due,cafe,ably) if due else []
    def _run_cancel_targets(self,targets,cafe,ably,test=False):
        from soldout_cancel import run_cancellations
        self.update('running',f'주문 취소 접수 {len(targets)}건 · Chrome을 엽니다.')
        try:results=(self.cancel_runner or run_cancellations)(self,targets,cafe,ably)
        except DisplayCancelled:raise
        except Exception as exc:
            results=[{**t,'result':{'cafe24':'자사몰','zigzag':'지그재그'}.get(t['platform'],'에이블리')+' 취소 실패','detail':(str(exc) or type(exc).__name__)[:200],'at':datetime.now(timezone.utc).isoformat(timespec='seconds')} for t in targets]
        for r in results:
            if test:r['test']=True
        with self.store.edit() as s:
            log=s.setdefault('soldoutCancelLog',[]);log.extend(results);del log[:-500]
        bad=[r for r in results if str(r.get('result','')).endswith('실패')]
        # 07:07 보고: the alert line carries the 상세 too, so a failure can be read without opening the 이력.
        summary='; '.join(f'{r.get("orderId","")}{(" · "+r["sno"]) if r.get("sno") else ""}: {r.get("result","")}'+((' ('+str(r.get('detail',''))[:140]+')') if r.get('detail') and str(r.get('result','')).endswith(('실패','확인 필요')) else '') for r in results)[:900]
        try:self.engine.add_job_alert('품절 주문취소 '+('확인 필요' if bad else '접수 완료'),summary,'error' if bad else 'info')
        except Exception:pass
        return results
    # ---- 07:07 요청: 테스트 버튼 (정상 동작 확인 뒤 제거 예정). 실제 사이트에서 실제로 처리하므로 테스트용 주문/상품으로만.
    def test_cancel(self,payload):
        from soldout_cancel import cancel_targets
        if not isinstance(payload,dict):raise DisplayError('테스트 입력을 확인하세요.')
        platform=str(payload.get('platform','')).strip();ident=str(payload.get('id','')).strip()
        if platform not in ('cafe24','ably','zigzag') or not ident or len(ident)>60:raise DisplayError('플랫폼(자사몰/에이블리/지그재그)과 주문번호(자사몰·지그재그) 또는 상품주문번호(에이블리)를 입력하세요.')
        item={'seller':{'cafe24':'누아브 자사몰','zigzag':'누아브 지그재그'}.get(platform,'누아브 에이블리'),'orderId':ident if platform in ('cafe24','zigzag') else '','orderItemId':ident if platform=='ably' else '','product':'','option':''}
        targets=cancel_targets([item])
        if not targets:raise DisplayError('번호 형식을 확인하세요. 자사몰: 20261018-0000029_1456 (주문번호_품목번호) · 에이블리: 상품주문번호 숫자 · 지그재그: 주문번호 숫자.')
        with self.lock:
            if self.running():raise DisplayError('품절 처리가 진행 중입니다. 끝난 뒤 실행하세요.')
            if self.busy():raise DisplayError('주문 불러오기·동기화·반품체크가 끝난 뒤 실행하세요.')
            self.stop.clear();self.job={'id':secrets.token_urlsafe(12),'phase':'running','message':'취소 테스트 · Chrome을 엽니다.'}
            def run():
                try:
                    cafe,ably,shop_name,note=self._accounts()
                    if ably is None and any(t['platform']=='ably' for t in targets):raise DisplayError(note or '에이블리 계정이 없습니다.')
                    results=self._run_cancel_targets(targets,cafe,ably,test=True)
                    bad=[r for r in results if str(r.get('result','')).endswith(('실패','확인 필요'))]
                    self.update('error' if bad else 'done','취소 테스트 '+('실패: ' if bad else '완료: ')+'; '.join(f'{r.get("result","")} · {r.get("detail","")}' for r in results)[:600])
                except DisplayCancelled as exc:self.update('error',str(exc))
                except Exception as exc:self.update('error','취소 테스트 실패: '+(str(exc) or type(exc).__name__)[:300])
            self.thread=threading.Thread(target=run,daemon=True);self.thread.start()
        return self.status()
    # ---- 2026-10-22 요청: 품절칸 '취소만 진행' — 미진열·문자/알림톡 없이 선택 주문의 취소 접수만 (실제 처리).
    DONE_RESULTS=('자사몰 취소 완료','자사몰 이미 취소됨','에이블리 취소 완료','지그재그 취소 완료')
    @staticmethod
    def target_key(t):
        if t.get('platform')=='ably':return ('ably',str(t.get('sno','')))
        if t.get('platform')=='zigzag':return ('zigzag',str(t.get('orderId','')))   # 지그재그는 주문 단위로 한 번만
        return ('cafe24',str(t.get('orderId','')),str(t.get('omNo','')))
    def cancel_only_targets(self,keys):
        """Selected order rows → cancel targets, minus ones the 이력 already shows as 취소 완료 (no double cancel)."""
        from soldout_cancel import cancel_targets
        if not isinstance(keys,list) or not keys or len(keys)>500 or not all(isinstance(k,str) for k in keys):raise DisplayError('취소할 주문을 선택하세요.')
        s=self.store.read();want=set(keys);flat=[]
        for r in s.get('rows',[]):
            if r.get('key') not in want:continue
            ids=[p.get('id') for p in (r.get('orderItems') or []) if p.get('id')] or ([r['orderItemId']] if r.get('orderItemId') else [])
            for iid in ids or ['']:
                flat.append({'seller':r.get('seller',''),'orderId':r.get('orderId',''),'orderItemId':str(iid),'product':r.get('product',''),'option':r.get('option','')})
        targets=cancel_targets(flat)
        done={self.target_key(x) for x in s.get('soldoutCancelLog',[]) if not x.get('test') and x.get('result') in self.DONE_RESULTS}
        todo=[t for t in targets if self.target_key(t) not in done];skipped=len(targets)-len(todo)
        if not targets:raise DisplayError('선택한 주문에 취소할 자사몰·에이블리·지그재그 주문이 없습니다. (에이블리는 상품주문번호가 있어야 합니다)')
        if not todo:raise DisplayError(f'선택한 {skipped}건은 이미 취소 완료로 기록돼 있어 다시 누르지 않습니다.')
        return todo,skipped
    @staticmethod
    def cancel_at(send_at):
        """예약 품절 문자 전송 시각 → 주문취소 시각(10분 전). '' → None."""
        if not send_at:return None
        try:
            at=datetime.fromisoformat(str(send_at).replace('Z','+00:00'))
            return (at if at.tzinfo else at.replace(tzinfo=timezone.utc))-CANCEL_LEAD
        except ValueError:return None
    def schedule_cancel(self,targets,at,source,send_at=''):
        entry={'id':secrets.token_urlsafe(9),'at':at.astimezone(timezone.utc).isoformat(timespec='seconds'),'source':source,'sendAt':send_at,
               'targets':[dict(t) for t in targets],'createdAt':datetime.now(timezone.utc).isoformat(timespec='seconds')}
        with self.store.edit() as s:s.setdefault('soldoutCancelSchedule',[]).append(entry)
        return entry
    def unschedule(self,payload):
        sid=str((payload or {}).get('id','')) if isinstance(payload,dict) else ''
        with self.store.edit() as s:
            before=len(s.get('soldoutCancelSchedule',[]));s['soldoutCancelSchedule']=[e for e in s.get('soldoutCancelSchedule',[]) if e.get('id')!=sid]
            if len(s['soldoutCancelSchedule'])==before:raise DisplayError('예약된 주문취소를 찾지 못했습니다.')
        return self.status()
    def notice_cancelled(self,s,t):
        """자동 예약분: 그 주문의 품절 예약 문자가 모두 취소됐으면 주문취소도 하지 않는다."""
        key=t.get('rowKey');send_at=t.get('sendAt')
        if not key or not send_at:return False
        ns=[n for n in s.get('notices',[]) if key in (n.get('itemKeys') or []) and str(n.get('noticeType','')).startswith('soldout') and n.get('scheduledAt')==send_at]
        return bool(ns) and all(n.get('status')=='CANCELLED' for n in ns)
    def run_due(self):
        """Scheduler tick: start the scheduled cancels whose time has come (one job at a time, after other web jobs)."""
        now=datetime.now(timezone.utc)
        with self.lock:
            if self.running() or self.busy() or self.engine.stop.is_set() or getattr(self.engine,'reset_in_progress',False):return False
            with self.store.edit() as s:
                sched=s.get('soldoutCancelSchedule',[]);due=[e for e in sched if (self.cancel_at_entry(e) or now)<=now]
                if not due:return False
                s['soldoutCancelSchedule']=[e for e in sched if e not in due]
                done={self.target_key(x) for x in s.get('soldoutCancelLog',[]) if not x.get('test') and x.get('result') in self.DONE_RESULTS}
                targets=[];seen=set();skipped=[]
                for e in due:
                    for t in e.get('targets') or []:
                        k=self.target_key(t)
                        if k in seen or k in done:continue
                        seen.add(k)
                        if e.get('source')=='notice' and self.notice_cancelled(s,t):
                            skipped.append({**t,'result':'주문취소 안 함','detail':'예약 품절 문자가 취소돼 예약 주문취소도 하지 않았습니다.','at':now.isoformat(timespec='seconds')});continue
                        targets.append(t)
                if skipped:
                    log=s.setdefault('soldoutCancelLog',[]);log.extend(skipped);del log[:-500]
            if not targets:return False
            self._start_cancel_job(targets,'예약 주문취소')
            return True
    @staticmethod
    def cancel_at_entry(e):
        try:return datetime.fromisoformat(str(e.get('at','')).replace('Z','+00:00'))
        except ValueError:return None
    def cancel_only(self,payload):
        keys=(payload or {}).get('keys') if isinstance(payload,dict) else None
        when=(payload or {}).get('when','now') if isinstance(payload,dict) else 'now'
        if when not in ('now','morning'):raise DisplayError('취소 시점을 확인하세요.')
        targets,skipped=self.cancel_only_targets(keys)
        if when=='morning':
            # 2026-10-22 02:13: 오전 9시 예약취소 = 9시 예약 문자 전송 10분 전(08:50)에 실행.
            from domain import morning_send_time
            send_at=morning_send_time(datetime.now(timezone.utc))
            e=self.schedule_cancel(targets,send_at-CANCEL_LEAD,'button',send_at.astimezone(timezone.utc).isoformat(timespec='seconds'))
            return {**self.status(),'scheduled':len(targets),'skipped':skipped,'at':e['at']}
        with self.lock:
            if self.running():raise DisplayError('품절 처리가 진행 중입니다. 끝난 뒤 실행하세요.')
            if self.busy():raise DisplayError('주문 불러오기·동기화·반품체크가 끝난 뒤 실행하세요.')
            self._start_cancel_job(targets,'취소만 진행')
        return {**self.status(),'started':len(targets),'skipped':skipped}
    def _start_cancel_job(self,targets,label):
        """Caller holds self.lock and has checked running()/busy()."""
        with self.lock:
            self.stop.clear();self.job={'id':secrets.token_urlsafe(12),'phase':'running','message':f'{label} {len(targets)}건 · Chrome을 엽니다.'}
            def run():
                cafe=ably=None
                try:
                    cafe,ably,shop_name,note=self._accounts()   # 계정이 없는 판매처는 그 건만 '계정 없음'으로 남고 나머지는 진행
                    results=self._run_cancel_targets(targets,cafe,ably)
                    bad=[r for r in results if str(r.get('result','')).endswith(('실패','확인 필요','보류'))]
                    self.update('error' if bad else 'done',label+' '+('확인 필요: ' if bad else '완료: ')+'; '.join(f'{r.get("result","")} · {r.get("detail","")}' for r in results)[:600])
                except DisplayCancelled as exc:self.update('error',str(exc))
                except Exception as exc:
                    self.update('error',label+' 실패: '+(str(exc) or type(exc).__name__)[:300])
                    try:self.engine.add_job_alert('품절 주문취소 실패',(str(exc) or type(exc).__name__)[:300],'error')
                    except Exception:pass
                finally:
                    for acct in (cafe,ably):
                        try:
                            if acct:acct.clear()
                        except Exception:pass
            self.thread=threading.Thread(target=run,daemon=True);self.thread.start()
    def test_display(self,payload):
        if not isinstance(payload,dict):raise DisplayError('테스트 입력을 확인하세요.')
        product=str(payload.get('product','')).strip();option=str(payload.get('option','')).strip()
        if not product or len(product)>200 or len(option)>100:raise DisplayError('상품명과 옵션(예: 그레이/FREE)을 입력하세요.')
        n=self.enqueue([{'product':product,'option':option,'seller':'','orderId':''}],'test')
        if not n and not self.running():raise DisplayError('같은 상품/옵션이 이미 대기 중입니다.')
        return self.status()
    def cancel(self):
        self.stop.set();return self.status()
    def start_scheduler(self):
        if self.scheduler_thread and self.scheduler_thread.is_alive():return
        def loop():
            while not self.scheduler_stop.wait(5):
                try:self.kick()
                except Exception:pass
                try:self.run_due()   # 2026-10-22: 예약 주문취소
                except Exception:pass
        self.scheduler_thread=threading.Thread(target=loop,daemon=True);self.scheduler_thread.start()
    def shutdown(self):
        self.scheduler_stop.set();self.stop.set()
