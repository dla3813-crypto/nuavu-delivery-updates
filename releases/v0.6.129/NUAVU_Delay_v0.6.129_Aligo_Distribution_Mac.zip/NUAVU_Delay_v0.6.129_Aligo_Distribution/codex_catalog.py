"""배송안내 배포판 · 앱이 관리하는 자료 목록 (2026-10-24 22:05 추가 요청서) — Nuavu Auto 1.31.3 catalog.py 를 이 앱 구조에 맞게 이식.

- 앱이 자료를 가져오거나(입력) 만들 때(결과) 바이트 그대로 회차별 보관본을 남기고 목록에 등록한다.
  확장주문(주문 엑셀) · 현재고 · 진행상황 · 출고장 · 배송지연 안내건(미출고 엑셀) · 회수접수 결과 · 안내문(앱 기록에서 만든 텍스트).
- 같은 파일명으로 덮어쓰는 결과(예: 현재 미출고 상품.xlsx)도 회차마다 보관본이 따로 있어 '지난 회차'가 최신 파일로 바뀌지 않는다.
- 같은 내용(SHA-256)을 다시 가져오면 새 버전을 만들지 않는다 (클로드 폴더·백업 폴더 복사본 중복 방지).
- 컴퓨터 전체를 검색하지 않는다. 앱이 실제로 다룬 파일과, 앱이 연결한 폴더의 기존 파일(시작 때 1회 확인)만 등록.
- 질문 → 자료 선택은 호스트(이 앱)가 한다. 파일명만 보고 수량을 추측하지 않도록 실제 복사본을 대화 작업 폴더에 연결한다.
"""
from __future__ import annotations
import datetime,hashlib,json,os,re,shutil,threading,unicodedata,uuid
from pathlib import Path
from codex_files import atomic_json,digest

KINDS={'notice_export':'배송지연 안내건(미출고 엑셀)','orders':'확장주문(주문 엑셀)','inventory':'현재고','progress':'진행상황',
       'shipment':'출고장','pickup':'회수접수 결과','notice_text':'안내문','order_list':'현재 주문 목록(앱)'}
# 질문에서 종류를 찾는 말 (앞쪽이 우선)
# 배포판(2026-10-25): 미출고 엑셀 자동 저장·현재고 기능이 없어 '미출고·안내건' 질문은 앱의 현재 주문 목록으로 연결
WORDS=[('order_list',r'주문\s*목록|미출고|미배송|안내\s*건|안내\s*대상|발송\s*대상|미출고\s*목록|메시지\s*없는|무발송|문자\s*(?:보내|발송|작성)|알림톡\s*(?:보내|발송)|(?:예정일|출고일)\s*(?:을|를)?\s*(?:변경|수정|바꿔)|출고\s*예상|예상\s*출고|입고\s*예정|출고장.{0,20}(?:변경|수정|바꿔|당겨|미뤄)|입고\s*확정|발송\s*처리|안내\s*(?:보내|처리)|보내\s*줘'),
       ('orders',r'확장\s*주문|주문\s*(?:엑셀|파일|서)|주문\s*내역'),
       ('progress',r'진행\s*상황'),
       ('shipment',r'출고장'),
       ('pickup',r'회수\s*접수|회수\s*결과'),
       ('notice_text',r'안내문|문구|안내\s*문자|알림톡\s*문구')]
KEEP=40          # 종류별 보관 회차
MAX_BYTES=50*1024*1024
KST=datetime.timezone(datetime.timedelta(hours=9))

_CATALOG=None
def install(cat):
    global _CATALOG;_CATALOG=cat;return cat
def current():return _CATALOG
def nfc(v):return unicodedata.normalize('NFC',str(v or ''))
def now():return datetime.datetime.now(KST).isoformat(timespec='seconds')

def record(kind,path,role='output',**meta):
    """앱 작업 코드에서 부르는 훅. 실패해도 업무 흐름은 절대 멈추지 않는다."""
    try:
        if _CATALOG is not None:return _CATALOG.register_file(kind,path,role=role,**meta)
    except Exception:pass
    return None
def record_bytes(kind,name,data,role='input',**meta):
    try:
        if _CATALOG is not None:return _CATALOG.register_bytes(kind,name,data,role=role,**meta)
    except Exception:pass
    return None

def public(item):
    return {k:item.get(k,'') for k in ('id','kind','label','name','createdAt','basis','version','role','status','run','size')}


class ArtifactCatalog:
    def __init__(self,state_dir,notice_text=None,order_list=None):
        self.root=Path(state_dir)/'codex_chat'/'artifacts';self.root.mkdir(parents=True,exist_ok=True)
        try:os.chmod(self.root,0o700)
        except OSError:pass
        self.path=self.root/'catalog.json';self.lock=threading.RLock();self.notice_text=notice_text;self.order_list=order_list
        try:self.data=json.loads(self.path.read_text(encoding='utf-8'))
        except (OSError,ValueError):self.data={'version':1,'items':[]}
        self.data.setdefault('items',[])
        # 보관본이 사라진 항목은 '실패'로 표시 (기록만 있고 파일이 없는 상태를 연결 성공으로 쓰지 않음)
        for it in self.data['items']:
            if it.get('status')=='complete' and not Path(it.get('path','')).is_file():it['status']='missing'

    def save(self):atomic_json(self.path,self.data)
    def items(self,kind=None,status='complete'):
        with self.lock:
            out=[dict(i) for i in self.data['items'] if (kind is None or i['kind']==kind) and (status is None or i.get('status')==status)]
        return sorted(out,key=lambda i:(i.get('createdAt',''),i.get('seq',0)),reverse=True)
    def get(self,key):
        with self.lock:return next((dict(i) for i in self.data['items'] if i['id']==str(key)),None)

    def _run_id(self,kind,stamp):return stamp[:19].replace('-','').replace('T','-').replace(':','')+'-'+kind+'-'+uuid.uuid4().hex[:6]
    def register_bytes(self,kind,name,data,role='input',source=None,basis='',period='',brand='',inputs=None,run=None,status='complete',note=''):
        if kind not in KINDS:raise ValueError('kind')
        if not isinstance(data,(bytes,bytearray)) or len(data)>MAX_BYTES:return None
        name=nfc(Path(str(name)).name) or (KINDS[kind]+'.bin')
        sha=hashlib.sha256(data).hexdigest()
        with self.lock:
            same=next((i for i in self.data['items'] if i['kind']==kind and i['sha256']==sha and i.get('status')=='complete' and Path(i['path']).is_file()),None)
            if same:
                # 같은 내용: 새 회차를 만들지 않고 마지막 확인 시각·원본 위치만 갱신
                same['seenAt']=now()
                if source and not same.get('source'):same['source']=str(source)
                self.save();return dict(same)
            key=uuid.uuid4().hex;folder=self.root/key;folder.mkdir(parents=True)
            target=folder/name;target.write_bytes(data)
            if digest(target)!=sha:
                shutil.rmtree(folder,ignore_errors=True);raise ValueError('copy')
            created=now();version=1+sum(1 for i in self.data['items'] if i['kind']==kind and nfc(i['name'])==name)
            item={'id':key,'run':run or self._run_id(kind,created),'kind':kind,'label':KINDS[kind],'role':role,'name':name,'path':str(target),
                  'source':str(source or ''),'createdAt':created,'seenAt':created,'basis':str(basis or created[:10]),'period':str(period or ''),'brand':str(brand or ''),
                  'status':status,'size':len(data),'sha256':sha,'version':version,'inputs':list(inputs or []),'note':str(note or ''),'seq':len(self.data['items'])}
            self.data['items'].append(item);self._prune(kind);self.save();return dict(item)
    def register_file(self,kind,path,role='output',basis='',**meta):
        p=Path(path)
        if p.is_symlink() or not p.is_file() or p.stat().st_size>MAX_BYTES:return None
        a=p.stat();data=p.read_bytes();b=p.stat()
        if (a.st_size,a.st_mtime_ns)!=(b.st_size,b.st_mtime_ns):return None   # 저장 중인 파일은 등록하지 않음
        if not basis:basis=datetime.datetime.fromtimestamp(b.st_mtime,KST).date().isoformat()
        return self.register_bytes(kind,p.name,data,role=role,source=str(p.resolve()),basis=basis,**meta)
    def _prune(self,kind):
        group=[i for i in self.data['items'] if i['kind']==kind and i.get('status')=='complete']
        group.sort(key=lambda i:i.get('createdAt',''),reverse=True)
        for old in group[KEEP:]:
            shutil.rmtree(Path(old['path']).parent,ignore_errors=True);old['status']='pruned'

    def latest_inputs(self):
        """결과를 만들 때 쓴 입력 자료 연결 정보 (가장 최근 확장주문·현재고·진행상황·출고장)."""
        out=[]
        for k in ('orders','inventory','progress','shipment'):
            g=self.items(k)
            if g:out.append(g[0]['id'])
        return out

    def is_live(self,item):
        """이 보관본이 지금 원본 파일과 같은지 (같을 때만 '원본에 반영' 가능)."""
        src=Path(item.get('source') or '')
        if not item.get('source') or not src.is_file() or src.is_symlink():return False
        newest=next((i for i in self.items(item['kind']) if i.get('source')==item['source']),None)
        if not newest or newest['id']!=item['id']:return False
        try:return digest(src)==item['sha256']
        except OSError:return False

    def make_notice_text(self):
        if not self.notice_text:return None
        text=self.notice_text()
        if not text:return None
        stamp=datetime.datetime.now(KST)
        return self.register_bytes('notice_text','최근 안내문.txt',text.encode('utf-8'),role='output',basis=stamp.date().isoformat(),note='앱 발송 기록에서 만든 텍스트 (연락처 제외)')

    def make_order_list(self):
        if not self.order_list:return None
        text=self.order_list()
        if not text:return None
        stamp=datetime.datetime.now(KST)
        return self.register_bytes('order_list','현재 주문 목록.csv',('\ufeff'+text).encode('utf-8'),role='output',basis=stamp.date().isoformat(),note='앱 화면의 미출고 주문상품 (연락처·고객명 제외, 행키 포함)')

    # ---------- 질문 → 자료 ----------
    def resolve(self,text,history=(),linked=()):
        """반환: requested, selected(항목), choices(모호할 때 후보), missing(이유 문장), reuse(이미 연결된 자료로 충분)."""
        text=nfc(text);kinds=[]
        for kind,pat in WORDS:
            if re.search(pat,text) and kind not in kinds:kinds.append(kind)
        if 'notice_export' in kinds and 'notice_text' in kinds and re.search(r'안내\s*건',text) and not re.search(r'안내문|문구',text):kinds.remove('notice_text')
        follow=bool(re.search(r'그중|그 중|그거|그것|그 파일|이 파일|이어서|방금 그|위 파일|거기서|여기서',text))
        latest=bool(re.search(r'최신|최근|방금|아까|지금|오늘|새로',text))
        previous=bool(re.search(r'지난\s*회차|이전\s*회차|저번|전\s*회차|지난번|그\s*전',text))
        compare=bool(re.search(r'비교|차이|대조|달라진',text))
        action=bool(re.search(r'분석|확인|알려|정리|수량|몇|얼마|합계|찾아|고쳐|수정|다듬|만들어|비교|대조|요약|읽어|봐\s*줘|보여|보내|처리|바꿔|변경|골라|뽑아',text))
        if not kinds and (follow or (action and latest)):
            # "그중 누아브만" 같은 추가 질문: 이미 연결된 자료가 있으면 그대로 사용
            if linked:return {'requested':True,'selected':[],'choices':[],'missing':[],'reuse':True}
            for msg in reversed([m for m in history if m.get('role')=='user'][-20:]):
                prev=nfc(msg.get('text'))
                kinds=[k for k,p in WORDS if re.search(p,prev)]
                if kinds:break
        if not kinds or not (action or latest or previous or follow or compare):
            return {'requested':False,'selected':[],'choices':[],'missing':[],'reuse':False}
        m=re.search(r'(\d{1,2})\s*(?:월|/|\.)\s*(\d{1,2})\s*일?',text);day=None
        if m and 1<=int(m[1])<=12 and 1<=int(m[2])<=31:day=f'-{int(m[1]):02}-{int(m[2]):02}'
        selected=[];choices=[];missing=[]
        if 'order_list' in kinds:
            made=self.make_order_list()
            if made:selected.append(made)
            else:missing.append('현재 주문 목록: 앱 상태를 읽지 못했습니다')
            kinds.remove('order_list')
        if 'notice_text' in kinds:
            made=self.make_notice_text()
            if made:selected.append(made)
            else:missing.append('안내문: 앱에 보낸 안내 기록이 없습니다')
            kinds.remove('notice_text')
        for kind in kinds:
            group=self.items(kind)
            if not group:missing.append(KINDS[kind]+': 앱에 등록된 파일이 없습니다');continue
            if day:
                by_basis=[i for i in group if i.get('basis','').endswith(day)]
                by_created=[i for i in group if i.get('createdAt','')[4:10]==day]
                pool=by_basis or by_created
                if not pool:missing.append(f'{KINDS[kind]}: {day[1:3]}월 {day[4:6]}일 자료가 없습니다');continue
                if len(pool)==1:selected.append(pool[0])
                else:choices.extend(pool[:8])
                continue
            if previous and not latest:
                if len(group)<2:missing.append(KINDS[kind]+': 지난 회차 자료가 없습니다 (보관된 회차 1개)');continue
                selected.append(group[1]);continue
            if compare and len(group)>=2:selected.extend(group[:2]);continue
            # 최신: 같은 순간에 함께 들어온 자료(예: 출고장 여러 날짜)는 업무 기준일이 가장 늦은 것, 그래도 겹치면 선택
            top=[i for i in group if i.get('run')==group[0].get('run')]   # 한 번에 함께 들어온 자료 (예: 출고장 여러 날짜)
            if len(top)>1:
                best=max(i.get('basis','') for i in top);tied=[i for i in top if i.get('basis','')==best]
                if len(tied)==1:selected.append(tied[0])
                else:choices.extend(tied[:8])
            else:selected.append(group[0])
        return {'requested':True,'selected':selected,'choices':choices,'missing':missing,'reuse':False}

    # ---------- 시작 때 1회: 이미 있는 작업 결과를 실제 파일이 있을 때만 이전 ----------
    def migrate_existing(self,engine=None,claude_dir=None):
        done=self.data.setdefault('migrated',{})
        def once(key,fn):
            if done.get(key):return
            try:fn()
            except Exception:pass
            done[key]=now()
        s=None
        try:s=engine.store.read() if engine is not None else None
        except Exception:s=None
        def notice():
            p=((s or {}).get('orderExport') or {}).get('lastPath')
            if p and Path(p).is_file():self.register_file('notice_export',p,role='output',note='이전 저장분 이전')
        def inventory():
            folder=((s or {}).get('inventory') or {}).get('folder')
            if folder and Path(folder).is_dir():
                files=sorted((x for x in Path(folder).iterdir() if x.is_file() and not x.name.startswith(('~$','.')) and nfc(x.name).startswith('현재고조회') and x.suffix.lower() in ('.xls','.xlsx')),key=lambda x:x.stat().st_mtime)
                for x in files[-3:]:self.register_file('inventory',x,role='input',note='이전 파일 이전')
        def supply():
            folder=((s or {}).get('supply') or {}).get('folder')
            if folder and Path(folder).is_dir():
                for x in sorted(Path(folder).iterdir(),key=lambda x:x.name):
                    n=nfc(x.name)
                    if not x.is_file() or n.startswith(('~$','.')) or x.suffix.lower()!='.xlsx':continue
                    if '출고장' in n:self.register_file('shipment',x,role='input',basis=_manifest_day(n),note='이전 파일 이전')
                    elif re.fullmatch(r'진행상황(?:\s*\(\d+\))?\.xlsx',n):self.register_file('progress',x,role='input',note='이전 파일 이전')
        def pickup():
            d=Path(claude_dir) if claude_dir else None
            if d and d.is_dir():
                for x in sorted(d.glob('회수접수_결과_*.xlsx'))[-3:]:self.register_file('pickup',x,role='output',note='이전 파일 이전')
        once('notice_export',notice);once('inventory',inventory);once('supply',supply);once('pickup',pickup)
        with self.lock:self.save()


def _manifest_day(name):
    m=re.search(r'(\d{1,2})\s*월\s*(\d{1,2})\s*일',name) or re.search(r'(?<!\d)(\d{2})(\d{2})(?!\d)',name)
    if not m:return ''
    mo,d=int(m[1]),int(m[2])
    if not (1<=mo<=12 and 1<=d<=31):return ''
    return f'{datetime.datetime.now(KST).year}-{mo:02}-{d:02}'
