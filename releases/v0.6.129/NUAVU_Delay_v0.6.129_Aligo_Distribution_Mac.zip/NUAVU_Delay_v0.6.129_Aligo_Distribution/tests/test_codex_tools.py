"""2026-10-25 요청: 앱 기능을 Codex 도구로 (dynamicTools · item/tool/call). 가짜 Codex 클라이언트로 확인 (실제 발송·주문 변경 없음)."""
import json,sys,tempfile,threading,time,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import codex_catalog
from codex_catalog import ArtifactCatalog
from codex_service import CodexChatService
from codex_view import parts
from codex_tools import AppTools,mask
from test_codex_chat import FakeClient

class FakeStore:
    def __init__(self):self.data={'settings':{'smsTemplates':{'my':'안녕하세요 {상품목록}'},'defaultTemplate':'first'},'aligo':{'templates':{'first':{'name':'배송지연','body':'#{상품명} #{출고예정일}','verified':True}}},
                                 'pickupHistory':[{'invoice':'612345678901','customer':'김민수','result':'접수 완료','attempt':1,'at':'2026-10-24T10:00:00+09:00'}],'orderAutoImport':{'lastDownload':'2026-10-25T09:00:00+09:00','lastFile':'a.xls'}}
    def read(self):return json.loads(json.dumps(self.data))
class FakeEngine:
    def __init__(self):self.store=FakeStore();self.refreshed=0
    def public_state(self):
        return {'supply':{'dispatchWaves':[{'chinaDate':'2026-10-23','koreaStart':'2026-10-28','koreaEnd':'2026-10-29','items':68}]},
                'returns':{'lastChecked':'2026-10-24T22:00:00+09:00','rows':[{'customer':'이영희','invoice':'698765432109','orderId':'A1','product':'니트','label':'회수 접수 완료','logistics':'transit','pickupHistory':[{'attempt':1,'result':'접수 완료'}]}],'exchangeRows':[]}}
    def supply_refresh(self,p=None):self.refreshed+=1;return {'message':'2개 파일 읽음','files':2}
    def save_preferences(self,p):self.store.data['settings']['defaultTemplate']=p['defaultTemplate'];return {}
    def set_auto_ably_push(self,p):self.store.data['settings']['autoAblyPush']=p['autoAblyPush'];return {}
class FakeReturns:
    def __init__(self):self.cfg={'mode':'manual','time':'09:00','watchEnabled':False,'folder':'/x','source':'ably'};self.saved=[]
    def config(self):return dict(self.cfg)
    def save(self,c):self.saved.append(c);self.cfg.update(c);return {}
class FakeBridge:
    def __init__(self):self.r=FakeReturns()
    def _return_controller(self):return self.r

class Base(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=Path(self.tmp.name);self.state=self.base/'state';self.out=self.base/'out';self.out.mkdir()
        self.cat=codex_catalog.install(ArtifactCatalog(self.state));self.engine=FakeEngine()
        self.bridge=FakeBridge();self.tools=AppTools(self.engine,self.bridge,self.cat)
        self.s=CodexChatService(self.state,self.out/'r',roots=[('out','out',self.out)],context=lambda:'요약',version='t',open_url=lambda u:None,open_path=lambda p:None,
                                client_factory=FakeClient,catalog=self.cat,tools=self.tools,
                                validate_action=lambda p:{'keys':[k for k in p.get('keys',[]) if k in ('k1','k2')],'samples':['에이블리 · 니트'],'unmatched':0,'warnings':[]} if p.get('action')!='change_dispatch' else {'chinaDates':p.get('chinaDates') or ['2026-10-23'],'samples':[],'unmatched':0,'warnings':[],'count':68})
    def tearDown(self):self.s.close();codex_catalog.install(None);self.tmp.cleanup()
    def wait(self,cond=None,t=5):
        end=time.monotonic()+t
        while time.monotonic()<end:
            if (cond() if cond else not self.s.op):return
            time.sleep(.01)
        self.fail('timeout')
    def send(self,text='질문'):self.s.send(text);self.wait()
    def tool(self,name,args,rid=1):
        before=len(self.s.client.replies)
        self.s._request({'id':rid,'method':'item/tool/call','params':{'threadId':self.s.chat['thread'],'turnId':'turn-1','callId':'c','tool':name,'arguments':args}})
        self.wait(lambda:len(self.s.client.replies)>before)
        r=self.s.client.replies[-1]['result'];return json.loads(r['contentItems'][0]['text']),r['success']

class ToolTests(Base):
    def test_tools_registered_on_new_thread(self):
        self.send()
        start=next(c['params'] for c in self.s.client.calls if c.get('method')=='thread/start')
        names={t['name'] for t in start['dynamicTools']}
        for n in ('app_overview','list_orders','search_returns','propose_action','import_orders','job_status','notice_templates','dispatch_batches','list_materials','shortage_report','bundle_plan'):self.assertIn(n,names)
        self.assertIn('propose_action',self.s._instructions());self.assertIn('Never say 불러왔다',self.s._instructions())
    def test_python_tools(self):
        self.send()
        r,ok=self.tool('dispatch_batches',{});self.assertTrue(ok);self.assertEqual(r['batches'][0]['items'],68)
        r,ok=self.tool('notice_templates',{});self.assertIn('first',r['defaults']);self.assertEqual(r['alimtalk'][0]['name'],'배송지연')
        r,ok=self.tool('search_returns',{'query':'이영희'});self.assertEqual(r['count'],1);self.assertEqual(r['matches'][0]['customer'],'이○희');self.assertNotIn('phone',json.dumps(r))
        r,ok=self.tool('search_returns',{'query':'이○희'});self.assertEqual(r['count'],1)
        r,ok=self.tool('search_returns',{'query':'김*수'});self.assertEqual(r['matches'][0]['kind'],'회수접수 기록')
        r,ok=self.tool('search_returns',{'query':'612345678901'});self.assertEqual(r['matches'][0]['kind'],'회수접수 기록');self.assertEqual(r['matches'][0]['pickupHistory'][0]['result'],'접수 완료')
        r,ok=self.tool('refresh_supply',{});self.assertTrue(ok);self.assertEqual(self.engine.refreshed,1)
        r,ok=self.tool('job_status',{});self.assertEqual(r['lastOrderDownload'],'2026-10-25T09:00:00+09:00')
        r,ok=self.tool('nope',{});self.assertFalse(ok)
        html=parts(self.s.status())['messages'];self.assertIn('앱 도구 · 출고장별 출고 예상일 확인',html);self.assertIn('cx-toolline fail',html)
    def test_ui_tool_round_trip_through_screen(self):
        self.send();out={}
        def run():out['r']=self.tools.call(self.s,'list_orders',{'status':'white_dated'})
        t=threading.Thread(target=run);t.start()
        self.wait(lambda:self.s.brief()['uiCalls'])
        call=self.s.brief()['uiCalls'][0];self.assertEqual(call['tool'],'list_orders');self.assertEqual(call['args']['status'],'white_dated')
        self.s.handle('cxToolResult',{'id':call['id'],'result':{'ok':True,'count':2,'rows':[{'key':'k1'},{'key':'k2'}]}})
        t.join(3);self.assertEqual(out['r']['count'],2);self.assertEqual(self.s.brief()['uiCalls'],[])
    def test_ui_tool_times_out_cleanly(self):
        self.send();r=self.s.ui_call('app_overview',{},timeout=.2)
        self.assertFalse(r['ok']);self.assertIn('앱 화면',r['error']);self.assertEqual(self.s.brief()['uiCalls'],[])
    def test_propose_compose_with_recommended_wording_is_card_only(self):
        self.send()
        r,ok=self.tool('propose_action',{'action':'compose_notice','rowKeys':['k1','k2','zz'],'message':'안녕하세요 고객님\n입고가 늦어져 10/28 출고 예정입니다.','title':'배송 안내','reason':'일정 확정'})
        self.assertTrue(ok);self.assertEqual(r['items'],2);self.assertIn('아직 보내거나 바꾸지 않았습니다',r['message'])
        card=[m for m in self.s.status()['messages'] if m['role']=='proposal'][-1]
        self.assertEqual(card['template'],'manual');self.assertIn('10/28',card['message'])
        html=parts(self.s.status())['messages'];self.assertIn('추천 문구',html);self.assertIn('입고가 늦어져',html)
        val=json.loads(html.split('data-cx-local="proposal" data-value="')[1].split('"')[0].replace('&quot;','"'))
        self.assertEqual(val['template'],'manual');self.assertTrue(val['proposal'])
        r,ok=self.tool('propose_action',{'action':'compose_notice','rowKeys':[],'template':'first'});self.assertFalse(ok)
        r,ok=self.tool('propose_action',{'action':'change_dispatch','chinaDates':['2026-10-23'],'dispatchStart':'2026-10-27'});self.assertTrue(ok);self.assertEqual(r['items'],68)
    def test_action_results_flow_back_to_chat_and_tool(self):
        self.send()
        self.s.handle('cxActionResult',{'kind':'문자·알림톡 요청','message':'문자·알림톡 요청 · 2건 요청했습니다','count':2,'proposal':'p1'})
        self.assertIn('앱에서 처리됨 · 문자·알림톡 요청',str(self.s.status()['messages']))
        r,ok=self.tool('recent_action_results',{});self.assertEqual(r['results'][0]['count'],2)
    def test_old_thread_restarts_with_tools_and_history_summary(self):
        self.send('첫 질문');self.s.client.event('turn/completed',{'threadId':'own-thread','turn':{'status':'completed'}});self.wait()
        self.s.chat['messages'].append({'id':'a1','role':'assistant','text':'첫 답변','at':'x'})
        self.s.tooled.clear()   # 앱 재시작과 같음: 이 실행에서 도구 없이 이어 붙이지 않는다
        self.s.loaded=None;self.send('두 번째 질문')
        starts=[c for c in self.s.client.calls if c.get('method')=='thread/start'];self.assertEqual(len(starts),2)
        turn=[c for c in self.s.client.calls if c.get('method')=='turn/start'][-1]['params']['input'][0]['text']
        self.assertIn('이전 대화 요약',turn);self.assertIn('첫 답변',turn);self.assertTrue(turn.endswith('두 번째 질문'))
        self.assertEqual(self.s.chat['previousThreads'],['own-thread'])
    def test_bold_with_masked_name_renders(self):
        from codex_view import markdown
        self.assertIn('<strong>에이블리 · 오*윤 · 주문</strong>',markdown('**에이블리 · 오*윤 · 주문**'))
        self.assertIn('<strong>0건</strong>이에요',markdown('주문은 **0건**이에요'))
    def test_report_tools_run_on_screen(self):
        from codex_tools import UI_TOOLS
        self.assertTrue({'shortage_report','bundle_plan'}<=UI_TOOLS)
        js=(ROOT/'web'/'codex_ui.js').read_text(encoding='utf-8')
        for w in ('shortage_report(a)','bundle_plan(a)','incomingParts(r)','weekRange('):self.assertIn(w,js)
        self.assertIn('shortage_report',self.s._instructions());self.assertIn('bundle_plan',self.s._instructions())
    def test_quote_box_and_card_message_without_quote_marks(self):
        from codex_view import markdown
        html=markdown('추천 문구\n\n> 안녕하세요 고객님\n>\n> 감사합니다')
        self.assertIn('<blockquote class="cx-quote"><p>안녕하세요 고객님</p><p>감사합니다</p></blockquote>',html)
        self.send();r,ok=self.tool('propose_action',{'action':'compose_notice','rowKeys':['k1'],'message':'> 안녕하세요 고객님\n> 감사합니다'})
        card=[m for m in self.s.status()['messages'] if m['role']=='proposal'][-1];self.assertEqual(card['message'],'안녕하세요 고객님\n감사합니다')
        self.assertIn('one card per distinct message',self.s._instructions())
    def test_settings_card_changes_only_after_owner_applies(self):
        self.send()
        r,ok=self.tool('get_settings',{});keys={x['key']:x for x in r['settings']}
        self.assertEqual(keys['return_check_time']['current'],'09:00');self.assertIn('default_template',keys);self.assertNotIn('sender',keys)
        r,ok=self.tool('propose_action',{'action':'change_settings','settings':{'return_check_time':'18:30','default_template':'일정 재변경','auto_ably_push':'끄기','smsPassword':'x'}})
        self.assertTrue(ok);self.assertEqual(r['items'],3)
        self.assertEqual(self.bridge.r.saved,[]);self.assertEqual(self.engine.store.data['settings']['defaultTemplate'],'first')   # 카드만
        card=[m for m in self.s.status()['messages'] if m['role']=='proposal'][-1];self.assertEqual(card['action'],'change_settings')
        self.assertTrue(any('바꿀 수 없는' in w for w in card['warnings']))
        html=parts(self.s.status())['messages'];self.assertIn('이대로 적용',html);self.assertIn('18:30',html);self.assertIn('일정 재변경 안내',html);self.assertIn('지금 09:00',html)
        self.s.handle('cxApplySettings',card['id'])
        self.assertEqual(self.bridge.r.saved[-1]['time'],'18:30');self.assertEqual(self.bridge.r.saved[-1]['mode'],'daily')
        self.assertEqual(self.engine.store.data['settings']['defaultTemplate'],'change');self.assertIs(self.engine.store.data['settings']['autoAblyPush'],False)
        self.assertIn('앱에서 처리됨 · 설정 변경',str(self.s.status()['messages']))
        with self.assertRaises(Exception):self.s.handle('cxApplySettings',card['id'])   # 한 번만
        self.assertIn('적용함',parts(self.s.status())['messages'])
        r,ok=self.tool('propose_action',{'action':'change_settings','settings':{'return_check_time':'25:00'}});self.assertFalse(ok)
        self.assertIn('change_settings',self.s._instructions());self.assertIn('ㄱㄱ',self.s._instructions())
    def test_mask(self):
        self.assertEqual(mask('홍길동'),'홍○동');self.assertEqual(mask('김수'),'김○');self.assertEqual(mask('남궁민수'),'남○○수')

if __name__=='__main__':unittest.main()
