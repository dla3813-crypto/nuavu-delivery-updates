"""2026-10-20 (공통) 품절 안내 문자 → 자사몰(카페24)·에이블리 품절 옵션 OFF: 이름 정리, 큐/실행, commit 훅."""
import unittest,tempfile,threading,time
from pathlib import Path
from types import SimpleNamespace
from soldout_display import (search_names,split_option,is_one_color,norm,norm_size,items_from_notice,SoldoutDisplayController)
from domain import SOLDOUT_CARD
try:from test_v056 import Base
except ImportError:from helpers import Base

class Parsing(unittest.TestCase):
    def test_search_names_strip_location_then_tags(self):
        self.assertEqual(search_names('(SC-2)[2color]사이드 집업 코튼 후드 티셔츠'),['(SC-2)[2color]사이드 집업 코튼 후드 티셔츠','[2color]사이드 집업 코튼 후드 티셔츠','사이드 집업 코튼 후드 티셔츠'])
        self.assertEqual(search_names('[7color]베이직 라운드넥 무지 슬림핏 반팔 티셔츠'),['[7color]베이직 라운드넥 무지 슬림핏 반팔 티셔츠','베이직 라운드넥 무지 슬림핏 반팔 티셔츠'])
        self.assertEqual(search_names('도트 프릴 경량 웰론 패딩'),['도트 프릴 경량 웰론 패딩'])
        self.assertEqual(search_names('(NA-6)[5color,3size,기획특가]웰론 후드 경량 패딩')[1],'[5color,3size,기획특가]웰론 후드 경량 패딩')
    def test_split_option_forms(self):
        self.assertEqual(split_option('[그레이-FREE]'),('그레이','FREE'));self.assertEqual(split_option('그레이 / FREE'),('그레이','FREE'))
        self.assertEqual(split_option('블랙-6XL(66)'),('블랙','6XL(66)'));self.assertEqual(split_option('원컬러/FREE'),('원컬러','FREE'))
    def test_one_color_and_norm(self):
        self.assertTrue(is_one_color('원컬러'));self.assertFalse(is_one_color('블랙'))
        self.assertEqual(norm('블랙（모델착용）'),norm('블랙'));self.assertEqual(norm('화이트(모델착용)'),'화이트');self.assertEqual(norm_size('6XL（66）'),norm_size('6XL(66)'))
    def test_items_from_notice_dedup(self):
        n={'seller':'누아브 에이블리','orderId':'1','products':[{'product':'A','option':'블랙/FREE'},{'product':'A','option':'블랙/FREE'},{'product':'B','option':'원컬러/FREE'}]}
        items=items_from_notice(n);self.assertEqual([(i['product'],i['option']) for i in items],[('A','블랙/FREE'),('B','원컬러/FREE')])

class ControllerTests(unittest.TestCase):
    def setUp(self):
        from domain import Store
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(Path(self.tmp.name)/'db');self.alerts=[]
        self.engine=SimpleNamespace(store=self.store,stop=threading.Event(),add_job_alert=lambda t,m,level='info':self.alerts.append((t,level)))
    def tearDown(self):self.store.close();self.tmp.cleanup()
    def ctrl(self,runner,busy=False):
        c=SoldoutDisplayController(self.engine,runner=runner,busy=lambda:busy);self.addCleanup(c.shutdown);return c
    def wait(self,c):
        for _ in range(100):
            if not c.running():return
            time.sleep(.03)
    def test_enqueue_runs_and_logs(self):
        calls=[]
        def runner(ctrl,batch,cafe,ably,shop):
            calls.append([(b['product'],b['option']) for b in batch])
            return [{**b,'cafe24':'자사몰 처리 완료','cafe24Detail':'P0000CWO · 그레이/FREE 진열안함','ably':'에이블리 처리 완료','ablyDetail':'68835960 · 그레이/FREE 진열 OFF'} for b in batch]
        c=self.ctrl(runner)
        with_accounts=lambda:(None,{'username':'u','password':'p'},'테스트상점','')
        c._accounts=with_accounts
        self.assertEqual(c.enqueue([{'product':'A','option':'그레이/FREE'}],'notice'),1)
        self.wait(c);s=c.status()
        self.assertEqual(calls,[[('A','그레이/FREE')]]);self.assertEqual(s['phase'],'done');self.assertEqual(len(s['log']),1);self.assertEqual(self.alerts,[('품절 옵션 처리 완료','info')])
        self.assertEqual(self.store.read()['soldoutDisplayQueue'],[])
    def test_failure_marks_alert_and_busy_defers(self):
        def runner(ctrl,batch,cafe,ably,shop):return [{**b,'cafe24':'자사몰 검색불가','cafe24Detail':'x','ably':'에이블리 처리 완료','ablyDetail':''} for b in batch]
        c=self.ctrl(runner,busy=True);c._accounts=lambda:(None,{'username':'u','password':'p'},'s','')
        c.enqueue([{'product':'B','option':'원컬러/FREE'}]);self.assertFalse(c.running());self.assertEqual(c.status()['queued'],1)
        self.assertEqual(self.store.read()['soldoutDisplayQueue'][0]['product'],'B')   # survives restart
        c.busy=lambda:False;self.assertTrue(c.kick());self.wait(c)
        self.assertEqual(c.status()['phase'],'error');self.assertEqual(self.alerts[-1],('품절 옵션 처리 확인 필요','error'))
    def test_runner_exception_requeues(self):
        def runner(ctrl,batch,cafe,ably,shop):raise RuntimeError('chrome down')
        c=self.ctrl(runner);c._accounts=lambda:(None,{'username':'u','password':'p'},'s','')
        c.enqueue([{'product':'C','option':'블랙/FREE'}]);self.wait(c)
        self.assertEqual(c.status()['queued'],1);self.assertIn('chrome down',c.status()['message'])
    def test_no_ably_account_records_failure(self):
        c=self.ctrl(lambda *a:self.fail('runner must not run'));c._accounts=lambda:(None,None,'s','에이블리 계정 없음')
        c.enqueue([{'product':'D','option':'블랙/FREE'}]);self.wait(c)
        self.assertEqual(c.status()['log'][0]['ably'],'에이블리 실패');self.assertIn('에이블리 계정 없음',c.status()['log'][0]['ablyDetail'])

class CommitHook(Base):
    def test_soldout_commit_calls_hook_with_items(self):
        got=[];self.engine.soldout_display_hook=lambda items:got.append(items)
        self.clock(10);self.queue(noticeType='soldout_card',template=SOLDOUT_CARD,dueDate='')
        self.assertEqual(len(got),1);items=got[0];self.assertTrue(items)
        rows=self.store.read()['rows'];self.assertEqual(sorted(i['product'] for i in items),sorted({r['product'] for r in rows[:2]}))
        self.assertTrue(all(i['option']==next(r['option'] for r in rows if r['product']==i['product']) for i in items))
    def test_scheduled_soldout_also_calls_hook(self):
        got=[];self.engine.soldout_display_hook=lambda items:got.append(items)
        self.clock(20);n=self.queue(sendMode='MORNING',noticeType='soldout_card',template=SOLDOUT_CARD,dueDate='')
        self.assertEqual(n['status'],'SCHEDULED');self.assertEqual(len(got),1)
    def test_delay_message_does_not_call_hook(self):
        got=[];self.engine.soldout_display_hook=lambda items:got.append(items)
        self.clock(10);self.queue(dueDate='2026-10-22');self.assertEqual(got,[])

if __name__=='__main__':unittest.main()

class PendingSoldoutBucket(Base):
    """06:19 요청: 예약/대기 중인 품절 안내도 품절 안내 완료(대기 포함)로 센다; 실패·취소되면 되돌아간다."""
    def test_scheduled_soldout_counts_as_notified(self):
        self.clock(20);n=self.queue(sendMode='MORNING',noticeType='soldout_card',template=SOLDOUT_CARD,dueDate='')
        self.assertEqual(n['status'],'SCHEDULED');r=self.row()
        self.assertTrue(r['soldoutNotified']);self.assertTrue(r['soldoutPending']);self.assertEqual(r['noticeBucket'],'soldout');self.assertEqual(r['bucket'],'scheduled');self.assertEqual(r['color'],'charcoal')
        self.engine.queue_control({'action':'cancel_one','id':n['id']})
        r=self.row();self.assertFalse(r['soldoutNotified']);self.assertFalse(r['soldoutPending']);self.assertNotEqual(r['noticeBucket'],'soldout')
    def test_delivered_soldout_not_pending(self):
        self.clock(10);n=self.send(noticeType='soldout_card',template=SOLDOUT_CARD,dueDate='');self.at_age(n,0,20);self.engine.poll()
        r=self.row();self.assertTrue(r['soldoutNotified']);self.assertFalse(r['soldoutPending'])
    def test_failed_soldout_drops_back(self):
        self.clock(10);self.queue(noticeType='soldout_card',template=SOLDOUT_CARD,dueDate='');self.assertTrue(self.row()['soldoutNotified'])
        self.fake.result='실패';self.assertTrue(self.engine.send_one());n=self.last();self.at_age(n,12);self.engine.poll()
        self.assertEqual(self.last()['status'],'FAILED');self.assertFalse(self.row()['soldoutNotified'])

class CancelIntegration(unittest.TestCase):
    """2026-10-20 06:05: 품절 안내 → 같은 배치에서 주문 취소 접수 (자사몰 품절 취소 · 에이블리 주문취소 접수 처리)."""
    def test_split_and_targets(self):
        from soldout_cancel import split_cafe_item,cancel_targets
        self.assertEqual(split_cafe_item('20261018-0000029_1456'),('20261018-0000029','1456'))
        self.assertEqual(split_cafe_item('20261018-0000043-01_1458'),('20261018-0000043','1458'))
        self.assertEqual(split_cafe_item('','20261018-0000043-01'),('20261018-0000043',''))
        items=[{'seller':'누아브 에이블리','orderId':'A1','orderItemId':'663715463','product':'P','option':'블랙/FREE'},
               {'seller':'누아브 에이블리','orderId':'A1','orderItemId':'663715463','product':'P','option':'블랙/FREE'},
               {'seller':'누아브 에이블리','orderId':'A2','orderItemId':'','product':'P','option':'블랙/FREE'},
               {'seller':'누아브 자사몰','orderId':'20261018-0000029_1456','orderItemId':'','product':'Q','option':'원컬러/FREE'},
               {'seller':'누아브 지그재그','orderId':'Z1','orderItemId':'1','product':'R','option':'x'}]
        t=cancel_targets(items)
        self.assertEqual([(x['platform'],x.get('sno',''),x.get('orderId',''),x.get('omNo','')) for x in t],[('ably','663715463','A1',''),('cafe24','','20261018-0000029','1456')])
    def test_controller_cancels_after_display(self):
        from domain import Store
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup);store=Store(Path(tmp.name)/'db');self.addCleanup(store.close);alerts=[]
        engine=SimpleNamespace(store=store,stop=threading.Event(),add_job_alert=lambda t,m,level='info':alerts.append((t,level)))
        seen={}
        def runner(ctrl,batch,cafe,ably,shop):
            seen['batch']=[(b['product'],b['option'],len(b.get('orders',[]))) for b in batch]
            return [{**b,'cafe24':'','cafe24Detail':'','ably':'에이블리 처리 완료','ablyDetail':''} for b in batch]
        def cancel_runner(ctrl,targets,cafe,ably):
            seen['targets']=targets;return [{**t,'result':'에이블리 취소 완료' if t['platform']=='ably' else '자사몰 취소 완료','detail':'ok'} for t in targets]
        c=SoldoutDisplayController(engine,runner=runner,busy=lambda:False);self.addCleanup(c.shutdown);c.cancel_runner=cancel_runner
        c._accounts=lambda:(None,{'username':'u','password':'p'},'s','')
        n=c.enqueue([{'product':'P','option':'블랙/FREE','seller':'누아브 에이블리','orderId':'A1','orderItemIds':['663715463']},
                     {'product':'P','option':'블랙/FREE','seller':'누아브 에이블리','orderId':'A2','orderItemIds':['663905616','665478336']},
                     {'product':'Q','option':'원컬러/FREE','seller':'누아브 자사몰','orderId':'20261018-0000029_1456','orderItemIds':[]}],'notice')
        self.assertEqual(n,2)
        for _ in range(100):
            if not c.running():break
            time.sleep(.03)
        self.assertEqual(seen['batch'],[('P','블랙/FREE',2),('Q','원컬러/FREE',1)])
        self.assertEqual([(t['platform'],t.get('sno') or t.get('orderId')) for t in seen['targets']],[('ably','663715463'),('ably','663905616'),('ably','665478336'),('cafe24','20261018-0000029')])
        s=c.status();self.assertEqual(s['phase'],'done');self.assertIn('주문취소 4건',s['message']);self.assertEqual(len(s['cancelLog']),4)
        self.assertNotIn('orders',s['log'][0]);self.assertEqual([a[0] for a in alerts],['품절 옵션 처리 완료','품절 주문취소 접수 완료'])
        self.assertEqual(store.read()['soldoutCancelLog'][0]['sno'],'663715463')
    def test_cancel_still_has_ably_account_after_display_clears_its_copy(self):
        """2026-10-22 01:44: '에이블리 취소 실패 (에이블리 계정 없음)' — the display step cleared the shared account dict."""
        from domain import Store
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup);store=Store(Path(tmp.name)/'db');self.addCleanup(store.close)
        engine=SimpleNamespace(store=store,stop=threading.Event(),add_job_alert=lambda *a,**k:None)
        seen={};acct={'username':'u','password':'p'}
        def runner(ctrl,batch,cafe,ably,shop):
            out=[{**b,'cafe24':'','cafe24Detail':'','ably':'에이블리 처리 완료','ablyDetail':''} for b in batch];ably.clear();return out
        def cancel_runner(ctrl,targets,cafe,ably):
            seen['ably']=dict(ably) if ably else None;return [{**t,'result':'에이블리 취소 완료','detail':''} for t in targets]
        c=SoldoutDisplayController(engine,runner=runner,busy=lambda:False);self.addCleanup(c.shutdown);c.cancel_runner=cancel_runner
        c._accounts=lambda:(None,acct,'s','')
        c.enqueue([{'product':'P','option':'블랙/FREE','seller':'누아브 에이블리','orderId':'A1','orderItemIds':['666332484']}],'notice')
        for _ in range(100):
            if not c.running():break
            time.sleep(.03)
        self.assertEqual(seen['ably'],{'username':'u','password':'p'})
        self.assertEqual(acct,{})   # cleared once both steps are done

class CommitHookOrders(Base):
    def test_hook_items_carry_order_ids(self):
        got=[];self.engine.soldout_display_hook=lambda items:got.append(items)
        self.clock(10);self.queue(noticeType='soldout_card',template=SOLDOUT_CARD,dueDate='')
        items=got[0];rows=self.store.read()['rows'][:2]
        self.assertEqual(sorted((i['seller'],i['orderId'],i['product'],tuple(i['orderItemIds'])) for i in items),sorted((r['seller'],r['orderId'],r['product'],()) for r in rows))

class AblySelectorRegression(unittest.TestCase):
    """06:47 보고: #keyword_type 의 조상 ant-select 를 잡을 때 .ant-select-selection-search 를 잡으면 안 된다 (xpath 정확 일치)."""
    def test_xpath_exact_class_match(self):
        import inspect,soldout_display
        src=inspect.getsource(soldout_display.AblyDisplayFlow.search)
        self.assertIn('concat(" ",normalize-space(@class)," ")," ant-select ")',src)
        self.assertNotIn('contains(@class,"ant-select")]',src)
        self.assertIn("my.a-bly.com/goods/v2/list",soldout_display.ABLY_LIST);self.assertIn("my.a-bly.com/goods/v2/edit/{no}",soldout_display.ABLY_EDIT)

class TestButtons(unittest.TestCase):
    """07:07 요청: 취소 테스트 · 품절 옵션 처리 테스트 버튼 (실제 처리, 이력에 [테스트] 표시)."""
    def ctrl(self):
        from domain import Store
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup);store=Store(Path(tmp.name)/'db');self.addCleanup(store.close);self.alerts=[]
        engine=SimpleNamespace(store=store,stop=threading.Event(),add_job_alert=lambda t,m,level='info':self.alerts.append((t,m,level)))
        c=SoldoutDisplayController(engine,runner=lambda ctrl,batch,cafe,ably,shop:[{**b,'cafe24':'','cafe24Detail':'','ably':'에이블리 실패','ablyDetail':'수정 화면 · 스위치 없음'} for b in batch],busy=lambda:False)
        self.addCleanup(c.shutdown);c._accounts=lambda:(None,{'username':'u','password':'p'},'s','');return c,store
    def wait(self,c):
        for _ in range(100):
            if not c.running():return
            time.sleep(.03)
    def test_cancel_button_runs_one_target_and_marks_test(self):
        from soldout_display import DisplayError
        c,store=self.ctrl();seen=[]
        c.cancel_runner=lambda ctrl,targets,cafe,ably:(seen.extend(targets) or [{**t,'result':'에이블리 취소 실패','detail':'주문취소 접수 처리 버튼 · 없음'} for t in targets])
        with self.assertRaises(DisplayError):c.test_cancel({'platform':'ably','id':'abc'})
        with self.assertRaises(DisplayError):c.test_cancel({'platform':'cafe24','id':''})
        c.test_cancel({'platform':'ably','id':'665538753'});self.wait(c)
        self.assertEqual([(t['platform'],t['sno']) for t in seen],[('ably','665538753')])
        s=c.status();self.assertEqual(s['phase'],'error');self.assertIn('취소 테스트 실패',s['message']);self.assertIn('주문취소 접수 처리 버튼',s['message'])
        self.assertTrue(s['cancelLog'][0]['test']);self.assertIn('(주문취소 접수 처리 버튼 · 없음)',self.alerts[-1][1])   # alert carries the 상세
        c.test_cancel({'platform':'cafe24','id':'20261018-0000043_1458'});self.wait(c)
        self.assertEqual((seen[-1]['platform'],seen[-1]['orderId'],seen[-1]['omNo']),('cafe24','20261018-0000043','1458'))
    def test_display_button_enqueues_and_alert_has_detail(self):
        c,store=self.ctrl()
        c.test_display({'product':'(B-13)Y2K 플라워 빈티지 프린팅 후드 집업','option':'원컬러/FREE'});self.wait(c)
        self.assertEqual(c.status()['log'][0]['source'],'test');self.assertIn('에이블리 실패 (수정 화면 · 스위치 없음)',self.alerts[-1][1])

class Cafe24ConfirmDialogs(unittest.TestCase):
    """07:32 보고: 자사몰 취소접수의 confirm() 창을 기본 처리(취소)로 닫아 접수가 안 됐다 → 취소 단계에서는 확인."""
    def test_confirm_ok_by_step(self):
        from soldout_cancel import Cafe24CancelFlow
        from soldout_display import Cafe24Flow
        f=Cafe24CancelFlow.__new__(Cafe24CancelFlow);f.step='자사몰 취소접수 확인'
        self.assertTrue(f.confirm_ok('취소접수 하시겠습니까?'));self.assertFalse(f.confirm_ok('정말 삭제하시겠습니까?'))
        f.step='자사몰 신용카드 전체취소';self.assertTrue(f.confirm_ok('신용카드 취소를 진행하시겠습니까?'))
        f.step='자사몰 주문상세 X';self.assertFalse(f.confirm_ok('취소접수 하시겠습니까?'));self.assertTrue(f.confirm_ok('상품을 수정하시겠습니까?'))
        g=Cafe24Flow.__new__(Cafe24Flow);g.step='';self.assertTrue(g.confirm_ok('수정'));self.assertFalse(g.confirm_ok('취소접수'))
        # 2026-10-26 21:09: 저장 단계(saving)에서는 어떤 확인창이든 수락 — 기각하면 카페24 저장이 취소된다
        g.saving=True;self.assertTrue(g.confirm_ok('옵션 진열 상태를 변경하시겠습니까?'));g.saving=False;self.assertFalse(g.confirm_ok('옵션 진열 상태를 변경하시겠습니까?'))
        from pathlib import Path as _P
        src=(_P(__file__).resolve().parents[1]/'soldout_display.py').read_text(encoding='utf-8');self.assertIn('2회 시도',src);self.assertIn('def save_and_verify',src);self.assertIn('반영 확인에 잠시 걸림',src);self.assertIn('품절처리_실패',src)

class Cafe24CardStep(unittest.TestCase):
    """07:38 요청: 취소접수 뒤 취소(N건) 탭에서 품목 확인 → 신용카드 전체취소(주문 전체 취소)/부분취소. 07:39: 이미 취소된 주문은 접수 없이 탭 확인부터."""
    def flow(self):
        from soldout_cancel import Cafe24CancelFlow
        f=Cafe24CancelFlow.__new__(Cafe24CancelFlow);f.step='';f.dialogs=[];f.host='x';f.calls=[]
        return f
    def test_already_cancelled_goes_to_tab_check_then_card(self):
        f=self.flow();import soldout_cancel as m
        info={'pay':'신용카드','items':[{'om':'1458','text':'20261018-0000043-01 D-… (C20261020-0000222) Y2K 후드 집업','cancelled':True}],'tabs':['주문내역(0건)','취소(1건)','환불(1건)']}
        f.detail=lambda oid:info
        f.cancel_tab_row=lambda item_no:('취소(1건)','20261018-0000043-01 … 취소처리중 [환불전] 상세 신용카드 환불 (신용카드 취소 전)')
        f.card_cancel=lambda oid,item_no,all_cancelled,label:(f.calls.append((oid,item_no,all_cancelled)) or {'result':'자사몰 취소 완료','detail':label+' · 신용카드 전체취소 완료'})
        r=f.cancel('20261018-0000043','1458','')
        self.assertEqual(f.calls,[('20261018-0000043','20261018-0000043-01',True)]);self.assertEqual(r['result'],'자사몰 취소 완료');self.assertIn('이미 취소접수된 주문',r['detail']);self.assertIn('취소(1건) 확인',r['detail'])
        # card already refunded → nothing to press
        f.calls.clear();f.cancel_tab_row=lambda item_no:('취소(1건)','20261018-0000043-01 … 취소처리중 [환불전] 상세 신용카드 환불 (신용카드 취소완료)')   # 07:47 실측 문구
        r=f.cancel('20261018-0000043','1458','');self.assertEqual(r['result'],'자사몰 이미 취소됨');self.assertEqual(f.calls,[])
        # item missing from the 취소 tab → 확인 필요 (여러 번 취소 대비)
        f.cancel_tab_row=lambda item_no:('취소(1건)','')
        r=f.cancel('20261018-0000043','1458','');self.assertEqual(r['result'],'자사몰 취소 확인 필요');self.assertIn('행이 없습니다',r['detail'])
    def test_partial_when_other_items_remain(self):
        f=self.flow()
        info={'pay':'신용카드','items':[{'om':'1','text':'20261018-0000050-01 (C20261020-0000230) A','cancelled':True},{'om':'2','text':'20261018-0000050-02 B','cancelled':False}],'tabs':['취소(1건)']}
        f.detail=lambda oid:info;f.cancel_tab_row=lambda item_no:('취소(1건)','20261018-0000050-01 … [환불전] (신용카드 취소 전)')
        f.card_cancel=lambda oid,item_no,all_cancelled,label:(f.calls.append(all_cancelled) or {'result':'자사몰 취소 완료','detail':''})
        f.cancel('20261018-0000050','1','');self.assertEqual(f.calls,[False])   # 부분취소
    def test_bank_order_stops_after_tab_check(self):
        f=self.flow()
        info={'pay':'무통장입금','items':[{'om':'1456','text':'20261018-0000029-01 (C20261020-0000221) A','cancelled':True}],'tabs':['취소(1건)']}
        f.detail=lambda oid:info;f.cancel_tab_row=lambda item_no:('취소(1건)','20261018-0000029-01 … 취소완료')
        f.card_cancel=lambda *a:self.fail('card step must not run for 무통장')
        self.assertEqual(f.cancel('20261018-0000029','1456','')['result'],'자사몰 취소 완료')
    def test_card_done_wording(self):
        from soldout_cancel import card_done
        self.assertFalse(card_done('… 취소처리중 [환불전] 상세 신용카드 환불 (신용카드 취소 전)'))
        self.assertTrue(card_done('… 취소처리중 [환불전] 상세 신용카드 환불 (신용카드 취소완료)'))
        self.assertFalse(card_done(''))



class CancelOnly(unittest.TestCase):
    """2026-10-22 품절칸 '취소만 진행': 선택 주문만 취소 접수 · 미진열 없음 · 이미 취소 완료는 건너뜀."""
    def setUp(self):
        from domain import Store
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(Path(self.tmp.name)/'db')
        self.engine=SimpleNamespace(store=self.store,stop=threading.Event(),add_job_alert=lambda *a,**k:None)
        with self.store.edit() as s:
            s['rows']=[{'key':'k1','seller':'누아브 에이블리','orderId':'1792581481372','orderItems':[{'id':'666332484'}],'product':'P','option':'블랙/FREE'},
                       {'key':'k2','seller':'누아브 자사몰','orderId':'20261018-0000029','orderItemId':'20261018-0000029_1456','product':'Q','option':'원컬러/FREE'},
                       {'key':'k3','seller':'누아브 지그재그','orderId':'Z1','product':'R','option':''},
                       {'key':'k4','seller':'누아브 에이블리','orderId':'A9','orderItems':[{'id':'111222333'}],'product':'S','option':''}]
            s['soldoutCancelLog']=[{'platform':'ably','sno':'111222333','result':'에이블리 취소 완료'},{'platform':'ably','sno':'666332484','result':'에이블리 취소 실패','detail':'에이블리 계정 없음'}]
    def tearDown(self):self.store.close();self.tmp.cleanup()
    def ctrl(self):
        self.calls=[];self.displayed=[]
        c=SoldoutDisplayController(self.engine,runner=lambda *a:self.displayed.append(a) or [],busy=lambda:False);self.addCleanup(c.shutdown)
        self.acct={'username':'u','password':'p'}
        c._accounts=lambda:({'username':'c','password':'d'},self.acct,'s','')
        def cancel_runner(ctrl,targets,cafe,ably):
            self.calls.append((targets,dict(cafe or {}),dict(ably or {})));return [{**t,'result':('에이블리' if t['platform']=='ably' else '자사몰')+' 취소 완료','detail':''} for t in targets]
        c.cancel_runner=cancel_runner;return c
    def wait(self,c):
        for _ in range(100):
            if not c.running():return
            time.sleep(.03)
    def test_selected_rows_only_cancel_without_display(self):
        c=self.ctrl();r=c.cancel_only({'keys':['k1','k2','k3']});self.wait(c)
        self.assertEqual(r['started'],2);self.assertEqual(self.displayed,[])
        targets=self.calls[0][0]
        self.assertEqual({(t['platform'],t.get('sno') or t['orderId']) for t in targets},{('ably','666332484'),('cafe24','20261018-0000029')})
        self.assertEqual(self.calls[0][2],{'username':'u','password':'p'});self.assertEqual(self.acct,{})
        log=self.store.read()['soldoutCancelLog'];self.assertTrue(any(x.get('sno')=='666332484' and x['result']=='에이블리 취소 완료' for x in log))
        self.assertEqual(c.status()['phase'],'done')
    def test_already_cancelled_is_skipped(self):
        c=self.ctrl();r=c.cancel_only({'keys':['k1','k4']});self.wait(c)
        self.assertEqual((r['started'],r['skipped']),(1,1));self.assertEqual([t['sno'] for t in self.calls[0][0]],['666332484'])
    def test_only_done_selection_refuses(self):
        from soldout_display import DisplayError
        c=self.ctrl()
        with self.assertRaisesRegex(DisplayError,'이미 취소 완료'):c.cancel_only({'keys':['k4']})
        with self.assertRaisesRegex(DisplayError,'취소할 자사몰·에이블리·지그재그 주문이 없습니다'):c.cancel_only({'keys':['k3']})
        with self.assertRaises(DisplayError):c.cancel_only({'keys':[]})
        self.assertEqual(self.calls,[])
