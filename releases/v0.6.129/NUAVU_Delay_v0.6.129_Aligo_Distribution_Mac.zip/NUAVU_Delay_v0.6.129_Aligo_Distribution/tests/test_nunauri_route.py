"""2026-10-26 17:46 요청: 배포판 — 너나우리 ID·비밀번호가 저장돼 있으면 문자(SMS/LMS)는 너나우리로, 없으면 알리고 문자로.
가짜 공급사·메모리 금고만 사용. 실제 발송 없음."""
import unittest
from pathlib import Path
from helpers import Base,MemoryVault,Clock
from domain import Engine,KST,now,parse_time,ValidationError

class FakeNuna:
    def __init__(self):self.sent=[];self.result='성공';self.error=None;self.report_calls=[]
    def send(self,kind,cred,sender,receiver,content,title,scheme):
        if self.error:raise self.error
        self.sent.append({'kind':kind,'user':cred.user,'send_number':sender,'receive_number':receiver,'msg':content,'senddate':parse_time(now()).astimezone(KST).isoformat(),'result':self.result})
        return 1
    def remaining(self,kind,cred,scheme='https'):return '77'
    def report(self,kind,cred,day,scheme):
        self.report_calls.append((kind,day));return [dict(r,result=self.result) for r in self.sent if r['kind']==kind]

class NunauriRouteTests(Base):
    def setUp(self):
        super().setUp()
        self.nuna=FakeNuna();self.nvault=MemoryVault()
        self.engine=Engine(self.store,self.fake,self.vault,aligo_provider=self.at,aligo_vault=self.atvault,nunauri=self.nuna,nuna_vault=self.nvault)
    def restart(self):self.engine=Engine(self.store,self.fake,self.vault,aligo_provider=self.at,aligo_vault=self.atvault,nunauri=self.nuna,nuna_vault=self.nvault)
    def nuna_on(self,**kw):
        p={'smsUser':'NUNA-SMS','smsPassword':'FAKE-ONLY','lmsUser':'NUNA-LMS','lmsPassword':'FAKE-ONLY'};p.update(kw);return self.engine.configure_nunauri(p)

    def test_default_is_aligo(self):
        st=self.engine.public_state();self.assertEqual(st['smsRoute'],{'SMS':'ALIGO_SMS','LMS':'ALIGO_SMS'});self.assertFalse(st['nunauriAccount']['active']['LMS'])
        n=self.send();self.assertEqual((n['provider'],n['channel'],n['status']),('ALIGO_SMS','알리고 LMS','PENDING'));self.assertEqual(len(self.fake.sent),1);self.assertEqual(self.nuna.sent,[])
    def test_nunauri_when_credentials_saved(self):
        r=self.nuna_on();self.assertIn('너나우리',r['message'])
        st=self.engine.public_state();self.assertEqual(st['smsRoute'],{'SMS':'NUNAURI','LMS':'NUNAURI'});self.assertTrue(st['credentialsReady']['LMS'])
        self.assertEqual(self.nvault.value['provider'],'NUNAURI');self.assertEqual(self.nvault.value['credential']['lmsPassword'],'FAKE-ONLY')
        n=self.send()
        self.assertEqual((n['provider'],n['channel'],n['account'],n['status'],n.get('nunaCode')),('NUNAURI','너나우리 LMS','NUNA-LMS','PENDING',1))
        self.assertEqual(len(self.nuna.sent),1);self.assertEqual(self.fake.sent,[]);self.assertEqual(self.nuna.sent[0]['send_number'],'0212345678')
        self.assertIn('안내번호:'+n['ref'],self.nuna.sent[0]['msg'])
        self.at_age(n,seconds=70);r=self.engine.poll_sms(force=True)
        self.assertIn('너나우리 문자 1건 조회 / 1건 최종 확인',r['message']);self.assertEqual(self.last()['status'],'DELIVERED');self.assertEqual(self.nuna.report_calls[0][0],'LMS')
    def test_nunauri_failure_result(self):
        self.nuna_on();self.nuna.result='실패';n=self.send();self.at_age(n,seconds=70);self.engine.poll_sms(force=True)
        self.assertEqual(self.last()['status'],'FAILED');self.assertTrue(any(a['code']=='DELIVERY_FAILED' for a in self.store.read()['alerts']))
    def test_only_sms_id_routes_sms_only(self):
        self.nuna_on(lmsUser='',lmsPassword='')
        self.assertEqual(self.engine.public_state()['smsRoute'],{'SMS':'NUNAURI','LMS':'ALIGO_SMS'})
        n=self.send();self.assertEqual(n['provider'],'ALIGO_SMS');self.assertEqual(len(self.fake.sent),1)
    def test_nuna_sender_overrides(self):
        self.nuna_on(sender='0299998888');n=self.queue();self.assertEqual(n['sender'],'0299998888');self.assertEqual(n['provider'],'NUNAURI')
    def test_remaining_uses_route(self):
        self.assertEqual(self.engine.remaining('LMS')['route'],'알리고');self.nuna_on();r=self.engine.remaining('LMS');self.assertEqual((r['route'],r['remaining']),('너나우리','77'))
    def test_forget_returns_to_aligo_and_pauses_queue(self):
        self.nuna_on();n=self.queue();self.assertEqual(n['provider'],'NUNAURI')
        r=self.engine.forget_nunauri({'confirmed':True});self.assertIn('알리고',r['message'])
        self.assertEqual(self.engine.public_state()['smsRoute']['LMS'],'ALIGO_SMS');self.assertEqual(self.last()['status'],'PAUSED');self.assertIsNone(self.nvault.value)
        with self.assertRaises(ValidationError):self.engine.forget_nunauri({})
    def test_route_change_pauses_old_queue(self):
        n=self.queue();self.assertEqual(n['provider'],'ALIGO_SMS');self.nuna_on()
        self.assertEqual(self.last()['status'],'PAUSED');self.assertFalse(self.engine.send_one())
    def test_restore_after_restart(self):
        self.nuna_on();self.restart()   # 시작 때 금고에서 자동 복구되거나, 아니면 아래 다시 불러오기로
        r=self.engine.restore_credentials();self.assertIn('너나우리 문자 계정도 불러왔습니다',r['message'])
        self.assertEqual(sorted(self.engine.nuna_creds),['LMS','SMS']);self.assertEqual(self.engine.public_state()['smsRoute']['LMS'],'NUNAURI')
    def test_restore_rejects_changed_binding(self):
        self.nuna_on();self.restart()
        with self.store.edit() as s:s['settings']['nunaLmsUser']='OTHER'
        r=self.engine.restore_credentials();self.assertIn('다릅니다',r['message']);self.assertEqual(self.engine.nuna_creds,{})
    def test_validation(self):
        with self.assertRaises(ValidationError):self.engine.configure_nunauri({})
        with self.assertRaises(ValidationError):self.engine.configure_nunauri({'smsUser':'A B','smsPassword':'x'})
        with self.assertRaises(ValidationError):self.engine.configure_nunauri({'smsUser':'A','smsPassword':''})   # 새 ID 는 비밀번호 필수
        self.nuna_on();self.engine.configure_nunauri({'smsUser':'NUNA-SMS','smsPassword':'','lmsUser':'NUNA-LMS','lmsPassword':''})   # 같은 ID 면 저장된 비밀번호 유지
        self.assertEqual(self.engine.nuna_creds['SMS'].password,'FAKE-ONLY')
    def test_ui_and_install_list(self):
        ROOT=Path(__file__).resolve().parents[1]
        html=(ROOT/'web/index.html').read_text(encoding='utf-8');js=(ROOT/'web/app.js').read_text(encoding='utf-8')
        for w in ('id="nunaSmsUser"','id="nunaLmsPassword"','id="saveNunaBtn"','id="forgetNunaBtn"','id="smsChannelOption"'):self.assertIn(w,html,w)
        for w in ("api('nunauri-settings'","api('nunauri-forget'",'smsRouteName'):self.assertIn(w,js,w)
        self.assertIn("'nunauri_provider.py'",(ROOT/'install_desktop.py').read_text(encoding='utf-8'))
        self.assertIn("'/api/nunauri-settings'",(ROOT/'app.py').read_text(encoding='utf-8'))

if __name__=='__main__':unittest.main()
