"""2026-10-24 요청 (배포판 2026-10-25): 출고 예상일 변경 — 출고장(중국 출고일) 단위로 앱의 실 출고 예상일을 직접 지정/해제.
고객에게 안내한 출고 예정일·발송 이력은 바뀌지 않고 메시지도 보내지 않는다. Codex는 제안 카드만 만든다."""
import sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from helpers import Base
from test_supply_regression import order,source_row,xlsx
from domain import SELLERS
from supply_workflow import SupplyError,apply_dispatch_override
import codex_context

class HelperTests(unittest.TestCase):
    def test_override_replaces_korea_and_receipt_dates(self):
        p={'chinaDate':'2026-10-24','koreaStart':'2026-10-28','koreaEnd':'2026-10-29','koreaLatest':'2026-10-30','receiptStart':'2026-10-29','receiptEnd':'2026-10-30','calendarKnown':True}
        o=apply_dispatch_override(p,{'2026-10-24':{'start':'2026-10-27','end':'2026-10-27'}})
        self.assertEqual((o['koreaStart'],o['koreaEnd'],o['receiptStart']),('2026-10-27','2026-10-27','2026-10-28'))
        self.assertEqual(o['overriddenFrom'],{'koreaStart':'2026-10-28','koreaEnd':'2026-10-29'});self.assertTrue(o['dispatchOverride'])
        self.assertEqual(p['koreaStart'],'2026-10-28')   # 원본 path는 그대로
        self.assertIs(apply_dispatch_override(p,{'2026-10-17':{'start':'2026-10-20','end':'2026-10-20'}}),p)
        self.assertIsNone(apply_dispatch_override(None,{}))

class EngineTests(Base):
    def setUp(self):
        super().setUp();self.folder=Path(self.tmp.name)/'자료';self.folder.mkdir();self.engine.supply_link(str(self.folder))
        self.engine.import_rows({'rows':[order(1)],'mode':'snapshot','scope':SELLERS,'replaceConfirmed':True})
        (self.folder/'솔리아 10월 13일 출고장 (완료).xlsx').write_bytes(xlsx([('자료',[source_row()])]))
        self.engine.supply_refresh()
    def row(self):return next(r for r in self.engine.public_state()['rows'] if r['active'])
    def test_change_and_clear_whole_batch_without_touching_customer_dates(self):
        before=self.row();self.assertEqual(before['dispatchEnd'],'2026-10-19')
        notices=len(self.store.read()['notices']);due=before.get('dueDate','')
        w=self.engine.public_state()['supply']['dispatchWaves'];self.assertEqual(w[0]['chinaDate'],'2026-10-13');self.assertEqual(w[0]['items'],1)
        r=self.engine.dispatch_override({'chinaDate':'2026-10-13','start':'2026-10-16','end':'2026-10-16'})
        self.assertIn('메시지는 보내지 않았습니다',r['message'])
        after=self.row();self.assertEqual((after['dispatchStart'],after['dispatchEnd']),('2026-10-16','2026-10-16'))
        self.assertEqual(after.get('dueDate',''),due);self.assertEqual(len(self.store.read()['notices']),notices)
        w=self.engine.public_state()['supply']['dispatchWaves'][0]
        self.assertEqual(w['override']['start'],'2026-10-16');self.assertEqual(w['original']['koreaEnd'],'2026-10-19')
        self.assertIn('출고 예상일 직접 지정',[a['event'] for a in self.store.read()['audits']])
        # Codex용 자료: 중국출고일·직접지정 열, 제안 확인
        csv=codex_context.order_list(self.engine);self.assertIn('중국출고일',csv.splitlines()[0]);self.assertIn('2026-10-13',csv.splitlines()[1])
        chk=codex_context.validate_action(self.engine,{'action':'change_dispatch','chinaDates':['2026-10-13','2026-09-01'],'dispatchStart':'2026-10-16'})
        self.assertEqual(chk['chinaDates'],['2026-10-13']);self.assertEqual(chk['unmatched'],1);self.assertEqual(chk['count'],1)
        self.assertIn('중국 출고 2026-10-13',codex_context.build(self.engine,'t'))
        key=self.row()['key']
        self.assertEqual(codex_context.validate_action(self.engine,{'action':'change_dispatch','rowKeys':[key],'dispatchStart':'2026-10-16'})['chinaDates'],['2026-10-13'])
        self.assertEqual(codex_context.validate_action(self.engine,{'action':'change_dispatch','fromDates':['2026-10-16'],'dispatchStart':'2026-10-15'})['chinaDates'],['2026-10-13'])
        self.engine.dispatch_override({'chinaDate':'2026-10-13','clear':True})
        self.assertEqual(self.row()['dispatchEnd'],'2026-10-19')
    def test_validation(self):
        for bad in ({'chinaDate':'x','start':'2026-10-16'},{'chinaDate':'2026-10-13','start':'2026-10-12'},
                    {'chinaDate':'2026-10-13','start':'2026-10-20','end':'2026-10-16'},{'chinaDate':'2026-10-13','start':'x'},
                    {'chinaDate':'2026-10-13','clear':True}):
            with self.subTest(bad=bad),self.assertRaises(SupplyError):self.engine.dispatch_override(bad)
    def test_ui_wired(self):
        self.assertIn("'/api/dispatch-override'",(ROOT/'app.py').read_text(encoding='utf-8'))
        js=(ROOT/'web'/'ship_delay.js').read_text(encoding='utf-8')
        self.assertIn('dispatchOverrideDialog',js);self.assertIn("api('dispatch-override'",js);self.assertIn('nuavuDispatchOverride',js)
        self.assertIn("p.action==='change_dispatch'",(ROOT/'web'/'codex_ui.js').read_text(encoding='utf-8'))

if __name__=='__main__':unittest.main()
