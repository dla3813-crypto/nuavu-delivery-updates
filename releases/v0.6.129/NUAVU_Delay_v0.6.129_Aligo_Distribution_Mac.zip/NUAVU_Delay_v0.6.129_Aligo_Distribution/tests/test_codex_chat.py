"""2026-10-24 Codex 대화 (Nuavu Auto 1.31.1 tests/test_codex_chat.py 이식 + 배송안내 앱 전용 검사)."""
import io,json,os,sys,tempfile,time,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from codex_files import Workspace,digest,preview
from codex_rpc import Client,CodexError,child_environment
from codex_service import CodexChatService
from codex_view import parts
def panel(s):return ''.join(v for v in parts(s).values() if isinstance(v,str))
import codex_context


def make_xlsx(path,value='재고',image=False):
    import openpyxl
    w=openpyxl.Workbook();w.active['A1']=value;w.active['B1']='=1+1'
    if image:
        from openpyxl.drawing.image import Image
        from PIL import Image as P
        b=io.BytesIO();P.new('RGB',(4,4),'red').save(b,'PNG');b.seek(0);w.active.add_image(Image(b),'C3')
    w.save(path)


class FileTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=Path(self.tmp.name);self.source=self.base/'원본.txt';self.source.write_text('연결 시험 전\n수량: 7\n')
        self.ws=Workspace(self.base/'session');self.key=self.ws.import_file(self.source);self.copy=self.ws.work/self.source.name
    def tearDown(self):self.tmp.cleanup()
    def test_working_copy_preview_apply_restore_are_separate(self):
        original=self.source.read_bytes();self.copy.write_text('구독 연결 완료\n수량: 7\n')
        review=self.ws.review()[0];self.assertTrue(review['changed']);self.assertIn('-연결 시험 전',review['preview']);self.assertEqual(self.source.read_bytes(),original)
        self.ws.apply(self.key,review['sha']);self.assertEqual(self.source.read_bytes(),self.copy.read_bytes())
        self.assertFalse(self.ws.review()[0]['changed']);backup=Path(self.ws.records[self.key]['history'][0]['backup']);self.assertEqual(backup.read_bytes(),original)
        self.ws.restore(self.key);self.assertEqual(self.source.read_bytes(),original);self.assertIn('구독 연결 완료',self.copy.read_text())
    def test_concurrent_original_change_and_stale_preview_never_overwrite(self):
        self.copy.write_text('AI 수정');sha=digest(self.copy);self.copy.write_text('뒤늦은 수정')
        with self.assertRaises(CodexError):self.ws.apply(self.key,sha)
        self.source.write_text('사장님 수정')
        with self.assertRaises(CodexError):self.ws.apply(self.key,digest(self.copy))
        self.assertEqual(self.source.read_text(),'사장님 수정');self.assertFalse(self.ws.records[self.key]['history'])
    def test_restore_respects_later_changes(self):
        self.copy.write_text('AI');self.ws.apply(self.key,digest(self.copy));self.source.write_text('이후 수정')
        with self.assertRaises(CodexError):self.ws.restore(self.key)
        self.assertEqual(self.source.read_text(),'이후 수정')
    def test_invalid_workbook_is_not_published(self):
        p=self.base/'재고.xlsx';make_xlsx(p);before=p.read_bytes()
        key=self.ws.import_file(p);copy=self.ws.work/p.name;copy.write_text('not a workbook')
        with self.assertRaises(CodexError):self.ws.apply(key,digest(copy))
        self.assertEqual(p.read_bytes(),before)
    def test_xlsx_preview_reports_cell_and_non_cell_changes(self):
        p=self.base/'안내.xlsx';make_xlsx(p,'예정일 미정',image=True);key=self.ws.import_file(p);copy=self.ws.work/p.name
        # 이미지가 빠지고 값만 바뀐 수정본 → 셀 값만 보고 '정상'이라 하지 않는다
        make_xlsx(copy,'예정일 10/28',image=False)
        r=next(x for x in self.ws.review() if x['key']==key);self.assertTrue(r['changed'])
        self.assertIn('예정일 미정 → 예정일 10/28',r['preview']);self.assertIn('이미지·그림 삭제',r['preview'])
        self.ws.apply(key,r['sha']);self.assertEqual(digest(p),r['sha'])   # 구조가 올바르면 반영은 가능 (판단은 사장님)
    def test_xlsx_only_one_cell_changed_keeps_other_parts(self):
        p=self.base/'b.xlsx';make_xlsx(p,'A',image=True);key=self.ws.import_file(p);copy=self.ws.work/p.name
        # 공유 문자열만 바꾼 수정 (다른 파트는 그대로 복사) — 이미지·수식 변경 없음으로 나와야 함
        out=io.BytesIO()
        with zipfile.ZipFile(copy) as zin,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as zout:
            for i in zin.infolist():
                data=zin.read(i.filename)
                if i.filename=='xl/sharedStrings.xml':data=data.replace(b'>A<',b'>B<')
                if i.filename=='xl/worksheets/sheet1.xml' and b't="inlineStr"' in data:data=data.replace(b'<t>A</t>',b'<t>B</t>')
                zout.writestr(i,data)
        copy.write_bytes(out.getvalue())
        pv=preview(self.ws.records[key]['original'],copy)
        self.assertIn('A → B',pv);self.assertIn('변경은 찾지 못했습니다',pv);self.assertNotIn('이미지·그림 삭제',pv);self.assertNotIn('수식 개수 변경',pv)
    def test_traversal_and_symlinks_are_rejected(self):
        for name in ('../원본.txt',str(self.source),'.nuavu/context.md'):
            with self.assertRaises(CodexError):self.ws.safe_work(name)
        (self.ws.work/'링크.txt').symlink_to(self.source)
        with self.assertRaises(CodexError):self.ws.safe_work('링크.txt')
        self.assertEqual([r['name'] for r in self.ws.review()],['원본.txt'])
    def test_program_source_is_not_a_work_file(self):
        p=self.base/'app.py';p.write_text('print(1)')
        with self.assertRaises(CodexError):self.ws.import_file(p)
    def test_new_result_exports_without_changing_original(self):
        p=self.ws.work/'새 결과.csv';p.write_text('상품,수량\n니트,7\n');sha=digest(p)
        result=self.ws.export('new:새 결과.csv',sha,self.base/'결과');self.assertEqual(result.read_bytes(),p.read_bytes())
        self.assertEqual(self.source.read_text(),'연결 시험 전\n수량: 7\n')


class FakeClient:
    account_type='chatgpt'
    def __init__(self,home,on_event,on_request,on_exit):self.home=home;self.event=on_event;self.request=on_request;self.exit=on_exit;self.calls=[];self.replies=[];self.closed=False
    def start(self):pass
    def send(self,m):self.calls.append(m)
    def call(self,method,p=None,timeout=35):
        self.calls.append({'method':method,'params':p or {}})
        if method=='account/read':return {'account':{'type':self.account_type,'email':'owner@example.test','planType':'pro'}}
        if method=='model/list':return {'data':[{'model':'available-model','displayName':'Available model','isDefault':True,'supportedReasoningEfforts':[{'reasoningEffort':'medium'}],'defaultReasoningEffort':'medium'}]}
        if method=='account/rateLimits/read':return {'rateLimits':{'primary':{'usedPercent':12,'resetsAt':1234,'windowDurationMins':300}}}
        if method=='thread/start':return {'thread':{'id':'own-thread'}}
        if method=='turn/start':return {'turn':{'id':'turn-1'}}
        if method=='account/login/start':return {'authUrl':'https://auth.openai.com/authorize?secret=login-code','loginId':'login-1'}
        return {}
    def reply(self,key,result=None,error=None):self.replies.append({'id':key,'result':result,'error':error})
    def close(self):self.closed=True


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=Path(self.tmp.name);self.opened=[]
        self.delay=self.base/'Desktop/배송지연(AI)';self.delay.mkdir(parents=True)
        self.s=self.make()
    def make(self,**k):
        return CodexChatService(self.base/'state',self.delay/'Codex 결과',roots=[('delay','배송지연(AI)',self.delay)],context=lambda:'안전한 요약',version='0.6.129',
                                open_url=self.opened.append,open_path=self.opened.append,client_factory=FakeClient,**k)
    def tearDown(self):self.s.close();self.tmp.cleanup()
    def wait(self):
        end=time.monotonic()+4
        while self.s.op and time.monotonic()<end:time.sleep(.01)
        self.assertFalse(self.s.op,self.s.error)
    def test_subscription_send_stream_finish_and_resume(self):
        self.s.connect();self.wait();self.assertEqual(self.s.account['type'],'chatgpt');self.assertEqual(self.s.saved['model'],'available-model')
        init=next(x['params'] for x in self.s.client.calls if x.get('method')=='initialize');self.assertEqual(init['clientInfo']['name'],'delivery_notice_distribution')
        self.s.send('수량을 확인해 줘');self.wait();c=self.s.client;self.assertTrue(self.s.running)
        turn=next(x['params'] for x in c.calls if x.get('method')=='turn/start')
        self.assertEqual(turn['sandboxPolicy']['type'],'workspaceWrite');self.assertFalse(turn['sandboxPolicy']['networkAccess'])
        self.assertEqual(turn['sandboxPolicy']['writableRoots'],[str(self.s.workspace.work)])
        self.assertEqual(turn['cwd'],str(self.s.workspace.work));self.assertEqual(turn['approvalPolicy'],'on-request')
        self.assertTrue((self.s.workspace.work/'.nuavu/context.md').read_text().startswith('안전한 요약'))
        c.event('item/agentMessage/delta',{'threadId':'own-thread','itemId':'reply','delta':'수량은 '})
        c.event('item/agentMessage/delta',{'threadId':'own-thread','itemId':'reply','delta':'7입니다.'})
        self.assertEqual(self.s.status()['messages'][-1]['text'],'수량은 7입니다.')
        c.event('item/completed',{'threadId':'own-thread','item':{'type':'agentMessage','id':'reply','text':'수량은 7입니다.'}})
        c.event('turn/completed',{'threadId':'own-thread','turn':{'status':'completed'}});self.wait()
        self.assertEqual(self.s.status()['messages'][-1]['text'],'수량은 7입니다.');key=self.s.chat['id'];self.s.close()
        self.s=self.make();self.assertEqual(self.s.chat['id'],key)
        self.assertFalse(any(m['role']=='system' for m in self.s.chat['messages']))   # 정상 완료 대화는 끊김 표시 없음
        self.s.send('다시 확인');self.wait();self.assertTrue(any(x.get('method')=='thread/resume' for x in self.s.client.calls));self.assertFalse(any(x.get('method')=='thread/start' for x in self.s.client.calls))
    def test_app_restart_mid_answer_marks_interrupted_and_never_resends(self):
        self.s.send('파일 수정');self.wait();key=self.s.chat['id'];self.s.close()
        self.s=self.make();self.assertEqual(self.s.chat['id'],key)
        self.assertEqual(self.s.chat['messages'][-1]['role'],'system');self.assertIn('자동으로 다시 보내지',self.s.chat['messages'][-1]['text'])
        self.s.activate();self.wait();self.assertFalse(any(x.get('method')=='turn/start' for x in self.s.client.calls))
    def test_api_auth_is_not_used_as_fallback(self):
        class ApiClient(FakeClient):account_type='apiKey'
        self.s.client_factory=ApiClient;self.s.send('안녕');self.wait()
        self.assertIn('API 키',self.s.error);self.assertFalse(any(x.get('method')=='turn/start' for x in self.s.client.calls))
        self.assertFalse(any(x.get('method')=='account/login/start' and x['params'].get('type')=='apiKey' for x in self.s.client.calls))
    def test_login_opens_on_this_mac_and_url_is_not_in_state_payload(self):
        self.s.login();self.wait();self.assertEqual(len(self.opened),1);self.assertTrue(self.opened[0].startswith('https://auth.openai.com/'))
        self.assertNotIn('secret=login-code',json.dumps(self.s.status(),ensure_ascii=False));self.assertNotIn('secret=login-code',panel(self.s.status()))
        self.assertTrue(self.s.status()['loginPending'])
    def test_login_url_must_be_official(self):
        class Bad(FakeClient):
            def call(self,method,p=None,timeout=35):
                if method=='account/login/start':return {'authUrl':'https://evil.example/login','loginId':'x'}
                return super().call(method,p,timeout)
        self.s.client_factory=Bad;self.s.login()
        end=time.monotonic()+4
        while self.s.op and time.monotonic()<end:time.sleep(.01)
        self.assertIn('공식 로그인',self.s.error);self.assertEqual(self.opened,[])
    def test_no_automatic_resend_after_process_disconnect(self):
        self.s.send('파일 수정');self.wait();old=self.s.client;old.exit();self.assertFalse(self.s.running)
        self.assertIn('자동 재전송하지',self.s.error)
        self.s.connect();self.wait();self.assertFalse(any(x.get('method')=='turn/start' for x in self.s.client.calls));self.assertIn('파일 수정',str(self.s.chat['messages']))
    def test_stop_sends_interrupt_only(self):
        self.s.send('긴 작업');self.wait();c=self.s.client;c.event('turn/started',{'threadId':'own-thread','turn':{'id':'turn-1'}})
        self.s.stop();time.sleep(.2)
        self.assertTrue(any(x.get('method')=='turn/interrupt' and x['params']=={'threadId':'own-thread','turnId':'turn-1'} for x in c.calls))
        c.event('turn/completed',{'threadId':'own-thread','turn':{'status':'interrupted'}});self.wait()
        self.assertEqual(sum(1 for x in c.calls if x.get('method')=='turn/start'),1);self.assertIn('중지',self.s.message)
    def test_permission_escalations_declined_and_question_answers_forwarded(self):
        self.s.send('파일 수정');self.wait();c=self.s.client
        for name in ('item/fileChange/requestApproval','item/commandExecution/requestApproval'):
            c.request({'id':42,'method':name,'params':{'threadId':'own-thread','turnId':'turn-1'}});self.assertEqual(c.replies[-1]['result'],{'decision':'decline'})
        c.request({'id':44,'method':'execCommandApproval','params':{'threadId':'own-thread'}});self.assertEqual(c.replies[-1]['result'],{'decision':'denied'})
        c.request({'id':43,'method':'item/permissions/requestApproval','params':{'threadId':'own-thread'}});self.assertEqual(c.replies[-1]['result']['permissions'],{})
        c.request({'id':0,'method':'item/tool/requestUserInput','params':{'threadId':'own-thread','questions':[{'id':'q','question':'어떤 색상?'}]}})
        self.assertIn('data-cx-request="0"',panel(self.s.status()));self.s.answer({'request':'0','answers':{'q':'아이보리'}})
        self.assertEqual(c.replies[-1]['id'],0);self.assertEqual(c.replies[-1]['result']['answers']['q']['answers'],['아이보리'])
    def test_file_browser_uses_only_host_roots(self):
        p=self.delay/'시험.txt';p.write_text('7');self.assertIn('시험.txt',[i['name'] for i in self.s.browse('delay:')['items']])
        self.s.attach_token('delay:시험.txt');self.wait()
        self.assertEqual(len(self.s.files),1);self.assertEqual(self.s.workspace.records[self.s.files[0]['key']]['source'],str(p.resolve()))
        for token in ('delay:../../secret.txt','delay:/etc/passwd','missing:file.txt'):
            with self.assertRaises(CodexError):self.s.attach_token(token)
        protected=self.base/'state'/'auth.json';protected.write_text('{}')
        with self.assertRaises(CodexError):self.s.attach(protected)
    def test_apply_is_blocked_while_app_automation_runs(self):
        p=self.delay/'안내.txt';p.write_text('A');self.s.can_apply=lambda path:False
        self.s.attach_token('delay:안내.txt');self.wait();f=self.s.files[0]
        (self.s.workspace.work/'안내.txt').write_text('B');self.s.review();self.wait();f=self.s.files[0]
        self.s.apply(f['key'],f['sha'])
        end=time.monotonic()+4
        while self.s.op and time.monotonic()<end:time.sleep(.01)
        self.assertIn('자동 작업 중',self.s.error);self.assertEqual(p.read_text(),'A')
    def test_html_is_inert_and_does_not_expose_auth(self):
        self.s.chat['messages']=[{'id':'x','role':'assistant','text':'<script>alert(1)</script><button data-cx="cxApply">x</button>'}]
        html=panel(self.s.status());self.assertNotIn('<script>',html);self.assertIn('&lt;script&gt;',html);self.assertNotIn('<button data-cx="cxApply">x',html);self.assertIn('&lt;button data-cx=&quot;cxApply&quot;&gt;',html)
    def test_handle_dispatch_reaches_service(self):
        # 배포판에는 원격 화면이 없다: 앱 창(handle)만 같은 서비스로 간다
        svc=self.s;svc.handle('cxSend',{'text':'질문'});self.wait()
        turn=next(x['params'] for x in svc.client.calls if x.get('method')=='turn/start')
        self.assertEqual(turn['cwd'],str(svc.workspace.work));self.assertEqual(svc.client.home,self.base/'state/codex_chat/home')
        self.assertIn('질문',str(svc.chat['messages']))
    def test_reopened_panel_reconnects_without_replaying_a_turn(self):
        self.s.connect();self.wait();self.s.close();self.s=self.make()
        self.s.activate();self.wait();self.assertEqual(self.s.account['type'],'chatgpt')
        self.assertFalse(any(x.get('method')=='turn/start' for x in self.s.client.calls))
    def test_brief_is_light(self):
        b=self.s.brief();self.assertNotIn('files',b);self.assertNotIn('messages',b);self.assertIn('revision',b)


class ContextTests(unittest.TestCase):
    def test_context_has_rules_but_no_customer_data(self):
        class Store:
            def read(self):return {'rows':[{'seller':'누아브 에이블리','active':True,'buyer':'홍길동','phone':'01012345678'}],'notices':[]}
        class E:store=Store()
        t=codex_context.build(E(),'0.6.129')
        self.assertIn('0.6.129',t);self.assertIn('{출고예정일}',t);self.assertIn('에이블리: 1개',t)
        self.assertNotIn('홍길동',t);self.assertNotIn('01012345678',t)


class RpcTests(unittest.TestCase):
    def test_environment_does_not_inherit_keys_or_remote_host(self):
        with patch.dict(os.environ,{'OPENAI_API_KEY':'secret','ANTHROPIC_API_KEY':'secret','CODEX_HOME':'elsewhere','CODEX_REMOTE_URL':'wss://elsewhere','PYTHONPATH':'elsewhere'}):
            e=child_environment(Path('/only-host/home'))
        self.assertEqual(e['CODEX_HOME'],'/only-host/home')
        for key in ('OPENAI_API_KEY','ANTHROPIC_API_KEY','CODEX_REMOTE_URL','PYTHONPATH'):self.assertNotIn(key,e)
    def test_stdio_transport_correlates_events_and_responses(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);stub=root/'codex';stub.write_text('#!'+sys.executable+'''
import json,sys
for line in sys.stdin:
 m=json.loads(line)
 if 'id' in m:
  print(json.dumps({'method':'event/test','params':{'ok':True}}),flush=True)
  print(json.dumps({'id':m['id'],'result':{'echo':m['params']}}),flush=True)
''');stub.chmod(0o700)
            events=[];c=Client(root/'home',lambda m,p:events.append((m,p)),lambda m:None,binary=stub)
            try:
                c.start();self.assertEqual(c.call('test',{'value':'한글'})['echo']['value'],'한글');self.assertEqual(events[0][0],'event/test')
                self.assertIn('stdio://',c.proc.args);self.assertIn('cli_auth_credentials_store="keyring"',c.proc.args)
                self.assertTrue((root/'home').is_dir());self.assertEqual((root/'home').stat().st_mode&0o777,0o700)
            finally:c.close()

if __name__=='__main__':unittest.main()
