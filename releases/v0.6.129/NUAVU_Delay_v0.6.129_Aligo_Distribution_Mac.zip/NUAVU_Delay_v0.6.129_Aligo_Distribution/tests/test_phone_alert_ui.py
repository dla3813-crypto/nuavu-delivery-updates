"""2026-10-23 20:57 보고: 체크하면 '아이폰 알림을 껐습니다', 번호 넣고 시험 보내기 → '받는 곳을 먼저 입력하세요'. 실제 화면(웹) + 실제 서버로 재현·확인."""
import os,shutil,sys,tempfile,threading,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import phone_alert as pa

class PhoneAlertScreen(unittest.TestCase):
    def setUp(self):
        from domain import Engine,Store
        from app import LocalServer
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(Path(self.tmp.name));self.engine=Engine(self.store)
        self.sent=[];pa.install(pa.PhoneAlerts(self.store.directory,sender=lambda to,text:self.sent.append((to,text)),platform='darwin',delay=0))
        self.srv=LocalServer(self.engine,port=0);threading.Thread(target=self.srv.serve_forever,daemon=True).start()
    def tearDown(self):
        self.srv.shutdown();pa.install(None)
        try:self.store.close()
        except Exception:pass
        self.tmp.cleanup()
    def page(self,pw):
        b=pw.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or '/opt/pw-browsers/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
        p=b.new_page();p.goto(f'http://127.0.0.1:{self.srv.server_port}/#{self.srv.token}');p.wait_for_timeout(1800)
        p.click('#settingsHubBtn');p.wait_for_selector('#phoneAlertOn');p.wait_for_timeout(500);return b,p
    def state(self,p):return p.locator('#phoneAlertState').inner_text()
    def test_owner_steps(self):
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            b,p=self.page(pw)
            try:
                # 1) 번호 없이 체크 → '껐습니다'가 아니라 받는 곳 안내, 체크는 풀림
                p.click('#phoneAlertOn');p.wait_for_timeout(700)
                self.assertIn('받는 곳',self.state(p));self.assertNotIn('껐습니다',self.state(p));self.assertFalse(p.is_checked('#phoneAlertOn'))
                # 2) 번호 넣고 바로 시험 보내기 → 그 번호로 1통
                p.fill('#phoneAlertTo','010-1234-5678');p.click('#phoneAlertTest');p.wait_for_timeout(1200)
                self.assertEqual([t for t,_ in self.sent],['+821012345678'],self.state(p));self.assertIn('시험 아이메시지를 보냈습니다',self.state(p))
                self.assertEqual(p.input_value('#phoneAlertTo'),'+821012345678')
                # 3) 체크 → 켜짐으로 저장
                p.click('#phoneAlertOn');p.wait_for_timeout(800)
                self.assertTrue(p.is_checked('#phoneAlertOn'));self.assertIn('켰습니다',self.state(p))
                self.assertEqual(pa.active().config(),{'enabled':True,'to':'+821012345678'})
                # 4) 끄기
                p.click('#phoneAlertOn');p.wait_for_timeout(800);self.assertEqual(pa.active().config()['enabled'],False);self.assertIn('껐습니다',self.state(p))
            finally:b.close()
    def test_type_number_then_check_directly(self):
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            b,p=self.page(pw)
            try:
                p.fill('#phoneAlertTo','boss@icloud.com');p.click('#phoneAlertOn');p.wait_for_timeout(1200)
                self.assertTrue(p.is_checked('#phoneAlertOn'));self.assertEqual(pa.active().config(),{'enabled':True,'to':'boss@icloud.com'})
            finally:b.close()

if __name__=='__main__':unittest.main()
