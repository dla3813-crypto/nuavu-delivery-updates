"""2026-10-25 배포판 윈도우: Codex 실행 파일 찾기 · 자식 환경 · 콘솔 창 없음 · 엑셀용 python.exe.
실제 윈도우가 아니라 경로·환경만 흉내 내어 확인한다 (실행은 하지 않음)."""
import os,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import codex_rpc,codex_service

class WindowsTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def test_finds_npm_vendor_exe_not_cmd_wrapper(self):
        appdata=self.base/'Roaming';exe=appdata/'npm/node_modules/@openai/codex/node_modules/@openai/codex-win32-x64/vendor/x86_64-pc-windows-msvc/bin/codex.exe'
        exe.parent.mkdir(parents=True);exe.write_bytes(b'MZ')
        (appdata/'npm/codex.cmd').write_text('@echo off')
        env={'APPDATA':str(appdata),'LOCALAPPDATA':str(self.base/'Local'),'PROCESSOR_ARCHITECTURE':'AMD64'}
        with patch.object(codex_rpc,'IS_WINDOWS',True),patch.dict(os.environ,env,clear=True),patch.object(codex_rpc.shutil,'which',return_value=None):
            self.assertEqual(codex_rpc.find_codex(),exe.resolve())
    def test_missing_codex_tells_how_to_install_on_windows(self):
        with patch.object(codex_rpc,'IS_WINDOWS',True),patch.dict(os.environ,{'APPDATA':str(self.base),'LOCALAPPDATA':str(self.base)},clear=True),patch.object(codex_rpc.shutil,'which',return_value=None):
            with self.assertRaises(codex_rpc.CodexError) as e:codex_rpc.find_codex()
        self.assertIn('npm install -g @openai/codex',str(e.exception))
    def test_explicit_location(self):
        exe=self.base/'codex.exe';exe.write_bytes(b'MZ')
        with patch.object(codex_rpc,'IS_WINDOWS',True),patch.dict(os.environ,{'NUAVU_CODEX_BIN':str(exe)},clear=True):
            self.assertEqual(codex_rpc.find_codex(),exe.resolve())
    def test_child_environment_keeps_windows_basics_and_drops_secrets(self):
        env={'SYSTEMROOT':r'C:\Windows','USERPROFILE':r'C:\Users\a','APPDATA':r'C:\Users\a\AppData\Roaming','TEMP':r'C:\Temp','OPENAI_API_KEY':'sk-x','CODEX_HOME':'x','PATH':r'C:\evil'}
        with patch.object(codex_rpc,'IS_WINDOWS',True),patch.dict(os.environ,env,clear=True):
            out=codex_rpc.child_environment(self.base/'home')
        self.assertEqual(out['SYSTEMROOT'],r'C:\Windows');self.assertEqual(out['CODEX_HOME'],str(self.base/'home'))
        self.assertNotIn('OPENAI_API_KEY',out);self.assertNotIn(r'C:\evil',out['PATH']);self.assertIn(r'C:\Windows\System32',out['PATH'])
    def test_no_console_window_on_windows(self):
        with patch.object(codex_rpc,'IS_WINDOWS',True):o=codex_rpc._spawn_options()
        self.assertTrue(o['creationflags']&0x08000000);self.assertNotIn('start_new_session',o)
        with patch.object(codex_rpc,'IS_WINDOWS',False):self.assertEqual(codex_rpc._spawn_options(),{'start_new_session':True})
    def test_codex_gets_console_python_not_pythonw(self):
        d=self.base/'Scripts';d.mkdir();(d/'python.exe').write_bytes(b'');(d/'pythonw.exe').write_bytes(b'')
        with patch.object(sys,'platform','win32'),patch.object(sys,'executable',str(d/'pythonw.exe')):
            self.assertEqual(codex_service._console_python(),str(d/'python.exe'))
    def test_attach_blocks_windows_credential_and_app_folders(self):
        src=(ROOT/'codex_service.py').read_text(encoding='utf-8')
        for word in ("'credentials'","'protect'","'nuavu delay distribution'"):self.assertIn(word,src)

if __name__=='__main__':unittest.main()
