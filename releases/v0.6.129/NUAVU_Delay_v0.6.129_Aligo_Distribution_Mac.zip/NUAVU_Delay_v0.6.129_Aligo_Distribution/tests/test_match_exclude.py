"""2026-10-26 15:22 요청: 매칭 취소 — 자동 매칭이 엉뚱하게 붙었을 때 연결 안 함으로 저장, 다시 자동으로 되돌리기."""
from test_dispatch_regression import StrictDatesTests as _helpers
from test_supply_regression import source_row,order
import unittest
from supply_workflow import candidates, order_signature

class MatchExcludeTests(_helpers):   # 도우미(one/progress/info)만 빌려 쓰고, 물려받은 테스트는 아래에서 지워 두 번 돌지 않게 한다
    def test_exclude_turns_automatic_match_off(self):
        self.one('가디건');self.progress([source_row(product='가디건',office='2026-10-15')])
        self.assertTrue(self.info()['matched']);self.assertEqual(self.info()['matchMethod'],'automatic')
        r=self.rows()[0];msg=self.engine.supply_match({'key':r['key'],'variants':[],'exclude':True})['message']
        self.assertIn('연결 안 함',msg)
        i=self.info();self.assertFalse(i['matched']);self.assertTrue(i['excluded']);self.assertFalse(i['matchNeeded']);self.assertEqual(i['reasonCode'],'EXCLUDED');self.assertEqual(i['matchMethod'],'manual');self.assertEqual(i['dispatchEnd'],'')
        self.assertEqual(self.store.read()['audits'][-1]['event'],'자동 매칭 취소(연결 안 함)')
    def test_clear_returns_to_automatic(self):
        self.one('가디건');self.progress([source_row(product='가디건',office='2026-10-15')]);r=self.rows()[0]
        self.engine.supply_match({'key':r['key'],'variants':[],'exclude':True});self.assertTrue(self.info()['excluded'])
        self.engine.supply_match({'key':r['key'],'variants':[]});i=self.info();self.assertFalse(i['excluded']);self.assertTrue(i['matched']);self.assertEqual(i['matchMethod'],'automatic')
    def test_exclude_applies_to_same_signature_orders(self):
        self.orders([order(1,product='가디건'),order(2,product='가디건')]);self.progress([source_row(product='가디건',office='2026-10-15',qty=5)])
        self.engine.supply_match({'key':self.rows()[0]['key'],'variants':[],'exclude':True})
        self.assertTrue(all(r['supplyInfo']['excluded'] and not r['supplyInfo']['matched'] for r in self.rows()))
    def test_exclude_then_manual_pick_reconnects(self):
        self.one('가디건');self.progress([source_row(product='가디건',office='2026-10-15')]);r=self.rows()[0]
        self.engine.supply_match({'key':r['key'],'variants':[],'exclude':True})
        vid=self.engine.public_state()['supply']['variants'][0]['variant'];self.engine.supply_match({'key':r['key'],'variants':[vid]})
        i=self.info();self.assertTrue(i['matched']);self.assertFalse(i['excluded']);self.assertEqual(i['matchMethod'],'manual')
    def test_ui_has_exclude_controls(self):
        from pathlib import Path
        ROOT=Path(__file__).resolve().parents[1];html=(ROOT/'web/index.html').read_text(encoding='utf-8');js=(ROOT/'web/app.js').read_text(encoding='utf-8')
        self.assertIn('id="excludeMatchBtn"',html)
        for w in ('exclude:true','receipt-exclude','매칭 취소됨','연결 수정·취소'):self.assertIn(w,js,w)

for _n in [n for n in dir(_helpers) if n.startswith('test_') and n not in MatchExcludeTests.__dict__]:setattr(MatchExcludeTests,_n,None)
del _helpers
