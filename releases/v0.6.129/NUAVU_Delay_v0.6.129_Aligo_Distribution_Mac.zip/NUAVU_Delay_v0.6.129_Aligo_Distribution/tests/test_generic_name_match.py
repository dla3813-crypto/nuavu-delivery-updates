"""2026-10-26: 진행상황 NS 행 '베이직'(灰色/黑色·F)이 '긱시크 베이직 레이스 슬림핏 반팔 셔츠 블라우스 [원컬러-FREE]'에 자동 매칭되던 오류."""
import pytest
from supply_workflow import candidates, variant_id, product_within, same_product

def src(product,color,size='F',brand='NS'):
    v=dict(brand=brand,product=product,color=color,size=size);v['variant']=variant_id(v);return v

ORDER='(BC-6)[넥타이포함]긱시크 베이직 레이스 슬림핏 반팔 셔츠 블라우스'

def test_generic_one_word_source_does_not_claim_unrelated_order():
    hits,amb,how=candidates(dict(product=ORDER,option='원컬러/FREE'),[src('베이직','灰色'),src('베이직','黑色')],{})
    assert hits==[] and not amb and how=='automatic'

@pytest.mark.parametrize('word',['베이직','후드','니트','코트','셔츠','블라우스'])
def test_generic_words_never_contain_match(word):
    assert not product_within(ORDER,word)

def test_exact_same_name_still_matches():
    assert same_product('베이직','베이직')
    assert len(candidates(dict(product='베이직',option='블랙/FREE'),[src('베이직','블랙')],{})[0])==1

def test_specific_short_source_name_still_contains():
    assert product_within('[2color]루즈핏 베이직코트 롱','베이직코트')
    assert product_within('F7 [신상] 더블 카라 브이 반팔 니트','더블 카라 브이 반팔 니트')

def test_manual_rule_still_wins_over_generic_block():
    row=dict(product=ORDER,option='원컬러/FREE');v=src('베이직','灰色')
    from supply_workflow import order_signature
    hits,amb,how=candidates(row,[v],{order_signature(row):[v['variant']]})
    assert [h['variant'] for h in hits]==[v['variant']] and how=='manual'
