"""2026-10-25 18:00 요청: ① AI가 만든 파일 [열기][Finder에서 보기] (+ Codex 도구 open_file)
② 설정을 대화로 조회·변경 — 저장된 값 그대로 답하고, '자동회수 켜기' 같은 버튼을 눌러야 저장, 저장 후 다시 읽어 결과를 남긴다.
반품 자동조회와 자동 회수접수는 별개. 비밀번호·연락처는 돌려주지 않는다. (가짜 Codex · 가짜 컨트롤러, 실제 발송·변경 없음)"""
import json,sys,time,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import test_codex_tools as T
from codex_view import parts

class FakePickup:
    def __init__(self):self.cfg={'enabled':False,'sellers':{'에이블리':True,'자사몰':True,'지그재그':True}};self.saved=[]
    def config(self):return json.loads(json.dumps(self.cfg))
    def save(self,v):
        self.saved.append(v);self.cfg['enabled']=v['enabled']
        if v.get('sellers'):self.cfg['sellers'].update(v['sellers'])
        return {}
class Bridge(T.FakeBridge):
    def __init__(self):super().__init__();self.p=FakePickup();self.r.cfg.update(mode='daily',time='18:00')
    def _pickup_controller(self):return self.p

class SettingsFiles(T.Base):
    def setUp(self):
        super().setUp()
        self.opened=[];self.revealed=[]
        self.bridge=Bridge();self.tools.bridge=self.bridge
        self.s.open_path=lambda p:self.opened.append(Path(p));self.s.reveal_path=lambda p:self.revealed.append(Path(p))
        self.engine.store.data['settings']['smsPassword']='SECRET-PW';self.engine.creds={'SMS':object()}
    def card(self):return [m for m in self.s.status()['messages'] if m['role']=='proposal'][-1]
    def test_ask_answer_from_stored_values_and_separate_features(self):
        self.send();r,ok=self.tool('get_settings',{})
        k={x['key']:x for x in r['settings']}
        self.assertIs(k['auto_pickup']['current'],False);self.assertEqual(k['auto_pickup']['short'],'자동회수')
        self.assertIn('반품 매일 자동 조회(18:00) 뒤',k['auto_pickup']['when'])
        self.assertIs(k['return_check_daily']['current'],True);self.assertEqual(k['return_check_daily']['when'],'매일 18:00')
        self.assertNotEqual(k['auto_pickup']['label'],k['return_check_daily']['label'])
        text=json.dumps(r,ensure_ascii=False)
        self.assertNotIn('SECRET-PW',text);self.assertIn('문자(너나우리) 계정',text);self.assertIn('저장됨',text)
        self.assertTrue(any('비밀번호' in n['item'] or '로그인' in n['item'] for n in r['notSupported']))
        ins=self.s._instructions();self.assertIn('never guess',ins);self.assertIn('켜시겠어요',ins);self.assertIn('separate features',ins)
    def test_off_setting_gets_named_button_then_saved_and_reread(self):
        self.send()
        r,ok=self.tool('propose_action',{'action':'change_settings','settings':{'자동회수':'켜기'}});self.assertTrue(ok)
        self.assertEqual(self.bridge.p.saved,[])   # 카드만
        html=parts(self.s.status())['messages'];self.assertIn('>자동회수 켜기</button>',html);self.assertIn('꺼짐',html)
        c=self.card();self.s.handle('cxApplySettings',c['id'])
        self.assertTrue(self.bridge.p.saved[-1]['enabled'])
        c=self.card();self.assertIn('저장 후 다시 확인: 켜짐',c['result']);self.assertTrue(c['done'][0]['verified'])
        self.assertIn('앱에서 처리됨 · 설정 변경 · 자동회수: 꺼짐 → 켜짐',str(self.s.status()['messages']))
        r,ok=self.tool('recent_action_results',{});self.assertIn('다시 확인: 켜짐',r['results'][-1]['message'])
        # 이미 켜져 있으면 카드를 만들지 않는다
        r,ok=self.tool('propose_action',{'action':'change_settings','settings':{'auto_pickup':True}});self.assertFalse(ok);self.assertIn('이미 켜짐',r['error'])
    def test_off_and_time_requests(self):
        self.send()
        r,ok=self.tool('propose_action',{'action':'change_settings','settings':{'return_check_time':'오후 6시 30분'}});self.assertTrue(ok)
        html=parts(self.s.status())['messages'];self.assertIn('반품 자동조회 시각 18:30(으)로 변경',html);self.assertIn('지금 18:00',html)
        self.s.handle('cxApplySettings',self.card()['id']);self.assertEqual(self.bridge.r.saved[-1]['time'],'18:30')
        r,ok=self.tool('propose_action',{'action':'change_settings','settings':{'return_check_daily':'끄기'}})
        self.assertIn('반품 자동조회 끄기',parts(self.s.status())['messages'])
        r,ok=self.tool('propose_action',{'action':'change_settings','settings':{'smsPassword':'x'}});self.assertFalse(ok);self.assertIn('바꿀 수 없는',r['error'])
    def test_failed_save_is_reported_not_claimed(self):
        self.send()
        self.bridge.p.save=lambda v:(_ for _ in ()).throw(RuntimeError('이지어드민 로그인 정보를 먼저 저장하세요.'))
        self.tool('propose_action',{'action':'change_settings','settings':{'auto_pickup':True}})
        self.s.handle('cxApplySettings',self.card()['id'])
        c=self.card();self.assertIn('설정 변경 실패',c['result']);self.assertIn('로그인 정보',c['result'])
        self.assertIn('cx-warn',parts(self.s.status())['messages'])
    def test_ai_made_files_get_open_and_reveal(self):
        self.send()
        f=self.s.workspace.work/'안내문_정리.csv';f.write_text('상품,수량\n가디건,1\n',encoding='utf-8')
        self.s.client.event('turn/completed',{'threadId':self.s.chat['thread'],'turn':{'status':'completed'}});self.wait()
        line=[m for m in self.s.status()['messages'] if m['role']=='files'][-1];self.assertEqual(line['items'][0]['name'],'안내문_정리.csv')
        html=parts(self.s.status())['messages'];self.assertIn('Codex가 만든 파일',html);self.assertIn('cxOpenFile',html);self.assertIn('cxRevealFile',html)
        key=line['items'][0]['key']
        self.s.handle('cxOpenFile',{'key':key});self.assertEqual(self.opened[-1].name,'안내문_정리.csv')
        self.s.handle('cxRevealFile',{'key':key});self.assertEqual(self.revealed[-1].name,'안내문_정리.csv')
        r,ok=self.tool('open_file',{'file':'안내문_정리.csv','reveal':True});self.assertTrue(ok);self.assertEqual(len(self.revealed),2)
        r,ok=self.tool('open_file',{'file':'../../etc/passwd'});self.assertFalse(ok)
        # 같은 내용은 다시 알리지 않는다
        self.s.client.event('turn/completed',{'threadId':self.s.chat['thread'],'turn':{'status':'completed'}});self.wait()
        self.assertEqual(len([m for m in self.s.status()['messages'] if m['role']=='files']),1)
        # 별도 저장한 결과도 [열기][Finder에서 보기]
        sha=next(x for x in self.s.files if x['key']==key)['sha']
        self.s.export(key,sha);self.wait()
        saved=[m for m in self.s.status()['messages'] if m['role']=='files' and m.get('saved')][-1]
        eid=saved['items'][0]['export'];self.s.handle('cxRevealFile',{'export':eid})
        self.assertTrue(self.revealed[-1].is_relative_to((self.out/'r').resolve()) or self.revealed[-1].is_relative_to(self.out/'r'))
        with self.assertRaises(Exception):self.s.handle('cxOpenFile',{'export':'nope'})
        html=parts(self.s.status())['messages'];self.assertIn('결과 저장함',html)
        panel=parts(self.s.status())['files'];self.assertIn('cxRevealFile',panel)

if __name__=='__main__':unittest.main()
