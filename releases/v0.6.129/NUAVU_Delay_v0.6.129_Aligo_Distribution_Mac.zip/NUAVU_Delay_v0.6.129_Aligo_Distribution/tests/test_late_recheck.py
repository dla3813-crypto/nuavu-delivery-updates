"""2026-10-24: 1분 결과 미확인 뒤 재조회 간격 (10분·30분·1시간·3시간·6시간 → 12시간)."""
import sys,unittest
from pathlib import Path
from datetime import datetime,timedelta,timezone
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import domain
B=datetime(2026,10,24,0,0,28,tzinfo=timezone.utc)
iso=lambda t:t.isoformat(timespec='milliseconds')
class LateRecheck(unittest.TestCase):
    def nxt(self,checked):
        n={'acceptedAt':iso(B)};domain.defer_check(n,checked);return domain.parse_time(n['nextCheckAt'])
    def test_steps(self):
        self.assertEqual(self.nxt(B+timedelta(seconds=5)),B+timedelta(seconds=15))
        self.assertEqual(self.nxt(B+timedelta(seconds=20)),B+timedelta(minutes=1))
        self.assertEqual(self.nxt(B+timedelta(seconds=61)),B+timedelta(minutes=10))
        self.assertEqual(self.nxt(B+timedelta(minutes=10,seconds=1)),B+timedelta(minutes=30))
        self.assertEqual(self.nxt(B+timedelta(minutes=31)),B+timedelta(hours=1))
        self.assertEqual(self.nxt(B+timedelta(hours=1,seconds=2)),B+timedelta(hours=3))
        self.assertEqual(self.nxt(B+timedelta(hours=3,seconds=2)),B+timedelta(hours=6))
        late=B+timedelta(hours=6,seconds=2);self.assertEqual(self.nxt(late),late+timedelta(hours=12))
    def test_pull_in_old_12h(self):
        # 10/24 09:00 실제 사례: 09:01:29 조회 후 다음 조회 21:01:29 → 업데이트 후 바로(09:10 기준, 이미 지남) 다시 조회
        n={'kind':'AT','status':'UNKNOWN','attemptedAt':iso(B),'reportCheckedAt':iso(B+timedelta(seconds=61)),'nextCheckAt':iso(B+timedelta(seconds=61,hours=12))}
        clock=B+timedelta(hours=9,minutes=10)
        self.assertTrue(domain.pull_in_late_check(n,clock))
        self.assertEqual(domain.parse_time(n['nextCheckAt']),B+timedelta(minutes=10))
        self.assertLessEqual(domain.report_due(n),clock)
        self.assertFalse(domain.pull_in_late_check(n,clock))   # 다시 실행해도 그대로
    def test_untouched(self):
        for st in ('DELIVERED','FAILED','QUEUED','SCHEDULED'):
            n={'kind':'AT','status':st,'attemptedAt':iso(B),'nextCheckAt':iso(B+timedelta(hours=12))}
            self.assertFalse(domain.pull_in_late_check(n,B+timedelta(hours=1)));self.assertEqual(n['nextCheckAt'],iso(B+timedelta(hours=12)))
        n={'kind':'AT','status':'PENDING','attemptedAt':iso(B),'nextCheckAt':iso(B+timedelta(minutes=1))}
        self.assertFalse(domain.pull_in_late_check(n,B))   # 1분 확인 전 일정은 건드리지 않음
if __name__=='__main__':unittest.main()
