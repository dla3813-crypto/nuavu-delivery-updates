"""2026-10-26 17:46 요청: 배포판에도 너나우리 문자 경로 — 너나우리 ID·비밀번호가 저장돼 있으면 문자(SMS/LMS)는 너나우리로, 없으면 알리고 문자로.
누아브판 provider.py(너나우리 SOAP 어댑터)를 그대로 옮겨 왔다. 예외는 배포판 provider.py 의 ProviderError/UncertainError 를 공유한다.
No sample code or bytecode is executed. No automatic retry of sends, no TLS downgrade.
"""
from __future__ import annotations
import hashlib
import http.client
import re
import ssl
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from provider import ProviderError, UncertainError

SOAP = 'http://www.w3.org/2003/05/soap-envelope'
SEND = {
    'SMS': ('webservice.youiwe.co.kr', '/SMS.v.6/ServiceSMS.asmx', 'http://webservice.youiwe.co.kr/', 'smsID'),
    'LMS': ('lmsservice.youiwe.co.kr', '/lms.1/ServiceLMS.asmx', 'http://lmsservice.youiwe.co.kr/', 'lmsID'),
}
REPORT_NS = 'http://reportservice.youiwe.co.kr/'
ERRORS = {
    0:'발송 가능량 부족', -1:'문자 서비스 ID/비밀번호 확인', -2:'서비스 ID 누락',
    -3:'발송 요청 거절 (번호·발송제한 확인)', -4:'인증 해시 누락', -5:'인증 정보 불일치',
    -6:'수신번호 누락', -8:'발신번호 누락', -9:'전송내용 누락', -10:'날짜 형식 오류',
    -11:'시간 형식 오류', -12:'예약시간 또는 조회기간 오류', -13:'스팸 동의서 미접수',
    -14:'LMS 등 서비스 사용 신청 필요', -21:'서버/요청 데이터 오류', -23:'허용되지 않은 발송 IP',
    -25:'주간 총 발송량 초과', -26:'주간 URL 발송량 초과', -27:'발신·수신번호 동일',
    -28:'발송제한 키워드 포함', -30:'미등록 발신번호', -31:'잘못된 발신번호',
    -40:'스팸 발송 차단', -50:'잘못된 전화번호', -55:'구축발송 사용 신청 필요',
}
@dataclass(frozen=True)
class NunaCredential:
    user: str
    password: str


def envelope(method: str, namespace: str, fields: dict[str, str]) -> bytes:
    root = ET.Element(f'{{{SOAP}}}Envelope')
    body = ET.SubElement(root, f'{{{SOAP}}}Body')
    op = ET.SubElement(body, method, xmlns=namespace)
    for key, value in fields.items():
        ET.SubElement(op, key).text = str(value)
    return ET.tostring(root, encoding='utf-8', xml_declaration=True)

def digest(text: str) -> str:
    # MD5 is mandated by this legacy provider protocol, not used for local passwords.
    return hashlib.md5(text.encode('utf-8')).hexdigest()

def parse_xml(data: bytes | str) -> ET.Element:
    upper = data.upper() if isinstance(data, bytes) else data.upper().encode('utf-8')
    if b'<!DOCTYPE' in upper or b'<!ENTITY' in upper:
        raise UncertainError('허용되지 않은 XML 선언입니다. 결과를 수동 확인하세요.')
    try: return ET.fromstring(data)
    except (ET.ParseError, ValueError) as exc:
        raise UncertainError('응답 XML을 해석하지 못했습니다. 자동 재발송하지 않습니다.') from exc

def result_text(data: bytes, method: str) -> str:
    root = parse_xml(data)
    for e in root.iter():
        if e.tag.split('}')[-1] == 'Fault':
            raise UncertainError('SOAP 오류 응답입니다. 전송내역을 확인하세요.')
    for e in root.iter():
        if e.tag.split('}')[-1] == method + 'Result':
            return (e.text or '').strip()
    raise UncertainError('예상한 결과 항목이 없습니다. 전송내역을 확인하세요.')

def report_rows(text: str) -> list[dict[str,str]]:
    if re.fullmatch(r'-\d+', text):
        code=int(text)
        raise ProviderError(f'조회 오류 {code}: '+{-9:'조회 시작/종료 월이 다름',-10:'시작일 오류',-11:'종료일 오류',-12:'조회 가능 기간 초과'}.get(code,ERRORS.get(code,'공급사 확인 필요')),code)
    if not text: return []
    root = parse_xml(text)
    records=[]
    for e in root.iter():
        if e.tag.split('}')[-1].lower() == 'table':
            records.append({c.tag.split('}')[-1].lower():(c.text or '') for c in e})
    return records

def report_status(value: str | int | None, kind: str | None = None) -> str:
    """Interpret a *matched Nunauri delivery-report row*, never a send response.

    v0.6.5 adds only the observed LMS result 1000 (success in the LG U+ MMS
    result-code reference). Nunauri groups LMS/MMS in its U+ result guide.
    See docs/NUNAURI_RESULT_FIX.md for evidence and limits. A provider's API
    acceptance code 1 is still NOT delivery success; SMS/Aligo numeric results
    do not inherit this mapping. Unknown values remain PENDING.
    """
    if value is None or isinstance(value, bool):
        return 'PENDING'
    raw = str(value).strip()
    # No substring/float/leading-zero/coerced-code matching.
    if kind == 'LMS' and raw == '1000':
        return 'DELIVERED'
    val = re.sub(r'\s+', '', raw).casefold()
    if val in {'성공','전송성공','발송성공','수신성공','success','delivered'}: return 'DELIVERED'
    if val in {'실패','전송실패','발송실패','수신실패','failed','failure'}: return 'FAILED'
    return 'PENDING'

class Nunauri:
    def __init__(self, transport=None): self.transport=transport or self._post

    @staticmethod
    def _post(host: str, path: str, body: bytes, scheme: str) -> bytes:
        if scheme not in ('https','http'): raise ProviderError('연결 방식 오류')
        conn = (http.client.HTTPSConnection(host,timeout=20,context=ssl.create_default_context())
                if scheme=='https' else http.client.HTTPConnection(host,timeout=20))
        try:
            conn.request('POST',path,body,{'Content-Type':'application/soap+xml; charset=utf-8','Content-Length':str(len(body))})
            resp=conn.getresponse()
            data=resp.read(24*1024*1024+1)
            if len(data)>24*1024*1024: raise UncertainError('응답이 너무 큽니다. 공급사에서 결과를 확인하세요.')
            if resp.status != 200: raise UncertainError(f'HTTP {resp.status}: 처리 여부가 불명확하여 자동 재발송하지 않습니다.')
            return data
        except (OSError, http.client.HTTPException, ssl.SSLError) as exc:
            # Do not expose request bodies, authentication hashes, or credentials.
            raise UncertainError(f'연결 오류 ({type(exc).__name__}). HTTPS/발송 IP/네트워크 설정을 확인하세요. 자동 재발송하지 않습니다.') from exc
        finally: conn.close()

    def send(self, kind: str, cred: NunaCredential, sender: str, receiver: str, content: str, title: str, scheme='https') -> int:
        host,path,ns,idkey=SEND[kind]
        method='Send'+kind
        fields={idkey:cred.user,'hashValue':digest(cred.user+cred.password+receiver),'senderPhone':sender,'receivePhone':receiver}
        if kind=='LMS': fields['lmsTitle']=title
        fields['smsContent' if kind=='SMS' else 'lmsContent']=content
        value=result_text(self.transport(host,path,envelope(method,ns,fields),scheme),method)
        if not re.fullmatch(r'-?\d+',value): raise UncertainError('발송 응답이 정수가 아닙니다. 전송내역을 확인하세요.')
        code=int(value)
        if code<=0: raise ProviderError(f'{code}: {ERRORS.get(code,"공급사에서 확인할 발송 오류")}',code)
        if code!=1: raise UncertainError(f'단일 수신자 요청의 응답이 {code}입니다. 결과를 확인하세요.')
        return code

    def remaining(self, kind: str, cred: NunaCredential, scheme='https') -> str:
        host,path,ns,idkey=SEND[kind];method='GetRemainCount'
        fields={idkey:cred.user,'hashValue':digest(cred.user+cred.password)}
        value=result_text(self.transport(host,path,envelope(method,ns,fields),scheme),method)
        if re.fullmatch(r'-\d+',value): raise ProviderError(f'{value}: {ERRORS.get(int(value),"잔여량 조회 오류")}',int(value))
        if not re.fullmatch(r'\d+',value): raise ProviderError('잔여량 응답을 확인할 수 없습니다.')
        return value

    def report(self, kind: str, cred: NunaCredential, day: str, scheme='https') -> list[dict[str,str]]:
        # Query one KST calendar day at a time: the official service forbids cross-month ranges.
        if not re.fullmatch(r'\d{8}',day): raise ProviderError('조회 날짜 형식 오류')
        method='report'+kind
        fields={'smsID':cred.user,'hashvalue':digest(cred.user+cred.password),'firstdate':day,'seconddate':day,'mode':'0'}
        value=result_text(self.transport('reportservice.youiwe.co.kr',f'/report{kind}/ServiceReport{kind}.asmx',envelope(method,REPORT_NS,fields),scheme),method)
        return report_rows(value)
