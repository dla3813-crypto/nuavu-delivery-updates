#!/bin/bash
set -euo pipefail
# Install native wheels even when Terminal itself was opened through Rosetta.
if [ "$(/usr/sbin/sysctl -n hw.optional.arm64 2>/dev/null || true)" = 1 ] && [ "$(/usr/sbin/sysctl -n sysctl.proc_translated 2>/dev/null || true)" = 1 ]; then
  exec /usr/bin/arch -arm64 /bin/bash "$0" "$@"
fi
cd "$(dirname "$0")"
umask 077
source './python_locator.sh'
onerror() {
 local status=$?
 trap - ERR
 printf '\n설치가 완료되지 않았습니다. 위 오류를 확인하세요. 기존 주문·발송 이력은 삭제하지 마세요.\n'
 nuavu_pause
 exit "$status"
}
trap onerror ERR
if [ "$(uname -s)" != Darwin ]; then echo 'macOS에서 실행하는 설치 파일입니다.'; exit 1; fi
echo '배송안내 v0.6.45 배포판 — 에이블리 동기화 · 주문 엑셀 자동 불러오기'
echo '기존 배송안내 배포판은 먼저 종료하세요. 주문/문자 이력은 삭제하지 않습니다.'
echo '설치된 Python을 찾고 버전과 경로를 표시합니다. Python 재설치 사이트는 열지 않습니다.'
if ! nuavu_find_python; then nuavu_pause; exit 1; fi
PY="$NUAVU_PY"
# Check only the process lock; do not open or migrate the order database here.
"$PY" -I - <<'CHECK_LOCK'
import fcntl,sys
from pathlib import Path
p=Path.home()/'Library/Application Support/NUAVU Delay Distribution/running.lock'
if p.exists():
 with p.open('a+') as f:
  try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:sys.exit('배송안내 배포판이 실행 중입니다. 기존 터미널에서 Control + C 또는 앱을 종료한 뒤 설치하세요.')
CHECK_LOCK
VENV="$HOME/Library/Application Support/NUAVU Delay Distribution/desktop-runtime-v05"
if [ -e "$VENV" ]; then
 if ! "$VENV/bin/python3" -I -c 'import sys,ssl,sqlite3,venv,platform,subprocess; assert (3,11)<=sys.version_info[:2]<=(3,15); arm=subprocess.run(["/usr/sbin/sysctl","-n","hw.optional.arm64"],capture_output=True,text=True).stdout.strip()=="1"; assert not arm or platform.machine()=="arm64"' >/dev/null 2>&1; then
   # Preserve an incomplete/incompatible runtime instead of deleting it.
   VENV="$HOME/Library/Application Support/NUAVU Delay Distribution/desktop-runtime-v051-$(date +%Y%m%d%H%M%S)-$$"
   echo '기존 실행환경은 보존하고 새로운 앱 전용 실행환경을 만듭니다.'
 fi
fi
if [ ! -x "$VENV/bin/python3" ]; then "$PY" -I -m venv "$VENV"; fi
echo '앱 창 구성요소와 HTTPS 인증서 묶음을 설치/확인합니다. 인터넷 연결이 필요합니다.'
"$VENV/bin/python3" -I -m pip install --disable-pip-version-check \
 --only-binary=pyobjc-core,pyobjc-framework-Cocoa,pyobjc-framework-Quartz,pyobjc-framework-WebKit,pyobjc-framework-Security,pyobjc-framework-UniformTypeIdentifiers \
 'pywebview==6.2.1' 'playwright==1.64.0' certifi
"$VENV/bin/python3" -I -c 'import webview, objc, AppKit, WebKit, Security, certifi, ssl, playwright.sync_api; ctx=ssl.create_default_context(); ctx.load_verify_locations(cafile=certifi.where()); assert ctx.check_hostname and ctx.verify_mode==ssl.CERT_REQUIRED; print("앱 구성요소·인증서 확인 완료")'
"$VENV/bin/python3" install_desktop.py --python "$VENV/bin/python3"
APP="$HOME/Applications/배송안내 배포판.app"
/usr/bin/open -R "$APP"
/usr/bin/open "$APP"
echo '';echo '설치 완료. 앞으로는 배송안내 배포판.app을 더블클릭하세요.'
echo '독립 앱이 열린 뒤 이 설치 터미널은 닫아도 됩니다. 앱 종료 시 예약·조회도 멈춥니다.'
