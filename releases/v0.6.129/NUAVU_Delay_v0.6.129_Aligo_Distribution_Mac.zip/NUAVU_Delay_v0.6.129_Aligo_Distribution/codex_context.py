"""배송안내 배포판 · Codex에 건네는 앱 요약 (2026-10-24 · 배포판 2026-10-25: 쇼핑몰 이름·판매처 표시 일반화).

필요한 것만: 앱 이름·버전, 오늘 날짜, 현재 목록 규모(숫자만), 안내문 작성 규칙·기본 문구, 날짜·열의 뜻.
고객 이름·연락처·주소·주문 전체 DB·계정·로그는 넣지 않는다.
"""
from __future__ import annotations
from datetime import datetime,timedelta,timezone

KST=timezone(timedelta(hours=9))

def shop_name(engine):
    try:return str((engine.store.read().get('settings') or {}).get('shopName') or '').strip()
    except Exception:return ''

def seller_label(v):
    # 앱 내부 판매처 키('누아브 에이블리' 등)는 화면 이름으로만 보여 준다.
    return str(v or '').replace('누아브 ','')

def build(engine=None,version=''):
    now=datetime.now(KST);shop=shop_name(engine) if engine is not None else ''
    lines=[f'# 배송안내 배포판 앱 요약 (v{version}) · {now:%Y-%m-%d %H:%M} 한국 시간'+(f' · 쇼핑몰 {shop}' if shop else ''),'',
           '## 이 앱이 하는 일',
           '- 판매처(에이블리·아무드·자사몰·지그재그 중 쇼핑몰이 쓰는 곳) 미출고 주문을 모아 출고 예정일을 계산하고, 배송지연·품절 안내를 문자/알림톡으로 보낸다.',
           '- 실제 발송·주문 변경·고객 상태 변경은 앱의 기존 검토·발송 화면에서만 한다. 이 대화(Codex)는 질문·안내문 초안·첨부 파일 수정만 한다.','']
    try:
        if engine is not None:
            s=engine.store.read();rows=s.get('rows',[]);active=[r for r in rows if r.get('active',True)]
            sellers={}
            for r in active:sellers[seller_label(r.get('seller','?'))]=sellers.get(seller_label(r.get('seller','?')),0)+1
            sent=sum(1 for n in s.get('notices',[]) if not n.get('isTest') and str(n.get('attemptedAt','')).startswith(now.strftime('%Y-%m-%d')))
            lines+=['## 현재 목록 (숫자만)',f'- 미출고 주문상품 {len(active):,}개 (전체 행 {len(rows):,})']+[f'- {k}: {v:,}개' for k,v in sorted(sellers.items())]+[f'- 오늘 요청한 안내 {sent:,}건','']
    except Exception:lines+=['## 현재 목록','- (요약을 읽지 못했습니다)','']
    try:
        waves=dispatch_waves(engine) if engine is not None else []
        if waves:
            lines+=['## 출고장(중국 출고분)별 출고 예상일 (앱 계산 · 출고 예상일 변경 단위)']
            for w in waves[:20]:
                lines.append(f"- 중국 출고 {w['chinaDate']} · {'·'.join(w.get('kinds') or [])} · 주문상품 {w.get('items',0)}개 · 출고 예상 {w.get('koreaStart','')}~{w.get('koreaEnd','')}"+(' · 사장님 직접 지정' if w.get('override') else ''))
            lines.append('')
    except Exception:pass
    try:
        from domain import FIRST,CHANGE,SOLDOUT_CARD,SOLDOUT_BANK
        lines+=['## 기본 안내문 (변수: {쇼핑몰명}, {상품목록}, {출고예정일})','### 첫 배송지연 안내',FIRST,'','### 출고 일정 변경 안내',CHANGE,'','### 품절 안내 (카드 결제)',SOLDOUT_CARD,'','### 품절 안내 (무통장)',SOLDOUT_BANK,'']
    except Exception:pass
    lines+=['## 안내문 작성 규칙',
            f'- 말투: "안녕하세요 고객님 / {shop or "{쇼핑몰명}"}입니다."로 시작하는 정중한 존댓말. 과장·약속 남발 금지. 쇼핑몰 이름은 설정의 이름({{쇼핑몰명}})을 그대로 쓴다.',
            '- 문자: 단문(SMS) 80바이트, 장문(LMS) 2,000바이트 이내. 알림톡은 승인된 템플릿 본문과 글자 그대로 같아야 발송된다 (템플릿을 바꾸면 카카오 재승인 필요).',
            '- 반품·교환 수동 메시지는 900자 이내.',
            '## 날짜·열의 뜻',
            '- 출고 예정일(dueDate): 고객에게 안내한 출고 예정일. 판매처 화면의 예상출고일과 같게 맞춘다.',
            '- 출고 예상일(출고예상_시작~끝): 앱이 출고장·진행상황·현재고로 계산한 실제 출고 예상일. 고객 안내와 별개. 사장님이 출고장(중국 출고일) 단위로 직접 바꿀 수 있다 (change_dispatch).',
            '- 주말·공휴일은 영업일이 아니다. 당일 출고 마감 시각은 쇼핑몰마다 다르니 사장님 말을 따른다.',
            '- 지그재그 배송연기: 발송 예정일 = 결제일 + 3영업일, 선택 가능 날짜 = 그 다음 영업일 ~ +7영업일.',
            '- 엑셀의 주문번호·상품주문번호는 숫자처럼 보여도 문자열로 다루고, 앞자리 0·자릿수를 바꾸지 않는다.']
    return '\n'.join(lines)

def notice_text(engine,limit=30):
    """'안내문' 자료: 앱 기본 문구 + 최근 실제 요청한 안내 본문 (연락처·이름·주문번호 제외)."""
    lines=['# 배송안내 배포판 · 최근 안내문','']   # 내용이 같으면 같은 회차로 (시각을 넣지 않음)
    try:
        from domain import FIRST,CHANGE,SOLDOUT_CARD,SOLDOUT_BANK
        lines+=['## 앱 기본 문구 (변수 {상품목록}, {출고예정일})','### 첫 배송지연 안내',FIRST,'','### 출고 일정 변경 안내',CHANGE,'','### 품절 안내 (카드)',SOLDOUT_CARD,'','### 품절 안내 (무통장)',SOLDOUT_BANK,'']
    except Exception:pass
    sent=[]
    try:
        s=engine.store.read()
        sent=[n for n in s.get('notices',[]) if not n.get('isTest') and n.get('content') and n.get('attemptedAt') and n.get('status')!='IMPORTED']
        sent=sorted(sent,key=lambda n:str(n.get('attemptedAt')),reverse=True)[:limit]
    except Exception:sent=[]
    names={'delay':'배송지연','manual':'수동 작성','soldout_card':'품절·카드','soldout_bank':'품절·무통장','return_overdue':'반품 기한 초과','return_not_defect':'불량 아님','return_manual':'반품/교환 수동'}
    lines.append(f'## 최근 실제 요청한 안내 {len(sent)}건 (최신순 · 연락처·고객명·주문번호 제외)')
    for i,n in enumerate(sent,1):
        lines+=['',f"### {i}. {str(n.get('attemptedAt',''))[:16].replace('T',' ')} · {names.get(n.get('noticeType') or 'delay',n.get('noticeType'))} · {n.get('channel') or n.get('kind','')} · 상태 {n.get('status','')}"+(f" · 예정일 {n['dueDate']}" if n.get('dueDate') else ''),str(n.get('content',''))]
    return '\n'.join(lines)

def _waves(r):
    """이 주문상품에 배정된 출고장·진행상황 물량의 중국 출고일 (출고 예상일 변경 단위)."""
    return sorted({(p.get('path') or {}).get('chinaDate') for p in (r.get('supplyInfo') or {}).get('parts',[]) if p.get('kind')!='inventory' and (p.get('path') or {}).get('chinaDate')})

def dispatch_waves(engine):
    try:return (engine.public_state().get('supply') or {}).get('dispatchWaves') or []
    except Exception:return []

def order_list(engine):
    """'현재 주문 목록' 자료: 앱이 지금 보고 있는 미출고 주문상품 (연락처·고객명 제외). 행키로 앱 화면에서 같은 상품을 선택한다."""
    import csv,io
    s=engine.public_state();rows=[r for r in s.get('rows',[]) if r.get('active')]
    out=io.StringIO();w=csv.writer(out)
    w.writerow(['행키','판매처','주문일','주문번호','상품명','옵션','수량','분류','안내한출고예정일','안내횟수','출고예상_시작','출고예상_끝','출고장수량확보','현재고배정','합포','중국출고일','출고예상_직접지정'])
    color={'white':'안내 전','green':'예정일 이내','confirmed':'예정일 이내(확정)','yellow':'예정일 당일','red':'예정일 초과','failed':'발송실패','charcoal':'품절 안내','scheduled':'예약발송대기'}
    for r in rows:
        w.writerow([r.get('key',''),seller_label(r.get('seller','')),r.get('orderDate',''),r.get('orderId',''),r.get('product',''),r.get('option',''),r.get('qty',''),
                    color.get(r.get('color'),r.get('color') or ''),r.get('dueDate') or '',r.get('noticeCount',''),r.get('dispatchStart') or '',r.get('dispatchEnd') or '',
                    'Y' if r.get('stockSecured') else '','Y' if r.get('inventoryReady') else '','Y' if r.get('isBundle') else '',
                    ' '.join(_waves(r)),'Y' if any((p.get('path') or {}).get('dispatchOverride') for p in (r.get('supplyInfo') or {}).get('parts',[])) else ''])
    return out.getvalue()

def validate_action(engine,p):
    """Codex 제안 확인용 (실행 아님): 지금 목록에 있는 행만 남기고, 미리보기 몇 줄과 주의 문구를 만든다."""
    if p.get('action')=='change_dispatch':
        waves={w['chinaDate']:w for w in dispatch_waves(engine)}
        asked=list(dict.fromkeys(p.get('chinaDates') or []))
        if not asked and p.get('rowKeys'):   # 행키만 준 경우: 그 상품들이 배정된 출고장
            try:rows={r['key']:r for r in engine.public_state()['rows'] if r.get('active')}
            except Exception:rows={}
            asked=list(dict.fromkeys(c for k in p['rowKeys'] if k in rows for c in _waves(rows[k])))
        if not asked and p.get('fromDates'):   # 지금 출고 예상일(예: 10/28~10/29)로 지목한 경우
            frm=set(p['fromDates']);asked=[c for c,w in waves.items() if w.get('koreaStart') in frm or w.get('koreaEnd') in frm]
        keep=[c for c in asked if c in waves]
        md=lambda v:f"{int(v[5:7])}/{int(v[8:10])}" if v else '?'
        samples=[f"{md(c)} 중국 출고분 ({'·'.join(waves[c].get('kinds') or [])}) · 주문상품 {waves[c].get('items',0)}개 · 지금 출고 예상 {md(waves[c].get('koreaStart'))}~{md(waves[c].get('koreaEnd'))}" for c in keep]
        warnings=[]
        start=str(p.get('dispatchStart') or '')
        if start and start<datetime.now(KST).date().isoformat():warnings.append('새 출고 예상일이 오늘보다 이전입니다.')
        if any(start and start<c for c in keep):warnings.append('새 출고 예상일이 중국 출고일보다 빠릅니다. 앱에서 적용되지 않습니다.')
        return {'chinaDates':keep,'samples':samples,'unmatched':len(set(asked))-len(keep),'warnings':warnings,'count':sum(waves[c].get('items',0) for c in keep)}
    s=engine.store.read();rows={r['key']:r for r in s.get('rows',[]) if r.get('active')}
    keys=[k for k in dict.fromkeys(p.get('keys') or []) if k in rows]
    samples=[f"{seller_label(rows[k].get('seller',''))} · {rows[k].get('product','')} · {rows[k].get('option','')}" for k in keys[:6]]
    warnings=[]
    if p.get('action')=='no_send_notice' and any(rows[k].get('seller')=='누아브 자사몰' for k in keys):
        warnings.append('자사몰 주문이 섞여 있습니다. 앱 규칙상 메시지 없는 안내에서는 자사몰을 빼야 합니다.')
    due=str(p.get('dueDate') or '')
    if due and due<datetime.now(KST).date().isoformat():warnings.append('출고 예정일이 오늘보다 이전입니다.')
    return {'keys':keys,'samples':samples,'unmatched':len(set(p.get('keys') or []))-len(keys),'warnings':warnings}
