#!/bin/bash
# Shared interpreter discovery. Compatible with macOS /bin/bash 3.2.
# Does not install Python, open websites, read order data, or modify shell settings.

nuavu_pause() {
  if [ -t 0 ]; then
    read -r -p '엔터를 누르면 이 창을 닫습니다. ' _nuavu_reply || true
  fi
  return 0
}

NUAVU_PROBE_CODE='
import sys
v = sys.version_info
version = ".".join(map(str, v[:3]))
if sys.implementation.name != "cpython":
    sys.exit("제외: CPython이 아닌 실행기입니다 (" + sys.implementation.name + ").")
if not ((3, 11) <= v[:2] <= (3, 15)):
    sys.exit("제외: Python " + version + " (이 설치기의 확인 범위는 3.11~3.15입니다).")
if v[3] != "final":
    sys.exit("제외: Python " + version + " 개발/시험 버전입니다.")
try:
    import os, platform, ssl, sqlite3, venv, fcntl
except ImportError as exc:
    sys.exit("제외: Python " + version + " 필수 구성요소를 읽지 못했습니다: " + str(exc))
executable = os.path.abspath(sys.executable)
if any(c in executable for c in ("\n", "\r", "\t")):
    sys.exit("제외: 실행 경로에 지원하지 않는 제어 문자가 있습니다.")
print("Python " + version + " / " + platform.machine())
print("NUAVU_EXECUTABLE=" + executable)
'

nuavu_try_python() {
  local candidate="$1" output rc line
  local -a invocation
  invocation=("$candidate")
  if [ "$(/usr/sbin/sysctl -n hw.optional.arm64 2>/dev/null || true)" = 1 ]; then
    invocation=(/usr/bin/arch -arm64 "$candidate")
  fi
  [ -x "$candidate" ] && [ ! -d "$candidate" ] || return 1
  # Never invoke Apple's developer-tools stub without an existing toolchain.
  if [ "$candidate" = /usr/bin/python3 ]; then
    if ! /usr/bin/xcode-select -p >/dev/null 2>&1; then
      printf '건너뜀: %s (Apple 개발도구용 경로)\n' "$candidate" >&2
      return 1
    fi
  fi
  printf '확인 경로: %s\n' "$candidate" >&2
  if output="$("${invocation[@]}" -I -c "$NUAVU_PROBE_CODE" 2>&1)"; then
    NUAVU_PY=''
    while IFS= read -r line; do
      case "$line" in
        NUAVU_EXECUTABLE=*) NUAVU_PY="${line#NUAVU_EXECUTABLE=}" ;;
        *) printf '  %s\n' "$line" >&2 ;;
      esac
    done <<< "$output"
    if [ -n "$NUAVU_PY" ] && [ -x "$NUAVU_PY" ]; then
      return 0
    fi
    printf '  실제 Python 실행 경로를 확인하지 못했습니다.\n' >&2
  else
    rc=$?
    printf '  %s\n' "$output" >&2
    printf '  실행 결과 코드: %s\n' "$rc" >&2
  fi
  NUAVU_PY=''
  return 1
}

nuavu_find_python() {
  local name found p seen
  local -a candidates
  NUAVU_PY=''
  # Explicit arguments allow a known interpreter and local fixture-based tests.
  if [ "$#" -gt 0 ]; then
    candidates=("$@")
  elif [ -n "${NUAVU_PYTHON:-}" ]; then
    candidates=("$NUAVU_PYTHON")
  else
    # A sentinel keeps empty arrays safe under Bash 3.2 with nounset enabled.
    candidates=("" "$HOME/Library/Application Support/NUAVU Delay Distribution/desktop-runtime-v05/bin/python3")
    for name in python3 python3.15 python3.14 python3.13 python3.12 python3.11; do
      found="$(type -P "$name" 2>/dev/null || true)"
      [ -z "$found" ] || candidates+=("$found")
    done
    candidates+=(/opt/homebrew/bin/python3 /usr/local/bin/python3
      /Library/Frameworks/Python.framework/Versions/Current/bin/python3
      "$HOME/.local/bin/python3" "$HOME/.pyenv/shims/python3"
      "$HOME/.asdf/shims/python3" /opt/local/bin/python3)
    for p in \
      /Library/Frameworks/Python.framework/Versions/*/bin/python3 \
      "$HOME"/Library/Frameworks/Python.framework/Versions/*/bin/python3 \
      /opt/homebrew/bin/python3.* /usr/local/bin/python3.* \
      /opt/homebrew/opt/python@3.*/bin/python3.* /usr/local/opt/python@3.*/bin/python3.* \
      /opt/local/bin/python3.* \
      "$HOME"/.pyenv/versions/*/bin/python3 \
      "$HOME"/.asdf/installs/python/*/bin/python3 \
      "$HOME"/.local/share/uv/python/cpython-3.*/bin/python3 \
      "$HOME"/miniconda3/bin/python3 "$HOME"/miniforge3/bin/python3 \
      "$HOME"/anaconda3/bin/python3 /opt/anaconda3/bin/python3 /opt/miniconda3/bin/python3; do
      # Only interpreter names, not executable *-config helper scripts.
      case "$p" in *-config|*.exe) continue ;; esac
      candidates+=("$p")
    done
  fi
  seen=$'\n'
  for p in "${candidates[@]}"; do
    [ -n "$p" ] || continue
    case "$seen" in *$'\n'"$p"$'\n'*) continue ;; esac
    seen="$seen$p"$'\n'
    if nuavu_try_python "$p"; then
      printf '선택한 Python: %s\n' "$NUAVU_PY" >&2
      return 0
    fi
  done
  printf '\n지원 가능한 Python을 자동으로 찾지 못했습니다. 미설치라고 단정한 것은 아닙니다.\n' >&2
  printf '위 경로·버전·오류를 확인하세요. 파이썬확인.command로 같은 검사를 다시 할 수 있습니다.\n' >&2
  printf 'Python 사이트를 자동으로 열거나 기존 Python을 삭제하지 않습니다.\n' >&2
  return 1
}
