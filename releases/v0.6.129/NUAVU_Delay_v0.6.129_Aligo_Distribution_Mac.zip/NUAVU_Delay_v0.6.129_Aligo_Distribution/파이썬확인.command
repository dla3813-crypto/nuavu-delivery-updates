#!/bin/bash
set -uo pipefail
cd "$(dirname "$0")"
source './python_locator.sh'
echo 'NUAVU Python 경로·버전 확인 (설치·발송·데이터 변경 없음)'
if nuavu_find_python; then
  echo ''
  echo 'Python을 찾았습니다. 같은 폴더의 처음한번_앱설치.command를 실행하세요.'
  result=0
else
  echo ''
  echo '이 터미널 화면을 보내주면 다음 원인을 확인할 수 있습니다.'
  result=1
fi
nuavu_pause
exit "$result"
