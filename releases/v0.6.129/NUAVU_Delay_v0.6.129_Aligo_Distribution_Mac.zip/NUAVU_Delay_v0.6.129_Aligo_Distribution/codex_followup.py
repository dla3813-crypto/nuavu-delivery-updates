"""2026-10-26 16:08 요청: AI 대화 '예약 확인' — "내일 오후 6시에 얘네 4명 우체국 회수 정상 진행되는지 확인해서 답변줘"
→ 그 시각에 같은 대화에 질문을 자동으로 보내고, Codex가 앱 도구로 확인한 답을 그 대화에 남긴다.

규칙
· 한 번만 실행(one-shot). 되풀이 예약은 아직 없음.
· 실행 조건: 앱이 켜져 있고 Codex(ChatGPT 구독) 연결이 되어 있어야 한다. 안 되면 '실패'로 남기고 앱 알림(문제 등급 → 아이폰 알림 대상).
· 예약 실행은 질문을 보내는 것뿐. 문자 발송·설정 변경은 평소처럼 확인 카드만 만들고 사장님이 누른다.
· 정상 답변은 조용히 대화에 쌓인다 (앱 '작업완료' 배너만, 아이폰 알림 없음).
"""
import datetime,re,threading,uuid

WEEKDAY='월화수목금토일'
MAX_DAYS=60
_STATUS={'pending':'대기 중','running':'실행 중','done':'답변 완료','failed':'실패','cancelled':'취소됨'}

class FollowupError(ValueError):pass

def parse_when(value,now=None):
    """'2026-10-27T18:00' · '2026-10-27 18:00' · '2026-10-27T18:00:00' → 'YYYY-MM-DDTHH:MM' (한국 시간·맥 로컬). 과거·60일 초과는 거부."""
    now=now or datetime.datetime.now()
    m=re.fullmatch(r'\s*(\d{4})-(\d{2})-(\d{2})[T ](\d{1,2}):(\d{2})(?::\d{2})?\s*',str(value or ''))
    if not m:raise FollowupError('실행 시각은 YYYY-MM-DDTHH:MM (예: 2026-10-27T18:00, 한국 시간) 으로 주세요.')
    try:t=datetime.datetime(int(m[1]),int(m[2]),int(m[3]),int(m[4]),int(m[5]))
    except ValueError:raise FollowupError('실행 시각이 달력에 없는 날짜·시각입니다.')
    if t<now-datetime.timedelta(minutes=1):raise FollowupError(f'이미 지난 시각입니다 (지금 {now.strftime("%Y-%m-%d %H:%M")}).')
    if t>now+datetime.timedelta(days=MAX_DAYS):raise FollowupError(f'{MAX_DAYS}일 이내로만 예약할 수 있습니다.')
    return t.strftime('%Y-%m-%dT%H:%M')

def label(run_at):
    try:t=datetime.datetime.strptime(run_at,'%Y-%m-%dT%H:%M');return f'{t.month}/{t.day}({WEEKDAY[t.weekday()]}) {t:%H:%M}'
    except Exception:return str(run_at)

def status_text(f):return _STATUS.get(f.get('status',''),f.get('status',''))

class FollowupMixin:
    """CodexChatService 에 섞어 쓴다. saved['followups'] 에 저장, 대화에는 role='followup' 카드."""
    followup_interval=20   # 초 · 테스트에서 줄인다

    def _followup_init(self):
        self.saved.setdefault('followups',[])
        self.followup_active=None;self._fu_stop=threading.Event();self._fu_thread=None
        changed=False
        for f in self.saved['followups']:   # 앱이 꺼진 사이 '실행 중'이던 것은 끊긴 것 → 실패
            if f.get('status')=='running':f['status']='failed';f['note']='앱이 다시 시작되어 실행이 끊겼습니다. 다시 예약해 주세요.';f['doneAt']=self.now();changed=True;self._followup_card(f)
        if changed:self.save()
        self._followup_start()
    def _followup_start(self):
        if self._fu_thread is None or not self._fu_thread.is_alive():
            self._fu_thread=threading.Thread(target=self._followup_loop,daemon=True,name='nuavu-codex-followup');self._fu_thread.start()
    def _followup_loop(self):
        while not self._fu_stop.wait(self.followup_interval):
            try:self.followup_tick()
            except Exception:pass
    def _followup_stop(self):
        try:self._fu_stop.set()
        except Exception:pass

    # ---------- 조회·등록·취소 ----------
    def followups(self,session=None,all_sessions=False):
        with self.lock:
            sid=session or self.chat['id']
            return [dict(f) for f in self.saved['followups'] if all_sessions or f['session']==sid]
    def schedule_followup(self,run_at,prompt,session=None,now=None):
        prompt=str(prompt or '').strip()
        if not prompt or len(prompt)>2000:raise FollowupError('그때 보낼 질문을 1~2,000자로 적어 주세요.')
        run_at=parse_when(run_at,now)
        with self.lock:
            sid=session or self.chat['id']
            pending=[f for f in self.saved['followups'] if f['status']=='pending']
            if len(pending)>=30:raise FollowupError('대기 중인 예약이 30개입니다. 먼저 정리해 주세요.')
            if any(f['session']==sid and f['runAt']==run_at and f['prompt']==prompt for f in pending):raise FollowupError('같은 시각·같은 질문이 이미 예약돼 있습니다.')
            f={'id':uuid.uuid4().hex,'session':sid,'runAt':run_at,'prompt':prompt,'status':'pending','createdAt':self.now(),'note':'','startedAt':'','doneAt':''}
            self.saved['followups'].append(f);self.save()
            self._followup_card(f);self._bump()
        return dict(f)
    def cancel_followup(self,fid):
        with self.lock:
            f=next((x for x in self.saved['followups'] if x['id']==str(fid)),None)
            if not f:raise FollowupError('그 예약을 찾지 못했습니다.')
            if f['status']!='pending':raise FollowupError(f"이미 {status_text(f)} 상태라 취소할 수 없습니다.")
            f['status']='cancelled';f['doneAt']=self.now();self.save();self._followup_card(f);self._bump()
        return dict(f)

    # ---------- 대화 카드 ----------
    def _edit_session_chat(self,sid,fn):
        """해당 대화의 chat.json 을 고친다 (지금 열린 대화면 메모리, 아니면 파일)."""
        import json
        if sid==self.chat['id']:fn(self.chat);self.save_chat();return
        p=self.root/'sessions'/sid/'chat.json'
        try:chat=json.loads(p.read_text(encoding='utf-8'))
        except (OSError,ValueError):return
        fn(chat)
        from codex_files import atomic_json
        atomic_json(p,chat)
    def _followup_card(self,f):
        def fn(chat):
            card=next((m for m in chat['messages'] if m.get('role')=='followup' and m.get('followup')==f['id']),None)
            body={'runAt':f['runAt'],'prompt':f['prompt'],'status':f['status'],'note':f.get('note',''),'doneAt':f.get('doneAt','')}
            if card:card.update(body)
            else:chat['messages'].append({'id':uuid.uuid4().hex,'role':'followup','followup':f['id'],'at':self.now(),'text':'',**body})
        try:self._edit_session_chat(f['session'],fn)
        except Exception:pass

    # ---------- 실행 ----------
    def followup_tick(self,now=None):
        """due 된 예약 하나를 실행한다 (한 번에 하나). 바쁘면 다음 tick."""
        now=now or datetime.datetime.now();stamp=now.strftime('%Y-%m-%dT%H:%M')
        with self.lock:
            if self.running or self.op or self.followup_active:return None
            due=sorted([f for f in self.saved['followups'] if f['status']=='pending' and f['runAt']<=stamp],key=lambda f:f['runAt'])
            if not due:return None
            f=due[0]
            if f['session'] not in [s['id'] for s in self.visible_sessions()]:
                f['status']='failed';f['note']='예약한 대화가 삭제돼 실행하지 않았습니다.';f['doneAt']=self.now();self.save();self._followup_card(f);return f['id']
            try:
                if f['session']!=self.chat['id']:
                    self._load_session(f['session']);self.saved['current']=f['session']
            except Exception as exc:
                f['status']='failed';f['note']='대화를 열지 못했습니다: '+str(exc)[:200];f['doneAt']=self.now();self.save();self._followup_card(f);self._followup_alert(f);return f['id']
            late=now-datetime.datetime.strptime(f['runAt'],'%Y-%m-%dT%H:%M')
            f['status']='running';f['startedAt']=self.now();self.save();self._followup_card(f);self.followup_active=f['id']
            self.result_picker=None;self.result_question=None;self.result_auto=[]
            text=f"⏰ 예약 확인 ({label(f['runAt'])}{' · 지연 실행' if late>datetime.timedelta(minutes=10) else ''}) · {f['prompt']}"
        try:self._submit(lambda:self._send(text,resolve_results=False),'예약한 확인을 보내는 중…')
        except Exception as exc:self._followup_end('failed',str(exc)[:300])
        return f['id']
    def _followup_end(self,status,note=''):
        """답변 완료·중단·실패 시 호출 (_finish 와 작업 큐 예외에서)."""
        with self.lock:
            fid=self.followup_active
            if not fid:return
            self.followup_active=None
            f=next((x for x in self.saved['followups'] if x['id']==fid),None)
            if not f:return
            f['status']='done' if status=='completed' else 'failed'
            f['note']={'completed':'','interrupted':'사장님이 중지했습니다.'}.get(status,note or '실행하지 못했습니다.')
            f['doneAt']=self.now();self.save();self._followup_card(f)
        if f['status']=='done':self._followup_alert(f,ok=True)
        else:self._followup_alert(f)
    def _followup_alert(self,f,ok=False):
        fn=getattr(self,'job_alert',None)
        if not fn:return
        try:
            if ok:fn('AI 예약 확인 답변',f"{label(f['runAt'])} 예약한 확인의 답변이 AI 대화에 도착했습니다: {f['prompt'][:60]}",'info')
            else:fn('AI 예약 확인 실패',f"{label(f['runAt'])} 예약한 확인을 실행하지 못했습니다 ({f.get('note','')[:120]}). AI 대화에서 다시 예약해 주세요.",'error')
        except Exception:pass
