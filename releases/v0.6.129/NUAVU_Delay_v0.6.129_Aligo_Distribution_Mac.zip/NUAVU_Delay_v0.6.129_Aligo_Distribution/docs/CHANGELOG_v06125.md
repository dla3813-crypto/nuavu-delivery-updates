# NUAVU_Delay_v0.6.125_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06124.md

- 수정: 직접 입력 번호 카드가 있는 대화에서 AI 대화창 제목줄 버튼이 사라지던 오류.
