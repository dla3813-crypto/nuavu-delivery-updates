# NUAVU_Delay_v0.6.121_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06120.md

- 자동 매칭 오류 수정: 한 단어 일반명사 상품명(베이직·후드·니트 등)이 포함 규칙으로 엉뚱한 주문에 붙던 문제.
