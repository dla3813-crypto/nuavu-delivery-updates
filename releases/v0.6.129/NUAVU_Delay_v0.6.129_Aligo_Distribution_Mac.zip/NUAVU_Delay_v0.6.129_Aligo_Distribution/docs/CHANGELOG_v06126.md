# NUAVU_Delay_v0.6.126_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06125.md

- AI 카드 열기 실패 시 이유를 대화에 기록, 목록 재조회 후 재시도.
