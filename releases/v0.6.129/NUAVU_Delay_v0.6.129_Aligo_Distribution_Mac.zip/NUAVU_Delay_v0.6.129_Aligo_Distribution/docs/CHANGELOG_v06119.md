# NUAVU_Delay_v0.6.119_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06118.md

- AI 대화창을 열 때 항상 마지막 메시지로 스크롤.
