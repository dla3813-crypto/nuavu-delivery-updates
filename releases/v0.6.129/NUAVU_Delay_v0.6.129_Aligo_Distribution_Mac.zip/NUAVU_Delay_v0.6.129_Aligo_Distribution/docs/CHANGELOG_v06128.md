# NUAVU_Delay_v0.6.128_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06127.md

- 자사몰 품절 옵션 처리 저장 단계 보강(확인창 수락·1회 재시도·실패 진단 캡처).
