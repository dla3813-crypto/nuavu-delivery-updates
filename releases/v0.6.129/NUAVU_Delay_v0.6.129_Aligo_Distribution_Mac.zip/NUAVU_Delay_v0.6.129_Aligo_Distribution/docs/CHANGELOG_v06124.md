# NUAVU_Delay_v0.6.124_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06123.md

- AI 예약 확인 (schedule_followup): 지정 시각에 같은 대화에서 자동 확인·답변. 패치노트에 추가.
