# NUAVU_Delay_v0.6.127_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06126.md

- 너나우리 문자 경로(선택): nunauri_provider.py(누아브판 어댑터 이식), 별도 키체인 항목(NUNA_SERVICE), configure_nunauri/forget_nunauri, /api/nunauri-settings·nunauri-forget. 너나우리 SMS/LMS 계정이 있으면 그 종류의 문자는 provider=NUNAURI(채널 "너나우리 SMS/LMS"), 결과는 전송내역 하루 단위 대조(_poll_nunauri). 없으면 알리고 문자 그대로. 알림톡 실패 대체 문자·반품 안내 문자도 경로 반영. 설정 화면에 너나우리 칸.
