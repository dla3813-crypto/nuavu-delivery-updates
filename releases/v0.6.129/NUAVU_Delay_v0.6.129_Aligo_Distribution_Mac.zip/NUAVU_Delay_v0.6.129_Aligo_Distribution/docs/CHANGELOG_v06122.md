# NUAVU_Delay_v0.6.122_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06121.md

- 매칭 취소(연결 안 함) 기능: 자료 확인 창·수동 매칭 창에서 취소, [저장한 매칭 해제]로 자동 매칭으로 복귀.
