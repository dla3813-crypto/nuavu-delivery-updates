# NUAVU_Delay_v0.6.94_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v0693.md

- 변경 없음 (누아브판 모바일 화면 작업으로 버전 번호만 함께 올라감).
