# NUAVU_Delay_v0.6.120_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06119.md

- AI 문자 작성 카드에 발송 시점(즉시/오전 9시 예약) 추가, 작성창에서 [오전 9시에 전송] 버튼 강조. 예약은 사장님이 버튼을 눌러야 등록됨.
