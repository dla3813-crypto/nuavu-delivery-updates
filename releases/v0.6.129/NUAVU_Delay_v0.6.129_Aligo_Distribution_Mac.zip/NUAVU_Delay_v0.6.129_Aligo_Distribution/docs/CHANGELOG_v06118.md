# NUAVU_Delay_v0.6.118_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06117.md

- 작성창 직접 입력 번호 칸 높이 축소 (공통 textarea 200px 규칙 제외).
