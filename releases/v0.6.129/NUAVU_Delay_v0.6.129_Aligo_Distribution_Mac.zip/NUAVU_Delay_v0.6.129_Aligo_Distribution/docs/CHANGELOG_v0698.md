# NUAVU_Delay_v0.6.98_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v0697.md
- 버전 숫자만 올림 (배포판 변경 없음)
