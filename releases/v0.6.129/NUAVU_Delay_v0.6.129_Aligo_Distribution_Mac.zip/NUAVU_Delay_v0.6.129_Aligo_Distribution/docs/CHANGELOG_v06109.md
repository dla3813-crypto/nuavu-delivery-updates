# NUAVU_Delay_v0.6.109_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06108.md

## (2026-10-25) Codex: 오른쪽 아래 버튼 + 앱 기능을 도구로 연결 (누아브판·배포판 공통)
- 화면: 상단 빠른 질문 바를 없애고 오른쪽 아래 버튼(채널톡처럼). 누르면 오른쪽 고정 창(작게 보기), ⤢ 로 전체 화면(크게 보기), 다시 누르면 닫힘.
  앱 화면은 버튼/창 폭만큼 오른쪽으로 비켜서 표·선택 바를 가리지 않음 (60% 배율 포함 확인). 휴대폰 폭에서는 아래쪽만 비움. 새 답이 오면 버튼에 빨간 점.
- 앱 도구 (Codex app-server dynamicTools): app_overview(카드·안내 상태 필터별 개수·자료 시각), list_orders(화면과 같은 필터·검색 · 출고 예상일·공급 배정·합포 정보, 고객명 가림·연락처 없음),
  search_returns(고객명·원송장·주문번호로 반품/교환·회수접수 기록), dispatch_batches, notice_templates, list_materials/link_material, job_status, import_orders(자동 불러오기 버튼과 같음),
  refresh_supply, refresh_inventory(누아브판), propose_action(확인 카드만: 메시지 없는 안내 / 문자 작성(추천 문구는 수동 작성에 그대로 채움) / 출고 예상일 변경), recent_action_results.
- 화면 계산이 필요한 도구는 앱 화면(app.js)의 같은 필터 함수로 계산 (화면과 채팅이 같은 로직).
- 카드로 연 화면에서 사장님이 실제로 처리하면 결과가 대화에 "앱에서 처리됨 · …"으로 남고 Codex 도 확인 가능.
- Codex 지침: 첨부 요청 대신 도구 사용, 결과 확인 전 "불러왔다·변경했다·발송했다" 금지, 두 날짜(안내한 출고 예정일 / 출고 예상일) 구분.
- 앱 재시작 후 이어지는 대화는 도구가 붙은 새 스레드로 이어 가며 이전 대화 요약을 넘김 (화면 기록은 그대로).
