# NUAVU_Delay_v0.6.123_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06122.md

- 앱 내장 패치노트(web/patch_notes.json)에 오전 9시 예약 카드·매칭 취소·매칭 오류 수정 항목 추가. 깃헙 배포 버전.
