# NUAVU_Delay_v0.6.129_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06128.md

- 자사몰 품절 옵션 처리 저장 확인: 잠시 뒤 재확인 후 재저장.
