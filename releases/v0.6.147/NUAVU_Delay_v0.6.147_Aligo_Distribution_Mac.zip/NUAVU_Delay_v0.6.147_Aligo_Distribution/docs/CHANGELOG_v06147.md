# NUAVU_Delay_v0.6.147_Aligo_Distribution 변경 내역

이전: docs/CHANGELOG_v06146.md

## 2026-11-09 00:45 사장님 (배포 대상: 0.6.146 → 0.6.147) — 누아브판 0.6.158 이식 (patch/apply_06158_ship_delay_cutoff_manual.py, 공용)
- supply_workflow.ship_delay_question: progress_cutoff(v) >= 그 화요일이면 묻지 않음 (완료 후 치워진 출고장). domain.ship_delay_alert: 마감(수요일 18:00 KST) 뒤 수동 갱신이면 빨간 알림 생략 (ship_delay_manual_seen).
- 테스트 tests/test_ship_delay_cutoff_manual_06147.py (5)
