"""Read-only section exports with mobile contacts and header filters."""
import io
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

HEADERS=['상품명+옵션','주문수량','주문일/주문시간','수령자이름','수령자휴대폰',
         '판매처','주문자전화','주문자휴대폰','주문번호','상세주문번호','안내한 출고 예정일','출고 예상일자','입고예정기반 데이터']  # v0.6.147: + 상세주문번호 (누아브 메인과 동일)
SECTIONS={'white_dated':'안내 전_일정 확정','white_undated':'안내 전_일정 미확정','notice_undated_seen':'출고 예정일자 (미확정)_이력 있음','notice_undated_new':'출고 예정일자 (미확정)_이력 없음','notice_resend':'출고 예정일 재발송 필요','notice_undated':'출고 예정일자 (미확정)','':'전체 주문','white':'안내 전','scheduled':'예약발송대기','green':'예정일 이내',
          'confirmed':'예정일 이내(확정)','yellow':'예정일 당일','red':'예정일 초과',
          'failed':'발송실패','charcoal':'품절 안내','pending':'예약·전송 처리 중','watch':'추가 확인',
          'review':'주문정보 변경 확인','delay_risk':'예정일 초과 예상','manual_recommended':'수동매칭 권장',
          'supply_unmatched':'수동 매칭 필요','dispatch_dated':'출고 예정일자(예정)',
          'dispatch_undated':'출고 예정일자(미확정)','exchange':'교환건'}
CONTACT_KEYS=('recipientMobile','recipientPhone','buyerPhone','buyerMobile','sellerLabel')
NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
ET.register_namespace('',NS)

def contacts(value):
    if value is None:return None
    if not isinstance(value,dict) or set(value)-set(CONTACT_KEYS):raise ValueError('엑셀 연락처 원본 형식 오류')
    result={}
    for key in CONTACT_KEYS:
        v=value.get(key,'')
        if not isinstance(v,str) or len(v)>1500:raise ValueError('엑셀 연락처 원본 항목을 확인하세요.')
        result[key]=v.strip()
    return result

def merge_contacts(a,b):
    if a is None or b is None:return None
    return {k:a.get(k,'') if a.get(k,'')==b.get(k,'') else '' for k in CONTACT_KEYS}

def month_day(value):
    from datetime import date
    try:
        d=date.fromisoformat(value)
        return f'{d.month}월 {d.day}일'
    except (ValueError,TypeError):return ''

def order_time(row):
    raw=row.get('orderTimestamp') or row.get('orderDate','')
    match=re.match(r'^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(?:[ T/](\d{1,2}:\d{2}(?::\d{2})?))?',raw)
    if not match:return raw
    y,m,d,t=match.groups()
    return f'{y}.{int(m)}.{int(d)}'+('/'+t if t else '')

def recipient_mobile(row):
    """Prefer recipient mobile; use the existing notice mobile for older rows.

    Export only: never changes the stored sender-recipient selection or consent.
    Landlines, masked values and missing numbers must not masquerade as mobiles.
    """
    from domain import phone,valid_phone
    raw=row.get('exportContacts') or {}
    for value in (raw.get('recipientMobile'),raw.get('recipientPhone'),row.get('phone'),
                  raw.get('buyerMobile'),raw.get('buyerPhone')):
        number=phone(value)
        if valid_phone(number):return number[:3]+'-'+number[3:-4]+'-'+number[-4:]
    return ''

def order_prefixes(rows):
    """'(합포)' for orders with 2+ active order-products, '(교환)' for C-prefixed exchange orders. Export-only labels."""
    from collections import Counter
    counts=Counter((r.get('seller',''),str(r.get('orderId') or '').strip()) for r in rows if r.get('active') and str(r.get('orderId') or '').strip())
    out={}
    for r in rows:
        oid=str(r.get('orderId') or '').strip();prefix=''
        if oid and counts[(r.get('seller',''),oid)]>1:prefix+='(합포)'
        if oid.upper().startswith('C'):prefix+='(교환)'
        out[r['key']]=prefix
    return out

def detail_ids(row):
    """상세주문번호 per order-product, one per line (누아브 메인과 동일). Covers non-Ably sellers; older Ably IDs remain usable."""
    source=row.get('exportOrderItemIds')
    if source is None:source=[p.get('id','') for p in row.get('orderItems',[]) or []] or [row.get('orderItemId','')]
    value='\n'.join(dict.fromkeys(str(v or '').strip() for v in source if v))
    if len(value)>32767:
        from domain import ValidationError
        raise ValidationError('상세주문번호가 엑셀 한 셀의 길이를 넘습니다. 번호를 생략하지 않고 내보내기를 중단했습니다.')
    return value

def values(row,shop):
    raw=row.get('exportContacts') or {}
    known=bool(row.get('exportContacts'))
    buyer_mobile=raw.get('buyerMobile','')
    if not known:
        if row.get('phoneSource')=='주문자':buyer_mobile=row.get('phone','')
    info=row.get('supplyInfo',{});kinds=[]
    if info.get('manifestQty',0)>0:kinds.append('출고장')
    if info.get('plannedQty',0)>0:kinds.append('진행상황')
    basis=' + '.join(kinds)
    if basis and info.get('allocatedQty',0)<row['qty']:basis+=' · 수량 부족'
    if not basis:
        basis=('매칭 필요' if info.get('matchNeeded') else '도착일 확인 · 수량 부족'
               if row.get('officeDates') else '도착일 미확인')
    start,end=row.get('dispatchStart',''),row.get('dispatchEnd','')
    dispatch=month_day(start) if start==end else (month_day(start)+' ~ '+month_day(end) if start and end else '')
    seller=raw.get('sellerLabel') or row['seller'].replace('누아브 ',(shop or '누아브')+' ',1)
    return [row['product']+('/'+row['option'] if row.get('option') else ''),row['qty'],order_time(row),
            row.get('recipient',''),recipient_mobile(row),seller,
            raw.get('buyerPhone',''),buyer_mobile,row.get('exportOrderPrefix','')+str(row['orderId']),detail_ids(row),month_day(row.get('dueDate','')),dispatch,basis]

def workbook_bytes(rows):
    template=Path(__file__).resolve().parent/'templates/order_export.xlsx'
    with zipfile.ZipFile(template) as source:
        root=ET.fromstring(source.read('xl/worksheets/sheet1.xml'))
        data=root.find(f'{{{NS}}}sheetData')
        prototype=data.find(f'{{{NS}}}row[@r="2"]')
        styles={c.attrib['r'].rstrip('0123456789'):c.attrib.get('s','0') for c in prototype}
        for r in list(data)[1:]:data.remove(r)
        for index,values_ in enumerate(rows,2):
            lines=max(1,str(values_[9]).count('\n')+1)  # 상세주문번호 lines → row height
            row=ET.SubElement(data,f'{{{NS}}}row',{'r':str(index),'ht':str(min(409.5,15*lines)),'customHeight':'1'})
            for col,value in enumerate(values_):
                letter=chr(65+col)
                cell=ET.SubElement(row,f'{{{NS}}}c',{'r':letter+str(index),'s':styles[letter]})
                if col==1:
                    ET.SubElement(cell,f'{{{NS}}}v').text=str(int(value))
                else:
                    cell.set('t','inlineStr')
                    text=ET.SubElement(ET.SubElement(cell,f'{{{NS}}}is'),f'{{{NS}}}t')
                    text.set('{http://www.w3.org/XML/1998/namespace}space','preserve')
                    # Inline strings never execute formula-like order text.
                    text.text=re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]','',str(value))
        dimension=root.find(f'{{{NS}}}dimension')
        last_column=chr(64+len(HEADERS));export_range=f'A1:{last_column}{len(rows)+1}'
        if dimension is not None:dimension.set('ref',export_range)
        # Plain worksheet filter: covers every exported row without adding a
        # styled Excel table or changing the user's original formatting.
        for old in root.findall(f'{{{NS}}}autoFilter'):root.remove(old)
        root.insert(list(root).index(data)+1,ET.Element(f'{{{NS}}}autoFilter',{'ref':export_range}))
        output=io.BytesIO()
        with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as target:
            for item in source.infolist():
                content=ET.tostring(root,encoding='utf-8',xml_declaration=True) if item.filename=='xl/worksheets/sheet1.xml' else source.read(item.filename)
                target.writestr(item,content)
    return output.getvalue()

def export_orders(engine,payload):
    from domain import ValidationError
    keys=payload.get('keys');section=payload.get('section','')
    if not isinstance(keys,list) or not 1<=len(keys)<=20000 or any(not isinstance(k,str) for k in keys) or len(set(keys))!=len(keys):
        raise ValidationError('다운로드할 주문상품을 선택하세요. 중복 없는 최대 20,000개까지 저장할 수 있습니다.')
    if not isinstance(section,str) or section not in SECTIONS:raise ValidationError('다운로드 섹션을 확인하세요.')
    state=engine.public_state()
    if payload.get('revision')!=state.get('revision'):raise ValidationError('주문 자료가 변경됐습니다. 목록을 새로 확인한 뒤 다운로드하세요.')
    by_key={r['key']:r for r in state['rows']}
    if any(k not in by_key for k in keys):raise ValidationError('현재 목록에서 찾을 수 없는 주문이 있습니다. 다시 확인하세요.')
    label=SECTIONS[section]
    if section=='delay_risk':
        stage=payload.get('riskStage')
        if stage not in ('watch','confirmed'):raise ValidationError('감시/확정 섹션을 선택하세요.')
        label+='_'+('감시' if stage=='watch' else '확정')
    prefixes=order_prefixes(state['rows'])
    rows=[{**by_key[k],'exportOrderPrefix':prefixes.get(k,'')} for k in keys]
    return {'name':label+'_'+state['today'][5:7]+state['today'][8:10]+'.xlsx',
            'data':workbook_bytes([values(r,state['settings'].get('shopName','')) for r in rows]),
            'count':len(rows),'missingContacts':sum(not recipient_mobile(r) for r in rows)}
