"""v0.6.147 출고장 갱신: manifests whose file left the folder are forgotten completely (rows + sealed proofs)."""
from test_color_matching import ColorWorkflowTests
from test_supply_regression import order, source_row

class ForgetMissingManifestTests(ColorWorkflowTests):
    def batches(self):return {b['name']:b for b in self.engine.public_state()['supply']['batches']}
    def test_missing_manifest_is_forgotten_on_reset(self):
        self.write('솔리아 10월 13일 출고장 (완료).xlsx',[source_row(color='다크그레이')])
        self.write('솔리아 10월 17일 출고장(1) (완료).xlsx',[source_row(color='다크그레이',product='다른 상품')])
        self.engine.supply_refresh()
        self.assertEqual(set(self.batches()),{'솔리아 10월 13일 출고장 (완료).xlsx','솔리아 10월 17일 출고장(1) (완료).xlsx'})
        (self.folder/'솔리아 10월 13일 출고장 (완료).xlsx').unlink()
        self.engine.supply_refresh()
        self.assertTrue(self.batches()['솔리아 10월 13일 출고장 (완료).xlsx']['fileMissing'])
        r=self.engine.supply_reset({'confirmed':True})
        self.assertEqual(r['forgotten'],['솔리아 10월 13일 출고장 (완료).xlsx']);self.assertIn('폴더 출고장 1개 확인',r['message']);self.assertIn('기억 삭제',r['message'])
        names=set(self.batches());self.assertNotIn('솔리아 10월 13일 출고장 (완료).xlsx',names);self.assertIn('솔리아 10월 17일 출고장(1) (완료).xlsx',names)
        self.assertTrue(self.batches()['솔리아 10월 17일 출고장(1) (완료).xlsx']['closed'])
    def test_sealed_proof_from_forgotten_manifest_is_dropped(self):
        self.write('솔리아 10월 13일 출고장 (완료).xlsx',[source_row(color='다크그레이')])
        self.engine.supply_refresh();self.engine.supply_reset({'confirmed':True})   # seals TEST-001 to the 10/13 manifest
        self.assertEqual(self.active()['TEST-001']['supplyInfo']['allocatedQty'],1)
        (self.folder/'솔리아 10월 13일 출고장 (완료).xlsx').unlink()
        r=self.engine.supply_reset({'confirmed':True})
        self.assertEqual(r['forgotten'],['솔리아 10월 13일 출고장 (완료).xlsx'])
        self.assertEqual(self.batches(),{});self.assertEqual(self.active()['TEST-001']['supplyInfo']['allocatedQty'],0)
    def test_present_files_keep_memory(self):
        self.write('솔리아 10월 13일 출고장 (완료).xlsx',[source_row(color='다크그레이')])
        self.engine.supply_refresh();r=self.engine.supply_reset({'confirmed':True})
        self.assertEqual(r['forgotten'],[]);self.assertIn('폴더 출고장 1개 확인',r['message']);self.assertEqual(set(self.batches()),{'솔리아 10월 13일 출고장 (완료).xlsx'})
