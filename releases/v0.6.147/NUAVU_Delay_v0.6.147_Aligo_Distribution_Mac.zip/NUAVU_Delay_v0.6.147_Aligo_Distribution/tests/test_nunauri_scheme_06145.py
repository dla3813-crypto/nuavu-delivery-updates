"""2026-11-04 22:01 긴급 (배포판 0.6.147): 너나우리 설정을 누아브판과 동일하게 — 연결 방식(HTTP 기본)·잔여량 조회.
너나우리는 실제로 HTTP로만 전송되므로, 너나우리 문자·잔여량 조회는 알리고용 https가 아니라 nunaScheme(기본 http)을 써야 한다.
가짜 공급사·메모리 금고만 사용. 실제 발송 없음."""
import unittest
from pathlib import Path
from helpers import Base,MemoryVault
from domain import Engine,ValidationError

class FakeNuna:
    def __init__(self):self.sent=[];self.remaining_calls=[]
    def send(self,kind,cred,sender,receiver,content,title,scheme):
        self.sent.append({'kind':kind,'scheme':scheme});return 1
    def remaining(self,kind,cred,scheme='https'):self.remaining_calls.append((kind,scheme));return '55'
    def report(self,kind,cred,day,scheme):return []

class NunauriSchemeTests(Base):
    def setUp(self):
        super().setUp()
        self.nuna=FakeNuna();self.nvault=MemoryVault()
        self.engine=Engine(self.store,self.fake,self.vault,aligo_provider=self.at,aligo_vault=self.atvault,nunauri=self.nuna,nuna_vault=self.nvault)
    def nuna_on(self,**kw):
        p={'smsUser':'NUNA-SMS','smsPassword':'FAKE-ONLY','lmsUser':'NUNA-LMS','lmsPassword':'FAKE-ONLY'};p.update(kw);return self.engine.configure_nunauri(p)

    def test_default_nuna_scheme_is_http_and_aligo_stays_https(self):
        s=self.store.read()['settings'];self.assertEqual((s['nunaScheme'],s['scheme']),('http','https'))
        self.assertEqual(self.engine.public_state()['nunauriAccount']['scheme'],'http')
    def test_legacy_state_without_nuna_scheme_gets_http(self):
        with self.store.edit() as s:s['settings'].pop('nunaScheme',None)
        e=Engine(self.store,self.fake,self.vault,aligo_provider=self.at,aligo_vault=self.atvault,nunauri=self.nuna,nuna_vault=self.nvault)
        self.assertEqual(self.store.read()['settings']['nunaScheme'],'http');self.assertEqual(e.public_state()['nunauriAccount']['scheme'],'http')
    def test_nuna_send_uses_http_even_though_aligo_scheme_is_https(self):
        r=self.nuna_on();self.assertIn('연결 HTTP',r['message'])
        n=self.send();self.assertEqual((n['provider'],n['scheme'],n['status']),('NUNAURI','http','PENDING'))
        self.assertEqual(self.nuna.sent,[{'kind':'LMS','scheme':'http'}])
    def test_aligo_sms_still_https(self):
        n=self.send();self.assertEqual((n['provider'],n['scheme'],n['status']),('ALIGO_SMS','https','PENDING'));self.assertEqual(self.nuna.sent,[])
    def test_save_scheme_https_is_kept_and_used(self):
        self.nuna_on(scheme='https');self.assertEqual(self.store.read()['settings']['nunaScheme'],'https')
        self.assertEqual(self.engine.public_state()['nunauriAccount']['scheme'],'https')
        n=self.send();self.assertEqual(n['scheme'],'https');self.assertEqual(self.nuna.sent[0]['scheme'],'https')
        self.assertEqual(self.store.read()['settings']['scheme'],'https')   # 알리고 설정은 그대로
    def test_invalid_scheme_rejected(self):
        with self.assertRaises(ValidationError):self.nuna_on(scheme='ftp')
    def test_scheme_change_pauses_queued_notice(self):
        self.nuna_on();n=self.queue();self.assertEqual(n['status'],'QUEUED');rev=self.store.read()['settings']['configRevision']
        self.nuna_on(scheme='https')
        self.assertEqual(self.store.read()['settings']['configRevision'],rev+1);self.assertEqual(self.last()['status'],'PAUSED')
    def test_legacy_https_nuna_queue_is_paused_not_sent(self):
        """0.6.144 이전에 너나우리 안내가 https로 대기열에 들어간 경우: 발송하지 않고 일시정지(재작성 요청)."""
        self.nuna_on();n=self.queue()
        with self.store.edit() as s:s['notices'][-1]['scheme']='https'
        self.assertFalse(self.engine.send_one());self.assertEqual(self.last()['status'],'PAUSED');self.assertIn('연결 방식',self.last()['note']);self.assertEqual(self.nuna.sent,[])
    def test_resave_same_scheme_does_not_bump_revision(self):
        self.nuna_on();rev=self.store.read()['settings']['configRevision'];self.nuna_on();self.assertEqual(self.store.read()['settings']['configRevision'],rev)
    def test_remaining_route_nunauri_uses_nuna_scheme(self):
        self.nuna_on();r=self.engine.remaining('SMS','NUNAURI')
        self.assertEqual((r['route'],r['remaining'],r['scheme']),('너나우리','55','http'));self.assertEqual(self.nuna.remaining_calls,[('SMS','http')])
        r=self.engine.remaining('LMS');self.assertEqual(r['route'],'너나우리');self.assertEqual(self.nuna.remaining_calls[-1],('LMS','http'))
    def test_remaining_route_nunauri_without_account_errors(self):
        with self.assertRaises(ValidationError) as cm:self.engine.remaining('SMS','NUNAURI')
        self.assertIn('너나우리 SMS 계정이 없습니다',str(cm.exception));self.assertEqual(self.nuna.remaining_calls,[])
    def test_remaining_route_aligo_forces_aligo_even_when_nuna_active(self):
        self.nuna_on();r=self.engine.remaining('LMS','ALIGO');self.assertEqual((r['route'],r['scheme']),('알리고','https'));self.assertEqual(self.nuna.remaining_calls,[])
    def test_remaining_bad_route_rejected(self):
        with self.assertRaises(ValidationError):self.engine.remaining('SMS','KAKAO')
    def test_ui_has_scheme_select_and_nuna_remaining_buttons(self):
        web=Path(__file__).resolve().parents[1]/'web'
        html=(web/'index.html').read_text(encoding='utf-8');js=(web/'app.js').read_text(encoding='utf-8')
        for token in ('id="nunaScheme"','value="http"','id="checkNunaSMS"','id="checkNunaLMS"','HTTP로만 전송'):self.assertIn(token,html)
        self.assertIn("route:'NUNAURI'",js);self.assertIn("route:'ALIGO'",js);self.assertIn("scheme:$('nunaScheme').value",js)

if __name__=='__main__':unittest.main()
