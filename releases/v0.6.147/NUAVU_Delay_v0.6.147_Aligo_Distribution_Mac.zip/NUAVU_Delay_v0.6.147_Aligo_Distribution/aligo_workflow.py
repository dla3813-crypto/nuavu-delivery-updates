"""Aligo workflow extension for the existing durable local outbox.

All new sending remains behind a user's compose/commit. Credential save and
approved-template reads do not send messages. Existing SMS jobs are unchanged.
"""
from __future__ import annotations
import copy
import json
import re
from datetime import timedelta
from aligo_provider import Aligo, AligoCredential, fill, delivery_result, safe_text
from aligo_credentials import default_aligo_vault
from credentials import VaultError
from provider import ProviderError, UncertainError

from branding import clean_name, safe_outgoing, message_title
TEMPLATE_KEYS=('first','change')

class AligoWorkflow:
    def setup_aligo(self,store,provider=None,vault=None):
        self.aligo_provider=provider or Aligo()
        self.aligo_vault=vault if vault is not None else default_aligo_vault(store.directory)
        self.aligo_cred=None
        self.aligo_login={'saved':False,'restored':False,'error':'','available':self.aligo_vault.available}

    def ensure_aligo_state(self,s):
        """This edition never includes another shop's account or approved codes."""
        cfg=s.setdefault('aligo',{})
        for k,v in {'enabled':False,'user':'','revision':0,'profile':'','lastTemplate':'first'}.items():cfg.setdefault(k,v)
        cfg.setdefault('sender',s['settings'].get('sender',''))
        codes=cfg.setdefault('templateCodes',{'first':'','change':''})
        templates=cfg.setdefault('templates',{})
        for key in TEMPLATE_KEYS:
            codes.setdefault(key,'')
            templates.setdefault(key,{'code':codes[key],'body':'','buttons':[],'emtitle':'',
                'name':'최초 지연 안내' if key=='first' else '일정 재변경 안내',
                'verified':False,'error':'이 쇼핑몰의 승인 템플릿 코드를 저장하고 불러오세요.'})

    @staticmethod
    def check_template_brand(template, name):
        from domain import ValidationError
        clean_name(name)
        # Approved Kakao content is immutable: reject a foreign identity, do not
        # change it silently, including buttons/mobile and PC URLs.
        if name not in template.get('body',''):
            raise ValidationError('승인 알림톡 본문에 설정한 쇼핑몰 이름이 없습니다. 해당 쇼핑몰 이름으로 승인받은 양식이 필요합니다.')
        safe_outgoing(json.dumps(template,ensure_ascii=False),name)

    def decorate_public(self,s):
        cfg=s.get('aligo',{})
        s['aligoReady']=bool(self.aligo_cred and self.aligo_cred.profile==cfg.get('profile'))
        s['aligoAccountStorage']=dict(self.aligo_login)
        for n in s['notices']:
            if n.get('kind')=='AT':n['channel']='알리고 알림톡'
            elif n.get('fallbackOf'):n['channel']='알리고 LMS (알림톡 대체)'
        return s

    def sender_for(self,s,kind):
        if kind=='AT':return s.get('aligo',{}).get('sender','')
        if self.nuna_active(kind):return s['settings'].get('nunaSender') or s['settings'].get('sender','')   # 2026-10-26: 너나우리 등록 발신번호(비우면 알리고 것)
        return s['settings'].get('sender','')

    def has_credential(self,kind):
        return bool(self.aligo_cred) if kind=='AT' else (kind in self.creds or kind in self.nuna_creds)

    def restore_aligo_credentials(self):
        from domain import ValidationError
        with self.network_lock:
            try:
                value=self.aligo_vault.load()
                if not value:
                    self.aligo_login.update(saved=False,restored=False,error='')
                    return {'message':'저장된 알리고 계정이 없습니다. 알림톡 설정에서 한 번 저장하세요.'}
                cred=AligoCredential(value['user'],value['apikey'],value['senderkey'])
                self._check_aligo_credential(cred)
                cfg=self.store.read()['aligo']
                if cred.user!=cfg['user'] or cred.profile!=cfg['profile']:raise VaultError('알리고 저장 계정과 설정이 다릅니다. 계정을 다시 저장하세요.')
                self.aligo_cred=cred
                self.aligo_login.update(saved=True,restored=True,error='')
                resumed=self._resume_recovered_locked()
                return {'message':f'알리고 계정 자동 불러오기 완료. 정상 대기 {resumed}건 재개, 미확정 건은 결과만 조회합니다.'}
            except (VaultError,ValidationError,KeyError,TypeError):
                self.aligo_login.update(restored=False,error='알리고 키체인 계정을 읽지 못했습니다. 접근 권한 또는 저장 계정을 확인하세요.')
                return {'message':self.aligo_login['error'],'restored':False}

    @staticmethod
    def _check_aligo_credential(cred):
        from domain import ValidationError
        for value,label,maximum in [(cred.user,'알리고 로그인 ID',100),(cred.apikey,'API Key',500),(cred.senderkey,'SenderKey',500)]:
            if not isinstance(value,str) or not value or len(value)>maximum or re.search(r'\s',value):
                raise ValidationError(label+'를 공백 없이 입력하세요.')

    def configure_aligo(self,p):
        from domain import ValidationError,now,phone
        with self.network_lock:
            snapshot=self.store.read();before=snapshot['aligo'];prev=self.aligo_cred
            # Older API clients can omit the field: preserve any separate sender,
            # or seed it once from the legacy SMS setting. An explicit blank or
            # malformed value is rejected instead of silently using another number.
            raw_sender=p.get('sender',before.get('sender') or snapshot['settings'].get('sender',''))
            if not isinstance(raw_sender,str) or len(raw_sender)>40 or re.search(r'[^0-9+() \-]',raw_sender):
                raise ValidationError('알리고 전용 발신번호를 올바르게 입력하세요.')
            sender=phone(raw_sender)
            if ('sender' in p or sender) and not re.fullmatch(r'0\d{8,10}|1[568]\d{6}',sender):
                raise ValidationError('알리고에 등록된 전용 발신번호를 입력하세요. 고객센터·문자 발신번호와 다르게 설정할 수 있습니다.')
            user=str(p.get('user','')).strip()
            api=p.get('apikey','');senderkey=p.get('senderkey','')
            if not isinstance(api,str) or not isinstance(senderkey,str):raise ValidationError('API Key와 SenderKey 형식을 확인하세요.')
            # Never silently attach secrets from a different account to a changed user.
            same=prev and prev.user==user
            cred=AligoCredential(user,api.strip() or (prev.apikey if same else ''),senderkey.strip() or (prev.senderkey if same else ''))
            self._check_aligo_credential(cred)
            if p.get('enabled') not in (True,False):raise ValidationError('알림톡 기본 사용 여부를 선택하세요.')
            codes={}
            for key in TEMPLATE_KEYS:
                value=p.get('templateCodes',{}).get(key,before.get('templateCodes',{}).get(key,''))
                if not isinstance(value,str) or (value and not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',value)):
                    raise ValidationError('승인 템플릿 코드는 영문·숫자·밑줄·하이픈으로 입력하세요.')
                codes[key]=value
            codes_changed=codes!=before.get('templateCodes')
            identity_changed=before.get('profile')!=cred.profile
            if self.aligo_vault.available:
                try:self.aligo_vault.save({'version':1,'user':cred.user,'apikey':cred.apikey,'senderkey':cred.senderkey})
                except VaultError as exc:raise ValidationError(str(exc)) from exc
            sender_changed=before.get('sender','')!=sender
            changed=prev!=cred or identity_changed or sender_changed or codes_changed
            with self.store.edit() as s:
                cfg=s['aligo'];cfg.update(user=user,profile=cred.profile,enabled=p['enabled'],sender=sender,templateCodes=codes)
                if identity_changed or codes_changed:
                    for key in TEMPLATE_KEYS:
                        cfg['templates'][key]={'code':codes[key],'body':'','buttons':[],'emtitle':'',
                            'name':'최초 지연 안내' if key=='first' else '일정 재변경 안내',
                            'verified':False,'error':'이 계정의 승인 템플릿을 다시 불러오세요.'}
                    cfg.pop('verifiedAt',None)
                if changed:
                    cfg['revision']+=1
                    for n in s['notices']:
                        if n['kind']=='AT' and n['status'] in {'QUEUED','SCHEDULED'}:
                            self.transition(n,'PAUSED',
                                '알리고 전용 발신번호 변경. 이 예약은 이전 번호를 보관하므로 취소 후 새로 작성하세요.' if sender_changed
                                else '알리고 설정 변경. 기존 예약의 계정과 내용을 확인 후 이어보내세요.')
                s['audits'].append({'at':now(),'event':'알리고 계정·전용 발신번호 저장 (문자 설정 보존, 발송 없음)',
                                    'senderChanged':sender_changed,'sender':sender})
            self.aligo_cred=cred;self.plans.clear()
            self.aligo_login.update(saved=self.aligo_vault.available,restored=False,error='')
            self._resume_recovered_locked()
        return {'message':'알리고 계정·전용 발신번호 저장 완료. 알리고 문자·대체문자 번호는 변경하지 않았습니다. '
                +('기존 미요청 알림톡은 이전 발신번호를 보관하므로 취소 후 새로 작성하세요. ' if sender_changed else '')
                +'번호 등록 완료 여부는 알리고에서 확인하세요. 계정 저장은 발신번호 인증이 아니며 메시지를 보내지 않았습니다.'}

    def forget_aligo(self,p):
        from domain import ValidationError,now
        if p.get('confirmed') is not True:raise ValidationError('알리고 계정 삭제를 확인하세요.')
        with self.network_lock:
            try:self.aligo_vault.delete()
            except VaultError as exc:raise ValidationError(str(exc)) from exc
            self.aligo_cred=None;self.aligo_login.update(saved=False,restored=False,error='')
            with self.store.edit() as s:
                s['aligo']['enabled']=False;s['aligo']['revision']+=1
                for n in s['notices']:
                    if n['kind']=='AT' and n['status'] in {'QUEUED','SCHEDULED'}:self.transition(n,'PAUSED','알리고 계정 삭제로 미요청 알림톡 중지')
                s['audits'].append({'at':now(),'event':'알리고 계정 삭제. 알리고 문자 계정과 모든 이력은 보존'})
            self.plans.clear()
        return {'message':'알리고 계정만 삭제했습니다. 알리고 문자 계정과 주문·이력은 유지합니다.'}

    def diagnose_aligo(self):
        from domain import now
        from aligo_http import tls_environment
        with self.network_lock:
            cred=self.credential('AT')
            env=tls_environment()
            try:
                code=self.store.read()['aligo']['templateCodes']['first']
                if not code:raise ProviderError('최초 지연 안내의 승인 템플릿 코드를 먼저 저장하세요.')
                template=self.aligo_provider.template(cred,code)
                ok=True
                message='알리고 연결·승인 템플릿 조회 성공. '+code+' 승인 상태를 확인했습니다. 발송 API는 호출하지 않았습니다.'
            except (ProviderError,UncertainError) as exc:
                ok=False
                message=safe_text(str(exc),cred)
            result={'ok':ok,'at':now(),'message':message,'environment':env}
            self.aligo_login['diagnostic']=result
            with self.store.edit() as s:
                s['audits'].append({'at':result['at'],'event':'알리고 연결 진단 (조회만, 발송 없음)',
                                    'ok':ok,'message':message,'environment':env})
        return result

    def refresh_aligo_templates(self):
        from domain import now, fingerprint, ValidationError
        with self.network_lock:
            cred=self.credential('AT');loaded={};errors={}
            state=self.store.read();name=clean_name(state['settings'].get('shopName',''))
            codes=state['aligo']['templateCodes']
            for key,code in codes.items():
                try:
                    if not code:raise ProviderError('승인 템플릿 코드를 먼저 저장하세요.')
                    template=self.aligo_provider.template(cred,code)
                    if template.get('code')!=code or template.get('verified') is not True:
                        raise ProviderError(code+': 요청한 새 승인 템플릿과 조회 결과가 다릅니다.')
                    self.check_template_brand(template,name)
                    template['profile']=cred.profile;template['verifiedAt']=now()
                    template['hash']=fingerprint({k:v for k,v in template.items() if k not in {'verifiedAt','hash'}})
                    loaded[key]=template
                except (ProviderError,UncertainError,ValidationError) as exc:errors[key]=safe_text(str(exc),cred)
            with self.store.edit() as s:
                for key in TEMPLATE_KEYS:
                    if key in loaded:s['aligo']['templates'][key]=loaded[key]
                    else:
                        s['aligo']['templates'][key]['verified']=False
                        s['aligo']['templates'][key]['error']=errors[key]
                s['aligo']['verifiedAt']=now()
                s['audits'].append({'at':now(),'event':'알리고 승인 템플릿 읽기 (발송 없음)','loaded':list(loaded),'errors':errors})
            self.plans.clear()
        return {'message':f'승인 템플릿 {len(loaded)}/2개 확인. '+('두 양식을 알림톡으로 사용할 수 있습니다.' if len(loaded)==2 else '확인되지 않은 양식은 전송을 차단합니다. '+ ' / '.join(errors.values())),
                'count':len(loaded),'errors':errors}

    def build_groups(self,s,p):
        from domain import ValidationError,FIRST,CHANGE,fingerprint,now
        channel=p.get('deliveryChannel','SMS')
        if channel not in ('SMS','AT'):raise ValidationError('발송 채널을 선택하세요.')
        if channel=='SMS':return self.build_sms_groups(s,p)
        if p.get('noticeType')=='manual':raise ValidationError('수동 작성은 문자(SMS/LMS)로만 발송합니다.')
        if p.get('noticeType','delay')!='delay':raise ValidationError('품절 안내는 아직 승인 템플릿이 없어 알리고 문자로 보내세요.')
        cfg=s['aligo'];key=p.get('aligoTemplate','first');codes=cfg['templateCodes']
        name=clean_name(s['settings'].get('shopName',''))
        if not self.sender_for(s,'AT'):
            raise ValidationError('알림톡 설정에서 알리고 전용 발신번호를 저장하세요.')
        if not cfg.get('enabled'):raise ValidationError('알림톡 설정에서 알림톡 사용을 켜세요.')
        cred=self.credential('AT');fallback_cred=self.credential('LMS')
        template=cfg.get('templates',{}).get(key)
        if not template or key not in TEMPLATE_KEYS or not codes.get(key) or template.get('code')!=codes[key] or not template.get('verified') or template.get('profile')!=cred.profile:
            raise ValidationError('알림톡 설정에서 승인 템플릿 불러오기를 먼저 실행하세요. 수신 테스트는 필요 없습니다.')
        self.check_template_brand(template,name)
        # Derive order grouping / number validation / fallback byte limits from the existing path.
        sms_template=template['body'].replace('#{상품명}','{상품목록}').replace('#{출고예정일}','{출고예정일}')
        args=dict(p,template=sms_template,kind='LMS')
        groups=self.build_sms_groups(s,args)
        from datetime import date
        from domain import bytecount
        for g in groups:
            body=g['base']
            if len(body)>1000:raise ValidationError(g['orderId']+': 알림톡 본문이 앱 제한 1,000자를 넘습니다. 상품을 나누어 선택하세요.')
            products='\n'.join(f"{r['product']}{' ('+r['option']+')' if r['option'] else ''} × {r['qty']}" for r in g['products'])
            d=date.fromisoformat(g['dueDate']);values={'상품명':products,'출고예정일':f'{d.year}년 {d.month}월 {d.day}일'}
            body=fill(template['body'],values)
            # No trimming or appended tracking text in the approved Kakao body.
            g['fallbackContent']=g['content'];g['content']=body;g['kind']='AT';g['channel']='알리고 알림톡'
            g['aligoCode']=template['code'];g['aligoTemplateKey']=key;g['aligoTemplateHash']=template['hash']
            g['aligoProfile']=cred.profile;g['aligoRevision']=cfg['revision']
            g['aligoButtons']=[{k:fill(v,values) for k,v in b.items()} for b in template['buttons']]
            g['aligoEmtitle']=fill(template['emtitle'],values)
            g['title']=template['name'];g['chars']=len(body)
            g['fingerprint']=fingerprint([g['seller'],g['orderId'],g['phone'],g['itemKeys'],g['dueDate'],body,'AT',template['code'],g['aligoButtons'],g['aligoEmtitle']])
            if any(n.get('fingerprint')==g['fingerprint'] and n['status'] in {'QUEUED','SCHEDULED','PAUSED','SENDING','PENDING','UNKNOWN','DELIVERED'} for n in s['notices']):
                raise ValidationError(g['orderId']+': 동일한 알림톡 안내를 이미 요청했습니다.')
            g['fallback']={'kind':'LMS','account':fallback_cred.user,'sender':self.sender_for(s,'LMS'),'scheme':s['settings']['scheme'],
                    'configRevision':s['settings']['configRevision'],'content':g['fallbackContent'],'title':message_title(name),
                    'shopName':name,'shopRevision':s['settings']['shopRevision']}
        return groups

    def decorate_notice(self,n,g,s):
        if g['kind']!='AT':return
        for k in ('aligoCode','aligoTemplateKey','aligoTemplateHash','aligoProfile','aligoRevision','aligoButtons','aligoEmtitle','fallback'):
            n[k]=copy.deepcopy(g[k])
        n['channel']='알리고 알림톡';n['scheme']='https';n['provider']='ALIGO_AT'
        n['logicalId']=n['id'];n['fallbackPolicy']='CONFIRMED_ONLY_DAYTIME'

    def validate_send_config(self,s,n):
        from domain import ValidationError
        cred=self.credential(n['kind']);cfg=s['settings']
        name=clean_name(cfg.get('shopName',''))
        if n.get('shopName')!=name or n.get('shopRevision')!=cfg.get('shopRevision'):
            raise ValidationError('쇼핑몰 이름 변경 전의 예약입니다. 취소하고 새 이름으로 다시 작성하세요.')
        safe_outgoing(n.get('content','')+'\n'+n.get('title',''),name)
        expected_sender=self.sender_for(s,n['kind'])
        if not expected_sender or n.get('sender')!=expected_sender or n.get('account')!=cred.user:
            raise ValidationError('기존 대기열과 발송 계정/발신번호가 다릅니다. 발신번호를 바꾼 미요청 예약은 취소 후 새로 작성하세요.')
        if n['kind']=='AT':
            key=n.get('aligoTemplateKey');codes=s['aligo']['templateCodes']
            if key not in TEMPLATE_KEYS or not codes.get(key) or n.get('aligoCode')!=codes[key]:
                raise ValidationError('옛 템플릿 또는 현재 양식과 다른 코드입니다. 기존 미발송 예약을 취소하고 새 승인 양식으로 작성하세요.')
            template=s['aligo']['templates'].get(key,{})
            if template.get('code')!=codes[key]:
                raise ValidationError('새 템플릿 본문·버튼이 확인되지 않았습니다. 승인 템플릿을 다시 불러오세요.')
            if n.get('aligoProfile')!=cred.profile:raise ValidationError('알림톡 발신 채널이 변경되었습니다.')
            if n.get('aligoRevision')!=s['aligo']['revision']:raise ValidationError('알리고 발송 설정이 변경되었습니다. 내용을 확인한 뒤 이어보내세요.')
            if not template.get('verified') or template.get('hash')!=n.get('aligoTemplateHash'):raise ValidationError('승인 템플릿이 변경되거나 확인되지 않습니다. 기존 예약 취소 후 새로 작성하세요.')
        elif n.get('provider')!=self.sms_provider_for(n['kind']) or n.get('scheme')!=(cfg.get('nunaScheme','http') if n.get('provider')=='NUNAURI' else 'https'):   # 2026-11-04 0.6.147: 너나우리는 nunaScheme(기본 http)
            raise ValidationError('문자 발송 경로(너나우리/알리고)나 연결 방식이 바뀌었습니다. 취소 후 새로 작성하세요.')
        elif n.get('configRevision')!=cfg.get('configRevision'):
            raise ValidationError('알리고 문자 설정이 변경되었습니다. 기존 예약은 취소 후 새로 작성하세요.')
        if n.get('fallbackOf'):
            parent=next((x for x in s['notices'] if x['id']==n['fallbackOf']),None)
            manual=bool(parent and parent.get('fallbackDecision')=='MANUAL' and n.get('manualFallback') and parent.get('fallbackId')==n['id'])   # 사장님이 고른 수동 대체
            if not parent or parent.get('aligoProviderSmsMid') or (not manual and (parent['status']!='FAILED' or not parent.get('aligoFailureConfirmed'))) or (manual and parent['status']=='DELIVERED'):
                raise ValidationError('알림톡 실패 확정 근거가 없거나 이미 대체문자가 있어 문자 대체를 중지합니다.')
            self.check_newer_notice(s,parent,exclude=n['id'])
        return cred

    def dispatch_notice(self,snap,cred):
        if snap['kind']=='AT':return {'mid':self.aligo_provider.send(cred,snap)}
        if snap.get('provider')=='NUNAURI':   # 2026-10-26: 너나우리 계정이 있으면 문자는 너나우리로 (접수 코드 1)
            return {'nunaCode':self.nunauri.send(snap['kind'],cred,snap['sender'],snap['phone'],snap['content'],snap['title'],snap.get('scheme','https'))}
        return self.provider.send(snap['kind'],cred,snap['sender'],snap['phone'],snap['content'],snap['title'],snap['scheme'])

    def check_newer_notice(self,s,parent,exclude=None):
        from domain import ValidationError
        seen=False
        for n in s['notices']:
            if n['id']==parent['id']:seen=True;continue
            if seen and n['id']!=exclude and n.get('fallbackOf')!=parent['id'] and n['status']!='CANCELLED' and set(n['itemKeys'])&set(parent['itemKeys']):
                raise ValidationError('더 최근의 안내/예약이 있어 예전 알림톡의 문자 대체를 보류합니다.')

    def manual_fallback(self,p):
        """2026-10-22 19:45 요청: 1분 결과 미확인(또는 실패) 알림톡을 같은 안내 문자로 1회 — 오전 9시 예약 / 즉시 전송."""
        from domain import ValidationError,now
        nid=str((p or {}).get('id','')) if isinstance(p,dict) else '';mode=(p or {}).get('mode') if isinstance(p,dict) else ''
        if mode not in ('MORNING','IMMEDIATE'):raise ValidationError('오전 9시 예약 또는 즉시 전송을 선택하세요.')
        with self.store.edit() as s:
            parent=next((x for x in s['notices'] if x['id']==nid),None)
            if not parent or parent.get('kind')!='AT' or parent.get('isTest'):raise ValidationError('알림톡 발송 이력을 찾지 못했습니다.')
            if parent['status'] not in {'PENDING','UNKNOWN','FAILED'}:raise ValidationError('결과 미확인 또는 실패한 알림톡만 문자로 다시 보낼 수 있습니다.')
            if parent.get('fallbackId'):raise ValidationError('이미 문자 대체가 등록된 알림톡입니다. 발송 이력에서 확인하세요.')
            if parent.get('aligoProviderSmsMid'):raise ValidationError('알리고가 이미 대체문자를 보낸 기록이 있어 중복 발송을 막았습니다.')
            self.enqueue_fallback(s,parent,manual=mode)
            if not parent.get('fallbackId'):raise ValidationError(parent.get('fallbackReason') or '문자 대체를 등록하지 못했습니다.')
            note='사장님 선택: 문자 대체 '+('오전 9시 예약' if mode=='MORNING' else '즉시 전송')+' 등록 (알림톡 기록은 그대로 보존)'
            parent.setdefault('events',[]).append({'at':now(),'status':parent['status'],'note':note})
            self.resolve_wait_alerts(s,parent)
            for a in s.get('alerts',[]):
                if a.get('noticeId')==nid and not a.get('resolvedAt') and a.get('code') in {'RESULT_UNCONFIRMED_1M','DELIVERY_FAILED'}:a['resolvedAt']=now()
        return {'message':'같은 안내를 문자로 '+('오전 9시에 보내도록 예약했습니다.' if mode=='MORNING' else '지금 보냅니다.')+' 결과는 발송 이력에서 확인하세요.'}

    def enqueue_fallback(self,s,parent,manual=''):
        """Called in the SAME transaction as a provider-confirmed failure.
        The child is durable before any HTTP request; no re-creation after a crash.
        """
        from domain import ValidationError,customer_send_time,morning_send_time,datetime,timezone,notice_sort_key,now,fingerprint
        if not manual:
            if parent.get('fallbackId') or parent.get('fallbackDecision'):return
            if parent.get('kind')!='AT' or parent['status']!='FAILED' or not parent.get('aligoFailureConfirmed'):return
        parent['fallbackDecision']='CHECKED'
        try:
            if parent.get('aligoProviderSmsMid'):raise ValidationError('알리고 자체 대체문자 내역이 있어 알리고 문자 중복 대체를 차단했습니다.')
            self.validate_snapshot(s,parent);self.check_newer_notice(s,parent)
            f=parent.get('fallback') or {};cred=self.credential('LMS')
            cfg=s['settings']
            if not f.get('sender'):
                raise ValidationError('알리고 대체문자의 발신번호가 없습니다. 수동 확인이 필요합니다.')
            if f.get('shopName')!=cfg.get('shopName') or f.get('shopRevision')!=cfg.get('shopRevision'):
                raise ValidationError('쇼핑몰 이름이 변경되어 예전 이름의 자동 대체문자를 보류합니다.')
            safe_outgoing(f.get('content','')+'\n'+f.get('title',''),cfg['shopName'])
            if f.get('account')!=cred.user or f.get('sender')!=self.sender_for(s,'LMS') or f.get('scheme')!=cfg['scheme'] or f.get('configRevision')!=cfg['configRevision']:
                raise ValidationError('알림톡 요청 이후 알리고 문자 계정/발신 설정이 변경되어 문자 대체를 보류합니다.')
            clock=datetime.now(timezone.utc)
            # 2026-10-22 19:45: 사장님이 고른 수동 대체 — MORNING=다음 오전 9시 예약, IMMEDIATE=지금(야간에도) 전송.
            target=(morning_send_time(clock) if manual=='MORNING' else clock) if manual else customer_send_time(clock)
            if parent.get('dueDate') and parent['dueDate']<target.date().isoformat():raise ValidationError('출고 예정일이 대체 발송일보다 이전입니다. 새로운 일정으로 재안내하세요.')
            if s.get('queuePaused'):raise ValidationError('사용자/오류로 대기열이 멈춰 있어 자동 문자 대체도 보류합니다.')
            n=self.new_notice('LMS',f['content'],f['title'],parent['phone'],parent['ref'],parent['itemKeys'],provider=self.sms_provider_for('LMS'))
            for k in ('seller','orderId','products','dueDate','noticeType'):n[k]=copy.deepcopy(parent[k])
            n.update(account=f['account'],sender=f['sender'],scheme=f['scheme'],configRevision=cfg['configRevision'],
                     shopName=f['shopName'],shopRevision=f['shopRevision'],
                     sendMode='AUTO',fallbackOf=parent['id'],logicalId=parent['id'],logicalCreatedAt=parent['createdAt'],
                     sendAuthorizedAt=parent['sendAuthorizedAt'],channel=('너나우리' if self.nuna_active('LMS') else '알리고')+' LMS (알림톡 실패 대체)',
                     fingerprint=fingerprint(['FALLBACK_ONCE',parent['id']]))
            if manual:n['sendMode']=manual;n['manualFallback']=True
            if manual and target>clock:
                n['scheduledAt']=target.isoformat(timespec='milliseconds')
                self.transition(n,'SCHEDULED','사장님 선택: 알림톡 결과 미확인/실패 → 같은 안내를 문자로 오전 9시 예약')
            elif manual:self.transition(n,'QUEUED','사장님 선택: 알림톡 결과 미확인/실패 → 같은 안내를 문자로 즉시 1회 전송')
            elif target>clock:
                n['scheduledAt']=target.isoformat(timespec='milliseconds')
                self.transition(n,'SCHEDULED','알림톡 실패 확정: 야간 문자 대체는 다음 허용 오전 9시 예약')
            else:self.transition(n,'QUEUED','알림톡 실패 확정: 승인한 동일 안내를 알리고 LMS로 1회 대체')
            parent['fallbackId']=n['id'];parent['fallbackDecision']='MANUAL' if manual else 'ENQUEUED';s['notices'].append(n)
            if not manual:self.add_alert(s,parent,'ALIGO_FALLBACK','warning','알림톡 실패가 확인되어 알리고 문자 1회를 대기열에 등록했습니다. 야간에는 오전 9시에 보냅니다.')
        except ValidationError as exc:
            if manual:raise
            parent['fallbackDecision']='HELD';parent['fallbackReason']=str(exc)
            self.add_alert(s,parent,'ALIGO_FALLBACK_HELD','warning','알림톡은 실패했으나 자동 문자 대체를 보류했습니다: '+str(exc))

    def poll(self,force=False):
        # SMS and Alimtalk credentials are independent; a query error in one
        # channel must never trigger a send or prevent the other channel query.
        a=self.poll_aligo(force)
        sms=self.poll_sms(force)
        if a.get('checked'):
            from domain import now
            with self.store.edit() as s:s['lastPoll']=now();s['pollNote']=a['message']+' / '+sms['message']
            return {'message':self.store.read()['pollNote']}
        return sms

    def poll_aligo(self,force=False):
        from domain import datetime,timezone,parse_time,report_due,defer_check,now,phone
        if not self.network_lock.acquire(blocking=False):return {'checked':0,'message':'발송 요청 중'}
        try:
            s=self.store.read();clock=datetime.now(timezone.utc);cred=self.aligo_cred
            candidates=[]
            for n in s['notices']:
                if n['kind']!='AT' or n['status'] not in {'PENDING','UNKNOWN'} or not n.get('attemptedAt'):continue
                at=parse_time(n['attemptedAt']);due=report_due(n)
                if not at or (not force and (clock-at>timedelta(days=7) or (due and clock<due))):continue
                if not cred or n['account']!=cred.user or n.get('aligoProfile')!=cred.profile:continue
                candidates.append(n)
            # Bound work per worker tick; order oldest-checked first to prevent starvation.
            candidates=sorted(candidates,key=lambda n:n.get('reportCheckedAt',''))[:30]
            changed=0
            for n in candidates:
                rows=[];reason='';matched=[]
                try:
                    if not n.get('aligoMid'):
                        reason='접수 응답에서 mid를 확보하지 못해 자동 결과 연결 불가. 알리고 내역 수동 확인이 필요합니다.'
                    else:
                        rows=self.aligo_provider.detail(cred,n['aligoMid'])
                        for row in rows:
                            norm=lambda t:str(t or '').replace('\r\n','\n').replace('\r','\n')
                            if (row.get('type')=='AT' and phone(row.get('phone'))==n['phone'] and phone(row.get('sender'))==n['sender']
                                    and row.get('tpl_code')==n['aligoCode'] and norm(row.get('message'))==norm(n['content'])
                                    and (not row.get('senderKey') or row['senderKey']==cred.senderkey)):
                                matched.append(row)
                        if len(matched)!=1:reason='mid 상세 내역의 수신번호·발신번호·템플릿·본문을 한 건으로 대조하지 못했습니다.'
                except (ProviderError,UncertainError) as exc:reason=safe_text(str(exc),cred)
                with self.store.edit() as current:
                    live=next(x for x in current['notices'] if x['id']==n['id'])
                    if live['status'] not in {'PENDING','UNKNOWN'}:continue
                    checked=datetime.now(timezone.utc);live['reportCheckedAt']=now();defer_check(live,checked)
                    live['reportRecordCount']=len(rows);live['reportMatchCount']=len(matched)
                    if len(matched)==1:
                        row=matched[0];status=delivery_result(row)
                        live['rawResult']=safe_text(json.dumps({k:row.get(k,'') for k in ('msgid','status','rslt','rslt_message','rsltdate','smid')},ensure_ascii=False),cred)
                        live['aligoDetailId']=str(row.get('msgid',''))
                        if str(row.get('smid') or '0') not in {'','0'}:live['aligoProviderSmsMid']=str(row['smid'])
                        if status in {'DELIVERED','FAILED'}:
                            self.transition(live,status,'알리고 상세 결과 확인: '+safe_text(row.get('rslt_message'),cred))
                            self.resolve_wait_alerts(current,live);live['resultReview']='RESOLVED';live['resultResolvedAt']=now();changed+=1
                            live['nextCheckAt']=None;live['resultUnknownReason']=''
                            if status=='DELIVERED':live['deliveredAt']=now()
                            else:
                                live['aligoFailureConfirmed']=True
                                self.enqueue_fallback(current,live)
                                if not live.get('fallbackId'):self.add_alert(current,live,'DELIVERY_FAILED','error','알림톡 전송 실패가 확정되었습니다. 문자 대체 보류 사유를 확인하세요.')
                        else:reason='알리고 결과값/처리 중 상태 미확인: '+safe_text(row.get('rslt_message'),cred)
                    if live['status'] in {'PENDING','UNKNOWN'}:
                        live['note']='알림톡 결과 확인 중. 미확인만으로 자동 문자 대체하지 않습니다. '+reason
                        self.flag_unconfirmed(current,live,checked,reason)
            return {'checked':len(candidates),'message':f'알리고 {len(candidates)}건 조회 / {changed}건 최종 결과 확인. 확정 실패만 알리고 문자로 1회 대체합니다.'}
        finally:self.network_lock.release()
