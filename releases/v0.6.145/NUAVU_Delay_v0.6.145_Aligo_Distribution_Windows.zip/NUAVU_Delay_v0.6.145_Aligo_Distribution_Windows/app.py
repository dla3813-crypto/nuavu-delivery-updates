#!/usr/bin/env python3
"""NUAVU Delay Distribution 0.6.145 — local-only standard-library UI server; desktop.py adds macOS window dependencies."""
from __future__ import annotations
import argparse
from platform_support import data_dir,ProcessLock,platform_name
import json
import re
import mimetypes
import os
import secrets
import signal
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit,quote
from domain import Engine, Store, ValidationError, FIRST, CHANGE, SOLDOUT_CARD, SOLDOUT_BANK
from provider import ProviderError, UncertainError
from supply_workflow import SupplyError
from external_notices import ExternalError

from factory_reset import operation_lock,complete_pending_reset,BLOCKED

ROOT=Path(__file__).resolve().parent
MAX_BODY=30*1024*1024 # accommodates a bounded 20MB XLSX encoded as base64

class LocalServer(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,engine,port=0,token=None):
        self.operation_lock=operation_lock(engine)
        self.engine=engine;self.token=token or secrets.token_urlsafe(32)
        try:   # 2026-10-23 아이폰 알림: 이 앱의 상태 폴더에 묶인 알림 발송기를 준비 (켜져 있을 때만 보냄)
            import phone_alert;phone_alert.for_engine(engine)
        except Exception:pass
        super().__init__(('127.0.0.1',port),Handler)
        self.origin=f'http://127.0.0.1:{self.server_port}'
    @property
    def url(self):return self.origin+'/#'+self.token

class Handler(BaseHTTPRequestHandler):
    server_version='NUAVU';sys_version=''
    def log_message(self,*args):pass # No customer numbers, credentials, request bodies, or tokens in logs.
    def setup(self):
        super().setup();self.connection.settimeout(30)
    def respond(self,status,body,ctype='application/json; charset=utf-8',headers=None):
        if not isinstance(body,bytes):body=json.dumps(body,ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type',ctype);self.send_header('Content-Length',str(len(body)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY');self.send_header('Referrer-Policy','no-referrer')
        native_eval=" 'unsafe-eval'" if getattr(self.server,'desktop',False) else ""
        self.send_header('Content-Security-Policy',f"default-src 'none'; script-src 'self'{native_eval}; style-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'")
        if headers:
            for k,v in headers.items():self.send_header(k,v)
        self.end_headers()
        try:self.wfile.write(body)
        except (BrokenPipeError,ConnectionResetError):pass
    def authorized(self,api=False):
        if self.headers.get('Host')!=self.server.origin.removeprefix('http://'):
            self.respond(403,{'error':'로컬 주소로만 사용할 수 있습니다.'});return False
        origin=self.headers.get('Origin')
        if origin and origin!=self.server.origin:
            self.respond(403,{'error':'다른 사이트에서 접근할 수 없습니다.'});return False
        if api and not secrets.compare_digest(self.headers.get('X-NUAVU-Token',''),self.server.token):
            self.respond(403,{'error':'실행 파일로 다시 화면을 열어주세요. 인증 세션이 없습니다.'});return False
        return True
    def do_GET(self):
        with operation_lock(self.server.engine):
            if urlsplit(self.path).path.startswith('/api/') and getattr(self.server.engine,'reset_in_progress',False):
                self.respond(503,{'error':BLOCKED});return
            self._get()

    def _get(self):
        path=urlsplit(self.path).path
        if not self.authorized(path.startswith('/api/')):return
        if path=='/api/version':   # 09:05 CPU 최적화: the UI asks this cheap number every few seconds and loads the full state only when it changed
            self.respond(200,{'version':self.server.engine.store.version});return
        if path=='/api/state':
            state=self.server.engine.public_state();state['desktopMode']=getattr(self.server,'desktop',False);state['stateVersion']=self.server.engine.store.version
            self.respond(200,state);return
        if path=='/api/templates':self.respond(200,self.server.engine.message_templates());return
        if path=='/api/export':
            self.respond(200,self.server.engine.export_csv(),'text/csv; charset=utf-8',{'Content-Disposition':'attachment; filename="NUAVU_message_history.csv"'});return
        if path=='/api/backup':
            state=self.server.engine.store.read()
            self.respond(200,{'format':'NUAVU_Delay_readonly_backup_v2','state':state},headers={'Content-Disposition':'attachment; filename="NUAVU_private_backup.json"'});return
        m=re.fullmatch(r'/patch/([a-z0-9_]{1,40})\.(png|jpg)',path)   # 2026-10-25: 업데이트 완료 창의 패치노트 사진
        if m:
            img=ROOT/'web'/'patch'/(m[1]+'.'+m[2])
            if img.is_file():self.respond(200,img.read_bytes(),'image/png' if m[2]=='png' else 'image/jpeg');return
        file={'/':'index.html','/index.html':'index.html','/app.js':'app.js','/idle_pause.js':'idle_pause.js','/style.css':'style.css','/excel.js':'excel.js','/import.js':'import.js','/dispatch_view.js':'dispatch_view.js','/ably_ui.js':'ably_ui.js','/cafe24_ui.js':'cafe24_ui.js','/manual_needed.js':'manual_needed.js','/update_ui.js':'update_ui.js','/phone_alert_ui.js':'phone_alert_ui.js','/activity_bar.js':'activity_bar.js','/china_ui.js':'china_ui.js','/error_log.js':'error_log.js','/ship_delay.js':'ship_delay.js','/codex_ui.js':'codex_ui.js','/codex.css':'codex.css','/manual_needed.js':'manual_needed.js','/pickup_ui.js':'pickup_ui.js','/auto_state.js':'auto_state.js','/order_auto_ui.js':'order_auto_ui.js','/factory_reset_ui.js':'factory_reset_ui.js','/returns_ui.js':'returns_ui.js','/view_tools.js':'view_tools.js','/settings_hub.js':'settings_hub.js','/zigzag_ui.js':'zigzag_ui.js','/failed_dismiss.js':'failed_dismiss.js'}.get(path)
        if not file:self.respond(404,{'error':'찾을 수 없습니다.'});return
        mime={'html':'text/html; charset=utf-8','js':'text/javascript; charset=utf-8','css':'text/css; charset=utf-8'}[file.split('.')[-1]]
        self.respond(200,(ROOT/'web'/file).read_bytes(),mime)
    def do_POST(self):
        with operation_lock(self.server.engine):
            if getattr(self.server.engine,'reset_in_progress',False):
                self.respond(503,{'error':BLOCKED});return
            self._post()

    def _post(self):
        if not self.authorized(True):return
        if self.headers.get('Origin')!=self.server.origin:
            self.respond(403,{'error':'앱 화면에서만 실행할 수 있습니다.'});return
        if self.headers.get('Content-Type','').split(';')[0]!='application/json':self.respond(415,{'error':'JSON 요청만 허용됩니다.'});return
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<=MAX_BODY:raise ValidationError('요청 데이터 크기를 확인하세요.')
            p=json.loads(self.rfile.read(size))
            if not isinstance(p,dict):raise ValidationError('요청 형식 오류')
            path=urlsplit(self.path).path;engine=self.server.engine
            if path=='/api/order-export':
                from order_export import export_orders
                result=export_orders(engine,p)
                self.respond(200,result['data'],'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                    {'Content-Disposition':"attachment; filename*=UTF-8''"+quote(result['name']),
                     'X-Export-Name':quote(result['name']),'X-Export-Count':str(result['count']),
                     'X-Export-Missing-Contacts':str(result['missingContacts'])})
                return
            actions={
                '/api/supply-auto':lambda:engine.supply_auto_settings(p),
                '/api/supply-settings':lambda:engine.supply_settings(p),
                '/api/supply-refresh':lambda:engine.supply_refresh(p),
                '/api/supply-reset':lambda:engine.supply_reset(p),
                '/api/supply-reallocate':lambda:engine.supply_reallocate(p),
                '/api/supply-match':lambda:engine.supply_match(p),
                '/api/ship-delay':lambda:engine.ship_delay_answer(p),
                '/api/dispatch-override':lambda:engine.dispatch_override(p),
                '/api/refund-done':lambda:engine.refund_done(p),
                '/api/error-log':lambda:engine.error_log(p),
                '/api/china-cancel':lambda:engine.china_cancel_action(p),
                '/api/external-preview':lambda:engine.external_preview(p),
                '/api/external-apply':lambda:engine.external_apply(p),
                '/api/external-manual':lambda:engine.external_manual(p),
                '/api/return-message-preview':lambda:engine.return_message_preview(p),
                '/api/return-message-send':lambda:engine.return_message_send(p),
                '/api/settings':lambda:engine.configure(p),
                '/api/shop-settings':lambda:engine.configure_shop(p),
                '/api/view-settings':lambda:engine.configure_view(p),
                '/api/import-scope':lambda:engine.configure_import_scope(p),
                '/api/preferences':lambda:engine.save_preferences(p),
                '/api/aligo-settings':lambda:engine.configure_aligo(p),
                '/api/aligo-templates':lambda:engine.refresh_aligo_templates(),
                '/api/aligo-diagnose':lambda:engine.diagnose_aligo(),
                '/api/aligo-reload':lambda:engine.restore_aligo_credentials(),
                '/api/aligo-forget':lambda:engine.forget_aligo(p),
                '/api/remaining':lambda:engine.remaining(p.get('kind'),p.get('route')),   # 2026-11-04 0.6.145: route=NUNAURI/ALIGO
                '/api/import':lambda:engine.import_rows(p),
                '/api/desktop-backup':lambda:engine.backup_desktop(force=True,reason='manual'),
                '/api/notice-reason':lambda:engine.set_notice_reason(p),
                '/api/review':lambda:engine.review_rows(p.get('keys',[])),
                '/api/account-reload':lambda:engine.restore_credentials(),
                '/api/account-forget':lambda:engine.forget_credentials(p),
                '/api/nunauri-settings':lambda:engine.configure_nunauri(p),   # 2026-10-26: 너나우리 문자 계정(선택)
                '/api/nunauri-forget':lambda:engine.forget_nunauri(p),
                '/api/preview':lambda:engine.preview(p),
                '/api/send':lambda:engine.commit(p),
                '/api/queue':lambda:engine.queue_control(p),
                '/api/poll':lambda:engine.poll(force=True),
                '/api/manual-result':lambda:engine.manual_result(p),
                '/api/alerts-ack':lambda:engine.acknowledge_alerts(p),
                '/api/failures-dismiss':lambda:engine.dismiss_failures(p),   # 2026-11-03 발송실패 표시 지우기
                '/api/aligo-fallback':lambda:engine.manual_fallback(p),
                '/api/browser-window':lambda:engine.set_browser_window(p),
                '/api/ezadmin-main-chrome':lambda:engine.set_ezadmin_main_chrome(p),
                '/api/auto-ably-push':lambda:engine.set_auto_ably_push(p),
                '/api/auto-zigzag-push':lambda:engine.set_auto_zigzag_push(p),
                '/api/phone-alert':lambda:engine.phone_alert(p),
            }
            if path not in actions:self.respond(404,{'error':'지원되지 않는 작업'});return
            self.respond(200,actions[path]())
        except (ValidationError,ProviderError,UncertainError,SupplyError,ExternalError) as exc:self.respond(400,{'error':str(exc)})
        except (json.JSONDecodeError,UnicodeError,ValueError,TypeError):self.respond(400,{'error':'잘못된 입력입니다. 입력 항목을 다시 확인하세요.'})
        except Exception:self.respond(500,{'error':'내부 처리 오류입니다. 반복 발송하지 말고 이력과 전송내역을 확인하세요.'})

def main():
    p=argparse.ArgumentParser();p.add_argument('--data-dir');p.add_argument('--no-browser',action='store_true');p.add_argument('--port',type=int,default=0)
    args=p.parse_args()
    default=data_dir()
    directory=Path(args.data_dir or default).expanduser();directory.mkdir(parents=True,exist_ok=True,mode=0o700)
    os.umask(0o077)
    lock=ProcessLock(directory)
    if not lock.acquire():
        runtime=directory/'runtime.json'
        if runtime.exists():
            try:
                info=json.loads(runtime.read_text());url=info['url']
                if url.startswith('http://127.0.0.1:') and not args.no_browser:webbrowser.open(url)
            except Exception:pass
        print('배송안내 배포판이 이미 실행 중입니다. 기존 창을 사용하세요.');return
    complete_pending_reset(directory)
    store=Store(directory);engine=Engine(store);server=LocalServer(engine,args.port)
    runtime=directory/'runtime.json';runtime.write_text(json.dumps({'url':server.url,'pid':os.getpid()}));os.chmod(runtime,0o600)
    print('\n배송안내 배포판 v0.6.145')
    print(platform_name()+' 안에서 실행 중입니다. 이 터미널 창을 닫으면 예약 발송과 자동 결과 조회가 멈춥니다.')
    print('화면: '+server.origin+'  (화면이 안 열리면 실행 파일을 다시 여세요.)')
    print('저장: '+str(store.path));print('종료: Control + C\n',flush=True)
    engine.start_worker()
    if not args.no_browser:webbrowser.open(server.url)
    def shutdown(*_):threading.Thread(target=server.shutdown,daemon=True).start()
    signal.signal(signal.SIGINT,shutdown);signal.signal(signal.SIGTERM,shutdown)
    try:server.serve_forever(poll_interval=.3)
    finally:
        engine.stop_worker();server.server_close()
        if not engine.supply_watcher.running() and (not engine.thread or not engine.thread.is_alive()):store.close()
        runtime.unlink(missing_ok=True);lock.release()

if __name__=='__main__':main()
