﻿# 배송안내 배포판 (Windows) — 처음 한 번 설치. Python 설치/웹사이트 열기는 하지 않습니다. 주문·이력은 건드리지 않습니다.
# 네이티브 명령(pip 등)의 stderr 출력이 오류로 승격되지 않도록 Continue; 실패는 $LASTEXITCODE 로 판단한다.
$ErrorActionPreference='Continue'
try{[Console]::OutputEncoding=[System.Text.Encoding]::UTF8}catch{}
$Root=Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)   # 이 스크립트는 windows\ 안에 있다 → 앱 폴더는 한 단계 위 (10:09 보고)
Set-Location $Root
function Pause-Exit($code){ Write-Host ''; Read-Host '엔터를 누르면 이 창을 닫습니다' | Out-Null; exit $code }
Write-Host '배송안내 v0.6.141 배포판 (Windows) — 에이블리 동기화 · 주문 엑셀 자동 불러오기 · 반품/교환 · 품절 처리'
Write-Host '기존 배송안내 배포판은 먼저 종료하세요. 주문/문자 이력은 삭제하지 않습니다.'
$Data=Join-Path $env:LOCALAPPDATA 'NUAVU Delay Distribution'
New-Item -ItemType Directory -Force -Path $Data | Out-Null
# 1) Python 3.11~3.15 찾기 (py 런처 → python). 09:56 보고: PowerShell 5.1은 네이티브 명령에 큰따옴표를 그대로 못 넘겨 -c 검사가 깨짐 → 검사 코드를 파일로 실행.
$Tmp=Join-Path $env:TEMP 'nuavu-install'
New-Item -ItemType Directory -Force -Path $Tmp | Out-Null
$probeFile=Join-Path $Tmp 'probe.py'
@'
import sys,platform
v=sys.version_info
if sys.implementation.name!='cpython':sys.exit('CPython 아님: '+sys.implementation.name)
if not ((3,11)<=v[:2]<=(3,15)):sys.exit('버전 범위 밖: '+platform.python_version())
if v[3]!='final':sys.exit('개발/시험 버전: '+platform.python_version())
import ssl,sqlite3,venv,msvcrt
print('NUAVU_EXECUTABLE='+sys.executable)
'@ | Set-Content -Path $probeFile -Encoding UTF8
$checkFile=Join-Path $Tmp 'check.py'
@'
import webview, certifi, ssl, playwright.sync_api
ctx=ssl.create_default_context(); ctx.load_verify_locations(cafile=certifi.where())
assert ctx.check_hostname and ctx.verify_mode==ssl.CERT_REQUIRED
print('앱 구성요소·인증서 확인 완료')
'@ | Set-Content -Path $checkFile -Encoding UTF8
$py=$null
foreach($c in @(@('py','-3.13'),@('py','-3.12'),@('py','-3.11'),@('py','-3.14'),@('py','-3.15'),@('py','-3'),@('python'),@('python3'))){
  if(-not (Get-Command $c[0] -ErrorAction SilentlyContinue)){ Write-Host ("  "+($c -join ' ')+": 명령 없음"); continue }
  $extra=@(); if($c.Length -gt 1){ $extra=@($c[1..($c.Length-1)]) }
  $out=(& $c[0] @($extra+@('-I',$probeFile)) 2>&1 | Out-String)
  $line=($out -split "`r?`n" | Where-Object { $_ -match 'NUAVU_EXECUTABLE=' } | Select-Object -Last 1)
  if($LASTEXITCODE -eq 0 -and $line){ $py=$line.Substring($line.IndexOf('=')+1).Trim(); Write-Host ("  "+($c -join ' ')+": 사용 → "+$py); break }
  else { Write-Host ("  "+($c -join ' ')+": 제외 ("+(($out -split "`r?`n" | Where-Object { $_.Trim() } | Select-Object -Last 1))+")") }
}
if(-not $py){
  Write-Host 'Python 3.11~3.15 (python.org 64비트)를 찾지 못했습니다. 설치 후 "Add python.exe to PATH"를 켜고 다시 실행하세요.'
  try{ Write-Host '설치된 Python 목록 (py --list):'; & py --list 2>&1 | ForEach-Object { Write-Host ("  "+$_) } }catch{}
  Pause-Exit 1
}
Write-Host ("Python: "+$py)
# 2) 실행 중 확인 (running.lock)
$lock=Join-Path $Data 'running.lock'
if(Test-Path $lock){ try{ $fs=[System.IO.File]::Open($lock,'Open','ReadWrite','None'); $fs.Close() }catch{ Write-Host '배송안내 배포판이 실행 중입니다. 앱을 종료한 뒤 설치하세요.'; Pause-Exit 1 } }
# 3) 앱 전용 가상환경
$Venv=Join-Path $Data 'desktop-runtime-win'
$VPy=Join-Path $Venv 'Scripts\python.exe'
if(Test-Path $VPy){ & $VPy -I -c 'import sys; assert (3,11)<=sys.version_info[:2]<=(3,15)' 2>$null; if($LASTEXITCODE -ne 0){ $Venv=Join-Path $Data ('desktop-runtime-win-'+(Get-Date -Format yyyyMMddHHmmss)); $VPy=Join-Path $Venv 'Scripts\python.exe'; Write-Host '기존 실행환경은 보존하고 새 실행환경을 만듭니다.' } }
if(-not (Test-Path $VPy)){ & $py -I -m venv $Venv; if($LASTEXITCODE -ne 0){ Write-Host '가상환경을 만들지 못했습니다.'; Pause-Exit 1 } }
Write-Host '앱 창 구성요소(pywebview)·브라우저 자동화(playwright)·HTTPS 인증서 묶음을 설치/확인합니다. 인터넷 연결이 필요합니다.'
& $VPy -I -m pip install --disable-pip-version-check 'pywebview==6.2.1' 'playwright==1.64.0' certifi tzdata
if($LASTEXITCODE -ne 0){ Write-Host '구성요소 설치에 실패했습니다. 인터넷 연결을 확인하세요.'; Pause-Exit 1 }
& $VPy -I $checkFile
if($LASTEXITCODE -ne 0){ Write-Host '앱 구성요소 확인에 실패했습니다.'; Pause-Exit 1 }
# 4) WebView2 런타임 · Chrome 확인 (설치 사이트는 열지 않음)
$wv=$false
foreach($k in @('HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}','HKLM:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}','HKCU:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}')){ if(Test-Path $k){ $wv=$true } }
if(-not $wv){ Write-Host '주의: Microsoft Edge WebView2 런타임이 보이지 않습니다. 앱 창이 안 열리면 Microsoft 사이트에서 "WebView2 Runtime (Evergreen)"을 설치하세요. (Windows 11은 기본 포함)' }
$chrome=@("$env:ProgramFiles\Google\Chrome\Application\chrome.exe","${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe","$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if(-not $chrome){ Write-Host '주의: Google Chrome이 보이지 않습니다. 에이블리·이지어드민·지그재그·자사몰 자동화는 Chrome이 필요합니다.' } else { Write-Host ("Chrome: "+$chrome) }
# 5) 바탕화면 바로가기
$Desk=[Environment]::GetFolderPath('Desktop')
$lnk=Join-Path $Desk '배송안내 배포판.lnk'
$ws=New-Object -ComObject WScript.Shell
$sc=$ws.CreateShortcut($lnk)
$sc.TargetPath=Join-Path $Venv 'Scripts\pythonw.exe'
$sc.Arguments='"'+(Join-Path $Root 'desktop.py')+'"'
$sc.WorkingDirectory=$Root
$ico=Join-Path $Root 'assets\CS-Pink.ico'; if(Test-Path $ico){ $sc.IconLocation=$ico }
$sc.Description='배송안내 배포판 · 배송지연 / 품절 안내'
$sc.Save()
Write-Host ("바로가기: "+$lnk)
# 6) 실행
Start-Process -FilePath (Join-Path $Venv 'Scripts\pythonw.exe') -ArgumentList ('"'+(Join-Path $Root 'desktop.py')+'"') -WorkingDirectory $Root
Write-Host ''; Write-Host '설치 완료. 앞으로는 바탕화면의 "배송안내 배포판" 바로가기를 더블클릭하세요.'
Write-Host ('문제 확인: '+(Join-Path $Data 'logs\desktop.log'))
Pause-Exit 0
