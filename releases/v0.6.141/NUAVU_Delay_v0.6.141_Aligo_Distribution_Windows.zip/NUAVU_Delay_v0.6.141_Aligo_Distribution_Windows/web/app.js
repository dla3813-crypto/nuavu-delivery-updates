'use strict';
const $=id=>document.getElementById(id),C=NuavuImport,D=NuavuDispatchView;
let dispatchRange='';
let riskStage='watch';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const token=location.hash.slice(1)||sessionStorage.getItem('nuavuToken')||'';
if(token)sessionStorage.setItem('nuavuToken',token);history.replaceState(null,'',location.pathname);
let state=null,selected=new Set(),seller='',sheets=[],parsed=null,mapping={},plan=null,templates={},historyKey=null,manualId=null,busy=0,composeKeys=[],sending=false,composeType="delay",composeTemplateKey="first",composeAligoKey="first",composeChannelPreference="SMS";
const seenAlerts=new Set();
let importScope=[],importAvailable=[],importScopeVersion=0,importScopePersisted=0,importScopeSaving=false,importChoicePrefs={};
function selectedImportScope(){return [...$('scopeChecks').querySelectorAll('input:checked')].map(x=>x.value);}
function renderImportScope(){
 const sheet=sheets[Number($('sheetSelect').value)];
 const found=C.discoverSellers(sheet.rows,Number($('headerSelect').value),mapping);
 if(JSON.stringify(found)===JSON.stringify(importAvailable))return;
 importAvailable=found;
 importScope=C.rememberedSellers(found,{...state.settings,importSellerChoices:importChoicePrefs});
 $('scopeChecks').innerHTML=found.map(s=>`<label><input type="checkbox" value="${esc(s)}" ${importScope.includes(s)?'checked':''}>${esc(s)}</label>`).join('')||'<span>이 파일에서 내 쇼핑몰 판매처를 찾지 못했습니다. 쇼핑몰 이름과 판매처 열을 확인하세요.</span>';
 $('replaceConfirmed').checked=false;$('emptyImportConfirmed').checked=false;
 rememberVisibleChoices();importScopeVersion++;saveImportScope();
}
function rememberVisibleChoices(){
 const id=state.settings.shopName.normalize('NFC').replace(/\s+/g,'');
 const prefs=importChoicePrefs[id]??={};
 for(const label of importAvailable)prefs[label.replace(/\s+/g,'')]=importScope.includes(label);
}
async function saveImportScope(){
 if(importScopeSaving)return;importScopeSaving=true;
 try{
  while(importScopePersisted<importScopeVersion){
   const revision=importScopeVersion,scope=[...importScope],available=[...importAvailable];
   const r=await api('import-scope',{scopeLabels:true,available,scope,shopRevision:state.settings.shopRevision});importScopePersisted=revision;
   if(state)state.settings.importSellerChoices=r.choices;
  }
  $('scopeSaveState').textContent='판매처별 체크 저장됨 · 파일에 없는 판매처는 숨기고, 다시 나타나면 이전 체크를 복원합니다.';
 }catch(e){$('scopeSaveState').textContent='판매처 선택 저장 실패 · 체크를 다시 변경해 저장하세요.';toast(e.message,true);}
 finally{importScopeSaving=false;updateImportImpact();}
}

const orderCollator=new Intl.Collator('ko-KR',{numeric:true,sensitivity:'base'});
const names={WATCH_15S:'1차 결과 미확인',UNCONFIRMED_1M:'1분 결과 미확인',IMPORTED:'안내 처리 (무발송)',SCHEDULED:'예약 발송 대기',QUEUED:'발송 대기',PAUSED:'미요청 일시정지',SENDING:'요청 중',PENDING:'안내 처리 (접수)',UNKNOWN:'요청 결과 미확정',DELIVERED:'수신 성공 확인',FALLBACK_SMS:'알림톡 불가 → 문자 안내',FAILED:'전송 실패',CANCELLED:'미요청 취소'};
function toast(text,error=false){if(window.factoryResetStarted)return;$('toast').textContent=text;$('toast').classList.toggle('error',error);$('toast').hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').hidden=true,error?13000:6500);}
async function api(path,data){const r=await fetch('/api/'+path,{method:data===undefined?'GET':'POST',headers:{'X-NUAVU-Token':token,...(data===undefined?{}:{'Content-Type':'application/json'})},body:data===undefined?undefined:JSON.stringify(data)});const j=await r.json();if(!r.ok)throw Error(j.error||'요청 오류');return j;}
async function action(fn,button){if(button){button.disabled=true;}busy++;try{await fn();await refresh();}catch(e){toast(e.message,true);}finally{busy--;if(button){button.disabled=false;if(button.id==='orderExportBtn')renderSelection();if(button.id==='applyImportBtn')updateImportImpact();if(button.id==='reallocateManifestBtn')renderSupplyInformation();}if($('composeDialog').open)updateSendButton();}}
function dateTime(s,withSeconds=false){if(!s)return '—';const d=new Date(s);return Number.isNaN(d.valueOf())?s:new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',...(withSeconds?{second:'2-digit'}:{}),hour12:false}).format(d);}
function phoneLabel(p,full=false){p=String(p||'');if(!$('showPhone').checked&&!full)return p.length>=8?p.slice(0,3)+'-****-'+p.slice(-4):'번호 확인 필요';return p.length===11?p.slice(0,3)+'-'+p.slice(3,7)+'-'+p.slice(7):p;}
function tag(s){return `<span class="tag ${s==='IMPORTED'?'external':['DELIVERED','PENDING','FALLBACK_SMS'].includes(s)?'ok':['FAILED','UNCONFIRMED_1M'].includes(s)?'fail':s==='SCHEDULED'?'scheduled':['WATCH_15S','PENDING','UNKNOWN','SENDING','PAUSED'].includes(s)?'wait':''}">${esc(names[s]||'미발송')}</span>`;}
// Cards/dropdown use workflow buckets, not row background colors. A pending
// reservation preserves the previous notice's color without counting twice.
const noticeFilterBuckets={white:'unnotified',scheduled:'scheduled',green:'within',confirmed:'within_confirmed',yellow:'due_today',red:'overdue',failed:'failed',charcoal:'soldout'};
function matchesNoticeFilter(r,status){if(status==='charcoal')return r.noticeBucket==='soldout'||r.bucket==='soldout';return !(status in noticeFilterBuckets)||r.bucket===noticeFilterBuckets[status];} // 2026-10-20 대기 포함
function pendingReservation(n){return !n.isTest&&(n.status==='SCHEDULED'||(!!n.scheduledAt&&['PAUSED','QUEUED','SENDING'].includes(n.status)));}
function noticeCountLabel(r){return r.noticeCount?`${r.noticeCount}회 안내완료`:'안내 이력 없음';}
function orderDisplay(id){return (String(id||'').trim().toUpperCase().startsWith('C')?'[교환] ':'')+String(id||'');}
function rowNoticeLabel(r){
 const prior=({white:'접수된 안내 없음',green:'예정일 이내',confirmed:'예정일 이내(확정)',yellow:'예정일 당일',red:'예정일 초과',failed:'최근 안내 발송실패',charcoal:'품절 안내 완료(대기 포함)'})[r.color]||'';
 if(r.bucket!=='scheduled')return r.failedReason||prior;
 return r.noticeCount?prior+' · 재안내 예약':('예약발송대기 · '+(r.reservationState==='PAUSED'?'일시정지':'아직 접수 전'));
}
const L=NuavuOrderList;
let selectionAnchor=null,selectionOrder='';
const sortColumns=[['sellerSort','판매처','seller_asc','seller_desc'],['orderDateSort','주문일','oldest','newest'],['orderNumberSort','주문번호','ordernumber_asc','ordernumber_desc'],['productSort','상품명','product_asc','product_desc'],['optionSort','옵션','option_asc','option_desc'],['qtySort','수량','qty_asc','qty_desc'],['customerSort','고객명','customer_asc','customer_desc'],['phoneSort','연락처','phone_asc','phone_desc'],['dueSort','안내한 출고 예정일','due_asc','due_desc'],['noticeSort','안내 종류','notice_asc','notice_desc'],['receiptSort','출고 예상일자','receipt_asc','receipt_desc'],['recentSort','최근 안내 처리','recent_asc','recent_desc'],['noticeCountSort','횟수','noticecount_asc','noticecount_desc'],['matchingSort','상품 매칭','matching_asc','matching_desc']];
const sectionGroups={
 group_china:{title:'중국 취소건',description:'진행상황(AI) › 취소건 폴더의 판매처별 취소건 엑셀에서 새로 발견된(초록) 취소를 주문에 연결했습니다. 같은 상품·옵션의 취소가 다시 잡히면 1차 → 2차 → 3차, 진행상황에서 더 늦은 같은 상품 주문이 보이면 (N차)재발주로 표시합니다. 수량체크는 \'50件起\'·\'150장 부터\'처럼 최소 수량 때문에 발주가 안 된 상품입니다. 상품명만 같은 취소상품은 반짝이는 행에서 같은 상품인지 골라주세요.',children:[['china_all','전체'],['china_1','1차'],['china_2','2차'],['china_3','3차'],['china_qty','수량체크']]},
 group_manual:{title:'수동매칭',description:'수동매칭 권장: 주문 컬러명과 거래처 컬러명이 비슷하지만 달라 자동 연결되지 않은 주문입니다. 수동매칭 필요: 출고장·진행상황에는 있는데 연결된 주문이 없는 거래처 상품·옵션입니다 — 주문을 골라 연결하면 목록에서 사라집니다.',children:[['manual_recommended','수동매칭 권장'],['manual_needed','수동매칭 필요']]},
 white:{title:'안내 전',description:'아직 안내하지 않은 상품을 출고 예상일 계산 여부로 나눕니다. 일정 확정은 출고 예상일이 계산되었다는 뜻이며 실제 출고 완료를 뜻하지 않습니다.',children:[['white_dated','일정 확정'],['white_undated','일정 미확정']]},
 notice_needed:{title:'배송지연 메시지 발송 필요',description:'예정일 초과 또는 초과 예상 확정 상품을 재발송 필요로 모았습니다. 같은 주문번호는 재발송 필요를 우선합니다. 미확정 상품은 적용된 배송지연 안내 이력으로 구분합니다. 문자·에이블리 동기화·무발송 안내 처리 포함, 예약·실패·품절 안내만 있으면 이력 없음.',children:[['notice_resend','출고 예정일 재발송 필요'],['notice_undated_seen','출고 예정일자 (미확정) / 배송지연 메시지 이력 있음'],['notice_undated_new','출고 예정일자 (미확정) / 배송지연 메시지 이력 없음']]},
 
};
function groupFor(status){return Object.keys(sectionGroups).find(k=>sectionGroups[k].children.some(([s])=>s===status));}
function cardStatus(key){return sectionGroups[key]?.children[0][0]??key;}
let messageRowsRef=null,messageRowsCache=null;
function messageGroups(){
 if(messageRowsRef!==state?.rows){messageRowsRef=state?.rows;messageRowsCache=L.noticeGroups(state?.rows||[],D.unconfirmed,r=>D.delayRisk?D.delayRisk(r,'confirmed'):r.delayRiskStage==='confirmed');for(const key of ['notice_resend','notice_undated','notice_undated_seen','notice_undated_new'])messageRowsCache[key+'Keys']=new Set(messageRowsCache[key].map(r=>r.key));}
 return messageRowsCache;
}
function matchesSection(r,key){
 if(String(key).startsWith('china_'))return typeof chinaMatches==='function'&&chinaMatches(r,key);   // 2026-10-22 중국 취소건
 if(['notice_resend','notice_undated','notice_undated_seen','notice_undated_new'].includes(key))return messageGroups()[key+'Keys'].has(r.key);
 if(!r.active)return false;
 if(key==='white_dated'||key==='white_undated')return matchesNoticeFilter(r,'white')&&(D.hasDate(r)===(key==='white_dated'));
 if(key==='charcoal')return matchesNoticeFilter(r,key);
 if(key==='soldout_check')return !!r.soldoutCheck&&!r.soldoutCheckHidden;
 if(key==='manual_recommended')return D.manualRecommended(r);
 if(key==='manual_needed')return false;   // 거래처 상품 목록은 manual_needed.js 패널이 그린다
 return typeof matchesOperations==='function'?matchesOperations(r,key):false;
}
function renderSectionGroups(){
 const status=$('statusFilter').value,key=groupFor(status),panel=$('sectionGroupPanel');panel.hidden=!key;panel.classList.toggle('notice-pink-panel',['notice_resend','notice_undated_seen'].includes(status));
 for(const [group,config] of Object.entries(sectionGroups)){
  const rows=(state?.rows||[]).filter(r=>config.children.some(([s])=>matchesSection(r,s)));
  const count=$(group+'Count');if(count)count.textContent=(group==='notice_needed'?messageGroups().notice_resend.length:group==='group_bundle'?D.rowStats(rows).orders:rows.length).toLocaleString();
 }
 if(!key)return;
 $('activeFilter').disabled=true;
 const config=sectionGroups[key];$('sectionGroupTitle').textContent=config.title;$('sectionGroupDescription').textContent=config.description;
 const pool=state.rows.filter(r=>(!seller||r.seller===seller)&&C.matchesSearch(r,$('search').value.trim().toLocaleLowerCase(),$('searchField').value));
 const html=config.children.map(([s,label])=>{const stats=D.rowStats(pool.filter(r=>matchesSection(r,s)));const extra=s==='manual_needed'?`${(state?.supply?.unmatchedVariants||[]).length}개 거래처 상품·옵션`:`${stats.count}개 상품 · ${stats.orders}개 주문`;return `<button class="dispatch-chip ${['notice_resend','notice_undated_seen'].includes(s)?'notice-pink':''} ${s===status?'on':''}" data-section="${s}" aria-pressed="${s===status}"><b>${esc(label.split(' / ')[0])}</b>${label.includes(' / ')?'<em class="notice-history-label">'+esc(label.split(' / ')[1])+'</em>':''}<span>${extra}</span></button>`;}).join('');
 if($('sectionGroupChoices').innerHTML!==html)$('sectionGroupChoices').innerHTML=html;
 const stats=D.rowStats(filtered());$('sectionGroupSummary').textContent=`${(config.children.find(([s])=>s===status)?.[1]||'전체')} · ${stats.count}개 상품 / ${stats.orders}개 주문 / ${stats.quantity}개 수량`;
}

function filtered(){if(!state)return [];const q=$('search').value.trim().toLocaleLowerCase(),field=$('searchField').value,status=$('statusFilter').value,active=$('activeFilter').value;return state.rows.filter(r=>{
 if(String(status).startsWith('china_')&&!matchesSection(r,status))return false;
 if((['white_dated','white_undated','notice_resend','notice_undated','notice_undated_seen','notice_undated_new'].includes(status))&&!matchesSection(r,status))return false;
 if(seller&&r.seller!==seller)return false;if(active==='active'&&!r.active||active==='inactive'&&r.active)return false;
 if(!matchesNoticeFilter(r,status)||(status==='charcoal'&&!r.active))return false;
 if(status==='pending'&&!r.pending||status==='review'&&!r.review)return false;
 if(status==='watch'&&r.lastState!=='WATCH_15S')return false;
 if(status==='supply_unmatched'&&(!r.active||!r.supplyInfo?.matchNeeded))return false;
 if(status==='manual_recommended'&&!D.manualRecommended(r))return false;
 if(status==='manual_needed')return false;
 if(status==='delay_risk'&&!D.delayRisk(r,riskStage))return false;
 if(status==='dispatch_dated'&&!D.plannedMatches(r,{source:$('dispatchSource').value,day:$('dispatchDay').value,rangeKey:dispatchRange}))return false;
 if(status==='dispatch_undated'&&!D.unconfirmed(r))return false;
 if(status==='exchange'&&!D.exchange(r))return false;
 return C.matchesSearch(r,q,field);
}).sort(compareOrders);}
let displayBundleKeys=new Set();
function displayBundle(r){return displayBundleKeys.has(r.key);}
function compareOrders(a,b){return L.compareRows({...a,isBundle:displayBundle(a)},{...b,isBundle:displayBundle(b)},$('sortOrder').value,D,rowNoticeLabel,!!state?.supply?.lastReadAt);}
function renderSortHeads(){
 const mode=$('sortOrder').value;
 for(const [id,label,asc,desc] of sortColumns){
  const b=$(id);b.textContent=label+(mode===asc?' ↑':mode===desc?' ↓':' ↕');
  b.setAttribute('aria-pressed',String(mode===asc||mode===desc));
  b.title=label+' 정렬 · '+(mode===asc?'현재 오름차순':mode===desc?'현재 내림차순':'클릭하면 오름차순')+(id==='matchingSort'?' · 권장 → 연결 필요 → 수동 연결 → 자동 연결 → 자료 미반영':'');
 }
}
// This panel is an overlapping lookup, not a new status or a notice action.
function resetDispatchDate(){dispatchRange='';$('dispatchDay').value='';}
function dispatchScopeRows(){
 const q=$('search').value.trim().toLocaleLowerCase(),field=$('searchField').value;
 return (state?.rows||[]).filter(r=>(!seller||r.seller===seller)&&C.matchesSearch(r,q,field)&&D.plannedMatches(r,{source:$('dispatchSource').value}));
}
function dispatchRangeLabel(start,end){
 const a=shortDay(start),b=shortDay(end);
 return start===end?start.slice(0,4)+'년 '+a:start.slice(0,4)+'년 '+a+' ~ '+(start.slice(0,4)!==end.slice(0,4)?end.slice(0,4)+'년 ':'')+b;
}
function renderDispatchPanel(){
 const on=$('statusFilter').value==='dispatch_dated',undated=$('statusFilter').value==='dispatch_undated';
 $('dispatchPanel').hidden=!on;$('dispatchUndatedPanel').hidden=!undated;
 const recommended=$('statusFilter').value==='manual_recommended';
 $('manualMatchPanel').hidden=!recommended;
 const riskOn=$('statusFilter').value==='delay_risk';$('delayRiskPanel').hidden=!riskOn;
 $('activeFilter').disabled=on||undated||recommended||riskOn||$('statusFilter').value==='exchange'; // Current-only lookup cards.
 if(riskOn)renderRiskPanel();
 if(recommended){
   const stats=D.rowStats(filtered());
   $('manualMatchSummary').textContent=`${stats.count}개 상품 / ${stats.orders}개 주문 / ${stats.quantity}장${!stats.count?' · 현재 조건에 수동매칭을 권장할 상품이 없습니다.':''}`;
 }
 if(undated){
   const stats=D.rowStats(filtered());
   $('dispatchUndatedSummary').textContent=`${stats.count}개 상품 / ${stats.orders}개 주문 / ${stats.quantity}장${!stats.count?' · 현재 조건에 사무실 도착일 미확정 상품이 없습니다.':''}`;
 }
 if(!on)return;
 const pool=dispatchScopeRows(),groups=D.groups(pool),stats=D.plannedStats(pool);
 const visible=pool.filter(r=>D.plannedMatches(r,{day:$('dispatchDay').value,rangeKey:dispatchRange})),shown=D.plannedStats(visible);
 // Do not destroy the focused button every five-second state refresh.
 const html=`<button class="dispatch-chip ${!dispatchRange&&!$('dispatchDay').value?'on':''}" data-range="" aria-pressed="${!dispatchRange&&!$('dispatchDay').value}"><b>전체 예정</b><span>${stats.count}개 상품</span></button>`+groups.map(g=>`<button class="dispatch-chip ${dispatchRange===g.key?'on':''}" data-range="${esc(g.key)}" aria-pressed="${dispatchRange===g.key}"><b>${esc(dispatchRangeLabel(g.start,g.end))}</b><span>${g.count}개 상품 · ${g.orders}개 주문 · ${g.quantity}장</span><small>출고장 확보 ${g.secured} · 전량 미확보 ${g.progress}</small></button>`).join('')+(stats.undated?`<button class="dispatch-chip ${dispatchRange==='__undated__'?'on':''}" data-range="__undated__" aria-pressed="${dispatchRange==='__undated__'}"><b>출고일 계산 대기</b><span>${stats.undated}개 상품</span><small>V 도착일 있음 · 수량/주문 확인</small></button>`:'');
 if($('dispatchGroups').innerHTML!==html)$('dispatchGroups').innerHTML=html;
 const group=groups.find(g=>g.key===dispatchRange);
 const choice=$('dispatchDay').value?shortDay($('dispatchDay').value)+' 포함 일정':dispatchRange==='__undated__'?'출고일 계산 대기':dispatchRange?(group?dispatchRangeLabel(group.start,group.end):'선택 일정 · 현재 조건 0건'):'전체 예정';
 $('dispatchSelectionSummary').textContent=`${choice} · ${shown.count}개 상품 / ${shown.orders}개 주문 / ${shown.quantity}장 · 날짜 계산 ${shown.dated}개 / 계산 대기 ${shown.undated}개 · 출고장 전량 확보 ${shown.secured}개${!pool.length?' · 현재 조건에 V 도착일이 확인된 상품이 없습니다.':''}`;
}
function riskScopeRows(){
 const q=$('search').value.trim().toLocaleLowerCase(),field=$('searchField').value;
 return (state?.rows||[]).filter(r=>(!seller||r.seller===seller)&&C.matchesSearch(r,q,field)&&D.delayRisk(r));
}
function renderRiskPanel(){
 const scope=riskScopeRows(),rows=filtered(),stats=D.rowStats(rows),missing=rows.reduce((n,r)=>n+r.delayRisk.shortQty,0);
 $('riskWatchCount').textContent=scope.filter(r=>D.delayRisk(r,'watch')).length.toLocaleString();
 $('riskConfirmedCount').textContent=scope.filter(r=>D.delayRisk(r,'confirmed')).length.toLocaleString();
 for(const b of $('delayRiskTabs').querySelectorAll('button'))b.setAttribute('aria-pressed',String(b.dataset.riskStage===riskStage));
 const refreshCount=rows.filter(r=>r.delayRisk.needsRefresh).length;
 $('delayRiskSummary').textContent=`${riskStage==='watch'?'감시 (당일 오후 4시 마감)':'확정'} · ${stats.count}개 상품 / ${stats.orders}개 주문 · 부족 ${missing}개${refreshCount?' · 갱신 대기 '+refreshCount+'개 상품':''}${!stats.count?' · 현재 조건에 해당하는 상품이 없습니다.':''}`;
 $('delayRiskReadAt').textContent=state.delayRiskSummary?.dataReady?`자료 기준: ${dateTime(state.delayRiskSummary.lastReadAt)} 수동갱신 · 오늘 ${state.today} (한국 시간)`:'선택 브랜드의 공급 자료를 먼저 수동갱신하세요.';
}
$('delayRiskTabs').onclick=e=>{const b=e.target.closest('button[data-risk-stage]');if(!b)return;riskStage=b.dataset.riskStage;changeFilter();};
function chooseRiskStage(){riskStage=state.rows.some(r=>D.delayRisk(r,'watch'))?'watch':'confirmed';}
$('dispatchGroups').onclick=e=>{const b=e.target.closest('button[data-range]');if(!b)return;dispatchRange=b.dataset.range;$('dispatchDay').value='';changeFilter();};
$('dispatchDay').onchange=()=>{dispatchRange='';changeFilter();};
$('dispatchSource').onchange=()=>{resetDispatchDate();changeFilter();};
$('dispatchClear').onclick=()=>{resetDispatchDate();changeFilter();};
function render(){if(!state)return;$('supplyBtn').classList.toggle('needs-folder',!state.supply?.folder);displayBundleKeys=NuavuDashboard.bundleRows(state.rows);renderShopState();renderDispatchPanel();const active=state.rows.filter(r=>r.active);$('totalCount').textContent=active.length.toLocaleString();$('orderCount').textContent=new Set(active.map(r=>r.seller+'|'+r.orderId)).size+'개 주문';for(const status of Object.keys(noticeFilterBuckets)){const count=$(status+'Count');if(count)count.textContent=(status==='failed'?state.rows:active).filter(r=>matchesNoticeFilter(r,status)).length.toLocaleString();}
 $('dispatchCount').textContent=state.rows.filter(D.planned).length.toLocaleString();
 if($('exchangeCount'))$('exchangeCount').textContent=state.rows.filter(D.exchange).length.toLocaleString();

 $('manualMatchCount').textContent=state.rows.filter(D.manualRecommended).length.toLocaleString();
 const riskWatch=state.rows.filter(r=>D.delayRisk(r,'watch')).length,riskConfirmed=state.rows.filter(r=>D.delayRisk(r,'confirmed')).length;
 $('delayRiskCount').textContent=(riskWatch+riskConfirmed).toLocaleString();$('delayRiskCounts').textContent=`감시 ${riskWatch.toLocaleString()} · 확정 ${riskConfirmed.toLocaleString()}`;
 for(const c of document.querySelectorAll('.card[data-color],#failedBtn')){const on=(c.dataset.color===$('statusFilter').value||c.dataset.color===groupFor($('statusFilter').value));c.classList.toggle('is-active',on);c.setAttribute('aria-pressed',String(on));}
 if(state.desktopMode){$('notifyPermissionBtn').hidden=true;$('connection').textContent='독립 앱 · 내 맥에 저장';}
 renderSectionGroups();renderDashboardSummary();
 const rows=filtered();const rowOrder=JSON.stringify(rows.filter(r=>r.active).map(r=>r.key));if(rowOrder!==selectionOrder){selectionAnchor=null;selectionOrder=rowOrder;}
 for(const r of state.rows)r.selectable=!!(r.active||(r.color==='failed'&&$('statusFilter').value==='failed'));   // 2026-11-03: 발송실패 필터에서 목록 제외 행도 선택 가능
 $('rows').innerHTML=rows.map(r=>`<tr class="${typeof chinaRowClass==='function'?chinaRowClass(r):''} row-${r.color} ${D.exchange(r)?'row-exchange':''} ${r.active?'':'row-inactive'}"><td><input class="rowcheck" type="checkbox" data-key="${esc(r.key)}" aria-label="주문상품 선택" ${selected.has(r.key)?'checked':''} ${r.selectable?'':'disabled'}></td><td>${esc(r.sourceSeller||r.seller.replace('누아브 ',''))}<span class="secondary">${esc(r.orderDate||'—')}</span></td><td class="orderid ${displayBundle(r)?'bundle-number':''}" title="${esc((r.orderItems||[]).length?'상품주문번호: '+r.orderItems.map(x=>x.id).join(', '):'')}">${displayBundle(r)?'<b class="bundle-label">(합포)</b> ':''}${D.exchange(r)?'<span class="exchange-label">[교환]</span> ':''}${esc(r.orderId)}</td><td><span class="productname">${esc(r.product)}</span><span class="secondary">${esc(r.option)}${r.review?' · <b class="dangertext">주문정보 변경 확인 필요</b>':''}</span>${typeof chinaCell==='function'?chinaCell(r):''}</td><td>${r.qty}</td><td>${esc(r.buyer||r.recipient||'고객님')}<span class="secondary">${esc(phoneLabel(r.phone))}${r.needsPhoneApproval?' · 대체번호':''}</span></td><td class="date-${r.color}">${esc(r.soldoutNotified?'품절 안내':r.dueDate||'—')}<span class="secondary">${esc(rowNoticeLabel(r))}${r.dueDateSource==='ably_sync'?' · 에이블리 동기화':r.dueDateSource==='zigzag_sync'?' · 지그재그 동기화':r.dueDateSource==='pending_message'?' · 예약·대기 반영':r.dueDateSource==='zigzag_default'?' · 지그재그 발송 예정일 · 메시지 없는 안내 (주문 수집 시 자동)':''}${!r.active?' · 목록 제외':''}</span></td><td>${receiptCell(r)}</td><td>${r.externalHistory?'외부 안내 · 발송일 미제공':dateTime(r.lastNoticeAt)}<span class="secondary">${esc(noticeCountLabel(r))}</span></td><td>${tag(r.reservationState||r.lastState)}${r.scheduledAt?'<span class="secondary">예약 '+esc(dateTime(r.scheduledAt))+'</span>':''}</td><td><button class="tiny rowhistory" data-key="${esc(r.key)}">이력</button>${pickupButton(r)}${typeof refundButton==='function'?refundButton(r):''}</td><td class="matching-cell">${matchingCell(r)}</td></tr>`).join('');
 $('empty').hidden=rows.length>0;if(!rows.length)$('empty').innerHTML=state.rows.length?'<b>검색 조건에 맞는 주문이 없습니다.</b><p>판매처와 안내 상태를 다시 확인하세요.</p>':'<b>주문 엑셀을 불러와 시작하세요.</b><p>설정한 쇼핑몰의 에이블리 · 자사몰 · 지그재그 주문을 반영합니다.</p>';
 const allowed=new Set(state.rows.filter(r=>(r.active||(r.color==='failed'&&$('statusFilter').value==='failed'))&&(!['white_dated','white_undated','notice_resend','notice_undated','notice_undated_seen','notice_undated_new'].includes($('statusFilter').value)||matchesSection(r,$('statusFilter').value))).map(r=>r.key));selected=new Set([...selected].filter(k=>allowed.has(k)));renderSelection();
 const imp=state.imports.at(-1);$('importStamp').textContent=imp?`${dateTime(imp.at)} · ${imp.fileName} · 추가 ${imp.added} / 갱신 ${imp.updated} / 목록 제외 ${imp.inactive}${imp.removedSoldout?' / 품절 상품 삭제 '+imp.removedSoldout:''}`:'엑셀을 불러오세요. 고객 주문은 예제로 내장하지 않았습니다.';
 const ns=state.notices;const q=ns.filter(n=>['QUEUED','PAUSED'].includes(n.status)&&!pendingReservation(n)).length,reserved=ns.filter(pendingReservation),p=ns.filter(n=>['PENDING','UNKNOWN','SENDING'].includes(n.status)&&!pendingReservation(n)).length;$('queueSummary').textContent=`예약발송대기 ${reserved.length}건 · 미요청/일시정지 ${q}건 · 최종 결과 조회 대기 ${p}건 · 추가 감시 ${ns.filter(n=>n.resultReview==='WATCH_15S'&&['PENDING','UNKNOWN'].includes(n.status)).length}건 · 확정 실패 ${ns.filter(n=>n.status==='FAILED'&&!n.fallbackSmsOk).length}건 / 1분 미확인 ${ns.filter(n=>n.displayStatus==='UNCONFIRMED_1M').length}건`;
 $('pollNote').textContent=state.pollNote||'접수 15초 후 1차 확인, 1분에도 미확인이면 발송실패 칸에 별도 표시합니다. 실제 실패 확정과 구분하며 자동 재발송하지 않습니다.';$('dataPath').textContent='로컬 저장 · '+state.dataPath;
 renderAccountState();renderAligoState();renderDesktopBackup();renderSupplyState();
 $('connection').textContent=state.desktopMode?'독립 앱 · 내 맥에 저장':'내 맥에 저장';$('connection').classList.remove('offline');
 renderSortHeads();
 renderAlerts();renderScheduleBanner();if($('historyDialog').open)renderHistory();if($('composeDialog').open)updateSendButton();}

function renderDesktopBackup(){
 const b=state?.desktopBackup||{};
 
 $('desktopBackupBanner').hidden=!b.error;
 $('desktopBackupError').textContent=b.error||'';
 $('desktopBackupState').textContent=b.enabled?`바탕화면 백업 · ${b.path} · ${b.lastSavedAt?dateTime(b.lastSavedAt)+' 저장':'저장 대기'} · iCloud 업로드 완료는 Finder 확인`:'';
}
const saveDesktopBackup=()=>action(async()=>{const r=await api('desktop-backup',{});toast(r.message,!!r.error);},$('retryDesktopBackupBtn'));
$('retryDesktopBackupBtn').onclick=saveDesktopBackup;

function renderScheduleBanner(){
 const active=state.notices.filter(pendingReservation);
 const waiting=active.filter(n=>n.status!=='PAUSED'),paused=active.length-waiting.length;
 const first=waiting.map(n=>n.scheduledAt).filter(Boolean).sort((a,b)=>Date.parse(a)-Date.parse(b))[0];
 $('scheduleBanner').hidden=!active.length;
 $('scheduleHeadline').textContent=`예약발송대기 ${active.length}건${first?' · 발송 시작 '+dateTime(first):''}${paused?' · 일시정지 '+paused+'건 (계정 대기 또는 확인 필요)':''}`;
}
$('scheduleHistoryBtn').onclick=()=>openHistory();
function renderSelection(){const visible=filtered().filter(r=>r.active),vis=new Set(visible.map(r=>r.key));const hidden=[...selected].filter(k=>!vis.has(k)).length;$('selectionCount').textContent=`${selected.size}개 선택됨${hidden?' (검색 밖 '+hidden+'개 포함)':''}`;$('selectionFloating').hidden=!selected.size;$('selectionFloatingCount').textContent=$('selectionCount').textContent;$('composeBtn').disabled=!selected.size;$('noSendBtn').disabled=!selected.size;$('orderExportBtn').disabled=!filtered().length;$('checkAll').checked=visible.length>0&&visible.every(r=>selected.has(r.key));if(typeof renderCancelOnly==='function')renderCancelOnly();if(typeof renderFailedDismiss==='function')renderFailedDismiss();}
$('selectionReturn').onclick=()=>$('selectionCount').closest('.toolbar').scrollIntoView({behavior:'smooth',block:'center'});
let lastFullRefresh=0;   // 09:05 CPU 최적화: 전체 상태는 revision이 바뀌었을 때(또는 60초마다)만 다시 받는다
async function refresh(){if(window.factoryResetStarted)return;try{const next=await api('state');if(window.factoryResetStarted)return;state=next;lastFullRefresh=Date.now();render();window.dispatchEvent(new CustomEvent('nuavu-state'));}catch(e){if(window.factoryResetStarted)return;$('connection').textContent='연결 끊김';$('connection').classList.add('offline');if(!state)toast(e.message+' 실행 파일로 화면을 열어주세요.',true);}}
function changeFilter(clear=true){selectionAnchor=null;if(clear)selected.clear();render();}
$('rows').addEventListener('click',e=>{if(!e.target.classList.contains('rowcheck')||e.target.disabled)return;
 const key=e.target.dataset.key;selected=L.rangeSelection(filtered(),selected,selectionAnchor,key,e.target.checked,e.shiftKey);
 if(!e.shiftKey||!selectionAnchor)selectionAnchor=key;
 for(const box of $('rows').querySelectorAll('.rowcheck'))box.checked=selected.has(box.dataset.key);
 renderSelection();
});
$('rows').addEventListener('click',e=>{const b=e.target.closest('.rowhistory');if(b)openHistory(b.dataset.key);const p=e.target.closest('.rowpickup');if(p){const row=state.rows.find(x=>x.key===p.dataset.key);if(!window.openPickup)return toast('회수접수는 설치한 맥 앱에서 사용할 수 있습니다.',true);const rec=row&&pickupRecordFor(row);window.openPickup(rec||(row?{invoice:'',recipient:row.recipient||row.buyer||'',recipientPhone:row.phone||''}:null));}});
// 회수접수 from the order table: an order row whose return/exchange record (반품/교환 조회 결과) carries the
// original invoice can open the pickup dialog pre-filled. Matching: same 상품주문번호 first, then the order
// number without the exchange 'C' prefix. Nothing is submitted here; the pickup dialog keeps its own checks.
function pickupRecordFor(r){
 const pool=[...(state?.returns?.rows||[]),...(state?.returns?.exchangeRows||[])].filter(x=>x.invoice);
 if(!pool.length)return null;
 const norm=id=>String(id||'').trim().toUpperCase().replace(/^C/,'');
 const items=new Set((r.orderItems||[]).map(x=>String(x.id)).concat(r.orderItemId?[String(r.orderItemId)]:[]));
 return pool.find(x=>x.itemId&&items.has(String(x.itemId)))||pool.find(x=>norm(x.orderId)===norm(r.orderId))||null;
}
function pickupButton(r){
 const rec=pickupRecordFor(r);
 // 2026-10-19: 회수접수 is reachable from every dashboard card. Without a return/exchange record the dialog opens with
 // the customer prefilled and the 원송장 left for the user to type.
 if(!rec)return `<button class="tiny rowpickup rowpickup-blank" data-key="${esc(r.key)}" title="반품/교환 조회 결과에 원송장이 없습니다. 고객명·연락처만 채워서 엽니다.">회수접수</button>`;
 const done=(rec.pickupHistory||[]).filter(h=>h.attempt);const last=done[done.length-1];
 const label=last?'회수 '+last.attempt+'차 · '+(last.result||'확인'):'회수접수';
 return `<button class="tiny rowpickup${last?' rowpickup-done':''}" data-key="${esc(r.key)}" title="원송장 ${esc(rec.invoice)} · ${esc(rec.kind==='exchange'?'교환':'반품')} 조회 결과 기준">${esc(label)}</button>`;
}

$('sellerTabs').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;seller=b.dataset.seller;for(const x of $('sellerTabs').querySelectorAll('button'))x.classList.toggle('on',x===b);changeFilter();});
$('search').addEventListener('input',()=>changeFilter(false));for(const id of ['searchField','activeFilter'])$(id).addEventListener('change',()=>changeFilter());
$('statusFilter').addEventListener('change',()=>{resetDispatchDate();if(groupFor($('statusFilter').value))$('activeFilter').value='active';if($('statusFilter').value==='delay_risk')chooseRiskStage();if(['dispatch_dated','dispatch_undated','exchange','manual_recommended','delay_risk'].includes($('statusFilter').value))$('activeFilter').value='active';if($('statusFilter').value==='dispatch_dated')$('sortOrder').value='receipt_asc';changeFilter();});$('showPhone').addEventListener('change',render);$('sortOrder').addEventListener('change',()=>{selectionAnchor=null;render();});for(const [id,label,asc,desc] of sortColumns)$(id).onclick=()=>{selectionAnchor=null;$('sortOrder').value=$('sortOrder').value===asc?desc:asc;render();};
for(const b of document.querySelectorAll('.card[data-color],#failedBtn'))b.addEventListener('click',()=>{$('statusFilter').value=cardStatus(b.dataset.color);if(b.dataset.color==='delay_risk')chooseRiskStage();$('activeFilter').value=b.dataset.color==='failed'?'all':'active';resetDispatchDate();if(b.dataset.color==='dispatch_dated')$('sortOrder').value='receipt_asc';if(b.dataset.color==='exchange')$('sortOrder').value='oldest';changeFilter();});
$('sectionGroupChoices').onclick=e=>{const b=e.target.closest('[data-section]');if(!b)return;$('statusFilter').value=b.dataset.section;$('activeFilter').value='active';resetDispatchDate();changeFilter();};
$('resetBtn').onclick=()=>{resetDispatchDate();$('dispatchSource').value='all';$('search').value='';$('statusFilter').value='';$('activeFilter').value='active';$('searchField').value='all';seller='';for(const b of $('sellerTabs').querySelectorAll('button'))b.classList.toggle('on',!b.dataset.seller);changeFilter();};
$('selectAllBtn').onclick=()=>{selectionAnchor=null;for(const r of filtered())if(r.active||(r.color==='failed'&&$('statusFilter').value==='failed'))selected.add(r.key);render();};$('clearBtn').onclick=()=>{selectionAnchor=null;selected.clear();render();};$('checkAll').onchange=e=>{selectionAnchor=null;for(const r of filtered())if(r.active)e.target.checked?selected.add(r.key):selected.delete(r.key);render();};
$('reviewBtn').onclick=()=>action(async()=>{if(!selected.size)throw Error('확인할 상품을 선택하세요.');if(!confirm('선택 상품의 수량·연락처 변경을 원본과 비교해 확인했나요?'))return;await api('review',{keys:[...selected]});toast('변경 내용을 확인 처리했습니다.');},$('reviewBtn'));
for(const b of document.querySelectorAll('[data-close]'))b.onclick=()=>$(b.dataset.close).close();
async function loadOrderFile(f){if(!f)return;if(importScopeSaving||importScopePersisted<importScopeVersion)throw Error('판매처 선택 저장을 완료한 뒤 파일을 다시 열어주세요.');const normalName=f.name.normalize('NFKC');if(/에이블리.*발송\s*관리/i.test(normalName)&&/\.xlsx$/i.test(normalName)){externalFileData=await readImportBytes(f);$('externalFileName').textContent=f.name;invalidateExternal();$('externalDialog').showModal();$('fileInput').value='';toast('에이블리 발송관리 파일은 메시지 없는 안내 반영 창으로 열었습니다. 현재 미출고 목록은 교체하지 않습니다.');return;}$('fileName').textContent=f.name;sheets=await NuavuExcel.read(await f.arrayBuffer(),f.name);if(!sheets.length)throw Error('읽을 수 있는 시트가 없습니다.');$('sheetSelect').innerHTML=sheets.map((s,i)=>`<option value="${i}">${esc(s.name)}</option>`).join('');$('importMode').value='snapshot';$('replaceConfirmed').checked=false;$('emptyImportConfirmed').checked=false;$('scopeBox').hidden=false;importAvailable=null;importChoicePrefs=JSON.parse(JSON.stringify(state.settings.importSellerChoices||{}));configureSheet();$('importDialog').showModal();$('fileInput').value='';}
function configureSheet(){const s=sheets[Number($('sheetSelect').value)];const best=C.findHeader(s.rows);$('headerSelect').innerHTML=s.rows.slice(0,25).map((r,i)=>`<option value="${i}">${i+1}행 · ${esc(r.slice(0,3).join(' / '))}</option>`).join('');$('headerSelect').value=best;configureMapping();}
const fieldNames={seller:'판매처 *',orderId:'주문번호 *',orderItemId:'에이블리 상품주문번호 (M열 주문 상세번호)',product:'상품명 *',option:'옵션',qty:'수량',orderDate:'주문일',buyer:'주문자명',recipient:'수령자명',phone:'주문자 연락처',altPhone:'수령자 대체 연락처'};
function configureMapping(){const headers=sheets[Number($('sheetSelect').value)].rows[Number($('headerSelect').value)]||[];mapping=C.guessMapping(headers);$('mapping').innerHTML=Object.keys(fieldNames).map(k=>`<label>${fieldNames[k]}<select data-map="${k}"><option value="-1">사용 안 함</option>${headers.map((h,i)=>`<option value="${i}" ${mapping[k]===i?'selected':''}>${esc(h||('열 '+(i+1)))}</option>`).join('')}</select></label>`).join('');parseImport();}
function parseImport(){
 renderImportScope();
 const sheet=sheets[Number($('sheetSelect').value)],scope=selectedImportScope();
 parsed=C.parseRows(sheet.rows,Number($('headerSelect').value),mapping,{scope,scopeLabels:true,strictShop:true});
 const req=['seller','orderId','product'].filter(k=>mapping[k]<0);
 const errors=[...(!state?.settings?.shopName?['쇼핑몰 이름을 먼저 설정하세요.']:[]),...req.map(k=>fieldNames[k]+' 열을 지정하세요.'),...parsed.errors.map(x=>x.line+'행: '+x.message)];
 const orders=new Set(parsed.rows.map(r=>r.seller+'|'+r.orderId));
 const counts=scope.map(s=>s+' '+parsed.rows.filter(r=>C.inSourceScope(r,[s])).length+'개').join(' · ');
 $('importSummary').textContent=`선택한 판매처 반영 대상 ${parsed.rows.length}개 상품 / ${orders.size}개 주문. ${counts}. 에이블리 상세번호 ${parsed.rows.filter(r=>r.seller===C.SELLERS[0]&&(r.orderItems||[]).length).length}/${parsed.rows.filter(r=>r.seller===C.SELLERS[0]).length}개 상품 확인. 다른 쇼핑몰·미선택 판매처 제외: ${Object.entries(parsed.excluded).map(([s,n])=>s+' '+n+'행').join(', ')||'없음'}`;
 $('importErrors').hidden=!errors.length;$('importErrors').textContent=errors.slice(0,30).join('\n');parsed.uiErrors=errors;
 updateImportImpact();
}
$('sheetSelect').onchange=configureSheet;$('headerSelect').onchange=configureMapping;$('mapping').onchange=e=>{if(e.target.dataset.map){mapping[e.target.dataset.map]=Number(e.target.value);parseImport();}};$('importMode').onchange=()=>{$('snapshotOptions').hidden=$('importMode').value!=='snapshot';$('replaceConfirmed').checked=false;$('emptyImportConfirmed').checked=false;updateImportImpact();};
function updateImportImpact(){
 $('supplySnapshotWarning').hidden=!($('importMode').value==='snapshot'&&(state?.supply?.batches||[]).some(b=>!b.closed));
 if(!parsed)return;
 $('snapshotOptions').hidden=$('importMode').value!=='snapshot';
 const snapshot=$('importMode').value==='snapshot',scope=[...$('scopeChecks').querySelectorAll('input:checked')].map(x=>x.value),keys=new Set(parsed.rows.map(r=>r.key));
 const removed=(state?.rows||[]).filter(r=>r.active&&C.inSourceScope(r,scope)&&!keys.has(r.key)),missing=new Set(removed.map(r=>r.key));
 const cancel=(state?.notices||[]).filter(n=>['QUEUED','SCHEDULED','PAUSED'].includes(n.status)&&n.itemKeys.some(k=>missing.has(k)));
 const soldoutRemoved=removed.filter(r=>r.removeIfExcludedSoldout).length;
 const zero=scope.filter(s=>!parsed.rows.some(r=>C.inSourceScope(r,[s])));
 $('importImpact').textContent=`현재 목록에서 제외할 상품 ${removed.length}개 / 주문 ${new Set(removed.map(r=>r.seller+'|'+r.orderId)).size}개 · 취소할 미요청/예약 문자 ${cancel.length}통. 제외된 품절 상품 ${soldoutRemoved}개는 품절·보관 목록에 남기지 않습니다. 전송 이력은 유지합니다.${zero.length?' 파일에 0건인 판매처: '+zero.join(', ')+'. 이 판매처의 기존 상품도 제외됩니다.':''}`;
 $('emptyImportBox').hidden=!snapshot||parsed.rows.length>0;
 $('applyImportBtn').disabled=importScopeSaving||importScopePersisted<importScopeVersion||!scope.length||!!parsed.uiErrors.length||(!parsed.rows.length&&!snapshot)||(snapshot&&(!$('replaceConfirmed').checked||!scope.length||(!parsed.rows.length&&!$('emptyImportConfirmed').checked)));
}
$('scopeChecks').onchange=()=>{importScope=selectedImportScope();rememberVisibleChoices();importScopeVersion++;$('scopeSaveState').textContent='판매처 선택 저장 중…';$('replaceConfirmed').checked=false;$('emptyImportConfirmed').checked=false;parseImport();saveImportScope();};$('replaceConfirmed').onchange=updateImportImpact;$('emptyImportConfirmed').onchange=updateImportImpact;

$('applyImportBtn').onclick=()=>action(async()=>{if(!parsed)throw Error('엑셀을 선택하세요.');if(importScopeSaving||importScopePersisted<importScopeVersion)throw Error('판매처 선택 저장을 완료해주세요.');const r=await api('import',{scopeLabels:true,available:[...importAvailable],scopeFilter:true,shopRevision:state.settings.shopRevision,rows:parsed.rows,excluded:parsed.excluded,mode:$('importMode').value,scope:[...$('scopeChecks').querySelectorAll('input:checked')].map(x=>x.value),replaceConfirmed:$('replaceConfirmed').checked,emptyConfirmed:$('emptyImportConfirmed').checked,parseErrors:parsed.uiErrors,fileName:$('fileName').textContent});$('importDialog').close();selected.clear();toast(`불러오기 완료 · 신규 ${r.added} / 갱신 ${r.updated} / 목록 제외 ${r.inactive} / 예약·미요청 취소 ${r.cancelled||0}통 / 품절 상품 삭제 ${r.removedSoldout||0}개`);},$('applyImportBtn'));
$('settingsBtn').onclick=()=>{if(!state)return;$('smsUser').value=state.settings.smsUser||'';$('sender').value=state.settings.sender||'';$('smsApiKey').value='';$('settingsResult').textContent='';$('settingsDialog').showModal();};
$('saveSettingsBtn').onclick=()=>action(async()=>{const r=await api('settings',{user:$('smsUser').value,apikey:$('smsApiKey').value,sender:$('sender').value});$('smsApiKey').value='';$('settingsResult').textContent=r.message;toast(r.message);},$('saveSettingsBtn'));
$('settingsDialog').addEventListener('close',()=>{$('smsApiKey').value='';$('nunaSmsPassword').value='';$('nunaLmsPassword').value='';});
// 2026-10-26 17:46 요청: 너나우리 계정이 적혀 있으면 문자는 너나우리로, 없으면 알리고 문자로
function smsRouteName(kind){return state?.smsRoute?.[kind||'LMS']==='NUNAURI'?'너나우리':'알리고';}
function renderNunaState(){
 const a=state?.nunauriAccount||{},act=a.active||{};
 if($('nunaSmsUser')&&document.activeElement!==$('nunaSmsUser'))$('nunaSmsUser').value=a.smsUser||'';
 if($('nunaLmsUser')&&document.activeElement!==$('nunaLmsUser'))$('nunaLmsUser').value=a.lmsUser||'';
 if($('nunaSender')&&document.activeElement!==$('nunaSender'))$('nunaSender').value=a.sender||'';
 if($('nunaState'))$('nunaState').textContent=`지금 문자 경로 — SMS: ${act.SMS?'너나우리':'알리고'} / LMS: ${act.LMS?'너나우리':'알리고'}${a.saved?' · 너나우리 계정 키체인 저장됨'+(a.restored?' · 자동 불러오기 완료':''):a.smsUser||a.lmsUser?' · 너나우리 계정 미복구(비밀번호 다시 저장)':' · 너나우리 계정 없음'}${a.error?' · '+a.error:''}`;
 const opt=$('smsChannelOption');if(opt)opt.textContent=smsRouteName('LMS')+' 문자';
}
$('saveNunaBtn').onclick=()=>action(async()=>{const r=await api('nunauri-settings',{smsUser:$('nunaSmsUser').value,smsPassword:$('nunaSmsPassword').value,lmsUser:$('nunaLmsUser').value,lmsPassword:$('nunaLmsPassword').value,sender:$('nunaSender').value});$('nunaSmsPassword').value='';$('nunaLmsPassword').value='';$('settingsResult').textContent=r.message;toast(r.message);},$('saveNunaBtn'));
$('forgetNunaBtn').onclick=()=>action(async()=>{if(!confirm('너나우리 계정을 지우고 문자를 알리고로 보낼까요? 기존 미요청·예약은 일시정지됩니다.'))return;const r=await api('nunauri-forget',{confirmed:true});$('settingsResult').textContent=r.message;toast(r.message);},$('forgetNunaBtn'));
$('aligoDialog').addEventListener('close',()=>{$('aligoApiKey').value='';$('aligoSenderKey').value='';});
for(const kind of ['SMS','LMS'])$('check'+kind).onclick=()=>action(async()=>{const r=await api('remaining',{kind});$('settingsResult').textContent=`${r.route||''} ${kind} 발송 가능량: ${r.remaining}건 (문자는 보내지 않았습니다.)`;toast($('settingsResult').textContent);},$('check'+kind));
function renderAccountState(){
 try{renderNunaState();}catch(_){}
 const a=state?.accountStorage||{},ready=state?.credentialsReady||{};
 $('accountState').textContent=`SMS ${ready.SMS?'사용 준비됨':'계정 없음'} / LMS ${ready.LMS?'사용 준비됨':'계정 없음'} · ${a.saved?'맥 키체인 저장됨'+(a.restored?' · 자동 불러오기 완료':''):a.available?'아직 저장하지 않음':'메모리 보관 전용'}${a.error?' · '+a.error:''}`;
 $('reloadAccountBtn').disabled=!a.available;
 $('accountBanner').hidden=!a.error&&(ready.SMS||ready.LMS);
 $('accountBannerText').textContent=a.error||'문자 설정에서 계정을 한 번 저장하세요. 수신 테스트 없이 발송하며 다음 실행부터 저장된 계정을 사용합니다.';
}
$('reloadAccountBtn').onclick=()=>action(async()=>{const r=await api('account-reload',{});$('settingsResult').textContent=r.message;toast(r.message,r.restored===false);},$('reloadAccountBtn'));
$('forgetAccountBtn').onclick=()=>action(async()=>{if(!confirm('이 앱에 저장한 문자 계정만 삭제할까요? 주문·발송 이력은 남고, 발송·조회는 계정을 다시 저장하기 전까지 멈춥니다.'))return;const r=await api('account-forget',{confirmed:true});$('settingsResult').textContent=r.message;toast(r.message);},$('forgetAccountBtn'));
$('accountBannerBtn').onclick=()=>$('settingsBtn').click();
function invalidate(){plan=null;updateSendButton();}
function composeRows(){return state.rows.filter(r=>composeKeys.includes(r.key));}
// 2026-10-25: 주문 목록에 없는 번호(직접 입력) — 수동 작성에서만
function directPhones(){if(composeType!=='manual')return [];return [...new Set($('directPhones').value.split(/[\s,;/]+/).map(v=>{v=v.trim();if(v.startsWith('+82'))v='0'+v.slice(3);return v.replace(/\D/g,'');}).filter(Boolean))];}
function updateComposeSummary(){
 const rows=composeRows(),orders=new Set(rows.map(r=>JSON.stringify([r.seller,r.orderId])));
 const selectedSellers=[...new Set(rows.map(r=>r.seller.replace('누아브 ','')))].join(' · ');
 const testCount=rows.filter(r=>r.orderId.startsWith('TEST-')).length;
 const direct=directPhones();
 $('composeSummary').textContent=(rows.length?`${selectedSellers} · ${rows.length}개 상품 / ${orders.size}개 주문에 ${orders.size}통 발송${testCount?' · TEST 주문 '+testCount+'개 상품 포함':''}`:'')+(direct.length?`${rows.length?' + ':''}직접 입력 번호 ${direct.length}개에 ${direct.length}통 발송`:'')||(composeType==='manual'?'직접 입력 번호를 적거나 주문을 선택하세요.':'');
 $('alternativeBox').hidden=!rows.some(r=>r.needsPhoneApproval);
}
function usingAligo(){return composeType==='delay'&&$('deliveryChannel').value==='AT';}
function approvedComposeTemplate(){return state?.aligo?.templates?.[composeAligoKey];}
function smsTemplate(key){if(key==='manual')return '';return state?.settings?.smsTemplates?.[key]||templates[key];}
function selectComposeTemplate(key){
 if(!['first','change','soldout_card','soldout_bank','manual'].includes(key))key='first';
 composeTemplateKey=key;composeType=key==='manual'||key.startsWith('soldout')?key:'delay';
 if(composeType==='delay')composeAligoKey=key;
 $('deliveryChannel').value=composeType==='delay'?composeChannelPreference:'SMS';
 $('template').value=smsTemplate(key);$('messageTitle').value=composeType==='manual'?(state.settings.shopName+' 안내'):shopMessageTitle(composeType!=='delay');
 updateTemplateMode();invalidate();
}
function openDirectCompose(pre){   // 2026-10-25: 번호 직접 문자 (주문 선택 없이) · Codex 카드도 여기로
 if(!state)return; if(!state.settings.shopName){openShopSettings();toast('먼저 쇼핑몰 이름을 저장하세요.',true);return;}
composeKeys=[...selected];$('dueDate').value='';composeChannelPreference='SMS';$('defaultTemplate').value=state.settings.defaultTemplate||'first';
 suggestedSendMode='';selectComposeTemplate('manual');$('alternativeApproved').checked=false;
 $('directPhones').value=(pre?.phones||[]).join('\n');$('noticeReason').value=pre?.reason||'';
 if(pre?.message)$('template').value=pre.message;if(pre?.title)$('messageTitle').value=pre.title;
 invalidate();updateComposeSummary();if(!$('composeDialog').open)$('composeDialog').showModal();$('directPhones').focus();
 if(pre?.sendMode)suggestSendMode(pre.sendMode);
}
window.nuavuDirectCompose={open:openDirectCompose,suggest:suggestSendMode};
$('directComposeBtn').onclick=()=>openDirectCompose();
$('composeBtn').onclick=()=>{
 if(!state||!selected.size)return;
 if(!state.settings.shopName){openShopSettings();toast('먼저 쇼핑몰 이름을 저장하세요.',true);return;}
 composeKeys=[...selected];$('directPhones').value='';$('noticeReason').value='';suggestedSendMode='';$('dueDate').min=state.sendWindow?.immediateMinDueDate||state.today;$('dueDate').value='';
 composeChannelPreference=state.aligo?.enabled?'AT':'SMS';
 const key=state.settings.defaultTemplate||'first';$('defaultTemplate').value=key;
 selectComposeTemplate(key);$('alternativeApproved').checked=false;invalidate();updateComposeSummary();$('composeDialog').showModal();
};
$('defaultTemplate').onchange=()=>action(async()=>{
 const r=await api('preferences',{defaultTemplate:$('defaultTemplate').value});
 toast(r.message);
},$('defaultTemplate'));
for(const id of ['dueDate','sendKind','template','messageTitle','alternativeApproved','noticeReason'])$(id).addEventListener('input',invalidate);
$('directPhones').addEventListener('input',()=>{invalidate();updateComposeSummary();});
$('deliveryChannel').onchange=()=>{composeChannelPreference=$('deliveryChannel').value;if(!usingAligo()){$('template').value=smsTemplate(composeTemplateKey);$('messageTitle').value=composeType==='manual'?(state.settings.shopName+' 안내'):shopMessageTitle(composeType!=='delay');}updateTemplateMode();invalidate();};
function updateTemplateMode(){
 const soldout=composeType.startsWith('soldout'),manual=composeType==='manual',noDate=soldout||manual;if(noDate)$('deliveryChannel').value='SMS';
 $('deliveryChannel').querySelector('option[value="AT"]').disabled=noDate;
 const at=usingAligo(),t=approvedComposeTemplate();
 $('dueDateField').hidden=noDate;$('manualComposeHint').hidden=!manual;$('manualFields').hidden=!manual;if(!manual)$('directPhones').value='';$('soldoutHint').hidden=!soldout;$('sendKindField').hidden=at;
 $('template').readOnly=at;$('messageTitle').readOnly=at;
 $('composeTitle').textContent=manual?'수동 문자 작성':soldout?'품절 안내 문자 작성':at?'배송지연 알림톡 작성':'배송지연 문자 작성';
 if(at){$('template').value=t?.body||'';$('messageTitle').value=t?.name||shopMessageTitle();}
 $('aligoComposeHint').hidden=!at;
 $('aligoComposeHint').textContent=at?`${t?.code||''} · ${t?.verified?'승인 양식 확인됨':'알림톡 설정에서 승인 템플릿을 먼저 불러오세요.'} · 알리고 발신 ${state?.aligo?.sender||'미설정'} / 대체문자 발신 ${state?.settings?.sender||'미설정'} · 고정 문구 수정 불가. 확정 실패 시에만 알리고 문자 1회 대체. 야간 문자 대체는 오전 9시.`:'';
 $('templateHelp').textContent=manual?'보낼 문구를 직접 입력하세요. 상품목록은 선택 사항이며, 안내번호가 마지막에 붙습니다. 기존 출고 예정일·배송지연 안내 횟수는 바뀌지 않습니다.':at?'#{상품명} · #{출고예정일}만 실제 값으로 채웁니다. 알림톡에는 안내번호를 덧붙이지 않습니다.':soldout?'{상품목록}은 선택한 상품으로 바뀝니다. 품절 상태는 발송 접수 후 반영합니다. 안내번호가 마지막에 붙습니다.':'{상품목록} · {출고예정일}은 실제 값으로 바뀝니다. 안내번호가 마지막에 붙습니다.';
 for(const [id,key] of [['firstTemplateBtn','first'],['changeTemplateBtn','change'],['soldoutCardTemplateBtn','soldout_card'],['soldoutBankTemplateBtn','soldout_bank'],['manualTemplateBtn','manual']])$(id).classList.toggle('on',key===composeTemplateKey);
}
for(const [id,key] of [['firstTemplateBtn','first'],['changeTemplateBtn','change'],['soldoutCardTemplateBtn','soldout_card'],['soldoutBankTemplateBtn','soldout_bank'],['manualTemplateBtn','manual']])$(id).onclick=()=>selectComposeTemplate(key);
let suggestedSendMode='';   // 2026-10-25 23:51: Codex 카드의 발송 시점 제안 (MORNING) → 버튼 강조만, 예약은 사장님이 누른다
function suggestSendMode(mode){
 suggestedSendMode=mode==='MORNING'?'MORNING':'';updateSendButton();
 if(suggestedSendMode&&$('sendMorningBtn').hidden)toast('지금은 오전 9시 예약을 고를 수 없습니다 (18시 이후에만 표시). 즉시전송만 가능합니다.',true);
 else if(suggestedSendMode){$('sendMorningBtn').scrollIntoView({block:'nearest'});$('sendMorningBtn').focus();}
}
function updateSendButton(){
 const w=state?.sendWindow;
 $('dueDate').min=w?.immediateMinDueDate||state?.today||'';
 $('scheduleHint').classList.toggle('is-scheduled',!!w?.nightChoices);
 $('scheduleHint').textContent=w?.nightChoices
   ?`지금 즉시전송 또는 ${dateTime(w.morningSendAt)} 오전 9시 전송을 선택하세요. 즉시전송은 밤에도 실제로 보냅니다. (한국 시간)`
   :(usingAligo()?'고객에게 알림톡 발송':'고객에게 실제 문자 발송')+'을 누르면 지금 요청합니다. 18시 이후에는 즉시전송과 오전 9시 전송 중 선택할 수 있습니다.';
 $('sendMorningBtn').hidden=!w?.nightChoices;
 $('sendMorningBtn').classList.toggle('suggested',suggestedSendMode==='MORNING'&&!!w?.nightChoices);
 if(suggestedSendMode==='MORNING'&&w?.nightChoices)$('scheduleHint').textContent+=' · AI 카드 제안: 오전 9시 예약 → [오전 9시에 전송] 버튼을 누르세요.';
 if(!sending){
   $('sendBtn').textContent=w?.nightChoices?'즉시전송':usingAligo()?'고객에게 알림톡 발송':'고객에게 실제 문자 발송';
   $('sendMorningBtn').textContent='오전 9시에 전송';
 }
 const invalid=sending||busy>0||(usingAligo()&&(!state?.aligoReady||!approvedComposeTemplate()?.verified||!state?.credentialsReady?.LMS))||!(composeKeys.length||directPhones().length)||!$('template').value.trim()||(composeType==='delay'&&(!$('dueDate').value||$('dueDate').value<$('dueDate').min));
 $('sendBtn').disabled=invalid;
 $('sendMorningBtn').disabled=invalid||(composeType==='delay'&&$('dueDate').value<(w?.morningMinDueDate||''));
 $('sendMorningBtn').title=composeType==='delay'&&$('dueDate').value<(w?.morningMinDueDate||'')?'오전 9시 발송일 또는 이후의 출고 예정일을 선택하세요.':(w?.morningSameDay?'오늘':'다음 날')+' 오전 9시부터 순차 발송';
}
function submitNotice(sendMode,button){
 if(sending||busy>0||button.disabled)return;
 sending=true;button.textContent='발송·예약 저장 중…';updateSendButton();
 action(async()=>{
   const input={keys:composeKeys,sendMode,deliveryChannel:usingAligo()?'AT':'SMS',aligoTemplate:composeAligoKey,noticeType:composeType,templateKey:composeTemplateKey,dueDate:composeType==='delay'?$('dueDate').value:'',kind:$('sendKind').value,title:$('messageTitle').value,template:$('template').value,alternativeApproved:$('alternativeApproved').checked,phones:directPhones(),reason:composeType==='manual'?$('noticeReason').value.trim():''};
   if(!plan||plan.sendMode!==sendMode)plan={...(await api('preview',input)),sendMode};
   const r=await api('send',{token:plan.token});
   $('composeDialog').close();selected.clear();composeKeys=[];plan=null;
   toast(r.message||'이미 대기열에 저장된 요청입니다. 같은 요청을 다시 발송하지 않습니다.');
 },button).finally(()=>{sending=false;updateSendButton();});
}
$('sendBtn').onclick=()=>submitNotice('IMMEDIATE',$('sendBtn'));
$('sendMorningBtn').onclick=()=>submitNotice('MORNING',$('sendMorningBtn'));
$('pollBtn').onclick=()=>action(async()=>toast((await api('poll',{})).message),$('pollBtn'));
for(const [id,act] of [['pauseBtn','pause'],['resumeBtn','resume'],['cancelQueueBtn','cancel']])$(id).onclick=()=>action(async()=>{if(act==='resume'&&!confirm('미요청·예약 작업을 이어서 진행합니다. 저장한 즉시전송/오전 9시 선택을 유지합니다. 즉시전송으로 선택한 작업은 밤에도 이어서 보냅니다. 미확정 접수 건은 재발송하지 않습니다. 진행할까요?'))return;if(act==='cancel'&&!confirm('아직 요청하지 않은 예약·대기·일시정지 작업을 모두 취소할까요? 이미 접수된 문자는 취소하지 않습니다.'))return;toast((await api('queue',{action:act,confirmed:act==='resume'})).message);},$(id));
function openHistory(key=null){historyKey=key;renderHistory();$('historyDialog').showModal();}
$('historyBtn').onclick=()=>openHistory();
function renderHistory(){const openHistoryIds=new Set([...$('historyBody').querySelectorAll('article[data-id]')].filter(a=>a.querySelector('details')?.open).map(a=>a.dataset.id));const ns=state.notices.filter(n=>!historyKey||n.itemKeys.includes(historyKey)).slice().reverse();$('historyTitle').textContent=historyKey?'선택 상품의 안내 이력':'예약 · 전체 발송 이력';$('historyBody').innerHTML=ns.length?ns.map(n=>n.status==='IMPORTED'?renderExternalNotice(n,openHistoryIds.has(n.id)):`<article class="historycard" data-id="${esc(n.id)}"><div class="historytop"><b>${n.isTest?'내 번호 테스트':n.direct?'직접 입력 번호 · '+esc(phoneLabel(n.phone,true)):esc(n.seller)+' · '+esc(n.orderId)}</b>${n.noticeType==='manual'?'<span class="tag external">수동안내'+(n.manualReason?' · 사유: '+esc(n.manualReason):'')+'</span>':''}${tag(n.displayStatus||n.status)}</div><div class="historymeta">${esc(n.channel||n.kind)} · ${esc(({soldout_card:'품절 · 카드',soldout_bank:'품절 · 무통장',delay:'배송지연',manual:'수동안내'+(n.manualReason?' · 사유: '+n.manualReason:' · 사유 없음'),return_overdue:'반품 기한 초과 안내',return_not_defect:n.returnExchange?'교환 불량 아님 안내':'반품 불량 아님 안내',return_manual:n.returnExchange?'교환 수동 메시지':'반품 수동 메시지'})[n.noticeType||'delay']||n.noticeType)} · ${esc(phoneLabel(n.phone,true))} · ${esc(n.ref)} · 요청 ${dateTime(n.attemptedAt,true)}${n.dueDate?' · 예정일 '+esc(n.dueDate):''}${n.manual?' · 사용자 수동 확인 포함':''}</div>${aligoHistoryMeta(n)}<p class="sub">발송 선택: ${esc(({IMMEDIATE:'즉시전송 (야간 포함)',MORNING:'오전 9시에 전송',AUTO:'이전 버전 자동 시간 규칙'})[n.sendMode||'AUTO'])}</p>${n.resultDeadlineAt&&['PENDING','UNKNOWN'].includes(n.status)?'<p class="sub">1분 확인 기준: '+esc(dateTime(n.resultDeadlineAt,true))+'</p>':''}${n.scheduledAt?'<p class="schedule-history">예약 시각 '+esc(dateTime(n.scheduledAt))+' (한국 시간) · 실제 요청 '+dateTime(n.attemptedAt,true)+'</p>':''}${n.status==='PENDING'||n.status==='UNKNOWN'?`<p class="sub">다음 결과 조회: ${dateTime(n.nextCheckAt,true)} · 접수 15초/1분 기준</p>`:''}<p>${esc(n.note||'')}</p>${n.reportCheckedAt?`<p class="sub">최근 조회 ${dateTime(n.reportCheckedAt,true)} · 조회 내역 ${n.reportRecordCount??'—'}개 / 일치 ${n.reportMatchCount??'—'}개</p>`:''}${n.rawResult!==undefined?'<p class="sub">공급사 결과 원문: '+esc(n.rawResult)+'</p>':''}<details ${openHistoryIds.has(n.id)?'open':''}><summary>발송 문구 · 처리 이력 보기</summary><pre>${esc(n.content)}</pre><div class="historyevents">${(n.events||[]).map(e=>`<div>${dateTime(e.at)} · ${esc(names[e.status]||e.status)} · ${esc(e.note)}</div>`).join('')}</div></details>${['QUEUED','SCHEDULED','PAUSED'].includes(n.status)?`<button class="tiny danger-quiet cancel-one" data-id="${esc(n.id)}">이 예약·미요청 취소</button>`:''}${n.noticeType==='manual'?`<button class="tiny reason-edit" data-id="${esc(n.id)}" data-reason="${esc(n.manualReason||'')}">${n.manualReason?'사유 수정':'사유 적기'}</button>`:''}${['UNKNOWN','PENDING'].includes(n.status)?`<button class="tiny manual-open" data-id="${esc(n.id)}">공급사 최종 결과 수동 확인</button>`:''}${typeof fallbackButtons==='function'?fallbackButtons(n):''}</article>`).join(''):'<div class="empty">아직 발송한 안내가 없습니다.</div>';}
function renderExternalNotice(n,isOpen){
 if(n.source==='zigzag_sync')return `<article class="historycard" data-id="${esc(n.id)}"><div class="historytop"><b>지그재그 · ${esc(orderDisplay(n.orderId))}</b><span class="tag external">지그재그 동기화</span></div><div class="historymeta">변경 발송 예정일: ${esc(n.dueDate)} · 조회 ${dateTime(n.importedAt)}</div><p>${esc(n.note)}</p></article>`;
 if(n.source==='ably_sync')return `<article class="historycard" data-id="${esc(n.id)}"><div class="historytop"><b>에이블리 · ${esc(orderDisplay(n.orderId))}</b><span class="tag external">에이블리 동기화</span>${n.pushedByApp?'<span class="tag external">앱이 에이블리 발송 처리</span>':''}</div><div class="historymeta">안내한 출고 예정일: ${esc(n.dueDate)} · 조회 ${dateTime(n.importedAt)}</div><p>${esc(n.note)}</p><p class="sub">에이블리 배송지연 메시지 발송일: ${esc((n.platformNoticeDates||[]).join(', ')||'화면에 발송 이력 없음')} · 앱 발송 0통</p><details ${isOpen?'open':''}><summary>상품주문번호 · 원래 날짜 범위</summary>${(n.sourceMappings||[]).map(x=>'<p>상품주문번호 '+esc(x.itemId)+' · '+esc(x.startDate)+' ~ '+esc(x.dueDate)+' · '+esc(x.qty)+'개</p>').join('')}</details></article>`;
 const variants=(n.sourceMappings||[]).filter(x=>x.optionVariant).length;
 return `<article class="historycard" data-id="${esc(n.id)}"><div class="historytop"><b>${esc(n.seller)} · ${esc(orderDisplay(n.orderId))}</b>${tag(n.displayStatus||n.status)}</div>
 <div class="historymeta">${n.manualAcknowledgement?'메시지 없이 안내 처리 · 실제 발송 없음':'기존 플랫폼 안내 이력'} · 안내한 출고 예정일: ${esc(n.dueDate)} · 실제 발송일 미제공</div>
 <p>${esc(n.note)}</p><p class="sub">출처 ${esc(n.sourceFile)}${n.sourceSheet?' / '+esc(n.sourceSheet):''}${n.sourceRows?.length?' / '+esc(n.sourceRows.join(', '))+'행':''} · 등록 ${dateTime(n.importedAt)}</p>
 ${variants?'<p class="sub">원컬러/화이트 옵션 표기 차이 '+variants+'행: 동일 주문·상품·수량·연락처·수취인·주문일로 대조한 기록입니다.</p>':''}
 <details ${isOpen?'open':''}><summary>기존 안내 상품 · 대조 근거 보기</summary><div class="historyevents">${(n.products||[]).map(x=>'<p>'+esc(x.product)+' · '+esc(x.option)+' × '+esc(x.qty)+'</p>').join('')}${(n.sourceMappings||[]).map(x=>'<p>원본 '+x.sourceRow+'행 · '+esc(x.method)+(x.manualRecipient?' · '+esc(x.manualRecipient):'')+'</p>').join('')}</div></details></article>`;
}
$('historyBody').onclick=e=>{const re=e.target.closest('.reason-edit');if(re){const v=prompt('수동안내 사유 (예: 회수 안내 · 교환 안내 · 오배송 안내)',re.dataset.reason||'');if(v===null)return;action(async()=>{const r=await api('notice-reason',{id:re.dataset.id,reason:v});toast(r.message);await refresh();renderHistory();},re);return;}
 const cancel=e.target.closest('.cancel-one');if(cancel){action(async()=>{if(confirm('이 주문의 아직 보내지 않은 예약·대기 문자만 취소할까요?'))toast((await api('queue',{action:'cancel_one',id:cancel.dataset.id})).message);},cancel);return;}const b=e.target.closest('.manual-open');if(!b)return;manualId=b.dataset.id;$('manualReason').value='';$('manualConfirmed').checked=false;$('manualDialog').showModal();};
$('manualSaveBtn').onclick=()=>action(async()=>{toast((await api('manual-result',{id:manualId,status:$('manualStatus').value,reason:$('manualReason').value,confirmed:$('manualConfirmed').checked})).message);$('manualDialog').close();},$('manualSaveBtn'));
function activeAlerts(){return (state?.alerts||[]).filter(a=>!a.acknowledgedAt&&!a.resolvedAt);}
function renderAlerts(){
 const all=activeAlerts(),jobs=all.filter(a=>a.job),alerts=all.filter(a=>!a.job),failed=alerts.filter(a=>a.level==='error'),jobsFailed=jobs.filter(a=>a.level==='error');
 $('alertsCount').textContent=String(all.length);$('alertsBtn').classList.toggle('has-alerts',failed.length>0||jobsFailed.length>0);
 $('alertBanner').hidden=!all.length;$('alertBanner').classList.toggle('warning-only',!failed.length&&!jobsFailed.length);$('alertBanner').classList.toggle('job-done',!alerts.length&&!jobsFailed.length);$('alertBanner').classList.toggle('job-blocked',jobsFailed.length>0);$('alertsBtn').classList.toggle('job-blocked-btn',jobsFailed.length>0);
 const unconfirmed=failed.filter(a=>a.code==='RESULT_UNCONFIRMED_1M').length;
 const jobLine=jobs.length?(jobsFailed.length?`🔴 막힌 작업 ${jobsFailed.length}건 — 확인 필요`:'')+(jobs.length-jobsFailed.length?`${jobsFailed.length?' · ':''}작업완료! ${jobs.length-jobsFailed.length}건`:''):'';
 $('alertHeadline').textContent=failed.length?`발송실패 확인 ${failed.length}건${unconfirmed?' (1분 미확인 '+unconfirmed+'건 포함)':''}${jobLine?' · '+jobLine:''}`:alerts.length?`예약·전송 확인이 필요한 알림 ${alerts.length}건${jobLine?' · '+jobLine:''}`:jobLine;
 $('alertDetail').textContent=failed.length?'확정 실패와 1분 결과 미확인을 구분해 확인하세요. 1분 미확인은 실제 미수신 확정이 아니며, 자동으로 다시 보내지 않습니다.':alerts.length?'예약 일시정지·조회 오류는 문자 발송 실패와 다릅니다. 이력에서 확인해 주세요.':(jobs.slice(-1)[0]?.title||'')+(jobs.slice(-1)[0]?' · '+dateTime(jobs.slice(-1)[0].at):'')+' · 알림 확인을 누르면 지웁니다.';
 const fresh=all.filter(a=>!seenAlerts.has(a.id));fresh.forEach(a=>seenAlerts.add(a.id));
 if(fresh.length){
   const failureCount=fresh.filter(a=>a.level==='error'&&!a.job).length,freshJobs=fresh.filter(a=>a.job);
   const message=failureCount?`발송실패 분류 ${failureCount}건이 있습니다. 실제 실패/결과 미확인 사유를 전송 알림에서 확인하세요.`:freshJobs.length?(freshJobs.some(a=>a.level==='error')?'🔴 막힘: ':'🟢 작업완료! ')+freshJobs.map(a=>a.title).join(', '):`예약·전송 확인 알림 ${fresh.length}건이 있습니다.`;
   toast(message,failureCount>0||fresh.some(a=>a.job&&a.level==='error'));
   if('Notification' in window&&Notification.permission==='granted'){
     try{new Notification((state?.settings?.shopName||'쇼핑몰')+' 배송안내',{body:message,tag:'nuavu-delivery-alert'});}catch(e){/* In-app alerts remain available. */}
   }
 }
 if($('alertsDialog').open)renderAlertsDialog();
}
function renderAlertsDialog(){
 const alerts=activeAlerts().slice().reverse(),byId=new Map(state.notices.map(n=>[n.id,n]));
 $('alertsBody').innerHTML=alerts.length?alerts.map(a=>{if(a.job)return `<article class="historycard alert-card ${a.level==='error'?'alert-fail alert-job-fail':'alert-job'}"><div class="historytop"><b>${a.level==='error'?'🔴 막힘 · ':'🟢 작업완료! · '}${esc(a.title||'')}</b><span class="sub">${dateTime(a.at)}</span></div><p>${esc(a.message)}</p><div class="alert-actions"><button class="tiny alert-ack" data-id="${esc(a.id)}">알림 지우기</button></div></article>`;const n=byId.get(a.noticeId);return `<article class="historycard alert-card ${a.level==='error'?'alert-fail':'alert-warn'}"><div class="historytop"><b>${a.code==='RESULT_UNCONFIRMED_1M'?'1분 결과 미확인':a.level==='error'?'전송 실패 확정':'확인 필요'} · ${esc(n?(n.isTest?'내 번호 테스트':n.seller+' / '+n.orderId):'알림')}</b><span class="sub">${dateTime(a.at)}</span></div><p>${esc(a.message)}</p><div class="alert-actions"><button class="tiny alert-history" data-id="${esc(a.noticeId)}">해당 발송 이력</button>${n&&typeof fallbackButtons==='function'?fallbackButtons(n):''}<button class="tiny alert-ack" data-id="${esc(a.id)}">알림 확인</button></div></article>`;}).join(''):'<div class="empty">확인하지 않은 알림이 없습니다.</div>';
 $('ackAllAlertsBtn').disabled=!alerts.length;
}
for(const id of ['alertsBtn','alertDetailsBtn'])$(id).onclick=()=>{renderAlertsDialog();$('alertsDialog').showModal();};
$('alertsBody').onclick=e=>{
 const ack=e.target.closest('.alert-ack');if(ack){action(async()=>{await api('alerts-ack',{ids:[ack.dataset.id]});},ack);return;}
 const button=e.target.closest('.alert-history');if(button){const n=state.notices.find(n=>n.id===button.dataset.id);$('alertsDialog').close();openHistory(n?.itemKeys[0]||null);}
};
$('ackAllAlertsBtn').onclick=()=>action(async()=>{await api('alerts-ack',{ids:activeAlerts().map(a=>a.id)});},$('ackAllAlertsBtn'));
$('notifyPermissionBtn').onclick=async()=>{
 if(!('Notification' in window)){toast('이 브라우저에서는 외부 알림을 지원하지 않습니다. 프로그램 안의 전송 알림은 계속 표시됩니다.',true);return;}
 try{const permission=await Notification.requestPermission();toast(permission==='granted'?'브라우저 알림을 허용했습니다. 프로그램 화면도 열어두세요.':'외부 알림이 허용되지 않았습니다. 앱 안의 전송 알림을 확인해 주세요.');if(permission==='granted'){seenAlerts.clear();renderAlerts();}}catch(e){toast('알림 권한을 요청하지 못했습니다. 앱 안의 전송 알림을 이용해 주세요.',true);}
};
async function download(path,name){if(state?.desktopMode){if(!window.pywebview?.api)throw Error('앱 창 준비 중입니다.');const r=await window.pywebview.api.save_export(token,path);if(r?.error)throw Error(r.error);if(r?.saved)toast('선택한 위치에 저장했습니다.');return;}const r=await fetch('/api/'+path,{headers:{'X-NUAVU-Token':token}});if(!r.ok)throw Error('내보내기에 실패했습니다.');const blob=await r.blob();const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
$('exportBtn').onclick=()=>action(()=>download('export','배송안내_발송이력.csv'),$('exportBtn'));
let savedOrderExportId='';
function showOrderExportResult(result){
 clearTimeout(toast.timer);$('toast').hidden=true;
 savedOrderExportId=result.revealId||'';
 $('orderExportMessage').textContent=`${result.count}개 주문상품 엑셀을 ${result.saved?'저장':'다운로드'}했습니다.`;
 $('orderExportFilename').textContent=result.name;
 $('orderExportMissing').hidden=!result.missingContacts;
 $('orderExportMissing').textContent=result.missingContacts?`휴대폰 번호가 없는 ${result.missingContacts}개 상품은 번호 칸을 비워 두었습니다.`:'';
 $('revealOrderExportBtn').hidden=!savedOrderExportId;
 $('openOrderExportBtn').hidden=!savedOrderExportId;
 $('orderExportResult').hidden=false;
}
$('dismissOrderExportBtn').onclick=()=>{$('orderExportResult').hidden=true;};
$('revealOrderExportBtn').onclick=()=>action(async()=>{
 const bridge=window.pywebview?.api;
 if(!savedOrderExportId||!bridge?.reveal_export)throw Error('Finder에서 보기는 파일을 저장한 Mac 앱에서 사용할 수 있습니다.');
 const result=await bridge.reveal_export(token,savedOrderExportId);
 if(result?.error)throw Error(result.error);
},$('revealOrderExportBtn'));
$('openOrderExportBtn').onclick=()=>action(async()=>{
 const bridge=window.pywebview?.api;
 if(!savedOrderExportId||!bridge?.open_export)throw Error('열기는 파일을 저장한 Mac 앱에서 사용할 수 있습니다.');
 const result=await bridge.open_export(token,savedOrderExportId);
 if(result?.error)throw Error(result.error);
},$('openOrderExportBtn'));
$('orderExportBtn').onclick=()=>action(async()=>{
 const visible=filtered(),rows=selected.size?visible.filter(r=>selected.has(r.key)):visible;
 if(!rows.length)throw Error('현재 섹션에서 선택한 주문이 없습니다. 선택을 해제하거나 다운로드할 주문을 선택하세요.');
 const payload={keys:rows.map(r=>r.key),section:$('statusFilter').value,riskStage,revision:state.revision};
 let result;
 if(state.desktopMode){
  if(!window.pywebview?.api)throw Error('앱 창 준비 중입니다.');
  result=await window.pywebview.api.save_export(token,'orders',payload);
  if(result?.error)throw Error(result.error);if(!result?.saved)return;
 }else{
  const response=await fetch('/api/order-export',{method:'POST',headers:{'X-NUAVU-Token':token,'Content-Type':'application/json'},body:JSON.stringify(payload)});
  if(!response.ok)throw Error((await response.json()).error||'주문 엑셀 저장에 실패했습니다.');
  result={name:decodeURIComponent(response.headers.get('X-Export-Name')),count:Number(response.headers.get('X-Export-Count')),missingContacts:Number(response.headers.get('X-Export-Missing-Contacts'))};
  const url=URL.createObjectURL(await response.blob()),a=document.createElement('a');a.href=url;a.download=result.name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
 }
 showOrderExportResult(result);
},$('orderExportBtn'));
(async()=>{await refresh();try{templates=await api('templates');}catch(e){toast(e.message,true);}setInterval(async()=>{if(busy)return;try{const v=await api('version');if(v.version!==state?.stateVersion||Date.now()-lastFullRefresh>60000){lastFullRefresh=Date.now();await refresh();}}catch(e){await refresh();}},3500);})();

function aligoHistoryMeta(n){
 if(n.kind==='AT')return `<p class="aligo-history-meta">알리고 발신 ${esc(n.sender)} · 대체문자 발신 ${esc(n.fallback?.sender||'')} · 템플릿 ${esc(n.aligoCode)} · mid ${esc(n.aligoMid||'접수 ID 미확인')} · 문자 대체 ${esc(n.fallbackId?'1건 연결됨':n.fallbackDecision==='HELD'?'보류: '+n.fallbackReason:'확정 실패 시에만 1회')}</p>`;
 if(n.fallbackOf)return `<p class="aligo-history-meta">알림톡 실패 대체 문자 · 원안내 ${esc(n.fallbackOf)} · 중복 대체 안 함</p>`;
 return '';
}
function renderAligoState(){
 const cfg=state?.aligo||{},a=state?.aligoAccountStorage||{};
 $('aligoSenderState').textContent=`저장된 알리고 발신번호: ${cfg.sender||'미설정'} · 알리고 문자·실패 대체문자: ${state?.settings?.sender||'미설정'}`;
 const d=a.diagnostic; $('aligoDiagnostic').hidden=!d; if(d){const e=d.environment||{}; $('aligoDiagnostic').textContent=`${d.ok?'연결 확인':'진단 결과'} · ${dateTime(d.at)}\n${d.message}\nPython ${e.python||''} · ${e.tls||''}\n인증서 묶음 ${e.certifi||''} · 신뢰 CA ${e.trustedCaCount??''}개`;}
 $('aligoSettingsBtn').textContent=cfg.enabled?'알림톡 설정 · 사용 중':'알림톡 설정';
 $('aligoAccountState').textContent=a.error||(!state?.aligoReady?'알리고 계정 입력 필요':a.restored?'자동 불러오기 완료':a.saved?'맥 키체인 저장됨':'개발 환경: 현재 메모리에서만 사용');
 $('aligoTemplateStatus').innerHTML=['first','change'].map(key=>{
  const t=cfg.templates?.[key]||{};
  const links=t.verified?(t.buttons||[]).map(b=>`<p class="template-link-details"><b>${esc(b.name||'버튼')}</b>${b.linkM?'<br>모바일 주소: <span>'+esc(b.linkM)+'</span>':''}${b.linkP?'<br>PC 주소: <span>'+esc(b.linkP)+'</span>':''}</p>`).join(''):'';
  return `<div><b>${esc(t.name||key)}</b><span>${esc(t.code)} · ${t.verified?'승인 양식 확인됨':'승인 후 불러오기 필요'} · 버튼 ${(t.buttons||[]).length}개</span>${links}${t.error?'<p class="dangertext">'+esc(t.error)+'</p>':''}</div>`;
 }).join('');
}
$('aligoSettingsBtn').onclick=()=>{const c=state.aligo||{};$('aligoUser').value=c.user||'';$('aligoFirstCode').value=c.templateCodes?.first||'';$('aligoChangeCode').value=c.templateCodes?.change||'';$('aligoSender').value=c.sender||state.settings.sender||'';$('aligoApiKey').value='';$('aligoSenderKey').value='';$('aligoEnabled').checked=c.profile?!!c.enabled:true;$('aligoResult').textContent='';renderAligoState();$('aligoDialog').showModal();};
$('saveAligoBtn').onclick=()=>action(async()=>{const r=await api('aligo-settings',{user:$('aligoUser').value,sender:$('aligoSender').value,apikey:$('aligoApiKey').value,senderkey:$('aligoSenderKey').value,enabled:$('aligoEnabled').checked,templateCodes:{first:$('aligoFirstCode').value.trim(),change:$('aligoChangeCode').value.trim()}});$('aligoApiKey').value='';$('aligoSenderKey').value='';$('aligoResult').textContent=r.message;toast(r.message);},$('saveAligoBtn'));
$('loadAligoTemplatesBtn').onclick=()=>action(async()=>{const r=await api('aligo-templates',{});$('aligoResult').textContent=r.message;toast(r.message,r.count!==2);},$('loadAligoTemplatesBtn'));
$('diagnoseAligoBtn').onclick=()=>action(async()=>{const r=await api('aligo-diagnose',{});$('aligoResult').textContent=r.message;toast(r.message,!r.ok);},$('diagnoseAligoBtn'));
$('reloadAligoBtn').onclick=()=>action(async()=>{const r=await api('aligo-reload',{});$('aligoResult').textContent=r.message;},$('reloadAligoBtn'));
$('forgetAligoBtn').onclick=()=>action(async()=>{if(confirm('알리고 저장 계정만 삭제할까요? 알리고 문자 계정과 주문·발송 이력은 유지합니다.'))toast((await api('aligo-forget',{confirmed:true})).message);},$('forgetAligoBtn'));

// v0.6.9: manual-only file reflection. No provider route is called below.
let externalFileData=null,externalPlan=null,noSendKeys=[],noSendRequest=null,matchingKey=null,matchingPicked=new Set();
function shortDay(v){if(!v)return '';const d=new Date(v+'T12:00:00+09:00');return Number.isNaN(+d)?v:new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',month:'numeric',day:'numeric',weekday:'short'}).format(d);}
function receiptCell(r){
 const arrivals=['progress','manifest'].map(kind=>{const dates=D.officeDates(r,kind);return dates.length?`<span class="secondary office-date">${kind==='manifest'?'출고장':'진행상황'} V · ${esc(dates.join(', '))}</span>`:'';}).join('');
 const risk=riskCell(r);if(!r.dispatchEnd)return (arrivals?`<button class="tiny receipt-details" data-key="${esc(r.key)}">도착일 근거 보기</button>`+arrivals:'')+risk;
 const label=r.dispatchStart===r.dispatchEnd?shortDay(r.dispatchEnd):shortDay(r.dispatchStart)+' ~ '+shortDay(r.dispatchEnd);
 return `<button class="receipt-details" data-key="${esc(r.key)}">${esc(label)}</button><span class="secondary">${r.stockSecured?'출고장 수량 확보':'중국 사무실 도착(V) 기준'}${r.supplyInfo?.calendarKnown===false?' · 휴일 확인 필요':''}</span>`+arrivals+risk;
}
function riskCell(r){
 if(!D.delayRisk(r))return '';
 const x=r.delayRisk;
 return `<button class="tiny risk-details ${x.stage==='confirmed'?'risk-confirmed':''}" data-key="${esc(r.key)}">${x.stage==='watch'?'감시 (오후 4시 마감)':'확정'} · 부족 ${x.shortQty}개</button><span class="secondary risk-quantity">근거 ${x.coveredQty} / 주문 ${x.requiredQty}개${x.needsRefresh?' · 자료 갱신 필요':''}</span>`;
}
$('rows').addEventListener('click',e=>{const b=e.target.closest('.risk-details');if(b)openRisk(b.dataset.key);});
function openRisk(key){
 const r=state.rows.find(r=>r.key===key);if(!r||!D.delayRisk(r))return;
 const x=r.delayRisk,stage=x.stage==='watch'?'감시':'확정';
 const facts=[['안내한 출고 예정일',x.dueDate],['필요한 중국 출고 회차',x.chinaDate],['감시 시작일',x.watchDate],['확정 기준일',x.confirmDate],['주문 수량',`${x.requiredQty}개`],['기한 내 도착 근거',`${x.coveredQty}개 · 출고장 ${x.manifestQty} / 진행상황 ${x.progressQty}`]];
 $('delayRiskDetails').innerHTML=`<p class="notice">${esc(r.product)} / ${esc(r.option)}<br>${esc(r.orderId)} · ${stage}</p><div class="risk-facts">${facts.map(([label,value])=>`<div><span>${esc(label)}</span><b>${esc(value)}</b></div>`).join('')}</div><p class="risk-summary">부족 수량 ${x.shortQty}개</p><p>${esc(x.reason)}</p><p class="sub">자료 기준: ${esc(dateTime(x.lastReadAt))} · 현재 주문 순서대로 배정된 수량입니다. 같은 회차의 출고장과 진행상황은 중복 합산하지 않습니다.</p><p class="sub">이 회차의 기존 국내 출고 예상 범위: ${esc(x.dispatchStart)} ~ ${esc(x.dispatchEnd)}. 안내일에 출고 가능한 회차를 기준으로 비교하며, 도착일 전이거나 안내일 이후에만 출고 가능한 물량은 기한 내 근거에 포함하지 않습니다.</p>`;
 $('delayRiskDialog').showModal();
}
function matchingCell(r){
 const a=r.supplyInfo;
 if(!r.active||!a||!Object.keys(a).length)return '';
 if(!state.supply?.lastReadAt)return '<span class="secondary">공급자료 미반영</span>';
 if(D.manualRecommended(r))return `<span class="match-status recommended">수동매칭 권장</span><br><button class="tiny rowmatch" data-key="${esc(r.key)}">후보 확인</button><span class="secondary supply-row-reason recommendation-reason">${esc(a.manualRecommendations[0].reason)}${a.manualRecommendations.length>1?` 외 ${a.manualRecommendations.length-1}개 후보`:''}</span>`;
 if(a.excluded&&!a.matched)return `<span class="match-status manual">매칭 취소됨</span><span class="secondary supply-row-reason">${esc(a.reason||'자동 연결 안 함')}</span><button class="tiny rowmatch-edit" data-key="${esc(r.key)}">다시 연결</button>`;
 if(a.matchNeeded)return `<button class="tiny rowmatch" data-key="${esc(r.key)}">수동 매칭</button><span class="secondary supply-row-reason">${esc(a.reason||'상품 연결 필요')}</span>`;
 return `<span class="match-status ${a.matchMethod==='manual'?'manual':'automatic'}">${a.matchMethod==='manual'?'수동 매칭됨':'자동 매칭됨'}</span><span class="secondary supply-row-reason">${esc(a.reason||'')}</span><button class="tiny source-details" data-key="${esc(r.key)}">자료 확인</button><button class="tiny rowmatch-edit" data-key="${esc(r.key)}">${a.matchMethod==='manual'?'연결 수정':'연결 수정·취소'}</button>`;
}

function renderSupplyState(){
 const v=state?.supply;if(!v)return;
 $('supplySummary').textContent=v.lastReadAt?`진행상황 ${v.lastReadMode==='automatic'?'자동':'수동'} 반영 ${dateTime(v.lastReadAt)} · 브랜드 ${(v.brands||[]).join(', ')||'선택 없음'} · 예상일 ${v.totals?.full||0}개 · 일부 수량 ${v.totals?.partial||0}개 · 예상일 공란 ${v.totals?.withoutDate||0}개 · 자동 매칭 ${v.totals?.automatic||0}개 · 수동 연결 ${v.totals?.manual||0}개 · 수동 매칭 필요 ${v.totals?.unmatched||0}개`:'진행상황 반영에서 폴더를 연결하고 자동 반영 또는 수동갱신을 선택하세요.';
 if(v.autoEnabled)$('supplySummary').textContent+=' · 자동 반영 '+(v.watch?.error?'오류 · 이전 자료 유지':'켜짐');
 if($('supplyDialog').open)renderSupplyInformation();
}
function renderSupplyInformation(){
 const recovery=state?.supply?.reallocation;$('reallocateManifestBtn').disabled=!recovery?.available;
 $('reallocateHint').textContent=recovery?.available?`최근 마감 ${dateTime(recovery.at)} · ${recovery.names.length}개 출고장 · ${recovery.requiresOriginal?'이전 버전 기록: 원본 파일이 필요합니다.':`복원 가능 수량 ${recovery.qty}개`} · 실수로 마감했고 실제 출고하지 않은 물량만 재배치하세요.`:'최근 마감한 출고장이 있으면 재배치할 수 있습니다. 과거의 다른 마감 물량은 복원하지 않습니다.';

 const v=state.supply||{};$('supplyFolder').textContent=v.folder||'폴더 배치·연결 필요 · 아직 연결한 폴더가 없습니다. 진행상황·출고장 엑셀이 있는 폴더를 연결하세요.';$('supplyFolder').classList.toggle('folder-need-text',!v.folder);
 $('supplyReadState').textContent=`마지막 ${v.lastReadMode==='automatic'?'자동':'수동'} 반영 ${dateTime(v.lastReadAt)} · 출고장 갱신 ${dateTime(v.lastResetAt)} · 최근 확인 ${dateTime(v.watch?.lastCheckedAt)} · ${v.autoEnabled?(v.watch?.message||'변경 확인 대기'):'자동 반영 꺼짐'}`;
 $('supplyReadState').classList.toggle('dangertext',!!v.watch?.error&&!!v.autoEnabled);
 $('supplyAutoBtn').textContent=v.autoEnabled?'자동 반영 끄기':'자동 반영 켜기';$('supplyAutoBtn').setAttribute('aria-pressed',String(!!v.autoEnabled));
 $('supplyCutoffInfo').textContent=v.progressCutoff?`진행상황 중복 제외 기준: ${v.progressCutoff} 포함 이전 V 도착일 · ${v.excludedProgress?.rows||0}행 / ${v.excludedProgress?.qty||0}개 제외. 출고장을 폴더에서 지워도 이 기준은 유지합니다. V 공란·해석 불가는 날짜를 추정하지 않습니다.`:'출고장 기준일 없음 · 완료 출고장을 읽으면 그날 포함 이전 V 도착일의 진행상황 수량을 제외합니다.';
 $('supplyWarnings').hidden=!(v.warnings||[]).length;$('supplyWarnings').textContent=(v.warnings||[]).slice(0,50).join('\n');
 const c=v.loadedCounts||{},scan=v.lastScan||{},chosen=scan.progressSelection;
 $('supplyLatestProgress').textContent=chosen?`반영된 최신 진행상황: ${chosen.name} · ${chosen.dateSource==='filename'?'파일명 날짜 '+chosen.date:'파일 수정시각 '+dateTime(chosen.modifiedAt)} · 후보 ${chosen.candidateCount}개 중 1개만 사용${chosen.ignoredCount?' (나머지 '+chosen.ignoredCount+'개는 합산하지 않음)':''}`:((scan.files||[]).some(f=>f.kind==='progress')?'진행상황·출고장 수동갱신을 누르면 최신 파일 선택 내역이 표시됩니다.':'반영된 진행상황 파일 없음 · 연결 폴더 바로 아래에 진행상황_1017.xlsx 등을 두고 수동갱신하세요.');
 const noBrandRows=!(c.manifestRows||c.progressRows)&&(v.discovered||[]).length>0;
 $('supplyBrandHint').hidden=!noBrandRows;
 $('supplyBrandHint').textContent=noBrandRows?`선택한 브랜드의 반영 자료가 없습니다. E열에서 자신의 쇼핑몰 코드(${(v.discovered||[]).join(', ')})를 확인하고 위에서 선택한 뒤 수동갱신하세요. 브랜드를 임의로 전체 선택하지는 않습니다.`:'';
 $('supplyLoadDetail').textContent=`선택 브랜드 출고장 ${c.manifestRows||0}행 / ${c.manifestQty||0}개 · 진행상황 ${c.progressRows||0}행 (V 날짜 있음 ${c.progressWithDate||0}행 / V 미확인 ${c.progressWithoutOffice||0}행) · 물량 확보 ${c.securedItems||0}개 주문상품 · 예정일 이내(확정) ${c.confirmedItems||0}개`;
 $('supplyFilesRead').textContent=scan.error||((scan.files||[]).map(f=>`${f.kind==='manifest'?'출고장':'진행상황'}: ${f.name} · ${f.rows}행 / 선택 브랜드 ${f.selectedRows}행`).join('\n'));
 $('supplyBatches').innerHTML='<table><thead><tr><th>출고장</th><th>중국 출고일</th><th>등록 수량</th><th>상태</th></tr></thead><tbody>'+(v.batches||[]).map(b=>`<tr><td>${esc(b.name)}</td><td>${esc(b.date)}</td><td>${b.qty}</td><td>${b.closed?'마감 · 재배정 0':b.fileMissing?'파일 없음 · 출고장 갱신 시 기억 삭제':'물량 배정 중'}</td></tr>`).join('')+'</tbody></table>';
}
function populateSupplyForm(){
 const v=state.supply||{};$('supplyYear').value=v.year||2026;$('supplyHolidays').value=(v.holidays||[]).join('\n');$('supplyCalendarChecked').checked=(v.confirmedCalendarYears||[]).includes(v.year);
 const brands=[...new Set([...(v.discovered||[]),...(v.brands||[]),'N','NS'])].sort();
 $('brandChoices').innerHTML=brands.map(b=>`<label><input type="checkbox" value="${esc(b)}" ${(v.brands||[]).includes(b)?'checked':''}>${esc(b)}</label>`).join('');renderSupplyInformation();
}
function supplySettingsInput(){return {year:Number($('supplyYear').value),brands:[...$('brandChoices').querySelectorAll('input:checked')].map(x=>x.value),holidays:$('supplyHolidays').value.split(/\s+/).filter(Boolean),calendarConfirmed:$('supplyCalendarChecked').checked};}
$('supplyBtn').onclick=()=>{populateSupplyForm();$('supplyDialog').showModal();};
$('supplyYear').oninput=()=>{$('supplyCalendarChecked').checked=(state.supply.confirmedCalendarYears||[]).includes(Number($('supplyYear').value));};
$('linkSupplyFolder').onclick=()=>action(async()=>{
 const bridge=window.pywebview?.api;if(!bridge?.pick_supply_folder)throw Error('폴더 연결은 설치된 맥 앱에서 사용하세요. 웹 진단 화면에서는 지원하지 않습니다.');
 const r=await bridge.pick_supply_folder(token);if(!r)return;if(r.error)throw Error(r.error);toast(r.message);
},$('linkSupplyFolder'));
$('supplyAutoBtn').onclick=()=>action(async()=>{
 const enabled=!state.supply?.autoEnabled;
 if(enabled)await api('supply-settings',supplySettingsInput());
 const result=await api('supply-auto',{enabled});await refresh();toast(result.message);
},$('supplyAutoBtn'));
$('saveSupplySettings').onclick=()=>action(async()=>{toast((await api('supply-settings',supplySettingsInput())).message);},$('saveSupplySettings'));
$('refreshSupply').onclick=()=>action(async()=>{
 await api('supply-settings',supplySettingsInput());const r=await api('supply-refresh',{});await refresh();populateSupplyForm();toast(r.message);
},$('refreshSupply'));
$('resetManifestBtn').onclick=()=>action(async()=>{
 if(!confirm('출고가 진행된 당일 버튼을 눌러주세요.\n\n기억한 출고장 전체의 새 배정 수량을 0으로 마감합니다. 같은 파일을 다시 읽어도 되살아나지 않습니다. 기존 주문의 확보 근거만 유지합니다.\n\n실제 출고를 마쳤고, 이어서 최신 전체 미출고 엑셀을 올릴 예정인가요?'))return;
 const r=await api('supply-reset',{confirmed:true});await refresh();populateSupplyForm();toast(r.message);
},$('resetManifestBtn'));
$('reallocateManifestBtn').onclick=()=>action(async()=>{
 const info=state.supply.reallocation;if(!info?.available)throw Error('재배치할 최근 출고장 갱신 기록이 없습니다.');
 if(!confirm(`최근 출고장 갱신(${dateTime(info.at)})을 취소하고 현재 주문 순서대로 물량을 다시 배정합니다.\n\n${info.names.join('\n')}\n\n${info.requiresOriginal?'마감 당시와 동일한 원본 출고장 파일을 확인합니다.':`선택 브랜드 ${info.qty}개 물량을 복원합니다.`}\n실제로 출고하지 않은 물량을 실수로 마감한 경우에만 사용하세요. 복원할까요?`))return;
 const result=await api('supply-reallocate',{confirmed:true,token:info.token});await refresh();populateSupplyForm();toast(result.message);
},$('reallocateManifestBtn'));
async function readImportBytes(file){
 if(!file.name.toLowerCase().endsWith('.xlsx'))throw Error('에이블리 발송관리 .xlsx 파일을 선택하세요.');
 if(file.size>20*1024*1024)throw Error('20MB 이하 엑셀을 선택하세요.');
 const bytes=new Uint8Array(await file.arrayBuffer());let value='';for(let i=0;i<bytes.length;i+=16384)value+=String.fromCharCode(...bytes.subarray(i,i+16384));return {name:file.name,data:btoa(value)};
}
function invalidateExternal(){externalPlan=null;$('applyExternalBtn').disabled=true;$('externalMatches').innerHTML='';$('externalSummary').textContent='파일과 날짜를 선택하고 주문 대조를 눌러주세요.';}

$('externalDue').oninput=invalidateExternal;
$('pickExternalBtn').onclick=()=>action(async()=>{
 if(state.desktopMode){const bridge=window.pywebview?.api;if(!bridge?.pick_orders)throw Error('앱 파일 선택창이 준비되지 않았습니다.');const r=await bridge.pick_orders(token);if(!r)return;if(r.error)throw Error(r.error);if(!r.name.toLowerCase().endsWith('.xlsx'))throw Error('.xlsx 파일을 선택하세요.');externalFileData=r;$('externalFileName').textContent=r.name;invalidateExternal();}
 else $('externalFile').click();
},$('pickExternalBtn'));
$('externalFile').onchange=()=>action(async()=>{const file=$('externalFile').files[0];if(!file)return;externalFileData=await readImportBytes(file);$('externalFileName').textContent=file.name;invalidateExternal();});
$('externalPreviewBtn').onclick=()=>action(async()=>{
 if(!externalFileData)throw Error('안내를 보낸 주문만 있는 에이블리 발송관리 파일을 선택하세요.');
 externalPlan=await api('external-preview',{fileName:externalFileData.name,data:externalFileData.data,dueDate:$('externalDue').value});
 const p=externalPlan;$('externalSummary').textContent=`파일 ${p.sourceCount}개 상품 · 상품주문번호 일치 ${p.ready}개 / ${p.orders}개 주문 · 확인 필요 ${p.missing}개 · 출고 예정일 ${p.dueDate}`;
 $('externalMatches').innerHTML='<table><thead><tr><th>원본 행</th><th>주문번호</th><th>상품·옵션</th><th>대조</th></tr></thead><tbody>'+p.entries.map(e=>`<tr><td>${e.line}</td><td>${esc(e.orderId)}<span class="secondary">상품주문번호 ${esc(e.itemId||'없음')}</span></td><td>${esc(e.product)}<span class="secondary">${esc(e.option)}</span></td><td>${e.status==='ready'?'상품주문번호 일치 · 반영 가능':esc(e.reason)}</td></tr>`).join('')+'</tbody></table>';
 $('applyExternalBtn').disabled=!p.ready;
},$('externalPreviewBtn'));
$('applyExternalBtn').onclick=()=>action(async()=>{if(!externalPlan)return;const r=await api('external-apply',{token:externalPlan.token});externalPlan=null;$('externalDialog').close();toast(r.message);},$('applyExternalBtn'));
$('noSendBtn').onclick=()=>{
 if(!selected.size)return;
 if((state?.rows||[]).some(r=>selected.has(r.key)&&r.seller==='누아브 자사몰')){toast('자사몰 주문건이 끼어있습니다. 자사몰을 해제 후 보내주세요.',true);return;}noSendKeys=[...selected];noSendRequest=null;$('noSendDue').value='';$('noSendType').value='first';$('noSendSummary').textContent=`선택 ${noSendKeys.length}개 상품 · 예정일 변경 + 안내 이력 1회 추가 · 실제 발송 0통`;
 // 18시 이후(또는 09시 전)에는 문자 작성과 같이 즉시 / 오전 9시 예약 두 가지. 안내 이력·예정일은 둘 다 지금 바뀌고, 에이블리·지그재그 플랫폼 안내 시점만 다릅니다.
 const w=state?.sendWindow,night=!!w?.nightChoices,pending=(state?.pendingPlatformPushes||[]).length;
 $('noSendMorning').hidden=!night;$('noSendApply').textContent=night?'즉시 처리 · 플랫폼 안내 바로 전송':'선택 상품 안내 처리 · 실제 발송 없음';
 $('noSendScheduleHint').textContent=(night?`18시 이후입니다. 즉시 처리하면 에이블리·지그재그 안내를 지금 보내고, 오전 9시 예약은 ${dateTime(w.morningSendAt)}에 보냅니다.`:'')+(pending?` · 오전 9시 예약 대기 ${pending}건`:'');
 if(typeof zigzagNoSendCalendar==='function')zigzagNoSendCalendar(noSendKeys);
 $('noSendDialog').showModal();
};
async function applyNoSend(schedule){const payload={keys:noSendKeys,dueDate:$('noSendDue').value,templateKey:$('noSendType').value,mode:'set_due_date',schedule};
 if(zzNoSend&&zzNoSend.open&&!zzNoSend.allowed.includes(payload.dueDate))throw Error(zzNoSend.allowed.length?`지그재그 배송연기 안내는 ${zzNoSend.min} ~ ${zzNoSend.max} 중 평일(공휴일 제외)만 고를 수 있습니다.`:'선택한 지그재그 주문들의 가능 날짜가 겹치지 않습니다. 주문일이 비슷한 것끼리 나눠서 처리하세요.');
 const signature=JSON.stringify(payload);if(!noSendRequest||noSendRequest.signature!==signature)noSendRequest={signature,id:nuavuRequestId()};
 const r=await api('external-manual',{...payload,requestId:noSendRequest.id});selected.clear();$('noSendDialog').close();toast(r.message);}
$('noSendApply').onclick=()=>action(()=>applyNoSend('now'),$('noSendApply'));
$('noSendMorning').onclick=()=>action(()=>applyNoSend('morning'),$('noSendMorning'));
function openMatch(key){
 const r=state.rows.find(r=>r.key===key);if(!r?.active)return;
 matchingKey=key;matchingPicked=new Set();$('matchingOrder').textContent=r.product+' / '+r.option+' · '+r.qty+'개';$('matchSearch').value='';
 // Current manual candidates are passed as source IDs without needing order IDs as rules.
 const info=r.supplyInfo||{};$('matchingReason').textContent=(info.reason||'')+' · 옵션 해석: '+(info.parsedColor||'색상 미해석')+' / '+(info.parsedSize==='free'?'FREE (사이즈 미기재 포함)':(info.parsedSize||'사이즈 미해석'));for(const id of info.manualVariants||[])matchingPicked.add(id);
 const recommended=D.manualRecommended(r);$('matchRecommendedOnlyLabel').hidden=!recommended;$('matchRecommendedOnly').checked=recommended;
 if(recommended)$('matchingReason').textContent='수동매칭 권장 · '+info.manualRecommendations.map(x=>x.reason).join(' / ')+' · 실제 컬러를 확인한 뒤 연결할 후보를 선택하세요.';
 renderMatchCandidates();$('matchDialog').showModal();
}
function renderMatchCandidates(){
 const row=state.rows.find(r=>r.key===matchingKey),recommendations=new Map((row?.supplyInfo?.manualRecommendations||[]).map(x=>[x.variant,x]));
 const q=$('matchSearch').value.trim().toLowerCase();const variants=(state.supply?.variants||[]).filter(v=>(!$('matchRecommendedOnly').checked||recommendations.has(v.variant))&&(!q||[v.brand,v.product,v.color,v.colorLabel||'',v.size].join(' ').toLowerCase().includes(q))).sort((a,b)=>Number(recommendations.has(b.variant))-Number(recommendations.has(a.variant)));
 $('matchCandidates').innerHTML='<table><thead><tr><th>선택</th><th>브랜드</th><th>출고장·진행상황 상품명</th><th>컬러</th><th>사이즈</th><th>날짜 근거</th></tr></thead><tbody>'+variants.map(v=>`<tr class="${recommendations.has(v.variant)?'match-recommended-row':''}"><td><input class="match-check" type="checkbox" value="${esc(v.variant)}" aria-label="${esc(v.product+' / '+(v.colorLabel||v.color)+' / '+v.size)} 연결 후보 선택" ${matchingPicked.has(v.variant)?'checked':''}></td><td>${esc(v.brand)}</td><td>${esc(v.product)}<span class="secondary">${esc((v.origins||[]).map(x=>x==='manifest'?'완료 출고장':'진행상황').join(' · '))}</span>${recommendations.has(v.variant)?`<span class="secondary recommendation-reason">${esc(recommendations.get(v.variant).reason)}</span>`:''}</td><td>${esc(v.colorLabel||v.color)}${v.colorHasChinese?'<span class="secondary">원문: '+esc(v.color)+'</span>':''}</td><td>${esc(v.size)}</td><td>${(v.origins||[]).includes('manifest')?'완료 출고장 있음':(v.officeDates||[]).length?'V '+esc(v.officeDates.join(', ')):'V 공란/미확인 · 날짜 계산 안 함'}</td></tr>`).join('')+'</tbody></table>';
 $('matchSelectionCount').textContent=`표시 ${variants.length}개 · 선택 ${matchingPicked.size}개 · 여러 변형을 직접 선택하면 해당 물량을 합쳐 배정합니다.`;
}
$('matchSearch').oninput=renderMatchCandidates;
$('matchRecommendedOnly').onchange=renderMatchCandidates;
$('matchCandidates').onchange=e=>{if(e.target.classList.contains('match-check')){e.target.checked?matchingPicked.add(e.target.value):matchingPicked.delete(e.target.value);$('matchSelectionCount').textContent=`선택 ${matchingPicked.size}개`;}};
$('saveMatchBtn').onclick=()=>action(async()=>{if(!matchingPicked.size)throw Error('연결할 상품·옵션을 선택하세요.');toast((await api('supply-match',{key:matchingKey,variants:[...matchingPicked]})).message);$('matchDialog').close();},$('saveMatchBtn'));
$('clearMatchBtn').onclick=()=>action(async()=>{toast((await api('supply-match',{key:matchingKey,variants:[]})).message);$('matchDialog').close();},$('clearMatchBtn'));
// 2026-10-26 15:22 요청: 매칭 취소 — 이 상품명·옵션은 자동으로 연결하지 않음 (같은 상품명·옵션의 다른 주문에도 적용)
async function excludeMatch(key){const r=state.rows.find(x=>x.key===key);if(!r)return;if(!confirm(`'${r.product}' (${r.option}) 의 매칭을 취소할까요?\n같은 상품명·옵션의 다른 주문도 자동 연결하지 않습니다. 출고 예상일 근거가 사라집니다. 문자는 보내지 않습니다.`))return;toast((await api('supply-match',{key,variants:[],exclude:true})).message);}
$('excludeMatchBtn').onclick=()=>action(async()=>{await excludeMatch(matchingKey);$('matchDialog').close();},$('excludeMatchBtn'));
function openReceipt(key){
 const r=state.rows.find(r=>r.key===key);if(!r)return;const a=r.supplyInfo||{};
 const paths=(a.parts||[]).map(p=>{const x=p.path;return `<article class="historycard"><b>${p.kind==='manifest'?'완료 출고장':'진행상황'} · ${esc(p.sourceFile)} ${p.line}행 · ${p.allocated}개${p.sealed?' · 마감 후 이 주문에만 고정':''}</b><p>${esc(p.product)} / ${esc(p.color)} / ${esc(p.size)}</p><p>① ${p.kind==='manifest'?'완료 출고장 기준':'V열 중국 사무실 도착'} ${shortDay(x.basisDate)}<br>② 중국 출고 ${shortDay(x.chinaDate)}<br>③ <b>국내 출고 예상 ${shortDay(x.koreaStart)}${x.koreaStart!==x.koreaEnd?' ~ '+shortDay(x.koreaEnd):''}</b></p><p class="sub">지연 시 국내 출고 ${shortDay(x.koreaLatest)}까지의 계산값입니다. 고객 수령일이 아니며 통관·운송 보장이 아닙니다.</p></article>`;}).join('');
 const sourceRows=(a.sources||[]).map(x=>`<tr><td>${esc(x.sourceFile)}<span class="secondary">${esc(x.sheet)} ${x.line}행 · ${esc(x.brand)}</span></td><td>${esc(x.product)}<span class="secondary">${esc(x.color)} / ${esc(x.size)}</span></td><td>${x.qty}</td><td>${x.kind==='manifest'?'출고장':'진행상황'} V · ${D.validDate(x.officeDate)?esc(x.officeDate):'공란/미확인'}${!D.validDate(x.officeDate)&&x.officeRaw?'<span class="secondary">원본: '+esc(x.officeRaw)+'</span>':''}</td><td>${x.kind==='manifest'?'완료 출고장 '+esc(x.shipDate):x.officeDate?'V '+esc(x.officeDate):'V 공란/미확인 · 날짜 계산 안 함'}</td></tr>`).join('');
 $('receiptDetails').innerHTML=`<div class="notice"><b>${esc(r.product)}</b><br>${esc(r.option)} · 주문 ${r.qty}개 / 출고장 확보 ${a.manifestQty||0}개 / 진행상황 날짜 확인 물량 ${a.plannedQty||0}개<br>${esc(a.reason||'')}</div>`+(a.matched&&!a.inventoryQty?`<div class="settings-actions"><button class="tiny pink-button receipt-exclude" data-key="${esc(r.key)}">이 매칭 취소 (연결 안 함)</button><button class="tiny receipt-rematch" data-key="${esc(r.key)}">다른 상품으로 연결</button></div>`:'')+paths+(sourceRows?'<h3>매칭된 원본 자료</h3><div class="history-seed-table"><table><thead><tr><th>파일 / 행</th><th>상품 / 컬러 / 사이즈</th><th>J 수량</th><th>V 사무실 도착일</th><th>출고 계산 근거</th></tr></thead><tbody>'+sourceRows+'</tbody></table></div>':'')+'<p class="sub">진행상황과 출고장의 V 도착일을 각각 표시합니다. 진행상황 V가 없으면 L열로 출고일을 추정하지 않습니다. 완료 출고장의 수량·출고 예상일은 기존처럼 출고장 기준일을 사용하며 V 날짜 표시는 이 계산을 바꾸지 않습니다. 수동 매칭은 상품 연결만 하며 도착일을 만들지 않습니다.</p>';
 $('receiptDialog').showModal();
}
$('rows').addEventListener('click',e=>{const m=e.target.closest('.rowmatch,.rowmatch-edit');if(m)openMatch(m.dataset.key);const r=e.target.closest('.receipt-details,.source-details');if(r)openReceipt(r.dataset.key);});
$('receiptDetails').addEventListener('click',e=>{const x=e.target.closest('.receipt-exclude');if(x){action(async()=>{await excludeMatch(x.dataset.key);$('receiptDialog').close();},x);return;}const m=e.target.closest('.receipt-rematch');if(m){$('receiptDialog').close();openMatch(m.dataset.key);}});


// Shareable edition: shop identity applies to future drafts, never old ledgers.
function shopMessageTitle(soldout=false){return state?.messageTitles?.[soldout?'soldout':'delay']||((state?.settings?.shopName||'쇼핑몰')+(soldout?' 품절 안내':' 배송지연 안내'));}
function renderShopState(){
 const name=state.settings.shopName||'';
 $('shopBrandName').textContent=name||'배송안내';
 $('shopBannerName').textContent=(name?name+' ':'')+'배송안내 · v'+(state.appVersion||'0.6.141')+' 배포판';
 document.title=(name?name+' · ':'')+'배송안내 배포판';
 C.setShopName(name);templates=state.messageTemplates||templates;
 const tabOrder=['누아브 에이블리','누아브 아무드','누아브 자사몰','누아브 지그재그'];const channels=[...new Set(state.rows.map(r=>r.seller))].sort((a,b)=>(tabOrder.indexOf(a)+1||99)-(tabOrder.indexOf(b)+1||99));   // 2026-10-21 탭 순서
 if(seller&&!channels.includes(seller))seller='';
 $('sellerTabs').innerHTML='<button data-seller="" class="'+(!seller?'on':'')+'">전체 판매처</button>'+channels.map(key=>`<button data-seller="${esc(key)}" class="${seller===key?'on':''}">${esc(state.rows.find(r=>r.seller===key&&r.sourceSeller)?.sourceSeller||key.replace('누아브 ',''))}</button>`).join('');
 $('shopSettingsBtn').classList.toggle('needs-setup',!name);
 if(window.NuavuZoom)window.NuavuZoom.sync(state.settings?.tableZoom);
}
function shopGreeting(){const name=$('shopName').value.trim();$('shopGreeting').textContent='안녕하세요. 고객님\n'+(name||'쇼핑몰 이름')+'입니다.';}
function openShopSettings(){$('shopName').value=state?.settings?.shopName||'';$('shopSettingsResult').textContent='';shopGreeting();$('shopDialog').showModal();$('shopName').focus();}
$('shopSettingsBtn').onclick=openShopSettings;
$('shopName').addEventListener('input',shopGreeting);
$('saveShopBtn').onclick=()=>action(async()=>{const r=await api('shop-settings',{shopName:$('shopName').value});invalidate();$('shopSettingsResult').textContent=r.message;$('shopDialog').close();toast(r.message);},$('saveShopBtn'));

function renderDashboardSummary(){
 const personal=false,v=NuavuDashboard.summary(state.rows,D,r=>matchesNoticeFilter(r,'white'),messageGroups());
 const count=n=>Number(n).toLocaleString()+'건';
 const details=(id,lines,title='')=>{const el=$(id);if(!el)return;el.innerHTML=lines.map(s=>'<span>'+esc(s)+'</span>').join('<i aria-hidden="true"> / </i>');el.title=title||lines.join(' / ');};
 details('whiteSummary',['일정 확정 '+count(v.whiteDated),'일정 미확정 '+count(v.whiteUndated)],'안내 전 상품 중 출고 예상일 계산 여부입니다. 실제 출고 확정과는 다릅니다.');
 details('noticeSummary',['재발송 필요 '+count(v.resend),'미확정 · 이력 있음 '+count(v.unknownSeen),'미확정 · 이력 없음 '+count(v.unknownNew)]);
 const day=d=>Number(d.slice(5,7))+'월 '+Number(d.slice(8,10))+'일';
 details('dispatchSummary',[...v.dates.map(g=>(g.start===g.end?day(g.start):day(g.start)+' ~ '+day(g.end))+' '+count(g.count)),'계산 대기 '+count(v.waiting)],'상품 수 기준 · 같은 상품은 한 번만 셉니다. 날짜 범위는 그대로 표시합니다.');
 if(personal){
  details('exchangeSummary',['출고 가능 '+count(v.exchangeReady),'출고 불가 '+count(v.exchanges-v.exchangeReady)]);
  details('soldoutSummary',['안내 완료 '+count(v.soldout),'확인 필요 '+count(v.checkSoldout)]);
  details('bundleSummary',['합출고 가능 '+count(v.readyBundle),'부분 출고 가능 '+count(v.partialBundle),'합포 주문건(확정+예정) '+count(v.confirmedPlannedBundle)],'주문 수 기준 · 부분 출고 가능은 일부 상품만 현재고 전량 배정된 합포입니다. 전체 합포 발송 가능을 의미하지 않습니다. 입고 예정·미정 상품은 상세에서 확인하세요.');
  details('riskSummary',['감시 '+count(v.watch),'확정 '+count(v.confirmedRisk)]);
  details('readySummary',['단품 '+count(v.readySingle),'합포 '+count(v.readyBundle)]);
  $('readyCount').textContent=(v.readySingle+v.readyBundle).toLocaleString();
 }else details('exchangeSummary',['교환 대기 '+count(v.exchanges)]);
}

window.addEventListener('nuavu-return-closed',()=>render());

// 2026-10-23 지그재그 메시지 없는 배송지연: 지그재그 달력처럼 고를 수 있는 날짜만 (발송 예정일 다음 영업일 ~ +7영업일, 주말·공휴일 제외).
let zzNoSend=null;
function zigzagNoSendCalendar(keys){
 const box=$('noSendZigzag');const input=$('noSendDue');if(!box||!input)return;
 const rows=(state?.rows||[]).filter(r=>keys.includes(r.key)&&r.seller==='누아브 지그재그');
 input.removeAttribute('min');input.removeAttribute('max');zzNoSend=null;
 if(!rows.length){box.hidden=true;box.innerHTML='';return;}
 const live=rows.filter(r=>r.zigzagWindow&&r.zigzagWindow.open),closed=rows.filter(r=>!(r.zigzagWindow&&r.zigzagWindow.open));
 const closedNote=closed.length?`<p class="zz-closed">지그재그 ${closed.length}건은 지그재그 배송연기 안내를 보낼 수 없습니다 — 앱 안내 이력만 바뀝니다.<br>${closed.slice(0,6).map(r=>esc(r.orderId)+' · '+esc((r.zigzagWindow||{}).reason||'날짜 계산 불가')).join('<br>')}${closed.length>6?'<br>…':''}</p>`:'';
 if(!live.length){box.hidden=false;box.innerHTML=closedNote;return;}
 let allowed=live[0].zigzagWindow.allowed.slice();for(const r of live.slice(1))allowed=allowed.filter(d=>r.zigzagWindow.allowed.includes(d));
 const hol=new Set(live.flatMap(r=>r.zigzagWindow.holidays||[]));const deadline=live.map(r=>r.zigzagWindow.deadline).sort()[0];
 zzNoSend={open:live.length,allowed,min:allowed[0]||'',max:allowed[allowed.length-1]||''};
 if(allowed.length){input.min=allowed[0];input.max=allowed[allowed.length-1];}
 const unknown=live.some(r=>!r.zigzagWindow.calendarKnown);
 const months=[];if(allowed.length){let d=new Date(allowed[0]+'T00:00:00');d.setDate(1);const end=new Date(allowed[allowed.length-1]+'T00:00:00');while(d<=end){months.push(new Date(d));d.setMonth(d.getMonth()+1);}}
 const iso=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
 const grid=m=>{const y=m.getFullYear(),mo=m.getMonth(),first=new Date(y,mo,1).getDay(),days=new Date(y,mo+1,0).getDate();let h=`<div class="zz-month"><b>${y}년 ${mo+1}월</b><div class="zz-grid">`+['일','월','화','수','목','금','토'].map(w=>`<span class="zz-wd">${w}</span>`).join('')+'<span></span>'.repeat(first);
  for(let i=1;i<=days;i++){const k=iso(new Date(y,mo,i)),wd=new Date(y,mo,i).getDay(),ok=allowed.includes(k),isHol=hol.has(k);h+=`<button type="button" class="zz-day${ok?' ok':''}${wd===0||wd===6?' wkend':''}${isHol?' hol':''}${input.value===k?' on':''}" data-day="${k}" ${ok?'':'disabled'} title="${isHol?'공휴일 · 선택 불가':ok?'선택 가능':'선택 불가'}">${i}${isHol?'<small>휴</small>':''}</button>`;}
  return h+'</div></div>';};
 box.hidden=false;
 box.innerHTML=`<p class="zz-head"><b>지그재그 배송연기 안내 가능 날짜</b> · 지그재그 ${live.length}건 · ${allowed.length?esc(zzNoSend.min)+' ~ '+esc(zzNoSend.max):'겹치는 날짜 없음'} · 배송연기 안내 마감 ${esc(deadline)}까지</p>`+
  (allowed.length?`<div class="zz-months">${months.map(grid).join('')}</div>`:'<p class="zz-closed">선택한 지그재그 주문들의 가능 날짜가 겹치지 않습니다. 주문일이 비슷한 것끼리 나눠서 처리하세요.</p>')+
  `<p class="sub">초록 날짜만 고를 수 있습니다 · 빨간 '휴' = 공휴일 · 고객 안내 문자 작성은 날짜 제한이 없습니다.${unknown?' · 2027년 이후 공휴일은 아직 반영되지 않아 주말만 뺐습니다(확실하지 않음).':''}</p>`+closedNote;
 box.querySelectorAll('.zz-day.ok').forEach(b=>b.onclick=()=>{input.value=b.dataset.day;box.querySelectorAll('.zz-day.on').forEach(x=>x.classList.remove('on'));b.classList.add('on');});
 input.oninput=()=>{box.querySelectorAll('.zz-day').forEach(x=>x.classList.toggle('on',x.dataset.day===input.value));};
}
